/*    */ package net.sf.RecordEditor.editProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EditOptions
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/* 26 */     boolean jdbc = (args == null) || (args.length <= 0) || (!"nojdbc".equalsIgnoreCase(args[(args.length - 1)]));
/*    */     
/* 28 */     new net.sf.RecordEditor.re.editProperties.EditOptions(true, jdbc, true);
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/editProperties/EditOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */