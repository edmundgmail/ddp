/*     */ package net.sf.RecordEditor.re.db.Table;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.common.ReConnection;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ import net.sf.RecordEditor.utils.swing.AbsRowList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TableList
/*     */   extends AbsRowList
/*     */ {
/*     */   public static final int FOREIGN_LANGUAGE_FIELD_NO = 2;
/*  34 */   private TableDB tableDb = new TableDB();
/*     */   
/*     */ 
/*     */ 
/*     */   private String idName;
/*     */   
/*     */ 
/*     */ 
/*     */   private String name;
/*     */   
/*     */ 
/*     */   private int arraySize;
/*     */   
/*     */ 
/*     */   private int tableIdent;
/*     */   
/*     */ 
/*     */   private final boolean foreignTrans;
/*     */   
/*     */ 
/*     */ 
/*     */   public TableList(int connectionId, int tableId, boolean sort, boolean nullFirstRow, String propertiesIdName, String propertiesName, int propertiesArraySize)
/*     */   {
/*  57 */     this(connectionId, tableId, sort, nullFirstRow, propertiesIdName, propertiesName, propertiesArraySize, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public TableList(int connectionId, int tableId, boolean sort, boolean nullFirstRow, String propertiesIdName, String propertiesName, int propertiesArraySize, boolean foreignTranslation)
/*     */   {
/*  65 */     super(0, getNameIdx(tableId), sort, nullFirstRow);
/*     */     
/*  67 */     this.tableIdent = tableId;
/*  68 */     this.idName = propertiesIdName;
/*  69 */     this.name = propertiesName;
/*  70 */     this.arraySize = propertiesArraySize;
/*  71 */     this.foreignTrans = foreignTranslation;
/*     */     
/*  73 */     this.tableDb.setConnection(new ReConnection(connectionId));
/*  74 */     this.tableDb.setParams(tableId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void loadData()
/*     */   {
/*  81 */     super.loadData(getPropertiesAndDB());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final ArrayList<TableRec> getPropertiesAndDB()
/*     */   {
/*  91 */     ArrayList<TableRec> list = this.tableDb.fetchAll();
/*     */     
/*  93 */     int[] keys = Common.readIntPropertiesArray(this.idName, this.arraySize);
/*     */     
/*     */ 
/*  96 */     getForeignTranslation(list);
/*     */     
/*  98 */     if (keys != null) {
/*  99 */       for (int i = 0; i < this.arraySize; i++) {
/* 100 */         if (keys[i] != -121) {
/* 101 */           String s = Parameters.getString(this.name + i);
/*     */           
/* 103 */           if ((s != null) && (!"".equals(s))) {
/* 104 */             list.add(new TableRec(keys[i], s));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 110 */     return list;
/*     */   }
/*     */   
/*     */   protected void getForeignTranslation(ArrayList<TableRec> list) {
/*     */     String foreignLookUpId;
/* 115 */     if ((this.foreignTrans) && (isForeignTranslation(this.tableIdent))) {
/* 116 */       foreignLookUpId = TableDB.getTblLookupKey(this.tableIdent);
/* 117 */       for (TableRec rec : list) {
/* 118 */         rec.setField(2, LangConversion.convertId(12, foreignLookUpId + rec.getField(getKeyIdx()), fix(rec.getField(1))));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String fix(Object o)
/*     */   {
/* 131 */     if (o == null) return "";
/* 132 */     return o.toString();
/*     */   }
/*     */   
/*     */   private static int getNameIdx(int tableId) {
/* 136 */     int ret = 1;
/* 137 */     if (isForeignTranslation(tableId)) {
/* 138 */       ret = 2;
/*     */     }
/* 140 */     return ret;
/*     */   }
/*     */   
/*     */   private static boolean isForeignTranslation(int tableId) {
/* 144 */     return tableId != 3;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/db/Table/TableList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */