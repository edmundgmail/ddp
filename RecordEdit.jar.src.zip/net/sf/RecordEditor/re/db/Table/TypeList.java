/*    */ package net.sf.RecordEditor.re.db.Table;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import net.sf.RecordEditor.utils.params.Parameters;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypeList
/*    */   extends TableList
/*    */ {
/*    */   public TypeList(int connectionId, boolean sort, boolean nullFirstRow)
/*    */   {
/* 31 */     this(connectionId, sort, nullFirstRow, true);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public TypeList(int connectionId, boolean sort, boolean nullFirstRow, boolean foriegnTranslation)
/*    */   {
/* 42 */     super(connectionId, 1, sort, nullFirstRow, "TypeNumber.", "TypeName.", 30, foriegnTranslation);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void loadData()
/*    */   {
/* 67 */     ArrayList<TableRec> list = getPropertiesAndDB();
/*    */     
/* 69 */     int j = 90;
/*    */     
/* 71 */     for (int i = 0; i < 20; i++) {
/* 72 */       String name = Parameters.getString("DateTypeName." + i);
/* 73 */       if ((name != null) && (!"".equals(name))) {
/* 74 */         list.add(new TableRec(j, name));
/*    */       }
/* 76 */       j++;
/*    */     }
/*    */     
/*    */ 
/* 80 */     loadData(list);
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/db/Table/TypeList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */