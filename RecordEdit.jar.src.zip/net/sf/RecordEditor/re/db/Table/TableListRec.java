/*     */ package net.sf.RecordEditor.re.db.Table;
/*     */ 
/*     */ import net.sf.RecordEditor.utils.jdbc.AbsRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TableListRec
/*     */   extends AbsRecord
/*     */ {
/*     */   private int TBlId;
/*     */   protected int initTBlId;
/*     */   private String tblName;
/*     */   private String description;
/*     */   
/*     */   public TableListRec()
/*     */   {
/*  33 */     this.TBlId = 0;
/*  34 */     this.tblName = "";
/*  35 */     this.description = "";
/*     */     
/*  37 */     setKeys();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public TableListRec(int pTBlId, String pTblName, String pDescription)
/*     */   {
/*  45 */     super(false);
/*     */     
/*  47 */     this.TBlId = pTBlId;
/*  48 */     this.tblName = pTblName;
/*  49 */     this.description = pDescription;
/*     */     
/*  51 */     setKeys();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setKeys()
/*     */   {
/*  60 */     this.initTBlId = this.TBlId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object clone()
/*     */   {
/*  70 */     super.clone();
/*     */     
/*  72 */     TableListRec ret = new TableListRec(this.TBlId, this.tblName, this.description);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  78 */     ret.setNew(true);
/*  79 */     ret.setUpdateStatus(3);
/*     */     
/*  81 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFieldCount()
/*     */   {
/*  90 */     return 3;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getField(int fieldNum)
/*     */   {
/* 104 */     if (this.updateStatus == -1) { return "";
/*     */     }
/* 106 */     switch (fieldNum) {
/* 107 */     case 0:  return Integer.valueOf(this.TBlId);
/* 108 */     case 1:  return this.tblName;
/* 109 */     case 2:  return this.description; }
/* 110 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setFieldWithString(int fieldNum, String val)
/*     */   {
/* 123 */     switch (fieldNum) {
/* 124 */     case 0:  setTBlId(cnvToInt(this.TBlId, val, "Table Id"));
/* 125 */       break;
/* 126 */     case 1:  setTblName(val);
/* 127 */       break;
/* 128 */     case 2:  setDescription(val);
/* 129 */       break;
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setFieldWithObject(int fieldNum, Object val)
/*     */   {
/* 143 */     switch (fieldNum) {
/* 144 */     case 0:  setTBlId(((Integer)val).intValue());
/* 145 */       break;
/* 146 */     default:  setFieldWithString(fieldNum, (String)val);
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */   public int getTBlId()
/*     */   {
/* 154 */     return this.TBlId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTBlId(int val)
/*     */   {
/* 164 */     if ((val != this.TBlId) || (this.updateStatus == -1)) {
/* 165 */       this.TBlId = val;
/* 166 */       this.updateStatus = 3;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getTblName()
/*     */   {
/* 174 */     return this.tblName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTblName(String val)
/*     */   {
/* 184 */     if (((val == null) || ("".equals(val))) && ((this.tblName == null) || ("".equals(this.tblName))))
/*     */     {
/* 186 */       return;
/*     */     }
/*     */     
/* 189 */     if ((val == null) || (!val.equals(this.tblName)) || (this.updateStatus == -1)) {
/* 190 */       this.tblName = val;
/* 191 */       this.updateStatus = 3;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getDescription()
/*     */   {
/* 199 */     return this.description;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDescription(String val)
/*     */   {
/* 209 */     if (((val == null) || ("".equals(val))) && ((this.description == null) || ("".equals(this.description))))
/*     */     {
/* 211 */       return;
/*     */     }
/*     */     
/* 214 */     if ((val == null) || (!val.equals(this.description)) || (this.updateStatus == -1)) {
/* 215 */       this.description = val;
/* 216 */       this.updateStatus = 3;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/db/Table/TableListRec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */