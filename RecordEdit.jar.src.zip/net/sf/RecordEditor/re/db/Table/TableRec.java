/*     */ package net.sf.RecordEditor.re.db.Table;
/*     */ 
/*     */ import net.sf.RecordEditor.utils.jdbc.AbsRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TableRec
/*     */   extends AbsRecord
/*     */ {
/*     */   private int tblKey;
/*     */   protected int initTblKey;
/*     */   private String details;
/*  25 */   private String foreignName = "";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public TableRec()
/*     */   {
/*  32 */     this.tblKey = 0;
/*  33 */     this.details = "";
/*     */     
/*  35 */     setKeys();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public TableRec(int pTblKey, String pDetails)
/*     */   {
/*  42 */     super(false);
/*     */     
/*  44 */     this.tblKey = pTblKey;
/*  45 */     this.details = pDetails;
/*  46 */     this.foreignName = this.details;
/*     */     
/*  48 */     setKeys();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setKeys()
/*     */   {
/*  70 */     this.initTblKey = this.tblKey;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasTheKeyChanged()
/*     */   {
/*  81 */     return this.initTblKey != this.tblKey;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object clone()
/*     */   {
/*  91 */     super.clone();
/*     */     
/*  93 */     TableRec ret = new TableRec(this.tblKey, this.details);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  98 */     ret.setNew(true);
/*  99 */     ret.setUpdateStatus(3);
/*     */     
/* 101 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFieldCount()
/*     */   {
/* 110 */     return 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getField(int fieldNum)
/*     */   {
/* 124 */     if (this.updateStatus == -1) { return "";
/*     */     }
/* 126 */     switch (fieldNum) {
/* 127 */     case 0:  return Integer.valueOf(this.tblKey);
/* 128 */     case 1:  return this.details;
/* 129 */     case 2:  return this.foreignName; }
/* 130 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setFieldWithString(int fieldNum, String val)
/*     */   {
/* 143 */     switch (fieldNum) {
/* 144 */     case 0:  setTblKey(cnvToInt(this.tblKey, val, "TblKey")); break;
/* 145 */     case 1:  setDetails(val); break;
/* 146 */     case 2:  this.foreignName = val; break;
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setFieldWithObject(int fieldNum, Object val)
/*     */   {
/* 160 */     switch (fieldNum) {
/* 161 */     case 0:  setTblKey(((Integer)val).intValue());
/* 162 */       break;
/* 163 */     default:  setFieldWithString(fieldNum, (String)val);
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */   public int getTblKey()
/*     */   {
/* 171 */     return this.tblKey;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTblKey(int val)
/*     */   {
/* 181 */     if ((val != this.tblKey) || (this.updateStatus == -1)) {
/* 182 */       this.tblKey = val;
/* 183 */       this.updateStatus = 3;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getDetails()
/*     */   {
/* 191 */     return this.details;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDetails(String val)
/*     */   {
/* 201 */     if (((val == null) || ("".equals(val))) && ((this.details == null) || ("".equals(this.details))))
/*     */     {
/* 203 */       return;
/*     */     }
/*     */     
/* 206 */     if ((val == null) || (!val.equals(this.details)) || (this.updateStatus == -1)) {
/* 207 */       this.details = val;
/* 208 */       this.updateStatus = 3;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/db/Table/TableRec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */