/*     */ package net.sf.RecordEditor.re.db.Table;
/*     */ 
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import net.sf.RecordEditor.utils.jdbc.AbsDB;
/*     */ import net.sf.RecordEditor.utils.jdbc.AbsRecord;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TableListDB
/*     */   extends AbsDB<TableListRec>
/*     */ {
/*  30 */   private static final String[] COLUMN_NAMES = LangConversion.convertColHeading("DB-TableList Columns", new String[] { "Table Id", "Table Name", "Description" });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TableListDB()
/*     */   {
/*  42 */     resetSearch();
/*     */     
/*  44 */     this.sSQL = " Select  TBlId, TblName, TblDescription";
/*  45 */     this.sFrom = "  From   Tbl_T_Table";
/*  46 */     this.sWhereSQL = " ";
/*  47 */     this.sOrderBy = " ";
/*  48 */     this.updateSQL = "Update Tbl_T_Table   Set TBlId= ?    , TblName= ?    , TblDescription= ?  Where TBlId= ? ";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  56 */     this.columnNames = COLUMN_NAMES;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbsRecord absFetch()
/*     */   {
/*  65 */     return fetch();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public TableListRec fetch()
/*     */   {
/*  73 */     TableListRec ret = null;
/*     */     try
/*     */     {
/*  76 */       if (this.rsCursor.next()) {
/*  77 */         ret = new TableListRec(this.rsCursor.getInt(1), this.rsCursor.getString(2), this.rsCursor.getString(3));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*  83 */       this.message = "";
/*     */     } catch (Exception ex) {
/*  85 */       setMessage(ex.getMessage(), ex);
/*     */     }
/*     */     
/*  88 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColumnCount()
/*     */   {
/*  96 */     return 3;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int setSQLParams(PreparedStatement statement, TableListRec value, boolean insert, int idx)
/*     */     throws SQLException
/*     */   {
/* 115 */     statement.setInt(idx++, value.getTBlId());
/* 116 */     statement.setString(idx++, correctStr(value.getTblName()));
/* 117 */     statement.setString(idx++, correctStr(value.getDescription()));
/*     */     
/*     */ 
/* 120 */     return idx;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setWhere(PreparedStatement statement, TableListRec value, int idx)
/*     */     throws SQLException
/*     */   {
/* 135 */     statement.setInt(idx++, value.initTBlId);
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/db/Table/TableListDB.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */