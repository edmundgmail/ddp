/*    */ package net.sf.RecordEditor.re.db.Table;
/*    */ 
/*    */ import javax.swing.table.TableColumn;
/*    */ import javax.swing.table.TableColumnModel;
/*    */ import javax.swing.table.TableModel;
/*    */ import net.sf.RecordEditor.utils.swing.AbsJTable;
/*    */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class TableListJTbl
/*    */   extends AbsJTable
/*    */ {
/* 36 */   private static final int KEY_WIDTH = SwingUtils.STANDARD_FONT_WIDTH * 7;
/* 37 */   private static final int DESCRIPTION_WIDTH = SwingUtils.STANDARD_FONT_WIDTH * 33;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public TableListJTbl(TableModel mdl)
/*    */   {
/* 46 */     super(mdl);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setColumnSizes()
/*    */   {
/* 57 */     setAutoResizeMode(0);
/* 58 */     TableColumn tc = getColumnModel().getColumn(0);
/* 59 */     tc.setPreferredWidth(KEY_WIDTH);
/* 60 */     tc = getColumnModel().getColumn(1);
/* 61 */     tc.setPreferredWidth(DESCRIPTION_WIDTH);
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/db/Table/TableListJTbl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */