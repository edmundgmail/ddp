/*     */ package net.sf.RecordEditor.re.db.Table;
/*     */ 
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.jdbc.AbsDB;
/*     */ import net.sf.RecordEditor.utils.jdbc.DBComboModel;
/*     */ import net.sf.RecordEditor.utils.jdbc.DBList;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class TableDB
/*     */   extends AbsDB<TableRec>
/*     */ {
/*  31 */   private static final String[] COLUMN_NAMES = LangConversion.convertColHeading("DB-Table Columns", new String[] { "Row Key", "Details" });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int paramTblId;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public TableDB()
/*     */   {
/*  43 */     resetSearch();
/*     */     
/*  45 */     this.sSQL = " Select  TblKey, Details";
/*  46 */     this.sFrom = "  From   Tbl_TI_IntTbls";
/*  47 */     this.sWhereSQL = "  Where  TblId = ?";
/*  48 */     this.sOrderBy = "  Order By TblKey";
/*  49 */     this.updateSQL = "Update Tbl_TI_IntTbls   Set TblKey= ?    , Details= ?  Where TblId= ?    and TblKey= ? ";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  56 */     this.deleteSQL = "Delete From  Tbl_TI_IntTbls   Where TblId= ?    and TblKey= ? ";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  61 */     this.insertSQL = "Insert Into  Tbl_TI_IntTbls  (    TblKey  , Details  , TblId) Values (     ?   , ?   , ?)";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  69 */     this.columnNames = COLUMN_NAMES;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParams(int tblId)
/*     */   {
/*  81 */     this.paramTblId = tblId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void open()
/*     */   {
/*  89 */     prepareCursor();
/*     */     try
/*     */     {
/*  92 */       this.sqlCursor.setInt(1, this.paramTblId);
/*     */       
/*  94 */       setStringArgs(1);
/*     */       
/*     */ 
/*  97 */       this.rsCursor = this.sqlCursor.executeQuery();
/*  98 */       this.message = "";
/*     */     } catch (Exception ex) {
/* 100 */       setMessage(ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TableRec fetch()
/*     */   {
/* 117 */     TableRec ret = null;
/*     */     try
/*     */     {
/* 120 */       if (this.rsCursor.next()) {
/* 121 */         ret = new TableRec(this.rsCursor.getInt(1), this.rsCursor.getString(2));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 126 */       this.message = "";
/*     */     } catch (Exception ex) {
/* 128 */       setMessage(ex.getMessage(), ex);
/*     */     }
/*     */     
/* 131 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColumnCount()
/*     */   {
/* 139 */     return 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int setSQLParams(PreparedStatement statement, TableRec value, boolean insert, int idx)
/*     */     throws SQLException
/*     */   {
/* 158 */     statement.setInt(idx++, value.getTblKey());
/* 159 */     statement.setString(idx++, correctStr(value.getDetails()));
/*     */     
/* 161 */     if (insert) {
/* 162 */       statement.setInt(idx++, this.paramTblId);
/*     */     }
/*     */     
/* 165 */     return idx;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setWhere(PreparedStatement statement, TableRec value, int idx)
/*     */     throws SQLException
/*     */   {
/* 180 */     statement.setInt(idx++, this.paramTblId);
/* 181 */     statement.setInt(idx, value.initTblKey);
/*     */   }
/*     */   
/*     */   public DBComboModel<TableRec> getComboModel(int tblId, boolean sort, boolean nullAllowed) {
/* 185 */     setParams(tblId);
/*     */     DBComboModel<TableRec> ret;
/*     */     DBComboModel<TableRec> ret;
/* 188 */     if (tblId == 3) {
/* 189 */       ret = new DBComboModel(this, 0, 1, sort, nullAllowed);
/*     */     } else {
/* 191 */       ret = new DBComboModel(new DBList(this, 0, 1, 2, getTblLookupKey(tblId), sort, nullAllowed));
/*     */     }
/*     */     
/*     */ 
/* 195 */     return ret;
/*     */   }
/*     */   
/*     */   public static String getTblLookupKey(int tblId) {
/* 199 */     return Common.getTblLookupKey(tblId);
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/db/Table/TableDB.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */