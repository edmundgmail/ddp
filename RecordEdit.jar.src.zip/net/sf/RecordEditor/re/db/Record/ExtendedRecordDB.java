/*     */ package net.sf.RecordEditor.re.db.Record;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.HashMap;
/*     */ import net.sf.JRecord.External.ExternalRecord;
/*     */ import net.sf.JRecord.ExternalRecordSelection.ExternalFieldSelection;
/*     */ import net.sf.JRecord.ExternalRecordSelection.ExternalGroupSelection;
/*     */ import net.sf.JRecord.ExternalRecordSelection.ExternalSelection;
/*     */ import net.sf.JRecord.detailsSelection.RecordSel;
/*     */ import net.sf.RecordEditor.re.db.Table.TableDB;
/*     */ import net.sf.RecordEditor.re.db.Table.TableRec;
/*     */ import net.sf.RecordEditor.trove.map.hash.TIntObjectHashMap;
/*     */ import net.sf.RecordEditor.utils.ReadRecordSelection;
/*     */ import net.sf.RecordEditor.utils.common.AbsConnection;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.common.ReConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExtendedRecordDB
/*     */   extends RecordDB
/*     */ {
/*  46 */   private ChildRecordsDB childDb = null;
/*  47 */   private RecordFieldsDB fieldDb = null;
/*     */   
/*     */   private boolean recSelWarn;
/*  50 */   private TIntObjectHashMap<String> systemNamesMap = null;
/*  51 */   private HashMap<String, Integer> tableId = null;
/*  52 */   private int maxTblKey = 0;
/*     */   
/*     */   public ExternalRecord fetchExternal() {
/*  55 */     RecordRec rec = fetch();
/*  56 */     if (rec == null) {
/*  57 */       return null;
/*     */     }
/*  59 */     return rec.getValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public RecordRec fetch()
/*     */   {
/*  67 */     boolean free = super.isSetDoFree(false);
/*     */     
/*  69 */     RecordRec rec = super.fetch();
/*     */     
/*  71 */     if (rec == null) {
/*  72 */       closeChildDbs();
/*     */     } else {
/*  74 */       getSystemName(rec);
/*  75 */       defineChildDbs();
/*     */       
/*  77 */       fetch_Records(rec.getValue());
/*  78 */       fetch_Fields(rec.getValue());
/*     */     }
/*  80 */     super.setDoFree(free);
/*  81 */     return rec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void fetch_Records(ExternalRecord rec)
/*     */   {
/*  90 */     this.childDb.setParams(rec.getRecordId());
/*     */     
/*  92 */     this.childDb.open();
/*  93 */     ChildRecordsRec child = this.childDb.fetch();
/*     */     
/*     */ 
/*  96 */     if (child != null)
/*     */     {
/*  98 */       ReadRecordSelection readSel = ReadRecordSelection.getInstance();
/*     */       
/* 100 */       RecordDB recDb = new RecordDB();
/*     */       
/*     */ 
/* 103 */       recDb.setConnection(this.connect);
/* 104 */       while (child != null) {
/* 105 */         recDb.resetSearch();
/* 106 */         recDb.setSearchArg("RecordId", "=", "" + child.getChildRecordId());
/* 107 */         recDb.open();
/* 108 */         RecordRec r = recDb.fetch();
/*     */         
/* 110 */         if (r != null) {
/* 111 */           getSystemName(r);
/* 112 */           ExternalRecord childRecord = r.getValue();
/*     */           
/*     */ 
/*     */ 
/* 116 */           RecordSel recSel = readSel.getRecordSelection(this.connect, rec.getRecordId(), child.getChildKey(), null, child.getField(), child.getFieldValue());
/*     */           
/*     */ 
/* 119 */           if (recSel != null) {
/* 120 */             childRecord.setRecordSelection(recSel);
/*     */           }
/* 122 */           childRecord.setParentRecord(child.getParentRecord());
/*     */           
/* 124 */           fetch_Fields(childRecord);
/*     */           
/* 126 */           rec.addRecord(childRecord);
/*     */         }
/*     */         
/* 129 */         child = this.childDb.fetch();
/*     */       }
/*     */       
/* 132 */       for (int i = 0; i < rec.getNumberOfRecords(); i++) {
/* 133 */         int parentId = rec.getRecord(i).getParentRecord();
/* 134 */         for (int j = 0; j < rec.getNumberOfRecords(); j++) {
/* 135 */           int id = rec.getRecord(j).getRecordId();
/* 136 */           if (parentId == id) {
/* 137 */             rec.getRecord(i).setParentRecord(j);
/* 138 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void fetch_Fields(ExternalRecord rec)
/*     */   {
/* 149 */     this.fieldDb.setParams(rec.getRecordId());
/*     */     
/* 151 */     this.fieldDb.open();
/* 152 */     RecordFieldsRec field = this.fieldDb.fetch();
/* 153 */     while (field != null) {
/* 154 */       rec.addRecordField(field.getValue());
/* 155 */       field = this.fieldDb.fetch();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void checkAndUpdate(ExternalRecord rec)
/*     */   {
/* 166 */     checkAndUpdate(new RecordRec(rec));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void checkAndUpdate(RecordRec rec)
/*     */   {
/* 175 */     boolean free = super.isSetDoFree(false);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 182 */     if (rec.isNew())
/*     */     {
/*     */ 
/* 185 */       super.resetSearch();
/* 186 */       super.setSearchRecordName("=", rec.getRecordName());
/* 187 */       super.open();
/* 188 */       RecordRec old = super.fetch();
/* 189 */       super.close();
/*     */       
/* 191 */       if (old != null) {
/* 192 */         rec.getValue().setRecordId(old.getValue().getRecordId());
/* 193 */         rec.setNew(false);
/* 194 */         rec.setUpdateStatus(3);
/*     */       }
/*     */     }
/*     */     
/* 198 */     super.checkAndUpdate(rec);
/* 199 */     super.setDoFree(free);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void insert(RecordRec value)
/*     */   {
/* 207 */     boolean free = super.isSetDoFree(false);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 213 */     super.insert(value);
/*     */     
/* 215 */     updateChildSegments(value.getValue());
/* 216 */     writeFields(value.getValue());
/*     */     
/* 218 */     super.setDoFree(free);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void update(RecordRec val)
/*     */   {
/* 226 */     boolean free = super.isSetDoFree(false);
/*     */     try
/*     */     {
/* 229 */       super.doUpdate(val);
/*     */     } catch (Exception e) {
/* 231 */       super.insert(val);
/*     */     }
/*     */     
/* 234 */     updateChildSegments(val.getValue());
/* 235 */     writeFields(val.getValue());
/*     */     
/* 237 */     super.setDoFree(free);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void updateChildSegments(ExternalRecord rec)
/*     */   {
/* 247 */     boolean free = super.isSetDoFree(false);
/*     */     
/*     */ 
/* 250 */     if (rec.getNumberOfRecords() > 0)
/*     */     {
/*     */ 
/*     */ 
/* 254 */       ChildRecordsDB db = new ChildRecordsDB();
/* 255 */       db.setDoFree(false);
/* 256 */       for (int i = 0; i < rec.getNumberOfRecords(); i++) {
/* 257 */         ExternalRecord child = rec.getRecord(i);
/* 258 */         checkAndUpdate(child);
/*     */       }
/*     */       
/* 261 */       db.setConnection(this.connect);
/* 262 */       db.setParams(rec.getRecordId());
/* 263 */       db.deleteAll();
/*     */       
/*     */ 
/* 266 */       for (i = 0; i < rec.getNumberOfRecords(); i++) {
/* 267 */         ExternalRecord child = rec.getRecord(i);
/*     */         
/*     */ 
/* 270 */         if (child.getParentRecord() >= 0) {}
/*     */         
/*     */ 
/*     */ 
/* 274 */         ChildRecordsRec childRec = ChildRecordsRec.getBlankChildRec(child.getRecordId());
/* 275 */         childRec.setChildId(i);
/* 276 */         childRec.setParentRecord(child.getParentRecord());
/*     */         
/* 278 */         writeChild(db, rec.getRecordId(), childRec, child.getRecordSelection());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 298 */     if (rec.getNumberOfRecordFields() > 0) {
/* 299 */       RecordFieldsDB db = new RecordFieldsDB();
/* 300 */       db.setDoFree(false);
/* 301 */       db.setConnection(this.connect);
/* 302 */       db.setParams(rec.getRecordId());
/* 303 */       db.deleteAll();
/*     */       
/* 305 */       for (int i = 0; i < rec.getNumberOfRecordFields(); i++) {
/* 306 */         db.insert(new RecordFieldsRec(rec.getRecordField(i)));
/*     */       }
/*     */     }
/* 309 */     super.setDoFree(free);
/*     */   }
/*     */   
/*     */ 
/*     */   public final void writeChild(ChildRecordsDB db, int recordId, ChildRecordsRec childRec, ExternalSelection recordSel)
/*     */   {
/* 315 */     if (recordSel != null) {
/* 316 */       if ((recordSel instanceof ExternalGroupSelection))
/*     */       {
/* 318 */         ExternalGroupSelection grp = (ExternalGroupSelection)recordSel;
/* 319 */         if ((grp.size() == 1) && (updateSelectionFields(childRec, grp.get(0)))) {
/* 320 */           recordSel = null;
/* 321 */         } else if ((grp.size() == 2) && (grp.getType() == 2) && (grp.get(1).getType() != 1) && (updateSelectionFields(childRec, grp.get(0))))
/*     */         {
/*     */ 
/*     */ 
/* 325 */           recordSel = grp.get(1);
/*     */         }
/* 327 */       } else if (updateSelectionFields(childRec, recordSel)) {
/* 328 */         recordSel = null;
/*     */       }
/*     */     }
/* 331 */     db.insert(childRec);
/*     */     
/* 333 */     writeRecordSelection(recordId, childRec.getChildKey(), recordSel);
/*     */   }
/*     */   
/*     */   public final void writeRecordSelection(int recordId, int childKey, ExternalSelection recordSel) {
/* 337 */     RecordSelectionDB db = new RecordSelectionDB();
/*     */     
/* 339 */     db.setConnection(this.connect);
/* 340 */     db.setParams(recordId, childKey);
/* 341 */     db.deleteAll();
/*     */     
/* 343 */     this.recSelWarn = false;
/* 344 */     if (recordSel != null) {
/* 345 */       if ((recordSel instanceof ExternalGroupSelection))
/*     */       {
/* 347 */         ExternalGroupSelection grp = (ExternalGroupSelection)recordSel;
/*     */         
/* 349 */         if (grp.getType() == 2) {
/* 350 */           writeAndSelection(db, recordId, childKey, 1, 1, grp);
/*     */         } else {
/* 352 */           writeOrSelection(db, recordId, childKey, grp);
/*     */         }
/*     */       } else {
/* 355 */         writeSelectionField(db, recordId, childKey, 1, 1, recordSel);
/*     */       }
/*     */     }
/* 358 */     if (this.recSelWarn) {
/* 359 */       String s = "     ----- Warning  -- Waring ---------\n     ----------------------------------\n\n  The record Selection was to complicated to be loaded in to the Database\n\n  You need to update Record Selection manualy ";
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 364 */       System.out.println(s);
/* 365 */       Common.logMsgId("RecSel001", 30, s, null);
/*     */     }
/* 367 */     db.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeOrSelection(RecordSelectionDB db, int recordId, int childKey, ExternalGroupSelection grp)
/*     */   {
/* 375 */     int idx = 1;
/* 376 */     int op = 1;
/*     */     
/*     */ 
/* 379 */     for (int i = 0; i < grp.size(); i++) {
/* 380 */       ExternalSelection child = grp.get(i);
/* 381 */       if (child.getType() == 1) {
/* 382 */         writeSelectionField(db, recordId, childKey, idx++, op, child);
/* 383 */       } else if (child.getType() == 2) {
/* 384 */         idx = writeAndSelection(db, recordId, childKey, idx, op, (ExternalGroupSelection)child);
/*     */       } else {
/* 386 */         this.recSelWarn = true;
/*     */       }
/*     */       
/* 389 */       op = 0;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int writeAndSelection(RecordSelectionDB db, int recordId, int childKey, int fieldNo, int boolOp, ExternalGroupSelection grp)
/*     */   {
/* 398 */     int idx = fieldNo;
/*     */     
/* 400 */     for (int i = 0; i < grp.size(); i++) {
/* 401 */       if (grp.get(i).getType() == 1) {
/* 402 */         writeSelectionField(db, recordId, childKey, idx++, boolOp, grp.get(i));
/* 403 */         boolOp = 1;
/*     */       } else {
/* 405 */         this.recSelWarn = true;
/*     */       }
/*     */     }
/* 408 */     return idx;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeSelectionField(RecordSelectionDB db, int recordId, int childKey, int fieldNo, int boolOp, ExternalSelection recordSel)
/*     */   {
/* 416 */     if ((recordSel instanceof ExternalFieldSelection)) {
/* 417 */       ExternalFieldSelection fieldSel = (ExternalFieldSelection)recordSel;
/* 418 */       RecordSelectionRec selRec = new RecordSelectionRec(recordId, childKey, fieldNo, boolOp, fieldSel.getFieldName(), fieldSel.getOperator(), fieldSel.getFieldValue());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 423 */       db.insert(selRec);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean updateSelectionFields(ChildRecordsRec childRec, ExternalSelection recordSel) {
/* 428 */     boolean ret = false;
/* 429 */     if ((recordSel instanceof ExternalFieldSelection)) {
/* 430 */       ExternalFieldSelection fieldSel = (ExternalFieldSelection)recordSel;
/*     */       
/* 432 */       if (("=".equals(fieldSel.getOperator())) || ("eq".equalsIgnoreCase(fieldSel.getOperator()))) {
/* 433 */         childRec.setField(fieldSel.getFieldName());
/* 434 */         childRec.setFieldValue(fieldSel.getFieldValue());
/* 435 */         ret = true;
/*     */       }
/*     */     }
/*     */     
/* 439 */     return ret;
/*     */   }
/*     */   
/*     */   public void writeFields(ExternalRecord rec) {
/* 443 */     boolean free = super.isSetDoFree(false);
/* 444 */     int count = rec.getNumberOfRecordFields();
/* 445 */     if (count > 0)
/*     */     {
/* 447 */       RecordFieldsDB db = new RecordFieldsDB();
/* 448 */       db.setDoFree(false);
/* 449 */       db.setConnection(this.connect);
/*     */       
/* 451 */       db.setParams(rec.getRecordId());
/* 452 */       db.deleteAll();
/*     */       
/* 454 */       for (int i = 0; i < count; i++) {
/* 455 */         RecordFieldsRec field = new RecordFieldsRec(rec.getRecordField(i));
/* 456 */         field.setNew(true);
/* 457 */         db.insert(field);
/*     */       }
/*     */     }
/* 460 */     super.setDoFree(free);
/*     */   }
/*     */   
/*     */   public void delete(int recordId) {
/* 464 */     RecordRec rec = RecordRec.getNullRecord("xx", "");
/* 465 */     rec.getValue().setRecordId(recordId);
/*     */     
/*     */ 
/* 468 */     delete(rec);
/*     */   }
/*     */   
/*     */   public void delete(RecordRec rec)
/*     */   {
/* 473 */     boolean free = super.isSetDoFree(false);
/* 474 */     int recordId = rec.getRecordId();
/* 475 */     String deleteSQL = "Delete From  Tbl_RFS_FieldSelection Where RecordId = " + recordId;
/*     */     
/*     */ 
/* 478 */     defineChildDbs();
/*     */     
/* 480 */     this.childDb.setParams(recordId);
/* 481 */     this.fieldDb.setParams(recordId);
/*     */     
/* 483 */     this.childDb.deleteAll();
/* 484 */     this.fieldDb.deleteAll();
/*     */     try
/*     */     {
/* 487 */       this.connect.getUpdateConnection().createStatement().executeUpdate(deleteSQL);
/*     */     } catch (SQLException ex) {
/* 489 */       setMessage(deleteSQL, "Error Deleting: " + rec.getRecordName() + "\n" + ex.toString(), ex);
/*     */     }
/*     */     
/* 492 */     super.delete(rec);
/*     */     
/* 494 */     closeChildDbs();
/* 495 */     super.setDoFree(free);
/*     */   }
/*     */   
/*     */   private void defineChildDbs()
/*     */   {
/* 500 */     if (this.childDb == null) {
/* 501 */       this.childDb = new ChildRecordsDB();
/* 502 */       this.fieldDb = new RecordFieldsDB();
/* 503 */       this.childDb.setConnection(this.connect);
/* 504 */       this.childDb.setDoFree(false);
/* 505 */       this.fieldDb.setConnection(this.connect);
/* 506 */       this.fieldDb.setDoFree(false);
/*     */     }
/*     */   }
/*     */   
/*     */   private void closeChildDbs() {
/* 511 */     if (this.childDb != null) {
/* 512 */       this.childDb.close();
/* 513 */       this.fieldDb.close();
/* 514 */       this.childDb = null;
/*     */     }
/* 516 */     this.fieldDb = null;
/*     */   }
/*     */   
/*     */   private void getSystemName(RecordRec rec) {
/* 520 */     int system = rec.getSystem();
/* 521 */     if (this.systemNamesMap == null) {
/* 522 */       TIntObjectHashMap<String> sysNamesMap = new TIntObjectHashMap(30);
/*     */       
/* 524 */       TableDB tblsDB = new TableDB();
/* 525 */       tblsDB.setConnection(super.getConnect());
/* 526 */       tblsDB.resetSearch();
/* 527 */       tblsDB.setParams(3);
/* 528 */       tblsDB.open();
/* 529 */       TableRec tblDtl; while ((tblDtl = tblsDB.fetch()) != null) {
/* 530 */         sysNamesMap.put(tblDtl.getTblKey(), tblDtl.getDetails());
/*     */       }
/* 532 */       this.systemNamesMap = sysNamesMap;
/* 533 */       tblsDB.close();
/*     */     }
/*     */     
/* 536 */     String s = "";
/* 537 */     if (this.systemNamesMap.contains(system)) {
/* 538 */       s = (String)this.systemNamesMap.get(system);
/*     */     }
/* 540 */     rec.getValue().setSystemName(s);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static RecordRec getRecord(int dbIdx, int recordId)
/*     */   {
/* 547 */     ExtendedRecordDB dbFrom = new ExtendedRecordDB();
/* 548 */     boolean free = dbFrom.isSetDoFree(false);
/*     */     
/* 550 */     dbFrom.setConnection(new ReConnection(dbIdx));
/* 551 */     dbFrom.resetSearch();
/* 552 */     dbFrom.setSearchRecordId("=", recordId);
/* 553 */     dbFrom.open();
/*     */     
/* 555 */     RecordRec r = dbFrom.fetch();
/* 556 */     dbFrom.close();
/* 557 */     dbFrom.setDoFree(free);
/*     */     
/* 559 */     return r;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void updateSystemCode(ExternalRecord rec)
/*     */     throws SQLException
/*     */   {
/* 573 */     for (int i = 0; i < rec.getNumberOfRecords(); i++) {
/* 574 */       updateSystemCode(rec.getRecord(i));
/*     */     }
/*     */     
/* 577 */     String s = rec.getSystemName();
/* 578 */     if (s != null) {
/* 579 */       TableDB tblsDB = new TableDB();
/* 580 */       if (this.tableId == null) {
/* 581 */         this.tableId = new HashMap();
/* 582 */         this.maxTblKey = 0;
/*     */         
/* 584 */         tblsDB.setConnection(getConnect());
/* 585 */         tblsDB.resetSearch();
/* 586 */         tblsDB.setParams(3);
/* 587 */         tblsDB.open();
/* 588 */         TableRec aTbl; while ((aTbl = tblsDB.fetch()) != null) {
/* 589 */           int ckey = aTbl.getTblKey();
/* 590 */           this.tableId.put(aTbl.getDetails(), Integer.valueOf(ckey));
/* 591 */           if (this.maxTblKey < ckey) {
/* 592 */             this.maxTblKey = ckey;
/*     */           }
/*     */         }
/* 595 */         tblsDB.close();
/*     */       }
/*     */       
/*     */ 
/* 599 */       if (this.tableId.containsKey(s)) {
/* 600 */         Integer tblKey = (Integer)this.tableId.get(s);
/* 601 */         rec.setSystem(tblKey.intValue());
/*     */       } else {
/* 603 */         this.maxTblKey += 1;
/* 604 */         TableRec aTbl = new TableRec(this.maxTblKey, s);
/* 605 */         i = 0;
/* 606 */         while ((i++ < 15) && (!tblsDB.tryToInsert(aTbl))) {
/* 607 */           this.maxTblKey += 1;
/* 608 */           aTbl.setTblKey(this.maxTblKey);
/*     */         }
/* 610 */         this.tableId.put(s, Integer.valueOf(this.maxTblKey));
/*     */         
/* 612 */         if (this.systemNamesMap != null) {
/* 613 */           this.systemNamesMap.put(this.maxTblKey, s);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/db/Record/ExtendedRecordDB.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */