/*    */ package net.sf.RecordEditor.re.db.Record;
/*    */ 
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import net.sf.JRecord.External.CopybookWriter;
/*    */ import net.sf.JRecord.External.CopybookWriterManager;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ import net.sf.RecordEditor.utils.params.ProgramOptions.FileNameOpt;
/*    */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*    */ import net.sf.RecordEditor.utils.swing.DirectoryFrame;
/*    */ 
/*    */ public class SaveRecordAsXml implements ActionListener
/*    */ {
/* 14 */   private DirectoryFrame saveFrame = new DirectoryFrame("Save Layout", Common.OPTIONS.DEFAULT_COPYBOOK_DIRECTORY.get(), true, true, true);
/*    */   
/*    */ 
/*    */   private final int dbIdx;
/*    */   
/*    */   private final int recordId;
/*    */   
/*    */ 
/*    */   public SaveRecordAsXml(int databaseIdx, int recordId)
/*    */   {
/* 24 */     this.recordId = recordId;
/* 25 */     this.dbIdx = databaseIdx;
/*    */     
/* 27 */     this.saveFrame.setActionListner(this);
/* 28 */     this.saveFrame.setVisible(true);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void actionPerformed(ActionEvent event)
/*    */   {
/* 37 */     String dir = this.saveFrame.getFileName();
/*    */     
/* 39 */     if ((dir == null) || ("".equals(dir))) {
/* 40 */       this.saveFrame.panel.setMessageTxtRE("You must enter a directory to save the layout");
/*    */     } else {
/* 42 */       net.sf.RecordEditor.re.util.CopybookLoaderFactoryDB.setCurrentDB(this.dbIdx);
/* 43 */       RecordRec r = ExtendedRecordDB.getRecord(this.dbIdx, this.recordId);
/*    */       
/* 45 */       if (r != null) {
/* 46 */         CopybookWriter writer = (CopybookWriter)CopybookWriterManager.getInstance().get(1);
/*    */         try
/*    */         {
/* 49 */           writer.writeCopyBook(dir, r.getValue(), Common.getLogger());
/* 50 */           this.saveFrame.setVisible(false);
/* 51 */           this.saveFrame = null;
/*    */         } catch (Exception e) {
/* 53 */           this.saveFrame.panel.setMessageTxtRE("Error saving layout:", e.getMessage());
/* 54 */           e.printStackTrace();
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/db/Record/SaveRecordAsXml.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */