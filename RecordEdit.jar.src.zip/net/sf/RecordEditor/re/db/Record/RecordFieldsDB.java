/*     */ package net.sf.RecordEditor.re.db.Record;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import net.sf.JRecord.External.Def.ExternalField;
/*     */ import net.sf.RecordEditor.utils.common.AbsConnection;
/*     */ import net.sf.RecordEditor.utils.jdbc.AbsDB;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RecordFieldsDB
/*     */   extends AbsDB<RecordFieldsRec>
/*     */ {
/*  45 */   private static final String[] COLUMN_NAMES = LangConversion.convertColHeading("DB-RecordFields Columns", new String[] { "Position", "Length", "FieldName", "Description", "FieldType", "DecimalPos", "Cell_Format", "Parameter", "DefaultValue", "Cobol Name", "Field Id" });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  62 */   private PreparedStatement delAllRecordFields = null;
/*     */   private int paramRecordId;
/*     */   
/*     */   public RecordFieldsDB()
/*     */   {
/*  67 */     resetSearch();
/*     */     
/*  69 */     this.sSQL = " Select  Field_Pos, Field_Length, Field_Name, FIELD_DESCRIPTION, Field_Type, Decimal_Pos, Cell_Format, Field_Parameter, Default_Value, Cobol_Name, Sub_Key";
/*  70 */     this.sFrom = "  From Tbl_RF1_RecordFields";
/*  71 */     this.sWhereSQL = "  where RecordId = ?";
/*  72 */     this.sOrderBy = "  order by Field_Pos, Field_Length Desc";
/*  73 */     this.updateSQL = "Update Tbl_RF1_RecordFields   Set Field_Pos= ?    , Field_Length= ?    , Field_Name= ?    , FIELD_DESCRIPTION= ?    , Field_Type= ?    , Decimal_Pos= ?    , Cell_Format= ?    , Field_Parameter= ?    , Default_Value= ?    , Cobol_Name= ?    , Sub_Key= ?  Where RecordId= ?    and Sub_Key= ? ";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  89 */     this.deleteSQL = "Delete From  Tbl_RF1_RecordFields   Where RecordId= ?    and Sub_Key= ? ";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  94 */     this.insertSQL = "Insert Into  Tbl_RF1_RecordFields  (    Field_Pos  , Field_Length  , Field_Name  , Field_Description  , Field_Type  , Decimal_Pos  , Cell_Format  , Field_Parameter  , Default_Value  , Cobol_Name  , Sub_Key  , RecordId) Values (     ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 111 */     this.columnNames = COLUMN_NAMES;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParams(int RecordId)
/*     */   {
/* 123 */     this.paramRecordId = RecordId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void open()
/*     */   {
/* 131 */     prepareCursor();
/*     */     try
/*     */     {
/* 134 */       this.sqlCursor.setInt(1, this.paramRecordId);
/*     */       
/* 136 */       setStringArgs(1);
/*     */       
/*     */ 
/* 139 */       this.rsCursor = this.sqlCursor.executeQuery();
/* 140 */       this.message = "";
/*     */     } catch (Exception ex) {
/* 142 */       setMessage(ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RecordFieldsRec fetch()
/*     */   {
/* 159 */     RecordFieldsRec ret = null;
/*     */     try
/*     */     {
/* 162 */       if (this.rsCursor.next()) {
/* 163 */         ret = new RecordFieldsRec(this.rsCursor.getInt(1), this.rsCursor.getInt(2), this.rsCursor.getString(3), this.rsCursor.getString(4), this.rsCursor.getInt(5), this.rsCursor.getInt(6), this.rsCursor.getInt(7), this.rsCursor.getString(8), this.rsCursor.getString(9), this.rsCursor.getString(10), this.rsCursor.getInt(11));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 177 */       this.message = "";
/*     */     } catch (Exception ex) {
/* 179 */       setMessage(ex.getMessage(), ex);
/*     */     }
/*     */     
/* 182 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColumnCount()
/*     */   {
/* 190 */     return 10;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int setSQLParams(PreparedStatement statement, RecordFieldsRec value, boolean insert, int idx)
/*     */     throws SQLException
/*     */   {
/* 208 */     RecordFieldsRec val = value;
/*     */     
/* 210 */     statement.setInt(idx++, val.getValue().getPos());
/* 211 */     statement.setInt(idx++, val.getValue().getLen());
/* 212 */     statement.setString(idx++, correctStr(val.getValue().getName()));
/* 213 */     statement.setString(idx++, correctStr(val.getValue().getDescription()));
/* 214 */     statement.setInt(idx++, val.getValue().getType());
/* 215 */     statement.setInt(idx++, val.getValue().getDecimal());
/* 216 */     statement.setInt(idx++, val.getValue().getCellFormat());
/* 217 */     statement.setString(idx++, correctStr(val.getValue().getParameter()));
/* 218 */     statement.setString(idx++, correctStr(val.getValue().getDefault()));
/* 219 */     statement.setString(idx++, correctStr(val.getValue().getCobolName()));
/* 220 */     statement.setInt(idx++, val.getValue().getSubKey());
/*     */     
/* 222 */     if (insert) {
/* 223 */       statement.setInt(idx++, this.paramRecordId);
/*     */     }
/*     */     
/* 226 */     return idx;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setWhere(PreparedStatement statement, RecordFieldsRec value, int idx)
/*     */     throws SQLException
/*     */   {
/* 241 */     statement.setInt(idx++, this.paramRecordId);
/* 242 */     statement.setInt(idx, value.initSubKey);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void deleteAll()
/*     */   {
/*     */     try
/*     */     {
/* 253 */       open();
/* 254 */       boolean doDelete = fetch() != null;
/* 255 */       close();
/* 256 */       if (doDelete) {
/* 257 */         if (isPrepareNeeded(this.delAllRecordFields)) {
/* 258 */           this.delAllRecordFields = this.connect.getUpdateConnection().prepareStatement("Delete From  Tbl_RF1_RecordFields   Where RecordId= ? ");
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 264 */         this.delAllRecordFields.setInt(1, this.paramRecordId);
/*     */         
/* 266 */         this.delAllRecordFields.executeUpdate();
/* 267 */         this.message = "";
/*     */       }
/*     */     } catch (Exception ex) {
/* 270 */       setMessage(ex.getMessage(), ex);
/*     */     } finally {
/* 272 */       freeConnection();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int getNextKey()
/*     */   {
/* 282 */     String sql = "Select max(Sub_Key) From  Tbl_RF1_RecordFields  Where RecordId= ? ";
/*     */     
/*     */ 
/*     */ 
/* 286 */     return getNextIntSubKey("Select max(Sub_Key) From  Tbl_RF1_RecordFields  Where RecordId= ? ", this.paramRecordId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void insert(RecordFieldsRec value)
/*     */   {
/* 301 */     int i = 0;
/* 302 */     boolean free = super.isSetDoFree(false);
/*     */     
/* 304 */     int key = getNextKey();
/*     */     
/* 306 */     value.getValue().setSubKey(key++);
/* 307 */     while ((i++ < 10) && (!tryToInsert(value))) {
/* 308 */       value.getValue().setSubKey(key++);
/*     */     }
/*     */     
/* 311 */     super.setDoFree(free);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void fullClose()
/*     */   {
/* 322 */     super.fullClose();
/*     */     
/* 324 */     closeStatement(this.delAllRecordFields);
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/db/Record/RecordFieldsDB.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */