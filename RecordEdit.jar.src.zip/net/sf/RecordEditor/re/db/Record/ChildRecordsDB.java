/*     */ package net.sf.RecordEditor.re.db.Record;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.sf.RecordEditor.utils.common.AbsConnection;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.jdbc.AbsDB;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChildRecordsDB
/*     */   extends AbsDB<ChildRecordsRec>
/*     */ {
/*     */   public static final String DB_NAME = "Tbl_RS2_SubRecords";
/*  37 */   private static final String[] COLUMN_NAMES = LangConversion.convertColHeading("DB-ChildRecords columns", new String[] { "Child Record", "Child Name", "Field", "Field Value", "Tree Parent" });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String selectParentSql = "Select RecordId from Tbl_RS2_SubRecords where Child_Record=";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  51 */   private PreparedStatement delAllChildRecords = null;
/*     */   
/*     */   private int paramRecordId;
/*     */   
/*     */   public ChildRecordsDB()
/*     */   {
/*  57 */     resetSearch();
/*     */     
/*  59 */     this.sSQL = " Select  Child_Record, Field_Start, Field_Name, Field_Value, PARENT_RECORDID, Child_Key, Operator_Sequence , default_Record, Child_Name , Child_Id ";
/*     */     
/*  61 */     this.sFrom = "  from Tbl_RS2_SubRecords";
/*  62 */     this.sWhereSQL = "  where RecordId = ?";
/*  63 */     this.sOrderBy = " Order by Child_Key";
/*  64 */     this.updateSQL = "Update Tbl_RS2_SubRecords Set Child_Key= ?    , Child_Record= ?    , Field_Start= ?    , Field_Name= ?    , Field_Value= ?    , PARENT_RECORDID = ?   , Operator_Sequence = ?   , Default_Record = ?   , Child_Name = ?    , Child_Id = ?  Where RecordId= ?    and Child_Key= ? ";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  79 */     this.deleteSQL = "Delete From  Tbl_RS2_SubRecords Where RecordId= ?    and Child_Key= ? ";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  84 */     this.insertSQL = "Insert Into  Tbl_RS2_SubRecords  (    Child_Key  , Child_Record  , Field_Start  , Field_Name  , Field_Value  , PARENT_RECORDID  , Operator_Sequence  , default_Record   , Child_Name  , Child_Id  , RecordId) Values (     ?   , ?   , ?   , ?   , ?, ?   , ?, ?, ?, ?, ?)";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 101 */     this.columnNames = COLUMN_NAMES;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParams(int recordId)
/*     */   {
/* 113 */     this.paramRecordId = recordId;
/*     */   }
/*     */   
/*     */   public int getRecordId()
/*     */   {
/* 118 */     return this.paramRecordId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void open()
/*     */   {
/* 126 */     prepareCursor();
/*     */     try
/*     */     {
/* 129 */       this.sqlCursor.setInt(1, this.paramRecordId);
/*     */       
/* 131 */       setStringArgs(1);
/*     */       
/*     */ 
/* 134 */       this.rsCursor = this.sqlCursor.executeQuery();
/* 135 */       this.message = "";
/*     */     } catch (Exception ex) {
/* 137 */       setMessage(ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ChildRecordsRec fetch()
/*     */   {
/* 154 */     ChildRecordsRec ret = null;
/*     */     try
/*     */     {
/* 157 */       if (this.rsCursor.next()) {
/* 158 */         ret = new ChildRecordsRec(this.rsCursor.getInt(1), this.rsCursor.getInt(2), this.rsCursor.getString(3), this.rsCursor.getString(4), this.rsCursor.getInt(5), this.rsCursor.getInt(6), this.rsCursor.getInt(7), "Y".equalsIgnoreCase(this.rsCursor.getString(8)), this.rsCursor.getString(9), this.rsCursor.getInt(10));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 171 */       this.message = "";
/*     */     } catch (Exception ex) {
/* 173 */       setMessage(ex.getMessage(), ex);
/*     */     }
/*     */     
/* 176 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColumnCount()
/*     */   {
/* 184 */     return 5;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int setSQLParams(PreparedStatement statement, ChildRecordsRec value, boolean insert, int idx)
/*     */     throws SQLException
/*     */   {
/* 202 */     ChildRecordsRec val = value;
/* 203 */     int childId = value.getChildId();
/* 204 */     String defaultRec = "N";
/*     */     
/* 206 */     if (value.isDefaultRecord()) {
/* 207 */       defaultRec = "Y";
/*     */     }
/*     */     
/* 210 */     if (childId < 0) {
/* 211 */       String sql = "Select max(Child_Id) From  Tbl_RS2_SubRecords  Where RecordId= ? ";
/*     */       
/*     */ 
/* 214 */       childId = getNextIntSubKey("Select max(Child_Id) From  Tbl_RS2_SubRecords  Where RecordId= ? ", this.paramRecordId);
/*     */     }
/*     */     
/* 217 */     statement.setInt(idx++, val.getChildKey());
/* 218 */     statement.setInt(idx++, val.getChildRecordId());
/* 219 */     statement.setInt(idx++, val.getStart());
/* 220 */     statement.setString(idx++, correctStr(val.getField()));
/* 221 */     statement.setString(idx++, correctStr(val.getFieldValue()));
/* 222 */     statement.setInt(idx++, val.getParentRecord());
/* 223 */     statement.setInt(idx++, val.getOperatorSequence());
/* 224 */     statement.setString(idx++, defaultRec);
/* 225 */     statement.setString(idx++, val.getChildName());
/* 226 */     statement.setInt(idx++, childId);
/*     */     
/*     */ 
/* 229 */     if (insert) {
/* 230 */       statement.setInt(idx++, this.paramRecordId);
/*     */     }
/*     */     
/* 233 */     return idx;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setWhere(PreparedStatement statement, ChildRecordsRec value, int idx)
/*     */     throws SQLException
/*     */   {
/* 249 */     statement.setInt(idx++, this.paramRecordId);
/* 250 */     statement.setInt(idx++, value.initChildKey);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void delete(ChildRecordsRec val)
/*     */   {
/* 260 */     String updSql = "Delete from  TBL_RFS_FIELDSELECTION where RECORDID = " + this.paramRecordId + "  and Child_Key = " + val.getChildKey();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 267 */       this.connect.getUpdateConnection().createStatement().execute(updSql);
/*     */     } catch (Exception e) {
/* 269 */       Common.logMsg(updSql, null);
/* 270 */       Common.logMsg(30, "Update Failed:", e.getClass().getName() + " " + e.getMessage(), e);
/* 271 */       e.printStackTrace();
/*     */     }
/*     */     
/*     */ 
/* 275 */     super.delete(val);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void deleteAll()
/*     */   {
/*     */     try
/*     */     {
/* 285 */       open();
/* 286 */       boolean doDelete = fetch() != null;
/* 287 */       close();
/*     */       
/* 289 */       if (doDelete) {
/* 290 */         if (isPrepareNeeded(this.delAllChildRecords)) {
/* 291 */           this.delAllChildRecords = this.connect.getUpdateConnection().prepareStatement("Delete From  Tbl_RS2_SubRecords Where RecordId= ? ");
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 297 */         this.delAllChildRecords.setInt(1, this.paramRecordId);
/*     */         
/* 299 */         this.delAllChildRecords.executeUpdate();
/* 300 */         this.message = "";
/*     */       }
/*     */     } catch (Exception ex) {
/* 303 */       setMessage(ex.getMessage(), ex);
/*     */     } finally {
/* 305 */       freeConnection();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void insert(ChildRecordsRec value)
/*     */   {
/* 317 */     int i = 0;
/* 318 */     boolean free = super.isSetDoFree(false);
/*     */     
/* 320 */     int key = getNextKey();
/*     */     
/* 322 */     value.setChildKey(key++);
/* 323 */     while ((i++ < 10) && (!tryToInsert(value))) {
/* 324 */       value.setChildKey(key++);
/*     */     }
/*     */     
/* 327 */     super.setDoFree(free);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int getNextKey()
/*     */   {
/* 335 */     String sql = "Select max(Child_Key) From  Tbl_RS2_SubRecords  Where RecordId= ? ";
/*     */     
/*     */ 
/* 338 */     return getNextIntSubKey("Select max(Child_Key) From  Tbl_RS2_SubRecords  Where RecordId= ? ", this.paramRecordId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void fullClose()
/*     */   {
/* 347 */     super.fullClose();
/*     */     
/* 349 */     closeStatement(this.delAllChildRecords);
/*     */   }
/*     */   
/*     */ 
/*     */   public List<Integer> getRecordsThatUse(int childRecordId)
/*     */   {
/* 355 */     String selectSql = "Select RecordId from Tbl_RS2_SubRecords where Child_Record=" + childRecordId;
/* 356 */     ret = new ArrayList();
/* 357 */     PreparedStatement cursor = null;
/* 358 */     ResultSet rs = null;
/*     */     try
/*     */     {
/* 361 */       cursor = this.connect.getConnection().prepareStatement(selectSql);
/* 362 */       rs = cursor.executeQuery();
/* 363 */       while (rs.next()) {
/* 364 */         ret.add(Integer.valueOf(rs.getInt(1)));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 383 */       return ret;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 367 */       Common.logMsg(selectSql, null);
/* 368 */       Common.logMsg(30, "Read Failed:", e.getClass().getName() + " " + e.getMessage(), e);
/* 369 */       e.printStackTrace();
/*     */     } finally {
/* 371 */       if (cursor != null) {
/*     */         try {
/* 373 */           if (rs != null) {
/* 374 */             rs.close();
/*     */           }
/* 376 */           cursor.close();
/*     */         } catch (SQLException e) {
/* 378 */           e.printStackTrace();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/db/Record/ChildRecordsDB.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */