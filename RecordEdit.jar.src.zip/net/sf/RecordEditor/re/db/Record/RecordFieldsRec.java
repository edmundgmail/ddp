/*     */ package net.sf.RecordEditor.re.db.Record;
/*     */ 
/*     */ import net.sf.JRecord.External.Def.ExternalField;
/*     */ import net.sf.RecordEditor.utils.jdbc.AbsRecord;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.TreeComboItem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RecordFieldsRec
/*     */   extends AbsRecord
/*     */ {
/*     */   protected int initSubKey;
/*     */   private ExternalField value;
/*     */   
/*     */   public RecordFieldsRec()
/*     */   {
/*  56 */     this.value = new ExternalField();
/*  57 */     setExternalValue(this.value);
/*  58 */     setKeys();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RecordFieldsRec(int pPos, int pLen, String pName, String pDescription, int pType, int pDecimal, int pCellFormat, String pParameter, String pDefault, String pCobolName, int pSubKey)
/*     */   {
/*  88 */     this(new ExternalField(pPos, pLen, pName, pDescription, pType, pDecimal, pCellFormat, pParameter, pDefault, pCobolName, pSubKey));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RecordFieldsRec(ExternalField field)
/*     */   {
/* 107 */     super(false);
/*     */     
/* 109 */     this.value = field;
/* 110 */     setExternalValue(this.value);
/* 111 */     setKeys();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setKeys()
/*     */   {
/* 119 */     this.initSubKey = this.value.getSubKey();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasTheKeyChanged()
/*     */   {
/* 131 */     return this.initSubKey != this.value.getSubKey();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object clone()
/*     */   {
/* 141 */     super.clone();
/*     */     
/* 143 */     RecordFieldsRec ret = new RecordFieldsRec(this.value.fullClone());
/*     */     
/*     */ 
/*     */ 
/* 147 */     ret.setNew(true);
/* 148 */     ret.setUpdateStatus(3);
/*     */     
/* 150 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFieldCount()
/*     */   {
/* 159 */     return 11;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getField(int fieldNum)
/*     */   {
/* 173 */     if (this.updateStatus == -1) { return "";
/*     */     }
/* 175 */     switch (fieldNum) {
/* 176 */     case 0:  return Integer.valueOf(this.value.getPos());
/* 177 */     case 1:  return Integer.valueOf(this.value.getLen());
/* 178 */     case 2:  return this.value.getName();
/* 179 */     case 3:  return this.value.getDescription();
/* 180 */     case 4:  return Integer.valueOf(this.value.getType());
/* 181 */     case 5:  return Integer.valueOf(this.value.getDecimal());
/* 182 */     case 6:  return Integer.valueOf(this.value.getCellFormat());
/* 183 */     case 7:  return this.value.getParameter();
/* 184 */     case 8:  return this.value.getDefault();
/* 185 */     case 9:  return this.value.getCobolName();
/* 186 */     case 10:  return Integer.valueOf(this.value.getSubKey()); }
/* 187 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setFieldWithString(int fieldNum, String val)
/*     */   {
/* 200 */     switch (fieldNum) {
/* 201 */     case 0:  this.value.setPos(cnvToInt(this.value.getPos(), val, "Position"));
/* 202 */       break;
/* 203 */     case 1:  this.value.setLen(cnvToInt(this.value.getLen(), val, "Length"));
/* 204 */       break;
/* 205 */     case 2:  this.value.setName(val);
/* 206 */       break;
/* 207 */     case 3:  this.value.setDescription(val);
/* 208 */       break;
/* 209 */     case 4:  this.value.setType(cnvToInt(this.value.getType(), val, "FieldType"));
/* 210 */       break;
/* 211 */     case 5:  this.value.setDecimal(cnvToInt(this.value.getDecimal(), val, "DecimalPos"));
/* 212 */       break;
/* 213 */     case 6:  this.value.setCellFormat(cnvToInt(this.value.getCellFormat(), val, "Cell_Format"));
/* 214 */       break;
/* 215 */     case 7:  this.value.setParameter(val);
/* 216 */       break;
/* 217 */     case 8:  this.value.setDefault(val);
/* 218 */       break;
/* 219 */     case 9:  this.value.setCobolName(val);
/* 220 */       break;
/* 221 */     case 10:  this.value.setSubKey(cnvToInt(this.value.getSubKey(), val, "Field Id"));
/* 222 */       break;
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setFieldWithObject(int fieldNum, Object val)
/*     */   {
/* 236 */     switch (fieldNum) {
/* 237 */     case 0:  this.value.setPos(((Integer)val).intValue());
/* 238 */       break;
/* 239 */     case 1:  this.value.setLen(((Integer)val).intValue());
/* 240 */       break;
/* 241 */     case 4:  this.value.setType(getInt(val));
/* 242 */       break;
/* 243 */     case 5:  this.value.setDecimal(getInt(val));
/* 244 */       break;
/* 245 */     case 6:  this.value.setCellFormat(((Integer)val).intValue());
/* 246 */       break;
/* 247 */     case 10:  this.value.setSubKey(((Integer)val).intValue());
/* 248 */       break;
/* 249 */     case 2: case 3: case 7: case 8: case 9: default:  setFieldWithString(fieldNum, (String)val);
/*     */     }
/*     */   }
/*     */   
/*     */   public int getInt(Object val)
/*     */   {
/* 255 */     if ((val instanceof TreeComboItem))
/* 256 */       return ((Integer)((TreeComboItem)val).key).intValue();
/* 257 */     if ((val instanceof Number)) {
/* 258 */       return ((Number)val).intValue();
/*     */     }
/* 260 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExternalField getValue()
/*     */   {
/* 268 */     return this.value;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/db/Record/RecordFieldsRec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */