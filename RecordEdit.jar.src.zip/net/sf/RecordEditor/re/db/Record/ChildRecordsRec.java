/*     */ package net.sf.RecordEditor.re.db.Record;
/*     */ 
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.jdbc.AbsRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChildRecordsRec
/*     */   extends AbsRecord
/*     */ {
/*     */   public static final int OP_OR_AND = 0;
/*     */   private int childRecord;
/*     */   protected int initChildKey;
/*     */   private int start;
/*     */   private String field;
/*     */   private String fieldValue;
/*     */   private int parentRecord;
/*     */   private int childKey;
/*  34 */   private int operatorSequence = 0;
/*     */   private boolean defaultRecord;
/*  36 */   private String childName = "";
/*     */   
/*     */ 
/*     */   private int childId;
/*     */   
/*     */ 
/*     */   public ChildRecordsRec()
/*     */   {
/*  44 */     this.childRecord = 0;
/*  45 */     this.start = 0;
/*  46 */     this.field = "";
/*  47 */     this.fieldValue = "";
/*  48 */     this.childRecord = -1;
/*  49 */     this.childKey = -1;
/*  50 */     this.defaultRecord = false;
/*  51 */     this.childId = -1;
/*  52 */     this.parentRecord = -1;
/*     */     
/*  54 */     setNew(true);
/*     */     
/*  56 */     setKeys();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ChildRecordsRec(int pChildRecord, int pStart, String pField, String pFieldValue, int pParentRecord, int pChildKey, int pOperatorSequence, boolean defaultRec, String childName, int childId)
/*     */   {
/*  71 */     super(false);
/*     */     
/*  73 */     this.childRecord = pChildRecord;
/*  74 */     this.start = pStart;
/*  75 */     this.field = pField;
/*  76 */     this.fieldValue = pFieldValue;
/*  77 */     this.parentRecord = pParentRecord;
/*  78 */     this.childKey = pChildKey;
/*  79 */     this.operatorSequence = pOperatorSequence;
/*  80 */     this.defaultRecord = defaultRec;
/*     */     
/*     */ 
/*  83 */     this.childName = Common.trimRight(childName);
/*  84 */     this.childId = childId;
/*     */     
/*  86 */     setKeys();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setKeys()
/*     */   {
/*  95 */     this.initChildKey = this.childKey;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasTheKeyChanged()
/*     */   {
/* 105 */     return this.initChildKey != this.childKey;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object clone()
/*     */   {
/* 116 */     super.clone();
/*     */     
/* 118 */     ChildRecordsRec ret = new ChildRecordsRec(this.childRecord, this.start, this.field, this.fieldValue, this.parentRecord, this.childKey, this.operatorSequence, this.defaultRecord, this.childName, -1);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 131 */     ret.setNew(true);
/* 132 */     ret.setUpdateStatus(3);
/* 133 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFieldCount()
/*     */   {
/* 142 */     return 5;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getField(int fieldNum)
/*     */   {
/* 156 */     if (this.updateStatus == -1) { return "";
/*     */     }
/* 158 */     switch (fieldNum) {
/* 159 */     case 0:  return Integer.valueOf(this.childRecord);
/* 160 */     case 1:  return this.childName;
/* 161 */     case 2:  return this.field;
/* 162 */     case 3:  return this.fieldValue;
/* 163 */     case 4:  return Integer.valueOf(this.parentRecord); }
/* 164 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setFieldWithString(int fieldNum, String val)
/*     */   {
/* 177 */     switch (fieldNum) {
/* 178 */     case 0:  setChildRecord(cnvToInt(this.childRecord, val, "Child Record"));
/* 179 */       break;
/* 180 */     case 1:  setChildName(val);
/* 181 */       break;
/* 182 */     case 2:  setField(val);
/* 183 */       break;
/* 184 */     case 3:  setFieldValue(val);
/* 185 */       break;
/* 186 */     case 4:  setParentRecord(cnvToInt(this.parentRecord, val, "Parent Record"));
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setFieldWithObject(int fieldNum, Object val)
/*     */   {
/* 200 */     switch (fieldNum) {
/* 201 */     case 0:  setChildRecord(((Integer)val).intValue());
/* 202 */       break;
/* 203 */     case 4:  setParentRecord(((Integer)val).intValue());
/* 204 */       break;
/* 205 */     default:  setFieldWithString(fieldNum, (String)val);
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */   public int getChildRecordId()
/*     */   {
/* 213 */     return this.childRecord;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setChildRecord(int val)
/*     */   {
/* 223 */     if ((val != this.childRecord) || (this.updateStatus == -1)) {
/* 224 */       this.childRecord = val;
/* 225 */       this.updateStatus = 3;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getStart()
/*     */   {
/* 233 */     return this.start;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStart(int val)
/*     */   {
/* 243 */     if ((val != this.start) || (this.updateStatus == -1)) {
/* 244 */       this.start = val;
/* 245 */       this.updateStatus = 3;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getField()
/*     */   {
/* 253 */     return this.field;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setField(String val)
/*     */   {
/* 263 */     if (((val == null) || ("".equals(val))) && ((this.field == null) || ("".equals(this.field))))
/*     */     {
/* 265 */       return;
/*     */     }
/*     */     
/* 268 */     if ((val == null) || (!val.equals(this.field)) || (this.updateStatus == -1)) {
/* 269 */       this.field = val;
/* 270 */       this.updateStatus = 3;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getFieldValue()
/*     */   {
/* 278 */     return this.fieldValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFieldValue(String val)
/*     */   {
/* 288 */     if (!equals(this.fieldValue, val)) {
/* 289 */       this.fieldValue = val;
/* 290 */       this.updateStatus = 3;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getParentRecord()
/*     */   {
/* 298 */     return this.parentRecord;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParentRecord(int parentRecord)
/*     */   {
/* 306 */     if (this.parentRecord != parentRecord) {
/* 307 */       this.parentRecord = parentRecord;
/* 308 */       this.updateStatus = 3;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getChildKey()
/*     */   {
/* 319 */     return this.childKey;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setChildKey(int childKey)
/*     */   {
/* 329 */     if (this.childKey != childKey) {
/* 330 */       this.childKey = childKey;
/* 331 */       this.updateStatus = 3;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getOperatorSequence()
/*     */   {
/* 342 */     return this.operatorSequence;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOperatorSequence(int operatorSequence)
/*     */   {
/* 351 */     if (this.operatorSequence != operatorSequence) {
/* 352 */       this.operatorSequence = operatorSequence;
/* 353 */       this.updateStatus = 3;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static ChildRecordsRec getBlankChildRec(int recordId)
/*     */   {
/* 360 */     return new ChildRecordsRec(recordId, 0, "", "", -1, 0, 0, false, "", -1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isDefaultRecord()
/*     */   {
/* 367 */     return this.defaultRecord;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setDefaultRecord(boolean defaultRecord)
/*     */   {
/* 374 */     if (this.defaultRecord != defaultRecord) {
/* 375 */       this.defaultRecord = defaultRecord;
/* 376 */       this.updateStatus = 3;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getChildName()
/*     */   {
/* 384 */     return this.childName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setChildName(String childName)
/*     */   {
/* 392 */     childName = Common.trimRight(childName);
/*     */     
/* 394 */     if (!equals(this.childName, childName)) {
/* 395 */       this.childName = childName;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getChildId()
/*     */   {
/* 403 */     return this.childId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setChildId(int childId)
/*     */   {
/* 410 */     if (this.childId != childId) {
/* 411 */       this.childId = childId;
/* 412 */       this.updateStatus = 3;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/db/Record/ChildRecordsRec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */