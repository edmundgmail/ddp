/*     */ package net.sf.RecordEditor.re.db.Record;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import net.sf.RecordEditor.utils.common.AbsConnection;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.jdbc.AbsDB;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RecordSelectionDB
/*     */   extends AbsDB<RecordSelectionRec>
/*     */ {
/*     */   public static final String DB_NAME = "Tbl_RFS_FieldSelection";
/*  37 */   private static final String[] COLUMN_NAMES = LangConversion.convertColHeading("DB-RecordSelection Columns", new String[] { "", "", "Field", "Operator", "Field Value" });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/*  48 */     if (Common.TEST_MODE) {
/*  49 */       COLUMN_NAMES[0] = "or";
/*  50 */       COLUMN_NAMES[1] = "and";
/*     */     }
/*     */   }
/*     */   
/*  54 */   private PreparedStatement delAllChildRecords = null;
/*     */   private int paramRecordId;
/*     */   private int paramChildKey;
/*     */   
/*     */   public RecordSelectionDB()
/*     */   {
/*  60 */     resetSearch();
/*     */     
/*  62 */     this.sSQL = " Select  RECORDID, Child_Key, Field_No, Boolean_Operator, Field_Name, Operator, Field_Value";
/*  63 */     this.sFrom = "  from Tbl_RFS_FieldSelection";
/*  64 */     this.sWhereSQL = "  where RecordId = ?  and Child_Key= ?";
/*  65 */     this.sOrderBy = " Order by Field_No";
/*     */     
/*  67 */     this.updateSQL = "Update Tbl_RFS_FieldSelection Set Field_No = ?   , Boolean_Operator= ?    , Field_Name= ?    , Operator= ?    , Field_Value= ?  Where RecordId= ?    and Child_Key= ?    and Field_No= ?";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  78 */     this.deleteSQL = "Delete From  Tbl_RFS_FieldSelection Where RecordId= ?    and Child_Key= ?    and Field_No= ?";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  84 */     this.insertSQL = "Insert Into  Tbl_RFS_FieldSelection  (    Field_No  , Boolean_Operator  , Field_Name  , Operator  , Field_Value  , RecordId  , Child_Key ) Values (     ?   , ?   , ?   , ?   , ?,  ?   , ?)";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  99 */     this.columnNames = COLUMN_NAMES;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParams(int recordId, int childKey)
/*     */   {
/* 111 */     this.paramRecordId = recordId;
/* 112 */     this.paramChildKey = childKey;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void open()
/*     */   {
/* 120 */     prepareCursor();
/*     */     try
/*     */     {
/* 123 */       this.sqlCursor.setInt(1, this.paramRecordId);
/* 124 */       this.sqlCursor.setInt(2, this.paramChildKey);
/*     */       
/* 126 */       setStringArgs(1);
/*     */       
/*     */ 
/* 129 */       this.rsCursor = this.sqlCursor.executeQuery();
/* 130 */       this.message = "";
/*     */     } catch (Exception ex) {
/* 132 */       setMessage(ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RecordSelectionRec fetch()
/*     */   {
/* 149 */     RecordSelectionRec ret = null;
/*     */     try
/*     */     {
/* 152 */       if (this.rsCursor.next()) {
/* 153 */         ret = new RecordSelectionRec(this.rsCursor.getInt(1), this.rsCursor.getInt(2), this.rsCursor.getInt(3), this.rsCursor.getInt(4), this.rsCursor.getString(5), this.rsCursor.getString(6), this.rsCursor.getString(7));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 163 */       this.message = "";
/*     */     } catch (Exception ex) {
/* 165 */       setMessage(ex.getMessage(), ex);
/*     */     }
/*     */     
/* 168 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColumnCount()
/*     */   {
/* 176 */     return 5;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int setSQLParams(PreparedStatement statement, RecordSelectionRec value, boolean insert, int idx)
/*     */     throws SQLException
/*     */   {
/* 194 */     RecordSelectionRec val = value;
/*     */     
/* 196 */     statement.setInt(idx++, val.getFieldNo());
/* 197 */     statement.setInt(idx++, val.getBooleanOperator());
/* 198 */     statement.setString(idx++, correctStr(val.getFieldName()));
/* 199 */     statement.setString(idx++, correctStr(val.getOperator()));
/* 200 */     statement.setString(idx++, correctStr(val.getFieldValue()));
/*     */     
/*     */ 
/* 203 */     if (insert) {
/* 204 */       statement.setInt(idx++, this.paramRecordId);
/* 205 */       statement.setInt(idx++, this.paramChildKey);
/*     */     }
/*     */     
/*     */ 
/* 209 */     return idx;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setWhere(PreparedStatement statement, RecordSelectionRec value, int idx)
/*     */     throws SQLException
/*     */   {
/* 225 */     statement.setInt(idx++, this.paramRecordId);
/* 226 */     statement.setInt(idx++, this.paramChildKey);
/* 227 */     statement.setInt(idx++, value.init_FieldNo);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void deleteAll()
/*     */   {
/*     */     try
/*     */     {
/* 237 */       if (isPrepareNeeded(this.delAllChildRecords)) {
/* 238 */         this.delAllChildRecords = this.connect.getUpdateConnection().prepareStatement("Delete From  Tbl_RFS_FieldSelection Where RecordId= ?    and Child_Key = ? ");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 245 */       this.delAllChildRecords.setInt(1, this.paramRecordId);
/* 246 */       this.delAllChildRecords.setInt(2, this.paramChildKey);
/*     */       
/* 248 */       this.delAllChildRecords.executeUpdate();
/* 249 */       this.message = "";
/*     */     } catch (Exception ex) {
/* 251 */       setMessage(ex.getMessage(), ex);
/*     */     } finally {
/* 253 */       freeConnection();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void insert(RecordSelectionRec value)
/*     */   {
/* 265 */     int i = 0;
/* 266 */     boolean free = super.isSetDoFree(false);
/*     */     
/*     */ 
/*     */ 
/* 270 */     if (!tryToInsert(value)) {
/* 271 */       int key = getNextKey();
/*     */       
/* 273 */       value.setFieldNo(key++);
/* 274 */       while ((i++ < 10) && (!tryToInsert(value))) {
/* 275 */         value.setFieldNo(key++);
/*     */       }
/*     */     }
/* 278 */     super.setDoFree(free);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private int getNextKey()
/*     */   {
/* 285 */     String sql = "Select max(fieldNo) From  Tbl_RFS_FieldSelection Where RecordId= ?  and childKey = ?";
/*     */     
/*     */ 
/* 288 */     return getNextIntSubKey("Select max(fieldNo) From  Tbl_RFS_FieldSelection Where RecordId= ?  and childKey = ?", this.paramRecordId, this.paramChildKey);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void fullClose()
/*     */   {
/* 297 */     super.fullClose();
/*     */     
/* 299 */     closeStatement(this.delAllChildRecords);
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/db/Record/RecordSelectionDB.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */