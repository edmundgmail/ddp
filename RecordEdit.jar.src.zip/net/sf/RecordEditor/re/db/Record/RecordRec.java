/*     */ package net.sf.RecordEditor.re.db.Record;
/*     */ 
/*     */ import net.sf.JRecord.External.ExternalRecord;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.jdbc.AbsRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RecordRec
/*     */   extends AbsRecord
/*     */ {
/*  46 */   public static int BF_NOT_DEFINED = 0;
/*  47 */   public static int BF_NO_BINARY_FIELDS = 1;
/*  48 */   public static int BF_BINARY_FIELDS = 2;
/*     */   
/*     */   private ExternalRecord value;
/*     */   
/*     */   private int initRecordId;
/*     */   
/*  54 */   private int binaryFields = BF_NOT_DEFINED;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RecordRec()
/*     */   {
/*  64 */     this.value = new ExternalRecord();
/*  65 */     setExternalValue(this.value);
/*  66 */     setNew(true);
/*  67 */     setUpdateStatus(4);
/*  68 */     setKeys();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RecordRec(int pRecordId, String pRecordName, String pDescription, int pRecordType, int pSystem, String pListChar, String pCopyBook, String pDelimiter, String pQuote, int pPosRecInd, String pRecSepList, byte[] pRecordSep, String pFontName, int precordStyle, int pfileStructure, boolean embeddedCr)
/*     */   {
/*  89 */     this(new ExternalRecord(pRecordId, pRecordName, pDescription, pRecordType, pSystem, pListChar, pCopyBook, pDelimiter, pQuote, pPosRecInd, pRecSepList, pRecordSep, pFontName, precordStyle, pfileStructure, embeddedCr));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RecordRec(ExternalRecord record)
/*     */   {
/* 113 */     super(false);
/*     */     
/* 115 */     this.value = record;
/* 116 */     setExternalValue(this.value);
/* 117 */     setNew(this.value.isNew());
/*     */     
/* 119 */     setKeys();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setKeys()
/*     */   {
/* 128 */     this.initRecordId = this.value.getRecordId();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object clone()
/*     */   {
/* 138 */     super.clone();
/*     */     
/* 140 */     RecordRec ret = new RecordRec(this.value.fullClone());
/*     */     
/*     */ 
/*     */ 
/* 144 */     ret.setNew(true);
/* 145 */     ret.setUpdateStatus(3);
/*     */     
/* 147 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFieldCount()
/*     */   {
/* 157 */     return 15;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getField(int fieldNum)
/*     */   {
/* 171 */     if (this.updateStatus == -1) { return "";
/*     */     }
/* 173 */     switch (fieldNum) {
/* 174 */     case 0:  return Integer.valueOf(this.value.getRecordId());
/* 175 */     case 1:  return this.value.getRecordName();
/* 176 */     case 2:  return this.value.getDescription();
/* 177 */     case 3:  return Integer.valueOf(this.value.getRecordType());
/* 178 */     case 4:  return Integer.valueOf(this.value.getSystem());
/* 179 */     case 5:  return this.value.getListChar();
/* 180 */     case 6:  return this.value.getCopyBook();
/* 181 */     case 7:  return this.value.getDelimiter();
/* 182 */     case 8:  return this.value.getQuote();
/* 183 */     case 9:  return Integer.valueOf(this.value.getPosRecInd());
/* 184 */     case 10:  return this.value.getRecSepList();
/* 185 */     case 11:  return this.value.getRecordSep();
/* 186 */     case 12:  return this.value.getFontName();
/* 187 */     case 13:  return Integer.valueOf(this.value.getRecordStyle());
/* 188 */     case 14:  return Integer.valueOf(this.value.getFileStructure()); }
/* 189 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setFieldWithString(int fieldNum, String val)
/*     */   {
/* 202 */     switch (fieldNum) {
/* 203 */     case 0:  this.value.setRecordId(cnvToInt(this.value.getRecordId(), val, "Record Id"));
/* 204 */       break;
/* 205 */     case 1:  this.value.setRecordName(val);
/* 206 */       break;
/* 207 */     case 2:  this.value.setDescription(val);
/* 208 */       break;
/* 209 */     case 3:  this.value.setRecordType(cnvToInt(this.value.getRecordType(), val, "Record Type"));
/* 210 */       break;
/* 211 */     case 4:  this.value.setSystem(cnvToInt(this.value.getSystem(), val, "System"));
/* 212 */       break;
/* 213 */     case 5:  this.value.setListChar(val);
/* 214 */       break;
/* 215 */     case 6:  this.value.setCopyBook(val);
/* 216 */       break;
/* 217 */     case 7:  this.value.setDelimiter(val);
/* 218 */       break;
/* 219 */     case 8:  this.value.setQuote(val);
/* 220 */       break;
/* 221 */     case 9:  this.value.setPosRecInd(cnvToInt(this.value.getPosRecInd(), val, "PosRecInd"));
/* 222 */       break;
/* 223 */     case 10:  this.value.setRecSepList(val);
/* 224 */       break;
/* 225 */     case 11:  this.value.setRecordSep(val.getBytes());
/* 226 */       break;
/* 227 */     case 12:  this.value.setFontName(val);
/* 228 */       break;
/* 229 */     case 13:  this.value.setRecordStyle(cnvToInt(this.value.getRecordStyle(), val, "Record_Style"));
/* 230 */       break;
/* 231 */     case 14:  this.value.setFileStructure(cnvToInt(this.value.getFileStructure(), val, "File_Structure"));
/* 232 */       break;
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setFieldWithObject(int fieldNum, Object val)
/*     */   {
/* 246 */     switch (fieldNum) {
/* 247 */     case 0:  this.value.setRecordId(((Integer)val).intValue());
/* 248 */       break;
/* 249 */     case 3:  this.value.setRecordType(((Integer)val).intValue());
/* 250 */       break;
/* 251 */     case 4:  this.value.setSystem(((Integer)val).intValue());
/* 252 */       break;
/* 253 */     case 9:  this.value.setPosRecInd(((Integer)val).intValue());
/* 254 */       break;
/* 255 */     case 11:  this.value.setRecordSep((byte[])val);
/* 256 */       break;
/* 257 */     case 13:  this.value.setRecordStyle(((Integer)val).intValue());
/* 258 */       break;
/* 259 */     case 14:  this.value.setFileStructure(((Integer)val).intValue());
/* 260 */       break;
/* 261 */     case 1: case 2: case 5: case 6: case 7: case 8: case 10: case 12: default:  setFieldWithString(fieldNum, (String)val);
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final RecordRec getNullRecord(String pRecordName, String fontName)
/*     */   {
/* 275 */     return getNullRecord(pRecordName, 1, fontName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final RecordRec getNullRecord(String pRecordName, int recordType, String fontName)
/*     */   {
/* 291 */     RecordRec ret = new RecordRec(-1, pRecordName, "", recordType, 0, "Y", "", "<Tab>", "", 0, "default", Common.CRLF_BYTES, fontName, 0, 0, false);
/*     */     
/*     */ 
/* 294 */     ret.setUpdateStatus(4);
/* 295 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getInitRecordId()
/*     */   {
/* 302 */     return this.initRecordId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ExternalRecord getValue()
/*     */   {
/* 309 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRecordId()
/*     */   {
/* 317 */     return this.value.getRecordId();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getRecordName()
/*     */   {
/* 324 */     return this.value.getRecordName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getSystem()
/*     */   {
/* 331 */     return this.value.getSystem();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final int getBinaryFields()
/*     */   {
/* 338 */     return this.binaryFields;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void setBinaryFields(int binaryFields)
/*     */   {
/* 345 */     this.binaryFields = binaryFields;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/db/Record/RecordRec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */