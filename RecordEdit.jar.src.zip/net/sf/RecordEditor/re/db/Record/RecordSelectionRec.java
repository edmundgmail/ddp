/*     */ package net.sf.RecordEditor.re.db.Record;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import net.sf.RecordEditor.utils.jdbc.AbsRecord;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RecordSelectionRec
/*     */   extends AbsRecord
/*     */ {
/*  35 */   private static final String[] OR_LIST = { LangConversion.convert(2, "Or"), "" };
/*  36 */   private static final String[] AND_LIST = { "", LangConversion.convert(2, "And") };
/*     */   
/*     */   protected int init_FieldNo;
/*     */   
/*     */   private int recordId;
/*     */   
/*     */   private int childKey;
/*     */   private int fieldNo;
/*     */   private int booleanOperator;
/*     */   private String testField;
/*     */   private String operator;
/*     */   private String fieldValue;
/*     */   
/*     */   public RecordSelectionRec()
/*     */   {
/*  51 */     this.recordId = 0;
/*  52 */     this.childKey = 0;
/*  53 */     this.fieldNo = -1;
/*  54 */     this.booleanOperator = 1;
/*  55 */     this.testField = "";
/*  56 */     this.operator = "=";
/*  57 */     this.fieldValue = "";
/*     */     
/*  59 */     setNew(true);
/*     */     
/*  61 */     setKeys();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RecordSelectionRec(int recordId, int childKey, int fieldNo, int booleanOperator, String field, String operator, String fieldValue)
/*     */   {
/*  70 */     this.recordId = recordId;
/*  71 */     this.childKey = childKey;
/*  72 */     this.fieldNo = fieldNo;
/*  73 */     this.booleanOperator = booleanOperator;
/*  74 */     this.testField = field;
/*  75 */     this.operator = trimField(operator);
/*  76 */     this.fieldValue = fieldValue;
/*     */     
/*  78 */     setKeys();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setKeys()
/*     */   {
/*  88 */     this.init_FieldNo = this.fieldNo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object clone()
/*     */   {
/*  98 */     Object r = super.clone();
/*  99 */     if ((r instanceof RecordSelectionRec)) {
/* 100 */       return r;
/*     */     }
/*     */     
/* 103 */     RecordSelectionRec ret = new RecordSelectionRec(this.recordId, this.childKey, this.fieldNo, this.booleanOperator, this.testField, this.operator, this.fieldValue);
/* 104 */     ret.setNew(true);
/* 105 */     ret.setUpdateStatus(3);
/*     */     
/* 107 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getFieldCount()
/*     */   {
/* 114 */     return 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getField(int fieldNum)
/*     */   {
/* 129 */     switch (fieldNum) {
/* 130 */     case 0:  return OR_LIST[this.booleanOperator];
/* 131 */     case 1:  return AND_LIST[this.booleanOperator];
/* 132 */     case 2:  return this.testField;
/* 133 */     case 3:  return trimField(this.operator);
/* 134 */     case 4:  return this.fieldValue;
/*     */     }
/*     */     
/* 137 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setFieldWithString(int fieldNum, String val)
/*     */   {
/* 155 */     switch (fieldNum) {
/* 156 */     case 0:  setBooleanOperator(searchArray(val, OR_LIST)); break;
/* 157 */     case 1:  setBooleanOperator(searchArray(val, AND_LIST)); break;
/* 158 */     case 2:  setTestField(val); break;
/* 159 */     case 3:  setOperator(val); break;
/* 160 */     case 4:  setFieldValue(val); break;
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setFieldWithObject(int fieldNum, Object val)
/*     */   {
/* 177 */     System.out.println("setFieldWithObject " + fieldNum + " " + val);
/* 178 */     if (val == null) {
/* 179 */       setFieldWithString(fieldNum, "");
/*     */     } else {
/* 181 */       setFieldWithString(fieldNum, val.toString());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int searchArray(String val, String[] array)
/*     */   {
/* 193 */     if (this.fieldNo == 0) { return 0;
/*     */     }
/* 195 */     for (int i = 0; i < array.length; i++) {
/* 196 */       if (array[i].equalsIgnoreCase(val)) {
/* 197 */         return i;
/*     */       }
/*     */     }
/* 200 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRecordId()
/*     */   {
/* 208 */     return this.recordId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRecordId(int recordId)
/*     */   {
/* 217 */     this.recordId = recordId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getChildKey()
/*     */   {
/* 226 */     return this.childKey;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setChildKey(int childKey)
/*     */   {
/* 235 */     if (this.childKey != childKey) {
/* 236 */       this.childKey = childKey;
/* 237 */       this.updateStatus = 3;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFieldNo()
/*     */   {
/* 247 */     return this.fieldNo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFieldNo(int fieldNo)
/*     */   {
/* 256 */     if (this.fieldNo != fieldNo) {
/* 257 */       this.fieldNo = fieldNo;
/* 258 */       this.updateStatus = 3;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getBooleanOperator()
/*     */   {
/* 268 */     return this.booleanOperator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBooleanOperator(int booleanOperator)
/*     */   {
/* 277 */     if (this.booleanOperator != booleanOperator) {
/* 278 */       this.booleanOperator = booleanOperator;
/* 279 */       this.updateStatus = 3;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFieldName()
/*     */   {
/* 289 */     return this.testField;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTestField(String testField)
/*     */   {
/* 298 */     if (!equals(this.testField, testField)) {
/* 299 */       this.testField = testField;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getOperator()
/*     */   {
/* 309 */     return trimField(this.operator);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOperator(String operator)
/*     */   {
/* 319 */     System.out.println("setOperator: " + operator + "< >" + trimField(operator) + "<");
/* 320 */     operator = trimField(operator);
/* 321 */     if (!equals(this.operator, operator)) {
/* 322 */       this.operator = operator;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected String trimField(String s)
/*     */   {
/* 329 */     if (s != null) {
/* 330 */       s = s.trim();
/*     */     }
/*     */     
/* 333 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getFieldValue()
/*     */   {
/* 340 */     return this.fieldValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFieldValue(String fieldValue)
/*     */   {
/* 349 */     if (!equals(this.fieldValue, fieldValue)) {
/* 350 */       this.fieldValue = fieldValue;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/db/Record/RecordSelectionRec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */