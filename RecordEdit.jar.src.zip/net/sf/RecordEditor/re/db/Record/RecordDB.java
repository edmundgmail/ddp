/*     */ package net.sf.RecordEditor.re.db.Record;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import net.sf.JRecord.External.ExternalRecord;
/*     */ import net.sf.RecordEditor.utils.common.AbsConnection;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.jdbc.AbsDB;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RecordDB
/*     */   extends AbsDB<RecordRec>
/*     */ {
/*  51 */   private static final String[] COLUMN_NAMES = { "Record Id", LangConversion.convert(5, "Record Name"), LangConversion.convert(5, "Description"), "Record Type", "System", "ListChar", "Cobol Copybook", "Delimiter", "Quote", "PosRecInd", "Record Seperator", "RecordSep", "Canonical_Name", "Record_Style", "File_Structure" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  70 */   private PreparedStatement getMaxKey = null;
/*     */   
/*     */   public RecordDB()
/*     */   {
/*  74 */     resetSearch();
/*     */     
/*  76 */     this.sSQL = " Select  RecordId, RecordName, Description, RecordType, System, ListChar, CopyBook, Delimiter, Quote, PosRecInd, RecSepList, RecordSep, Canonical_Name, Record_Style, File_Structure";
/*  77 */     this.sFrom = "  From Tbl_R_Records";
/*  78 */     this.sWhereSQL = " ";
/*  79 */     this.sOrderBy = " ";
/*  80 */     this.updateSQL = "Update Tbl_R_Records   Set RecordId= ?    , RecordName= ?    , Description= ?    , RecordType= ?    , System= ?    , ListChar= ?    , CopyBook= ?    , Delimiter= ?    , Quote= ?    , PosRecInd= ?    , RecSepList= ?    , RecordSep= ?    , Canonical_Name= ?    , Record_Style= ?    , File_Structure= ?  Where RecordId= ? ";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  99 */     this.deleteSQL = "Delete From  Tbl_R_Records   Where RecordId= ? ";
/*     */     
/*     */ 
/*     */ 
/* 103 */     this.insertSQL = "Insert Into  Tbl_R_Records  (    RecordId  , RecordName  , Description  , RecordType  , System  , ListChar  , CopyBook  , Delimiter  , Quote  , PosRecInd  , RecSepList  , RecordSep  , Canonical_Name  , Record_Style  , File_Structure) Values (     ?   , ?   , ?   , ?   , ?   , ?   , ?   , ?   , ?   , ?   , ?   , ?   , ?   , ?   , ?)";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 123 */     this.columnNames = COLUMN_NAMES;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RecordRec fetch()
/*     */   {
/* 140 */     RecordRec ret = null;
/*     */     try
/*     */     {
/* 143 */       if (this.rsCursor == null) {
/* 144 */         super.open();
/*     */       }
/* 146 */       if (this.rsCursor.next()) {
/* 147 */         byte[] b = new byte[0];
/*     */         try {
/* 149 */           b = this.rsCursor.getString(12).getBytes();
/*     */         } catch (Exception e) {
/*     */           try {
/* 152 */             b = this.rsCursor.getBytes(12);
/*     */           }
/*     */           catch (Exception ex) {}
/*     */         }
/* 156 */         ret = new RecordRec(this.rsCursor.getInt(1), fix(this.rsCursor.getString(2)), this.rsCursor.getString(3), this.rsCursor.getInt(4), this.rsCursor.getInt(5), fix(this.rsCursor.getString(6)), fix(this.rsCursor.getString(7)), fix(this.rsCursor.getString(8)), fix(this.rsCursor.getString(9)), this.rsCursor.getInt(10), fix(this.rsCursor.getString(11)), b, fix(this.rsCursor.getString(13)), this.rsCursor.getInt(14), this.rsCursor.getInt(15), false);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 175 */       this.message = "";
/*     */     } catch (Exception ex) {
/* 177 */       setMessage(ex.getMessage(), ex);
/*     */     }
/*     */     
/* 180 */     if (ret == null) {
/* 181 */       super.freeConnection();
/*     */     }
/*     */     
/* 184 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColumnCount()
/*     */   {
/* 192 */     return 16;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void delete(RecordRec val)
/*     */   {
/* 204 */     String sSql = " select rs2.RECORDID, rs2.child_key   from  TBL_RS2_SUBRECORDS rs1 inner join TBL_RS2_SUBRECORDS rs2     on  rs1.RECORDID = rs2.RECORDID    and  rs2.PARENT_RECORDID = rs1.CHILD_ID  where  rs1.CHILD_RECORD = " + val.getRecordId();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 210 */     String[] updSql = { "Delete from  TBL_RS2_SUBRECORDS where CHILD_RECORD = " + val.getRecordId(), "Delete from  TBL_RFS_FIELDSELECTION where RECORDID = " + val.getRecordId(), "Delete from  TBL_RF1_RECORDFIELDS where RECORDID = " + val.getRecordId(), "Delete from  TBL_RS2_SUBRECORDS where RECORDID = " + val.getRecordId() };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 228 */       ResultSet resultset = this.connect.getUpdateConnection().createStatement().executeQuery(sSql);
/* 229 */       while (resultset.next()) {
/* 230 */         String uSql = " Update  TBL_RS2_SUBRECORDS rs3     set PARENT_RECORDID = -1   Where RecordId   = " + resultset.getString(1) + " and  child_key = " + resultset.getString(2);
/*     */         
/*     */ 
/*     */ 
/* 234 */         this.connect.getUpdateConnection().createStatement().execute(uSql);
/*     */       }
/*     */     } catch (Exception e) {
/* 237 */       Common.logMsgRaw(sSql, null);
/* 238 */       Common.logMsgRaw(UPDATE_FAILED + e.getClass().getName() + " " + e.getMessage(), e);
/* 239 */       e.printStackTrace();
/*     */     }
/*     */     
/* 242 */     for (String sql : updSql) {
/*     */       try {
/* 244 */         this.connect.getUpdateConnection().createStatement().execute(sql);
/*     */       } catch (Exception e) {
/* 246 */         Common.logMsgRaw(sql, null);
/* 247 */         Common.logMsgRaw(UPDATE_FAILED + e.getClass().getName() + " " + e.getMessage(), e);
/* 248 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */     
/* 252 */     super.delete(val);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void resetSearch()
/*     */   {
/* 263 */     super.resetSearch();
/* 264 */     this.sep = " Where ";
/* 265 */     this.sqlCursor = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSearchRecordName(String operator, String val)
/*     */   {
/* 277 */     setSearchStrArg("RecordName", operator, val);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSearchRecordId(String operator, int val)
/*     */   {
/* 290 */     setSearchArg("RecordId", operator, val);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSearchDescription(String operator, String val)
/*     */   {
/* 301 */     setSearchStrArg("Description", operator, val);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSearchRecordType(String operator, int val)
/*     */   {
/* 315 */     this.sWhere = (this.sWhere + this.sep + "RecordType" + operator + val);
/* 316 */     this.sep = "   and ";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSearchSystem(String operator, int val)
/*     */   {
/* 330 */     this.sWhere = (this.sWhere + this.sep + "System" + operator + val);
/* 331 */     this.sep = "   and ";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSearchListChar(String operator, String val)
/*     */   {
/* 345 */     setSearchStrArg("ListChar", operator, val);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int setSQLParams(PreparedStatement statement, RecordRec value, boolean insert, int idx)
/*     */     throws SQLException
/*     */   {
/* 364 */     ExternalRecord val = value.getValue();
/*     */     
/* 366 */     statement.setInt(idx++, val.getRecordId());
/* 367 */     statement.setString(idx++, correctStr(val.getRecordName()));
/* 368 */     statement.setString(idx++, correctStr(val.getDescription()));
/* 369 */     statement.setInt(idx++, val.getRecordType());
/* 370 */     statement.setInt(idx++, val.getSystem());
/* 371 */     statement.setString(idx++, correctStr(val.getListChar()));
/* 372 */     statement.setString(idx++, correctStr(val.getCopyBook()));
/* 373 */     statement.setString(idx++, correctStr(val.getDelimiter()));
/* 374 */     statement.setString(idx++, correctStr(val.getQuote()));
/* 375 */     statement.setInt(idx++, val.getPosRecInd());
/* 376 */     statement.setString(idx++, correctStr(val.getRecSepList()));
/* 377 */     statement.setString(idx++, new String(correctBytes(val.getRecordSep())));
/* 378 */     statement.setString(idx++, correctStr(val.getFontName()));
/* 379 */     statement.setInt(idx++, val.getRecordStyle());
/* 380 */     statement.setInt(idx++, val.getFileStructure());
/*     */     
/*     */ 
/* 383 */     return idx;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setWhere(PreparedStatement statement, RecordRec value, int idx)
/*     */     throws SQLException
/*     */   {
/* 397 */     statement.setInt(idx, value.getInitRecordId());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private int getNextKey()
/*     */   {
/* 404 */     String sql = "Select max(RecordId) From  Tbl_R_Records ";
/*     */     
/* 406 */     int ret = 1;
/*     */     try
/*     */     {
/* 409 */       if (isPrepareNeeded(this.getMaxKey)) {
/* 410 */         this.getMaxKey = this.connect.getConnection().prepareStatement("Select max(RecordId) From  Tbl_R_Records ");
/*     */       }
/*     */       
/* 413 */       ResultSet rsKey = this.getMaxKey.executeQuery();
/* 414 */       if (rsKey.next()) {
/* 415 */         ret = rsKey.getInt(1) + 1;
/*     */       }
/* 417 */       rsKey.close();
/* 418 */       this.message = "";
/*     */     } catch (Exception ex) {
/* 420 */       setMessage("Select max(RecordId) From  Tbl_R_Records ", ex.getMessage(), ex);
/*     */     }
/*     */     
/* 423 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void insert(RecordRec value)
/*     */   {
/* 439 */     int i = 0;
/*     */     
/* 441 */     boolean free = super.isSetDoFree(false);
/*     */     
/* 443 */     int key = getNextKey();
/*     */     
/*     */ 
/* 446 */     value.getValue().setRecordId(key++);
/*     */     
/* 448 */     while ((i++ < 10) && (!tryToInsert(value))) {
/* 449 */       value.getValue().setRecordId(key++);
/*     */     }
/* 451 */     super.setDoFree(free);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void fullClose()
/*     */   {
/* 462 */     super.fullClose();
/*     */     
/* 464 */     closeStatement(this.getMaxKey);
/*     */   }
/*     */   
/*     */   private String fix(String s)
/*     */   {
/* 469 */     if (s == null) {
/* 470 */       return null;
/*     */     }
/* 472 */     return s.trim();
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/db/Record/RecordDB.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */