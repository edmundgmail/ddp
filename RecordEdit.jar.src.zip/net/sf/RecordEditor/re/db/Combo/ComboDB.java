/*     */ package net.sf.RecordEditor.re.db.Combo;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import net.sf.RecordEditor.utils.common.AbsConnection;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.jdbc.AbsDB;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComboDB
/*     */   extends AbsDB<ComboRec>
/*     */ {
/*  31 */   private static final String[] COLUMN_NAMES = LangConversion.convertColHeading("DB-Combo Columns", new String[] { "System", "Combo_Name" });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  38 */   private PreparedStatement getMaxKey = null;
/*  39 */   protected PreparedStatement getSql = null;
/*     */   
/*     */ 
/*     */   public ComboDB()
/*     */   {
/*  44 */     resetSearch();
/*     */     
/*  46 */     this.sSQL = " Select  Combo_Id, System, Combo_Name, Column_Type";
/*  47 */     this.sFrom = "  From   Tbl_C_Combos";
/*  48 */     this.sWhereSQL = " ";
/*  49 */     this.sOrderBy = " ";
/*  50 */     this.updateSQL = "Update Tbl_C_Combos   Set Combo_Id= ?    , System= ?    , Combo_Name= ?    , Column_Type= ?  Where Combo_Id= ? ";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  58 */     this.deleteSQL = "Delete From  Tbl_C_Combos   Where Combo_Id= ? ";
/*     */     
/*     */ 
/*     */ 
/*  62 */     this.insertSQL = "Insert Into  Tbl_C_Combos  (    Combo_Id  , System  , Combo_Name  , Column_Type) Values (     ?   , ?   , ?   , ?)";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  71 */     this.columnNames = COLUMN_NAMES;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ComboRec fetch()
/*     */   {
/*  87 */     return fetch(this.rsCursor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ComboRec fetch(ResultSet results)
/*     */   {
/*  96 */     ComboRec ret = null;
/*     */     try
/*     */     {
/*  99 */       if (results.next()) {
/* 100 */         ret = new ComboRec(results.getInt(1), results.getInt(2), results.getString(3), results.getInt(4));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 107 */       this.message = "";
/*     */     } catch (Exception ex) {
/* 109 */       setMessage(ex.getMessage(), ex);
/*     */     }
/*     */     
/* 112 */     return ret;
/*     */   }
/*     */   
/*     */   public ComboRec get(String name)
/*     */   {
/* 117 */     String sql = this.sSQL + this.sFrom + " Where Combo_Name = ? ;";
/* 118 */     ComboRec ret = null;
/* 119 */     ResultSet rs = null;
/*     */     try
/*     */     {
/* 122 */       if (isPrepareNeeded(this.getSql)) {
/* 123 */         this.getSql = this.connect.getConnection().prepareStatement(sql);
/*     */       }
/* 125 */       this.getSql.setString(1, correctStr(name));
/*     */       
/* 127 */       rs = this.getSql.executeQuery();
/*     */       try
/*     */       {
/* 130 */         ret = fetch(rs);
/*     */       } finally {
/* 132 */         rs.close();
/*     */       }
/*     */     }
/*     */     catch (Exception ex) {
/* 136 */       setMessage(sql, ex.getMessage(), ex);
/*     */     } finally {
/* 138 */       freeConnection();
/*     */     }
/*     */     
/* 141 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColumnCount()
/*     */   {
/* 149 */     return 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int setSQLParams(PreparedStatement statement, ComboRec value, boolean insert, int idx)
/*     */     throws SQLException
/*     */   {
/* 168 */     statement.setInt(idx++, value.getComboId());
/* 169 */     statement.setInt(idx++, value.getSystem());
/* 170 */     statement.setString(idx++, correctStr(value.getComboName()));
/* 171 */     statement.setInt(idx++, value.getColumnType());
/*     */     
/*     */ 
/* 174 */     return idx;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setWhere(PreparedStatement statement, ComboRec value, int idx)
/*     */     throws SQLException
/*     */   {
/* 189 */     statement.setInt(idx++, value.initCombo_Id);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void insert(ComboRec value)
/*     */   {
/* 201 */     int i = 0;
/* 202 */     int key = getNextKey();
/*     */     
/* 204 */     value.setComboId(key++);
/* 205 */     while ((i++ < 10) && (!tryToInsert(value))) {
/* 206 */       value.setComboId(key++);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private int getNextKey()
/*     */   {
/* 214 */     String sql = "Select max(Combo_Id) From Tbl_C_Combos ";
/*     */     
/* 216 */     int ret = 1;
/*     */     try
/*     */     {
/* 219 */       if (isPrepareNeeded(this.getMaxKey)) {
/* 220 */         this.getMaxKey = this.connect.getConnection().prepareStatement("Select max(Combo_Id) From Tbl_C_Combos ");
/*     */       }
/*     */       
/* 223 */       ResultSet rsKey = this.getMaxKey.executeQuery();
/* 224 */       if (rsKey.next()) {
/* 225 */         ret = rsKey.getInt(1) + 1;
/*     */       }
/* 227 */       rsKey.close();
/* 228 */       this.message = "";
/*     */     } catch (Exception ex) {
/* 230 */       setMessage("Select max(Combo_Id) From Tbl_C_Combos ", ex.getMessage(), ex);
/*     */     }
/*     */     
/* 233 */     return ret;
/*     */   }
/*     */   
/*     */   public void fullClose() {
/* 237 */     super.fullClose();
/*     */     
/* 239 */     closeStatement(this.getMaxKey);
/* 240 */     closeStatement(this.getSql);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void delete(ComboRec val)
/*     */   {
/* 252 */     String updSql = "Delete from  Tbl_CI_ComboItems where Combo_Id = " + val.getComboId();
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 257 */       this.connect.getUpdateConnection().createStatement().execute(updSql);
/*     */     } catch (Exception e) {
/* 259 */       Common.logMsgRaw(updSql, null);
/* 260 */       Common.logMsg(30, "Update Failed:", e.getClass().getName() + " " + e.getMessage(), e);
/* 261 */       e.printStackTrace();
/*     */     }
/*     */     
/*     */ 
/* 265 */     super.delete(val);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSearchComboName(String operator, String val)
/*     */   {
/* 277 */     setSearchStrArg("Combo_Name", operator, val);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSearchSystem(String operator, int val)
/*     */   {
/* 290 */     this.sWhere = (this.sWhere + this.sep + "System" + operator + val);
/* 291 */     this.sep = "   and ";
/*     */   }
/*     */   
/*     */ 
/*     */   public void resetSearch()
/*     */   {
/* 297 */     super.resetSearch();
/*     */     
/* 299 */     this.sep = " Where ";
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/db/Combo/ComboDB.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */