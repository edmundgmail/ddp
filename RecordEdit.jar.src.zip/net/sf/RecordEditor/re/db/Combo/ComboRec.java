/*     */ package net.sf.RecordEditor.re.db.Combo;
/*     */ 
/*     */ import net.sf.RecordEditor.utils.jdbc.AbsRecord;
/*     */ import net.sf.RecordEditor.utils.swing.AbstractRowList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComboRec
/*     */   extends AbsRecord
/*     */ {
/*     */   public static final int SINGLE_COLUMN = 1;
/*     */   private int comboId;
/*     */   protected int initCombo_Id;
/*     */   private int system;
/*     */   private String comboName;
/*     */   private int columnType;
/*  34 */   private AbstractRowList rows = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ComboRec()
/*     */   {
/*  47 */     this.comboId = 0;
/*  48 */     this.system = 0;
/*  49 */     this.comboName = "";
/*  50 */     this.columnType = 0;
/*     */     
/*     */ 
/*  53 */     setKeys();
/*     */   }
/*     */   
/*     */   public ComboRec(int pCombo_Id, int pSystem, String pCombo_Name, int pColumn_Type) {
/*  57 */     super(false);
/*     */     
/*  59 */     this.comboId = pCombo_Id;
/*  60 */     this.system = pSystem;
/*  61 */     this.comboName = pCombo_Name;
/*  62 */     this.columnType = pColumn_Type;
/*     */     
/*     */ 
/*  65 */     setKeys();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setKeys()
/*     */   {
/*  73 */     this.initCombo_Id = this.comboId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object clone()
/*     */   {
/*  83 */     Object r = super.clone();
/*  84 */     if ((r instanceof ComboRec)) {
/*  85 */       return r;
/*     */     }
/*     */     
/*  88 */     ComboRec ret = new ComboRec(-121, this.system, this.comboName, this.columnType);
/*  89 */     ret.setNew(true);
/*  90 */     ret.setUpdateStatus(3);
/*     */     
/*  92 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getFieldCount()
/*     */   {
/*  99 */     return 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getField(int fieldNum)
/*     */   {
/* 111 */     if (this.updateStatus == -1) {
/* 112 */       return "";
/*     */     }
/* 114 */     switch (fieldNum)
/*     */     {
/*     */     case 0: 
/* 117 */       return Integer.valueOf(this.system);
/*     */     case 1: 
/* 119 */       return this.comboName;
/*     */     }
/* 121 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setFieldWithString(int fieldNum, String val)
/*     */   {
/* 135 */     switch (fieldNum)
/*     */     {
/*     */ 
/*     */     case 0: 
/* 139 */       setSystem(cnvToInt(this.system, val, "System"));
/* 140 */       break;
/*     */     case 1: 
/* 142 */       setComboName(val);
/* 143 */       break;
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setFieldWithObject(int fieldNum, Object val)
/*     */   {
/* 159 */     switch (fieldNum)
/*     */     {
/*     */ 
/*     */     case 0: 
/* 163 */       setSystem(((Integer)val).intValue());
/* 164 */       break;
/*     */     default: 
/* 166 */       setFieldWithString(fieldNum, (String)val);
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */   public int getComboId()
/*     */   {
/* 174 */     return this.comboId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setComboId(int val)
/*     */   {
/* 185 */     if ((val != this.comboId) || (this.updateStatus == -1)) {
/* 186 */       this.comboId = val;
/* 187 */       this.updateStatus = 3;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getSystem()
/*     */   {
/* 195 */     return this.system;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSystem(int val)
/*     */   {
/* 206 */     if ((val != this.system) || (this.updateStatus == -1)) {
/* 207 */       this.system = val;
/* 208 */       this.updateStatus = 3;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getComboName()
/*     */   {
/* 216 */     return this.comboName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setComboName(String val)
/*     */   {
/* 227 */     if (((val == null) || ("".equals(val))) && ((this.comboName == null) || ("".equals(this.comboName))))
/*     */     {
/* 229 */       return;
/*     */     }
/*     */     
/* 232 */     if ((val == null) || (!val.equals(this.comboName)) || (this.updateStatus == -1))
/*     */     {
/* 234 */       this.comboName = val;
/* 235 */       this.updateStatus = 3;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColumnType()
/*     */   {
/* 244 */     return this.columnType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setColumnType(int newColumnType)
/*     */   {
/* 252 */     if (this.columnType != newColumnType) {
/* 253 */       this.columnType = newColumnType;
/* 254 */       this.updateStatus = 3;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public AbstractRowList getRows()
/*     */   {
/* 262 */     return this.rows;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setRows(AbstractRowList rows)
/*     */   {
/* 269 */     this.rows = rows;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/db/Combo/ComboRec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */