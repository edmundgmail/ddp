/*     */ package net.sf.RecordEditor.re.db.Combo;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import net.sf.RecordEditor.utils.common.AbsConnection;
/*     */ import net.sf.RecordEditor.utils.jdbc.AbsDB;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComboValuesDB
/*     */   extends AbsDB<ComboValuesRec>
/*     */ {
/*  27 */   private static final String[] COLUMN_NAMES = LangConversion.convertColHeading("DB ComboValues", new String[] { "Combo Code", "Combo Value" });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int paramCombo_Id;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  37 */   private int columnCount = 2;
/*     */   
/*  39 */   private PreparedStatement delAllRecordFields = null;
/*     */   
/*     */ 
/*     */ 
/*     */   public ComboValuesDB()
/*     */   {
/*  45 */     resetSearch();
/*     */     
/*  47 */     this.sSQL = " Select  Combo_Code, Combo_Value";
/*  48 */     this.sFrom = "  From   Tbl_CI_ComboItems";
/*  49 */     this.sWhereSQL = "  Where  Combo_Id = ?";
/*  50 */     this.sOrderBy = "  Order By Combo_Code";
/*  51 */     this.updateSQL = "Update Tbl_CI_ComboItems   Set Combo_Code= ?    , Combo_Value= ?  Where Combo_Id= ?    and Combo_Code= ? ";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  58 */     this.deleteSQL = "Delete From  Tbl_CI_ComboItems   Where Combo_Id= ?    and Combo_Code= ? ";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  63 */     this.insertSQL = "Insert Into  Tbl_CI_ComboItems  (    Combo_Code  , Combo_Value  , Combo_Id) Values (     ?   , ?   , ?)";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  71 */     this.columnNames = COLUMN_NAMES;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParams(int Combo_Id)
/*     */   {
/*  83 */     this.paramCombo_Id = Combo_Id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void open()
/*     */   {
/*  91 */     prepareCursor();
/*     */     try
/*     */     {
/*  94 */       this.sqlCursor.setInt(1, this.paramCombo_Id);
/*     */       
/*  96 */       setStringArgs(1);
/*     */       
/*     */ 
/*  99 */       this.rsCursor = this.sqlCursor.executeQuery();
/* 100 */       this.message = "";
/*     */     } catch (Exception ex) {
/* 102 */       setMessage(ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ComboValuesRec fetch()
/*     */   {
/* 119 */     ComboValuesRec ret = null;
/*     */     try
/*     */     {
/* 122 */       if (this.rsCursor.next()) {
/* 123 */         ret = new ComboValuesRec(this.rsCursor.getString(1), this.rsCursor.getString(2));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 128 */       this.message = "";
/*     */     } catch (Exception ex) {
/* 130 */       setMessage(ex.getMessage(), ex);
/*     */     }
/*     */     
/* 133 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColumnCount()
/*     */   {
/* 141 */     return this.columnCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setColumnCount(int columnCount)
/*     */   {
/* 150 */     this.columnCount = columnCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int setSQLParams(PreparedStatement statement, ComboValuesRec value, boolean insert, int idx)
/*     */     throws SQLException
/*     */   {
/* 166 */     statement.setString(idx++, correctStr(value.getCombo_Code()));
/* 167 */     statement.setString(idx++, correctStr(value.getCombo_Value()));
/*     */     
/* 169 */     if (insert) {
/* 170 */       statement.setInt(idx++, this.paramCombo_Id);
/*     */     }
/*     */     
/* 173 */     return idx;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setWhere(PreparedStatement statement, ComboValuesRec value, int idx)
/*     */     throws SQLException
/*     */   {
/* 188 */     statement.setInt(idx++, this.paramCombo_Id);
/* 189 */     statement.setString(idx, correctStr(value.initCombo_Code));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void deleteAll()
/*     */   {
/*     */     try
/*     */     {
/* 200 */       if (isPrepareNeeded(this.delAllRecordFields)) {
/* 201 */         this.delAllRecordFields = this.connect.getUpdateConnection().prepareStatement("Delete From  Tbl_CI_ComboItems   Where Combo_Id= ? ");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 207 */       this.delAllRecordFields.setInt(1, this.paramCombo_Id);
/*     */       
/* 209 */       this.delAllRecordFields.executeUpdate();
/* 210 */       this.message = "";
/*     */     } catch (Exception ex) {
/* 212 */       setMessage(ex.getMessage(), ex);
/*     */     } finally {
/* 214 */       freeConnection();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/db/Combo/ComboValuesDB.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */