/*    */ package net.sf.RecordEditor.re.db.Combo;
/*    */ 
/*    */ import javax.swing.DefaultCellEditor;
/*    */ import javax.swing.table.TableColumn;
/*    */ import javax.swing.table.TableColumnModel;
/*    */ import javax.swing.table.TableModel;
/*    */ import net.sf.RecordEditor.re.db.Table.TableDB;
/*    */ import net.sf.RecordEditor.re.db.Table.TableRec;
/*    */ import net.sf.RecordEditor.utils.common.ReConnection;
/*    */ import net.sf.RecordEditor.utils.jdbc.DBComboModel;
/*    */ import net.sf.RecordEditor.utils.swing.AbsJTable;
/*    */ import net.sf.RecordEditor.utils.swing.BmKeyedComboBox;
/*    */ import net.sf.RecordEditor.utils.swing.BmKeyedComboBoxRender;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ComboJTbl
/*    */   extends AbsJTable
/*    */ {
/* 21 */   private TableDB System_Table = new TableDB();
/* 22 */   private DBComboModel<TableRec> System_Model = new DBComboModel(this.System_Table, 0, 1, false, false);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private BmKeyedComboBox locSystem;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ComboJTbl(TableModel mdl, int dbIdx)
/*    */   {
/* 38 */     super(mdl);
/*    */     
/* 40 */     commonInit(dbIdx);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private void commonInit(int dbIdx)
/*    */   {
/* 49 */     this.System_Table.setConnection(new ReConnection(dbIdx));
/* 50 */     this.System_Table.setParams(3);
/* 51 */     this.locSystem = new BmKeyedComboBox(this.System_Model, false);
/*    */     
/* 53 */     setColumnSizes();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setColumnSizes()
/*    */   {
/* 62 */     TableColumnModel tcm = getColumnModel();
/*    */     
/* 64 */     tcm.getColumn(0).setCellRenderer(new BmKeyedComboBoxRender(this.System_Model, false));
/* 65 */     tcm.getColumn(0).setCellEditor(new DefaultCellEditor(this.locSystem));
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/db/Combo/ComboJTbl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */