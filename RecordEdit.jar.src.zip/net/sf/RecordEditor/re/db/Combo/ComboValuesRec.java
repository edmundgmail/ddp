/*     */ package net.sf.RecordEditor.re.db.Combo;
/*     */ 
/*     */ import net.sf.RecordEditor.utils.jdbc.AbsRecord;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComboValuesRec
/*     */   extends AbsRecord
/*     */ {
/*     */   private String Combo_Code;
/*     */   protected String initCombo_Code;
/*     */   private String Combo_Value;
/*     */   
/*     */   public ComboValuesRec()
/*     */   {
/*  32 */     this.Combo_Code = "";
/*  33 */     this.Combo_Value = "";
/*     */     
/*  35 */     setKeys();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ComboValuesRec(String pCombo_Code, String pCombo_Value)
/*     */   {
/*  42 */     super(false);
/*     */     
/*  44 */     this.Combo_Code = pCombo_Code;
/*  45 */     this.Combo_Value = pCombo_Value;
/*     */     
/*  47 */     setKeys();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setKeys()
/*     */   {
/*  56 */     this.initCombo_Code = this.Combo_Code;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasTheKeyChanged()
/*     */   {
/*  65 */     return (this.initCombo_Code == null) || (!this.initCombo_Code.equals(this.Combo_Code));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object clone()
/*     */   {
/*  76 */     super.clone();
/*     */     
/*  78 */     ComboValuesRec ret = new ComboValuesRec(this.Combo_Code, this.Combo_Value);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  83 */     ret.setNew(true);
/*  84 */     ret.setUpdateStatus(3);
/*     */     
/*  86 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFieldCount()
/*     */   {
/*  95 */     return 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getField(int fieldNum)
/*     */   {
/* 109 */     if (this.updateStatus == -1) { return "";
/*     */     }
/* 111 */     switch (fieldNum) {
/* 112 */     case 0:  return this.Combo_Code;
/* 113 */     case 1:  return this.Combo_Value; }
/* 114 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setFieldWithString(int fieldNum, String val)
/*     */   {
/* 127 */     switch (fieldNum) {
/* 128 */     case 0:  setCombo_Code(val);
/* 129 */       break;
/* 130 */     case 1:  setCombo_Value(val);
/* 131 */       break;
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setFieldWithObject(int fieldNum, Object val)
/*     */   {
/* 145 */     switch (fieldNum) {}
/* 146 */     setFieldWithString(fieldNum, (String)val);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCombo_Code()
/*     */   {
/* 154 */     return this.Combo_Code;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCombo_Code(String val)
/*     */   {
/* 164 */     if (((val == null) || ("".equals(val))) && ((this.Combo_Code == null) || ("".equals(this.Combo_Code))))
/*     */     {
/* 166 */       return;
/*     */     }
/*     */     
/* 169 */     if ((val == null) || (!val.equals(this.Combo_Code)) || (this.updateStatus == -1)) {
/* 170 */       this.Combo_Code = val;
/* 171 */       this.updateStatus = 3;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getCombo_Value()
/*     */   {
/* 179 */     return this.Combo_Value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCombo_Value(String val)
/*     */   {
/* 189 */     if (((val == null) || ("".equals(val))) && ((this.Combo_Value == null) || ("".equals(this.Combo_Value))))
/*     */     {
/* 191 */       return;
/*     */     }
/*     */     
/* 194 */     if ((val == null) || (!val.equals(this.Combo_Value)) || (this.updateStatus == -1)) {
/* 195 */       this.Combo_Value = val;
/* 196 */       this.updateStatus = 3;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/db/Combo/ComboValuesRec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */