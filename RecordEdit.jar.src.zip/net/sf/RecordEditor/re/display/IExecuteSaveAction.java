package net.sf.RecordEditor.re.display;

public abstract interface IExecuteSaveAction
{
  public abstract void executeSavedFilterDialog();
  
  public abstract void executeSavedSortTreeDialog();
  
  public abstract void executeSavedRecordTreeDialog();
  
  public abstract AbstractFileDisplay executeSavedTask(String paramString);
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/display/IExecuteSaveAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */