/*    */ package net.sf.RecordEditor.re.display;
/*    */ 
/*    */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DisplayDetails
/*    */ {
/*    */   public static AbstractFileDisplay getDisplayDetails(ReFrame frame)
/*    */   {
/* 12 */     AbstractFileDisplay parentTab = null;
/* 13 */     if ((frame instanceof AbstractFileDisplay)) {
/* 14 */       parentTab = (AbstractFileDisplay)frame;
/* 15 */     } else if ((frame instanceof IChildDisplay)) {
/* 16 */       parentTab = ((IChildDisplay)frame).getSourceDisplay();
/* 17 */     } else if ((frame instanceof IDisplayFrame)) {
/* 18 */       parentTab = ((IDisplayFrame)frame).getActiveDisplay();
/*    */     }
/* 20 */     return parentTab;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/display/DisplayDetails.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */