package net.sf.RecordEditor.re.display;

import net.sf.JRecord.Details.AbstractLayoutDetails;
import net.sf.JRecord.Details.AbstractLine;
import net.sf.RecordEditor.re.file.AbstractLineNode;
import net.sf.RecordEditor.re.file.FileView;
import net.sf.RecordEditor.re.tree.AbstractLineNodeTreeParser;

public abstract interface IDisplayBuilder
{
  public static final int ST_INITIAL_EDIT = 1;
  public static final int ST_INITIAL_BROWSE = 2;
  public static final int ST_LIST_SCREEN = 3;
  public static final int ST_RECORD_SCREEN = 4;
  public static final int ST_RECORD_TREE = 5;
  public static final int ST_CB2XML_TREE = 6;
  public static final int ST_LINES_AS_COLUMNS = 7;
  public static final int ST_LINE_TREE_CHILD = 8;
  public static final int ST_LINE_TREE_CHILD_EXPAND_PROTO = 9;
  public static final int ST_DOCUMENT = 10;
  public static final int ST_COLORED_DOCUMENT = 11;
  
  public abstract AbstractFileDisplayWithFieldHide newDisplay(int paramInt1, String paramString, IDisplayFrame<? extends AbstractFileDisplay> paramIDisplayFrame, AbstractLayoutDetails paramAbstractLayoutDetails, FileView paramFileView, int paramInt2);
  
  public abstract AbstractFileDisplayWithFieldHide newDisplay(int paramInt, String paramString, IDisplayFrame<? extends AbstractFileDisplay> paramIDisplayFrame, AbstractLayoutDetails paramAbstractLayoutDetails, FileView paramFileView, AbstractLine paramAbstractLine);
  
  public abstract AbstractFileDisplayWithFieldHide newDisplay(int paramInt1, IDisplayFrame<? extends AbstractFileDisplay> paramIDisplayFrame, AbstractLayoutDetails paramAbstractLayoutDetails, FileView paramFileView, AbstractLineNodeTreeParser paramAbstractLineNodeTreeParser, boolean paramBoolean, int paramInt2);
  
  public abstract AbstractFileDisplayWithFieldHide newLineTreeChildScreen(int paramInt1, IDisplayFrame paramIDisplayFrame, FileView paramFileView, AbstractLineNode paramAbstractLineNode, boolean paramBoolean, int paramInt2);
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/display/IDisplayBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */