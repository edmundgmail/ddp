/*     */ package net.sf.RecordEditor.re.display;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.RecordEditor.re.file.AbstractLineNode;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.re.tree.AbstractLineNodeTreeParser;
/*     */ import net.sf.RecordEditor.utils.fileStorage.DataStoreStd;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DisplayBuilderFactory
/*     */   implements IDisplayBuilder
/*     */ {
/*  21 */   private static final DisplayBuilderFactory instance = new DisplayBuilderFactory();
/*     */   
/*  23 */   private ArrayList<IDisplayBuilder> builders = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static IDisplayBuilder getInstance()
/*     */   {
/*  48 */     return instance;
/*     */   }
/*     */   
/*     */   public static void startEditorNewFile(AbstractLayoutDetails layout) {
/*  52 */     FileView file = new FileView(DataStoreStd.newStore(layout), null, null, false);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  57 */     instance.newDisplay(1, "", null, file.getLayout(), file, 0);
/*     */   }
/*     */   
/*     */   public static void register(IDisplayBuilder builder) {
/*  61 */     instance.builders.add(builder);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static AbstractFileDisplay newLineList(IDisplayFrame<? extends AbstractFileDisplay> frame, AbstractLayoutDetails group, FileView viewOfFile, FileView masterFile)
/*     */   {
/*  70 */     return instance.newDisplay(3, "", frame, group, viewOfFile, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static AbstractFileDisplayWithFieldHide newLineTree(IDisplayFrame<? extends AbstractFileDisplay> parentFrame, FileView viewOfFile, AbstractLineNodeTreeParser treeParser, boolean mainView, int columnsToSkip)
/*     */   {
/*  79 */     return instance.newDisplay(3, parentFrame, viewOfFile.getLayout(), viewOfFile, treeParser, mainView, columnsToSkip);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static AbstractFileDisplayWithFieldHide newLineTreeChild(IDisplayFrame df, FileView viewOfFile, AbstractLineNode rootNode, boolean mainView, int columnsToSkip)
/*     */   {
/*  88 */     return instance.newLineTreeChildScreen(8, df, viewOfFile, rootNode, mainView, columnsToSkip);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractFileDisplayWithFieldHide newDisplay(int screenType, String screenName, IDisplayFrame<? extends AbstractFileDisplay> parentFrame, AbstractLayoutDetails group, FileView viewOfFile, int lineNo)
/*     */   {
/*  96 */     AbstractFileDisplayWithFieldHide disp = null;
/*     */     
/*     */ 
/*  99 */     for (int i = this.builders.size() - 1; (disp == null) && (i >= 0); i--) {
/* 100 */       disp = ((IDisplayBuilder)this.builders.get(i)).newDisplay(screenType, screenName, parentFrame, group, viewOfFile, lineNo);
/*     */     }
/*     */     
/*     */ 
/* 104 */     return disp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractFileDisplayWithFieldHide newDisplay(int screenType, String screenName, IDisplayFrame<? extends AbstractFileDisplay> parentFrame, AbstractLayoutDetails group, FileView viewOfFile, AbstractLine line)
/*     */   {
/* 112 */     AbstractFileDisplayWithFieldHide disp = null;
/*     */     
/* 114 */     for (int i = this.builders.size() - 1; (disp == null) && (i >= 0); i--) {
/* 115 */       disp = ((IDisplayBuilder)this.builders.get(i)).newDisplay(screenType, screenName, parentFrame, group, viewOfFile, line);
/*     */     }
/*     */     
/* 118 */     return disp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractFileDisplayWithFieldHide newDisplay(int screenType, IDisplayFrame<? extends AbstractFileDisplay> parentFrame, AbstractLayoutDetails group, FileView viewOfFile, AbstractLineNodeTreeParser treeParser, boolean mainView, int columnsToSkip)
/*     */   {
/* 127 */     AbstractFileDisplayWithFieldHide disp = null;
/*     */     
/* 129 */     for (int i = this.builders.size() - 1; (disp == null) && (i >= 0); i--) {
/* 130 */       disp = ((IDisplayBuilder)this.builders.get(i)).newDisplay(screenType, parentFrame, group, viewOfFile, treeParser, mainView, columnsToSkip);
/*     */     }
/*     */     
/* 133 */     return disp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractFileDisplayWithFieldHide newLineTreeChildScreen(int screenType, IDisplayFrame df, FileView viewOfFile, AbstractLineNode rootNode, boolean mainView, int columnsToSkip)
/*     */   {
/* 143 */     AbstractFileDisplayWithFieldHide disp = null;
/*     */     
/* 145 */     for (int i = this.builders.size() - 1; (disp == null) && (i >= 0); i--) {
/* 146 */       disp = ((IDisplayBuilder)this.builders.get(i)).newLineTreeChildScreen(screenType, df, viewOfFile, rootNode, mainView, columnsToSkip);
/*     */     }
/*     */     
/* 149 */     return disp;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/display/DisplayBuilderFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */