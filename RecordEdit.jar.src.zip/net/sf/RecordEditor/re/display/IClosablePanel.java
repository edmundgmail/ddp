package net.sf.RecordEditor.re.display;

public abstract interface IClosablePanel
{
  public abstract void closePanel();
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/display/IClosablePanel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */