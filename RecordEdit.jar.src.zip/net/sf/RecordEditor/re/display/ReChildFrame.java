/*    */ package net.sf.RecordEditor.re.display;
/*    */ 
/*    */ import net.sf.RecordEditor.re.file.FileView;
/*    */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReChildFrame
/*    */   extends ReFrame
/*    */   implements IChildDisplay
/*    */ {
/*    */   private final AbstractFileDisplay source;
/*    */   
/*    */   public ReChildFrame(AbstractFileDisplay src, String enName)
/*    */   {
/* 19 */     this(src, "", enName);
/*    */   }
/*    */   
/*    */   public ReChildFrame(AbstractFileDisplay src, String name, String enName)
/*    */   {
/* 24 */     super(src.getFileView().getFileNameNoDirectory(), name, enName, src.getFileView().getBaseFile());
/* 25 */     this.source = src;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public AbstractFileDisplay getSourceDisplay()
/*    */   {
/* 32 */     return this.source;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/display/ReChildFrame.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */