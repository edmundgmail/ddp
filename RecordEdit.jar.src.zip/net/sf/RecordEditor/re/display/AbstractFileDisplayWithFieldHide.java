package net.sf.RecordEditor.re.display;

public abstract interface AbstractFileDisplayWithFieldHide
  extends AbstractFileDisplay
{
  public abstract boolean[] getFieldVisibility(int paramInt);
  
  public abstract void setFieldVisibility(int paramInt, boolean[] paramArrayOfBoolean);
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/display/AbstractFileDisplayWithFieldHide.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */