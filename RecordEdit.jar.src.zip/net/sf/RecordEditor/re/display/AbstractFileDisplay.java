package net.sf.RecordEditor.re.display;

import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JTable;
import net.sf.JRecord.Details.AbstractLayoutDetails;
import net.sf.JRecord.Details.AbstractLine;
import net.sf.RecordEditor.re.file.FilePosition;
import net.sf.RecordEditor.re.file.FileView;
import net.sf.RecordEditor.utils.common.ReActionHandler;
import net.sf.RecordEditor.utils.swing.BaseHelpPanel;

public abstract interface AbstractFileDisplay
  extends ReActionHandler
{
  public abstract int getCurrRow();
  
  public abstract void setCurrRow(FilePosition paramFilePosition);
  
  public abstract boolean isOkToUseSelectedRows();
  
  public abstract void doClose();
  
  public abstract int[] getSelectedRows();
  
  public abstract List<AbstractLine> getSelectedLines();
  
  public abstract AbstractLine getTreeLine();
  
  public abstract int getLayoutIndex();
  
  public abstract void setLayoutIndex(int paramInt);
  
  public abstract FileView getFileView();
  
  public abstract void stopCellEditing();
  
  public abstract JTable getJTable();
  
  public abstract void setNewLayout(AbstractLayoutDetails paramAbstractLayoutDetails);
  
  public abstract IDisplayFrame<? extends AbstractFileDisplay> getParentFrame();
  
  public abstract BaseHelpPanel getActualPnl();
  
  public abstract void setDockingPopup(MouseListener paramMouseListener);
  
  public abstract void insertLine(int paramInt);
  
  public abstract void setCurrRow(int paramInt1, int paramInt2, int paramInt3);
  
  public abstract IExecuteSaveAction getExecuteTasks();
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/display/AbstractFileDisplay.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */