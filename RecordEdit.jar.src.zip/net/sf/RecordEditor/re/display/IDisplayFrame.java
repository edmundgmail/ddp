package net.sf.RecordEditor.re.display;

import net.sf.RecordEditor.edit.display.common.ILayoutChanged;
import net.sf.RecordEditor.utils.common.ReActionHandler;
import net.sf.RecordEditor.utils.screenManager.ReFrame;

public abstract interface IDisplayFrame<BD extends AbstractFileDisplay>
  extends ReActionHandler, ILayoutChanged
{
  public abstract void addScreen(BD paramBD);
  
  public abstract void close(AbstractFileDisplay paramAbstractFileDisplay);
  
  public abstract void reClose();
  
  public abstract void setToActiveTab(AbstractFileDisplay paramAbstractFileDisplay);
  
  public abstract void setToActiveFrame();
  
  public abstract void bldScreen();
  
  public abstract AbstractFileDisplay getActiveDisplay();
  
  public abstract int getScreenCount();
  
  public abstract void moveToSeperateScreen(AbstractFileDisplay paramAbstractFileDisplay);
  
  public abstract int indexOf(AbstractFileDisplay paramAbstractFileDisplay);
  
  public abstract boolean isActionAvailable(int paramInt1, int paramInt2);
  
  public abstract void executeAction(int paramInt1, int paramInt2);
  
  public abstract ReFrame getReFrame();
  
  public abstract void moveToFront();
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/display/IDisplayFrame.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */