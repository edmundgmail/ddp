package net.sf.RecordEditor.re.display;

public abstract interface IChildDisplay
{
  public abstract AbstractFileDisplay getSourceDisplay();
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/display/IChildDisplay.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */