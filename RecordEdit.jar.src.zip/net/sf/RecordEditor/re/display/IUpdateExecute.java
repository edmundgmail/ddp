package net.sf.RecordEditor.re.display;

import net.sf.RecordEditor.utils.swing.saveRestore.IUpdateDetails;

public abstract interface IUpdateExecute<What>
  extends IUpdateDetails<What>
{
  public abstract AbstractFileDisplay doAction();
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/display/IUpdateExecute.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */