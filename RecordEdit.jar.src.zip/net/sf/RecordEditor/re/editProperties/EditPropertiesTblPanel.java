/*    */ package net.sf.RecordEditor.re.editProperties;
/*    */ 
/*    */ import javax.swing.JEditorPane;
/*    */ import javax.swing.JScrollPane;
/*    */ import javax.swing.JTable;
/*    */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*    */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EditPropertiesTblPanel
/*    */   extends BasePanel
/*    */ {
/* 27 */   private static final int TABLE_HEIGHT = SwingUtils.TABLE_ROW_HEIGHT * 13;
/*    */   
/*    */ 
/*    */ 
/*    */   private JEditorPane tips;
/*    */   
/*    */ 
/*    */ 
/*    */   private PropertiesTableModel loaderModel;
/*    */   
/*    */ 
/*    */ 
/*    */   private JTable propertiesTbl;
/*    */   
/*    */ 
/*    */ 
/*    */   private EditParams pgmParams;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public EditPropertiesTblPanel(EditParams params, String description, String[] columnNames, String[] columnHeadings, int tableSize)
/*    */   {
/* 50 */     this.pgmParams = params;
/*    */     
/* 52 */     this.tips = new JEditorPane("text/html", description);
/*    */     
/* 54 */     this.loaderModel = new PropertiesTableModel(this.pgmParams, columnNames, columnHeadings, tableSize);
/*    */     
/*    */ 
/* 57 */     init_100_ScreenFields();
/* 58 */     init_200_Screen();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private void init_100_ScreenFields()
/*    */   {
/* 67 */     this.propertiesTbl = new JTable(this.loaderModel);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private void init_200_Screen()
/*    */   {
/* 76 */     addComponentRE(1, 5, CommonCode.TIP_HEIGHT, BasePanel.GAP1, 2, 2, this.tips);
/*    */     
/*    */ 
/*    */ 
/* 80 */     addComponentRE(1, 5, TABLE_HEIGHT, BasePanel.GAP2, 2, 2, new JScrollPane(this.propertiesTbl));
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/editProperties/EditPropertiesTblPanel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */