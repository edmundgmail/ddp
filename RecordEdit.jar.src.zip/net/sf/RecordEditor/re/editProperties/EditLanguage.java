/*     */ package net.sf.RecordEditor.re.editProperties;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.event.FocusAdapter;
/*     */ import java.awt.event.FocusEvent;
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Locale;
/*     */ import java.util.TreeMap;
/*     */ import java.util.TreeSet;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JEditorPane;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.ListCellRenderer;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.TreeComboFileSelect;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EditLanguage
/*     */   extends BasePanel
/*     */ {
/*     */   private static final String FLAG_DIR = "/pict/flags/";
/*  35 */   private static final ImageIcon BLANK_ICON = Common.readIcon("/pict/flags/blank.png");
/*     */   
/*  37 */   private static final String DESCRIPTION = LangConversion.convertId(2, "EditProtoperties_Language", "<h2>Foreign Language</h2>This screen lets you change the language used in the <b>RecordEditor</b><br/>You will need to <b>exit</b> and <b>restart</b> the Editor for the change to come into effect<br/><br/>If your language is not supported ???, Why not do the Translation your self ???.<br/>Have a look at the ReadMe.html in the language directory:") + " " + Parameters.expandVars(Parameters.formatLangDir(Parameters.getString("LangDirectory")));
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  48 */   private JEditorPane tips = new JEditorPane("text/html", DESCRIPTION);
/*     */   
/*  50 */   private TreeComboFileSelect langDirFchooser = new TreeComboFileSelect(true, false, true, null, null);
/*     */   
/*  52 */   private JComboBox languagesCombo = new JComboBox();
/*     */   
/*     */   private final EditParams params;
/*     */   
/*  56 */   private String lastLangDir = null;
/*     */   
/*     */   private String lastLang;
/*  59 */   private TreeMap<String, FlagComboItem> langItmHash = new TreeMap();
/*  60 */   private TreeMap<String, String> langLongName = new TreeMap();
/*     */   
/*     */   public EditLanguage(EditParams params)
/*     */   {
/*  64 */     this.params = params;
/*     */     
/*  66 */     init_100_InitVars();
/*  67 */     init_200_LayoutScreen();
/*  68 */     init_300_FinaliseScreen();
/*     */   }
/*     */   
/*     */   private void init_100_InitVars() {
/*  72 */     init_110_InitLang();
/*  73 */     this.lastLang = this.params.getProperty("Language");
/*     */     
/*     */ 
/*     */ 
/*  77 */     getLanguages();
/*     */     
/*  79 */     this.langDirFchooser.setText(getLangDir());
/*  80 */     this.langDirFchooser.setExpandVars(true);
/*     */     
/*     */ 
/*  83 */     if ((this.lastLang != null) && (this.langItmHash.containsKey(this.lastLang))) {
/*  84 */       this.languagesCombo.setSelectedItem(this.langItmHash.get(this.lastLang));
/*     */     } else {
/*  86 */       this.languagesCombo.setSelectedIndex(0);
/*     */     }
/*     */   }
/*     */   
/*     */   private void init_110_InitLang()
/*     */   {
/*  92 */     Locale[] locales = Locale.getAvailableLocales();
/*     */     
/*     */ 
/*     */ 
/*  96 */     for (Locale l : locales) {
/*  97 */       String s = l.getCountry();
/*     */       
/*  99 */       if ((s != null) && (!"".equals(s))) {
/* 100 */         this.langLongName.put(s.toLowerCase(), l.getDisplayLanguage());
/*     */       }
/*     */     }
/*     */     
/* 104 */     for (Locale l : locales) {
/* 105 */       this.langLongName.put(l.getLanguage(), l.getDisplayLanguage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void init_200_LayoutScreen()
/*     */   {
/* 112 */     addComponentRE(1, 5, CommonCode.TIP_HEIGHT, BasePanel.GAP2, 2, 2, this.tips);
/*     */     
/*     */ 
/* 115 */     addLineRE("Language Directory", this.langDirFchooser);
/* 116 */     addLineRE("Language", this.languagesCombo);
/*     */   }
/*     */   
/*     */   private void init_300_FinaliseScreen()
/*     */   {
/* 121 */     this.languagesCombo.setRenderer(new FlagComboRenderer(null));
/* 122 */     this.langDirFchooser.addFcFocusListener(new FocusAdapter()
/*     */     {
/*     */ 
/*     */ 
/*     */       public void focusLost(FocusEvent e)
/*     */       {
/*     */ 
/*     */ 
/* 130 */         EditLanguage.this.params.setProperty("LangDirectory", EditLanguage.this.langDirFchooser.getText());
/*     */         
/*     */ 
/* 133 */         EditLanguage.this.params.propertiesChanged = true;
/*     */         
/*     */ 
/* 136 */         System.out.println("Focus Lost ... get Languages");
/* 137 */         EditLanguage.this.getLanguages();
/*     */       }
/*     */       
/* 140 */     });
/* 141 */     this.languagesCombo.addFocusListener(new FocusAdapter()
/*     */     {
/*     */ 
/*     */ 
/*     */       public void focusLost(FocusEvent e)
/*     */       {
/*     */ 
/* 148 */         Object o = EditLanguage.this.languagesCombo.getSelectedItem();
/* 149 */         if (o == null) {
/* 150 */           o = "";
/*     */         }
/*     */         
/* 153 */         EditLanguage.this.lastLang = o.toString().trim();
/* 154 */         EditLanguage.this.params.setProperty("Language", EditLanguage.this.lastLang);
/*     */         
/*     */ 
/* 157 */         EditLanguage.this.params.propertiesChanged = true;
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */   private void getLanguages()
/*     */   {
/* 165 */     String dir = Parameters.expandVars(getLangDir());
/*     */     
/* 167 */     if ((this.lastLangDir == null) || (!this.lastLangDir.equals(dir)))
/*     */     {
/* 169 */       String langFilePref = "ReMsgs.";
/* 170 */       Object lang = this.languagesCombo.getSelectedItem();
/* 171 */       TreeSet<String> items = new TreeSet();
/*     */       
/* 173 */       this.lastLangDir = dir;
/* 174 */       this.languagesCombo.removeAllItems();
/* 175 */       this.langItmHash.clear();
/*     */       
/* 177 */       File directory = new File(dir);
/*     */       
/*     */ 
/* 180 */       if ((directory.exists()) && (directory.isDirectory())) {
/* 181 */         File[] fList = directory.listFiles();
/*     */         
/* 183 */         for (File file : fList) {
/* 184 */           if (file.isFile()) {
/* 185 */             String s = file.getName();
/* 186 */             if (s.startsWith(Parameters.LANG_FILE_PREFIX)) {
/* 187 */               if (s.toLowerCase().endsWith(".class")) {
/* 188 */                 items.add(s.substring(Parameters.LANG_FILE_PREFIX.length(), s.length() - 6));
/* 189 */               } else if (s.endsWith(".po")) {
/* 190 */                 items.add(s.substring(Parameters.LANG_FILE_PREFIX.length(), s.length() - 3));
/*     */               }
/* 192 */             } else if ((s.startsWith(langFilePref)) && (s.endsWith(".po"))) {
/* 193 */               items.add(s.substring(langFilePref.length(), s.length() - 3));
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 199 */       this.languagesCombo.addItem(new FlagComboItem(" "));
/* 200 */       for (String itm : items) {
/* 201 */         this.languagesCombo.addItem(new FlagComboItem(itm));
/*     */       }
/*     */       
/* 204 */       if ((lang != null) && (!"".equals(lang.toString()))) {
/* 205 */         this.languagesCombo.setSelectedItem(lang);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private String getLangDir()
/*     */   {
/* 212 */     return Parameters.formatLangDir(this.params.getProperty("LangDirectory"));
/*     */   }
/*     */   
/*     */ 
/*     */   private class FlagComboItem
/*     */   {
/*     */     private ImageIcon icon;
/*     */     public final String langCode;
/*     */     public final String longName;
/*     */     
/*     */     public FlagComboItem(String langCode)
/*     */     {
/* 224 */       String s = "";
/* 225 */       if ((langCode != null) && (EditLanguage.this.langLongName.containsKey(langCode))) {
/* 226 */         s = (String)EditLanguage.this.langLongName.get(langCode);
/* 227 */         if ((s != null) && (!"".equals(s))) {
/* 228 */           s = " - " + s;
/*     */         }
/*     */       }
/* 231 */       this.langCode = langCode;
/* 232 */       this.longName = s;
/*     */       
/* 234 */       if ((langCode == null) || ("".equals(langCode.trim()))) {
/* 235 */         this.icon = null;
/* 236 */       } else if (("tst".equals(langCode)) || ("txt".equals(langCode)) || (langCode.length() > 3)) {
/* 237 */         this.icon = EditLanguage.BLANK_ICON;
/*     */       } else {
/* 239 */         this.icon = Common.readIcon("/pict/flags/" + langCode + ".png");
/* 240 */         if (this.icon == null) {
/* 241 */           this.icon = EditLanguage.BLANK_ICON;
/*     */         }
/*     */       }
/* 244 */       EditLanguage.this.langItmHash.put(langCode, this);
/*     */     }
/*     */     
/*     */     public String toString() {
/* 248 */       return this.langCode;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class FlagComboRenderer
/*     */     extends JLabel
/*     */     implements ListCellRenderer
/*     */   {
/*     */     private FlagComboRenderer()
/*     */     {
/* 258 */       setOpaque(true);
/*     */       
/* 260 */       setVerticalAlignment(0);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
/*     */     {
/* 278 */       if ((value instanceof EditLanguage.FlagComboItem)) {
/* 279 */         EditLanguage.FlagComboItem ci = (EditLanguage.FlagComboItem)value;
/* 280 */         super.setIcon(EditLanguage.FlagComboItem.access$900(ci));
/* 281 */         super.setText(ci.langCode + ci.longName);
/*     */       } else {
/* 283 */         super.setIcon(null);
/* 284 */         super.setText(value.toString());
/*     */       }
/* 286 */       if (isSelected) {
/* 287 */         setBackground(list.getSelectionBackground());
/* 288 */         setForeground(list.getSelectionForeground());
/*     */       } else {
/* 290 */         setBackground(list.getBackground());
/* 291 */         setForeground(list.getForeground());
/*     */       }
/*     */       
/* 294 */       return this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/editProperties/EditLanguage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */