/*    */ package net.sf.RecordEditor.re.editProperties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JarGroup
/*    */ {
/*    */   public static final int TYPE_COLUMN = 0;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static final int JAR_COLUMN = 1;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static final int DESCRIPTION_COLUMN = 2;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 24 */   protected int count = 0;
/* 25 */   protected String[][] jars = new String[30][3];
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void add(String type, String jar, String description)
/*    */   {
/* 35 */     if (this.count < this.jars.length) {
/* 36 */       this.jars[this.count] = new String[3];
/* 37 */       this.jars[this.count][0] = type;
/* 38 */       this.jars[this.count][1] = jar;
/* 39 */       this.jars[(this.count++)][2] = description;
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/editProperties/JarGroup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */