/*     */ package net.sf.RecordEditor.re.editProperties;
/*     */ 
/*     */ import java.awt.Container;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FileReader;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.io.Reader;
/*     */ import java.sql.Connection;
/*     */ import java.sql.Statement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Properties;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JEditorPane;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTabbedPane;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.JTextField;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.JarFileSelect;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenericInstaller
/*     */   implements ActionListener
/*     */ {
/*  59 */   public static final int TIP_HEIGHT = SwingUtils.STANDARD_FONT_HEIGHT * 17;
/*     */   
/*     */   private static final int HSQL_IDX = 2;
/*     */   private static final int SQLITE_IDX = 11;
/*  63 */   private Properties properties = Parameters.readProperties();
/*     */   
/*  65 */   private String sqlDir = Parameters.getBaseDirectory() + "/SQL/";
/*  66 */   private JFrame frame = new JFrame("RecordEditor - Generic DB installer");
/*     */   
/*     */   private JPanel secondPanel;
/*  69 */   private static final String[] DB_LIST = { "Other", "Microsoft Access", "HSQL", "HSQL Imbedded", "My SQL", "Oracle", "H2 Mixed Mode", "H2", "H2 Imbeded", "Derby", "Derby Imbedded", "SQLite", "Postgres" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  75 */   private JTabbedPane tabbedPane = new JTabbedPane();
/*     */   
/*     */   private JEditorPane tips;
/*     */   private JEditorPane tipsRunSql;
/*  79 */   private JComboBox database = new JComboBox(DB_LIST);
/*     */   
/*     */ 
/*     */ 
/*  83 */   private JTextField driver = new JTextField();
/*  84 */   private JTextField source = new JTextField();
/*  85 */   private JTextField user = new JTextField();
/*  86 */   private JTextField password = new JTextField();
/*  87 */   private JTextField commit = new JTextField();
/*  88 */   private JTextField checkpoint = new JTextField();
/*  89 */   private JTextField createExt = new JTextField();
/*  90 */   private JTextField dbIndex = new JTextField("0");
/*  91 */   private JarFileSelect jdbcJar = new JarFileSelect(true, null);
/*     */   
/*  93 */   private JCheckBox dropSemiChk = new JCheckBox();
/*     */   
/*  95 */   private JCheckBox saveInLibDir = new JCheckBox();
/*  96 */   private JButton test = SwingUtils.newButton("Test Conection");
/*  97 */   private JButton sqlScreen = SwingUtils.newButton("Run SQL");
/*     */   
/*  99 */   private JButton bldAllTables = new JButton(" + ");
/* 100 */   private JButton bldCreateTables = new JButton(" + ");
/* 101 */   private JButton bldRecordTables = new JButton(" + ");
/* 102 */   private JButton bldtblTables = new JButton(" + ");
/*     */   
/* 104 */   private JTextArea sqlOutput = new JTextArea();
/*     */   
/* 106 */   private BasePanel pnl = new BasePanel();
/*     */   
/*     */ 
/*     */ 
/* 110 */   private JTextField[] screenFields = { this.driver, this.source, this.user, this.password, this.createExt, this.commit, this.checkpoint };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String DESCRIPTION = "<h2>Generic Database Setup</h2>This program will<ol compact><li>Create <b>RecordEditor</b> Properties file with the Data Base details you enter.</li><li>Add the JDBC driver jar you select to the jar file.</li><li>Add <b>RecordEditor</b> tables to the Database.</ol><h2>How to use the screen</h2><ol compact><li>Select the database you are using in the <it>Database</it> Combo box, this will set the other fields to the default values.</li><li>Update the Database connection details as needed</li><li>Enter the JDBC (Java database Concectivity) Jar for the Database.</li><li>Your Database needs to be running (except for MS Access)</li><li>Test the database connection.</li><li>Run the SQL</li></ol>";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String DESCRIPTION_RUN_SQL = "<h2>Create DataBase Tables</h2>This screen runs the SQL to create an load the backend SQL tables used by the <b>RecordEditor</b>.<br>You can either run everything at once (first option) or run it one step at a time.";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 138 */   private static final String[][] DB_DETAILS = { { "sun.jdbc.odbc.JdbcOdbcDriver", "JDBC:ODBC:RecordLayout", "", "", "" }, { "org.hsqldb.jdbcDriver", "jdbc:hsqldb:hsql://localhost/recordedit", "sa", "", "" }, { "org.hsqldb.jdbcDriver", "jdbc:hsqldb:file:" + Parameters.getApplicationDirectory() + "HsqlDatabase/recordedit;readonly=no;", "sa", "", "" }, { "org.gjt.mm.mysql.Driver", "jdbc:mysql://localhost/recordedit", "", "", "" }, { "oracle.jdbc.driver.OracleDriver", "jdbc:oracle:oci<version>:@<database>", "...", "...", "" }, { "org.h2.Driver", "jdbc:h2:" + Parameters.getApplicationDirectory() + "H2RecordEditor;AUTO_SERVER=TRUE", "sa", "", "" }, { "org.h2.Driver", "jdbc:h2:tcp://localhost/RecordEditor", "sa", "", "" }, { "org.h2.Driver", "jdbc:h2:" + Parameters.getApplicationDirectory() + "H2RecordEditor", "sa", "", "" }, { "org.apache.derby.jdbc.ClientDriver", "jdbc:derby://localhost:1527/RecordEditor", "???", "???", ";create=true" }, { "org.apache.derby.jdbc.EmbeddedDriver", "jdbc:derby:" + Parameters.getApplicationDirectory() + "DerbyRecordEditor", "???", "???", ";create=true" }, { "org.sqlite.JDBC", "jdbc:sqlite:" + Parameters.getApplicationDirectory() + "SQLiteRE.db", "sa", "", "" }, { "org.postgresql.Driver", "jdbc:postgresql://localhost:5432/RecordEditor", "???", "???", "" } };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 153 */   private static boolean[] dropSemiArray = { false, false, false, false, false, false, false, false, true, true, true, false };
/*     */   
/*     */ 
/*     */   private Connection connection;
/*     */   
/* 158 */   private String currDriver = "";
/* 159 */   private String currSource = "";
/*     */   
/* 161 */   private String currUser = "";
/* 162 */   private String currPassword = "";
/* 163 */   private String currJarName = "";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public GenericInstaller()
/*     */   {
/* 170 */     init_100_ScreenFields();
/* 171 */     init_200_Screen();
/*     */     
/* 173 */     this.frame.setVisible(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_100_ScreenFields()
/*     */   {
/* 182 */     String libDir = Parameters.getLibDirectory();
/* 183 */     if (libDir == null) {
/* 184 */       libDir = "";
/*     */     }
/*     */     
/* 187 */     this.tips = new JEditorPane("text/html", "<h2>Generic Database Setup</h2>This program will<ol compact><li>Create <b>RecordEditor</b> Properties file with the Data Base details you enter.</li><li>Add the JDBC driver jar you select to the jar file.</li><li>Add <b>RecordEditor</b> tables to the Database.</ol><h2>How to use the screen</h2><ol compact><li>Select the database you are using in the <it>Database</it> Combo box, this will set the other fields to the default values.</li><li>Update the Database connection details as needed</li><li>Enter the JDBC (Java database Concectivity) Jar for the Database.</li><li>Your Database needs to be running (except for MS Access)</li><li>Test the database connection.</li><li>Run the SQL</li></ol>");
/* 188 */     this.tips.setEditable(false);
/* 189 */     this.tipsRunSql = new JEditorPane("text/html", "<h2>Create DataBase Tables</h2>This screen runs the SQL to create an load the backend SQL tables used by the <b>RecordEditor</b>.<br>You can either run everything at once (first option) or run it one step at a time.");
/* 190 */     this.tipsRunSql.setEditable(false);
/*     */     
/*     */ 
/* 193 */     if (this.properties == null) {
/* 194 */       this.properties = new Properties();
/* 195 */       System.out.println("No properties");
/*     */     } else {
/* 197 */       this.driver.setText(this.properties.getProperty("Driver.0"));
/* 198 */       this.source.setText(this.properties.getProperty("Source.0"));
/* 199 */       this.user.setText(this.properties.getProperty("User.0"));
/* 200 */       this.password.setText(this.properties.getProperty("Password.0"));
/* 201 */       this.jdbcJar.setText(this.properties.getProperty("JdbcJar.0"));
/*     */     }
/*     */     
/* 204 */     this.database.addActionListener(this);
/* 205 */     this.test.addActionListener(this);
/* 206 */     this.sqlScreen.addActionListener(this);
/* 207 */     this.bldAllTables.addActionListener(this);
/* 208 */     this.bldCreateTables.addActionListener(this);
/* 209 */     this.bldRecordTables.addActionListener(this);
/* 210 */     this.bldtblTables.addActionListener(this);
/*     */     
/* 212 */     this.saveInLibDir.setSelected(libDir.indexOf("usr/") >= 0);
/*     */     
/*     */ 
/*     */ 
/* 216 */     this.frame.setDefaultCloseOperation(3);
/* 217 */     this.frame.addWindowListener(new WindowAdapter() {
/*     */       public void windowClosing(WindowEvent e) {
/* 219 */         GenericInstaller.this.ap_310_SaveProperties();
/* 220 */         GenericInstaller.this.ap_320_SaveJarDetails();
/*     */         
/* 222 */         if (GenericInstaller.this.connection != null) {
/*     */           try {
/* 224 */             GenericInstaller.this.connection.close();
/*     */           }
/*     */           catch (Exception ex) {}
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_200_Screen()
/*     */   {
/* 239 */     SwingUtils.addTab(this.tabbedPane, "GenericInstaller", "DB Definition", new JScrollPane(init_210_buildDbDefPanel()));
/* 240 */     this.secondPanel = init_220_RunSqlPanel();
/*     */     
/* 242 */     this.pnl.addComponentRE(1, 5, -1.0D, BasePanel.GAP, 2, 2, this.tabbedPane);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 247 */     this.pnl.addMessageRE();
/* 248 */     this.pnl.setHeightRE(BasePanel.GAP3);
/*     */     
/*     */ 
/* 251 */     this.frame.getContentPane().add(this.pnl);
/*     */     
/* 253 */     this.frame.pack();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JPanel init_210_buildDbDefPanel()
/*     */   {
/* 263 */     BasePanel pnl = new BasePanel();
/*     */     
/* 265 */     this.dropSemiChk.setSelected(false);
/*     */     
/* 267 */     pnl.addComponentRE(1, 5, TIP_HEIGHT, BasePanel.GAP0, 2, 2, this.tips);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 272 */     pnl.addLineRE("Database Index (0->15)", this.dbIndex);
/* 273 */     pnl.addLineRE("Database", this.database);
/* 274 */     pnl.addLineRE("Drop ; from SQL", this.dropSemiChk);
/* 275 */     pnl.setGapRE(BasePanel.GAP0);
/* 276 */     pnl.addLineRE("Driver", this.driver);
/* 277 */     pnl.addLineRE("Source", this.source);
/* 278 */     pnl.addLineRE("DB Create Extension", this.createExt);
/* 279 */     pnl.setGapRE(BasePanel.GAP0);
/* 280 */     pnl.addLineRE("User", this.user);
/* 281 */     pnl.addLineRE("Password", this.password);
/* 282 */     pnl.setGapRE(BasePanel.GAP0);
/* 283 */     pnl.addLineRE("JDBC Jar", this.jdbcJar);
/* 284 */     pnl.addLineRE("Save Properties in Lib Dir", this.saveInLibDir, this.test);
/* 285 */     pnl.setGapRE(BasePanel.GAP0);
/* 286 */     pnl.addLineRE("Also ", null, this.sqlScreen);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 291 */     return pnl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private JPanel init_220_RunSqlPanel()
/*     */   {
/* 299 */     BasePanel pnl = new BasePanel();
/*     */     
/* 301 */     pnl.addComponentRE(1, 5, CommonCode.TIP_HEIGHT, BasePanel.GAP2, 2, 2, new JScrollPane(this.tipsRunSql));
/*     */     
/*     */ 
/*     */ 
/* 305 */     pnl.addMenuItemRE("Build Everything", this.bldAllTables);
/* 306 */     pnl.setGapRE(BasePanel.GAP0);
/* 307 */     pnl.addLineRE("    or", null);
/* 308 */     pnl.setGapRE(BasePanel.GAP0);
/* 309 */     pnl.addMenuItemRE("Create Tables in DB", this.bldCreateTables);
/* 310 */     pnl.addMenuItemRE("Load Common Tables", this.bldtblTables);
/* 311 */     pnl.addMenuItemRE("Load Record Layouts", this.bldRecordTables);
/* 312 */     pnl.setGapRE(BasePanel.GAP2);
/*     */     
/* 314 */     pnl.addComponentRE(1, 5, -1.0D, BasePanel.GAP, 2, 2, new JScrollPane(this.sqlOutput));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 319 */     return pnl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void actionPerformed(ActionEvent e)
/*     */   {
/* 327 */     if (e.getSource() == this.database) {
/* 328 */       ap_100_ChangeDB();
/* 329 */     } else if (e.getSource() == this.test) {
/* 330 */       ap_200_Test();
/* 331 */     } else if (e.getSource() == this.sqlScreen) {
/* 332 */       ap_300_Change2SqlScreen();
/* 333 */     } else if (e.getSource() == this.bldAllTables) {
/* 334 */       ap_400_RunSql(true, true, true);
/*     */     } else {
/* 336 */       ap_400_RunSql(e.getSource() == this.bldCreateTables, e.getSource() == this.bldRecordTables, e.getSource() == this.bldtblTables);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void ap_100_ChangeDB()
/*     */   {
/* 346 */     int idx = this.database.getSelectedIndex() - 1;
/*     */     
/* 348 */     if (idx >= 0) {
/* 349 */       for (int i = 0; i < DB_DETAILS[idx].length; i++) {
/* 350 */         this.screenFields[i].setText(DB_DETAILS[idx][i]);
/*     */       }
/*     */       
/*     */ 
/* 354 */       this.dropSemiChk.setSelected(dropSemiArray[idx]);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void ap_200_Test()
/*     */   {
/*     */     try
/*     */     {
/* 365 */       getConnection();
/*     */     } catch (Exception e) {
/* 367 */       this.pnl.setMessageTxtRE("Connection Failed:", e.getMessage());
/* 368 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void ap_300_Change2SqlScreen()
/*     */   {
/* 377 */     int idx = -1;
/*     */     try {
/* 379 */       idx = Integer.parseInt(this.dbIndex.getText());
/*     */     }
/*     */     catch (Exception e) {}
/*     */     
/* 383 */     if ((idx < 0) || (idx > 15)) {
/* 384 */       this.pnl.setMessageTxtRE("Invalid Database Index");
/* 385 */       this.dbIndex.requestFocus();
/*     */     } else {
/* 387 */       ap_310_SaveProperties();
/* 388 */       ap_320_SaveJarDetails();
/*     */       try
/*     */       {
/* 391 */         getConnection();
/*     */         
/* 393 */         this.tabbedPane.removeTabAt(0);
/* 394 */         SwingUtils.addTab(this.tabbedPane, "GenericInstaller", "Run SQL", this.secondPanel);
/*     */       } catch (Exception e) {
/* 396 */         this.pnl.setMessageRplTxtRE("Connection Failed: {0}, can not run SQL", e.getMessage());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private Connection getConnection()
/*     */     throws Exception
/*     */   {
/* 404 */     if ((this.connection == null) || (!this.currDriver.equals(this.driver.getText())) || (!this.currSource.equals(this.source.getText())) || (!this.currUser.equals(this.user.getText())) || (!this.currPassword.equals(this.password.getText())) || (!this.currJarName.equals(this.jdbcJar.getText())))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 411 */       this.currDriver = this.driver.getText();
/* 412 */       this.currSource = this.source.getText();
/* 413 */       this.currUser = this.user.getText();
/* 414 */       this.currPassword = this.password.getText();
/* 415 */       this.currJarName = this.jdbcJar.getText();
/*     */       
/* 417 */       this.connection = CommonCode.getConnection("RecordEditor", this.currDriver, this.currSource + this.createExt.getText(), this.currUser, this.currPassword, this.currJarName);
/*     */       
/*     */ 
/*     */ 
/* 421 */       this.createExt.setText("");
/* 422 */       this.pnl.setMessageTxtRE("Connection Ok ~", this.connection.getClass().getName());
/*     */     }
/* 424 */     return this.connection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void ap_310_SaveProperties()
/*     */   {
/* 453 */     String id = this.dbIndex.getText();
/* 454 */     String drop = "";
/* 455 */     if (this.dropSemiChk.isSelected()) {
/* 456 */       drop = "Y";
/*     */     }
/*     */     
/* 459 */     ap_311_SetProperty("SourceName." + id, "DB: " + this.database.getSelectedItem().toString());
/* 460 */     ap_311_SetProperty("Driver." + id, this.driver.getText());
/* 461 */     ap_311_SetProperty("Source." + id, this.source.getText());
/* 462 */     ap_311_SetProperty("User." + id, this.user.getText());
/* 463 */     ap_311_SetProperty("Password." + id, this.password.getText());
/* 464 */     ap_311_SetProperty("JdbcJar." + id, this.jdbcJar.getText());
/* 465 */     ap_311_SetProperty("DBDropSemi." + id, drop);
/*     */     
/* 467 */     if ((this.database.getSelectedIndex() == 2) || (this.database.getSelectedIndex() == 3)) {
/* 468 */       ap_311_SetProperty("Commit." + id, "Y");
/* 469 */       ap_311_SetProperty("Checkpoint." + id, "Y");
/* 470 */     } else if (this.database.getSelectedIndex() == 11) {
/* 471 */       ap_311_SetProperty("Commit." + id, "Y");
/*     */     }
/*     */     try
/*     */     {
/* 475 */       String propertyFileName = Parameters.getPropertyFileName();
/* 476 */       CommonCode.renameFile(propertyFileName);
/* 477 */       this.properties.store(new FileOutputStream(propertyFileName), "RecordEditor");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 481 */       e.printStackTrace();
/*     */     }
/*     */     
/* 484 */     String libDir = Parameters.getGlobalPropertyFileName();
/*     */     
/* 486 */     if ((this.saveInLibDir.isSelected()) && (libDir != null)) {
/*     */       try {
/* 488 */         this.properties.store(new FileOutputStream(libDir), "RecordEditorGlobal");
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 492 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void ap_311_SetProperty(String name, String val)
/*     */   {
/* 505 */     String s = this.properties.getProperty(name);
/*     */     
/* 507 */     if (((s != null) && (!"".equals(s))) || ((val != null) && (!"".equals(val))))
/*     */     {
/* 509 */       this.properties.setProperty(name, val);
/* 510 */       System.out.println(" == Setting property " + name + " ~ " + val);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void ap_320_SaveJarDetails()
/*     */   {
/* 522 */     String newJar = this.jdbcJar.getText();
/* 523 */     System.out.println("Saving jar to file ...");
/* 524 */     this.sqlOutput.setText(this.sqlOutput.getText() + "\n\nSaving jar to file ...");
/* 525 */     if ("".equals(newJar)) {
/* 526 */       return;
/*     */     }
/* 528 */     String outputFile = CommonCode.USER_JAR_FILE;
/*     */     
/* 530 */     ArrayList<String> jarList = new ArrayList();
/* 531 */     FileWriter writer = null;
/* 532 */     BufferedWriter w = null;
/* 533 */     BufferedReader in = null;
/* 534 */     FileReader inReader = null;
/*     */     
/*     */     try
/*     */     {
/* 538 */       File f = new File(outputFile);
/* 539 */       f.getParentFile().mkdirs();
/*     */     } catch (Exception e) {
/* 541 */       e.printStackTrace();
/*     */     }
/*     */     try
/*     */     {
/* 545 */       int jdbcCount = 0;
/*     */       try {
/* 547 */         inReader = new FileReader(outputFile);
/* 548 */         in = new BufferedReader(inReader);
/*     */         
/*     */         String jar;
/*     */         
/* 552 */         while ((jar = in.readLine()) != null) {
/* 553 */           if (!jar.trim().startsWith("#")) {
/* 554 */             String adjJar = jar;
/*     */             int j;
/* 556 */             if ((j = jar.indexOf('\t')) >= 0) {
/* 557 */               if (jar.toLowerCase().startsWith("jdbc")) {
/* 558 */                 jdbcCount++;
/*     */               }
/*     */               
/* 561 */               adjJar = jar.substring(j + 1);
/*     */             }
/* 563 */             if (adjJar.equals(newJar))
/*     */             {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               try
/*     */               {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 575 */                 if (in != null) {
/* 576 */                   in.close();
/*     */                 }
/* 578 */                 if (inReader != null) {
/* 579 */                   inReader.close();
/*     */                 }
/*     */               }
/*     */               catch (IOException ioe) {}
/*     */               return;
/*     */             }
/*     */           }
/* 567 */           jarList.add(jar);
/*     */         }
/*     */         
/* 570 */         CommonCode.renameFile(outputFile);
/*     */         
/*     */ 
/*     */         try
/*     */         {
/* 575 */           if (in != null) {
/* 576 */             in.close();
/*     */           }
/* 578 */           if (inReader != null) {
/* 579 */             inReader.close();
/*     */           }
/*     */         }
/*     */         catch (IOException ioe) {}
/*     */         
/* 584 */         writer = new FileWriter(outputFile);
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 572 */         e.printStackTrace();
/*     */       } finally {
/*     */         try {
/* 575 */           if (in != null) {
/* 576 */             in.close();
/*     */           }
/* 578 */           if (inReader != null) {
/* 579 */             inReader.close();
/*     */           }
/*     */         }
/*     */         catch (IOException ioe) {}
/*     */       }
/*     */       
/* 585 */       w = new BufferedWriter(writer);
/*     */       
/* 587 */       for (int i = 0; i < jarList.size(); i++) {
/* 588 */         w.write((String)jarList.get(i));
/* 589 */         w.newLine();
/*     */       }
/* 591 */       w.write("jdbc." + jdbcCount + "\t" + newJar);
/* 592 */       w.newLine();
/*     */       
/* 594 */       w.close();
/*     */       
/*     */ 
/*     */       try
/*     */       {
/* 599 */         if (writer != null) {
/* 600 */           writer.close();
/*     */         }
/* 602 */         if (w != null) {
/* 603 */           w.close();
/*     */         }
/*     */       } catch (Exception e) {
/* 606 */         e.printStackTrace();
/*     */       }
/*     */       
/* 609 */       System.out.println("Saving jar to file ... done");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 596 */       e.printStackTrace();
/*     */     } finally {
/*     */       try {
/* 599 */         if (writer != null) {
/* 600 */           writer.close();
/*     */         }
/* 602 */         if (w != null) {
/* 603 */           w.close();
/*     */         }
/*     */       } catch (Exception e) {
/* 606 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */     
/* 610 */     this.sqlOutput.setText(this.sqlOutput.getText() + "\n\nSaving jar to file ... Done\n\n");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void ap_400_RunSql(boolean createTbls, boolean loadRecords, boolean loadTables)
/*     */   {
/*     */     try
/*     */     {
/* 623 */       boolean ok = true;
/* 624 */       boolean dropSemiColumn = this.driver.getText().contains("derby");
/* 625 */       String step = "";
/* 626 */       StringBuffer output = new StringBuffer(this.sqlOutput.getText());
/* 627 */       Connection c = getConnection();
/* 628 */       System.out.println("drop Semi " + dropSemiColumn + " " + this.driver.getText());
/*     */       
/* 630 */       Statement statement = c.createStatement();
/*     */       
/* 632 */       if (createTbls) {
/* 633 */         ok = ap_410_RunSqlInAfile(statement, output, "Create_RecordEdit.Sql");
/* 634 */         step = "Create Tables in DB";
/*     */       }
/*     */       
/* 637 */       if ((ok) && (loadTables)) {
/* 638 */         ok = ap_410_RunSqlInAfile(statement, output, "Data_Tables.Sql");
/* 639 */         step = "Load Common Tables";
/*     */       }
/*     */       
/* 642 */       if ((ok) && (loadRecords)) {
/* 643 */         ok = (ap_410_RunSqlInAfile(statement, output, "Data_Record.Sql")) && (ap_410_RunSqlInAfile(statement, output, "Data_RecordFields.Sql")) && (ap_410_RunSqlInAfile(statement, output, "Data_SubRecords.Sql"));
/*     */         
/*     */ 
/* 646 */         step = "Load Record Layouts";
/*     */       }
/*     */       
/* 649 */       if (!ok) {
/* 650 */         output.append("\n**************************************************************");
/* 651 */         output.append("\n* Error at step " + step + " processing stopped");
/* 652 */         output.append("\n* Check the log above for the actual errors");
/* 653 */         output.append("\n**************************************************************");
/*     */       }
/*     */       
/*     */ 
/* 657 */       this.sqlOutput.setText(output.toString());
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 661 */       this.pnl.setMessageRplTxtRE("Connection Failed: {0}, can not run SQL", e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean ap_410_RunSqlInAfile(Statement statement, StringBuffer output, String filename)
/*     */   {
/* 675 */     boolean ok = true;
/* 676 */     boolean dropSemiColumn = this.dropSemiChk.isSelected();
/*     */     try {
/* 678 */       Reader reader = new FileReader(this.sqlDir + filename);
/* 679 */       BufferedReader r = new BufferedReader(reader);
/*     */       
/*     */       String sql;
/*     */       
/* 683 */       while ((sql = r.readLine()) != null) {
/* 684 */         if ((!"".equals(sql.trim())) && (!sql.trim().startsWith("--"))) {
/* 685 */           output.append("   " + sql + "\n");
/* 686 */           if (!sql.trim().endsWith(";")) {
/* 687 */             StringBuffer longSql = new StringBuffer(sql);
/* 688 */             while ((sql = r.readLine()) != null) {
/* 689 */               if ((!"".equals(sql.trim())) && (!sql.trim().startsWith("--"))) {
/* 690 */                 output.append(" " + sql + "\n");
/* 691 */                 longSql.append(" ").append(sql.trim());
/* 692 */                 if (sql.trim().endsWith(";")) {
/*     */                   break;
/*     */                 }
/*     */               }
/*     */             }
/* 697 */             sql = longSql.toString();
/*     */           }
/* 699 */           if ((dropSemiColumn) && (sql.trim().endsWith(";"))) {
/* 700 */             sql = sql.trim();
/* 701 */             sql = sql.substring(0, sql.length() - 1);
/*     */           }
/*     */           try
/*     */           {
/* 705 */             statement.execute(sql.trim());
/*     */           }
/*     */           catch (Exception e) {
/* 708 */             output.append("** Error: " + e.getMessage() + "\n\n");
/*     */             
/* 710 */             ok = false;
/*     */           }
/*     */         }
/*     */       }
/* 714 */       r.close();
/*     */       
/* 716 */       output.append("\n\nFile: " + filename + " proessed\n\n");
/*     */     } catch (Exception e) {
/* 718 */       ok = false;
/* 719 */       output.append("\nError: " + e.getMessage() + "\non file " + filename + "\n\n");
/*     */     }
/*     */     
/* 722 */     return ok;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 733 */     new GenericInstaller();
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/editProperties/GenericInstaller.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */