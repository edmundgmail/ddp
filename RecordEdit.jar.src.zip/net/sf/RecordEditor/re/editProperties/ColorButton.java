/*    */ package net.sf.RecordEditor.re.editProperties;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Component;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Insets;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.swing.Icon;
/*    */ import javax.swing.JButton;
/*    */ import javax.swing.JColorChooser;
/*    */ 
/*    */ 
/*    */ public class ColorButton
/*    */   extends JButton
/*    */   implements ActionListener
/*    */ {
/*    */   private Color color;
/*    */   private final String title;
/*    */   
/*    */   public ColorButton(Color color, String title)
/*    */   {
/* 23 */     this.color = color;
/* 24 */     this.title = title;
/* 25 */     setIcon(new ColorBox(null));
/* 26 */     setMargin(new Insets(2, 2, 2, 2));
/* 27 */     addActionListener(this);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public final Color getColor()
/*    */   {
/* 35 */     return this.color;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void actionPerformed(ActionEvent e)
/*    */   {
/* 44 */     Color newColor = JColorChooser.showDialog(this, this.title, this.color);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 49 */     if (newColor != null) {
/* 50 */       this.color = newColor;
/* 51 */       revalidate();
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   private class ColorBox
/*    */     implements Icon
/*    */   {
/*    */     private ColorBox() {}
/*    */     
/*    */ 
/*    */     public void paintIcon(Component c, Graphics g, int x, int y)
/*    */     {
/* 64 */       if (ColorButton.this.color == null) { return;
/*    */       }
/* 66 */       g.setColor(ColorButton.this.color);
/* 67 */       g.fillRect(x, y, getIconWidth(), getIconHeight());
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     public int getIconWidth()
/*    */     {
/* 77 */       return 37;
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */     public int getIconHeight()
/*    */     {
/* 85 */       return 9;
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/editProperties/ColorButton.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */