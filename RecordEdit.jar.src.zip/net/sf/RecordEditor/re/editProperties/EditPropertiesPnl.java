/*     */ package net.sf.RecordEditor.re.editProperties;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.FocusEvent;
/*     */ import java.awt.event.FocusListener;
/*     */ import java.io.File;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JEditorPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextField;
/*     */ import net.sf.JRecord.Common.Conversion;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.lang.ReOptionDialog;
/*     */ import net.sf.RecordEditor.utils.msg.UtMessages;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMainFrame;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMsg;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasicGenericPopup;
/*     */ import net.sf.RecordEditor.utils.swing.Combo.ComboStrOption;
/*     */ import net.sf.RecordEditor.utils.swing.DatePopup;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.swing.filechooser.IFileChooserWrapper;
/*     */ import net.sf.RecordEditor.utils.swing.filechooser.JRFileChooserWrapper;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.TreeComboFileSelect;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EditPropertiesPnl
/*     */   extends BasePanel
/*     */ {
/*     */   private static final int EMPTY_VAL = 0;
/*     */   private static final int STRING_VAL = 1;
/*     */   private static final int INT_VAL = 2;
/*     */   private static final int BOOLEAN_VAL = 3;
/*     */   private static final int LIST_VAL = 5;
/*     */   private static final int DIRECTORY = 6;
/*     */   private static final int DATE_VAL = 7;
/*     */   private static final int RETRIEVE_APPL_SIZE = 8;
/*     */   private static final int CHARSET_VAL = 9;
/*     */   private static final int SINGLE_BYTE_CHARSET_VAL = 10;
/*  68 */   public static final Integer FLD_EMPTY = Integer.valueOf(0);
/*  69 */   public static final Integer FLD_TEXT = Integer.valueOf(1);
/*  70 */   public static final Integer FLD_CHARSET = Integer.valueOf(9);
/*  71 */   public static final Integer FLD_SINGLE_BYTE_CHARSET = Integer.valueOf(10);
/*  72 */   public static final Integer FLD_INT = Integer.valueOf(2);
/*  73 */   public static final Integer FLD_BOOLEAN = Integer.valueOf(3);
/*  74 */   public static final Integer FLD_LIST = Integer.valueOf(5);
/*  75 */   public static final Integer FLD_DIR = Integer.valueOf(6);
/*  76 */   public static final Integer FLD_DATE = Integer.valueOf(7);
/*  77 */   public static final Integer FLD_RETRIEVE_SIZE = Integer.valueOf(8);
/*     */   
/*     */   private static final int NAME_COLUMN = 0;
/*     */   
/*     */   private static final int DESCRPTION_COLUMN = 1;
/*     */   
/*     */   private static final int VALUE_COLUMN = 2;
/*     */   
/*     */   private static final int TYPE_COLUMN = 3;
/*     */   
/*     */   private static final int PROMPT_COLUMN = 4;
/*     */   
/*     */   private static final int PARAM_COLUMN = 5;
/*     */   
/*     */   private JEditorPane tips;
/*     */   
/*     */   private Object[][] tableData;
/*     */   
/*     */   private final JComponent[] components;
/*     */   
/*     */   private EditParams pgmParams;
/*     */   
/*     */ 
/*     */   public EditPropertiesPnl(EditParams params, String description, Object[][] tblData)
/*     */   {
/* 102 */     this(params, description, -1, -1, tblData);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EditPropertiesPnl(EditParams params, String description, int splitAt1, int splitAt2, Object[][] tblData)
/*     */   {
/* 115 */     this.pgmParams = params;
/* 116 */     this.tableData = tblData;
/* 117 */     this.components = new JComponent[this.tableData.length];
/*     */     
/* 119 */     this.tips = new JEditorPane("text/html", description);
/*     */     
/* 121 */     init_100_Fields(splitAt1, splitAt2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_100_Fields(int splitAt1, int splitAt2)
/*     */   {
/* 131 */     setNameComponents(true);
/*     */     
/* 133 */     addComponentRE(1, 5, CommonCode.TIP_HEIGHT, BasePanel.GAP1, 2, 2, this.tips);
/*     */     
/*     */ 
/*     */ 
/* 137 */     if (splitAt1 < 0) {
/* 138 */       if (this.tableData.length > 9) {
/* 139 */         splitAt1 = 10;
/* 140 */       } else if (splitAt2 > 0) {
/* 141 */         splitAt1 = splitAt2;
/* 142 */         splitAt2 = -1;
/*     */       }
/*     */     }
/*     */     
/* 146 */     if (splitAt1 < 0) {
/* 147 */       addOptions(this, 0, this.tableData.length);
/*     */     } else {
/* 149 */       JPanel p = new JPanel(new BorderLayout());
/*     */       
/* 151 */       p.add("West", addOptions(new BasePanel(), 0, splitAt1));
/*     */       
/* 153 */       if (splitAt2 < 0) {
/* 154 */         p.add("Center", addOptions(new BasePanel(), splitAt1, this.tableData.length));
/*     */       } else {
/* 156 */         p.add("Center", addOptions(new BasePanel(), splitAt1, splitAt2));
/* 157 */         p.add("East", addOptions(new BasePanel(), splitAt2, this.tableData.length));
/*     */       }
/*     */       
/* 160 */       addComponentRE(0, 6, -1.0D, BasePanel.GAP1, 2, 2, p);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private BasePanel addOptions(BasePanel pnl, int st, int en)
/*     */   {
/* 168 */     pnl.setNameComponents(true);
/* 169 */     for (int i = st; i < en; i++) {
/* 170 */       String s = Parameters.getString(this.tableData[i][0].toString());
/* 171 */       if (s != null) {
/* 172 */         this.tableData[i][2] = s;
/*     */       }
/* 174 */       if ((this.tableData[i][3] instanceof Integer)) {
/* 175 */         int type = ((Integer)this.tableData[i][3]).intValue();
/* 176 */         switch (type) {
/*     */         case 0: 
/* 178 */           pnl.addLineRE(" ", null);
/* 179 */           break;
/*     */         case 1: 
/* 181 */           addField(pnl, i, new TxtFld(i, null), null);
/* 182 */           break;
/*     */         case 9: 
/*     */         case 10: 
/* 185 */           addField(pnl, i, new CharsetFld(i, type == 10, null), null);
/* 186 */           break;
/*     */         case 7: 
/* 188 */           addField(pnl, i, new DateFld(i, null), null);
/* 189 */           break;
/*     */         case 2: 
/* 191 */           addField(pnl, i, new IntFld(i, null), null);
/* 192 */           break;
/*     */         case 3: 
/* 194 */           addField(pnl, i, new BoolFld(i, null), null);
/* 195 */           break;
/*     */         case 5: 
/* 197 */           addField(pnl, i, new Combo(i), null);
/* 198 */           break;
/*     */         case 6: 
/* 200 */           ChooseFileName fn = new ChooseFileName(i);
/* 201 */           addField(pnl, i, fn, null);
/* 202 */           break;
/*     */         case 8: 
/* 204 */           if ((i > 1) && ((this.components[(i - 1)] instanceof TxtFld)) && ((this.components[(i - 2)] instanceof TxtFld))) {
/* 205 */             addField(pnl, i, new FetchSize((TxtFld)this.components[(i - 2)], (TxtFld)this.components[(i - 1)]), null);
/*     */           }
/*     */           break;
/*     */         }
/*     */       }
/*     */     }
/* 211 */     return pnl;
/*     */   }
/*     */   
/*     */   public final void save() {
/* 215 */     for (JComponent c : this.components) {
/* 216 */       if ((c instanceof ChooseFileName)) {
/* 217 */         ((ChooseFileName)c).focusLost(null);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void addField(BasePanel pnl, int row, JComponent item, JComponent item2) {
/* 223 */     Object prompt = this.tableData[row][4];
/* 224 */     if (prompt == null) {
/* 225 */       prompt = this.tableData[row][1];
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 231 */     item.setToolTipText(LangConversion.convert(11, this.tableData[row][1].toString()));
/*     */     
/* 233 */     if (item2 == null) {
/* 234 */       pnl.addLineRE(prompt.toString(), item);
/*     */     } else {
/* 236 */       pnl.addLineRE(prompt.toString(), item, item2);
/*     */     }
/* 238 */     this.components[row] = item;
/*     */   }
/*     */   
/*     */   private void setValue(int row, String value) {
/* 242 */     this.tableData[row][2] = value;
/*     */     
/* 244 */     String propertyName = this.tableData[row][0].toString();
/* 245 */     String oldValue = this.pgmParams.getProperty(propertyName);
/*     */     
/*     */ 
/* 248 */     if ((value == null) || ("".equals(value.trim()))) {
/* 249 */       String dflt = Parameters.getSecondayString(propertyName);
/* 250 */       if ((dflt == null) || ("".equals(dflt.trim()))) {
/* 251 */         this.pgmParams.remove(propertyName);
/* 252 */         if ((oldValue != null) && (!oldValue.trim().equals(""))) {
/* 253 */           this.pgmParams.propertiesChanged = true;
/*     */         }
/*     */       } else {
/* 256 */         this.pgmParams.setProperty(propertyName, "");
/* 257 */         this.pgmParams.propertiesChanged = true;
/*     */       }
/* 259 */     } else if ((oldValue == null) || (!oldValue.equals(value))) {
/* 260 */       this.pgmParams.setProperty(propertyName, value);
/* 261 */       this.pgmParams.propertiesChanged = true;
/*     */     }
/*     */   }
/*     */   
/*     */   private class TxtFld extends JTextField implements FocusListener
/*     */   {
/*     */     int fieldNo;
/*     */     
/*     */     private TxtFld(int fldNo)
/*     */     {
/* 271 */       this.fieldNo = fldNo;
/* 272 */       if (EditPropertiesPnl.this.tableData[this.fieldNo][2] == null) {
/* 273 */         super.setText("");
/*     */       } else {
/* 275 */         super.setText(EditPropertiesPnl.this.tableData[this.fieldNo][2].toString());
/*     */       }
/*     */       
/* 278 */       super.addFocusListener(this);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void focusLost(FocusEvent arg0)
/*     */     {
/* 287 */       EditPropertiesPnl.this.setValue(this.fieldNo, super.getText());
/*     */     }
/*     */     
/*     */ 
/*     */     public void focusGained(FocusEvent arg0) {}
/*     */   }
/*     */   
/*     */ 
/*     */   private class CharsetFld
/*     */     extends EditPropertiesPnl.TxtFld
/*     */   {
/*     */     final boolean singleByte;
/*     */     
/*     */     private CharsetFld(int fldNo, boolean singleByte)
/*     */     {
/* 302 */       super(fldNo, null);
/* 303 */       this.singleByte = singleByte;
/*     */     }
/*     */     
/*     */     public void focusLost(FocusEvent arg0)
/*     */     {
/* 308 */       String charset = super.getText();
/* 309 */       if (Charset.isSupported(charset)) {
/* 310 */         if ((this.singleByte) && (Conversion.isMultiByte(charset))) {
/* 311 */           ReOptionDialog.showMessageDialog(this, UtMessages.SINGLE_BYTE_FONT.get(charset));
/*     */         } else {
/* 313 */           super.focusLost(arg0);
/*     */         }
/*     */       } else {
/* 316 */         ReOptionDialog.showMessageDialog(this, UtMessages.INVALID_FONT.get(charset));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private class DateFld
/*     */     extends BasicGenericPopup
/*     */     implements FocusListener
/*     */   {
/*     */     int fieldNo;
/* 327 */     DatePopup popup = new DatePopup();
/*     */     
/*     */     private DateFld(int fldNo) {
/* 330 */       this.fieldNo = fldNo;
/* 331 */       if (EditPropertiesPnl.this.tableData[this.fieldNo][2] == null) {
/* 332 */         super.setText("");
/*     */       } else {
/* 334 */         super.setText(EditPropertiesPnl.this.tableData[this.fieldNo][2].toString());
/*     */       }
/*     */       
/* 337 */       setupBackground();
/*     */       
/*     */ 
/*     */ 
/* 341 */       getMinimumSize().setSize(getMinimumSize().getWidth(), Math.max(getMinimumSize().getWidth(), SwingUtils.NORMAL_FIELD_HEIGHT));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 347 */       super.setPopup(this.popup);
/* 348 */       super.addFocusListener(this);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void focusLost(FocusEvent arg0)
/*     */     {
/* 357 */       EditPropertiesPnl.this.setValue(this.fieldNo, super.getText());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void focusGained(FocusEvent arg0) {}
/*     */   }
/*     */   
/*     */ 
/*     */   private class IntFld
/*     */     extends EditPropertiesPnl.TxtFld
/*     */   {
/*     */     private IntFld(int row)
/*     */     {
/* 371 */       super(row, null);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void focusLost(FocusEvent arg0)
/*     */     {
/*     */       try
/*     */       {
/* 380 */         String s = super.getText().trim();
/* 381 */         Long.getLong(s);
/* 382 */         EditPropertiesPnl.this.setValue(this.fieldNo, s);
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*     */   }
/*     */   
/*     */   private class BoolFld extends JCheckBox implements FocusListener {
/*     */     int fieldNo;
/*     */     boolean defaultVal;
/*     */     
/*     */     private BoolFld(int fldNo) {
/* 393 */       Object val = EditPropertiesPnl.this.tableData[fldNo][2];
/* 394 */       this.fieldNo = fldNo;
/* 395 */       this.defaultVal = Parameters.isDefaultTrue(EditPropertiesPnl.this.tableData[this.fieldNo][0].toString());
/* 396 */       if ((val == null) || ("".equals(val.toString()))) {
/* 397 */         super.setSelected(this.defaultVal);
/*     */       } else {
/* 399 */         String s = val.toString().toUpperCase();
/* 400 */         if (s.startsWith("Y")) {
/* 401 */           super.setSelected(true);
/* 402 */         } else if (s.startsWith("N")) {
/* 403 */           super.setSelected(false);
/*     */         } else {
/* 405 */           super.setSelected(this.defaultVal);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 413 */       super.addFocusListener(this);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void focusLost(FocusEvent arg0)
/*     */     {
/* 422 */       if (super.isSelected() == this.defaultVal) {
/* 423 */         EditPropertiesPnl.this.setValue(this.fieldNo, null);
/* 424 */       } else if (super.isSelected()) {
/* 425 */         EditPropertiesPnl.this.setValue(this.fieldNo, "Y");
/*     */       } else {
/* 427 */         EditPropertiesPnl.this.setValue(this.fieldNo, "N");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void focusGained(FocusEvent arg0) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 440 */   private static File[] standardFiles = { new File(Parameters.expandVars("<reproperties>")), new File(Parameters.expandVars("<reproperties>.User")) };
/*     */   
/*     */ 
/*     */ 
/* 444 */   private static final IFileChooserWrapper cw = JRFileChooserWrapper.newChooser(null, standardFiles);
/*     */   
/*     */   private class ChooseFileName extends TreeComboFileSelect implements FocusListener {
/*     */     private int fieldNo;
/*     */     
/* 449 */     public ChooseFileName(int fldNo) { super(true, (List)null, EditPropertiesPnl.cw, Arrays.asList(EditPropertiesPnl.standardFiles));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 456 */       super.setExpandVars(true);
/* 457 */       this.fieldNo = fldNo;
/* 458 */       if (EditPropertiesPnl.this.tableData[this.fieldNo][2] == null) {
/* 459 */         super.setText("");
/*     */       } else {
/* 461 */         super.setText(EditPropertiesPnl.this.tableData[this.fieldNo][2].toString());
/*     */       }
/*     */       
/*     */ 
/* 465 */       super.addFcFocusListener(this);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void focusLost(FocusEvent arg0)
/*     */     {
/* 474 */       EditPropertiesPnl.this.setValue(this.fieldNo, super.getText());
/*     */     }
/*     */     
/*     */ 
/*     */     public void focusGained(FocusEvent arg0) {}
/*     */   }
/*     */   
/*     */ 
/*     */   private class Combo
/*     */     extends JComboBox
/*     */     implements FocusListener
/*     */   {
/*     */     private int fieldNo;
/*     */     
/*     */     public Combo(int fldNo)
/*     */     {
/* 490 */       Object o = EditPropertiesPnl.this.tableData[fldNo][2];
/* 491 */       String s = "";
/* 492 */       int idx = 0;
/* 493 */       String[][] items = (String[][])EditPropertiesPnl.this.tableData[fldNo][5];
/* 494 */       ComboStrOption[] options = new ComboStrOption[items.length + 1];
/* 495 */       this.fieldNo = fldNo;
/*     */       
/* 497 */       if (o != null) {
/* 498 */         s = o.toString();
/*     */       }
/*     */       
/* 501 */       options[0] = new ComboStrOption("", "", null);
/* 502 */       for (int i = 0; i < items.length; i++) {
/* 503 */         options[(i + 1)] = new ComboStrOption(items[i][0], items[i][1], null);
/*     */         
/* 505 */         if (s.equalsIgnoreCase(items[i][0])) {
/* 506 */           idx = i + 1;
/*     */         }
/*     */       }
/*     */       
/* 510 */       super.setModel(new DefaultComboBoxModel(options));
/*     */       
/* 512 */       super.setSelectedIndex(idx);
/*     */       
/* 514 */       super.addFocusListener(this);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void focusLost(FocusEvent arg0)
/*     */     {
/* 523 */       EditPropertiesPnl.this.setValue(this.fieldNo, (String)((ComboStrOption)super.getSelectedItem()).key);
/*     */     }
/*     */     
/*     */     public void focusGained(FocusEvent arg0) {}
/*     */   }
/*     */   
/*     */   public static class FetchSize
/*     */     extends JButton implements ActionListener
/*     */   {
/*     */     EditPropertiesPnl.TxtFld heightTxt;
/*     */     EditPropertiesPnl.TxtFld widthTxt;
/*     */     
/*     */     public FetchSize(EditPropertiesPnl.TxtFld height, EditPropertiesPnl.TxtFld width)
/*     */     {
/* 537 */       super();
/* 538 */       this.heightTxt = height;
/* 539 */       this.widthTxt = width;
/*     */       
/* 541 */       addActionListener(this);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void actionPerformed(ActionEvent arg0)
/*     */     {
/* 549 */       Dimension d = ReMainFrame.getMasterFrame().getSize();
/* 550 */       this.heightTxt.setText(String.valueOf(d.height));
/* 551 */       this.widthTxt.setText(String.valueOf(d.width));
/* 552 */       this.heightTxt.focusLost(null);
/* 553 */       this.widthTxt.focusLost(null);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/editProperties/EditPropertiesPnl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */