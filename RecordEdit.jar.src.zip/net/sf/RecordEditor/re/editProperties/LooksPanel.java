/*     */ package net.sf.RecordEditor.re.editProperties;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.FocusAdapter;
/*     */ import java.awt.event.FocusEvent;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JEditorPane;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LookAndFeel;
/*     */ import javax.swing.UIManager;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.JarFileSelect;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LooksPanel
/*     */   extends BasePanel
/*     */   implements ActionListener
/*     */ {
/*  36 */   private static final String PANEL_DESCRIPTION = LangConversion.convertId(2, "EditProperties_Looks", "<h1>Look and Feel</h1>In java you can plug in a look-and-feel module to format Screen. This screen lets you choose which Look-and-Feel to use.<br><b>Warning:</b> Independent Look-and-Feel modules can slow down response times and cause the <b>RecordEditor</b> to crash.<br><br>The following 2 sites list a number of <b>Look and Feel</b><ul compact><li><b>http://www.java2s.com/Product/Java/Swing/LookAndFeel.htm</b><li><b>http://www.java-tips.org/java-libraries/java-look-and-feel/</b></ul>The JGoodies Look-and-Feel (<b>http://www.jgoodies.com/freeware/libraries/looks/</b>)is popular");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String JGOODIES = "JGoodies provide a popular Look and Feel, <br>You may find the Jar <b>looks-<i>&lt;<i>version<i>&gt;.jar</b> is already on your system.<br>If not download it from <b>http://www.jgoodies.com/freeware/libraries/looks/</b> ";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String COMPIERE = "Compiere provide there look and feel at <b>http://www.compiere.org/looks/</b>";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String TONIC = "Tonic look and feel is available at<br><b>http://www.digitprop.com/p.php?page=toniclf&lang=eng</b>";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String OFFICE_LN_FS = "OfficeLnFs available at <b>http://sourceforge.net/projects/officelnfs/</b><br>only works on <i>Windows</i> and <i>Java 1.5</i> or latter. Looks to work well";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  61 */   private static final String[] LOOKS_OPTIONS = { "Default", "Java - System look and Feel", "Java - Metal", "Java - Windows", "Java - Mac", "JGoodies Plastic XP Look And Feel", "JGoodies Plastic 3D Look And Feel", "JGoodies Plastic Look And Feel", "JGoodies Windows Look And Feel", "Compiere", "OfficeLnFs - Office 2003", "OfficeLnFs - Office XP", "OfficeLnFs - Visual Studio 2005", "Tonic", "JTattoo", "Liquid", "PGS", "Infonode", "Nimbus", "RecordEditor Default", "Other" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int NUMBER_OF_JAVA_LOOKS = 5;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  89 */   private int otherOptions = 0;
/*     */   
/*  91 */   private String[] looksDescriptions = { "Default Java Look and Feel", "Builtin System Look and Feel: " + UIManager.getSystemLookAndFeelClassName(), "Builtin Java Metal Look and Feel", "Builtin Java Windows", "Builtin Java Mac", "JGoodies provide a popular Look and Feel, <br>You may find the Jar <b>looks-<i>&lt;<i>version<i>&gt;.jar</b> is already on your system.<br>If not download it from <b>http://www.jgoodies.com/freeware/libraries/looks/</b> ", "JGoodies provide a popular Look and Feel, <br>You may find the Jar <b>looks-<i>&lt;<i>version<i>&gt;.jar</b> is already on your system.<br>If not download it from <b>http://www.jgoodies.com/freeware/libraries/looks/</b> ", "JGoodies provide a popular Look and Feel, <br>You may find the Jar <b>looks-<i>&lt;<i>version<i>&gt;.jar</b> is already on your system.<br>If not download it from <b>http://www.jgoodies.com/freeware/libraries/looks/</b> ", "JGoodies provide a popular Look and Feel, <br>You may find the Jar <b>looks-<i>&lt;<i>version<i>&gt;.jar</b> is already on your system.<br>If not download it from <b>http://www.jgoodies.com/freeware/libraries/looks/</b> ", "Compiere provide there look and feel at <b>http://www.compiere.org/looks/</b>", "OfficeLnFs available at <b>http://sourceforge.net/projects/officelnfs/</b><br>only works on <i>Windows</i> and <i>Java 1.5</i> or latter. Looks to work well", "OfficeLnFs available at <b>http://sourceforge.net/projects/officelnfs/</b><br>only works on <i>Windows</i> and <i>Java 1.5</i> or latter. Looks to work well", "OfficeLnFs available at <b>http://sourceforge.net/projects/officelnfs/</b><br>only works on <i>Windows</i> and <i>Java 1.5</i> or latter. Looks to work well", "Tonic look and feel is available at<br><b>http://www.digitprop.com/p.php?page=toniclf&lang=eng</b>", "JTattoo not my taste but seems fast<br>see <b>http://www.jtattoo.net/</b>", "Liquid Look and Feel<br>See <b>https://liquidlnf.dev.java.net/</b>", "pgs<br>See <b>https://pgslookandfeel.dev.java.net/</b>", "Infonode many commercial java packages use it<br/>see <b>http://www.infonode.net</b>", "Nimbus", "RecordEditor Default (Windows - Windows; other wise Nimbus)", "Other Look and Feel, remember to fill in the <b>class name</b>" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 111 */   private String[] looksClasses = { "", "", "javax.swing.plaf.metal.MetalLookAndFeel", "com.sun.java.swing.plaf.windows.WindowsLookAndFeel", "com.sun.java.swing.plaf.mac.MacLookAndFeel", "com.jgoodies.plaf.plastic.PlasticXPLookAndFeel", "com.jgoodies.plaf.plastic.Plastic3DLookAndFeel", "com.jgoodies.plaf.plastic.PlasticLookAndFeel", "com.jgoodies.plaf.windows.ExtWindowsLookAndFeel", "org.compiere.plaf.CompiereLookAndFeel", "org.fife.plaf.Office2003.Office2003LookAndFeel", "org.fife.plaf.OfficeXP.OfficeXPLookAndFeel", "org.fife.plaf.VisualStudio2005.VisualStudio2005LookAndFeel", "com.digitprop.tonic.TonicLookAndFeel", "com.jtattoo.plaf.smart.SmartLookAndFeel", "com.birosoft.liquid.LiquidLookAndFeel", "com.pagosoft.plaf.PgsLookAndFeel", "net.infonode.gui.laf.InfoNodeLookAndFeel", "Nimbus", "RecordEditor_Default", "" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 136 */   private JEditorPane tips = new JEditorPane("text/html", PANEL_DESCRIPTION);
/*     */   
/* 138 */   private JComboBox looks = new JComboBox();
/* 139 */   private JTextField className = new JTextField();
/* 140 */   private JarFileSelect jarName = new JarFileSelect(true, null);
/* 141 */   private JEditorPane description = new JEditorPane("text/html", "");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private EditParams pgmParams;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public LooksPanel(EditParams params)
/*     */   {
/* 153 */     this.pgmParams = params;
/*     */     
/* 155 */     init_100_ScreenFields();
/* 156 */     init_200_ScreenBuild();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_100_ScreenFields()
/*     */   {
/* 166 */     FocusAdapter focusMgr = new FocusAdapter() {
/*     */       public void focusLost(FocusEvent e) {
/* 168 */         LooksPanel.this.setParameters();
/*     */       }
/*     */       
/* 171 */     };
/* 172 */     init_110_BuildLooksComb();
/* 173 */     this.looks.setSelectedIndex(0);
/*     */     try {
/* 175 */       int idx = Integer.parseInt(this.pgmParams.getProperty("LooksClassIndex"));
/*     */       
/* 177 */       this.looks.setSelectedIndex(idx);
/*     */     }
/*     */     catch (Exception e) {}
/* 180 */     this.className.setText(this.pgmParams.getProperty("LooksClassName"));
/* 181 */     this.jarName.setText(this.pgmParams.looksJar);
/*     */     
/* 183 */     setOptions();
/*     */     
/*     */ 
/* 186 */     this.looks.addActionListener(this);
/* 187 */     this.looks.addFocusListener(focusMgr);
/* 188 */     this.className.addFocusListener(focusMgr);
/* 189 */     this.jarName.addFcFocusListener(focusMgr);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_110_BuildLooksComb()
/*     */   {
/* 198 */     this.looks.addItem(LOOKS_OPTIONS[0]);
/* 199 */     this.looks.addItem(LOOKS_OPTIONS[1]);
/* 200 */     int j = 2;
/* 201 */     for (int i = 2; i < LOOKS_OPTIONS.length; i++) {
/* 202 */       if ((i >= 5) || (isAvailableLookAndFeel(this.looksClasses[i])))
/*     */       {
/* 204 */         this.looks.addItem(LOOKS_OPTIONS[i]);
/* 205 */         this.looksDescriptions[j] = this.looksDescriptions[i];
/* 206 */         this.looksClasses[j] = this.looksClasses[i];
/* 207 */         j++;
/*     */       }
/*     */     }
/* 210 */     this.otherOptions = (j - 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_200_ScreenBuild()
/*     */   {
/* 219 */     setNameComponents(true);
/*     */     
/* 221 */     addComponentRE(1, 5, CommonCode.TIP_HEIGHT, BasePanel.GAP2, 2, 2, this.tips);
/*     */     
/*     */ 
/*     */ 
/* 225 */     addLineRE("Look and Feel", this.looks);
/* 226 */     setGapRE(BasePanel.GAP1);
/*     */     
/* 228 */     addLineRE("Look and Feel Class Name", this.className);
/* 229 */     addLineRE("Jar File", this.jarName);
/* 230 */     setGapRE(BasePanel.GAP3);
/*     */     
/* 232 */     addComponentRE(1, 5, CommonCode.TIP_HEIGHT, BasePanel.GAP1, 2, 2, new JScrollPane(this.description));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void actionPerformed(ActionEvent e)
/*     */   {
/* 243 */     if (e.getSource() == this.looks) {
/* 244 */       setOptions();
/* 245 */       setParameters();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setOptions()
/*     */   {
/* 255 */     int idx = this.looks.getSelectedIndex();
/*     */     
/* 257 */     this.className.setEnabled(idx == this.otherOptions);
/* 258 */     this.jarName.setEnabled(idx > 0);
/*     */     
/* 260 */     if (idx < this.otherOptions) {
/* 261 */       this.className.setText(this.looksClasses[idx]);
/*     */     }
/*     */     
/* 264 */     this.description.setText(this.looksDescriptions[idx]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setParameters()
/*     */   {
/* 273 */     this.pgmParams.setProperty("LooksClassIndex", Integer.toString(this.looks.getSelectedIndex()));
/*     */     
/*     */ 
/* 276 */     this.pgmParams.setProperty("LooksClassName", this.className.getText());
/*     */     
/* 278 */     this.pgmParams.looksJar = this.jarName.getText();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isAvailableLookAndFeel(String laf)
/*     */   {
/*     */     try
/*     */     {
/* 291 */       LookAndFeel newLAF = (LookAndFeel)Class.forName(laf).newInstance();
/* 292 */       if (newLAF != null) {
/* 293 */         return newLAF.isSupportedLookAndFeel();
/*     */       }
/*     */     }
/*     */     catch (Exception e) {}
/* 297 */     return false;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/editProperties/LooksPanel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */