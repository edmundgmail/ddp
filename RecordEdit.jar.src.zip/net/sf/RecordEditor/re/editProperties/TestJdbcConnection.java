/*     */ package net.sf.RecordEditor.re.editProperties;
/*     */ 
/*     */ import java.awt.Container;
/*     */ import java.sql.Connection;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextArea;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TestJdbcConnection
/*     */ {
/*  28 */   private static final int SCREEN_WIDTH = SwingUtils.STANDARD_FONT_WIDTH * 55;
/*  29 */   private static final int SCREEN_HEIGHT = SwingUtils.STANDARD_FONT_HEIGHT * 17;
/*     */   
/*     */   private String jdbcSourceName;
/*     */   
/*     */   private String jdbcDriver;
/*     */   private String jdbcSource;
/*     */   private String jdbcUser;
/*     */   private String jdbcPassword;
/*     */   private String jdbcJar;
/*  38 */   private JFrame frame = new JFrame();
/*  39 */   private JTextArea message = new JTextArea();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void testConnection(String sourceName, String driver, String source, String user, String password, String jarName)
/*     */   {
/*  58 */     this.jdbcSourceName = sourceName;
/*  59 */     this.jdbcDriver = driver;
/*  60 */     this.jdbcSource = Common.fixVars(source);
/*  61 */     this.jdbcUser = user;
/*  62 */     this.jdbcPassword = password;
/*  63 */     this.jdbcJar = jarName;
/*     */     
/*  65 */     init_200_TestConnection();
/*  66 */     init_300_Screen();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_200_TestConnection()
/*     */   {
/*  75 */     String common = "\n\n   Source: " + this.jdbcSource + "\n     User: " + this.jdbcUser + "\n Password: " + this.jdbcPassword;
/*     */     
/*     */     try
/*     */     {
/*  79 */       Connection dbConnection = CommonCode.getConnection(this.jdbcSourceName, this.jdbcDriver, this.jdbcSource, this.jdbcUser, this.jdbcPassword, this.jdbcJar);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  86 */       dbConnection.close();
/*     */       
/*  88 */       this.message.setText(LangConversion.convert("Connection succesfull to") + " " + this.jdbcSourceName + common);
/*     */     }
/*     */     catch (Exception e) {
/*  91 */       this.message.setText(LangConversion.convert("Error Connecting to the Database:") + e.getMessage() + common);
/*  92 */       Common.logMsg("Source: " + this.jdbcSource, null);
/*  93 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_300_Screen()
/*     */   {
/* 103 */     this.frame.getContentPane().add(new JScrollPane(this.message));
/* 104 */     this.frame.pack();
/* 105 */     this.frame.setBounds(1, 1, SCREEN_WIDTH, SCREEN_HEIGHT);
/* 106 */     this.frame.setVisible(true);
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/editProperties/TestJdbcConnection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */