/*     */ package net.sf.RecordEditor.re.editProperties;
/*     */ 
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import java.sql.Connection;
/*     */ import java.sql.Driver;
/*     */ import java.sql.DriverManager;
/*     */ import java.util.Properties;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CommonCode
/*     */ {
/*  29 */   public static final int TIP_HEIGHT = SwingUtils.TIP_HEIGHT;
/*  30 */   public static final String SYSTEM_JAR_FILE = Parameters.getSytemJarFileDirectory() + Common.FILE_SEPERATOR + "SystemJars.txt";
/*     */   
/*     */ 
/*  33 */   public static final String SYSTEM_JDBC_JAR_FILE = Parameters.getSytemJarFileDirectory() + Common.FILE_SEPERATOR + "SystemJdbcJars.txt";
/*     */   
/*     */ 
/*  36 */   public static final String USER_JAR_FILE = Parameters.getUserJarFileDirectory() + "UserJars.txt";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final void renameFile(String fileName)
/*     */   {
/*  60 */     Parameters.renameFile(fileName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static Connection getConnection(String sourceName, String driver, String source, String user, String password, String jarName)
/*     */     throws Exception
/*     */   {
/*  86 */     Connection dbConnection = null;
/*     */     
/*  88 */     if ((jarName == null) || ("".equals(jarName.trim()))) {
/*  89 */       Class.forName(driver);
/*     */     } else {
/*  91 */       URL[] urls = { new URL("file:" + Parameters.expandVars(jarName)) };
/*  92 */       URLClassLoader urlLoader = new URLClassLoader(urls);
/*  93 */       Driver d = (Driver)Class.forName(driver, true, urlLoader).newInstance();
/*     */       
/*  95 */       Properties p = new Properties();
/*     */       
/*  97 */       p.setProperty("user", user);
/*  98 */       p.setProperty("password", password);
/*  99 */       return d.connect(source, p);
/*     */     }
/*     */     
/* 102 */     if ((user == null) || ("".equals(user))) {
/* 103 */       dbConnection = DriverManager.getConnection(source);
/*     */     } else {
/* 105 */       dbConnection = DriverManager.getConnection(source, user, password);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 110 */     return dbConnection;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/editProperties/CommonCode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */