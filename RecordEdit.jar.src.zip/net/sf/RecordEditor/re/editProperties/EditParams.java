/*     */ package net.sf.RecordEditor.re.editProperties;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.FileReader;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.io.Writer;
/*     */ import java.util.Properties;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JTextArea;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.msg.UtMessages;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMsgId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class EditParams
/*     */ {
/*     */   private static final String LOOKS_PREFIX = "looks";
/*     */   private static final String ICON_PREFIX = "icon";
/*     */   protected Properties properties;
/*  42 */   protected boolean propertiesChanged = false;
/*  43 */   protected JTextArea msgFld = new JTextArea("");
/*     */   
/*  45 */   protected JarGroup jdbcJars = new JarGroup();
/*  46 */   protected JarGroup systemJars = new JarGroup();
/*  47 */   protected JarGroup optionalJars = new JarGroup();
/*  48 */   protected JarGroup userJars = new JarGroup();
/*  49 */   protected JarGroup xsltJars = new JarGroup();
/*     */   
/*  51 */   protected String looksJar = "";
/*  52 */   protected String iconJar = "";
/*     */   
/*     */ 
/*     */ 
/*     */   private String lastLang;
/*     */   
/*     */ 
/*     */ 
/*     */   private String lastLangDir;
/*     */   
/*     */ 
/*     */ 
/*     */   protected EditParams()
/*     */   {
/*  66 */     this.properties = Parameters.readProperties();
/*  67 */     System.out.println("Read Properties !!! " + (this.properties == null));
/*  68 */     if (this.properties == null) {
/*  69 */       this.properties = new Properties();
/*     */     }
/*  71 */     this.lastLang = fix(this.properties.getProperty("Language"));
/*  72 */     this.lastLangDir = fix(this.properties.getProperty("LangDirectory"));
/*     */     
/*  74 */     init_100_LoadJars();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_100_LoadJars()
/*     */   {
/*  82 */     init_110_LoadJars(CommonCode.SYSTEM_JAR_FILE, true, true);
/*  83 */     init_110_LoadJars(CommonCode.SYSTEM_JDBC_JAR_FILE, false, true);
/*  84 */     init_110_LoadJars(CommonCode.USER_JAR_FILE, false, false);
/*     */   }
/*     */   
/*     */   private void init_110_LoadJars(String jarFile, boolean required, boolean system) {
/*     */     try {
/*  89 */       FileReader inReader = new FileReader(jarFile);
/*     */       
/*  91 */       BufferedReader in = new BufferedReader(inReader);
/*     */       
/*     */       try
/*     */       {
/*     */         String jar;
/*  96 */         while ((jar = in.readLine()) != null) {
/*  97 */           if (!jar.trim().startsWith("#")) {
/*  98 */             String type = "";
/*  99 */             int j; if ((j = jar.indexOf('\t')) >= 0) {
/* 100 */               type = jar.substring(0, j);
/* 101 */               jar = jar.substring(j + 1);
/*     */             }
/* 103 */             init_111_StoreJar(type, jar, system);
/*     */           }
/*     */         }
/*     */       } finally {
/* 107 */         in.close();
/*     */       }
/*     */     } catch (Exception e) {
/* 110 */       if (required) {
/* 111 */         e.printStackTrace();
/* 112 */         this.msgFld.setText(e.getMessage());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_111_StoreJar(String type, String jar, boolean system)
/*     */   {
/* 125 */     String typeLC = type.toLowerCase();
/*     */     
/*     */ 
/* 128 */     if (system) {
/* 129 */       if (typeLC.startsWith("velocity")) {
/* 130 */         this.systemJars.add(type, jar, "This jar holds part of Velocity (a template engine for java). ");
/* 131 */       } else if (typeLC.startsWith("stax")) {
/* 132 */         this.systemJars.add(type, jar, "This is the Streaming XML API Jar (StAX)");
/* 133 */       } else if (typeLC.startsWith("zdate")) {
/* 134 */         this.systemJars.add(type, jar, "This jar holds the date field code.");
/* 135 */       } else if (typeLC.startsWith("jibx")) {
/* 136 */         this.systemJars.add(type, jar, "Holds XML interface code");
/* 137 */       } else if (typeLC.startsWith("jlibdiff")) {
/* 138 */         this.systemJars.add(type, jar, "Holds Compare library code");
/* 139 */       } else if (typeLC.startsWith("chardet")) {
/* 140 */         this.systemJars.add(type, jar, "Holds Charset Determining library");
/* 141 */       } else if (typeLC.startsWith("cb2xml")) {
/* 142 */         this.systemJars.add(type, jar, "This jar converts Cobol Copybooks from XML, its used when importing Cobol copybooks into the record editor");
/*     */       }
/* 144 */       else if (typeLC.startsWith("flags")) {
/* 145 */         this.systemJars.add(type, jar, "Holds Country Flags (for use with language selection)");
/*     */       } else {
/* 147 */         this.systemJars.add(type, jar, "");
/*     */       }
/* 149 */     } else if (typeLC.startsWith("jdbc")) {
/* 150 */       this.jdbcJars.add(type, jar, "");
/* 151 */     } else if (typeLC.startsWith("xslt")) {
/* 152 */       this.xsltJars.add("xslt" + (this.xsltJars.count + 1), jar, "Xslt Jar");
/* 153 */     } else if (typeLC.startsWith("optional")) {
/* 154 */       this.optionalJars.add(type, jar, "");
/* 155 */     } else if (typeLC.startsWith("user")) {
/* 156 */       this.userJars.add(type, jar, "");
/* 157 */     } else if (typeLC.startsWith("looks")) {
/* 158 */       this.looksJar = jar;
/* 159 */     } else if (typeLC.startsWith("icon")) {
/* 160 */       this.iconJar = jar;
/*     */     } else {
/* 162 */       this.userJars.add(type, jar, "");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeJarFiles()
/*     */   {
/* 171 */     w1100_writeOneJarFile(CommonCode.USER_JAR_FILE, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void w1100_writeOneJarFile(String filename, boolean full)
/*     */   {
/*     */     try
/*     */     {
/* 183 */       CommonCode.renameFile(filename);
/* 184 */       Writer w = new FileWriter(filename);
/* 185 */       BufferedWriter writer = new BufferedWriter(w);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 190 */       w1110_writeOneJarGroup(writer, this.jdbcJars, true);
/*     */       
/* 192 */       w1110_writeOneJarGroup(writer, this.userJars, true);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 200 */       w1110_writeOneJarGroup(writer, this.xsltJars, true);
/* 201 */       if (full) {
/* 202 */         w1110_writeOneJarGroup(writer, this.optionalJars, full);
/*     */       }
/*     */       
/* 205 */       w1120_writeSingleJar(writer, "looks", this.looksJar);
/* 206 */       w1120_writeSingleJar(writer, "icon", this.iconJar);
/*     */       
/* 208 */       writer.close();
/*     */     } catch (Exception e) {
/* 210 */       e.printStackTrace();
/* 211 */       this.msgFld.setText(e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void w1110_writeOneJarGroup(BufferedWriter writer, JarGroup jars, boolean full)
/*     */     throws IOException
/*     */   {
/* 226 */     for (int i = 0; i < jars.jars.length; i++) {
/* 227 */       if (jars.jars[i] != null) {
/* 228 */         if (jars.jars[i][0] == null) {
/* 229 */           jars.jars[i][0] = "";
/*     */         }
/* 231 */         if (jars.jars[i][1] == null) {
/* 232 */           jars.jars[i][1] = "";
/*     */         }
/* 234 */         if ((!"".equals(jars.jars[i][1])) && ((full) || (jars.jars[i][1].indexOf("cb2xml") < 0)))
/*     */         {
/* 236 */           writer.write(jars.jars[i][0] + "\t" + jars.jars[i][1]);
/* 237 */           writer.newLine();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void w1120_writeSingleJar(BufferedWriter writer, String prefix, String jar)
/*     */     throws IOException
/*     */   {
/* 254 */     if (!"".equals(jar)) {
/* 255 */       writer.write(prefix + "\t" + jar);
/* 256 */       writer.newLine();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void writeProperties()
/*     */   {
/* 267 */     String lang = fix(this.properties.getProperty("Language"));
/* 268 */     String langDir = fix(this.properties.getProperty("LangDirectory"));
/*     */     try {
/* 270 */       CommonCode.renameFile(Parameters.getPropertyFileName());
/* 271 */       this.properties.store(new FileOutputStream(Parameters.getPropertyFileName()), "RecordEditor");
/*     */       
/*     */ 
/* 274 */       Parameters.setProperties(this.properties);
/*     */       
/* 276 */       if ((!this.lastLang.equals(lang)) || (!this.lastLangDir.equals(langDir)))
/*     */       {
/*     */ 
/* 279 */         this.lastLang = lang;
/* 280 */         this.lastLangDir = langDir;
/* 281 */         if ((lang == null) || ("".equals(lang))) {
/* 282 */           lang = "English";
/*     */         }
/* 284 */         LangConversion.setConversion();
/*     */         
/* 286 */         String t = "";
/* 287 */         if (LangConversion.isPoTrans()) {
/* 288 */           t = UtMessages.LANGUAGE_WARNING.get();
/* 289 */           if ("#".equals(t)) {
/* 290 */             t = "";
/*     */           }
/*     */         }
/* 293 */         String s = UtMessages.LANG_RESTART.get(lang) + "\n\n" + t;
/* 294 */         JOptionPane.showMessageDialog(null, s);
/*     */       }
/*     */     } catch (Exception e) {
/* 297 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */   private String fix(String s) {
/* 302 */     if (s == null) return "";
/* 303 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getProperty(String key)
/*     */   {
/* 311 */     return this.properties.getProperty(key);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getProperty(String key, String defaultValue)
/*     */   {
/* 320 */     return this.properties.getProperty(key, defaultValue);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object setProperty(String key, String value)
/*     */   {
/* 329 */     return this.properties.setProperty(key, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object remove(Object key)
/*     */   {
/* 337 */     return this.properties.remove(key);
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/editProperties/EditParams.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */