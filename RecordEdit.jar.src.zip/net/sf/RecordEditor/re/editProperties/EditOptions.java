/*     */ package net.sf.RecordEditor.re.editProperties;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.io.PrintStream;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JEditorPane;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTabbedPane;
/*     */ import javax.swing.JToolBar;
/*     */ import net.sf.JRecord.Common.Conversion;
/*     */ import net.sf.JRecord.Common.Conversion.HoldEbcidicFlag;
/*     */ import net.sf.JRecord.External.CopybookWriterManager;
/*     */ import net.sf.JRecord.IO.LineIOProvider;
/*     */ import net.sf.JRecord.Numeric.ConversionManager;
/*     */ import net.sf.RecordEditor.re.util.CopybookLoaderFactoryDB;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.lang.ReAbstractAction;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions.FileNameOptWithDefault;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions.InternalBoolOption;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMainFrame;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.ComboBoxs.EnglishStrModel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EditOptions
/*     */ {
/*  57 */   private static final int PROGRAM_DESCRIPTION_HEIGHT = Math.min(SwingUtils.NORMAL_FIELD_HEIGHT * 21, Toolkit.getDefaultToolkit().getScreenSize().height * 3 / 5);
/*     */   
/*     */ 
/*     */ 
/*  61 */   private EditParams params = new EditParams();
/*     */   
/*  63 */   private JFrame frame = new JFrame("Record Editor Options Editor");
/*     */   
/*     */   private JEditorPane programDescription;
/*  66 */   private JTabbedPane mainTabbed = new JTabbedPane();
/*  67 */   private JTabbedPane propertiesTabbed = new JTabbedPane();
/*  68 */   private JTabbedPane otherTabbed = new JTabbedPane();
/*  69 */   private JTabbedPane textTabbed = new JTabbedPane();
/*  70 */   private JTabbedPane xmlTabbed = new JTabbedPane();
/*  71 */   private JTabbedPane jdbcTabbed = new JTabbedPane();
/*  72 */   private JTabbedPane jarsTabbed = new JTabbedPane();
/*  73 */   private JTabbedPane userTabbed = new JTabbedPane();
/*  74 */   private JTabbedPane looksTabbed = new JTabbedPane();
/*     */   
/*     */ 
/*  77 */   private AbstractAction saveBtn = new ReAbstractAction("Save", 2)
/*     */   {
/*     */     public void actionPerformed(ActionEvent e) {
/*  80 */       EditOptions.this.save();
/*  81 */       EditOptions.this.params.writeProperties();
/*  82 */       EditOptions.this.params.writeJarFiles();
/*     */     }
/*     */   };
/*     */   
/*  86 */   private String description = LangConversion.convertId(2, "EditProps_PnlDescription", "<h2>RecordEditor (" + Common.currentVersion() + ") Properties Editor</h2>" + "This program lets you edit the <b>RecordEditor (" + Common.currentVersion() + ") </b> properties files " + "and jar files." + "<br>There is little validation, so be very careful what changes you make." + "<br>Many changes will not take affect until the next time" + "the <b>RecordEditor</b> / <b>Layout Editor</b> is run again." + "<br><br>There are 5 basic tab types in the program: " + "<table border=\"1\" cellpadding=\"3\">" + "<tr><TD><b>Properties</b></td>" + "<td>Lets you update system properties like " + "<b>Screen Position, Directories, Other Options, Wizard Option and Big File Options</b></td></tr>" + "<tr><td><b>Xml</b></td><td>Xml Xslt properties / jars " + "<tr><td><b>Jars</b></td><td>These options let you update " + "the various JAR (java libraries) used by the <b>RecordEditor</b>." + "<br>The only time you should need to do this " + "is if you are adding your own code to the <b>RecordEditor</b> or installing Velocity.</td></tr>" + "<tr><td><b>Extensions</b></td><td>These option let you define your own Types, formats to " + "the <b>RecordEditor</b>.</td></tr>" + "<tr><td><b>Looks</b></td><td>This option lets you define the look and feel of the RecordEditor</td</tr>" + "</table>" + "<br/><b>Files being updated are:</b><br/><pre>" + "System       Jars File={0}" + "<br>System JDBC  Jars File={1}" + "<br>  User       Jars File={2}" + "<br>       Properties file={3}</pre>", new Object[] { CommonCode.SYSTEM_JAR_FILE, CommonCode.SYSTEM_JDBC_JAR_FILE, CommonCode.USER_JAR_FILE, Parameters.getPropertyFileName() });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 126 */   private String directoryDescription = LangConversion.convertId(2, "EditProps_Directories", "<h2>Directories</h2>The properties on this panel are for the various directories used by the <b>RecordEditor</b>");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 133 */   private Object[][] directoryParams1 = { { "HelpDir", "Directory holding the help files", null, EditPropertiesPnl.FLD_DIR, null }, { "DefaultFileDirectory", "Directory where the Editor Starts in (if no file specified)", null, EditPropertiesPnl.FLD_DIR, null }, { "DefaultCobolDirectory", "The Directory where Cobol Copybooks are stored.", null, EditPropertiesPnl.FLD_DIR, null }, { "VelocityTemplateDirectory", "Velocity Template directory (Editor)", "<reproperties>/User/VelocityTemplates/File/*", EditPropertiesPnl.FLD_DIR, null }, { "VelocityCopybookDirectory", "Velocity Template directory (Copybooks)", "<reproperties>/User/VelocityTemplates/Copybook/*", EditPropertiesPnl.FLD_DIR, null }, { "CopybookDirectory", "Directory to read / write file copybooks to", null, EditPropertiesPnl.FLD_DIR, null }, { "XsltTemplateDirectory", "Xslt Template directory (Editor)", Parameters.encodeVars(Common.OPTIONS.DEFAULT_XSLT_DIRECTORY.get()), EditPropertiesPnl.FLD_DIR, null }, { "ExportScriptDirectory", "Export Script directory", Parameters.encodeVars(Common.OPTIONS.DEFAULT_SCRIPT_EXPORT_DIRECTORY.defaultValue), EditPropertiesPnl.FLD_DIR, null }, { "ScriptDirectory", "Extension Script directory", Parameters.encodeVars(Common.OPTIONS.DEFAULT_SCRIPT_DIRECTORY.get()), EditPropertiesPnl.FLD_DIR, null } };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 146 */   private Object[][] directoryParams2 = { { "CompareSaveDirectory", "Compare Save Directory", null, EditPropertiesPnl.FLD_DIR, null }, { "FilterSaveDirectory", "Filter Save Directory", null, EditPropertiesPnl.FLD_DIR, null }, { "FieldSaveDirectory", "Fields used Save Directory", null, EditPropertiesPnl.FLD_DIR, null }, { "SortTreeSaveDirectory", "Sort Tree Save Directory", null, EditPropertiesPnl.FLD_DIR, null }, { "RecordTreeSaveDirectory", "Record Tree Save Directory", null, EditPropertiesPnl.FLD_DIR, null }, { "CopySaveDirectory", "Copy Save Directory", "<reproperties>/User/Copy/*", EditPropertiesPnl.FLD_DIR, null }, { "LayoutExportDirectory", "Layout Velocity Export Directory", "<reproperties>/User/LayoutExport/*", EditPropertiesPnl.FLD_DIR, null } };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 156 */   private String testDescription = LangConversion.convertId(2, "EditProps_Test", "<h2>Test Properties</h2>The options on this screen are used in Testing the Editor.");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 162 */   private Object[][] testParams = { { "TestMode", "Weather we are running automated Tests (Marathon ?) or not", null, EditPropertiesPnl.FLD_BOOLEAN, "Test Mode" }, { "WarnBinFieldsAndDefault", "Warn the user if Binary-Fields and Structure=Default", null, EditPropertiesPnl.FLD_BOOLEAN, "Warn on Structure change" }, { "LoadFileInBackground", "Load File in Background thread", null, EditPropertiesPnl.FLD_BOOLEAN, "Load In background" }, { "NewTreeExpansion", "Use New Tree Expansion", null, EditPropertiesPnl.FLD_BOOLEAN, "Use New Tree Expansion" }, { "SearchAllFields", "Search: All Fields", null, EditPropertiesPnl.FLD_BOOLEAN, "On Search Screen default to \"All Fields\"" }, { "NameFields", "Add names to screen Components", null, EditPropertiesPnl.FLD_BOOLEAN, "Add names to JComponents for use by testing tools" }, { "LogText", "Keep a record of all Text Fields going through the Language section. This can be used to generate the language conversion file (GetText PO)", null, EditPropertiesPnl.FLD_BOOLEAN, "Record Text Fields" }, { "useAltFindName", "This option adds >> to the search button (on the find search screen) to better identifier it in testing", null, EditPropertiesPnl.FLD_BOOLEAN, "Rename Search btn" }, { "IncTypeName", "Include the type name on the record screen", null, EditPropertiesPnl.FLD_BOOLEAN, "Include Type Name on Record Screen" }, { "AddFileSearchBtn", "Add file search button to Open Screen", null, EditPropertiesPnl.FLD_BOOLEAN, "Add file search button to Open Screen" } };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 181 */   private String behaviourDescription = LangConversion.convertId(2, "EditProps_Behaviour", "<h2>Behavior Properties</h2>The options on this screen affect the behavior of the editor.<br/><b>Bring Log to the Front</b>: Wether the log file will be brought to the fron when data is written to it.<br/><b>Default to prefered</b>: Wether to use the prefered layout by default when editting<br/><b>Show all export panels</b>: Wether to show all export options or just the option selected<br/>");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 192 */   private String[][] EXTENDED_FILE_CHOOSER = { { "N", "Standard FileChooser" }, { "V", "Recent Pane visible Based on LAF" }, { "E", "Extended FileChooser" } };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 198 */   private Object[][] behaviourParams = { { "LogToFront", "Bring Log to the Front if Data is written to it", null, EditPropertiesPnl.FLD_BOOLEAN, "Bring log to Front" }, { "AsterixInFileName", "Allow the asterix ('*') character in file Names", null, EditPropertiesPnl.FLD_BOOLEAN, null }, { "PreferedAsDefault", "Default to prefered layout", null, EditPropertiesPnl.FLD_BOOLEAN, null }, { "AllExportOptions", "Show all export panels", null, EditPropertiesPnl.FLD_BOOLEAN, "Show all export panels on the export Screen" }, { "DeleteSelectedWithDelKey", "Delete Selected Rows using the delete key", null, EditPropertiesPnl.FLD_BOOLEAN, "Delete Selected rows with the delete key" }, { "WarnWithDelKey", "Warn the user before deleteing Selected Rows using the delete key", null, EditPropertiesPnl.FLD_BOOLEAN, "Warn when deleteing rows via delete key" }, { "UseFileWizard", "Use File Wizard when no Layout is known for the file", null, EditPropertiesPnl.FLD_BOOLEAN, "Use file Wizard" }, { "FlagMissingTranslations", "Highlight text for which there is no translation by adding a # to the start of the text", null, EditPropertiesPnl.FLD_BOOLEAN, "Highlight missing translations" }, { "SepWindows", "Create views in seperate windows instead of tabs on the file panel", null, EditPropertiesPnl.FLD_BOOLEAN, "Create Screens in seperate Windows" }, { "showRecordEditorTips", "Show RecordEditor Tips on program startup", null, EditPropertiesPnl.FLD_BOOLEAN, "Show RecordEditor Tips" }, { "EditRawText", "Allow the user to edit file as Raw Text ??", null, EditPropertiesPnl.FLD_BOOLEAN, "Allow Editting Raw Text" }, { "ShowFileChooserOptions", "Show File Options on Csv Open Screen", null, EditPropertiesPnl.FLD_BOOLEAN, "Show File Options on Csv Open" }, { "UseLastDir", "Open program using Last used Directory (instead of the default Directory)", null, EditPropertiesPnl.FLD_BOOLEAN, "Open in Last Directory" }, { "", "", null, EditPropertiesPnl.FLD_EMPTY, null }, { "FileChooserOpt", "Type of FileCooser to use: Normal, Extended, or choose based on Look and feel", null, EditPropertiesPnl.FLD_LIST, "File Chooser Type", this.EXTENDED_FILE_CHOOSER }, { "FileChooserCsvEdOpt", "Type of FileCooser to use: Normal, Extended, or choose based on Look and feel / screen size", null, EditPropertiesPnl.FLD_LIST, "File Chooser Type (Csv Editor)", this.EXTENDED_FILE_CHOOSER } };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 219 */   private String fileDescription = LangConversion.convertId(2, "EditProps_FileParams", "<h2>File Propertie 2s</h2>This panels lists various File related parameters.");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 225 */   private Object[][] fileParams = { { "UserInitilizeClass", "This User written class will be invoked when the <b>RecordEditor</b starts.", EditPropertiesPnl.FLD_TEXT, "User Init Class" }, { "InvalidFileChars", "Characters that are invalid in a file Name", null, EditPropertiesPnl.FLD_TEXT, null }, { "FileReplChar", "Char to Replace invalid Filename Chars", null, EditPropertiesPnl.FLD_TEXT, null }, { "DateFormat", "Date Format String eg dd/MM/yy or dd.MMM.yy. the field is case sensitive, it uses Java date Formatting", null, EditPropertiesPnl.FLD_DATE, "Date Format" }, { "SignificantCharInFiles.1", "Number of characters to use when looking up record layouts (small)", null, EditPropertiesPnl.FLD_INT, "Significant chars 1" }, { "SignificantCharInFiles.2", "Number of characters to use when looking up record layouts (medium)", null, EditPropertiesPnl.FLD_INT, "Significant chars 2" }, { "SignificantCharInFiles.3", "Number of characters to use when looking up record layouts (large)", null, EditPropertiesPnl.FLD_INT, "Significant chars 3" } };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 235 */   private String layoutWizardParamsDescription = LangConversion.convertId(2, "EditProps_WizardParams", "<h2>Layout Wizard Properties</h2>This panels holds various Field Search options used by the Layout Wizard");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 240 */   private Object[][] layoutWizardParams = { { "FsAutoRun", "Weather to Run the field search Automatically or not", null, EditPropertiesPnl.FLD_BOOLEAN, "Run the field search Automatically" }, { "FsMainframeZoned", "Look for Mainframe Zoned numeric fields", null, EditPropertiesPnl.FLD_BOOLEAN, null }, { "FsPcZoned", "Look for PC Zoned numeric fields (Cobol PIC 9 fields)", null, EditPropertiesPnl.FLD_BOOLEAN, null }, { "FsComp3", "Look for comp-3 fields", null, EditPropertiesPnl.FLD_BOOLEAN, null }, { "FsCompBigEndian", "Look for Big Endian Binary", null, EditPropertiesPnl.FLD_BOOLEAN, null }, { "FsCompLittleEndian", "Look for Little Endian Binary", null, EditPropertiesPnl.FLD_BOOLEAN, null } };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 250 */   private String bigModelDescription = LangConversion.convertId(2, "EditProps_BigFiles", "<h2>Big Model Properties</h2>This panels lists parameters for the \"Big File\" Data Models.<br\\>You can use these options to optimise the Read Time for very big files");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 268 */   private String[][] COMPRESS_OPTION = { { "N", "No" }, { "R", "Read" }, { "F", "Read (fast cpu)" }, { "S", "Space" }, { "Y", "Yes" } };
/* 269 */   private String[][] YNT_OPTION = { { "Y", "Yes" }, { "N", "No" }, { "T", "Test" } };
/* 270 */   private String[][] YNT_OPTION2 = { { "Y", "Mock" }, { "N", "No" }, { "T", "Yes" } };
/* 271 */   private Object[][] bigModelParams = { { "BigFilePercentage", "File Size to Memory Percent to Start using the Big-File-Model", null, EditPropertiesPnl.FLD_INT, "Big File Percentage" }, { "BigFileChunkSize", "Big-File-Model Memory Chunks (KB) default=1000", null, EditPropertiesPnl.FLD_INT, "Chunk Size (KB)" }, { "BigFileCompressOption", "Big-File-Model compress option (Default Read)", null, EditPropertiesPnl.FLD_LIST, "Compress Option", this.COMPRESS_OPTION }, { "BigFileFilterLimit", "Big-File Filter/Tree limit (thousands)", null, EditPropertiesPnl.FLD_INT, null }, { "BigFileDiskFlag", "Force Storing chunks on Disk (Used in Testing)", null, EditPropertiesPnl.FLD_LIST, "Storing chunks on Disk", this.YNT_OPTION2 }, { "UseOVerflow", "When space is tight, Try to store data in an overflow file ", null, EditPropertiesPnl.FLD_BOOLEAN, "Use Overflow file" }, { "BigFileUseFixedModel", "Use Fixed Length Model (Used in Testing)", null, EditPropertiesPnl.FLD_BOOLEAN, "Use Fixed Length Model" }, { "BigFileLargeVB", "Use Large VB Model (Default Yes)", null, EditPropertiesPnl.FLD_LIST, "Use Large VB Model", this.YNT_OPTION }, { "LoadFileInBackground", "Load File in Background thread", null, EditPropertiesPnl.FLD_BOOLEAN, "Load In background" } };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 283 */   private EditPropertiesPnl directoryPnl1 = new EditPropertiesPnl(this.params, this.directoryDescription, this.directoryParams1);
/*     */   
/* 285 */   private EditPropertiesPnl directoryPnl2 = new EditPropertiesPnl(this.params, this.directoryDescription, this.directoryParams2);
/*     */   
/* 287 */   private EditPropertiesPnl testPnl = new EditPropertiesPnl(this.params, this.testDescription, this.testParams);
/*     */   
/* 289 */   private EditPropertiesPnl behaviourPnl = new EditPropertiesPnl(this.params, this.behaviourDescription, this.behaviourParams);
/*     */   
/* 291 */   private EditPropertiesPnl file2Pnl = new EditPropertiesPnl(this.params, this.fileDescription, this.fileParams);
/*     */   
/* 293 */   private EditPropertiesPnl layoutWizardPnl = new EditPropertiesPnl(this.params, this.layoutWizardParamsDescription, this.layoutWizardParams);
/*     */   
/* 295 */   private EditPropertiesPnl bigModelPnl = new EditPropertiesPnl(this.params, this.bigModelDescription, this.bigModelParams);
/*     */   
/*     */ 
/* 298 */   private String specialCharsetDescription = LangConversion.convertId(2, "EditProps_BigFiles", "<h2>Special Character Sets</h2>There are several character sets that the <b>RecordEditor</b> needs to know:<ul><li>Binary fields only work correctly in single byte character-sets,<br/>So if the default character-set is multi-byte (say utf-8);<br/>The <b>RecordEditor</b> needs to know what character-set to use<br/>CP1252 is often a good choice.<li>If you transfer files from the mainframe to a PC/*nix machine<br>the <b>RecordEditor</b> needs to know the original mainframe character-set<br>to correctly translate Zoned decimal (Cobol s999 fields).</ul");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 314 */   private Object[][] specialCharsetParams = { { "defaultSingleByteCharset", "Single byte charater-set to be used for binary files when no character set is suppplied", null, EditPropertiesPnl.FLD_SINGLE_BYTE_CHARSET, "Default Single byte character set" }, { "useDefaultSingleByteCharset", "Controls wether default Characterset (above) is used when font=\"\" for all Layout's or only binary layouts", null, EditPropertiesPnl.FLD_BOOLEAN, "Alway use above charset when font=\"\"" }, { "defaultEbcidicCharset", "Default EBCDIC characterset", null, EditPropertiesPnl.FLD_CHARSET, "Default Ebcdic Character set" } };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 319 */   private Object[][] specialCharsetParams1 = { this.specialCharsetParams[2] };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 325 */   private String xsltDescription = LangConversion.convertId(2, "EditProps_Xslt", "<h2>Xslt Properties</h2>This panels let you specify XSLT related jars and the XSLT transform class<br>For Saxon or Xalan, you can just enter Saxon or Xalan, Or you can enter<pre>        net.sf.saxon.TransformerFactoryImpl\n    or  org.apache.xalan.processor.TransformerFactoryImpl</pre>");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 334 */   private Object[][] xsltParams = { { "XsltEngine", "Xslt Transform factory class", null, EditPropertiesPnl.FLD_TEXT, null } };
/*     */   
/*     */ 
/*     */ 
/* 338 */   private EditPropertiesPnl xsltPnl = new EditPropertiesPnl(this.params, this.xsltDescription, this.xsltParams);
/*     */   
/*     */ 
/* 341 */   private EditJarsPanel xsltJarsPnl = new EditJarsPanel(this.params, "EditProps_XsltJars", "<h2>Xslt Jars</h2>This panel lets you specify your XSLT jars", this.params.xsltJars, "xslt", true);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 349 */   private String csvDescription = LangConversion.convertId(2, "EditProps_CsvParams", "<h2>Csv Editor Properties</h2>This panels holds Csv-Editor specific options<br>");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 354 */   private Object[][] csvParams = { { "CsvSearchFixed", "Check for binary Fixed Width", null, EditPropertiesPnl.FLD_BOOLEAN, "Should the program check for binary Fixed Width Files ???" } };
/*     */   
/*     */ 
/*     */ 
/* 358 */   private EditPropertiesPnl csvPnl = new EditPropertiesPnl(this.params, this.csvDescription, this.csvParams);
/*     */   
/*     */ 
/* 361 */   private String poDescription = LangConversion.convertId(2, "EditProps_CsvParams", "<h2>GetText-Po Properties</h2>This panels holds GetText-PO editor specific options<br>");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 366 */   String[][] poChildPosOptions = { { "R", "Right" }, { "B", "Bottom" } };
/* 367 */   private Object[][] poParams = { { "PoChildPos", "Position of Child Screen", null, EditPropertiesPnl.FLD_LIST, null, this.poChildPosOptions }, { "PoFuzzyView", "Open Fuzzy / Blank View", null, EditPropertiesPnl.FLD_BOOLEAN, "Open a view containing Just the Fuzzy / Blank translations" } };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 373 */   private EditPropertiesPnl poPnl = new EditPropertiesPnl(this.params, this.poDescription, this.poParams);
/*     */   
/*     */ 
/* 376 */   private EditJdbcParamsPanel jdbcParamsPnl = new EditJdbcParamsPanel(this.params, this.params.jdbcJars);
/*     */   
/* 378 */   private EditJarsPanel jdbcPnl = new EditJarsPanel(this.params, "EditProps_JdbcJars", "<h2>JDBC Jars</h2>This panel lets you change the JDBC (Java Database Conectivity) Jars that are needed by the <b>RecordEditor</b>.<br><br>If you click on a row in the table, the fields at the bottom will be updated with the values from the selected row.<br>You can update values either using the fields at the bottom of the screen or directly into the table itself.", this.params.jdbcJars, "jdbc.", true);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 391 */   private EditJarsPanel systemPnl = new EditJarsPanel(this.params, "EditProps_Jars", "<h2>System Jars</h2>This panel lets you change the Jars supplied with the <b>RecordEditor</b> like cb2xml.<br>These jars are used by the <b>RecordEditor</b> but are written and maintained by other people", this.params.systemJars, "", false);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 400 */   private EditJarsPanel optionalPnl = new EditJarsPanel(this.params, "EditProps_OptionalJars", "<h2>Optional Jars</h2>This panel lets you specify your own jars. <br/>This could include User code or scripting languages (JRuby.jar, Jython.jar etc).", this.params.optionalJars, "optional.", true);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 408 */   private EditJarsPanel userPnl = new EditJarsPanel(this.params, "EditProps_UserJars", "<h2>User Jars</h2>This panel lets you specify your own jars <br>These jars will be used when the <b>RecordEditor</b starts. <br>When adding your own jars, <br>you should also invoke your own initialisation class via the <i>UserInitilizeClass</i> property on the other screen.", this.params.userJars, "User.", true);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 420 */   private static String jarsNote = LangConversion.convertId(2, "EditProps_JarsNote", "<b>Note:</b>You will also need to add the jar with your class to the <b>User Jars</b> tab.");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 425 */   private static String loaderDescription = LangConversion.convertId(2, "EditProps_CopyBook_Loaders", "<h2>Copybook Loaders</h2>This tab is for defining user written <b>Copybook Loader's</b> to the <b>RecordEditor</b>.<br>A <b>Copybook Loader's</b> is a Java Class that can load a copybook from a file into the <b>RecordEditor</b>.<br><br><b>Copybook Loader's</b> are used in <ul><li>Load Copybook function in the <b>LayoutEditor</b><li>Cobol Editor</ul><br>") + jarsNote;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 436 */   private static String pluginDescription = LangConversion.convertId(2, "EditProps_Plugin", "<h2>Plugins</h2>This tab is for defining user written <b>Functions</b> that will listed on the <br/><b>Plugin</b> Drop down menu in the   <b>RecordEditor</b>.<br> Local Functions must implement the Plugin interface");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 443 */   private static String optionDescription = LangConversion.convertId(2, "EditProps_DefaultOpts", "<h2>Default Options</h2>This Tab is for defining the default value for several Combo Box's used by the Package<br/><br/>Click on a row to change the default Value");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 449 */   private static final String[] LOADER_COLUMN_HEADINGS = { "Loader Name", "Loader Class" };
/* 450 */   private static final String[] LOADER_COLUMN_NAMES = { "CopybookLoaderName.", "CopybookloaderClass." };
/*     */   
/*     */ 
/* 453 */   private static final String[] PLUGIN_COLUMN_HEADINGS = { "Name", "Class Name", "Parameter" };
/* 454 */   private static final String[] PLUGIN_COLUMN_NAMES = { "LocalFuncName", "LocalFuncClass", "LocalFuncParam" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 460 */   private static String typeDescription = LangConversion.convertId(2, "EditProps_TypeDef", "<h2>Type Definition</h2>This tab for defining user written <b>Type's</b> to the <b>RecordEditor</b>.<br>A <b>Type's</b> is a Java Class that converts a fields between the external representation and the internal Java Representation.<br>Columns in the Table are <br><table><tr><td>Type Number</td><td>Unique number used to identify the type. It should be between {0} and {1}</td></tr><tr><td>Type Name</td><td>Name of the Type</td></tr><tr><td>Type Class</td><td>Java Type class.</td></tr><tr><td>Format Class</td><td>Class that implements table cell Formating. Leave blank if there is not one</td></tr></table><br>" + jarsNote, new Object[] { Integer.valueOf(1000), Integer.valueOf(1074) });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 480 */   private static String formatDescription = LangConversion.convertId(2, "EditProps_Format", "<h2>Format Definition</h2>This tab for defining user written <b>Format's</b> to the <b>RecordEditor</b>.<br><b>Format's</b> define TableCellRenders and TableCellEditors for a field.<br><br>You may want to use Format to edit Dates using a Date Popup");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 488 */   private static final String[] TYPE_COLUMN_HEADINGS = { "Type Number", "Type Name", "Type Class", "Format Class" };
/* 489 */   private static final String[] TYPE_COLUMN_NAMES = { "TypeNumber.", "TypeName.", "TypeClass.", "TypeFormat." };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 494 */   private static final String[] FORMAT_COLUMN_HEADINGS = { "Format Number", "Format Name", "Format Class" };
/* 495 */   private static final String[] FORMAT_COLUMN_NAMES = { "FormatNumber.", "FormatName.", "FormatClass." };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 500 */   private EditPropertiesTblPanel loadersPnl = new EditPropertiesTblPanel(this.params, loaderDescription, LOADER_COLUMN_NAMES, LOADER_COLUMN_HEADINGS, 20);
/*     */   
/*     */ 
/*     */ 
/* 504 */   private EditPropertiesTblPanel pluginPnl = new EditPropertiesTblPanel(this.params, pluginDescription, PLUGIN_COLUMN_NAMES, PLUGIN_COLUMN_HEADINGS, 32);
/*     */   
/*     */ 
/*     */ 
/* 508 */   private EditPropertiesTblPanel typePnl = new EditPropertiesTblPanel(this.params, typeDescription, TYPE_COLUMN_NAMES, TYPE_COLUMN_HEADINGS, 30);
/*     */   
/*     */ 
/*     */ 
/* 512 */   private EditPropertiesTblPanel formatPnl = new EditPropertiesTblPanel(this.params, formatDescription, FORMAT_COLUMN_NAMES, FORMAT_COLUMN_HEADINGS, 30);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 517 */   private static String[][] defaultDetails = { { "CopyBookReader", "The default copybook reader" }, { "CopyBookWriter", "The default copybook writer" }, { "DefaultDB", "The default Database to use" }, { "DefaultIO", "The default IO Routine to use" }, { "DefaultBin", "The default Binary Encoding" } };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 525 */   private String screenLocationDescription = LangConversion.convertId(2, "EditProps_ScreenLocation", "<h2>Program initial Size</h2>This screen controls the program size when it inially opens. The options are <b>Maximised</b>, <b>Last Size</b>,<br/><b>Space around Edges</b> and <b>Initial Size</b>.<br/>The <b>retrieve screen size</b> button at the bottom of the screen.retrieves the current program Size.");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 541 */   private String applId = getApplId();
/*     */   
/*     */ 
/* 544 */   private static final String[][] SIZE_OPTION = { { String.valueOf('M'), "Maximized" }, { String.valueOf('L'), "Last Screen Size" }, { String.valueOf('S'), "Use Space around parameters" }, { String.valueOf('D'), "Height, Width Below" } };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 551 */   private Object[][] screenLocationParams = { { "ScreenSizeOpt", "Program Initial Size", null, EditPropertiesPnl.FLD_LIST, "Size of the program when it opens", SIZE_OPTION }, { "spaceAtBottomOfScreen", "Space to be left at the bottom of the screen.", null, EditPropertiesPnl.FLD_INT, null }, { "spaceAtTopOfScreen", "Space to be left at the top of the screen.", null, EditPropertiesPnl.FLD_INT, null }, { "spaceAtLeftOfScreen", "Space to be left at the left of the screen.", null, EditPropertiesPnl.FLD_INT, null }, { "spaceAtRightOfScreen", "Space to be left at the Right of the screen.", null, EditPropertiesPnl.FLD_INT, null }, { "", "", null, EditPropertiesPnl.FLD_EMPTY, null }, { this.applId + "ScreenStartHeight", "Screen Height", null, EditPropertiesPnl.FLD_INT, null }, { this.applId + "ScreenStartWidth", "Screen Width", null, EditPropertiesPnl.FLD_INT, null }, { "", "", null, EditPropertiesPnl.FLD_RETRIEVE_SIZE, null } };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 563 */   private EditPropertiesPnl screenPosPnl = new EditPropertiesPnl(this.params, this.screenLocationDescription, this.screenLocationParams);
/*     */   
/*     */ 
/*     */ 
/* 567 */   private static EnglishStrModel[] defaultModels = new EnglishStrModel[5];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   static
/*     */   {
/* 576 */     defaultModels[0] = DefaultOptModel.newModel(CopybookLoaderFactoryDB.getInstance());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 587 */     defaultModels[1] = DefaultOptModel.newModel(CopybookWriterManager.getInstance());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 597 */     defaultModels[2] = DefaultOptModel.newModel(Common.getSourceId());
/*     */     
/* 599 */     defaultModels[3] = DefaultOptModel.newModel(LineIOProvider.getInstance());
/* 600 */     defaultModels[4] = DefaultOptModel.newModel(ConversionManager.getInstance());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final void setDefaultDetails(String[][] theDefaultDetails, EnglishStrModel[] theDefaultModels)
/*     */   {
/* 622 */     defaultDetails = theDefaultDetails;
/* 623 */     defaultModels = theDefaultModels;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EditOptions(boolean terminateOnExit, boolean includeJDBC, boolean includeWizardOptions)
/*     */   {
/* 640 */     this(terminateOnExit, includeJDBC, includeWizardOptions, true);
/*     */   }
/*     */   
/*     */ 
/* 644 */   private EditPropertiesPnl[] propertiesPnl = { this.directoryPnl1, this.directoryPnl2, this.testPnl, this.behaviourPnl, this.file2Pnl, this.layoutWizardPnl, this.bigModelPnl, this.xsltPnl, this.csvPnl, this.poPnl, this.screenPosPnl };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EditOptions(boolean terminateOnExit, boolean includeJDBC, boolean includeWizardOptions, boolean display)
/*     */   {
/* 667 */     init_100_ScreenFields(terminateOnExit);
/* 668 */     init_200_Screen(includeJDBC, includeWizardOptions);
/* 669 */     if (display) {
/* 670 */       displayScreen();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_100_ScreenFields(boolean terminateOnExit)
/*     */   {
/* 683 */     this.saveBtn.putValue("ShortDescription", LangConversion.convert(2, "Save ..."));
/*     */     
/* 685 */     this.programDescription = new JEditorPane("text/html", this.description);
/* 686 */     this.xsltJarsPnl.setInitialValues();
/* 687 */     this.jdbcPnl.setInitialValues();
/* 688 */     this.systemPnl.setInitialValues();
/* 689 */     this.optionalPnl.setInitialValues();
/* 690 */     this.userPnl.setInitialValues();
/*     */     
/* 692 */     this.jdbcParamsPnl.buildJarCombo();
/*     */     
/* 694 */     this.mainTabbed.setTabPlacement(2);
/*     */     
/* 696 */     if (terminateOnExit) {
/* 697 */       this.frame.setDefaultCloseOperation(3);
/*     */     } else {
/* 699 */       this.frame.setDefaultCloseOperation(2);
/*     */     }
/*     */     
/* 702 */     this.frame.addWindowListener(new WindowAdapter() {
/*     */       public void windowClosing(WindowEvent e) {
/* 704 */         EditOptions.this.save();
/* 705 */         EditOptions.this.params.writeProperties();
/* 706 */         EditOptions.this.params.writeJarFiles();
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_200_Screen(boolean includeJDBC, boolean includeWizardOptions)
/*     */   {
/* 716 */     JPanel pnl = new JPanel();
/* 717 */     JPanel topPnl = new JPanel();
/* 718 */     JToolBar toolBar = new JToolBar();
/*     */     
/* 720 */     String[][] defaultDescription = (String[][])defaultDetails.clone();
/*     */     
/* 722 */     for (int i = 0; i < defaultDescription.length; i++) {
/* 723 */       defaultDescription[i][1] = LangConversion.convert(2, defaultDescription[i][1]);
/*     */     }
/*     */     
/* 726 */     toolBar.add(this.saveBtn);
/*     */     
/* 728 */     SwingUtils.addTab(this.propertiesTabbed, "EditOpts_Properties", "Directories", this.directoryPnl1);
/* 729 */     SwingUtils.addTab(this.propertiesTabbed, "EditOpts_Properties", "Save Directories", this.directoryPnl2);
/* 730 */     SwingUtils.addTab(this.propertiesTabbed, "EditOpts_Properties", "Test", this.testPnl);
/* 731 */     SwingUtils.addTab(this.propertiesTabbed, "EditOpts_Properties", "Behaviour", this.behaviourPnl);
/* 732 */     SwingUtils.addTab(this.propertiesTabbed, "EditOpts_Properties", "File Options", this.file2Pnl);
/*     */     
/* 734 */     if (includeWizardOptions) {
/* 735 */       SwingUtils.addTab(this.propertiesTabbed, "EditOpts_Properties", "Layout Wizard", this.layoutWizardPnl);
/*     */     }
/* 737 */     SwingUtils.addTab(this.propertiesTabbed, "EditOpts_Properties", "Big Model", this.bigModelPnl);
/*     */     
/* 739 */     SwingUtils.addTab(this.propertiesTabbed, "EditOpts_Properties", "Defaults", new EditDefaults(this.params, optionDescription, defaultDescription, defaultModels));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 744 */     Object[][] scParams = this.specialCharsetParams1;
/* 745 */     if (Conversion.DEFAULT_CHARSET_DETAILS.isMultiByte) {
/* 746 */       scParams = this.specialCharsetParams;
/*     */     }
/* 748 */     SwingUtils.addTab(this.otherTabbed, "Special_Chars", "Special Fonts", new EditPropertiesPnl(this.params, this.specialCharsetDescription, scParams));
/*     */     
/* 750 */     SwingUtils.addTab(this.textTabbed, "EditOpts_EditColors", "Field Colors", EditColors.getFieldColorEditor(this.frame, this.params));
/* 751 */     SwingUtils.addTab(this.textTabbed, "EditOpts_EditColors", "Special Colors", EditColors.getSpecialColorEditor(this.frame, this.params));
/*     */     
/* 753 */     SwingUtils.addTab(this.xmlTabbed, "EditOpts_Xml", "Xslt Options", this.xsltPnl);
/* 754 */     SwingUtils.addTab(this.xmlTabbed, "EditOpts_Xml", "Xslt Jars", this.xsltJarsPnl);
/*     */     
/* 756 */     SwingUtils.addTab(this.jarsTabbed, "EditOpts_Jars", "System Jars", this.systemPnl);
/* 757 */     SwingUtils.addTab(this.jarsTabbed, "EditOpts_Jars", "Optional Jars", this.optionalPnl);
/*     */     
/* 759 */     SwingUtils.addTab(this.userTabbed, "EditOpts_User", "User Jars", this.userPnl);
/* 760 */     SwingUtils.addTab(this.userTabbed, "EditOpts_User", "Copybook Loaders", this.loadersPnl);
/* 761 */     SwingUtils.addTab(this.userTabbed, "EditOpts_User", "Plugins", this.pluginPnl);
/* 762 */     SwingUtils.addTab(this.userTabbed, "EditOpts_User", "User Types", this.typePnl);
/* 763 */     SwingUtils.addTab(this.userTabbed, "EditOpts_User", "User Formats", this.formatPnl);
/* 764 */     if (includeJDBC) {
/* 765 */       SwingUtils.addTab(this.propertiesTabbed, "EditOpts_User", "Date Types", new EditDateTypes(this.params));
/*     */     }
/*     */     
/* 768 */     SwingUtils.addTab(this.looksTabbed, "EditOpts_User", "Look and Feel", new LooksPanel(this.params));
/* 769 */     SwingUtils.addTab(this.looksTabbed, "EditOpts_User", "Icons", new EditIcons(this.params));
/* 770 */     SwingUtils.addTab(this.looksTabbed, "EditOpts_User", "Initial Program Size", this.screenPosPnl);
/*     */     
/* 772 */     addMainTab("Description", init_310_Screen());
/* 773 */     addMainTab("Properties", this.propertiesTabbed);
/*     */     
/* 775 */     System.out.println("Application Id: " + getApplId());
/* 776 */     if ("csv".equals(getApplId())) {
/* 777 */       addMainTab("Csv Options", this.csvPnl);
/*     */     }
/* 779 */     if (Common.OPTIONS.getTextPoPresent.isSelected()) {
/* 780 */       addMainTab("Special Formats", this.poPnl);
/*     */     }
/*     */     
/* 783 */     addMainTab("Other", this.otherTabbed);
/* 784 */     addMainTab("Text", this.textTabbed);
/*     */     
/* 786 */     addMainTab("Xml", this.xmlTabbed);
/* 787 */     if (includeJDBC) {
/* 788 */       SwingUtils.addTab(this.jdbcTabbed, "EditOpts_JDBC", "JDBC Jars", this.jdbcPnl);
/* 789 */       SwingUtils.addTab(this.jdbcTabbed, "EditOpts_JDBC", "JDBC Properties", this.jdbcParamsPnl);
/* 790 */       addMainTab("JDBC Parameters", this.jdbcTabbed);
/*     */     }
/* 792 */     addMainTab("Language", new EditLanguage(this.params));
/* 793 */     addMainTab("Jars", this.jarsTabbed);
/* 794 */     addMainTab("Extensions", this.userTabbed);
/* 795 */     addMainTab("Looks", this.looksTabbed);
/*     */     
/* 797 */     topPnl.setLayout(new BorderLayout());
/* 798 */     topPnl.add("North", toolBar);
/*     */     
/* 800 */     topPnl.add("South", new JPanel());
/* 801 */     pnl.setLayout(new BorderLayout());
/* 802 */     pnl.add("North", topPnl);
/* 803 */     pnl.add("Center", this.mainTabbed);
/* 804 */     pnl.add("South", this.params.msgFld);
/* 805 */     this.frame.getContentPane().add(pnl);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addMainTab(String name, JComponent item)
/*     */   {
/* 816 */     item.setName(name + "Tab");
/* 817 */     SwingUtils.addTab(this.mainTabbed, "EdProps_MainTab_" + name, name, item);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void save()
/*     */   {
/* 836 */     for (EditPropertiesPnl p : this.propertiesPnl) {
/* 837 */       p.save();
/*     */     }
/*     */   }
/*     */   
/*     */   public EditParams getParams() {
/* 842 */     return this.params;
/*     */   }
/*     */   
/*     */   public final void displayScreen()
/*     */   {
/* 847 */     Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
/* 848 */     this.frame.pack();
/* 849 */     this.frame.setBounds(this.frame.getY(), this.frame.getX(), Math.min(this.frame.getWidth(), screenSize.width - Common.getSpaceAtRightOfScreen() - this.frame.getY()), Math.min(this.frame.getHeight(), screenSize.height - Common.getSpaceAtBottomOfScreen() - SwingUtils.NORMAL_FIELD_HEIGHT * 2 - this.frame.getX()));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 858 */     this.frame.setVisible(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(String name, JComponent component)
/*     */   {
/* 867 */     SwingUtils.addTab(this.mainTabbed, "EditOptions_MainTab", name, component);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private BasePanel init_310_Screen()
/*     */   {
/* 875 */     BasePanel pnl = new BasePanel();
/*     */     
/* 877 */     pnl.addComponentRE(1, 5, PROGRAM_DESCRIPTION_HEIGHT, BasePanel.GAP1, 2, 2, new JScrollPane(this.programDescription));
/*     */     
/*     */ 
/*     */ 
/* 881 */     return pnl;
/*     */   }
/*     */   
/*     */   private static String getApplId()
/*     */   {
/* 886 */     String ret = "";
/* 887 */     ReMainFrame f = ReMainFrame.getMasterFrame();
/* 888 */     if (f != null) {
/* 889 */       ret = f.getApplicationId();
/*     */     }
/*     */     
/* 892 */     return ret;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/editProperties/EditOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */