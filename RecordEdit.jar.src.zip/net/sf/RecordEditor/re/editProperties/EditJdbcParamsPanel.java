/*     */ package net.sf.RecordEditor.re.editProperties;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.FocusAdapter;
/*     */ import java.awt.event.FocusEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JEditorPane;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextField;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.lang.ReAbstractAction;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EditJdbcParamsPanel
/*     */   extends BasePanel
/*     */ {
/*  41 */   private static final int TABLE_HEIGHT = SwingUtils.NORMAL_FIELD_HEIGHT * 14 / 2;
/*     */   
/*     */   private static final int JDBC_TABLE_SIZE = 16;
/*     */   
/*     */   private PropertiesTableModel model;
/*     */   private JEditorPane tips;
/*     */   private JTable paramTbl;
/*  48 */   private JTextField sourceName = new JTextField();
/*  49 */   private JTextField driver = new JTextField();
/*  50 */   private JTextField source = new JTextField();
/*  51 */   private JTextField readOnly = new JTextField();
/*  52 */   private JTextField user = new JTextField();
/*  53 */   private JTextField password = new JTextField();
/*     */   
/*     */ 
/*     */   private ReAbstractAction startAction;
/*     */   
/*  58 */   private JComboBox jdbcJarsCombo = new JComboBox();
/*     */   
/*  60 */   private JTextField[] screenFields = { this.sourceName, this.driver, this.source, this.readOnly, this.user, this.password };
/*     */   
/*     */ 
/*     */   private int currentRow;
/*     */   
/*     */ 
/*  66 */   private static final String[] COL_HEADERS = { "Source Name", "Driver", "Source", "Read Only Source", " User ", "Password", "Commit", "Checkpoint", "Expand variables (Y/N)", "Auto Close Connections", "Drop ; from SQL statements" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  71 */   private static final String[] COL_NAMES = { "SourceName.", "Driver.", "Source.", "ReadOnly.", "User.", "Password.", "Commit.", "Checkpoint.", "ExpandVars.", "AutoClose.", "DBDropSemi." };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  78 */   private String description = LangConversion.convertId(2, "EditProps_JDBC_Params", "<h1>JDBC Parameters</h1>These parameters Control the Database connection that the <b>RecordEditor</b> uses<br>to connect to the RecordLayout Database (where all the Record Layouts are stored).<br>If you click on a row in the table, the fields at the bottom will be updated with the values from the selected row.<br>You can update values either using the fields at the bottom of the screen or directly into the table itself.");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private EditParams pgmParams;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JarGroup jdbcJarHolder;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EditJdbcParamsPanel(EditParams params, JarGroup jdbcJars)
/*     */   {
/* 101 */     this.pgmParams = params;
/* 102 */     this.jdbcJarHolder = jdbcJars;
/*     */     
/* 104 */     init_100_ScreenFields();
/* 105 */     init_200_Screen();
/*     */     
/* 107 */     g200_SetScreenFields(0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_100_ScreenFields()
/*     */   {
/* 116 */     this.tips = new JEditorPane("text/html", this.description);
/* 117 */     this.model = new PropertiesTableModel(this.pgmParams, COL_NAMES, COL_HEADERS, "PropsEd_JDBC", 16) {
/*     */       public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
/* 119 */         super.setValueAt(aValue, rowIndex, columnIndex);
/* 120 */         if ((aValue != null) && (columnIndex < EditJdbcParamsPanel.this.screenFields.length)) {
/* 121 */           EditJdbcParamsPanel.this.screenFields[columnIndex].setText(aValue.toString());
/*     */         }
/*     */       }
/* 124 */     };
/* 125 */     this.paramTbl = new JTable(this.model);
/* 126 */     this.paramTbl.setAutoResizeMode(0);
/* 127 */     Common.calcColumnWidths(this.paramTbl, 1);
/*     */     
/* 129 */     this.paramTbl.addMouseListener(new MouseAdapter() {
/*     */       public void mousePressed(MouseEvent m) {
/* 131 */         EditJdbcParamsPanel.this.g200_SetScreenFields(EditJdbcParamsPanel.this.paramTbl.getSelectedRow());
/*     */       }
/*     */     });
/*     */     
/* 135 */     for (int i = 0; i < this.screenFields.length; i++) {
/* 136 */       new FieldAddapter(this.screenFields[i], i);
/*     */     }
/*     */     
/* 139 */     this.startAction = new ReAbstractAction("Test Driver") {
/*     */       public void actionPerformed(ActionEvent e) {
/* 141 */         EditJdbcParamsPanel.this.g500_TestConnection();
/*     */       }
/*     */       
/* 144 */     };
/* 145 */     buildJarCombo();
/* 146 */     this.jdbcJarsCombo.addFocusListener(new FocusAdapter() {
/*     */       public void focusGained(FocusEvent e) {
/* 148 */         EditJdbcParamsPanel.this.buildJarCombo();
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_200_Screen()
/*     */   {
/* 162 */     addComponentRE(1, 5, TABLE_HEIGHT, BasePanel.GAP0, 2, 2, this.tips);
/*     */     
/*     */ 
/*     */ 
/* 166 */     addComponentRE(1, 5, TABLE_HEIGHT, BasePanel.GAP0, 2, 2, new JScrollPane(this.paramTbl));
/*     */     
/*     */ 
/*     */ 
/* 170 */     addLineRE("Source Name", this.sourceName);
/* 171 */     addLineRE("Driver", this.driver);
/* 172 */     addLineRE("Source", this.source);
/*     */     
/*     */ 
/* 175 */     addLineRE("User", this.user);
/* 176 */     addLineRE("Password", this.password);
/*     */     
/* 178 */     addLineRE("JDBC JAR", this.jdbcJarsCombo, new JButton(this.startAction));
/* 179 */     setGapRE(BasePanel.GAP0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void g200_SetScreenFields(int row)
/*     */   {
/* 203 */     this.currentRow = row;
/*     */     
/* 205 */     for (int i = 0; i < this.screenFields.length; i++) {
/* 206 */       this.screenFields[i].setText(this.model.getStringValueAt(row, i));
/*     */     }
/* 208 */     buildJarCombo();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void g500_TestConnection()
/*     */   {
/* 234 */     String jarName = null;
/* 235 */     if (this.jdbcJarsCombo.getSelectedItem() != null) {
/* 236 */       jarName = this.jdbcJarsCombo.getSelectedItem().toString();
/*     */     }
/*     */     
/* 239 */     TestJdbcConnection connectionTester = new TestJdbcConnection();
/*     */     
/* 241 */     connectionTester.testConnection(this.sourceName.getText(), this.driver.getText(), this.source.getText(), this.user.getText(), this.password.getText(), jarName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void buildJarCombo()
/*     */   {
/* 256 */     this.jdbcJarsCombo.removeAllItems();
/* 257 */     this.jdbcJarsCombo.addItem("");
/*     */     try
/*     */     {
/* 260 */       for (int i = 0; i < this.jdbcJarHolder.jars.length; i++) {
/* 261 */         String name = this.jdbcJarHolder.jars[i][1];
/* 262 */         if ((name != null) && (!"".equals(name.trim()))) {
/* 263 */           this.jdbcJarsCombo.addItem(name);
/*     */         }
/*     */       }
/*     */     } catch (Exception e) {
/* 267 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private class FieldAddapter
/*     */     extends FocusAdapter
/*     */   {
/*     */     private JTextField fld;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private int col;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public FieldAddapter(JTextField field, int column)
/*     */     {
/* 290 */       this.fld = field;
/* 291 */       this.col = column;
/*     */       
/* 293 */       field.addFocusListener(this);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void focusLost(FocusEvent e)
/*     */     {
/* 310 */       EditJdbcParamsPanel.this.pgmParams.setProperty(EditJdbcParamsPanel.this.model.getCellName(EditJdbcParamsPanel.this.currentRow, this.col), this.fld.getText());
/* 311 */       EditJdbcParamsPanel.this.model.fireTableRowsUpdated(EditJdbcParamsPanel.this.currentRow, EditJdbcParamsPanel.this.currentRow);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/editProperties/EditJdbcParamsPanel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */