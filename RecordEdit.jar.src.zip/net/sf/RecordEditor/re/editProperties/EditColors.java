/*     */ package net.sf.RecordEditor.re.editProperties;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.event.FocusAdapter;
/*     */ import java.awt.event.FocusEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.io.PrintStream;
/*     */ import javax.swing.JEditorPane;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.table.AbstractTableModel;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import javax.swing.table.TableModel;
/*     */ import net.sf.RecordEditor.utils.msg.UtMessages;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMsgId;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.color.ColorGroup;
/*     */ import net.sf.RecordEditor.utils.swing.color.ColorGroupManager;
/*     */ import net.sf.RecordEditor.utils.swing.color.IColorGroup;
/*     */ 
/*     */ public class EditColors
/*     */   extends BaseHelpPanel
/*     */ {
/*  30 */   private static String[] SPECIAL_OPTIONS = { "Field Delimiter" };
/*     */   
/*     */   private static final int MAXIMUM_NUMBER_OF_ROWS = 120;
/*     */   private JEditorPane tipsPane;
/*  34 */   private JTextField numberOfColorsTxt = new JTextField();
/*  35 */   private colorTblMdl mdl = new colorTblMdl(null);
/*  36 */   private JTable colorTbl = new JTable(this.mdl);
/*     */   
/*  38 */   private String[] rowNames = new String[120];
/*  39 */   private Color[] colors = new Color[120];
/*  40 */   private Color[] backgroundColors = new Color[120];
/*  41 */   private int rowCount = 8;
/*     */   
/*  43 */   private static final String[] COLUMNS = { "Field", "Color" };
/*     */   private final String propertiesName;
/*     */   private final EditParams params;
/*     */   private final IColorGroup currentColors;
/*     */   private final IColorGroup defaultColors;
/*     */   private final boolean canChangeSize;
/*     */   private final JFrame parent;
/*     */   
/*     */   public static EditColors getFieldColorEditor(JFrame parent, EditParams params)
/*     */   {
/*  53 */     return new EditColors(parent, UtMessages.FIELD_COLOR_TIP.get(), params, "fieldColors.", true, ColorGroupManager.getInstance().get(0), ColorGroup.getDefaultStandardColors(), null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static EditColors getSpecialColorEditor(JFrame parent, EditParams params)
/*     */   {
/*  66 */     return new EditColors(parent, UtMessages.SPECIAL_COLOR_TIP.get(), params, "specialColors.", true, ColorGroupManager.getInstance().get(1), ColorGroup.getDefaultSpecialColors(), SPECIAL_OPTIONS);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private EditColors(JFrame parent, String tip, EditParams params, String propertiesName, boolean canChangeSize, IColorGroup currentColors, IColorGroup defaultColors, String[] rowNames)
/*     */   {
/*  81 */     this.propertiesName = propertiesName;
/*  82 */     this.params = params;
/*  83 */     this.currentColors = currentColors;
/*  84 */     this.defaultColors = defaultColors;
/*  85 */     this.canChangeSize = canChangeSize;
/*  86 */     this.parent = parent;
/*     */     
/*  88 */     this.tipsPane = new JEditorPane("text/html", tip);
/*     */     
/*  90 */     init_100_setup(rowNames);
/*  91 */     init_200_layoutScreen();
/*  92 */     init_300_Finalise();
/*     */   }
/*     */   
/*     */   private void init_100_setup(String[] paramRowNames) {
/*  96 */     this.rowCount = this.currentColors.size();
/*     */     
/*  98 */     for (int i = this.rowCount; i < 120; i++) {
/*  99 */       this.rowNames[i] = "";
/* 100 */       this.colors[i] = Color.BLACK;
/* 101 */       this.backgroundColors[i] = null;
/*     */     }
/*     */     
/* 104 */     for (int i = 0; i < this.rowCount; i++) {
/* 105 */       this.rowNames[i] = "";
/* 106 */       this.colors[i] = this.currentColors.getForegroundColor(i);
/* 107 */       this.backgroundColors[i] = this.currentColors.getBackgroundColor(i);
/*     */     }
/*     */     
/* 110 */     if (paramRowNames == null) {
/* 111 */       for (int i = 0; i < 120; i++) {
/* 112 */         this.rowNames[i] = ("Field " + i);
/*     */       }
/*     */     } else {
/* 115 */       System.arraycopy(paramRowNames, 0, this.rowNames, 0, paramRowNames.length);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void init_200_layoutScreen()
/*     */   {
/* 122 */     addComponentRE(1, 5, CommonCode.TIP_HEIGHT, BasePanel.GAP1, 2, 2, this.tipsPane);
/*     */     
/*     */ 
/*     */ 
/* 126 */     if (this.canChangeSize) {
/* 127 */       addLineRE("Number of Field Colors", this.numberOfColorsTxt);
/*     */     }
/*     */     
/* 130 */     addComponentRE(1, 5, -2.0D, BasePanel.GAP2, 2, 2, this.colorTbl);
/*     */   }
/*     */   
/*     */   private void init_300_Finalise()
/*     */   {
/* 135 */     TableColumnModel columnModel = this.colorTbl.getColumnModel();
/*     */     
/* 137 */     columnModel.getColumn(1).setCellRenderer(new ColorRendor(null));
/*     */     
/* 139 */     this.numberOfColorsTxt.setText(Integer.toString(this.rowCount));
/* 140 */     this.numberOfColorsTxt.addFocusListener(new FocusAdapter() {
/*     */       public void focusLost(FocusEvent e) {
/*     */         try {
/* 143 */           int newRowCount = Math.min(120, Integer.parseInt(EditColors.this.numberOfColorsTxt.getText()));
/* 144 */           String key = EditColors.this.propertiesName + "count";
/* 145 */           EditColors.this.rowCount = newRowCount;
/* 146 */           if (newRowCount == EditColors.this.defaultColors.size()) {
/* 147 */             EditColors.this.params.remove(key);
/*     */           } else {
/* 149 */             EditColors.this.mdl.fireTableDataChanged();
/* 150 */             EditColors.this.params.setProperty(key, Integer.toString(EditColors.this.rowCount));
/*     */           }
/*     */         }
/*     */         catch (NumberFormatException e1) {
/* 154 */           e1.printStackTrace();
/*     */         }
/*     */         
/*     */       }
/* 158 */     });
/* 159 */     this.colorTbl.addMouseListener(new MouseAdapter() {
/*     */       public void mouseReleased(MouseEvent e) {
/* 161 */         EditColors.this.showStyle(EditColors.this.colorTbl.rowAtPoint(e.getPoint()));
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   private void showStyle(int row) {
/* 167 */     if ((row < 0) || (row >= this.rowCount)) { return;
/*     */     }
/* 169 */     StyleEdit se = new StyleEdit(this.parent, this.colorTbl, this.rowNames[row], this.colors[row], this.backgroundColors[row]);
/*     */     
/* 171 */     Color newColor = se.getColor();
/* 172 */     Color newBackground = se.getBackgroundColor();
/* 173 */     boolean changed = false;
/*     */     
/* 175 */     if (newColor != this.colors[row]) {
/* 176 */       saveColor(this.propertiesName + row, this.defaultColors.getForegroundColor(row), newColor);
/* 177 */       this.colors[row] = newColor;
/* 178 */       changed = true;
/*     */     }
/*     */     
/* 181 */     if (newBackground != this.backgroundColors[row]) {
/* 182 */       saveColor(this.propertiesName + "back." + row, this.defaultColors.getBackgroundColor(row), newBackground);
/* 183 */       this.backgroundColors[row] = newBackground;
/* 184 */       changed = true;
/*     */     }
/*     */     
/* 187 */     if (changed) {
/* 188 */       this.params.writeProperties();
/* 189 */       this.mdl.fireTableDataChanged();
/*     */     }
/*     */   }
/*     */   
/*     */   private void saveColor(String key, Color oldColor, Color newColor)
/*     */   {
/* 195 */     if (newColor == oldColor) {
/* 196 */       this.params.remove(key);
/*     */     } else {
/* 198 */       String s = "null";
/* 199 */       if (newColor != null) {
/* 200 */         int c = newColor.getRGB();
/* 201 */         System.out.println("Color " + newColor.getRed() + " " + newColor.getGreen() + " " + newColor.getBlue() + " ");
/* 202 */         s = Integer.toString(c);
/*     */       }
/* 204 */       this.params.setProperty(key, s);
/*     */     }
/*     */   }
/*     */   
/*     */   private class colorTblMdl
/*     */     extends AbstractTableModel implements TableModel
/*     */   {
/*     */     private colorTblMdl() {}
/*     */     
/*     */     public int getRowCount()
/*     */     {
/* 215 */       return EditColors.this.rowCount;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getColumnCount()
/*     */     {
/* 223 */       return EditColors.COLUMNS.length;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Object getValueAt(int rowIndex, int columnIndex)
/*     */     {
/* 231 */       if (columnIndex == 0) {
/* 232 */         return EditColors.this.rowNames[rowIndex];
/*     */       }
/* 234 */       return "Hello World";
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getColumnName(int column)
/*     */     {
/* 242 */       return EditColors.COLUMNS[column];
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isCellEditable(int rowIndex, int columnIndex)
/*     */     {
/* 250 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */   private class ColorRendor
/*     */     extends JTextField implements TableCellRenderer
/*     */   {
/* 257 */     Color origBackGround = getBackground();
/*     */     
/*     */ 
/*     */ 
/*     */     private ColorRendor() {}
/*     */     
/*     */ 
/*     */     public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
/*     */     {
/* 266 */       String val = "";
/* 267 */       if (value != null) {
/* 268 */         val = value.toString();
/*     */       }
/*     */       
/* 271 */       setForeground(EditColors.this.colors[row]);
/*     */       
/* 273 */       if (EditColors.this.backgroundColors[row] == null) {
/* 274 */         setBackground(this.origBackGround);
/*     */       } else {
/* 276 */         setBackground(EditColors.this.backgroundColors[row]);
/*     */       }
/* 278 */       setText(val);
/* 279 */       return this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/editProperties/EditColors.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */