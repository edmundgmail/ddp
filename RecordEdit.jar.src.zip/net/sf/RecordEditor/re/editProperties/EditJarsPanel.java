/*     */ package net.sf.RecordEditor.re.editProperties;
/*     */ 
/*     */ import java.awt.event.FocusAdapter;
/*     */ import java.awt.event.FocusEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import javax.swing.JEditorPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.JarFileSelect;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EditJarsPanel
/*     */   extends BasePanel
/*     */ {
/*  38 */   private static final int TABLE_HEIGHT = SwingUtils.NORMAL_FIELD_HEIGHT * 15 / 2;
/*     */   
/*     */   private JEditorPane tips;
/*     */   private JarTblModel jarMdl;
/*     */   private JTable jarsTbl;
/*  43 */   private JTextField typeFld = new JTextField();
/*  44 */   private JarFileSelect jarFld = new JarFileSelect(true, null);
/*  45 */   private JTextArea descriptionFld = new JTextArea();
/*     */   
/*     */   private JarGroup jarsList;
/*     */   private String typeName;
/*  49 */   private static final String[] columnHeadings = LangConversion.convertColHeading("PropEd_Jars", new String[] { "Name", "Jar", "Description" });
/*     */   
/*     */   private boolean update;
/*     */   
/*  53 */   private int currentRow = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EditJarsPanel(EditParams params, String id, String description, JarGroup jars, String namePrefix, boolean updatePnl)
/*     */   {
/*  66 */     this.jarsList = jars;
/*  67 */     this.typeName = namePrefix;
/*  68 */     this.update = updatePnl;
/*     */     
/*  70 */     this.tips = new JEditorPane("text/html", LangConversion.convertId(2, id, description));
/*     */     
/*     */ 
/*     */ 
/*  74 */     init_100_ScreenFields();
/*  75 */     init_200_Screen();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_100_ScreenFields()
/*     */   {
/*  84 */     this.jarsTbl = new JTable();
/*  85 */     this.jarsTbl.addMouseListener(new MouseAdapter() {
/*     */       public void mousePressed(MouseEvent m) {
/*  87 */         EditJarsPanel.this.g100_SetFields(EditJarsPanel.this.jarsTbl.getSelectedRow());
/*     */       }
/*     */       
/*  90 */     });
/*  91 */     this.typeFld.setEditable((this.update) && ("".equals(this.typeName)));
/*  92 */     this.typeFld.addFocusListener(new FocusAdapter()
/*     */     {
/*     */       public void focusLost(FocusEvent e) {
/*  95 */         EditJarsPanel.this.jarsList.jars[EditJarsPanel.this.currentRow][0] = EditJarsPanel.this.typeFld.getText();
/*     */         
/*  97 */         EditJarsPanel.this.jarMdl.fireTableRowsUpdated(EditJarsPanel.this.currentRow, EditJarsPanel.this.currentRow);
/*     */       }
/*     */       
/* 100 */     });
/* 101 */     this.jarFld.addFcFocusListener(new FocusAdapter() {
/*     */       public void focusLost(FocusEvent e) {
/* 103 */         EditJarsPanel.this.jarsList.jars[EditJarsPanel.this.currentRow][1] = EditJarsPanel.this.jarFld.getText();
/*     */         
/* 105 */         EditJarsPanel.this.g200_checkForFixedTypeName(EditJarsPanel.this.currentRow);
/* 106 */         EditJarsPanel.this.jarMdl.fireTableRowsUpdated(EditJarsPanel.this.currentRow, EditJarsPanel.this.currentRow);
/*     */       }
/*     */       
/* 109 */     });
/* 110 */     this.jarFld.setEditable(this.update);
/* 111 */     this.descriptionFld.setEditable(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_200_Screen()
/*     */   {
/* 119 */     addComponentRE(1, 5, CommonCode.TIP_HEIGHT, BasePanel.GAP1, 2, 2, this.tips);
/*     */     
/*     */ 
/*     */ 
/* 123 */     addComponentRE(1, 5, TABLE_HEIGHT, BasePanel.GAP2, 2, 2, this.jarsTbl);
/*     */     
/*     */ 
/*     */ 
/* 127 */     addLineRE("Jar Type", this.typeFld);
/* 128 */     addLineRE("Jar", this.jarFld);
/* 129 */     addLineRE("Description", this.descriptionFld);
/* 130 */     setHeightRE(BasePanel.GAP3);
/* 131 */     setGapRE(BasePanel.GAP2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setInitialValues()
/*     */   {
/* 142 */     this.jarMdl = new JarTblModel(this.jarsList.jars, columnHeadings);
/* 143 */     this.jarsTbl.setModel(this.jarMdl);
/*     */     
/* 145 */     g100_SetFields(0);
/* 146 */     this.jarMdl.fireTableDataChanged();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void g100_SetFields(int row)
/*     */   {
/* 155 */     if (this.currentRow >= 0) {
/* 156 */       this.jarsList.jars[this.currentRow][1] = this.jarFld.getText();
/*     */     }
/* 158 */     this.currentRow = row;
/* 159 */     this.typeFld.setText(this.jarsList.jars[row][0]);
/* 160 */     this.jarFld.setText(this.jarsList.jars[row][1]);
/* 161 */     this.descriptionFld.setText(this.jarsList.jars[row][2]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void g200_checkForFixedTypeName(int row)
/*     */   {
/* 170 */     if (!"".equals(this.typeName)) {
/* 171 */       this.jarsList.jars[row][0] = (this.typeName + row);
/* 172 */       this.typeFld.setText(this.jarsList.jars[row][0]);
/* 173 */       this.jarMdl.fireTableRowsUpdated(row, row);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private class JarTblModel
/*     */     extends DefaultTableModel
/*     */   {
/*     */     private String[][] tableData;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public JarTblModel(String[][] data, Object[] columnNames)
/*     */     {
/* 196 */       super(columnNames);
/*     */       
/* 198 */       this.tableData = data;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isCellEditable(int row, int column)
/*     */     {
/* 206 */       return (EditJarsPanel.this.update) && ((column == 1) || ((column == 0) && ("".equals(EditJarsPanel.this.typeName))));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Object getValueAt(int row, int column)
/*     */     {
/* 217 */       if (this.tableData[row] == null) {
/* 218 */         return null;
/*     */       }
/* 220 */       return this.tableData[row][column];
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void setValueAt(Object aValue, int row, int column)
/*     */     {
/* 227 */       super.setValueAt(aValue, row, column);
/*     */       
/* 229 */       String s = "";
/* 230 */       if (s != null) {
/* 231 */         s = aValue.toString();
/*     */       }
/*     */       
/* 234 */       if (this.tableData[row] == null) {
/* 235 */         this.tableData[row] = new String[3];
/*     */       }
/*     */       
/* 238 */       this.tableData[row][column] = s;
/*     */       
/* 240 */       EditJarsPanel.this.g200_checkForFixedTypeName(row);
/* 241 */       if (row == EditJarsPanel.this.currentRow) {
/* 242 */         if (column == 0) {
/* 243 */           EditJarsPanel.this.typeFld.setText(s);
/* 244 */         } else if (column == 1) {
/* 245 */           EditJarsPanel.this.jarFld.setText(s);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/editProperties/EditJarsPanel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */