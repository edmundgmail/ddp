/*    */ package net.sf.RecordEditor.re.editProperties;
/*    */ 
/*    */ import net.sf.JRecord.Common.AbstractManager;
/*    */ import net.sf.RecordEditor.utils.swing.Combo.ComboStrOption;
/*    */ import net.sf.RecordEditor.utils.swing.ComboBoxs.EnglishStrModel;
/*    */ 
/*    */ public class DefaultOptModel
/*    */ {
/*    */   public static EnglishStrModel newModel(AbstractManager manager)
/*    */   {
/* 11 */     EnglishStrModel mdl = new EnglishStrModel();
/* 12 */     String id = manager.getManagerName();
/*    */     
/* 14 */     for (int i = 0; i < manager.getNumberOfEntries(); i++) {
/* 15 */       String s = manager.getName(i);
/*    */       
/* 17 */       if ((s != null) && (!"".equals(s))) {
/* 18 */         mdl.addElement(getItem(id, manager.getKey(i), s));
/*    */       }
/*    */     }
/* 21 */     return mdl;
/*    */   }
/*    */   
/*    */   public static EnglishStrModel newModel(String[] list) {
/* 25 */     EnglishStrModel mdl = new EnglishStrModel();
/*    */     
/* 27 */     for (int i = 0; i < list.length; i++) {
/* 28 */       String s = list[i];
/* 29 */       if ((s != null) && (!"".equals(s))) {
/* 30 */         mdl.addElement(new ComboStrOption(s, s, s));
/*    */       }
/*    */     }
/* 33 */     return mdl;
/*    */   }
/*    */   
/*    */   public static EnglishStrModel newModel(String id, String[] list)
/*    */   {
/* 38 */     EnglishStrModel mdl = new EnglishStrModel();
/*    */     
/* 40 */     for (int i = 0; i < list.length; i++) {
/* 41 */       String s = list[i];
/* 42 */       if ((s != null) && (!"".equals(s))) {
/* 43 */         mdl.addElement(getItem(id, i, s));
/*    */       }
/*    */     }
/* 46 */     return mdl;
/*    */   }
/*    */   
/*    */   private static ComboStrOption getItem(String id, int idx, String s) {
/* 50 */     return new ComboStrOption(s, net.sf.RecordEditor.utils.lang.LangConversion.convertId(10, id + "_" + idx, s), s);
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/editProperties/DefaultOptModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */