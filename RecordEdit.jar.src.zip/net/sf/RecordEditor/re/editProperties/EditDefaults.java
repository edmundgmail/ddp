/*     */ package net.sf.RecordEditor.re.editProperties;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.util.Properties;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JEditorPane;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.Combo.ComboStrOption;
/*     */ import net.sf.RecordEditor.utils.swing.ComboBoxs.EnglishStrModel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EditDefaults
/*     */   extends BasePanel
/*     */ {
/*  31 */   private static final int TABLE_HEIGHT = SwingUtils.NORMAL_FIELD_HEIGHT * 15 / 2;
/*     */   
/*     */   private EditParams editParams;
/*     */   private ListModel model;
/*  35 */   private JTextArea descriptionFld = new JTextArea();
/*     */   
/*     */   private JEditorPane tips;
/*     */   private JTable optionTbl;
/*  39 */   private JComboBox optionCombo = new JComboBox();
/*     */   
/*     */   private EnglishStrModel[] comboModels;
/*  42 */   private int currentRow = -1;
/*     */   
/*     */   private String[][] data;
/*     */   
/*  46 */   private static final String[] columnHeadings = LangConversion.convertArray(5, "editProps_DefaultColHeadings", new String[] { "Property Variable", "Description" });
/*     */   
/*     */ 
/*  49 */   private AbstractAction action = new AbstractAction()
/*     */   {
/*     */ 
/*     */ 
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/*     */ 
/*     */ 
/*  57 */       EditDefaults.this.saveProperty();
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EditDefaults(EditParams params, String description, String[][] dataDescription, EnglishStrModel[] comboBoxModels)
/*     */   {
/*  69 */     this.editParams = params;
/*  70 */     this.data = dataDescription;
/*  71 */     this.comboModels = comboBoxModels;
/*     */     
/*  73 */     this.tips = new JEditorPane("text/html", description);
/*     */     
/*     */ 
/*  76 */     init_100_ScreenFields();
/*  77 */     init_200_Screen();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_100_ScreenFields()
/*     */   {
/*  87 */     this.model = new ListModel(this.data, columnHeadings);
/*  88 */     this.optionTbl = new JTable(this.model);
/*  89 */     this.optionTbl.addMouseListener(new MouseAdapter() {
/*     */       public void mousePressed(MouseEvent m) {
/*  91 */         EditDefaults.this.g100_SetFields(EditDefaults.this.optionTbl.getSelectedRow());
/*     */       }
/*  93 */     });
/*  94 */     g100_SetFields(0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_200_Screen()
/*     */   {
/* 102 */     addComponentRE(1, 5, CommonCode.TIP_HEIGHT, BasePanel.GAP1, 2, 2, this.tips);
/*     */     
/*     */ 
/*     */ 
/* 106 */     addComponentRE(1, 5, TABLE_HEIGHT, BasePanel.GAP2, 2, 2, new JScrollPane(this.optionTbl));
/*     */     
/*     */ 
/*     */ 
/* 110 */     addLineRE("Description", this.descriptionFld);
/* 111 */     setHeightRE(BasePanel.GAP3);
/* 112 */     setGapRE(BasePanel.GAP2);
/* 113 */     addLineRE("Default Value", this.optionCombo);
/* 114 */     setGapRE(BasePanel.GAP1);
/*     */     
/* 116 */     done();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void g100_SetFields(int row)
/*     */   {
/* 126 */     this.optionCombo.removeActionListener(this.action);
/*     */     
/* 128 */     saveProperty();
/*     */     
/* 130 */     this.currentRow = row;
/* 131 */     this.descriptionFld.setText(this.data[row][1]);
/* 132 */     this.optionCombo.setModel(this.comboModels[row]);
/*     */     
/* 134 */     Object o = this.editParams.properties.get(this.data[row][0]);
/* 135 */     if (o != null) {
/* 136 */       String s = o.toString();
/* 137 */       for (int i = 0; i < this.optionCombo.getItemCount(); i++) {
/* 138 */         if (s.equals(((ComboStrOption)this.optionCombo.getItemAt(i)).getEnglish())) {
/* 139 */           this.optionCombo.setSelectedIndex(i);
/* 140 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 144 */     this.optionCombo.addActionListener(this.action);
/*     */   }
/*     */   
/*     */ 
/*     */   private void saveProperty()
/*     */   {
/* 150 */     Object selectedItem = this.optionCombo.getSelectedItem();
/* 151 */     if ((this.currentRow >= 0) && (selectedItem != null) && ((selectedItem instanceof ComboStrOption))) {
/* 152 */       this.editParams.properties.setProperty(this.data[this.currentRow][0], ((ComboStrOption)selectedItem).getEnglish());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class ListModel
/*     */     extends DefaultTableModel
/*     */   {
/*     */     private String[][] tableData;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public ListModel(String[][] data, Object[] columnNames)
/*     */     {
/* 174 */       super(columnNames);
/*     */       
/* 176 */       this.tableData = data;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isCellEditable(int row, int column)
/*     */     {
/* 184 */       return false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Object getValueAt(int row, int column)
/*     */     {
/* 192 */       if (this.tableData[row] == null) {
/* 193 */         return null;
/*     */       }
/* 195 */       return this.tableData[row][column];
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/editProperties/EditDefaults.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */