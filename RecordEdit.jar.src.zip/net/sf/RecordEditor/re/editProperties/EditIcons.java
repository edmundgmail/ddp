/*     */ package net.sf.RecordEditor.re.editProperties;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.FocusAdapter;
/*     */ import java.awt.event.FocusEvent;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JEditorPane;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.JarFileSelect;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EditIcons
/*     */   extends BasePanel
/*     */   implements ActionListener
/*     */ {
/*  32 */   private static final String DESCRIPTION = LangConversion.convertId(2, "EditProperties_Icons", "<h2>Icons</h2>This screen lets you choose which icon set to use in the <b>RecordEditor</b>");
/*     */   
/*     */ 
/*     */ 
/*  36 */   private static final String[] ICON_NAMES = { "Windows", "Eclipse", "Office XP", "Office 2003", "Aqua", "Gnome", "Tango", "Other" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  46 */   private static final String[] ZIP_NAME = { "", "<lib>/iconsEclipse.zip", "<lib>/iconsOfficeXP.zip", "<lib>/iconsOffice2003.zip", "<lib>/iconsAqua.zip", "<lib>/iconsGnome.zip", "<lib>/iconsTango.zip", "" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  56 */   private static final boolean[] USE_PNG = { true, false, false, false, true, true, true, false };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  67 */   private static final int OTHER_ZIP_OPTION = ICON_NAMES.length - 1;
/*     */   
/*  69 */   private JEditorPane tips = new JEditorPane("text/html", DESCRIPTION);
/*     */   
/*  71 */   private JComboBox looks = new JComboBox(ICON_NAMES);
/*  72 */   private JCheckBox usePng = new JCheckBox();
/*  73 */   private JarFileSelect jarName = new JarFileSelect(true, null);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private EditParams pgmParams;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public EditIcons(EditParams params)
/*     */   {
/*  85 */     this.pgmParams = params;
/*     */     
/*  87 */     init_100_ScreenFields();
/*  88 */     init_200_ScreenBuild();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_100_ScreenFields()
/*     */   {
/*  97 */     String usePgnStr = this.pgmParams.getProperty("usePgnIcons", "Y").toUpperCase();
/*  98 */     FocusAdapter focusMgr = new FocusAdapter() {
/*     */       public void focusLost(FocusEvent e) {
/* 100 */         EditIcons.this.setParameters();
/*     */       }
/*     */       
/* 103 */     };
/* 104 */     this.looks.setSelectedIndex(0);
/*     */     try {
/* 106 */       int idx = Integer.parseInt(this.pgmParams.getProperty("IconIndex"));
/*     */       
/* 108 */       this.looks.setSelectedIndex(idx);
/*     */     }
/*     */     catch (Exception e) {}
/* 111 */     this.usePng.setSelected("Y".equals(usePgnStr));
/* 112 */     this.jarName.setText(this.pgmParams.iconJar);
/*     */     
/* 114 */     setOptions();
/*     */     
/*     */ 
/* 117 */     this.usePng.addActionListener(this);
/* 118 */     this.looks.addActionListener(this);
/* 119 */     this.looks.addFocusListener(focusMgr);
/* 120 */     this.jarName.addFcFocusListener(focusMgr);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_200_ScreenBuild()
/*     */   {
/* 129 */     addComponentRE(1, 5, CommonCode.TIP_HEIGHT, BasePanel.GAP2, 2, 2, this.tips);
/*     */     
/*     */ 
/*     */ 
/* 133 */     addLineRE("Icon Set", this.looks);
/* 134 */     setGapRE(BasePanel.GAP1);
/* 135 */     addLineRE("Look for png icons", this.usePng);
/* 136 */     setGapRE(BasePanel.GAP1);
/*     */     
/* 138 */     addLineRE("Zip/Jar File", this.jarName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setOptions()
/*     */   {
/* 146 */     int idx = this.looks.getSelectedIndex();
/* 147 */     boolean otherOption = idx == OTHER_ZIP_OPTION;
/*     */     
/* 149 */     if (!otherOption) {
/* 150 */       this.jarName.setText(ZIP_NAME[idx]);
/*     */     }
/* 152 */     if (idx < OTHER_ZIP_OPTION) {
/* 153 */       this.usePng.setSelected(USE_PNG[idx]);
/*     */     }
/* 155 */     this.usePng.setEnabled(otherOption);
/* 156 */     this.jarName.setEnabled(otherOption);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setParameters()
/*     */   {
/* 164 */     String usePgnString = "N";
/*     */     
/* 166 */     if (this.usePng.isSelected()) {
/* 167 */       usePgnString = "Y";
/*     */     }
/*     */     
/* 170 */     this.pgmParams.setProperty("IconIndex", Integer.toString(this.looks.getSelectedIndex()));
/*     */     
/* 172 */     this.pgmParams.setProperty("usePgnIcons", usePgnString);
/*     */     
/* 174 */     this.pgmParams.iconJar = this.jarName.getText();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void actionPerformed(ActionEvent e)
/*     */   {
/* 182 */     setOptions();
/* 183 */     setParameters();
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/editProperties/EditIcons.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */