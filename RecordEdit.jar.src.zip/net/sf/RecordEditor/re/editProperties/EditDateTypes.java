/*     */ package net.sf.RecordEditor.re.editProperties;
/*     */ 
/*     */ import java.awt.event.FocusAdapter;
/*     */ import java.awt.event.FocusEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import javax.swing.DefaultCellEditor;
/*     */ import javax.swing.JEditorPane;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import net.sf.RecordEditor.re.db.Table.TableList;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.BmKeyedComboBox;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EditDateTypes
/*     */   extends BasePanel
/*     */ {
/*  41 */   private static final Calendar XMAS_CAL = new GregorianCalendar(1998, 11, 25);
/*  42 */   private static Date xmas = XMAS_CAL.getTime();
/*     */   
/*  44 */   private static final int TABLE_HEIGHT = SwingUtils.TABLE_ROW_HEIGHT * 10 + 4;
/*  45 */   private static final int NAME_WIDTH = SwingUtils.STANDARD_FONT_WIDTH * 13;
/*     */   
/*     */   private static final int TYPE_NAME_COLUMN = 0;
/*     */   
/*     */   private static final int BASE_TYPE_COLUMN = 1;
/*     */   private static final int FORMAT_COLUMN = 2;
/*  51 */   private static final String DESCRIPTION = LangConversion.convertId(2, "EditProtoperties_DataTypes", "<h2>Date Types</h2>This screen lets you define Date Types to the <b>RecordEditor</b><br><br>") + Common.DATE_FORMAT_DESCRIPTION;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  57 */   private static final String[] COL_HEADERS = { "Type Name", "Base Type", "Date Format" };
/*     */   
/*     */ 
/*  60 */   private static final String[] COL_NAMES = { "DateTypeName.", "DateBaseType.", "DateFormat." };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  66 */   private JEditorPane tips = new JEditorPane("text/html", DESCRIPTION);
/*     */   
/*     */   private PropertiesTableModel typeTblModel;
/*     */   
/*     */   private JTable typeTbl;
/*     */   
/*  72 */   private JTextField name = new JTextField();
/*     */   private TableList typeModel;
/*     */   private BmKeyedComboBox typeName;
/*  75 */   private JTextField dateFormat = new JTextField();
/*     */   
/*     */ 
/*     */   private EditParams pgmParams;
/*     */   
/*  80 */   private int currentRow = 0;
/*     */   
/*  82 */   private FocusAdapter lostFocus = new FocusAdapter() {
/*     */     public void focusLost(FocusEvent e) {
/*  84 */       EditDateTypes.this.g100_SetTblFields();
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EditDateTypes(EditParams params)
/*     */   {
/*  96 */     this.pgmParams = params;
/*     */     
/*  98 */     init_100_ScreenFields();
/*  99 */     init_200_Screen();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void init_100_ScreenFields()
/*     */   {
/* 106 */     int connectionIdx = Common.getConnectionIndex();
/*     */     
/*     */ 
/* 109 */     this.typeModel = new TableList(connectionIdx, 1, true, false, "TypeNumber.", "TypeName.", 30);
/*     */     
/*     */ 
/* 112 */     this.typeName = new BmKeyedComboBox(this.typeModel, false);
/*     */     
/* 114 */     this.typeTblModel = new PropertiesTableModel(this.pgmParams, COL_NAMES, COL_HEADERS, "PropEd_DataTypes", 20)
/*     */     {
/*     */       public Object getValueAt(int rowIndex, int columnIndex) {
/* 117 */         Object ret = super.getValueAt(rowIndex, columnIndex);
/*     */         
/* 119 */         if ((ret != null) && (columnIndex == 1)) {
/*     */           try {
/* 121 */             ret = new Integer(ret.toString());
/*     */           }
/*     */           catch (Exception e) {}
/*     */         }
/* 125 */         return ret;
/*     */       }
/*     */       
/*     */       public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
/* 129 */         super.setValueAt(aValue, rowIndex, columnIndex);
/* 130 */         if (aValue != null) {
/* 131 */           if (columnIndex == 0) {
/* 132 */             String s = aValue.toString();
/* 133 */             EditDateTypes.this.name.setText(s);
/* 134 */           } else if (columnIndex == 1) {
/* 135 */             EditDateTypes.this.g300_SetBaseType(rowIndex);
/* 136 */           } else if (columnIndex == 2) {
/* 137 */             String s = aValue.toString();
/* 138 */             EditDateTypes.this.dateFormat.setText(s);
/* 139 */             EditDateTypes.this.g400_CheckDateFormat(s);
/*     */           }
/*     */         }
/*     */       }
/* 143 */     };
/* 144 */     this.typeTbl = new JTable(this.typeTblModel);
/* 145 */     this.typeTbl.setAutoResizeMode(0);
/* 146 */     this.typeTbl.setRowHeight(SwingUtils.COMBO_TABLE_ROW_HEIGHT);
/*     */     
/* 148 */     BmKeyedComboBox tblTypeCombo = new BmKeyedComboBox(this.typeModel, false);
/* 149 */     DefaultCellEditor typeEditor = new DefaultCellEditor(tblTypeCombo);
/* 150 */     typeEditor.setClickCountToStart(1);
/*     */     
/* 152 */     this.tips.setCaretPosition(0);
/*     */     
/* 154 */     TableColumn tc = this.typeTbl.getColumnModel().getColumn(1);
/* 155 */     tc.setCellRenderer(tblTypeCombo.getTableCellRenderer());
/* 156 */     tc.setCellEditor(typeEditor);
/*     */     
/* 158 */     g200_SetScreenFields(this.currentRow);
/* 159 */     Common.calcColumnWidths(this.typeTbl, 1);
/*     */     
/* 161 */     tc = this.typeTbl.getColumnModel().getColumn(0);
/* 162 */     tc.setPreferredWidth(Math.max(tc.getPreferredWidth(), NAME_WIDTH));
/*     */     
/* 164 */     this.name.addFocusListener(this.lostFocus);
/* 165 */     this.typeName.addFocusListener(this.lostFocus);
/* 166 */     this.dateFormat.addFocusListener(this.lostFocus);
/*     */     
/* 168 */     this.typeTbl.addMouseListener(new MouseAdapter() {
/*     */       public void mousePressed(MouseEvent m) {
/* 170 */         EditDateTypes.this.g200_SetScreenFields(EditDateTypes.this.typeTbl.getSelectedRow());
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_200_Screen()
/*     */   {
/* 182 */     addComponentRE(1, 5, CommonCode.TIP_HEIGHT, BasePanel.GAP2, 2, 2, this.tips);
/*     */     
/*     */ 
/*     */ 
/* 186 */     addComponentRE(1, 5, TABLE_HEIGHT, BasePanel.GAP0, 2, 2, new JScrollPane(this.typeTbl));
/*     */     
/*     */ 
/*     */ 
/* 190 */     addLineRE("Source Name", this.name);
/* 191 */     addLineRE("Base Type", this.typeName);
/* 192 */     addLineRE("Date Format", this.dateFormat);
/*     */     
/* 194 */     setGapRE(BasePanel.GAP2);
/* 195 */     addMessageRE();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void g100_SetTblFields()
/*     */   {
/* 204 */     this.typeTblModel.setValueAt(this.name.getText(), this.currentRow, 0);
/* 205 */     this.typeTblModel.setValueAt(this.typeName.getSelectedItem(), this.currentRow, 1);
/* 206 */     this.typeTblModel.setValueAt(this.dateFormat.getText(), this.currentRow, 2);
/* 207 */     this.typeTblModel.fireTableDataChanged();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void g200_SetScreenFields(int row)
/*     */   {
/* 215 */     this.currentRow = row;
/*     */     
/* 217 */     this.name.setText(this.typeTblModel.getStringValueAt(row, 0));
/* 218 */     g300_SetBaseType(row);
/* 219 */     this.dateFormat.setText(this.typeTblModel.getStringValueAt(row, 2));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void g300_SetBaseType(int row)
/*     */   {
/*     */     try
/*     */     {
/* 230 */       this.typeName.setSelectedItem(new Integer(this.typeTblModel.getStringValueAt(row, 1)));
/*     */     }
/*     */     catch (Exception e) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void g400_CheckDateFormat(String format)
/*     */   {
/* 241 */     if (format != null) {
/*     */       try
/*     */       {
/* 244 */         SimpleDateFormat sd = new SimpleDateFormat(format);
/* 245 */         setMessageTxtRE("25.Dec.98 will be formatted as " + sd.format(xmas));
/*     */       } catch (Exception e) {
/* 247 */         setMessageTxtRE("Date Format Error: " + e.getMessage());
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/editProperties/EditDateTypes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */