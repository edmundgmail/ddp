/*     */ package net.sf.RecordEditor.re.editProperties;
/*     */ 
/*     */ import javax.swing.table.AbstractTableModel;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PropertiesTableModel
/*     */   extends AbstractTableModel
/*     */ {
/*     */   private String[] colHeadings;
/*     */   private String[] colNames;
/*     */   private int tblSize;
/*     */   private EditParams pgmProperties;
/*     */   
/*     */   public PropertiesTableModel(EditParams params, String[] columnNames, String[] columnHeader, String id, int tableSize)
/*     */   {
/*  43 */     this(params, columnNames, LangConversion.convertColHeading(id, (String[])columnHeader.clone()), tableSize);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public PropertiesTableModel(EditParams params, String[] columnNames, String[] columnHeader, int tableSize)
/*     */   {
/*  60 */     this.pgmProperties = params;
/*  61 */     this.colHeadings = columnHeader;
/*  62 */     this.colNames = columnNames;
/*  63 */     this.tblSize = tableSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getCellName(int row, int col)
/*     */   {
/*  73 */     return this.colNames[col] + row;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getStringValueAt(int rowIndex, int columnIndex)
/*     */   {
/*  83 */     String colName = getCellName(rowIndex, columnIndex);
/*  84 */     String s = this.pgmProperties.getProperty(colName);
/*     */     
/*  86 */     if (s == null) {
/*  87 */       s = Parameters.getString(colName);
/*     */     }
/*  89 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValueAt(Object aValue, int rowIndex, int columnIndex)
/*     */   {
/*  97 */     this.pgmProperties.setProperty(getCellName(rowIndex, columnIndex), aValue.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getColumnCount()
/*     */   {
/* 104 */     return this.colHeadings.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getRowCount()
/*     */   {
/* 111 */     return this.tblSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getValueAt(int rowIndex, int columnIndex)
/*     */   {
/* 119 */     return getStringValueAt(rowIndex, columnIndex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getColumnName(int column)
/*     */   {
/* 126 */     return this.colHeadings[column];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCellEditable(int rowIndex, int columnIndex)
/*     */   {
/* 134 */     return true;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/editProperties/PropertiesTableModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */