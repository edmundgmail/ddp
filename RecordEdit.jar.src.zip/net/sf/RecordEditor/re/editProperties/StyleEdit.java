/*     */ package net.sf.RecordEditor.re.editProperties;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dialog.ModalityType;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextField;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ public class StyleEdit
/*     */   implements ActionListener
/*     */ {
/*     */   private JDialog dialog;
/*  23 */   private final BaseHelpPanel panel = new BaseHelpPanel("EditProps_StyleEdit");
/*     */   private final Color orginalColor;
/*     */   private final Color origiginalBackgroundColor;
/*  26 */   private final JTextField typeJTxt = new JTextField();
/*  27 */   private final JCheckBox colorChk = new JCheckBox("Forground Color");
/*  28 */   private final JCheckBox backgroundColorChk = new JCheckBox("Backgroundground Color");
/*     */   private final ColorButton colorBtn;
/*  30 */   private final ColorButton backgroundColorBtn; private final JButton okBtn = SwingUtils.newButton("Ok"); private final JButton cancelBtn = SwingUtils.newButton("Cancel");
/*     */   
/*     */ 
/*  33 */   private boolean ok = true;
/*     */   
/*     */   public StyleEdit(JFrame w, JComponent locationComp, String type, Color currentColor, Color backGroundColor) {
/*  36 */     this.orginalColor = currentColor;
/*  37 */     this.origiginalBackgroundColor = backGroundColor;
/*     */     
/*  39 */     this.typeJTxt.setText(type);
/*  40 */     this.colorBtn = new ColorButton(currentColor, "Choose Foreground Color");
/*  41 */     this.backgroundColorBtn = new ColorButton(backGroundColor, "Choose Background Color");
/*  42 */     this.dialog = new JDialog(w);
/*     */     
/*  44 */     init_100_setup();
/*  45 */     init_200_LayoutScreen();
/*  46 */     init_300_Finalise(locationComp);
/*     */   }
/*     */   
/*     */ 
/*     */   private void init_100_setup()
/*     */   {
/*  52 */     this.colorChk.setSelected(true);
/*  53 */     this.colorChk.setEnabled(false);
/*  54 */     this.backgroundColorChk.setSelected(this.origiginalBackgroundColor != null);
/*     */     
/*  56 */     this.typeJTxt.setEnabled(false);
/*     */   }
/*     */   
/*     */ 
/*     */   private void init_200_LayoutScreen()
/*     */   {
/*  62 */     JPanel btnPanel = new JPanel();
/*  63 */     btnPanel.add(this.okBtn);
/*  64 */     btnPanel.add(this.cancelBtn);
/*     */     
/*  66 */     this.panel.setGapRE(BasePanel.GAP2);
/*  67 */     this.panel.addLineRE("", this.typeJTxt).setGapRE(BasePanel.GAP2);
/*     */     
/*  69 */     this.panel.addLineRE("", this.colorChk, this.colorBtn);
/*  70 */     this.panel.addLineRE("", this.backgroundColorChk, this.backgroundColorBtn).setGapRE(BasePanel.GAP2);
/*     */     
/*     */ 
/*  73 */     this.panel.addComponentRE(1, 5, -2.0D, BasePanel.GAP2, 2, 2, btnPanel);
/*     */     
/*     */ 
/*     */ 
/*  77 */     this.dialog.getContentPane().add(this.panel);
/*  78 */     this.dialog.pack();
/*     */   }
/*     */   
/*     */   private void init_300_Finalise(JComponent locationComp)
/*     */   {
/*  83 */     this.okBtn.addActionListener(this);
/*  84 */     this.cancelBtn.addActionListener(this);
/*     */     
/*  86 */     this.dialog.setModalityType(Dialog.ModalityType.APPLICATION_MODAL);
/*  87 */     this.dialog.setLocationRelativeTo(locationComp);
/*  88 */     this.dialog.setVisible(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final Color getColor()
/*     */   {
/*  95 */     if (this.ok) {
/*  96 */       return this.colorBtn.getColor();
/*     */     }
/*  98 */     return this.orginalColor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final Color getBackgroundColor()
/*     */   {
/* 106 */     if (this.ok) {
/* 107 */       if (!this.backgroundColorChk.isSelected()) {
/* 108 */         return null;
/*     */       }
/* 110 */       return this.backgroundColorBtn.getColor();
/*     */     }
/* 112 */     return this.origiginalBackgroundColor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void actionPerformed(ActionEvent e)
/*     */   {
/* 120 */     this.ok = (e.getSource() == this.okBtn);
/* 121 */     this.dialog.setVisible(false);
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/editProperties/StyleEdit.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */