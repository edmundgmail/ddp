/*     */ package net.sf.RecordEditor.re.jrecord.types;
/*     */ 
/*     */ import com.zbluesoftware.java.bm.ZDateField;
/*     */ import java.io.PrintStream;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import net.sf.JRecord.Common.IFieldDetail;
/*     */ import net.sf.JRecord.Common.RecordException;
/*     */ import net.sf.JRecord.Types.ISizeInformation;
/*     */ import net.sf.JRecord.Types.Type;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeDateWrapper
/*     */   implements Type, ISizeInformation
/*     */ {
/*     */   private Type baseType;
/*  32 */   private SimpleDateFormat df = null;
/*     */   
/*     */ 
/*     */   private String dateFormatStr;
/*     */   
/*     */ 
/*     */   private final int defaultSize;
/*     */   
/*     */ 
/*     */ 
/*     */   public TypeDateWrapper(Type type, String dateFormat)
/*     */   {
/*  44 */     this.baseType = type;
/*     */     
/*     */ 
/*  47 */     this.dateFormatStr = dateFormat;
/*  48 */     if (dateFormat == null) {
/*  49 */       this.defaultSize = 20;
/*     */     } else {
/*  51 */       this.df = new SimpleDateFormat(dateFormat);
/*  52 */       this.defaultSize = dateFormat.length();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String formatValueForRecord(IFieldDetail field, String val)
/*     */     throws RecordException
/*     */   {
/*  74 */     return val;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getField(byte[] data, int position, IFieldDetail currField)
/*     */   {
/*  88 */     Object ret = this.baseType.getField(data, position, currField);
/*     */     
/*  90 */     if ((ret != null) && (!"".equals(ret.toString()))) {
/*     */       try {
/*  92 */         String s = ZDateField.padZeros(this.dateFormatStr, ret.toString());
/*  93 */         SimpleDateFormat f = getDateFormater(currField);
/*     */         
/*  95 */         ret = f.parse(s);
/*     */ 
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */ 
/* 101 */         System.out.println("Format error > " + e.getMessage() + " Value: " + ret + " Format: " + this.dateFormatStr);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 107 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFieldType()
/*     */   {
/* 115 */     return 11;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isBinary()
/*     */   {
/* 124 */     return this.baseType.isBinary();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] setField(byte[] data, int position, IFieldDetail field, Object val)
/*     */     throws RecordException
/*     */   {
/* 142 */     Object o = val;
/* 143 */     if ((o instanceof Date)) {
/* 144 */       SimpleDateFormat f = getDateFormater(field);
/* 145 */       o = f.format((Date)val);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 153 */     return this.baseType.setField(data, position, field, o);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private SimpleDateFormat getDateFormater(IFieldDetail field)
/*     */   {
/* 164 */     if (this.df == null) {
/* 165 */       String s = field.getParamater();
/* 166 */       if ((s == null) || ("".equals(s))) {
/* 167 */         s = "yyMMdd";
/*     */       }
/*     */       
/* 170 */       return new SimpleDateFormat(s);
/*     */     }
/* 172 */     return this.df;
/*     */   }
/*     */   
/*     */   public boolean isNumeric()
/*     */   {
/* 177 */     return this.baseType.isNumeric();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNormalSize()
/*     */   {
/* 186 */     return this.defaultSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public char getDecimalChar()
/*     */   {
/* 194 */     return '.';
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/jrecord/types/TypeDateWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */