/*     */ package net.sf.RecordEditor.re.jrecord.types;
/*     */ 
/*     */ import javax.swing.DefaultCellEditor;
/*     */ import javax.swing.table.TableCellEditor;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail.FieldDetails;
/*     */ import net.sf.RecordEditor.re.jrecord.format.CellFormat;
/*     */ import net.sf.RecordEditor.utils.ColumnMappingInterface;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.swing.CheckboxTableRenderStringBased;
/*     */ import net.sf.RecordEditor.utils.swing.Combo.ComboItemEditor;
/*     */ import net.sf.RecordEditor.utils.swing.Combo.ComboItemRender;
/*     */ import net.sf.RecordEditor.utils.swing.Combo.ComboModelSupplier;
/*     */ import net.sf.RecordEditor.utils.swing.ComboBoxRenderAdapter;
/*     */ import net.sf.RecordEditor.utils.swing.LayoutCombo;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.swing.TableCellEditorWithDefault;
/*     */ import net.sf.RecordEditor.utils.swing.TextAreaTableCellEditor;
/*     */ import net.sf.RecordEditor.utils.swing.TextAreaTableCellRendor;
/*     */ import net.sf.RecordEditor.utils.swing.array.ArrayRender;
/*     */ import net.sf.RecordEditor.utils.swing.array.ArrayTableEditor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RecordFormats
/*     */ {
/*  47 */   private int rendorStatus = 0; private int editorStatus = 0;
/*     */   
/*     */ 
/*  50 */   private int maxHeight = -121;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  58 */   private TableCellRenderer[] cellRenders = null;
/*  59 */   private TableCellEditor[] cellEditor = null;
/*     */   private static final int STATUS_DOES_NOT_EXIST = -1;
/*     */   private static final int STATUS_UNKOWN = 0;
/*     */   private int[] widths;
/*     */   private CellFormat[] fieldFormats;
/*     */   private final AbstractRecordDetail recordDescription;
/*     */   private final AbstractLayoutDetails layout;
/*     */   private final int recordIdx;
/*     */   private final ColumnMappingInterface mapping;
/*     */   
/*     */   public RecordFormats(ColumnMappingInterface columnMapping, AbstractLayoutDetails recordLayout, int recordIndex) {
/*  70 */     this.mapping = columnMapping;
/*  71 */     this.layout = recordLayout;
/*  72 */     this.recordIdx = recordIndex;
/*  73 */     this.recordDescription = this.layout.getRecord(this.recordIdx);
/*     */     
/*  75 */     allocateArrays();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TableCellRenderer[] getCellRenders()
/*     */   {
/*  86 */     if ((this.cellRenders == null) && (this.rendorStatus != -1))
/*     */     {
/*     */ 
/*  89 */       boolean foundRendor = false;
/*     */       
/*  91 */       this.cellRenders = new TableCellRenderer[this.recordDescription.getFieldCount()];
/*     */       
/*  93 */       for (int j = 0; j < this.cellRenders.length; j++) {
/*  94 */         this.cellRenders[j] = null;
/*  95 */         int idx = this.mapping.getRealColumn(this.recordIdx, j);
/*     */         
/*  97 */         AbstractRecordDetail.FieldDetails fieldDef = this.recordDescription.getField(idx);
/*  98 */         switch (fieldDef.getType()) {
/*     */         case 116: 
/* 100 */           this.cellRenders[j] = new ComboBoxRenderAdapter(new LayoutCombo(this.layout, false, true));
/* 101 */           break;
/*     */         case 109: 
/* 103 */           this.cellRenders[j] = new CheckboxTableRenderStringBased("Y", "", false, false);
/* 104 */           break;
/* 105 */         case 92:  this.cellRenders[j] = new ArrayRender(); break;
/*     */         case 51: case 118: 
/* 107 */           this.cellRenders[j] = new TextAreaTableCellRendor(); break;
/*     */         default: 
/* 109 */           if ((fieldDef.getType() == 93) && ((fieldDef instanceof ComboModelSupplier)))
/*     */           {
/* 111 */             this.cellRenders[j] = new ComboItemRender(((ComboModelSupplier)fieldDef).getComboModel());
/* 112 */           } else if ((idx < this.fieldFormats.length) && (this.fieldFormats[idx] != null)) {
/*     */             try {
/* 114 */               this.cellRenders[j] = this.fieldFormats[idx].getTableCellRenderer(this.recordDescription.getField(idx));
/*     */             }
/*     */             catch (Exception e) {
/* 117 */               Common.logMsg(30, "Can not create Rendor for field:", this.recordDescription.getField(idx).getName(), e);
/*     */             }
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           break;
/*     */         }
/*     */         
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 135 */         foundRendor |= this.cellRenders[j] != null;
/*     */       }
/*     */       
/* 138 */       if (!foundRendor) {
/* 139 */         this.cellRenders = null;
/* 140 */         this.rendorStatus = -1;
/*     */       }
/*     */     }
/* 143 */     return this.cellRenders;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TableCellEditor[] getCellEditors()
/*     */   {
/* 154 */     if ((this.cellEditor == null) && (this.editorStatus != -1))
/*     */     {
/*     */ 
/* 157 */       boolean foundRendor = false;
/*     */       
/* 159 */       this.cellEditor = new TableCellEditor[this.recordDescription.getFieldCount()];
/*     */       
/* 161 */       for (int j = 0; j < this.cellEditor.length; j++) {
/* 162 */         this.cellEditor[j] = null;
/* 163 */         int idx = this.mapping.getRealColumn(this.recordIdx, j);
/*     */         
/*     */ 
/*     */ 
/* 167 */         AbstractRecordDetail.FieldDetails fieldDef = this.recordDescription.getField(idx);
/* 168 */         switch (fieldDef.getType()) {
/*     */         case 116: 
/* 170 */           this.cellEditor[j] = new DefaultCellEditor(new LayoutCombo(this.layout, false, true));
/*     */           
/* 172 */           break;
/*     */         case 109: 
/* 174 */           this.cellEditor[j] = new CheckboxTableRenderStringBased("Y", "", false, false);
/* 175 */           break;
/* 176 */         case 92:  this.cellEditor[j] = new ArrayTableEditor(); break;
/*     */         case 51: case 118: 
/* 178 */           this.cellEditor[j] = new TextAreaTableCellEditor(); break;
/*     */         default: 
/* 180 */           if ((fieldDef.getType() == 93) && ((fieldDef instanceof ComboModelSupplier)))
/*     */           {
/* 182 */             this.cellEditor[j] = new ComboItemEditor(((ComboModelSupplier)fieldDef).getComboModel());
/* 183 */             this.maxHeight = Math.max(this.maxHeight, SwingUtils.COMBO_TABLE_ROW_HEIGHT);
/* 184 */           } else if ((idx < this.fieldFormats.length) && (this.fieldFormats[idx] != null)) {
/*     */             try {
/* 186 */               this.cellEditor[j] = this.fieldFormats[idx].getTableCellEditor(this.recordDescription.getField(idx));
/*     */             }
/*     */             catch (Exception e) {}
/*     */           }
/*     */           break;
/*     */         }
/*     */         
/* 193 */         if ((this.cellEditor[j] == null) && (fieldDef.getDefaultValue() != null)) {
/* 194 */           this.cellEditor[j] = new TableCellEditorWithDefault(fieldDef.getDefaultValue());
/*     */         }
/*     */         
/* 197 */         foundRendor |= this.cellEditor[j] != null;
/*     */       }
/*     */       
/* 200 */       if (!foundRendor) {
/* 201 */         this.cellEditor = null;
/* 202 */         this.editorStatus = -1;
/*     */       }
/*     */     }
/* 205 */     return this.cellEditor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasTheFormatChanged()
/*     */   {
/* 214 */     boolean ret = this.fieldFormats.length != this.recordDescription.getFieldCount();
/*     */     
/* 216 */     if (ret) {
/* 217 */       allocateArrays();
/*     */     }
/*     */     
/* 220 */     return ret;
/*     */   }
/*     */   
/*     */   private void allocateArrays()
/*     */   {
/* 225 */     boolean foundWidth = false;
/* 226 */     ReTypeManger manager = ReTypeManger.getInstance();
/* 227 */     this.fieldFormats = new CellFormat[this.recordDescription.getFieldCount()];
/*     */     
/* 229 */     this.widths = new int[this.recordDescription.getFieldCount()];
/* 230 */     for (int j = 0; j < this.widths.length; j++) {
/* 231 */       this.widths[j] = -121;
/*     */       try
/*     */       {
/* 234 */         this.fieldFormats[j] = manager.getFormat(this.recordDescription.getField(j).getFormat());
/*     */         
/* 236 */         if (this.fieldFormats[j] == null) {
/* 237 */           this.fieldFormats[j] = manager.getTypeFormat(this.recordDescription.getField(j).getType());
/*     */         }
/*     */         
/* 240 */         if (this.fieldFormats[j] != null) {
/* 241 */           this.maxHeight = Math.max(this.maxHeight, this.fieldFormats[j].getFieldHeight());
/* 242 */           this.widths[j] = this.fieldFormats[j].getFieldWidth();
/* 243 */           foundWidth |= this.widths[j] > 0;
/*     */         }
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*     */     
/* 249 */     if (!foundWidth) {
/* 250 */       this.widths = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int[] getWidths()
/*     */   {
/* 263 */     return this.widths;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMaxHeight()
/*     */   {
/* 273 */     return this.maxHeight;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/jrecord/types/RecordFormats.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */