/*     */ package net.sf.RecordEditor.re.jrecord.types;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import net.sf.JRecord.Common.RecordException;
/*     */ import net.sf.JRecord.Types.Type;
/*     */ import net.sf.JRecord.Types.TypeChar;
/*     */ import net.sf.JRecord.Types.TypeManager;
/*     */ import net.sf.JRecord.Types.TypeNum;
/*     */ import net.sf.RecordEditor.re.jrecord.format.BoldFormat;
/*     */ import net.sf.RecordEditor.re.jrecord.format.CellFormat;
/*     */ import net.sf.RecordEditor.re.jrecord.format.CheckBoxBooleanFormat;
/*     */ import net.sf.RecordEditor.re.jrecord.format.CheckBoxFldFormat;
/*     */ import net.sf.RecordEditor.re.jrecord.format.CheckBoxFormat;
/*     */ import net.sf.RecordEditor.re.jrecord.format.ColorFormat;
/*     */ import net.sf.RecordEditor.re.jrecord.format.ComboFormat;
/*     */ import net.sf.RecordEditor.re.jrecord.format.CsvArrayFormat;
/*     */ import net.sf.RecordEditor.re.jrecord.format.DateFormat;
/*     */ import net.sf.RecordEditor.re.jrecord.format.HtmlEditorFormat;
/*     */ import net.sf.RecordEditor.re.jrecord.format.MultiLineFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReTypeManger
/*     */   extends TypeManager
/*     */ {
/*     */   public static final int FORMAT_SYSTEM_ENTRIES = 40;
/*     */   private static final int INVALID_FORMAT_INDEX = 39;
/*     */   private CellFormat[] typesFormat;
/*     */   private CellFormat[] formats;
/*     */   private int userFormatSize;
/*  46 */   private static String dateFormat = null;
/*     */   
/*  48 */   private static ReTypeManger systemTypeManager = null;
/*     */   
/*  50 */   private static DateFormat standardDateFormat = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReTypeManger()
/*     */   {
/*  57 */     this(true, 75, 50);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReTypeManger(boolean addSystemTypes, int numberOfUserTypes, int numberOfUserFormats)
/*     */   {
/*  67 */     super(addSystemTypes, numberOfUserTypes);
/*     */     
/*     */ 
/*     */ 
/*  71 */     this.userFormatSize = numberOfUserFormats;
/*     */     
/*  73 */     this.typesFormat = new CellFormat[super.getNumberOfTypes()];
/*  74 */     this.formats = new CellFormat[40 + this.userFormatSize];
/*     */     
/*  76 */     for (int i = 0; i < this.typesFormat.length; i++) {
/*  77 */       this.typesFormat[i] = null;
/*     */     }
/*     */     
/*  80 */     for (i = 0; i < this.formats.length; i++) {
/*  81 */       this.formats[i] = null;
/*     */     }
/*     */     
/*  84 */     if (addSystemTypes) {
/*  85 */       Type charTypes = new TypeChar(true);
/*  86 */       TypeNum zeroPaded = new TypeNum(7);
/*     */       
/*  88 */       System.out.println("Defining MultiLine Edit");
/*  89 */       this.typesFormat[115] = new CsvArrayFormat();
/*  90 */       this.typesFormat[117] = new MultiLineFormat();
/*  91 */       this.typesFormat[119] = new HtmlEditorFormat();
/*     */       try
/*     */       {
/*  94 */         super.registerType(71, new TypeDateWrapper(charTypes, null));
/*  95 */         super.registerType(74, new TypeDateWrapper(zeroPaded, "ddMMyy"));
/*  96 */         super.registerType(75, new TypeDateWrapper(zeroPaded, "ddMMyyyy"));
/*  97 */         super.registerType(72, new TypeDateWrapper(zeroPaded, "yyMMdd"));
/*  98 */         super.registerType(73, new TypeDateWrapper(zeroPaded, "yyyyMMdd"));
/*     */       } catch (Exception e) {
/* 100 */         e.printStackTrace();
/*     */       }
/*     */       
/* 103 */       if (dateFormat == null) {
/* 104 */         this.typesFormat[71] = new DateFormat(true, null);
/* 105 */         this.typesFormat[74] = new DateFormat(true, "ddMMyy");
/* 106 */         this.typesFormat[75] = new DateFormat(true, "ddMMyyyy");
/* 107 */         this.typesFormat[72] = new DateFormat(true, "yyMMdd");
/* 108 */         this.typesFormat[73] = new DateFormat(true, "yyyyMMdd");
/*     */       }
/*     */       else {
/* 111 */         this.typesFormat[71] = standardDateFormat;
/* 112 */         this.typesFormat[74] = standardDateFormat;
/* 113 */         this.typesFormat[75] = standardDateFormat;
/* 114 */         this.typesFormat[72] = standardDateFormat;
/* 115 */         this.typesFormat[73] = standardDateFormat;
/*     */       }
/*     */       
/* 118 */       this.typesFormat[110] = new CheckBoxFormat("True", "", false);
/* 119 */       this.typesFormat[111] = new CheckBoxFormat("Y", "N", true);
/* 120 */       this.typesFormat[112] = new CheckBoxFormat("T", "F", true);
/* 121 */       this.typesFormat[114] = new CheckBoxBooleanFormat();
/*     */       
/* 123 */       this.formats[1] = new CheckBoxFldFormat();
/* 124 */       this.formats[2] = new DateFormat(false, null);
/* 125 */       this.formats[3] = new DateFormat(false, "ddMMyyyy");
/* 126 */       this.formats[4] = new DateFormat(false, "yyyyMMdd");
/* 127 */       this.formats[15] = new ComboFormat();
/* 128 */       this.formats[21] = new BoldFormat();
/* 129 */       this.formats[22] = new ColorFormat();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void registerType(int typeId, Type typeDef)
/*     */     throws RecordException
/*     */   {
/* 143 */     registerType(typeId, typeDef, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void registerType(int typeId, Type typeDef, CellFormat format)
/*     */     throws RecordException
/*     */   {
/* 160 */     int idx = super.getIndex(typeId);
/*     */     
/* 162 */     super.registerType(typeId, typeDef);
/*     */     
/* 164 */     this.typesFormat[idx] = format;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void registerFormat(int formatId, CellFormat format)
/*     */     throws RecordException
/*     */   {
/* 178 */     int idx = getFormatIndex(formatId);
/*     */     
/* 180 */     if (idx == 149) {
/* 181 */       throw new RecordException("Invalid Index Supplied {0} Should be between {1} and {2}", new Object[] { Integer.valueOf(formatId), Integer.valueOf(1000), Integer.valueOf(1000 + this.userFormatSize) });
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 189 */     this.formats[idx] = format;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellFormat getTypeFormat(int typeId)
/*     */   {
/* 201 */     return this.typesFormat[getIndex(typeId)];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CellFormat getFormat(int formatId)
/*     */   {
/* 213 */     return this.formats[getFormatIndex(formatId)];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getFormatIndex(int index)
/*     */   {
/* 225 */     int idx = 39;
/*     */     
/* 227 */     if ((index >= 0) && (index < 40)) {
/* 228 */       idx = index;
/* 229 */     } else if ((index >= 1000) && (index < 1000 + this.userFormatSize))
/*     */     {
/* 231 */       idx = index - 1000 + 150;
/*     */     }
/*     */     
/* 234 */     return idx;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void setDateFormat(String dateFormatStr)
/*     */   {
/* 243 */     dateFormat = dateFormatStr;
/*     */     
/* 245 */     standardDateFormat = null;
/* 246 */     if (dateFormat != null) {
/* 247 */       standardDateFormat = new DateFormat(true, dateFormat);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final DateFormat getFormatFor(String dateFormatStr)
/*     */   {
/* 257 */     DateFormat ret = standardDateFormat;
/*     */     
/* 259 */     if (ret == null) {
/* 260 */       ret = new DateFormat(true, dateFormatStr);
/*     */     }
/* 262 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ReTypeManger getInstance()
/*     */   {
/* 273 */     if (systemTypeManager == null) {
/* 274 */       systemTypeManager = new ReTypeManger();
/* 275 */       TypeManager.setSystemTypeManager(systemTypeManager);
/*     */     }
/* 277 */     return systemTypeManager;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getUserFormatSize()
/*     */   {
/* 284 */     return this.userFormatSize;
/*     */   }
/*     */   
/*     */   public final int getNumberOfFormats()
/*     */   {
/* 289 */     return this.formats.length;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/jrecord/types/ReTypeManger.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */