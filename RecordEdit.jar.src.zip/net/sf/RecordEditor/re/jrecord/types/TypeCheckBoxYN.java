/*     */ package net.sf.RecordEditor.re.jrecord.types;
/*     */ 
/*     */ import javax.swing.DefaultCellEditor;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.table.TableCellEditor;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import net.sf.JRecord.Common.IFieldDetail;
/*     */ import net.sf.JRecord.Common.RecordException;
/*     */ import net.sf.JRecord.Types.Type;
/*     */ import net.sf.RecordEditor.re.jrecord.format.CellFormat;
/*     */ import net.sf.RecordEditor.utils.swing.CheckBoxTableRender;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeCheckBoxYN
/*     */   implements Type, CellFormat
/*     */ {
/*  33 */   private final CheckBoxTableRender checkBoxRendor = new CheckBoxTableRender();
/*     */   
/*     */   private static final byte YES_BYTE = 89;
/*     */   
/*     */   private static final byte NO_BYTE = 78;
/*     */   
/*     */ 
/*     */   public String formatValueForRecord(IFieldDetail field, String val)
/*     */     throws RecordException
/*     */   {
/*  43 */     return val;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getField(byte[] record, int position, IFieldDetail currField)
/*     */   {
/*  53 */     Boolean b = Boolean.FALSE;
/*     */     
/*  55 */     if (record[(position - 1)] == 89) {
/*  56 */       b = Boolean.TRUE;
/*     */     }
/*  58 */     return b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] setField(byte[] record, int position, IFieldDetail field, Object val)
/*     */     throws RecordException
/*     */   {
/*  71 */     record[(position - 1)] = 78;
/*     */     
/*  73 */     if ("true".equalsIgnoreCase(val.toString())) {
/*  74 */       record[(field.getPos() - 1)] = 89;
/*     */     }
/*  76 */     return record;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TableCellEditor getTableCellEditor(IFieldDetail fld)
/*     */   {
/*  88 */     return new DefaultCellEditor(new JCheckBox());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TableCellRenderer getTableCellRenderer(IFieldDetail fld)
/*     */   {
/*  97 */     return this.checkBoxRendor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFieldWidth()
/*     */   {
/* 107 */     return -121;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFieldHeight()
/*     */   {
/* 117 */     return -121;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isBinary()
/*     */   {
/* 125 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isNumeric()
/*     */   {
/* 132 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFieldType()
/*     */   {
/* 141 */     return 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public char getDecimalChar()
/*     */   {
/* 150 */     return '.';
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/jrecord/types/TypeCheckBoxYN.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */