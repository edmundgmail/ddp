/*    */ package net.sf.RecordEditor.re.jrecord.format;
/*    */ 
/*    */ import java.awt.Font;
/*    */ import javax.swing.DefaultCellEditor;
/*    */ import javax.swing.JTextField;
/*    */ import javax.swing.table.TableCellEditor;
/*    */ import javax.swing.table.TableCellRenderer;
/*    */ import net.sf.JRecord.Common.IFieldDetail;
/*    */ import net.sf.RecordEditor.utils.swing.StandardRendor;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BoldFormat
/*    */   implements CellFormat
/*    */ {
/* 16 */   private StandardRendor boldRendor = new StandardRendor(true);
/*    */   
/*    */   public int getFieldHeight()
/*    */   {
/* 20 */     return -121;
/*    */   }
/*    */   
/*    */   public int getFieldWidth()
/*    */   {
/* 25 */     return -121;
/*    */   }
/*    */   
/*    */   public TableCellEditor getTableCellEditor(IFieldDetail fld)
/*    */   {
/* 30 */     JTextField txtFld = new JTextField();
/* 31 */     Font font = txtFld.getFont();
/* 32 */     txtFld.setFont(new Font(font.getFamily(), 1, font.getSize()));
/*    */     
/*    */ 
/* 35 */     return new DefaultCellEditor(txtFld);
/*    */   }
/*    */   
/*    */   public TableCellRenderer getTableCellRenderer(IFieldDetail fld)
/*    */   {
/* 40 */     return this.boldRendor;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/jrecord/format/BoldFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */