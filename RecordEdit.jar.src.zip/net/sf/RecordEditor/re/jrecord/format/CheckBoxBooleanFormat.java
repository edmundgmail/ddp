/*    */ package net.sf.RecordEditor.re.jrecord.format;
/*    */ 
/*    */ import javax.swing.DefaultCellEditor;
/*    */ import javax.swing.table.TableCellEditor;
/*    */ import javax.swing.table.TableCellRenderer;
/*    */ import net.sf.JRecord.Common.IFieldDetail;
/*    */ import net.sf.RecordEditor.utils.swing.CheckBoxTableRender;
/*    */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CheckBoxBooleanFormat
/*    */   implements CellFormat
/*    */ {
/* 27 */   private CheckBoxTableRender render = new CheckBoxTableRender();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getFieldHeight()
/*    */   {
/* 36 */     return SwingUtils.CHECK_BOX_HEIGHT;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public int getFieldWidth()
/*    */   {
/* 43 */     return SwingUtils.CHECK_BOX_WIDTH;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public TableCellEditor getTableCellEditor(IFieldDetail fld)
/*    */   {
/* 51 */     return new DefaultCellEditor(new CheckBoxTableRender());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public TableCellRenderer getTableCellRenderer(IFieldDetail fld)
/*    */   {
/* 59 */     return this.render;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/jrecord/format/CheckBoxBooleanFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */