/*    */ package net.sf.RecordEditor.re.jrecord.format;
/*    */ 
/*    */ import javax.swing.table.TableCellEditor;
/*    */ import javax.swing.table.TableCellRenderer;
/*    */ import net.sf.JRecord.Common.IFieldDetail;
/*    */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*    */ import net.sf.RecordEditor.utils.swing.common.Editor4Combos;
/*    */ import net.sf.RecordEditor.utils.swing.editors.HtmlField;
/*    */ 
/*    */ public class HtmlEditorFormat
/*    */   implements CellFormat
/*    */ {
/* 13 */   private HtmlField htmlField = new HtmlField();
/*    */   
/*    */   public TableCellRenderer getTableCellRenderer(IFieldDetail fld) {
/* 16 */     return this.htmlField;
/*    */   }
/*    */   
/*    */   public TableCellEditor getTableCellEditor(IFieldDetail fld)
/*    */   {
/* 21 */     return new Editor4Combos(new HtmlField());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public int getFieldHeight()
/*    */   {
/* 28 */     return SwingUtils.COMBO_TABLE_ROW_HEIGHT;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public int getFieldWidth()
/*    */   {
/* 35 */     return -1;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/jrecord/format/HtmlEditorFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */