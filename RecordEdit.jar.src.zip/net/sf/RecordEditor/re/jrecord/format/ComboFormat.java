/*     */ package net.sf.RecordEditor.re.jrecord.format;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import javax.swing.DefaultCellEditor;
/*     */ import javax.swing.table.TableCellEditor;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import net.sf.JRecord.Common.AbstractRecord;
/*     */ import net.sf.JRecord.Common.IFieldDetail;
/*     */ import net.sf.RecordEditor.re.db.Combo.ComboDB;
/*     */ import net.sf.RecordEditor.re.db.Combo.ComboRec;
/*     */ import net.sf.RecordEditor.re.db.Combo.ComboValuesDB;
/*     */ import net.sf.RecordEditor.utils.common.ReConnection;
/*     */ import net.sf.RecordEditor.utils.swing.AbsRowList;
/*     */ import net.sf.RecordEditor.utils.swing.BmKeyedComboBox;
/*     */ import net.sf.RecordEditor.utils.swing.BmKeyedComboBoxRender;
/*     */ import net.sf.RecordEditor.utils.swing.BmKeyedComboModel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ComboFormat
/*     */   implements CellFormat
/*     */ {
/*  42 */   private static HashMap<String, ComboRec>[] map = new HashMap[16];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFieldHeight()
/*     */   {
/*  56 */     return SwingUtils.COMBO_TABLE_ROW_HEIGHT;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getFieldWidth()
/*     */   {
/*  63 */     return -121;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public TableCellEditor getTableCellEditor(IFieldDetail fld)
/*     */   {
/*  71 */     TableCellEditor ret = null;
/*     */     
/*  73 */     ComboRec comboDtls = getCombo(fld.getRecord().getSourceIndex(), fld.getParamater());
/*     */     
/*  75 */     if (comboDtls != null)
/*     */     {
/*  77 */       ret = new DefaultCellEditor(new BmKeyedComboBox(comboDtls.getRows(), true));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*  82 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TableCellRenderer getTableCellRenderer(IFieldDetail fld)
/*     */   {
/*  91 */     TableCellRenderer render = null;
/*  92 */     ComboRec comboDtls = getCombo(fld.getRecord().getSourceIndex(), fld.getParamater());
/*     */     
/*  94 */     if (comboDtls != null) {
/*  95 */       render = new BmKeyedComboBoxRender(new BmKeyedComboModel(comboDtls.getRows()), true);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 100 */     return render;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ComboRec getCombo(int idx, String name)
/*     */   {
/* 110 */     if ((idx < 0) || (idx >= map.length) || (name == null) || ("".equals(name))) {
/* 111 */       return null;
/*     */     }
/*     */     
/* 114 */     if (map[idx] == null) {
/* 115 */       map[idx] = new HashMap();
/*     */     }
/* 117 */     ComboRec ret = (ComboRec)map[idx].get(name);
/*     */     
/* 119 */     if (ret == null) {
/* 120 */       ReConnection con = new ReConnection(idx);
/* 121 */       ComboDB db = new ComboDB();
/* 122 */       db.setConnection(con);
/*     */       
/* 124 */       ret = db.get(name);
/*     */       
/* 126 */       if (ret != null) {
/* 127 */         ComboValuesDB valuesDB = new ComboValuesDB();
/*     */         
/* 129 */         valuesDB.setConnection(con);
/* 130 */         valuesDB.setParams(ret.getComboId());
/*     */         AbsRowList rows;
/* 132 */         AbsRowList rows; if (ret.getColumnType() == 1) {
/* 133 */           rows = new AbsRowList(0, 0, false, false);
/*     */         } else {
/* 135 */           rows = new AbsRowList(0, 1, false, false);
/*     */         }
/* 137 */         rows.loadData(valuesDB.fetchAll());
/* 138 */         ret.setRows(rows);
/*     */         
/* 140 */         map[idx].put(name, ret);
/*     */       }
/*     */     }
/*     */     
/* 144 */     return ret;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/jrecord/format/ComboFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */