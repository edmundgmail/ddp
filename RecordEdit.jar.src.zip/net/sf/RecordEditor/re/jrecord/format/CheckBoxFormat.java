/*    */ package net.sf.RecordEditor.re.jrecord.format;
/*    */ 
/*    */ import javax.swing.table.TableCellEditor;
/*    */ import javax.swing.table.TableCellRenderer;
/*    */ import net.sf.JRecord.Common.IFieldDetail;
/*    */ import net.sf.RecordEditor.utils.swing.CheckboxTableRenderStringBased;
/*    */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CheckBoxFormat
/*    */   implements CellFormat
/*    */ {
/*    */   private CheckboxTableRenderStringBased render;
/*    */   private String yesStr;
/*    */   private String noStr;
/*    */   private boolean defaultVal;
/*    */   
/*    */   public CheckBoxFormat(String yes, String no, boolean defaultValue)
/*    */   {
/* 40 */     this.yesStr = yes;
/* 41 */     this.noStr = no;
/* 42 */     this.defaultVal = defaultValue;
/*    */     
/* 44 */     this.render = new CheckboxTableRenderStringBased(this.yesStr, this.noStr, this.defaultVal, false);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getFieldHeight()
/*    */   {
/* 52 */     return SwingUtils.CHECK_BOX_HEIGHT;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public int getFieldWidth()
/*    */   {
/* 59 */     return SwingUtils.CHECK_BOX_WIDTH;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public TableCellEditor getTableCellEditor(IFieldDetail fld)
/*    */   {
/* 67 */     return new CheckboxTableRenderStringBased(this.yesStr, this.noStr, this.defaultVal, false);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public TableCellRenderer getTableCellRenderer(IFieldDetail fld)
/*    */   {
/* 75 */     return this.render;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/jrecord/format/CheckBoxFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */