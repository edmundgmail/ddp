/*     */ package net.sf.RecordEditor.re.jrecord.format;
/*     */ 
/*     */ import com.zbluesoftware.java.bm.ZDateTableRender;
/*     */ import java.io.PrintStream;
/*     */ import javax.swing.table.TableCellEditor;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import net.sf.JRecord.Common.IFieldDetail;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DateFormat
/*     */   implements CellFormat
/*     */ {
/*  27 */   private static final int CELL_WIDTH = SwingUtils.STANDARD_FONT_WIDTH * 8;
/*     */   
/*  29 */   private ZDateTableRender render = null;
/*     */   
/*     */ 
/*     */ 
/*     */   private boolean useDateFormat;
/*     */   
/*     */ 
/*     */ 
/*     */   private String dateFormat;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public DateFormat(boolean isDateFormat, String dateFormatString)
/*     */   {
/*  44 */     this.useDateFormat = isDateFormat;
/*     */     
/*  46 */     this.dateFormat = dateFormatString;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getFieldHeight()
/*     */   {
/*  53 */     return SwingUtils.COMBO_TABLE_ROW_HEIGHT;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getFieldWidth()
/*     */   {
/*  60 */     return CELL_WIDTH;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public TableCellEditor getTableCellEditor(IFieldDetail fld)
/*     */   {
/*  68 */     return getDateDisplay(fld);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public TableCellRenderer getTableCellRenderer(IFieldDetail fld)
/*     */   {
/*  76 */     if (this.render == null) {
/*  77 */       this.render = getDateDisplay(fld);
/*     */     }
/*  79 */     return this.render;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ZDateTableRender getDateDisplay(IFieldDetail fld)
/*     */   {
/*  88 */     String s = this.dateFormat;
/*  89 */     ZDateTableRender ret = null;
/*     */     
/*  91 */     if (s == null) {
/*  92 */       s = fld.getParamater();
/*     */     }
/*     */     try
/*     */     {
/*  96 */       ret = new ZDateTableRender(this.useDateFormat, s);
/*     */     } catch (Exception e) {
/*  98 */       System.out.println("@@ format > " + s);
/*  99 */       e.printStackTrace();
/*     */     }
/*     */     
/* 102 */     return ret;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/jrecord/format/DateFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */