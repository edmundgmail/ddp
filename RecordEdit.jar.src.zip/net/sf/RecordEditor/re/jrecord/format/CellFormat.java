package net.sf.RecordEditor.re.jrecord.format;

import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import net.sf.JRecord.Common.IFieldDetail;

public abstract interface CellFormat
{
  public static final int USER_RANGE_START = 1000;
  public static final int DEFAULT_USER_RANGE_SIZE = 50;
  public static final int FMT_CHECKBOX = 1;
  public static final int FMT_DATE = 2;
  public static final int FMT_DATE_DMYY = 3;
  public static final int FMT_DATE_YYMD = 4;
  public static final int FMT_COMBO = 15;
  public static final int FMT_BOLD = 21;
  public static final int FMT_COLOR = 22;
  
  public abstract TableCellRenderer getTableCellRenderer(IFieldDetail paramIFieldDetail);
  
  public abstract TableCellEditor getTableCellEditor(IFieldDetail paramIFieldDetail);
  
  public abstract int getFieldWidth();
  
  public abstract int getFieldHeight();
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/jrecord/format/CellFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */