/*    */ package net.sf.RecordEditor.re.jrecord.format;
/*    */ 
/*    */ import javax.swing.table.TableCellEditor;
/*    */ import javax.swing.table.TableCellRenderer;
/*    */ import net.sf.JRecord.Common.IFieldDetail;
/*    */ import net.sf.JRecord.CsvParser.BasicCsvLineParser;
/*    */ import net.sf.JRecord.CsvParser.CsvDefinition;
/*    */ import net.sf.RecordEditor.utils.swing.CsvArray;
/*    */ import net.sf.RecordEditor.utils.swing.CsvArrayTableEditor;
/*    */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CsvArrayFormat
/*    */   implements CellFormat
/*    */ {
/* 31 */   private static int HEIGHT = Math.max(SwingUtils.TABLE_ROW_HEIGHT, Math.min(SwingUtils.CHECK_BOX_HEIGHT, SwingUtils.COMBO_TABLE_ROW_HEIGHT));
/*    */   
/* 33 */   private CsvArray render = null;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getFieldHeight()
/*    */   {
/* 42 */     return HEIGHT;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public int getFieldWidth()
/*    */   {
/* 49 */     return -121;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public TableCellEditor getTableCellEditor(IFieldDetail fld)
/*    */   {
/* 57 */     String[] f = getFields(fld);
/* 58 */     return new CsvArrayTableEditor(f[1], f[2], f[0]);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public TableCellRenderer getTableCellRenderer(IFieldDetail fld)
/*    */   {
/* 66 */     if (this.render == null) {
/* 67 */       String[] f = getFields(fld);
/* 68 */       this.render = new CsvArray(f[1], f[2], f[0]);
/*    */     }
/* 70 */     return this.render;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private String[] getFields(IFieldDetail fld)
/*    */   {
/* 89 */     String s = fld.getParamater();
/* 90 */     BasicCsvLineParser p = BasicCsvLineParser.getInstance();
/*    */     
/* 92 */     return p.split(s.substring(1), new CsvDefinition(s.substring(0, 1), ""), 3);
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/jrecord/format/CsvArrayFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */