/*    */ package net.sf.RecordEditor.re.jrecord.format;
/*    */ 
/*    */ import com.zbluesoftware.java.bm.AbstractGenericCombo;
/*    */ import com.zbluesoftware.java.bm.GenericComboTableRender;
/*    */ import javax.swing.table.TableCellEditor;
/*    */ import javax.swing.table.TableCellRenderer;
/*    */ import net.sf.JRecord.Common.IFieldDetail;
/*    */ import net.sf.RecordEditor.utils.swing.MultiLineCombo;
/*    */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MultiLineFormat
/*    */   implements CellFormat
/*    */ {
/* 31 */   private static int HEIGHT = Math.max(SwingUtils.TABLE_ROW_HEIGHT, Math.min(SwingUtils.CHECK_BOX_HEIGHT, SwingUtils.COMBO_TABLE_ROW_HEIGHT));
/*    */   
/* 33 */   private TableCellRenderer render = null;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getFieldHeight()
/*    */   {
/* 41 */     return HEIGHT;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public int getFieldWidth()
/*    */   {
/* 48 */     return -121;
/*    */   }
/*    */   
/*    */   private GenericComboTableRender getTableRender()
/*    */   {
/* 53 */     new GenericComboTableRender(false, new MultiLineCombo())
/*    */     {
/*    */       protected AbstractGenericCombo getCombo() {
/* 56 */         return new MultiLineCombo();
/*    */       }
/*    */     };
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public TableCellEditor getTableCellEditor(IFieldDetail fld)
/*    */   {
/* 67 */     return getTableRender();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public TableCellRenderer getTableCellRenderer(IFieldDetail fld)
/*    */   {
/* 76 */     if (this.render == null) {
/* 77 */       this.render = getTableRender();
/*    */     }
/* 79 */     return this.render;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/jrecord/format/MultiLineFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */