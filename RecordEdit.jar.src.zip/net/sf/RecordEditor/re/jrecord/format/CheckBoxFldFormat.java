/*    */ package net.sf.RecordEditor.re.jrecord.format;
/*    */ 
/*    */ import javax.swing.table.TableCellEditor;
/*    */ import javax.swing.table.TableCellRenderer;
/*    */ import net.sf.JRecord.Common.IFieldDetail;
/*    */ import net.sf.JRecord.CsvParser.BasicCsvLineParser;
/*    */ import net.sf.JRecord.CsvParser.CsvDefinition;
/*    */ import net.sf.RecordEditor.utils.swing.CheckboxTableRenderStringBased;
/*    */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CheckBoxFldFormat
/*    */   implements CellFormat
/*    */ {
/* 29 */   private CheckboxTableRenderStringBased render = null;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getFieldHeight()
/*    */   {
/* 37 */     return SwingUtils.CHECK_BOX_HEIGHT;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public int getFieldWidth()
/*    */   {
/* 44 */     return SwingUtils.CHECK_BOX_WIDTH;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public TableCellEditor getTableCellEditor(IFieldDetail fld)
/*    */   {
/* 52 */     return getCheckbox(fld);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public TableCellRenderer getTableCellRenderer(IFieldDetail fld)
/*    */   {
/* 60 */     if (this.render == null) {
/* 61 */       this.render = getCheckbox(fld);
/*    */     }
/* 63 */     return this.render;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private CheckboxTableRenderStringBased getCheckbox(IFieldDetail fld)
/*    */   {
/* 72 */     String s = fld.getParamater();
/* 73 */     CheckboxTableRenderStringBased ret = null;
/*    */     
/* 75 */     if (s != null) {
/*    */       try {
/* 77 */         BasicCsvLineParser parser = BasicCsvLineParser.getInstance();
/* 78 */         String line = s.substring(1);
/* 79 */         String delim = s.substring(0, 1);
/*    */         
/* 81 */         CsvDefinition csvDef = new CsvDefinition(delim, "");
/* 82 */         String yesStr = parser.getField(0, line, csvDef);
/* 83 */         String noStr = parser.getField(1, line, csvDef);
/* 84 */         String defaultValue = parser.getField(2, line, csvDef);
/*    */         
/* 86 */         boolean caseSensitive = "Y".equalsIgnoreCase(parser.getField(3, line, csvDef));
/*    */         
/* 88 */         ret = new CheckboxTableRenderStringBased(yesStr, noStr, yesStr.equals(defaultValue), caseSensitive);
/*    */       }
/*    */       catch (Exception e) {
/* 91 */         e.printStackTrace();
/*    */       }
/*    */     }
/* 94 */     return ret;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/jrecord/format/CheckBoxFldFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */