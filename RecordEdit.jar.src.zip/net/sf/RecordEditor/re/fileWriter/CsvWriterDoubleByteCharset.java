/*     */ package net.sf.RecordEditor.re.fileWriter;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Writer;
/*     */ import net.sf.JRecord.Common.CommonBits;
/*     */ import net.sf.JRecord.Common.Conversion;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ 
/*     */ public class CsvWriterDoubleByteCharset extends BaseWriter
/*     */ {
/*     */   private Writer fileWriter;
/*     */   private String fieldSep;
/*     */   private String sep;
/*     */   private String eolString;
/*     */   public final String quote;
/*  20 */   private int lineNo = 0;
/*  21 */   private int fieldNo = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean quoteAllTextFlds;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected CsvWriterDoubleByteCharset(String fileName, String delimiter, String fontName, String quoteStr, boolean quoteAllTextFields, boolean[] includeFields)
/*     */     throws IOException
/*     */   {
/*  38 */     this.quote = quoteStr;
/*  39 */     this.quoteAllTextFlds = quoteAllTextFields;
/*  40 */     setPrintField(includeFields);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  45 */     BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(fileName), 4096);
/*  46 */     if ((fontName == null) || ("".equals(fontName))) {
/*  47 */       this.fileWriter = new OutputStreamWriter(out);
/*     */     } else {
/*  49 */       this.fileWriter = new OutputStreamWriter(out, fontName);
/*     */     }
/*     */     
/*  52 */     this.eolString = CommonBits.getEolString("", fontName);
/*     */     
/*     */ 
/*  55 */     this.fieldSep = delimiter;
/*     */     
/*  57 */     if ("<tab>".equalsIgnoreCase(delimiter))
/*     */     {
/*  59 */       this.fieldSep = "\t";
/*  60 */     } else if ("<space>".equalsIgnoreCase(delimiter)) {
/*  61 */       this.fieldSep = " ";
/*     */     }
/*     */     
/*  64 */     this.sep = "";
/*     */   }
/*     */   
/*     */ 
/*     */   public void newLine()
/*     */     throws IOException
/*     */   {
/*  71 */     this.fileWriter.write(this.eolString);
/*  72 */     this.sep = "";
/*  73 */     this.lineNo += 1;
/*  74 */     this.fieldNo = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void writeFieldHeading(String field)
/*     */     throws IOException
/*     */   {
/*  82 */     if (isFieldToBePrinted(this.fieldNo)) {
/*  83 */       this.fileWriter.write(this.sep);
/*     */       try {
/*  85 */         this.fileWriter.write(field);
/*     */       }
/*     */       catch (Exception e) {}
/*     */       
/*  89 */       this.sep = this.fieldSep;
/*     */     }
/*  91 */     this.fieldNo += 1;
/*  92 */     this.lineNo = -1;
/*     */   }
/*     */   
/*     */ 
/*     */   public final void writeField(String field)
/*     */     throws IOException
/*     */   {
/*  99 */     writeField(field, isNumeric(this.fieldNo));
/*     */   }
/*     */   
/*     */   public void writeField(String field, boolean isNumeric) throws IOException
/*     */   {
/* 104 */     if (isFieldToBePrinted(this.fieldNo))
/*     */     {
/* 106 */       this.fileWriter.write(this.sep);
/*     */       
/* 108 */       if (field != null) {
/* 109 */         if (!isNumeric) {
/* 110 */           if ("".equals(this.quote)) {
/* 111 */             if ((!"".equals(this.fieldSep)) && (field.indexOf(this.fieldSep) >= 0)) {
/* 112 */               StringBuilder b = new StringBuilder(field);
/* 113 */               Conversion.replace(b, this.fieldSep, "");
/* 114 */               Common.logMsgRaw(LangConversion.convert("Warning: on line {0} Field {1} Seperator {2} Dropped", new Object[] { Integer.valueOf(this.lineNo), Integer.valueOf(this.fieldNo), this.fieldSep }), null);
/*     */               
/*     */ 
/*     */ 
/*     */ 
/* 119 */               field = b.toString();
/*     */             }
/* 121 */           } else if (((!"".equals(this.fieldSep)) && (field.indexOf(this.fieldSep) >= 0)) || (this.quoteAllTextFlds) || (field.indexOf("\n") >= 0) || (field.indexOf("\r") >= 0))
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/* 126 */             StringBuffer b = new StringBuffer(field);
/*     */             
/*     */ 
/* 129 */             int j = 0;
/*     */             int pos;
/* 131 */             while ((pos = b.indexOf(this.quote, j)) >= 0) {
/* 132 */               b.insert(pos, this.quote);
/* 133 */               j = pos + 2;
/*     */             }
/*     */             
/* 136 */             field = this.quote;
/*     */           }
/*     */         }
/*     */         
/* 140 */         this.fileWriter.write(field);
/*     */       }
/*     */       
/* 143 */       this.sep = this.fieldSep;
/*     */     }
/* 145 */     this.fieldNo += 1;
/*     */   }
/*     */   
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 152 */     this.fileWriter.close();
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/fileWriter/CsvWriterDoubleByteCharset.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */