/*     */ package net.sf.RecordEditor.re.fileWriter;
/*     */ 
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import net.sf.JRecord.Common.TranslateXmlChars;
/*     */ 
/*     */ public class HtmlWriter
/*     */   extends BaseWriter
/*     */ {
/*  11 */   private boolean newLine = false;
/*     */   
/*     */   private BufferedWriter writer;
/*  14 */   private int lineNo = 0;
/*     */   
/*     */   private final HtmlColors colors;
/*     */   
/*     */   public HtmlWriter(String fileName, boolean tblBorder, HtmlColors colors, String tittle)
/*     */     throws IOException
/*     */   {
/*  21 */     this.colors = colors;
/*     */     
/*     */ 
/*  24 */     this.writer = new BufferedWriter(new FileWriter(fileName), 4096);
/*     */     
/*     */ 
/*  27 */     String bg = bgColor(colors.headingBackground);
/*  28 */     String borderColor = "";
/*  29 */     if (colors.borderColor != null) {
/*  30 */       borderColor = " bordercolor=\"" + colors.borderColor + "\"";
/*     */     }
/*     */     
/*     */ 
/*  34 */     this.writer.write("<html><body" + bgColor(colors.backgroundColor) + ">");
/*  35 */     this.writer.write("<table align=\"CENTER\" border=\"1\" width=\"60%\"><tbody><tr><td><center><font size=\"12pt\">" + tittle + "</font></center></td></tr>" + "</tbody></table>" + "<p>&nbsp;</p><p>&nbsp;</p>");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  41 */     if (tblBorder) {
/*  42 */       this.writer.write("<table BORDER=\"1\" CELLSPACING=\"1\"" + borderColor + "><tr" + bg + ">");
/*     */     } else {
/*  44 */       this.writer.write("<table><tr" + bg + ">");
/*     */     }
/*     */   }
/*     */   
/*     */   public void newLine()
/*     */     throws IOException
/*     */   {
/*  51 */     this.writer.write("</tr>");
/*  52 */     this.writer.newLine();
/*     */     
/*  54 */     this.newLine = true;
/*     */   }
/*     */   
/*     */   public void writeFieldHeading(String field) throws IOException
/*     */   {
/*  59 */     this.writer.write("<th>");
/*  60 */     if (this.colors.headingColor == null) {
/*  61 */       this.writer.write("<b>");
/*  62 */       writeAField(field);
/*  63 */       this.writer.write("</b>");
/*     */     } else {
/*  65 */       this.writer.write("<font color=\"" + this.colors.headingColor + "\"><b>");
/*  66 */       writeAField(field);
/*  67 */       this.writer.write("</b></font>");
/*     */     }
/*  69 */     this.writer.write("</th>");
/*     */   }
/*     */   
/*     */   public void writeField(String field) throws IOException
/*     */   {
/*  74 */     if (this.newLine) {
/*  75 */       String bg = "";
/*  76 */       this.lineNo += 1;
/*     */       
/*  78 */       if (this.lineNo % 2 == 0) {
/*  79 */         bg = bgColor(this.colors.evenBackground);
/*     */       } else {
/*  81 */         bg = bgColor(this.colors.oddBackground);
/*     */       }
/*  83 */       this.writer.write("<tr" + bg + ">");
/*     */     }
/*  85 */     this.writer.write("<td>");
/*  86 */     writeAField(field);
/*  87 */     this.writer.write("</td>");
/*     */   }
/*     */   
/*     */   protected final void writeAField(String field) throws IOException {
/*  91 */     if ((field == null) || ("".equals(field.trim()))) {
/*  92 */       this.writer.write("&nbsp;");
/*     */     } else {
/*  94 */       this.writer.write(TranslateXmlChars.replaceXmlCharsStr(field));
/*     */     }
/*  96 */     this.newLine = false;
/*     */   }
/*     */   
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 102 */     if (!this.newLine) {
/* 103 */       newLine();
/*     */     }
/* 105 */     this.writer.write("</table></body></html>");
/* 106 */     this.writer.close();
/*     */   }
/*     */   
/*     */   private String bgColor(String color) {
/* 110 */     String ret = "";
/* 111 */     if (color != null) {
/* 112 */       ret = " bgcolor=\"" + color + "\"";
/*     */     }
/*     */     
/* 115 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean printAllFields()
/*     */   {
/* 125 */     return true;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/fileWriter/HtmlWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */