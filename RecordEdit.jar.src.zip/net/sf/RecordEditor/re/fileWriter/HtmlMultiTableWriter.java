/*     */ package net.sf.RecordEditor.re.fileWriter;
/*     */ 
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import net.sf.JRecord.Common.IFieldDetail;
/*     */ import net.sf.JRecord.Common.TranslateXmlChars;
/*     */ import net.sf.JRecord.External.ExternalConversion;
/*     */ 
/*     */ public class HtmlMultiTableWriter
/*     */   extends BaseWriter
/*     */ {
/*  13 */   private boolean newRow = false;
/*     */   
/*     */   private BufferedWriter writer;
/*  16 */   private int lineNo = 0;
/*  17 */   private int fieldNo = 1;
/*     */   
/*  19 */   private String recordId = null;
/*     */   private final boolean tblBorder;
/*     */   private final boolean showTxt;
/*     */   private final boolean showHex;
/*     */   private final HtmlColors colors;
/*     */   
/*     */   public HtmlMultiTableWriter(String fileName, boolean tblBorder, boolean showTxt, boolean showHex, HtmlColors colors, String tittle) throws IOException
/*     */   {
/*  27 */     this.tblBorder = tblBorder;
/*  28 */     this.showTxt = showTxt;
/*  29 */     this.showHex = showHex;
/*  30 */     this.colors = colors;
/*     */     
/*     */ 
/*  33 */     this.writer = new BufferedWriter(new FileWriter(fileName), 4096);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  38 */     this.writer.write("<html><body" + bgColor(colors.backgroundColor) + ">");
/*  39 */     this.writer.write("</head><body size=\"1\" bgcolor=\"#E6E7FF\"><table align=\"CENTER\" border=\"1\" width=\"60%\"><tbody><tr><td><center><font size=\"12pt\">" + tittle + "</font></center></td></tr>" + "</tbody></table>" + "<p>&nbsp;</p><p>&nbsp;</p>");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void newLine()
/*     */     throws IOException
/*     */   {
/*  50 */     this.writer.write("</table>");
/*  51 */     this.writer.newLine();
/*     */     
/*  53 */     this.lineNo += 1;
/*  54 */     this.newRow = true;
/*     */   }
/*     */   
/*     */   public void rowHeading() throws IOException {
/*  58 */     String bg = bgColor(this.colors.headingBackground);
/*  59 */     String borderColor = "";
/*  60 */     String recId = this.recordId;
/*  61 */     if (this.colors.borderColor != null) {
/*  62 */       borderColor = " bordercolor=\"" + this.colors.borderColor + "\"";
/*     */     }
/*  64 */     if (recId == null) {
/*  65 */       recId = Integer.toString(this.lineNo);
/*     */     }
/*     */     
/*  68 */     this.writer.write("<p>&nbsp;</p><p><b>Record: " + recId + "</b></p>");
/*  69 */     if (this.tblBorder) {
/*  70 */       this.writer.write("<table BORDER=\"1\" CELLSPACING=\"1\"" + borderColor + "><tr" + bg + ">");
/*     */     } else {
/*  72 */       this.writer.write("<table><tr" + bg + ">");
/*     */     }
/*     */     
/*  75 */     this.writer.write(fmtHeading("Field Name") + fmtHeading("Position") + fmtHeading("Length") + fmtHeading("Type") + fmtHeading("Field Value"));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  82 */     if (this.showTxt) {
/*  83 */       this.writer.write(fmtHeading("Text Value"));
/*     */     }
/*  85 */     if (this.showHex) {
/*  86 */       this.writer.write(fmtHeading("Hex Value"));
/*     */     }
/*  88 */     this.writer.write("</tr>");
/*  89 */     this.writer.newLine();
/*  90 */     this.newRow = false;
/*  91 */     this.fieldNo = 1;
/*     */   }
/*     */   
/*     */   private String fmtHeading(String fldName) { String s;
/*     */     String s;
/*  96 */     if (this.colors.headingColor == null) {
/*  97 */       s = "<th><b>" + fldName + "</b></th>";
/*     */     } else {
/*  99 */       s = "<th><font color=\"" + this.colors.headingColor + "\"><b>" + fldName + "</b></th>";
/*     */     }
/* 101 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeFieldHeading(String field)
/*     */     throws IOException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */   public void writeFieldDetails(IFieldDetail fldDetail, String fieldValue, String textValue, String HexValue)
/*     */     throws IOException
/*     */   {
/* 116 */     if (this.newRow) {
/* 117 */       rowHeading();
/*     */     }
/*     */     String bg;
/*     */     String bg;
/* 121 */     if (this.fieldNo++ % 2 == 0) {
/* 122 */       bg = bgColor(this.colors.evenBackground);
/*     */     } else {
/* 124 */       bg = bgColor(this.colors.oddBackground);
/*     */     }
/* 126 */     this.writer.write("<tr" + bg + ">");
/*     */     
/*     */ 
/* 129 */     writeOneField(fldDetail.getName());
/* 130 */     writeOneField(Integer.toString(fldDetail.getPos()));
/* 131 */     if (fldDetail.getLen() >= 0) {
/* 132 */       writeOneField(Integer.toString(fldDetail.getLen()));
/*     */     } else {
/* 134 */       writeOneField(null);
/*     */     }
/*     */     
/* 137 */     this.writer.write("<td>");
/* 138 */     writeAField(ExternalConversion.getTypeAsString(0, fldDetail.getType()));
/* 139 */     this.writer.write(" &nbsp;</td>");
/*     */     
/* 141 */     writeOneField(fieldValue);
/* 142 */     if (this.showTxt) {
/* 143 */       writeOneField(textValue);
/*     */     }
/* 145 */     if (this.showHex) {
/* 146 */       writeOneField(HexValue);
/*     */     }
/* 148 */     this.writer.write("</tr>");
/* 149 */     this.writer.newLine();
/*     */   }
/*     */   
/*     */   public void writeOneField(String field)
/*     */     throws IOException
/*     */   {
/* 155 */     this.writer.write("<td>");
/* 156 */     writeAField(field);
/* 157 */     this.writer.write("</td>");
/*     */   }
/*     */   
/*     */   public void writeField(String field) throws IOException
/*     */   {
/* 162 */     if (this.newRow) {
/* 163 */       rowHeading();
/*     */     }
/* 165 */     this.writer.write("<td>");
/* 166 */     writeAField(field);
/* 167 */     this.writer.write("</td>");
/*     */   }
/*     */   
/*     */   protected final void writeAField(String field) throws IOException {
/* 171 */     if ((field == null) || ("".equals(field.trim()))) {
/* 172 */       this.writer.write("&nbsp;");
/*     */     } else {
/* 174 */       this.writer.write(TranslateXmlChars.replaceXmlCharsStr(field));
/*     */     }
/* 176 */     this.newRow = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void startLevel(boolean indent, String id)
/*     */   {
/*     */     try
/*     */     {
/* 188 */       String indentStr = "";
/* 189 */       if (indent) {
/* 190 */         indentStr = "&nbsp;&nbsp;&nbsp;&nbsp;";
/*     */       }
/* 192 */       this.recordId = id;
/* 193 */       this.writer.write("<table><tr><td>" + indentStr + "</td><td><p>&nbsp;</p>");
/*     */     }
/*     */     catch (IOException e) {
/* 196 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void endLevel()
/*     */   {
/*     */     try
/*     */     {
/* 207 */       this.writer.write("</td></tr></table>");
/*     */     } catch (IOException e) {
/* 209 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 217 */     if (!this.newRow) {
/* 218 */       newLine();
/*     */     }
/* 220 */     this.writer.write("</body></html>");
/* 221 */     this.writer.close();
/*     */   }
/*     */   
/*     */   private String bgColor(String color) {
/* 225 */     String ret = "";
/* 226 */     if (color != null) {
/* 227 */       ret = " bgcolor=\"" + color + "\"";
/*     */     }
/*     */     
/* 230 */     return ret;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/fileWriter/HtmlMultiTableWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */