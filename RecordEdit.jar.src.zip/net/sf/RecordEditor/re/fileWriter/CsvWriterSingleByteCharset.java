/*     */ package net.sf.RecordEditor.re.fileWriter;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import net.sf.JRecord.Common.CommonBits;
/*     */ import net.sf.JRecord.Common.Conversion;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ 
/*     */ public class CsvWriterSingleByteCharset
/*     */   extends BaseWriter
/*     */ {
/*  15 */   private static final byte[] noBytes = new byte[0];
/*     */   private OutputStream fileWriter;
/*     */   private String fieldSep;
/*     */   private byte[] fieldSepByte;
/*     */   private byte[] sep;
/*     */   private byte[] eolBytes;
/*     */   private String font;
/*  22 */   public final String quote; private int lineNo = 0;
/*  23 */   private int fieldNo = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean quoteAllTextFlds;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected CsvWriterSingleByteCharset(String fileName, String delimiter, String fontName, String quoteStr, boolean quoteAllTextFields, boolean[] includeFields)
/*     */     throws IOException
/*     */   {
/*  40 */     this.font = fontName;
/*  41 */     this.quote = quoteStr;
/*  42 */     this.quoteAllTextFlds = quoteAllTextFields;
/*  43 */     setPrintField(includeFields);
/*     */     
/*  45 */     this.fileWriter = new BufferedOutputStream(new FileOutputStream(fileName), 4096);
/*     */     
/*     */ 
/*     */ 
/*  49 */     this.eolBytes = CommonBits.getEolBytes(null, "", this.font);
/*     */     
/*  51 */     this.fieldSepByte = Conversion.getBytes(delimiter, this.font);
/*  52 */     this.fieldSep = delimiter;
/*     */     
/*  54 */     if ("<tab>".equalsIgnoreCase(delimiter)) {
/*  55 */       this.fieldSepByte = Conversion.getBytes("\t", this.font);
/*  56 */       this.fieldSep = "\t";
/*  57 */     } else if ("<space>".equalsIgnoreCase(delimiter)) {
/*  58 */       this.fieldSepByte = Conversion.getBytes(" ", this.font);
/*  59 */       this.fieldSep = " ";
/*  60 */     } else if ((delimiter != null) && (delimiter.toLowerCase().startsWith("x'"))) {
/*     */       try {
/*  62 */         this.fieldSepByte = new byte[1];
/*  63 */         this.fieldSepByte[0] = Conversion.getByteFromHexString(delimiter);
/*     */         try {
/*  65 */           this.fieldSep = new String(this.fieldSepByte);
/*     */         } catch (Exception e) {
/*  67 */           this.fieldSep = "";
/*     */         }
/*     */       } catch (Exception e) {
/*  70 */         Common.logMsg("Invalid Hex Seperator", null);
/*  71 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */     
/*  75 */     this.sep = noBytes;
/*     */   }
/*     */   
/*     */ 
/*     */   public void newLine()
/*     */     throws IOException
/*     */   {
/*  82 */     this.fileWriter.write(this.eolBytes);
/*  83 */     this.sep = noBytes;
/*  84 */     this.lineNo += 1;
/*  85 */     this.fieldNo = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void writeFieldHeading(String field)
/*     */     throws IOException
/*     */   {
/*  93 */     if (isFieldToBePrinted(this.fieldNo)) {
/*  94 */       this.fileWriter.write(this.sep);
/*     */       try {
/*  96 */         this.fileWriter.write(Conversion.getBytes(field, this.font));
/*     */       }
/*     */       catch (Exception e) {}
/*     */       
/* 100 */       this.sep = this.fieldSepByte;
/*     */     }
/* 102 */     this.fieldNo += 1;
/* 103 */     this.lineNo = -1;
/*     */   }
/*     */   
/*     */ 
/*     */   public final void writeField(String field)
/*     */     throws IOException
/*     */   {
/* 110 */     writeField(field, isNumeric(this.fieldNo));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void writeField(String field, boolean isNumeric)
/*     */     throws IOException
/*     */   {
/* 118 */     if (isFieldToBePrinted(this.fieldNo))
/*     */     {
/* 120 */       this.fileWriter.write(this.sep);
/*     */       
/* 122 */       if (field != null) {
/* 123 */         if (!isNumeric) {
/* 124 */           if ("".equals(this.quote)) {
/* 125 */             if ((!"".equals(this.fieldSep)) && (field.indexOf(this.fieldSep) >= 0)) {
/* 126 */               StringBuilder b = new StringBuilder(field);
/* 127 */               Conversion.replace(b, this.fieldSep, "");
/* 128 */               Common.logMsgRaw(LangConversion.convert("Warning: on line {0} Field {1} Seperator {2} Dropped", new Object[] { Integer.valueOf(this.lineNo), Integer.valueOf(this.fieldNo), this.fieldSep }), null);
/*     */               
/*     */ 
/*     */ 
/*     */ 
/* 133 */               field = b.toString();
/*     */             }
/* 135 */           } else if (((!"".equals(this.fieldSep)) && (field.indexOf(this.fieldSep) >= 0)) || (this.quoteAllTextFlds) || (field.indexOf("\n") >= 0) || (field.indexOf("\r") >= 0))
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/* 140 */             StringBuffer b = new StringBuffer(field);
/*     */             
/*     */ 
/* 143 */             int j = 0;
/*     */             int pos;
/* 145 */             while ((pos = b.indexOf(this.quote, j)) >= 0) {
/* 146 */               b.insert(pos, this.quote);
/* 147 */               j = pos + 2;
/*     */             }
/*     */             
/*     */ 
/* 151 */             field = this.quote;
/*     */           }
/*     */         }
/*     */         
/* 155 */         this.fileWriter.write(Conversion.getBytes(field, this.font));
/*     */       }
/*     */       
/* 158 */       this.sep = this.fieldSepByte;
/*     */     }
/* 160 */     this.fieldNo += 1;
/*     */   }
/*     */   
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 167 */     this.fileWriter.close();
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/fileWriter/CsvWriterSingleByteCharset.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */