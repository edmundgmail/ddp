/*    */ package net.sf.RecordEditor.re.fileWriter;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import net.sf.JRecord.Common.IFieldDetail;
/*    */ 
/*    */ 
/*    */ public abstract class BaseWriter
/*    */   implements FieldWriter
/*    */ {
/* 10 */   private boolean[] numericFields = null;
/*    */   private boolean[] printField;
/* 12 */   private int numberOfInitialFields = 0;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void writeFieldDetails(IFieldDetail fldDetail, String fieldValue, String textValue, String HexValue)
/*    */     throws IOException
/*    */   {
/* 23 */     writeField(fieldValue);
/*    */   }
/*    */   
/*    */   public final void setNumericFields(boolean[] numericFields)
/*    */   {
/* 28 */     this.numericFields = numericFields;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void startLevel(boolean indent, String id) {}
/*    */   
/*    */ 
/*    */ 
/*    */   public void endLevel() {}
/*    */   
/*    */ 
/*    */ 
/*    */   public void writeField(String field, boolean isNumeric)
/*    */     throws IOException
/*    */   {
/* 44 */     writeField(field);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean printAllFields()
/*    */   {
/* 52 */     return false;
/*    */   }
/*    */   
/*    */ 
/*    */   public final boolean isFieldToBePrinted(int fldNo)
/*    */   {
/* 58 */     return (this.printField == null) || (fldNo - this.numberOfInitialFields >= this.printField.length) || (fldNo < this.numberOfInitialFields) || (this.printField[(fldNo - this.numberOfInitialFields)] != 0);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected final boolean isNumeric(int fieldNo)
/*    */   {
/* 65 */     return (this.numericFields != null) && (fieldNo >= this.numberOfInitialFields) && (fieldNo - this.numberOfInitialFields < this.numericFields.length) && (this.numericFields[(fieldNo - this.numberOfInitialFields)] != 0);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected final int adjustFieldNo(int fieldNo)
/*    */   {
/* 72 */     return fieldNo - this.numberOfInitialFields;
/*    */   }
/*    */   
/*    */   public void setupInitialFields(int numberOfInitialFields, int[] levelSizes)
/*    */   {
/* 77 */     this.numberOfInitialFields = numberOfInitialFields;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public final void setPrintField(boolean[] printField)
/*    */   {
/* 84 */     this.printField = printField;
/*    */   }
/*    */   
/*    */   public final void setPrintField(int idx, boolean include)
/*    */   {
/* 89 */     if ((this.printField != null) && (idx >= 0) && (idx < this.printField.length)) {
/* 90 */       this.printField[idx] = include;
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/fileWriter/BaseWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */