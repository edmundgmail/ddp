/*    */ package net.sf.RecordEditor.re.fileWriter;
/*    */ 
/*    */ public class HtmlColors {
/*  4 */   public static final HtmlColors BOORING_COLORS = new HtmlColors(null, null, null, null, null, null);
/*  5 */   public static final HtmlColors STANDARD_COLORS = new HtmlColors(null, "#DADADA", "#F3F3F3", null, null, null);
/*  6 */   public static final HtmlColors MONEY_COLORS = new HtmlColors(null, "#CEC6B5", "#FFFBF0", "#DEE7DE", null, null);
/*  7 */   public static final HtmlColors BRIGHT_COLORS = new HtmlColors("#E6E7FF", "#0000FF", "#FFFFB0", "#FFFFE0", "#FF0000", "#FFFFFF");
/*    */   public final String backgroundColor;
/*    */   public final String headingBackground;
/*    */   public final String evenBackground;
/*    */   public final String oddBackground;
/*    */   public final String borderColor;
/*    */   public final String headingColor;
/*    */   
/*    */   public HtmlColors(String backgroundColor, String headingBackground, String evenBackground, String oddColor, String borderColor, String headingColor) {
/* 16 */     this.backgroundColor = backgroundColor;
/* 17 */     this.headingBackground = headingBackground;
/* 18 */     this.evenBackground = evenBackground;
/* 19 */     this.oddBackground = oddColor;
/* 20 */     this.borderColor = borderColor;
/* 21 */     this.headingColor = headingColor;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/fileWriter/HtmlColors.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */