/*     */ package net.sf.RecordEditor.re.fileWriter;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import net.sf.JRecord.Common.CommonBits;
/*     */ import net.sf.JRecord.Common.Conversion;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ 
/*     */ public class FixedWriter
/*     */   extends BaseWriter
/*     */ {
/*  14 */   private static final byte[] noBytes = new byte[0];
/*     */   
/*     */   private OutputStream fileWriter;
/*     */   
/*     */   private byte[] fieldSepByte;
/*     */   private byte[] sep;
/*     */   private byte[] eolBytes;
/*     */   private String font;
/*  22 */   private int fieldNo = 0;
/*     */   
/*     */   private final int[] fieldLen;
/*  25 */   private int[] prefixLen = null;
/*     */   
/*     */   public FixedWriter(String fileName, String delimiter, String fontName, int[] fieldLengths, boolean[] includeField) throws IOException
/*     */   {
/*  29 */     this.font = fontName;
/*  30 */     this.fieldLen = fieldLengths;
/*  31 */     setPrintField(includeField);
/*     */     
/*  33 */     this.fileWriter = new BufferedOutputStream(new FileOutputStream(fileName), 4096);
/*     */     
/*     */ 
/*     */ 
/*  37 */     this.eolBytes = CommonBits.getEolBytes(null, "", this.font);
/*     */     
/*  39 */     this.fieldSepByte = Conversion.getBytes(delimiter, this.font);
/*     */     
/*  41 */     if ("<tab>".equalsIgnoreCase(delimiter)) {
/*  42 */       this.fieldSepByte = Conversion.getBytes("\t", this.font);
/*  43 */     } else if ("<space>".equalsIgnoreCase(delimiter)) {
/*  44 */       this.fieldSepByte = Conversion.getBytes(" ", this.font);
/*  45 */     } else if ((delimiter != null) && (delimiter.toLowerCase().startsWith("x'"))) {
/*     */       try {
/*  47 */         this.fieldSepByte = new byte[1];
/*  48 */         this.fieldSepByte[0] = Conversion.getByteFromHexString(delimiter);
/*     */       }
/*     */       catch (Exception e) {
/*  51 */         Common.logMsg("Invalid Hex Seperator", null);
/*  52 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */     
/*  56 */     this.sep = noBytes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setupInitialFields(int numberOfInitialFields, int[] levelSizes)
/*     */   {
/*  65 */     this.prefixLen = levelSizes;
/*  66 */     super.setupInitialFields(numberOfInitialFields, levelSizes);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void newLine()
/*     */     throws IOException
/*     */   {
/*  74 */     this.fileWriter.write(this.eolBytes);
/*  75 */     this.sep = noBytes;
/*     */     
/*  77 */     this.fieldNo = 0;
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeFieldHeading(String field)
/*     */     throws IOException
/*     */   {
/*  84 */     if (isFieldToBePrinted(this.fieldNo)) {
/*  85 */       this.fileWriter.write(this.sep);
/*     */       try
/*     */       {
/*  88 */         this.fileWriter.write(Conversion.getBytes(pad(field, getFieldLength(this.fieldNo, field.length()), isNumeric(this.fieldNo)), this.font));
/*     */ 
/*     */ 
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */ 
/*  95 */         e.printStackTrace();
/*     */       }
/*  97 */       this.sep = this.fieldSepByte;
/*     */     }
/*     */     
/* 100 */     this.fieldNo += 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void writeField(String field)
/*     */     throws IOException
/*     */   {
/* 108 */     writeField(field, isNumeric(this.fieldNo));
/*     */   }
/*     */   
/*     */   public void writeField(String field, boolean isNumeric) throws IOException
/*     */   {
/* 113 */     if (isFieldToBePrinted(this.fieldNo)) {
/* 114 */       this.fileWriter.write(this.sep);
/*     */       
/* 116 */       if (field == null) {
/* 117 */         field = "";
/*     */       }
/*     */       
/* 120 */       this.fileWriter.write(Conversion.getBytes(pad(field, getFieldLength(this.fieldNo, field.length()), isNumeric), this.font));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 126 */       this.sep = this.fieldSepByte;
/*     */     }
/* 128 */     this.fieldNo += 1;
/*     */   }
/*     */   
/*     */   private int getFieldLength(int fldNo, int fieldLength) {
/* 132 */     int ret = fieldLength;
/*     */     
/* 134 */     if ((this.prefixLen != null) && (fldNo < this.prefixLen.length)) {
/* 135 */       if (fieldLength > this.prefixLen[fldNo]) {
/* 136 */         this.prefixLen[fldNo] = fieldLength;
/*     */       }
/* 138 */       ret = this.prefixLen[fldNo];
/*     */     } else {
/* 140 */       int idx = adjustFieldNo(this.fieldNo);
/* 141 */       if (idx < this.fieldLen.length) {
/* 142 */         if (fieldLength > this.fieldLen[idx]) {
/* 143 */           this.fieldLen[idx] = fieldLength;
/*     */         }
/* 145 */         ret = this.fieldLen[idx];
/*     */       }
/*     */     }
/* 148 */     return ret;
/*     */   }
/*     */   
/*     */   private String pad(String val, int len, boolean rightJustified) {
/* 152 */     char[] bld = new char[len];
/*     */     
/*     */ 
/* 155 */     int start = 0;
/*     */     
/* 157 */     if (val == null) {
/* 158 */       val = "";
/*     */     }
/* 160 */     int l = Math.min(len, val.length());
/* 161 */     if (rightJustified) {
/* 162 */       start = len - l;
/*     */     }
/*     */     
/* 165 */     for (int i = 0; i < bld.length; i++) {
/* 166 */       bld[i] = ' ';
/*     */     }
/* 168 */     for (i = 0; i < l; start++) {
/* 169 */       bld[start] = val.charAt(i);i++;
/*     */     }
/*     */     
/* 172 */     return new String(bld, 0, len);
/*     */   }
/*     */   
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 179 */     this.fileWriter.close();
/*     */   }
/*     */   
/*     */   public int[] getColumnWidths()
/*     */   {
/* 184 */     int st = 0;
/* 185 */     int diff = 0;
/* 186 */     int[] ret; int[] ret; if (this.prefixLen == null) {
/* 187 */       ret = new int[this.fieldLen.length];
/*     */     } else {
/* 189 */       ret = new int[this.prefixLen.length + this.fieldLen.length];
/* 190 */       System.arraycopy(this.prefixLen, 0, ret, 0, this.prefixLen.length);
/* 191 */       st = this.prefixLen.length;
/* 192 */       diff = st;
/*     */     }
/*     */     
/* 195 */     for (int i = 0; i < this.fieldLen.length; i++) {
/* 196 */       if (isFieldToBePrinted(i + diff)) {
/* 197 */         ret[(st++)] = this.fieldLen[i];
/*     */       }
/*     */     }
/*     */     
/* 201 */     return ret;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/fileWriter/FixedWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */