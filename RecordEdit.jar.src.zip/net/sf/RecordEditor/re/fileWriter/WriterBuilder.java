/*    */ package net.sf.RecordEditor.re.fileWriter;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import net.sf.JRecord.Common.Conversion;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WriterBuilder
/*    */ {
/*    */   public static FieldWriter newCsvWriter(String fileName, String delimiter, String fontName, String quoteStr, boolean quoteAllTextFields, boolean[] includeFields)
/*    */     throws IOException
/*    */   {
/* 13 */     if (Conversion.isMultiByte(fontName)) {
/* 14 */       return new CsvWriterDoubleByteCharset(fileName, delimiter, fontName, quoteStr, quoteAllTextFields, includeFields);
/*    */     }
/* 16 */     return new CsvWriterSingleByteCharset(fileName, delimiter, fontName, quoteStr, quoteAllTextFields, includeFields);
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/fileWriter/WriterBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */