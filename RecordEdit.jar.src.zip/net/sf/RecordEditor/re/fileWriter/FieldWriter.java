package net.sf.RecordEditor.re.fileWriter;

import java.io.IOException;
import net.sf.JRecord.Common.IFieldDetail;

public abstract interface FieldWriter
{
  public abstract void newLine()
    throws IOException;
  
  public abstract void writeFieldHeading(String paramString)
    throws IOException;
  
  public abstract void writeFieldDetails(IFieldDetail paramIFieldDetail, String paramString1, String paramString2, String paramString3)
    throws IOException;
  
  public abstract void writeField(String paramString)
    throws IOException;
  
  public abstract void close()
    throws IOException;
  
  public abstract void setNumericFields(boolean[] paramArrayOfBoolean);
  
  public abstract boolean isFieldToBePrinted(int paramInt);
  
  public abstract void setPrintField(int paramInt, boolean paramBoolean);
  
  public abstract void setupInitialFields(int paramInt, int[] paramArrayOfInt);
  
  public abstract void startLevel(boolean paramBoolean, String paramString);
  
  public abstract void endLevel();
  
  public abstract boolean printAllFields();
  
  public abstract void writeField(String paramString, boolean paramBoolean)
    throws IOException;
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/fileWriter/FieldWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */