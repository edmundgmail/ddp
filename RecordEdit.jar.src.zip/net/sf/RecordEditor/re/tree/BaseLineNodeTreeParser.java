/*    */ package net.sf.RecordEditor.re.tree;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import net.sf.RecordEditor.re.file.FileView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class BaseLineNodeTreeParser
/*    */ {
/*    */   public LineNode parse(FileView view)
/*    */   {
/* 17 */     LineNode root = new LineNode("File", view, -1);
/*    */     
/* 19 */     parseAppend(view, root);
/*    */     
/* 21 */     return root;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void parseAppend(FileView view, LineNode node)
/*    */   {
/* 28 */     parseAppend(view, node, 0, view.getRowCount() - 1);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public abstract void parseAppend(FileView paramFileView, LineNode paramLineNode, int paramInt1, int paramInt2);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected ArrayList<LineNode> buildExisting(LineNode root, int start, int end)
/*    */   {
/* 45 */     ArrayList<LineNode> existing = new ArrayList();
/* 46 */     LineNode node = (LineNode)root.getNextNode();
/*    */     
/* 48 */     for (int i = start; i <= end; i++) {
/* 49 */       existing.add(null);
/*    */     }
/*    */     
/* 52 */     while ((node != null) && (node.getLineNumber() <= end)) {
/* 53 */       if (node.getLineNumber() >= start) {
/* 54 */         existing.set(node.getLineNumber() - start, node);
/*    */       }
/* 56 */       node = (LineNode)node.getNextNode();
/*    */     }
/*    */     
/*    */ 
/* 60 */     return existing;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected String toString(Object o)
/*    */   {
/* 70 */     String s = "";
/* 71 */     if (o != null) {
/* 72 */       s = o.toString();
/*    */     }
/* 74 */     return s;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/tree/BaseLineNodeTreeParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */