/*     */ package net.sf.RecordEditor.re.tree;
/*     */ 
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail.FieldDetails;
/*     */ import net.sf.RecordEditor.jibx.compare.SortSummary;
/*     */ 
/*     */ public class FieldSummaryDetails
/*     */ {
/*     */   public static final int OP_NONE = 0;
/*     */   public static final int OP_SUM = 1;
/*     */   public static final int OP_MAX = 3;
/*     */   public static final int OP_MIN = 2;
/*     */   public static final int OP_AVE = 4;
/*  15 */   public static final String[] OPERATOR_NAMES = new String[5];
/*     */   public static final String[] FOREIGN_OPERATOR_NAMES;
/*     */   
/*  18 */   static { OPERATOR_NAMES[0] = "";
/*  19 */     OPERATOR_NAMES[1] = "Sum";
/*  20 */     OPERATOR_NAMES[2] = "Minimum";
/*  21 */     OPERATOR_NAMES[3] = "Maximum";
/*  22 */     OPERATOR_NAMES[4] = "Average";
/*     */     
/*  24 */     FOREIGN_OPERATOR_NAMES = (String[])OPERATOR_NAMES.clone();
/*     */     
/*  26 */     net.sf.RecordEditor.utils.lang.LangConversion.convertComboItms("Sum Operators", FOREIGN_OPERATOR_NAMES);
/*     */   }
/*     */   
/*     */   private AbstractLayoutDetails layout;
/*  30 */   private int recordIndex = 0;
/*     */   private int[] operator;
/*     */   
/*     */   public FieldSummaryDetails(AbstractLayoutDetails recordLayout) {
/*  34 */     int max = 1;
/*  35 */     this.layout = recordLayout;
/*  36 */     for (int i = 0; i < this.layout.getRecordCount(); i++) {
/*  37 */       max = Math.max(max, this.layout.getRecord(i).getFieldCount());
/*     */     }
/*     */     
/*  40 */     this.operator = new int[max];
/*  41 */     setOperator(0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getType(int idx)
/*     */   {
/*  50 */     return this.layout.getRecord(this.recordIndex).getField(idx).getType();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getFieldName(int idx)
/*     */   {
/*  59 */     return this.layout.getRecord(this.recordIndex).getField(idx).getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getOperator(int idx)
/*     */   {
/*  68 */     if (idx < this.operator.length) {
/*  69 */       return this.operator[idx];
/*     */     }
/*  71 */     return 0;
/*     */   }
/*     */   
/*     */   public final void setOperator(int idx, int newOption) {
/*  75 */     this.operator[idx] = newOption;
/*     */   }
/*     */   
/*     */   public final int getFieldCount() {
/*  79 */     return this.layout.getRecord(this.recordIndex).getFieldCount();
/*     */   }
/*     */   
/*     */   public final int getRecordIndex() {
/*  83 */     return this.recordIndex;
/*     */   }
/*     */   
/*     */   public final void setRecordIndex(int layoutIndex) {
/*  87 */     if (this.recordIndex != layoutIndex) {
/*  88 */       setOperator(0);
/*  89 */       this.recordIndex = layoutIndex;
/*     */     }
/*     */   }
/*     */   
/*     */   public final void setOperator(int op)
/*     */   {
/*  95 */     for (int i = 0; i < this.operator.length; i++) {
/*  96 */       this.operator[i] = 0;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final SortSummary[] getSummary()
/*     */   {
/* 108 */     int size = 0;
/* 109 */     for (int i = 0; i < this.operator.length; i++) {
/* 110 */       if (this.operator[i] != 0) {
/* 111 */         size++;
/*     */       }
/*     */     }
/*     */     
/* 115 */     SortSummary[] ret = new SortSummary[size];
/*     */     
/* 117 */     int j = 0;
/* 118 */     for (i = 0; i < this.operator.length; i++) {
/* 119 */       if (this.operator[i] != 0) {
/* 120 */         ret[j] = new SortSummary();
/* 121 */         ret[j].fieldName = getFieldName(i);
/* 122 */         ret[(j++)].operator = OPERATOR_NAMES[getOperator(i)];
/*     */       }
/*     */     }
/*     */     
/* 126 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setSummary(int recordIdx, SortSummary[] summary)
/*     */   {
/* 137 */     if (summary != null) {
/* 138 */       for (int i = 0; i < summary.length; i++) {
/* 139 */         int idx = this.layout.getRecord(recordIdx).getFieldIndex(summary[i].fieldName);
/*     */         
/* 141 */         if (idx >= 0) {
/* 142 */           int op = 0;
/* 143 */           for (int j = 0; j < OPERATOR_NAMES.length; j++) {
/* 144 */             if (OPERATOR_NAMES[j].equalsIgnoreCase(summary[i].operator)) {
/* 145 */               op = j;
/* 146 */               break;
/*     */             }
/*     */           }
/*     */           
/* 150 */           this.operator[idx] = op;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/tree/FieldSummaryDetails.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */