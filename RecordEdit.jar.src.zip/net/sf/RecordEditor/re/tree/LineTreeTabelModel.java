/*     */ package net.sf.RecordEditor.re.tree;
/*     */ 
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.tree.MutableTreeNode;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail.FieldDetails;
/*     */ import net.sf.RecordEditor.re.file.AbstractChangeNotify;
/*     */ import net.sf.RecordEditor.re.file.AbstractLineNode;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.swing.treeTable.AbstractTreeTableModel;
/*     */ import net.sf.RecordEditor.utils.swing.treeTable.TreeTableModel;
/*     */ import net.sf.RecordEditor.utils.swing.treeTable.TreeTableNotify;
/*     */ 
/*     */ public class LineTreeTabelModel extends AbstractTreeTableModel implements TreeTableNotify
/*     */ {
/*  19 */   private static final String MAP_KEY = LangConversion.convert(5, "Map Key");
/*  20 */   private static final String TREE = LangConversion.convert(5, "Tree");
/*     */   
/*     */   private static final int MAP_SKIP_COLUMNS = 3;
/*     */   
/*     */   private static final int MAP_SKIP_COLUMN = 2;
/*     */   
/*  26 */   private int defaultPreferedIndex = 0;
/*  27 */   private int maxNumColumns = -1;
/*     */   private int columnShift;
/*  29 */   private int treeColumn = 1;
/*     */   
/*     */   private final int skipColumns;
/*  32 */   private int recordIndex = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private AbstractLayoutDetails layout;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private AbstractChangeNotify notify;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public LineTreeTabelModel(AbstractChangeNotify changeNotify, AbstractLineNode rootNode, int columnsToSkip, boolean showKey)
/*     */   {
/*  49 */     super(rootNode);
/*     */     
/*  51 */     this.columnShift = columnsToSkip;
/*  52 */     this.notify = changeNotify;
/*     */     
/*  54 */     this.layout = rootNode.getLayout();
/*     */     
/*  56 */     if (showKey) {
/*  57 */       this.skipColumns = 3;
/*     */     } else {
/*  59 */       this.skipColumns = 2;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColumnCount()
/*     */   {
/* 115 */     if (this.recordIndex == this.layout.getRecordCount()) {
/* 116 */       if (this.maxNumColumns < 0) {
/* 117 */         for (int i = 0; i < this.layout.getRecordCount(); i++) {
/* 118 */           this.maxNumColumns = Math.max(this.maxNumColumns, this.layout.getRecord(i).getFieldCount());
/*     */         }
/*     */       }
/* 121 */       return this.maxNumColumns + this.skipColumns - this.columnShift;
/*     */     }
/* 123 */     return getRecord().getFieldCount() + this.skipColumns - this.columnShift;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getColumnName(int column)
/*     */   {
/* 136 */     if (column == this.treeColumn)
/* 137 */       return TREE;
/* 138 */     if ((this.skipColumns == 3) && (column == 2))
/* 139 */       return MAP_KEY;
/* 140 */     if (column < this.skipColumns) {
/* 141 */       return " ";
/*     */     }
/* 143 */     int col = adjustColumn(null, column);
/* 144 */     AbstractRecordDetail rec = getRecord();
/* 145 */     if (col >= rec.getFieldCount()) {
/* 146 */       return " ";
/*     */     }
/* 148 */     return rec.getField(col).getName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Class<?> getColumnClass(int column)
/*     */   {
/* 162 */     int col = adjustColumn(null, column);
/* 163 */     if (column == this.treeColumn) {
/* 164 */       return TreeTableModel.class;
/*     */     }
/* 166 */     return super.getColumnClass(col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getValueAt(Object node, int column)
/*     */   {
/* 180 */     AbstractLine rec = ((AbstractLineNode)node).getLine();
/*     */     
/*     */ 
/* 183 */     if ((rec == null) || (column < 2))
/* 184 */       return null;
/* 185 */     int col; int col; if ((this.skipColumns == 3) && (column == 2)) {
/* 186 */       col = 64771;
/*     */     } else {
/* 188 */       col = adjustColumn(rec, column);
/*     */     }
/*     */     try
/*     */     {
/* 192 */       return rec.getField(getRecordIndex(rec), col);
/*     */     } catch (Exception e) {
/* 194 */       e.printStackTrace(); }
/* 195 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCellEditable(Object node, int column)
/*     */   {
/* 205 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValueAt(Object newValue, Object node, int column)
/*     */   {
/* 213 */     AbstractLineNode lNode = (AbstractLineNode)node;
/* 214 */     AbstractLine rec = lNode.getLine();
/* 215 */     int recordIdx = getRecordIndex(rec);
/*     */     
/*     */ 
/* 218 */     if ((rec == null) || (column < 2)) return;
/*     */     int col;
/* 220 */     int col; if ((this.skipColumns == 3) && (column == 2)) {
/* 221 */       col = 64771;
/*     */     } else {
/* 223 */       col = adjustColumn(rec, column);
/*     */     }
/* 225 */     Object oldValue = rec.getField(recordIdx, col);
/*     */     
/* 227 */     if (((newValue != null) || (oldValue != null)) && ((newValue == null) || (!newValue.equals(oldValue))))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 234 */       String eMsg = doFieldUpdate(lNode, rec, recordIdx, col, oldValue, newValue);
/* 235 */       while (eMsg != null) {
/* 236 */         newValue = JOptionPane.showInputDialog(null, eMsg, LangConversion.convert(2, "Conversion Error"), 0, null, null, newValue);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 242 */         eMsg = null;
/* 243 */         if (newValue != null) {
/* 244 */           eMsg = doFieldUpdate(lNode, rec, recordIdx, col, oldValue, newValue);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private String doFieldUpdate(AbstractLineNode lNode, AbstractLine rec, int recordIdx, int col, Object oldValue, Object newValue)
/*     */   {
/* 253 */     String ret = null;
/*     */     try {
/* 255 */       rec.setField(recordIdx, col, newValue);
/* 256 */       if ((oldValue == null) || (!oldValue.equals(rec.getField(recordIdx, col)))) {
/* 257 */         this.notify.setChanged(true);
/*     */       }
/* 259 */       lNode.getView().fireRowUpdated(lNode.getLineNumber(), recordIdx, col, rec);
/*     */     } catch (Exception e) {
/* 261 */       ret = e.getMessage();
/*     */     }
/* 263 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int adjustColumn(AbstractLine rec, int column)
/*     */   {
/* 274 */     return this.layout.getAdjFieldNumber(getRecordIndex(rec), column - this.skipColumns + this.columnShift);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTreeColumn(int newTreeColumn)
/*     */   {
/* 284 */     this.treeColumn = newTreeColumn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private AbstractRecordDetail getRecord()
/*     */   {
/* 292 */     return this.layout.getRecord(getRecordIndex(null));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRecordIndex()
/*     */   {
/* 300 */     return this.recordIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int getRecordIndex(AbstractLine rec)
/*     */   {
/* 309 */     if (this.recordIndex < this.layout.getRecordCount())
/* 310 */       return this.recordIndex;
/* 311 */     if (rec == null) {
/* 312 */       return this.defaultPreferedIndex;
/*     */     }
/* 314 */     return rec.getPreferredLayoutIdx();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRecordIndex(int recordIndex)
/*     */   {
/* 323 */     this.recordIndex = recordIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final int getDefaultPreferredIndex()
/*     */   {
/* 330 */     return this.defaultPreferedIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void setDefaultPreferredIndex(int defaultPreferedIndex)
/*     */   {
/* 337 */     this.defaultPreferedIndex = defaultPreferedIndex;
/*     */   }
/*     */   
/*     */   public int getSkipColumns() {
/* 341 */     return this.skipColumns;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void fireTreeNodesInserted(MutableTreeNode node)
/*     */   {
/* 349 */     AbstractLineNode parentNode = (AbstractLineNode)node.getParent();
/* 350 */     if (parentNode != null) {
/* 351 */       int[] ic = { parentNode.getIndex(node) };
/* 352 */       Object[] c = { node };
/* 353 */       fireTreeNodesInserted(parentNode, parentNode.getPath(), ic, c);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void fireTreeNodesRemoved(MutableTreeNode node)
/*     */   {
/* 362 */     AbstractLineNode parentNode = (AbstractLineNode)node.getParent();
/* 363 */     if (parentNode != null) {
/* 364 */       int[] ic = { parentNode.getIndex(node) };
/* 365 */       Object[] c = { node };
/* 366 */       fireTreeNodesRemoved(parentNode, parentNode.getPath(), ic, c);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/tree/LineTreeTabelModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */