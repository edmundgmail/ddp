/*     */ package net.sf.RecordEditor.re.tree;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import net.sf.JRecord.Common.AbstractFieldValue;
/*     */ import net.sf.JRecord.Common.IFieldDetail;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail.FieldDetails;
/*     */ import net.sf.JRecord.Details.ArrayListLine;
/*     */ import net.sf.JRecord.Types.Type;
/*     */ import net.sf.RecordEditor.re.file.AbstractLineNode;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.re.jrecord.types.ReTypeManger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TreeParserField
/*     */   extends BaseLineNodeTreeParser
/*     */   implements AbstractLineNodeTreeParser
/*     */ {
/*     */   private int recordIdx;
/*     */   private int[] fields;
/*     */   private FieldSummaryDetails fldDetails;
/*     */   private LineNode[] levels;
/*     */   
/*     */   public TreeParserField(int recordIndex, int[] groupingFields, FieldSummaryDetails fieldDetails)
/*     */   {
/*  33 */     this.recordIdx = recordIndex;
/*  34 */     this.fields = groupingFields;
/*  35 */     this.fldDetails = fieldDetails;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void parseAppend(FileView view, LineNode root, int start, int end)
/*     */   {
/*  43 */     int startLevel = root.getLevel();
/*  44 */     int numberLevels = this.fields.length - startLevel + 1;
/*  45 */     int arraySize = this.fields.length + 1;
/*  46 */     AbstractRecordDetail rec = view.getLayout().getRecord(this.recordIdx);
/*     */     
/*     */ 
/*     */ 
/*  50 */     end = Math.min(end, view.getRowCount() - 1);
/*     */     
/*  52 */     this.levels = new LineNode[arraySize];
/*     */     
/*     */ 
/*  55 */     String[] currentFields = new String[arraySize];
/*  56 */     String[] parentFields = new String[arraySize];
/*     */     
/*     */ 
/*  59 */     root.removeAllChildren();
/*     */     
/*  61 */     root.setLastLeafLine(end);
/*  62 */     this.levels[0] = root;
/*     */     
/*  64 */     parseAppend_200_SetNodeNames(parentFields, view, start, startLevel);
/*     */     
/*  66 */     parseAppend_300_addNode(view, parentFields, start, 1, start, numberLevels);
/*     */     
/*  68 */     for (int i = start + 1; i <= end; i++) {
/*  69 */       parseAppend_200_SetNodeNames(currentFields, view, i, startLevel);
/*     */       
/*  71 */       int diffAtLevel = 0;
/*     */       
/*     */ 
/*  74 */       while ((diffAtLevel < numberLevels) && (currentFields[diffAtLevel] != null) && (currentFields[diffAtLevel].equals(parentFields[diffAtLevel]))) {
/*  75 */         diffAtLevel++;
/*     */       }
/*     */       
/*     */ 
/*  79 */       parseAppend_100_setLastLine(rec, startLevel, diffAtLevel, i - 1, numberLevels);
/*     */       
/*  81 */       for (int j = 0; j < numberLevels; j++) {
/*  82 */         parentFields[j] = currentFields[j];
/*     */       }
/*  84 */       parseAppend_300_addNode(view, parentFields, start, diffAtLevel + 1, i, numberLevels);
/*     */     }
/*     */     
/*  87 */     parseAppend_100_setLastLine(rec, startLevel, 0, end, numberLevels);
/*     */     
/*     */ 
/*     */ 
/*  91 */     currentFields = null;
/*  92 */     parentFields = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void parseAppend_100_setLastLine(AbstractRecordDetail layout, int startLevel, int diffAtLevel, int lineNum, int numberLevels)
/*     */   {
/* 109 */     for (int j = numberLevels - 1; j >= diffAtLevel; j--) {
/* 110 */       this.levels[j].setLastLeafLine(lineNum);
/*     */       
/* 112 */       ArrayListLine summaryLine = new ArrayListLine(this.levels[diffAtLevel].getLayout(), this.recordIdx, 0);
/*     */       
/*     */ 
/* 115 */       for (int i = 0; i < this.fldDetails.getFieldCount(); i++) {
/* 116 */         Object o = "";
/* 117 */         int op = this.fldDetails.getOperator(i);
/* 118 */         switch (op) {
/*     */         case 1: 
/* 120 */           o = sumFields(this.levels[j], i);
/* 121 */           break;
/*     */         case 3: 
/* 123 */           o = maxFields(this.levels[j], i);
/* 124 */           break;
/*     */         case 2: 
/* 126 */           o = minFields(this.levels[j], i);
/* 127 */           break;
/*     */         case 4: 
/* 129 */           o = average(this.levels[j], i);
/* 130 */           break;
/*     */         }
/*     */         
/*     */         
/*     */         try
/*     */         {
/* 136 */           summaryLine.setField(this.recordIdx, i, o);
/*     */         } catch (Exception e) {
/* 138 */           e.printStackTrace();
/*     */         }
/*     */       }
/* 141 */       String s = "";
/* 142 */       if (j + startLevel == 0) {
/* 143 */         s = "Root";
/* 144 */       } else if (j + startLevel <= this.fields.length) {
/* 145 */         s = layout.getField(this.fields[(j + startLevel - 1)]).getName();
/*     */       }
/*     */       
/*     */ 
/* 149 */       this.levels[j].setSummaryLine(summaryLine, s);
/*     */     }
/*     */   }
/*     */   
/*     */   private BigDecimal sumFields(LineNode node, int idx)
/*     */   {
/* 155 */     BigDecimal sum = new BigDecimal(0);
/*     */     
/*     */ 
/* 158 */     for (int j = 0; j < node.getChildCount(); j++) {
/* 159 */       AbstractLine line = ((AbstractLineNode)node.getChildAt(j)).getLine();
/*     */       try
/*     */       {
/* 162 */         sum = sum.add(line.getFieldValue(this.recordIdx, idx).asBigDecimal());
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/* 166 */     return sum;
/*     */   }
/*     */   
/*     */ 
/*     */   private Double average(LineNode node, int idx)
/*     */   {
/* 172 */     IFieldDetail fld = node.getLayout().getField(this.recordIdx, idx);
/* 173 */     int type = fld.getType();
/*     */     
/* 175 */     double sum = 0.0D;
/*     */     
/* 177 */     FileView view = node.getView();
/* 178 */     int start = node.getFirstLeafLine();
/* 179 */     int end = node.getLastLeafLine();
/*     */     
/*     */ 
/* 182 */     for (int j = start; j <= end; j++) {
/* 183 */       AbstractLine line = view.getLine(j);
/*     */       try
/*     */       {
/* 186 */         sum += line.getFieldValue(this.recordIdx, idx).asDouble();
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/* 190 */     sum /= (end - start + 1);
/*     */     
/* 192 */     if ((type != 17) && (type != 18)) {
/* 193 */       double m = Math.pow(10.0D, fld.getDecimal() + 2);
/* 194 */       sum = Math.round(sum * m) / m;
/*     */     }
/* 196 */     return Double.valueOf(sum);
/*     */   }
/*     */   
/*     */ 
/*     */   private Object maxFields(LineNode node, int idx)
/*     */   {
/* 202 */     boolean numeric = ReTypeManger.getInstance().getType(node.getLayout().getField(this.recordIdx, idx).getType()).isNumeric();
/*     */     
/*     */ 
/* 205 */     if (numeric) {
/* 206 */       BigDecimal initMax = new BigDecimal(Long.MIN_VALUE);
/* 207 */       BigDecimal max = initMax;
/*     */       
/*     */ 
/* 210 */       for (int j = 0; j < node.getChildCount(); j++) {
/* 211 */         AbstractLine line = ((AbstractLineNode)node.getChildAt(j)).getLine();
/*     */         try
/*     */         {
/* 214 */           max = max.max(line.getFieldValue(this.recordIdx, idx).asBigDecimal());
/*     */         } catch (Exception e) {}
/*     */       }
/* 217 */       if (max == initMax) {
/* 218 */         return "";
/*     */       }
/* 220 */       return max;
/*     */     }
/* 222 */     String max = "";
/*     */     
/*     */ 
/*     */ 
/* 226 */     for (int j = 0; j < node.getChildCount(); j++) {
/* 227 */       AbstractLine line = ((AbstractLineNode)node.getChildAt(j)).getLine();
/*     */       try
/*     */       {
/* 230 */         String s = line.getFieldValue(this.recordIdx, idx).asString();
/* 231 */         if (max.compareToIgnoreCase(s) < 0) {
/* 232 */           max = s;
/*     */         }
/*     */       } catch (Exception e) {}
/*     */     }
/* 236 */     return max;
/*     */   }
/*     */   
/*     */ 
/*     */   private Object minFields(LineNode node, int idx)
/*     */   {
/* 242 */     boolean numeric = ReTypeManger.getInstance().getType(node.getLayout().getField(this.recordIdx, idx).getType()).isNumeric();
/*     */     
/*     */ 
/* 245 */     if (numeric) {
/* 246 */       BigDecimal initMin = BigDecimal.valueOf(Long.MAX_VALUE);
/* 247 */       BigDecimal min = initMin;
/*     */       
/*     */ 
/* 250 */       for (int j = 0; j < node.getChildCount(); j++) {
/* 251 */         AbstractLine line = ((AbstractLineNode)node.getChildAt(j)).getLine();
/*     */         try
/*     */         {
/* 254 */           min = min.min(line.getFieldValue(this.recordIdx, idx).asBigDecimal());
/*     */         } catch (Exception e) {}
/*     */       }
/* 257 */       if (min == initMin) {
/* 258 */         return "";
/*     */       }
/* 260 */       return min;
/*     */     }
/* 262 */     String min = "ZZZZ";
/*     */     
/*     */ 
/*     */ 
/* 266 */     for (int j = 0; j < node.getChildCount(); j++) {
/* 267 */       AbstractLine line = ((AbstractLineNode)node.getChildAt(j)).getLine();
/*     */       try
/*     */       {
/* 270 */         String s = line.getFieldValue(this.recordIdx, idx).asString();
/* 271 */         if (min.compareToIgnoreCase(s) > 0) {
/* 272 */           min = s;
/*     */         }
/*     */       } catch (Exception e) {}
/*     */     }
/* 276 */     if (min.equals("ZZZZ")) {
/* 277 */       min = "";
/*     */     }
/* 279 */     return min;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void parseAppend_200_SetNodeNames(String[] values, FileView view, int lineNumber, int startLevel)
/*     */   {
/* 294 */     if (lineNumber >= 0) {
/* 295 */       AbstractLine line = view.getLine(lineNumber);
/*     */       
/* 297 */       for (int j = 0; j < this.fields.length - startLevel; j++) {
/* 298 */         values[j] = toString(line.getField(this.recordIdx, this.fields[(j + startLevel)]));
/*     */       }
/*     */     } else {
/* 301 */       for (int j = 0; j < this.fields.length - startLevel; j++) {
/* 302 */         values[j] = toString("");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void parseAppend_300_addNode(FileView view, String[] parentFields, int start, int changeLevel, int lineNum, int numberLevels)
/*     */   {
/* 318 */     for (int j = changeLevel; j < numberLevels; j++) {
/* 319 */       if (this.levels[j] != null) {
/* 320 */         this.levels[j].setLastLeafLine(lineNum - 1);
/*     */       }
/* 322 */       this.levels[j] = new LineNode(parentFields[(j - 1)], view, -121);
/* 323 */       this.levels[j].setFirstLeafLine(lineNum);
/* 324 */       this.levels[j].setLastLeafLine(lineNum);
/*     */       
/*     */ 
/*     */ 
/* 328 */       this.levels[(j - 1)].add(this.levels[j]);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 335 */     LineNode node = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 342 */     node = new LineNode(parentFields[(numberLevels - 1)], view, lineNum);
/* 343 */     node.setFirstLeafLine(lineNum);
/*     */     
/*     */ 
/* 346 */     this.levels[(numberLevels - 1)].add(node);
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/tree/TreeParserField.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */