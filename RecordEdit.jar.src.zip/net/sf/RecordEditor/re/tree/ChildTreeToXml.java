/*     */ package net.sf.RecordEditor.re.tree;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import net.sf.JRecord.Details.AbstractChildDetails;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.JRecord.Details.AbstractTreeDetails;
/*     */ import net.sf.RecordEditor.re.util.BasicLine2Xml;
/*     */ 
/*     */ public class ChildTreeToXml<Layout extends AbstractLayoutDetails> extends BasicLine2Xml
/*     */ {
/*     */   private Iterator<? extends AbstractLine> lineIterator;
/*     */   private AbstractLayoutDetails layout;
/*     */   
/*     */   public ChildTreeToXml(String fileName, List<? extends AbstractLine> lines)
/*     */   {
/*  21 */     super(fileName);
/*     */     
/*  23 */     this.lineIterator = lines.listIterator();
/*     */     
/*  25 */     super.doWork();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void writeDetails()
/*     */     throws XMLStreamException
/*     */   {
/*  43 */     if (this.lineIterator.hasNext()) {
/*  44 */       AbstractLine line = (AbstractLine)this.lineIterator.next();
/*  45 */       this.layout = line.getLayout();
/*  46 */       if (this.lineIterator.hasNext()) {
/*  47 */         this.writer.writeStartElement("File_" + this.layout.getLayoutName());
/*  48 */         writeNode((AbstractLine)this.lineIterator.next());
/*  49 */         while (this.lineIterator.hasNext()) {
/*  50 */           writeNode((AbstractLine)this.lineIterator.next());
/*     */         }
/*  52 */         this.writer.writeEndElement();
/*     */       } else {
/*  54 */         writeNode(line);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeNode(AbstractLine line)
/*     */     throws XMLStreamException
/*     */   {
/*  77 */     String name = fixName(this.layout.getRecord(line.getPreferredLayoutIdx()).getRecordName().replace(" ", "_"));
/*     */     
/*     */ 
/*     */ 
/*  81 */     boolean leaf = true;
/*  82 */     AbstractTreeDetails children = line.getTreeDetails();
/*     */     
/*  84 */     if (children != null) {
/*  85 */       for (int i = 0; i < children.getChildCount(); i++) {
/*  86 */         if (children.getLines(i).size() > 0) {
/*  87 */           leaf = false;
/*  88 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  93 */     if (leaf) {
/*  94 */       this.writer.writeEmptyElement(name);
/*  95 */       writeAttributes(line);
/*     */     }
/*     */     else {
/*  98 */       this.writer.writeStartElement(name);
/*     */       
/* 100 */       writeAttributes(line);
/*     */       
/* 102 */       for (int i = 0; i < children.getChildCount(); i++) {
/* 103 */         List<? extends AbstractLine> childLines = children.getLines(i);
/* 104 */         if (childLines.size() > 0) {
/* 105 */           if ((childLines.size() > 1) || (children.getChildDetails(i).isRepeated())) {
/* 106 */             writeList(children.getChildName(i) + "s", childLines);
/*     */           } else {
/* 108 */             writeNode((AbstractLine)childLines.get(0));
/*     */           }
/*     */         }
/*     */       }
/* 112 */       this.writer.writeEndElement();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void writeList(String name, List<? extends AbstractLine> lines2write)
/*     */     throws XMLStreamException
/*     */   {
/* 120 */     this.writer.writeStartElement(name);
/* 121 */     for (AbstractLine l : lines2write) {
/* 122 */       writeNode(l);
/*     */     }
/* 124 */     this.writer.writeEndElement();
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/tree/ChildTreeToXml.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */