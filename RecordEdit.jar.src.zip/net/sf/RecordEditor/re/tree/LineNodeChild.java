/*     */ package net.sf.RecordEditor.re.tree;
/*     */ 
/*     */ import java.util.List;
/*     */ import javax.swing.tree.MutableTreeNode;
/*     */ import javax.swing.tree.TreeNode;
/*     */ import net.sf.JRecord.Details.AbstractChildDetails;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.JRecord.Details.AbstractTreeDetails;
/*     */ import net.sf.RecordEditor.re.file.AbstractLineNode;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.swing.BmDefaultMutableTreeNode;
/*     */ import net.sf.RecordEditor.utils.swing.treeTable.TreeTableNotify;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LineNodeChild
/*     */   extends BmDefaultMutableTreeNode
/*     */   implements AbstractLineNode
/*     */ {
/*     */   private FileView view;
/*  35 */   private AbstractLine line = null;
/*     */   
/*     */ 
/*  38 */   private boolean hasChildren = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private AbstractLineNode[] children;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public LineNodeChild(String pNodeName, FileView fileView)
/*     */   {
/*  50 */     super(pNodeName);
/*     */     
/*     */ 
/*  53 */     this.view = fileView;
/*     */     
/*     */ 
/*  56 */     if (this.view.getRowCount() > 0)
/*     */     {
/*     */ 
/*  59 */       for (int i = 0; i < this.view.getRowCount(); i++) {
/*  60 */         int RecordIdx = this.view.getLine(i).getPreferredLayoutIdx();
/*     */         
/*  62 */         String name = getRootName(RecordIdx);
/*     */         
/*  64 */         super.add(new LineNodeChild(name, this.view, this.view.getLine(i)));
/*     */       }
/*  66 */       this.hasChildren = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LineNodeChild(String pNodeName, FileView fileView, AbstractLine theLine)
/*     */   {
/*  81 */     super(pNodeName);
/*     */     
/*  83 */     this.view = fileView;
/*  84 */     this.line = theLine;
/*     */     
/*  86 */     this.view.setNodeForLine(this.line, this);
/*     */     
/*  88 */     if (this.line != null) {
/*  89 */       int recordIdx = this.line.getPreferredLayoutIdx();
/*     */       
/*  91 */       if ((recordIdx >= 0) && (getLayout().getRecord(recordIdx) != null)) {
/*  92 */         AbstractRecordDetail recordDef = getLayout().getRecord(recordIdx);
/*  93 */         this.hasChildren = (recordDef.getChildRecordCount() > 0);
/*     */         
/*  95 */         if (this.hasChildren)
/*     */         {
/*  97 */           AbstractTreeDetails childLineDtls = theLine.getTreeDetails();
/*     */           
/*  99 */           this.children = new AbstractLineNode[recordDef.getChildRecordCount()];
/* 100 */           for (int i = 0; i < recordDef.getChildRecordCount(); i++) {
/* 101 */             AbstractChildDetails childDtls = recordDef.getChildRecord(i);
/* 102 */             if (!childLineDtls.hasLines(i)) {
/* 103 */               this.children[i] = null;
/* 104 */             } else if (childDtls.isRepeated()) {
/* 105 */               this.children[i] = new LineNodeChildList(childLineDtls.getChildName(i) + "'s", fileView, childLineDtls, i);
/* 106 */               add(this.children[i]);
/*     */             } else {
/* 108 */               List<AbstractLine> childLines = childLineDtls.getLines(i);
/* 109 */               this.children[i] = new LineNodeChild(childLineDtls.getChildName(i), fileView, (AbstractLine)childLines.get(0));
/*     */               
/* 111 */               add(this.children[i]);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractLayoutDetails getLayout()
/*     */   {
/* 124 */     return this.view.getLayout();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractLine getLine()
/*     */   {
/* 132 */     return this.line;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLineType()
/*     */   {
/* 141 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public FileView getView()
/*     */   {
/* 149 */     return this.view;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void remove(int index)
/*     */   {
/* 159 */     removeLocal(getChildAt(index));
/* 160 */     super.remove(index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void remove(MutableTreeNode node)
/*     */   {
/* 168 */     super.remove(node);
/* 169 */     removeLocal(node);
/*     */   }
/*     */   
/*     */   private void removeLocal(TreeNode node)
/*     */   {
/* 174 */     if (this.children != null) {
/* 175 */       for (int i = 0; i < this.children.length; i++) {
/* 176 */         if (this.children[i] == node) {
/* 177 */           this.children[i] = null;
/* 178 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSummaryLine(AbstractLine summaryLine, String fieldName) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLineNumber()
/*     */   {
/* 196 */     if (this.line != null) {
/* 197 */       return this.view.indexOf(this.line);
/*     */     }
/*     */     
/* 200 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getDefaultLineNumber()
/*     */   {
/* 209 */     return getLineNumber();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSortValue()
/*     */   {
/* 217 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public AbstractLineNode insert(AbstractLine newLine, int lineNum, int pos)
/*     */   {
/*     */     AbstractLineNode ret;
/*     */     
/*     */     AbstractLineNode ret;
/*     */     
/* 228 */     if (this.line != null) {
/* 229 */       ret = insertStd(newLine, lineNum, pos);
/*     */     } else {
/* 231 */       ret = new LineNodeChild(getRootName(newLine.getPreferredLayoutIdx()), this.view, newLine);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 236 */       super.insert(ret, pos);
/*     */     }
/*     */     
/* 239 */     if ((ret != null) && (this.view.getBaseFile().getTreeTableNotify() != null)) {
/* 240 */       this.view.getBaseFile().getTreeTableNotify().fireTreeNodesInserted(ret);
/*     */     }
/*     */     
/* 243 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */   public AbstractLineNode insertStd(AbstractLine newLine, int lineNum, int pos)
/*     */   {
/* 249 */     AbstractChildDetails childDef = newLine.getTreeDetails().getChildDefinitionInParent();
/* 250 */     AbstractTreeDetails childLineDtls = this.line.getTreeDetails();
/* 251 */     int idx = childDef.getChildIndex();
/* 252 */     AbstractLineNode n = null;
/*     */     
/* 254 */     int count = 0;
/* 255 */     for (int i = 0; i < childDef.getChildIndex(); i++) {
/* 256 */       if (this.children != null) {
/* 257 */         count++;
/*     */       }
/*     */     }
/*     */     
/* 261 */     if (childDef.isRepeated()) {
/* 262 */       if (this.children[idx] == null)
/*     */       {
/* 264 */         this.children[idx] = new LineNodeChildList(childLineDtls.getChildName(idx) + "'s", this.view, childLineDtls, idx);
/* 265 */         super.insert(this.children[idx], count);
/* 266 */         this.view.getTreeTableNotify().fireTreeNodesInserted(this.children[idx]);
/*     */ 
/*     */ 
/*     */       }
/* 270 */       else if (((this.children[idx] instanceof LineNodeChildList)) && (((LineNodeChildList)this.children[idx]).isBuilt()))
/*     */       {
/* 272 */         n = new LineNodeChild(getLayout().getRecord(newLine.getPreferredLayoutIdx()).getRecordName(), this.view, newLine);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 277 */         if ((pos < 0) || (pos >= this.children[idx].getChildCount()))
/*     */         {
/* 279 */           this.children[idx].add(n);
/*     */         }
/*     */         else {
/* 282 */           this.children[idx].insert(n, pos);
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 288 */       n = new LineNodeChild(childLineDtls.getChildName(idx), this.view, newLine);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 293 */       if (this.children[idx] != null) {
/* 294 */         super.remove(this.children[idx]);
/*     */       }
/* 296 */       this.children[idx] = n;
/* 297 */       super.insert(n, count);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 305 */     return n;
/*     */   }
/*     */   
/*     */   private String getRootName(int idx) {
/* 309 */     String name = "root";
/* 310 */     AbstractLayoutDetails layout = getLayout();
/* 311 */     if ((idx >= 0) && (layout != null) && (layout.getRecord(idx) != null)) {
/* 312 */       name = layout.getRecord(idx).getRecordName();
/*     */     }
/* 314 */     return name;
/*     */   }
/*     */   
/*     */   public AbstractLineNode getChildbyCode(int code)
/*     */   {
/* 319 */     return this.children[code];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractLineNode insertNode(int location, String nodeName, FileView fileView, AbstractLine theLine)
/*     */   {
/* 329 */     AbstractLineNode node = new LineNodeChild(nodeName, fileView, theLine);
/* 330 */     insert(node, location);
/* 331 */     return node;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/tree/LineNodeChild.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */