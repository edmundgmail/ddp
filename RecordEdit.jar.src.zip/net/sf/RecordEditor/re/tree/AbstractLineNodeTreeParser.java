package net.sf.RecordEditor.re.tree;

import net.sf.RecordEditor.re.file.FileView;

public abstract interface AbstractLineNodeTreeParser
{
  public abstract LineNode parse(FileView paramFileView);
  
  public abstract void parseAppend(FileView paramFileView, LineNode paramLineNode);
  
  public abstract void parseAppend(FileView paramFileView, LineNode paramLineNode, int paramInt1, int paramInt2);
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/tree/AbstractLineNodeTreeParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */