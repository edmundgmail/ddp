/*     */ package net.sf.RecordEditor.re.tree;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TreeParserRecord
/*     */   extends BaseLineNodeTreeParser
/*     */   implements AbstractLineNodeTreeParser
/*     */ {
/*     */   private int[] parent;
/*     */   private LineNode[] levels;
/*     */   private int[] levelRecordIdx;
/*     */   private ArrayList<LineNode> existing;
/*     */   
/*     */   public TreeParserRecord(int[] parentRecord)
/*     */   {
/*  26 */     this.parent = parentRecord;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void parseAppend(FileView view, LineNode root, int start, int end)
/*     */   {
/*  34 */     int startLevel = root.getLevel();
/*  35 */     int levelIdx = startLevel;
/*  36 */     int numberLevels = this.parent.length + 2;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  42 */     end = Math.min(end, view.getRowCount() - 1);
/*     */     
/*  44 */     this.levels = new LineNode[numberLevels];
/*  45 */     this.levelRecordIdx = new int[numberLevels];
/*  46 */     this.existing = buildExisting(root, start, end);
/*     */     
/*  48 */     int i = startLevel;
/*  49 */     LineNode parentNode = root;
/*     */     AbstractLine line;
/*     */     do {
/*  52 */       this.levels[i] = parentNode;
/*  53 */       line = parentNode.getLine();
/*     */       
/*  55 */       this.levelRecordIdx[i] = -121;
/*  56 */       if (line != null) {
/*  57 */         this.levelRecordIdx[(i--)] = line.getPreferredLayoutIdx();
/*     */       }
/*  59 */       parentNode = (LineNode)parentNode.getParent();
/*  60 */     } while ((i >= 0) && (parentNode != null));
/*     */     
/*  62 */     root.removeAllChildren();
/*  63 */     root.setLastLeafLine(end);
/*     */     
/*  65 */     for (i = start; i <= end; i++) {
/*  66 */       line = view.getLine(i);
/*  67 */       int recordIndex = line.getPreferredLayoutIdx();
/*     */       
/*  69 */       if (recordIndex >= 0) {
/*  70 */         int searchIndex = this.parent[recordIndex];
/*     */         
/*  72 */         int oldLevel = levelIdx;
/*  73 */         levelIdx = 1;
/*  74 */         if (searchIndex >= 0)
/*     */         {
/*  76 */           for (int j = oldLevel; j > 0; j--)
/*     */           {
/*  78 */             if (this.levelRecordIdx[j] == searchIndex) {
/*  79 */               levelIdx = j + 1;
/*  80 */               break;
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*  85 */         for (int j = levelIdx; j < oldLevel; j++) {
/*  86 */           this.levels[j].setLastLeafLine(i - 1);
/*     */         }
/*     */         
/*     */ 
/*  90 */         String name = view.getLayout().getRecord(recordIndex).getRecordName();
/*  91 */         this.levels[levelIdx] = getNode(view, name, start, i);
/*  92 */         this.levelRecordIdx[levelIdx] = recordIndex;
/*  93 */         this.levels[(levelIdx - 1)].add(this.levels[levelIdx]);
/*     */       } else {
/*  95 */         this.levels[levelIdx].add(getNode(view, "", start, i));
/*     */       }
/*     */     }
/*     */     
/*  99 */     for (int j = startLevel; j < levelIdx; j++) {
/* 100 */       this.levels[j].setLastLeafLine(end);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 106 */     this.levels = null;
/* 107 */     this.existing = null;
/* 108 */     this.levelRecordIdx = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final LineNode getNode(FileView view, String name, int start, int lineNum)
/*     */   {
/* 123 */     LineNode node = (LineNode)this.existing.get(lineNum - start);
/* 124 */     if ((node == null) || (!name.equals(node.nodeName))) {
/* 125 */       node = new LineNode(name, view, lineNum);
/*     */     } else {
/* 127 */       node.setLineNumberEtc(lineNum);
/*     */     }
/*     */     
/* 130 */     return node;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/tree/TreeParserRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */