/*    */ package net.sf.RecordEditor.re.tree;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import net.sf.JRecord.Common.AbstractFieldValue;
/*    */ import net.sf.JRecord.Details.AbstractLine;
/*    */ import net.sf.RecordEditor.re.file.FileView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TreeParserXml
/*    */   extends BaseLineNodeTreeParser
/*    */   implements AbstractLineNodeTreeParser
/*    */ {
/* 19 */   private static AbstractLineNodeTreeParser instance = new TreeParserXml();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void parseAppend(FileView view, LineNode root, int start, int end)
/*    */   {
/* 27 */     int level = 0;
/* 28 */     ArrayList<LineNode> levels = new ArrayList();
/* 29 */     ArrayList<LineNode> existing = buildExisting(root, start, end);
/*    */     
/*    */ 
/* 32 */     LineNode current = root;
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 37 */     current.removeAllChildren();
/*    */     
/* 39 */     root.setLastLeafLine(end);
/* 40 */     levels.add(root);
/*    */     
/* 42 */     end = Math.min(end, view.getRowCount() - 1);
/*    */     
/* 44 */     for (int i = Math.max(0, start); i <= end; i++) {
/* 45 */       AbstractLine line = view.getLine(i);
/* 46 */       String name = toString(line.getField(line.getPreferredLayoutIdx(), 0));
/*    */       
/* 48 */       if (name.startsWith("/")) {
/* 49 */         ((LineNode)levels.get(level)).setLastLeafLine(i);
/* 50 */         level = Math.max(0, level - 1);
/* 51 */         current = (LineNode)levels.get(level);
/*    */       } else {
/* 53 */         LineNode node = (LineNode)existing.get(i - start);
/*    */         
/*    */ 
/*    */ 
/*    */ 
/* 58 */         if ((node != null) || (line.getPreferredLayoutIdx() >= 0)) {
/* 59 */           if ((node == null) || (!name.equals(node.nodeName))) {
/* 60 */             node = new LineNode(name, view, i);
/*    */           }
/*    */           else {
/* 63 */             node.setLineNumberEtc(i);
/*    */           }
/*    */           
/*    */ 
/* 67 */           current.add(node);
/* 68 */           if ((!name.startsWith("XML ")) && (!"True".equalsIgnoreCase(line.getFieldValue("Xml~End").asString())))
/*    */           {
/* 70 */             level++;
/* 71 */             node.removeAllChildren();
/* 72 */             if (level < levels.size()) {
/* 73 */               levels.set(level, node);
/*    */             } else {
/* 75 */               levels.add(node);
/*    */             }
/* 77 */             current = node;
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 86 */     for (i = 0; i <= level; i++) {
/* 87 */       ((LineNode)levels.get(level)).setLastLeafLine(end);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static AbstractLineNodeTreeParser getInstance()
/*    */   {
/* 97 */     return instance;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/tree/TreeParserXml.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */