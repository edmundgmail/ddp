/*     */ package net.sf.RecordEditor.re.tree;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Vector;
/*     */ import javax.swing.tree.MutableTreeNode;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.JRecord.Details.AbstractTreeDetails;
/*     */ import net.sf.RecordEditor.re.file.AbstractLineNode;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.swing.BmDefaultMutableTreeNode;
/*     */ import net.sf.RecordEditor.utils.swing.treeTable.TreeTableNotify;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LineNodeChildList
/*     */   extends BmDefaultMutableTreeNode
/*     */   implements AbstractLineNode
/*     */ {
/*     */   public final String nodeName;
/*     */   private FileView view;
/*  31 */   private static final AbstractLine line = null;
/*     */   
/*  33 */   private boolean toBuild = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private AbstractTreeDetails childLineDtls;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int childIdx;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public LineNodeChildList(String pNodeName, FileView fileView, AbstractTreeDetails childLineDetails, int childIndex)
/*     */   {
/*  50 */     super(pNodeName);
/*     */     
/*  52 */     this.nodeName = pNodeName;
/*  53 */     this.view = fileView;
/*  54 */     this.childLineDtls = childLineDetails;
/*  55 */     this.childIdx = childIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractLayoutDetails getLayout()
/*     */   {
/*  63 */     return this.view.getLayout();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractLine getLine()
/*     */   {
/*  71 */     return line;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLineType()
/*     */   {
/*  80 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public FileView getView()
/*     */   {
/*  88 */     return this.view;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSummaryLine(AbstractLine summaryLine, String fieldName) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isLeaf()
/*     */   {
/* 106 */     if (this.toBuild) {
/* 107 */       return !this.childLineDtls.hasLines(this.childIdx);
/*     */     }
/* 109 */     return super.isLeaf();
/*     */   }
/*     */   
/*     */   protected Vector<MutableTreeNode> getChildren()
/*     */   {
/* 114 */     if (this.toBuild) {
/* 115 */       this.toBuild = false;
/* 116 */       List<AbstractLine> lines = this.childLineDtls.getLines(this.childIdx);
/*     */       
/*     */ 
/*     */ 
/* 120 */       for (AbstractLine theLine : lines) {
/* 121 */         String name = this.nodeName;
/* 122 */         int idx = theLine.getPreferredLayoutIdx();
/* 123 */         if (idx >= 0) {
/* 124 */           name = getLayout().getRecord(idx).getRecordName();
/*     */         }
/*     */         
/* 127 */         add(new LineNodeChild(name, this.view, theLine));
/*     */       }
/* 129 */       this.childLineDtls = null;
/*     */     }
/* 131 */     return super.getChildren();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getDefaultLineNumber()
/*     */   {
/* 140 */     return getLineNumber();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLineNumber()
/*     */   {
/* 148 */     if (line != null) {
/* 149 */       return this.view.indexOf(line);
/*     */     }
/* 151 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getSortValue()
/*     */   {
/* 159 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractLineNode insert(AbstractLine line, int lineNumber, int pos)
/*     */   {
/* 168 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void remove(int index)
/*     */   {
/* 176 */     super.remove(index);
/* 177 */     if (getChildCount() == 0) {
/* 178 */       removeFromParent();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void remove(MutableTreeNode node)
/*     */   {
/* 187 */     super.remove(node);
/* 188 */     if (getChildCount() == 0) {
/* 189 */       this.view.getTreeTableNotify().fireTreeNodesRemoved(this);
/* 190 */       removeFromParent();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void removeAllChildren() {}
/*     */   
/*     */   public boolean isBuilt()
/*     */   {
/* 199 */     return !this.toBuild;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractLineNode insertNode(int location, String nodeName, FileView fileView, AbstractLine theLine)
/*     */   {
/* 209 */     AbstractLineNode node = new LineNodeChild(nodeName, fileView, theLine);
/* 210 */     insert(node, location);
/* 211 */     return node;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/tree/LineNodeChildList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */