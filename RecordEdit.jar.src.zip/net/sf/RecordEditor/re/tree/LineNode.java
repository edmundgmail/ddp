/*     */ package net.sf.RecordEditor.re.tree;
/*     */ 
/*     */ import javax.swing.tree.DefaultMutableTreeNode;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.RecordEditor.re.file.AbstractLineNode;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.swing.treeTable.TreeTableNotify;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class LineNode
/*     */   extends DefaultMutableTreeNode
/*     */   implements AbstractLineNode
/*     */ {
/*     */   public final String nodeName;
/*     */   private FileView view;
/*     */   private int lineNumber;
/*     */   private int firstLeafLine;
/*     */   private int lastLeafLine;
/*  26 */   private AbstractLine summaryLine = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String sortField;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LineNode(String pNodeName, FileView fileView, int lineNum)
/*     */   {
/*  43 */     super(pNodeName);
/*     */     
/*  45 */     this.nodeName = pNodeName;
/*  46 */     this.view = fileView;
/*  47 */     setLineNumberEtc(lineNum);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final AbstractLayoutDetails getLayout()
/*     */   {
/*  56 */     return this.view.getLayout();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final int getLineNumber()
/*     */   {
/*  63 */     return this.lineNumber;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setLineNumberEtc(int lineNumber)
/*     */   {
/*  79 */     this.lineNumber = lineNumber;
/*  80 */     this.lastLeafLine = lineNumber;
/*  81 */     this.firstLeafLine = (lineNumber + 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final AbstractLine getLine()
/*     */   {
/*  90 */     if ((this.lineNumber < 0) || (this.lineNumber >= this.view.getRowCount())) {
/*  91 */       return this.summaryLine;
/*     */     }
/*  93 */     return this.view.getLine(this.lineNumber);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final FileView getView()
/*     */   {
/* 103 */     return this.view;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getLastLeafLine()
/*     */   {
/* 112 */     return this.lastLeafLine;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setLastLeafLine(int lastLeafLine)
/*     */   {
/* 121 */     this.lastLeafLine = lastLeafLine;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getDefaultLineNumber()
/*     */   {
/* 132 */     return this.firstLeafLine;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getFirstLeafLine()
/*     */   {
/* 141 */     return this.firstLeafLine;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setFirstLeafLine(int firstLeafLine)
/*     */   {
/* 150 */     this.firstLeafLine = firstLeafLine;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void adjustLineNumbers(int start, int difference)
/*     */   {
/* 163 */     if (this.lineNumber > start) {
/* 164 */       this.lineNumber += difference;
/*     */     }
/* 166 */     if (this.firstLeafLine > start) {
/* 167 */       this.firstLeafLine += difference;
/*     */     }
/* 169 */     if (this.lastLeafLine >= start) {
/* 170 */       this.lastLeafLine += difference;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setSummaryLine(AbstractLine summaryLine, String fieldName)
/*     */   {
/* 182 */     this.summaryLine = summaryLine;
/* 183 */     this.sortField = fieldName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getLineType()
/*     */   {
/* 191 */     String ret = "";
/*     */     
/* 193 */     if (this.summaryLine == null) {
/* 194 */       if (this.lineNumber >= 0) {
/* 195 */         int pref = this.view.getLine(this.lineNumber).getPreferredLayoutIdx();
/* 196 */         if ((pref < 0) || (pref > this.view.getLayout().getRecordCount())) {
/* 197 */           pref = 0;
/*     */         }
/* 199 */         ret = this.view.getLayout().getRecord(pref).getRecordName();
/* 200 */       } else if (isRoot()) {
/* 201 */         return this.view.getLayout().getLayoutName();
/*     */       }
/*     */     } else {
/* 204 */       ret = this.sortField;
/*     */     }
/*     */     
/* 207 */     return ret;
/*     */   }
/*     */   
/*     */   public final String getSortValue() {
/* 211 */     String ret = "";
/* 212 */     if (this.summaryLine != null) {
/* 213 */       ret = this.nodeName;
/*     */     }
/*     */     
/* 216 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LineNode insert(AbstractLine line, int lineNum, int pos)
/*     */   {
/* 228 */     LineNode n = new LineNode("inserted", this.view, lineNum);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 233 */     if ((pos < 0) || (pos > getChildCount())) {
/* 234 */       add(n);
/*     */     } else {
/* 236 */       insert(n, pos);
/*     */     }
/*     */     
/* 239 */     if (this.view.getBaseFile().getTreeTableNotify() != null) {
/* 240 */       this.view.getBaseFile().getTreeTableNotify().fireTreeNodesInserted(n);
/*     */     }
/* 242 */     return n;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractLineNode insertNode(int location, String nodeName, FileView fileView, AbstractLine theLine)
/*     */   {
/* 253 */     AbstractLineNode node = new LineNodeChild(nodeName, fileView, theLine);
/* 254 */     insert(node, location);
/* 255 */     return node;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/tree/LineNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */