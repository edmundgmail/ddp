/*    */ package net.sf.RecordEditor.re.tree;
/*    */ 
/*    */ import javax.xml.stream.XMLStreamWriter;
/*    */ import net.sf.RecordEditor.re.file.AbstractLineNode;
/*    */ import net.sf.RecordEditor.re.util.BasicLine2Xml;
/*    */ 
/*    */ public class TreeToXml extends BasicLine2Xml
/*    */ {
/*    */   private AbstractLineNode rootNode;
/*    */   
/*    */   public TreeToXml(String fileName, AbstractLineNode node)
/*    */   {
/* 13 */     super(fileName);
/* 14 */     this.rootNode = node;
/*    */     
/* 16 */     super.doWork();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void writeDetails()
/*    */     throws javax.xml.stream.XMLStreamException
/*    */   {
/* 25 */     writeNode(this.rootNode);
/*    */   }
/*    */   
/*    */   private void writeNode(AbstractLineNode node) throws javax.xml.stream.XMLStreamException
/*    */   {
/* 30 */     String name = fixName(node.getLineType().replace(" ", "_"));
/* 31 */     if (node.isLeaf()) {
/* 32 */       this.writer.writeEmptyElement(name);
/* 33 */       writeAttributes(node.getLine());
/*    */     } else {
/* 35 */       String s = node.getSortValue();
/* 36 */       this.writer.writeStartElement(name);
/*    */       
/* 38 */       if (!"".equals(s)) {
/* 39 */         this.writer.writeAttribute("Key", s);
/*    */       }
/*    */       
/* 42 */       writeAttributes(node.getLine());
/*    */       
/* 44 */       for (int i = 0; i < node.getChildCount(); i++) {
/* 45 */         writeNode((LineNode)node.getChildAt(i));
/*    */       }
/* 47 */       this.writer.writeEndElement();
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/tree/TreeToXml.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */