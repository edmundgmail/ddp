/*     */ package net.sf.RecordEditor.re.file;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.RecordEditor.utils.ExpandLineTree;
/*     */ import net.sf.RecordEditor.utils.lang.ReOptionDialog;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class PositionIncrement
/*     */ {
/*     */   public final FilePosition pos;
/*     */   protected final List<? extends AbstractLine> lines;
/*  19 */   private boolean endOfFileChk = true;
/*     */   
/*     */ 
/*     */ 
/*     */   public static PositionIncrement newIncrement(FilePosition position, List<? extends AbstractLine> allLines, boolean endOfFileChk)
/*     */   {
/*     */     PositionIncrement ret;
/*     */     
/*     */ 
/*     */     PositionIncrement ret;
/*     */     
/*     */ 
/*  31 */     if (position.currentLine != null) { Iterator<AbstractLine> it;
/*     */       Iterator<AbstractLine> it;
/*  33 */       if (position.isForward()) {
/*  34 */         it = new TreeIteratorForward(allLines, position.currentLine);
/*     */       } else {
/*  36 */         it = new TreeIteratorBackward(allLines, position.currentLine);
/*     */       }
/*     */       
/*  39 */       if ((position.isReadPending()) && (it.hasNext())) {
/*  40 */         position.currentLine = ((AbstractLine)it.next());
/*  41 */         position.setReadPending(false);
/*     */       }
/*     */       PositionIncrement ret;
/*  44 */       if (position.getFieldId() == -102) {
/*  45 */         ret = new AllFieldsIterator(position, allLines, it, null);
/*     */       } else
/*  47 */         ret = new SpecificFieldIterator(position, allLines, it, null);
/*     */     } else { PositionIncrement ret;
/*  49 */       if (position.getFieldId() == -102) {
/*  50 */         ret = new AllFields(position, allLines, null);
/*     */       } else {
/*  52 */         ret = new SpecificField(position, allLines, null);
/*     */       }
/*     */     }
/*  55 */     ret.endOfFileChk = endOfFileChk;
/*  56 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private PositionIncrement(FilePosition position, List<? extends AbstractLine> allLines)
/*     */   {
/*  63 */     this.pos = position;
/*  64 */     this.lines = allLines;
/*     */   }
/*     */   
/*     */   public boolean isValidPosition()
/*     */   {
/*  69 */     if (iIsValidPosition()) {
/*  70 */       return true;
/*     */     }
/*     */     
/*  73 */     if (this.endOfFileChk) { String s;
/*     */       String s;
/*  75 */       if (this.pos.isForward()) {
/*  76 */         s = "Reached the end of the file, do you want search from the start ??";
/*     */       } else {
/*  78 */         s = "Reached the Start of the file, do you want search from the end ??";
/*     */       }
/*     */       
/*  81 */       int opt = ReOptionDialog.showConfirmDialog(null, s, "", 0);
/*     */       
/*  83 */       if (opt == 0) {
/*  84 */         this.pos.gotoStart();
/*  85 */         nextPosition();
/*     */         
/*  87 */         return iIsValidPosition();
/*     */       }
/*     */     }
/*  90 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean iIsValidPosition() {
/*  94 */     return (this.pos.row < this.lines.size()) && (this.pos.row >= 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int getMaxField()
/*     */   {
/* 102 */     if ((this.pos.row >= this.lines.size()) || (this.pos.row < 0)) {
/* 103 */       return -1;
/*     */     }
/*     */     
/*     */ 
/* 107 */     AbstractLine currLine = (AbstractLine)this.lines.get(this.pos.row);
/* 108 */     if (this.pos.currentLine != null) {
/* 109 */       currLine = this.pos.currentLine;
/*     */     }
/* 111 */     int prefIdx = currLine.getPreferredLayoutIdx();
/* 112 */     if ((prefIdx < 0) || (prefIdx >= currLine.getLayout().getRecordCount())) {
/* 113 */       return -1;
/*     */     }
/* 115 */     int maxField = currLine.getLayout().getRecord(prefIdx).getFieldCount();
/*     */     
/* 117 */     this.pos.recordId = prefIdx;
/*     */     
/* 119 */     if (!this.pos.isValidFieldNum(maxField)) {
/* 120 */       this.pos.currentFieldNumber = (maxField - 1);
/* 121 */       if (this.pos.isForward()) {
/* 122 */         this.pos.currentFieldNumber = 0;
/*     */       }
/*     */     }
/* 125 */     return maxField;
/*     */   }
/*     */   
/*     */   public abstract FilePosition nextPosition();
/*     */   
/*     */   private static class SpecificField
/*     */     extends PositionIncrement
/*     */   {
/*     */     private SpecificField(FilePosition position, List<? extends AbstractLine> allLines)
/*     */     {
/* 135 */       super(allLines, null);
/*     */     }
/*     */     
/*     */     public FilePosition nextPosition() {
/* 139 */       this.pos.nextRow();
/*     */       
/* 141 */       return this.pos;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class AllFields extends PositionIncrement
/*     */   {
/*     */     int maxField;
/*     */     
/*     */     private AllFields(FilePosition position, List<? extends AbstractLine> allLines) {
/* 150 */       super(allLines, null);
/* 151 */       this.maxField = getMaxField();
/* 152 */       checkField();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     protected boolean iIsValidPosition()
/*     */     {
/* 160 */       return (super.iIsValidPosition()) || (this.pos.isValidFieldNum(this.maxField));
/*     */     }
/*     */     
/*     */ 
/*     */     public FilePosition nextPosition()
/*     */     {
/* 166 */       this.pos.nextField();
/* 167 */       checkField();
/*     */       
/* 169 */       return this.pos;
/*     */     }
/*     */     
/*     */     private void checkField()
/*     */     {
/* 174 */       if (!this.pos.isValidFieldNum(this.maxField)) {
/* 175 */         this.pos.nextRow();
/* 176 */         this.maxField = getMaxField();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static abstract class IteratorInc extends PositionIncrement
/*     */   {
/*     */     private Iterator<AbstractLine> it;
/* 184 */     private boolean valid = true;
/*     */     
/*     */ 
/*     */ 
/*     */     public IteratorInc(FilePosition position, List<? extends AbstractLine> allLines, Iterator<AbstractLine> iterator)
/*     */     {
/* 190 */       super(allLines, null);
/*     */       
/* 192 */       this.it = iterator;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     protected final boolean iIsValidPosition()
/*     */     {
/* 200 */       return this.valid;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public FilePosition nextRow()
/*     */     {
/* 207 */       if (this.it.hasNext()) {
/*     */         AbstractLine l;
/* 209 */         do { l = (AbstractLine)this.it.next();
/* 210 */           this.pos.currentLine = l;
/*     */ 
/*     */         }
/* 213 */         while (((this.pos.currentLine != null) && (l.getLayout().getRecord(l.getPreferredLayoutIdx()).getFieldCount() == 0)) || ((this.pos.currentLine.getPreferredLayoutIdx() != this.pos.recordId) && (this.pos.getFieldId() >= 0) && (this.it.hasNext())));
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 218 */         int row = this.lines.indexOf(ExpandLineTree.getRootLine(this.pos.currentLine));
/*     */         
/* 220 */         if (row >= 0)
/*     */         {
/*     */ 
/*     */ 
/* 224 */           this.pos.row = row;
/*     */         }
/*     */         
/* 227 */         this.valid = this.it.hasNext();
/*     */         
/* 229 */         this.pos.resetCol();
/*     */       } else {
/* 231 */         this.valid = false;
/*     */       }
/*     */       
/* 234 */       return this.pos;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class SpecificFieldIterator
/*     */     extends PositionIncrement.IteratorInc
/*     */   {
/*     */     private SpecificFieldIterator(FilePosition position, List<? extends AbstractLine> allLines, Iterator<AbstractLine> iterator)
/*     */     {
/* 245 */       super(allLines, iterator);
/*     */     }
/*     */     
/*     */     public FilePosition nextPosition() {
/* 249 */       return nextRow();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class AllFieldsIterator
/*     */     extends PositionIncrement.IteratorInc
/*     */   {
/*     */     int maxField;
/*     */     
/*     */ 
/*     */     private AllFieldsIterator(FilePosition position, List<? extends AbstractLine> allLines, Iterator<AbstractLine> iterator)
/*     */     {
/* 263 */       super(allLines, iterator);
/* 264 */       this.maxField = getMaxField();
/* 265 */       checkRow();
/*     */     }
/*     */     
/*     */     public FilePosition nextPosition()
/*     */     {
/* 270 */       this.pos.nextField();
/* 271 */       checkRow();
/*     */       
/* 273 */       return this.pos;
/*     */     }
/*     */     
/*     */     private void checkRow()
/*     */     {
/* 278 */       if (!this.pos.isValidFieldNum(this.maxField)) {
/* 279 */         this.pos.nextRow();
/* 280 */         nextRow();
/* 281 */         this.maxField = getMaxField();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/PositionIncrement.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */