package net.sf.RecordEditor.re.file;

public abstract interface AbstractChangeNotify
{
  public abstract void setChanged(boolean paramBoolean);
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/AbstractChangeNotify.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */