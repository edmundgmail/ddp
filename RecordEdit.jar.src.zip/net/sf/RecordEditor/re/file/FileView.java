/*      */ package net.sf.RecordEditor.re.file;
/*      */ 
/*      */ import java.beans.PropertyChangeEvent;
/*      */ import java.beans.PropertyChangeListener;
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.math.BigDecimal;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.WeakHashMap;
/*      */ import java.util.zip.GZIPInputStream;
/*      */ import javax.swing.JFrame;
/*      */ import javax.swing.JOptionPane;
/*      */ import javax.swing.SwingUtilities;
/*      */ import javax.swing.event.TableModelEvent;
/*      */ import javax.swing.event.TableModelListener;
/*      */ import javax.swing.event.TreeModelEvent;
/*      */ import javax.swing.event.TreeModelListener;
/*      */ import javax.swing.table.AbstractTableModel;
/*      */ import javax.swing.tree.TreeNode;
/*      */ import net.sf.JRecord.ByteIO.IByteReader;
/*      */ import net.sf.JRecord.Common.IFieldDetail;
/*      */ import net.sf.JRecord.Common.RecordException;
/*      */ import net.sf.JRecord.Details.AbstractChildDetails;
/*      */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*      */ import net.sf.JRecord.Details.AbstractLine;
/*      */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*      */ import net.sf.JRecord.Details.AbstractRecordDetail.FieldDetails;
/*      */ import net.sf.JRecord.Details.AbstractTreeDetails;
/*      */ import net.sf.JRecord.Details.Attribute;
/*      */ import net.sf.JRecord.Details.IColumnInsertDelete;
/*      */ import net.sf.JRecord.Details.LayoutDetail;
/*      */ import net.sf.JRecord.Details.LineCompare;
/*      */ import net.sf.JRecord.Details.LineProvider;
/*      */ import net.sf.JRecord.IO.AbstractLineIOProvider;
/*      */ import net.sf.JRecord.IO.AbstractLineReader;
/*      */ import net.sf.JRecord.IO.AbstractLineWriter;
/*      */ import net.sf.JRecord.IO.LineIOProvider;
/*      */ import net.sf.JRecord.IO.LineReaderWrapper;
/*      */ import net.sf.JRecord.Types.Type;
/*      */ import net.sf.JRecord.Types.TypeManager;
/*      */ import net.sf.JRecord.detailsSelection.RecordSel;
/*      */ import net.sf.RecordEditor.edit.display.util.LinePosition;
/*      */ import net.sf.RecordEditor.layoutWizard.FileAnalyser;
/*      */ import net.sf.RecordEditor.re.file.filter.Compare;
/*      */ import net.sf.RecordEditor.re.file.filter.FilterDetails;
/*      */ import net.sf.RecordEditor.re.file.filter.FilterFieldBaseList;
/*      */ import net.sf.RecordEditor.re.util.FileStructureDtls;
/*      */ import net.sf.RecordEditor.utils.ColumnMappingInterface;
/*      */ import net.sf.RecordEditor.utils.basicStuff.IRetrieveTable;
/*      */ import net.sf.RecordEditor.utils.common.Common;
/*      */ import net.sf.RecordEditor.utils.common.GcManager;
/*      */ import net.sf.RecordEditor.utils.common.StreamUtil;
/*      */ import net.sf.RecordEditor.utils.fileStorage.DataStoreIterator;
/*      */ import net.sf.RecordEditor.utils.fileStorage.DataStoreLarge;
/*      */ import net.sf.RecordEditor.utils.fileStorage.DataStoreLargeView;
/*      */ import net.sf.RecordEditor.utils.fileStorage.DataStoreRange;
/*      */ import net.sf.RecordEditor.utils.fileStorage.DataStoreStd;
/*      */ import net.sf.RecordEditor.utils.fileStorage.DataStoreStd.DataStoreStdBinary;
/*      */ import net.sf.RecordEditor.utils.fileStorage.FileDetails;
/*      */ import net.sf.RecordEditor.utils.fileStorage.IDataStore;
/*      */ import net.sf.RecordEditor.utils.fileStorage.IDataStoreIterator;
/*      */ import net.sf.RecordEditor.utils.fileStorage.IDataStoreView;
/*      */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*      */ import net.sf.RecordEditor.utils.msg.UtMessages;
/*      */ import net.sf.RecordEditor.utils.params.BoolOpt;
/*      */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*      */ import net.sf.RecordEditor.utils.params.ProgramOptions.IntOpt;
/*      */ import net.sf.RecordEditor.utils.params.ProgramOptions.MultiValOpt;
/*      */ import net.sf.RecordEditor.utils.screenManager.ReMsg;
/*      */ import net.sf.RecordEditor.utils.swing.DelayedFieldValue;
/*      */ import net.sf.RecordEditor.utils.swing.array.ArrayNotifyInterface;
/*      */ import net.sf.RecordEditor.utils.swing.common.EmptyProgressDisplay;
/*      */ import net.sf.RecordEditor.utils.swing.common.IProgressDisplay;
/*      */ import net.sf.RecordEditor.utils.swing.treeTable.TreeTableNotify;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class FileView
/*      */   extends AbstractTableModel
/*      */   implements Iterable<AbstractLine>, TableModelListener, ColumnMappingInterface, TreeModelListener, AbstractChangeNotify, IGetView, ArrayNotifyInterface
/*      */ {
/*  122 */   private static final String INTERNAL_ERROR_LINES_CLEARED_SAVE_IS_NOT_POSSIBLE = LangConversion.convert("Internal Error: lines cleared, save is not possible !!!");
/*      */   
/*      */   private static final String ONLY_ONE_IS_ALLOWED = "Only one {0} is allowed !!!";
/*      */   
/*      */   public static final int SPECIAL_FIELDS_AT_START = 2;
/*      */   
/*      */   private static final int BUFFER_SIZE = 65536;
/*      */   
/*      */   private static final int SET_USING_FIELD = 1;
/*      */   
/*      */   public static final int SET_USING_TEXT = 2;
/*      */   
/*      */   public static final int SET_USING_HEX = 3;
/*      */   public static final int SELECTION_COLUMN = 0;
/*      */   public static final int LINE_NUMER_COLUMN = 1;
/*      */   private static final int INITIAL_FILE_SIZE = 1000;
/*      */   private static final int MINIMUM_FILE_SIZE = 512;
/*      */   private static final int CAN_INSERT = 1;
/*      */   private static final int FAILED_2ND_ROOT_NOT_ALLOWED = 3;
/*      */   private static final int FAILED_CHILD_ALREADY_EXISTS = 4;
/*      */   private static final int FAILED_CHILD_NOT_IN_PARENT = 5;
/*      */   private static final byte NO_CHANGE = 1;
/*      */   private static final byte BEING_SAVED = 2;
/*      */   private static final byte CHANGED = 3;
/*  146 */   private static final EmptyProgressDisplay EMPTY_PROGRESS = new EmptyProgressDisplay();
/*  147 */   private static final CheckStore NO_CHECK = new CheckStore()
/*      */   {
/*      */     public void checkDatasStore(int numLines) {}
/*      */   };
/*      */   
/*  152 */   private static final FieldMapping NULL_MAPPING = new FieldMapping(new int[0]);
/*      */   
/*  154 */   private static final String[] LINE_COLUMN_HEADINGS = LangConversion.convertArray(5, "Record_ColumnHeadings", new String[] { "", "Full Line", "Hex (1 Line)", "Hex (2 Lines)", "Hex (SPF Edit Style)", "Hex (Alternative)" });
/*      */   
/*      */ 
/*      */ 
/*  158 */   private String[] lineColumns = new String[LINE_COLUMN_HEADINGS.length];
/*      */   
/*  160 */   private int maxNumColumns = -1;
/*  161 */   private int defaultPreferredIndex = 0;
/*      */   
/*      */ 
/*      */ 
/*  165 */   public boolean saveAvailable = true;
/*      */   
/*      */ 
/*  168 */   private static IDataStore<AbstractLine> copySrc = null;
/*      */   
/*      */   private String fileName;
/*  171 */   private String altName = null;
/*      */   
/*      */   private AbstractLineIOProvider ioProvider;
/*      */   
/*  175 */   private int currLayoutIdx = 0;
/*  176 */   private boolean fileRead = false;
/*  177 */   private boolean clearWaiting = false;
/*  178 */   private String msg = "";
/*      */   
/*  180 */   private boolean toSave = true;
/*  181 */   private boolean view = false;
/*      */   
/*      */   private IDataStore<AbstractLine> lines;
/*      */   
/*      */   private AbstractLayoutDetails layout;
/*      */   
/*      */   private boolean browse;
/*  188 */   private byte changeStatus = 1;
/*      */   
/*  190 */   private JFrame frame = null;
/*      */   
/*      */   private FileView baseFile;
/*      */   
/*  194 */   private FieldMapping columnMapping = NULL_MAPPING;
/*  195 */   private boolean displayErrorDialog = true;
/*  196 */   private boolean allowMultipleRecords = true;
/*      */   
/*  198 */   private TreeTableNotify treeTableNotify = null;
/*  199 */   private WeakHashMap<AbstractLine, AbstractLineNode> nodes = null;
/*      */   
/*      */ 
/*  202 */   private ArrayList<WeakReference<FileWriter>> writers = new ArrayList();
/*      */   
/*  204 */   private long memoryCompare = Common.getMemoryCompare();
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean textFile;
/*      */   
/*      */ 
/*      */ 
/*  212 */   private PropertyChangeListener saveDoneListner = new PropertyChangeListener()
/*      */   {
/*      */     public void propertyChange(PropertyChangeEvent evt)
/*      */     {
/*  216 */       FileView.this.dropCompletedWriters();
/*  217 */       if ((FileView.this.clearWaiting) && (FileView.this.writers.size() == 0)) {
/*  218 */         FileView.this.clearWaiting = false;
/*  219 */         FileView.this.doClear();
/*      */       }
/*      */     }
/*      */   };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public FileView(AbstractLayoutDetails pFd, AbstractLineIOProvider pIoProvider, boolean pBrowse)
/*      */   {
/*  237 */     newLines(1000, -121L, null, "");
/*  238 */     this.fileName = null;
/*  239 */     this.layout = pFd;
/*  240 */     this.ioProvider = pIoProvider;
/*  241 */     this.browse = pBrowse;
/*  242 */     this.baseFile = this;
/*  243 */     checkIfTextFile();
/*      */     
/*  245 */     if (this.ioProvider == null) {
/*  246 */       this.ioProvider = LineIOProvider.getInstance();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public FileView(String pFileName, AbstractLayoutDetails pFd, boolean pBrowse)
/*      */     throws IOException, RecordException
/*      */   {
/*  262 */     this(pFileName, pFd, LineIOProvider.getInstance(), pBrowse);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public FileView(String pFileName, AbstractLayoutDetails pFd, AbstractLineIOProvider pIoProvider, boolean pBrowse)
/*      */     throws IOException, RecordException
/*      */   {
/*  283 */     this.layout = pFd;
/*  284 */     this.ioProvider = pIoProvider;
/*  285 */     this.browse = pBrowse;
/*  286 */     this.baseFile = this;
/*  287 */     checkIfTextFile();
/*      */     
/*  289 */     readFile(pFileName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public FileView(IDataStore<? extends AbstractLine> pLines, FileView pBaseFile, FieldMapping colMapping)
/*      */   {
/*  303 */     this(pLines, pBaseFile, pLines.getLayoutRE(), colMapping, pBaseFile == null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public FileView(IDataStore<? extends AbstractLine> pLines, FileView pBaseFile, FieldMapping colMapping, boolean pBrowse)
/*      */   {
/*  317 */     this(pLines, pBaseFile, pLines.getLayoutRE(), colMapping, pBrowse);
/*      */   }
/*      */   
/*      */ 
/*      */   public FileView(String name, IDataStore pLines, AbstractLayoutDetails layoutDtls)
/*      */   {
/*  323 */     this(pLines, null, layoutDtls, null, false);
/*      */     
/*  325 */     this.altName = name;
/*  326 */     this.saveAvailable = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private FileView(IDataStore pLines, FileView pBaseFile, AbstractLayoutDetails layoutDtls, FieldMapping colMapping, boolean pBrowse)
/*      */   {
/*  336 */     this.lines = pLines;
/*  337 */     checkDataStore4ModeListner(this.lines);
/*      */     
/*  339 */     if (colMapping != null) {
/*  340 */       this.columnMapping = colMapping;
/*      */     }
/*      */     
/*  343 */     this.fileRead = true;
/*  344 */     this.view = (pBaseFile != null);
/*      */     
/*  346 */     if (pBaseFile == null) {
/*  347 */       this.baseFile = this;
/*  348 */       this.fileName = "";
/*  349 */       this.layout = layoutDtls;
/*  350 */       this.browse = pBrowse;
/*  351 */       this.ioProvider = LineIOProvider.getInstance();
/*      */     } else {
/*  353 */       this.baseFile = pBaseFile;
/*  354 */       this.fileName = this.baseFile.getFileName();
/*  355 */       this.layout = this.baseFile.getLayout();
/*  356 */       this.browse = this.baseFile.isBrowse();
/*  357 */       this.ioProvider = this.baseFile.getIoProvider();
/*  358 */       this.baseFile.addTableModelListener(this);
/*      */     }
/*      */     
/*  361 */     initLineCols();
/*  362 */     checkIfTextFile();
/*      */   }
/*      */   
/*      */   private void initLineCols()
/*      */   {
/*  367 */     StringBuffer buf = new StringBuffer();
/*      */     
/*      */ 
/*  370 */     int num = this.layout.getMaximumRecordLength() / 10 + 1;
/*      */     
/*      */ 
/*  373 */     for (int i = 1; i < num + 1; i++) {
/*  374 */       String s = "    " + i;
/*  375 */       buf.append("    +").append(s.substring(s.length() - 5));
/*      */     }
/*      */     
/*  378 */     this.lineColumns[1] = buf.toString();
/*  379 */     this.lineColumns[4] = this.lineColumns[1];
/*      */     
/*  381 */     buf = new StringBuffer();
/*  382 */     for (int i = 1; i < num + 1; i++) {
/*  383 */       String s = "         " + i;
/*  384 */       buf.append("         +").append(s.substring(s.length() - 10));
/*      */     }
/*      */     
/*  387 */     this.lineColumns[2] = buf.toString();
/*  388 */     this.lineColumns[3] = this.lineColumns[2];
/*      */     
/*  390 */     buf = new StringBuffer();
/*  391 */     for (int i = 1; i < num + 1; i++) {
/*  392 */       String s = "                " + i;
/*  393 */       buf.append("                +").append(s.substring(s.length() - 16) + " ");
/*      */     }
/*      */     
/*  396 */     this.lineColumns[5] = buf.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public final void clear()
/*      */   {
/*  403 */     dropCompletedWriters();
/*      */     
/*  405 */     if (this.writers.size() > 0) {
/*  406 */       this.clearWaiting = true;
/*  407 */       if (!this.view) {
/*  408 */         doCompress(0);
/*      */       }
/*      */     } else {
/*  411 */       doClear();
/*      */     }
/*  413 */     this.nodes = null;
/*      */   }
/*      */   
/*      */   public final void doClear() {
/*  417 */     if (this.lines != null) {
/*  418 */       this.lines.clear();
/*      */     }
/*  420 */     if (this.baseFile != null) {
/*  421 */       this.baseFile.removeTableModelListener(this);
/*      */     }
/*      */     
/*  424 */     this.lines = null;
/*      */     
/*  426 */     GcManager.doGcIfNeccessary(0.5D);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void readFile(String pFileName)
/*      */     throws IOException, RecordException
/*      */   {
/*  435 */     this.fileName = pFileName;
/*  436 */     File file = new File(pFileName);
/*      */     
/*      */ 
/*  439 */     if (file.exists()) {
/*  440 */       if (file.isDirectory())
/*  441 */         throw new IOException(pFileName + " is a directory not a file");
/*  442 */       if (!file.isFile()) {
/*  443 */         throw new IOException(pFileName + " is not a file");
/*      */       }
/*  445 */       boolean isGZip = checkIfGZip(pFileName);
/*  446 */       int structure = this.layout.getFileStructure();
/*      */       
/*  448 */       if (this.ioProvider == null) {
/*  449 */         this.ioProvider = LineIOProvider.getInstance();
/*      */       }
/*      */       
/*  452 */       long fileLength = file.length();
/*  453 */       int bufSize = FileWriter.calcBufferSize(65536, fileLength);
/*      */       
/*  455 */       boolean checkFileStructureStd = this.layout.getOption(4) == 1;
/*  456 */       boolean checkFileStructureX = this.layout.getOption(5) == 1;
/*  457 */       if ((checkFileStructureStd) || (checkFileStructureX)) {
/*  458 */         byte[] data = StreamUtil.read(new FileInputStream(this.fileName), 16000);
/*      */         
/*  460 */         if ((data != null) && (data.length > 0)) {
/*  461 */           FileAnalyser fileAnaylser = FileAnalyser.getAnaylserNoLengthCheck(data, "");
/*  462 */           int fd = fileAnaylser.getFileStructure();
/*  463 */           if ((fd > 0) && (fd != 9) && ((fileAnaylser.getLinesRead() > 6) || ((checkFileStructureStd) && (fileAnaylser.getLinesRead() > 2))))
/*      */           {
/*      */ 
/*  466 */             structure = fd;
/*  467 */             this.layout.setAttribute(Attribute.FILE_STRUCTURE, Integer.valueOf(fd));
/*  468 */             Common.logMsgRaw(29, UtMessages.FILE_FORMAT_USED.get(new Object[] { getFileNameNoDirectory(), FileStructureDtls.getStructureName(fd) }), null);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  480 */       AbstractLineReader reader = this.ioProvider.getLineReader(this.layout);
/*      */       
/*  482 */       FileInputStream rff = new FileInputStream(pFileName);
/*  483 */       if (isGZip) {
/*  484 */         reader.open(new GZIPInputStream(rff, bufSize), this.layout);
/*      */         
/*  486 */         readFile(reader, file, isGZip, rff, pFileName);
/*  487 */       } else if ((Common.OPTIONS.useBigFixedModel.isSelected()) && (structure == 2) && (useBigFileModel(fileLength)))
/*      */       {
/*      */ 
/*  490 */         this.lines = DataStoreLarge.getFixedLengthRecordStore((LayoutDetail)this.layout, pFileName);
/*      */       } else {
/*  492 */         BufferedInputStream rf = new BufferedInputStream(rff, bufSize);
/*      */         
/*  494 */         reader.open(rf, pFileName, this.layout);
/*  495 */         this.browse |= !reader.canWrite();
/*  496 */         readFile(reader, file, isGZip, rf, pFileName);
/*      */       }
/*  498 */       rff.close();
/*      */     }
/*      */     else {
/*  501 */       AbstractLineReader reader = this.ioProvider.getLineReader(this.layout);
/*  502 */       reader.generateLayout(this.layout);
/*  503 */       retrieveLayout(reader);
/*  504 */       this.toSave = false;
/*      */       
/*  506 */       newLines(1000, -121L, null, "");
/*      */     }
/*      */     
/*  509 */     initLineCols();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void readFile(AbstractLineReader<AbstractLayoutDetails> reader, File file, boolean isGZip, InputStream rf, String fname)
/*      */     throws IOException
/*      */   {
/*  529 */     int count = 0;
/*  530 */     long interval = 1000000000L;
/*      */     
/*  532 */     long time = System.nanoTime();
/*  533 */     long lastTime = time;
/*      */     
/*  535 */     boolean isVeryBigFile = file.length() > 2147483647L;
/*      */     
/*  537 */     double total = file.length();
/*      */     
/*  539 */     long len = file.length();
/*  540 */     CheckStore checkStore = NO_CHECK;
/*      */     
/*  542 */     retrieveLayout(reader);
/*      */     
/*      */ 
/*  545 */     long t1 = time;
/*  546 */     long tt1 = 0L;
/*  547 */     long tt2 = 0L;
/*      */     
/*  549 */     AbstractLine line = reader.read();
/*  550 */     retrieveLayout(reader);
/*  551 */     allocateLines(file, isGZip, len, reader, fname);
/*      */     
/*  553 */     if ((this.layout != null) && (this.layout.getOption(7) == 1) && ((this.lines instanceof ArrayList)) && ((isGZip) || (useBigFileModel(len * 10L))))
/*      */     {
/*      */ 
/*  556 */       checkStore = new ChkStore(null);
/*      */     }
/*      */     
/*  559 */     if (line != null) {
/*  560 */       this.lines.add(line);
/*      */     }
/*      */     
/*  563 */     if (Common.OPTIONS.loadInBackgroundThread.isSelected()) {
/*  564 */       ProgressDisplay readProgress = new ProgressDisplay("Reading", file.getName());
/*      */       try {
/*  566 */         while ((line = reader.read()) != null) {
/*  567 */           tt1 += System.nanoTime() - t1;
/*  568 */           long t2 = System.nanoTime();
/*  569 */           this.lines.add(line);
/*  570 */           tt2 += System.nanoTime() - t2;
/*  571 */           if (count++ > 2000) {
/*  572 */             checkStore.checkDatasStore(count);
/*      */             
/*  574 */             count = 0;
/*  575 */             long t = System.nanoTime();
/*  576 */             if (t - lastTime > interval) { double ratio;
/*  577 */               double ratio; if (isVeryBigFile) {
/*  578 */                 ratio = this.lines.getSpaceRE() / total;
/*      */               } else {
/*  580 */                 ratio = 1.0D - getAvailable(rf) / total;
/*      */               }
/*  582 */               readProgress.updateDisplay(this.lines.getSizeDisplayRE(), (int)(100.0D * ratio));
/*      */               
/*      */ 
/*  585 */               lastTime = t;
/*      */             }
/*      */           }
/*      */           
/*  589 */           t1 = System.nanoTime();
/*      */         }
/*      */       } finally {
/*  592 */         readProgress.done();
/*      */       }
/*      */     } else {
/*  595 */       while ((line = reader.read()) != null) {
/*  596 */         this.lines.add(line);
/*  597 */         checkStore.checkDatasStore(1);
/*      */       }
/*      */     }
/*  600 */     retrieveLayout(reader);
/*  601 */     this.lines.setLayoutRE(this.layout);
/*      */     
/*  603 */     reader.close();
/*      */     
/*      */ 
/*  606 */     time = (System.nanoTime() - time) / 10000000L;
/*  607 */     double ttime = time / 100.0D;
/*      */     
/*      */ 
/*      */ 
/*  611 */     System.out.println(this.lines.getSizeDisplayRE());
/*  612 */     System.out.println("File Read Time: " + ttime);
/*      */     
/*  614 */     System.out.println("Read Total: " + tt1 / 100000000L);
/*  615 */     System.out.println("Add  Total: " + tt2 / 100000000L);
/*  616 */     System.out.println("     Lines: " + this.lines.size());
/*      */   }
/*      */   
/*      */   private int getAvailable(InputStream rf) {
/*  620 */     int ret = 0;
/*      */     try {
/*  622 */       ret = rf.available();
/*      */     }
/*      */     catch (Exception e) {}
/*      */     
/*      */ 
/*  627 */     return ret;
/*      */   }
/*      */   
/*      */   private void retrieveLayout(AbstractLineReader<AbstractLayoutDetails> reader) {
/*  631 */     AbstractLayoutDetails l = reader.getLayout();
/*  632 */     if (l != null) {
/*  633 */       this.layout = l;
/*      */     }
/*      */   }
/*      */   
/*      */   private void allocateLines(File file, boolean isGZip, long len, AbstractLineReader<AbstractLayoutDetails> reader, String fname) {
/*  638 */     int numLines = 1000;
/*  639 */     int maxLength = this.layout.getMaximumRecordLength();
/*  640 */     AbstractLineReader<AbstractLayoutDetails> r = reader;
/*      */     
/*  642 */     if ((this.lines != null) && ((this.lines instanceof TableModelListener))) {
/*  643 */       removeTableModelListener((TableModelListener)this.lines);
/*      */     }
/*      */     try {
/*  646 */       if (maxLength > 0) {
/*  647 */         numLines = (int)(len / maxLength * 11L / 10L);
/*  648 */         if (isGZip) {
/*  649 */           numLines *= 3;
/*      */         }
/*      */         
/*  652 */         numLines = Math.max(512, numLines);
/*      */       }
/*  654 */       if (isGZip) {
/*  655 */         len *= 14L;
/*  656 */         r = null;
/*      */       }
/*  658 */       newLines(numLines, len, r, fname);
/*      */     } catch (Exception e) {
/*  660 */       newLines(1000, -121L, null, fname);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void add(AbstractLine line2add)
/*      */   {
/*  671 */     this.lines.add(line2add);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getColumnCount()
/*      */   {
/*  679 */     return getLayoutColumnCount(this.currLayoutIdx) + 2;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getRowCount()
/*      */   {
/*  688 */     if (this.lines == null) {
/*  689 */       return 0;
/*      */     }
/*  691 */     return this.lines.size();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getValueAt(int row, int col)
/*      */   {
/*  699 */     return getValueAt1(this.currLayoutIdx, row, col);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getValueAt1(int layoutIndex, int row, int col)
/*      */   {
/*  710 */     if ((row >= getRowCount()) || (col >= getLayoutColumnCount(layoutIndex) + 2) || (col == 0))
/*  711 */       return null;
/*  712 */     if (col == 1) {
/*  713 */       return Integer.toString(row + 1);
/*      */     }
/*  715 */     switch (DisplayType.displayType(this.layout, layoutIndex)) {
/*      */     case 1: 
/*  717 */       return getValueAt(((AbstractLine)this.lines.get(row)).getPreferredLayoutIdx(), row, col - 2);
/*      */     case 2: 
/*  719 */       return ((AbstractLine)this.lines.get(row)).getFullLine();
/*      */     
/*      */     case 3: 
/*  722 */       return ((AbstractLine)this.lines.get(row)).getData();
/*      */     }
/*  724 */     return getValueAt(layoutIndex, row, col - 2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setValueAt(Object val, int row, int col)
/*      */   {
/*  735 */     setValueAt(this.currLayoutIdx, val, row, col);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setValueAt(int layoutIdx, Object val, int row, int col)
/*      */   {
/*  744 */     if ((row < getRowCount()) && (col < getLayoutColumnCount(layoutIdx) + 2) && (col > 1))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  750 */       if (this.frame != null) {
/*  751 */         setValueAt(this.frame, layoutIdx, row, col - 2, val);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getColumnName(int col)
/*      */   {
/*  763 */     switch (col) {
/*      */     case 0: 
/*  765 */       if (Common.TEST_MODE) {
/*  766 */         return "Sl";
/*      */       }
/*  768 */       return null;
/*  769 */     case 1:  return LangConversion.convert(5, "Line");
/*      */     }
/*  771 */     switch (DisplayType.displayType(this.layout, this.currLayoutIdx)) {
/*      */     case 2: 
/*  773 */       return LINE_COLUMN_HEADINGS[1];
/*      */     
/*      */     case 1: 
/*  776 */       return getFieldName(this.defaultPreferredIndex, col);
/*      */     case 3: 
/*  778 */       int idx = Math.min(this.currLayoutIdx - this.layout.getRecordCount(), LINE_COLUMN_HEADINGS.length - 1);
/*      */       
/*      */ 
/*      */ 
/*  782 */       return this.lineColumns[idx] + "|" + LINE_COLUMN_HEADINGS[idx];
/*      */     }
/*      */     
/*  785 */     return getFieldName(this.currLayoutIdx, col);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final int getDefaultPreferredIndex()
/*      */   {
/*  795 */     return this.defaultPreferredIndex;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public final void setDefaultPreferredIndex(int currentPreferredIndex)
/*      */   {
/*  802 */     this.defaultPreferredIndex = Math.max(0, currentPreferredIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getFieldName(int layoutIndex, int fldNum)
/*      */   {
/*  812 */     int tCol = getRealColumn(layoutIndex, fldNum - 2);
/*      */     
/*  814 */     IFieldDetail fld = getLayoutField(layoutIndex, tCol);
/*  815 */     if (fld == null) {
/*  816 */       return "";
/*      */     }
/*  818 */     int r = fld.getPos();
/*  819 */     int len = fld.getLen();
/*      */     String s;
/*  821 */     String s; if (len == -121) {
/*  822 */       s = Integer.toString(r);
/*      */     } else {
/*  824 */       s = r + " - " + len;
/*      */     }
/*      */     
/*  827 */     return s + "|" + getRealColumnName(layoutIndex, tCol);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getLayoutColumnCount(int layoutIdx)
/*      */   {
/*  839 */     int l = layoutIdx;
/*  840 */     if (l < 0) {
/*  841 */       l = 0;
/*      */     }
/*      */     
/*  844 */     if (DisplayType.displayType(this.layout, l) == 1) {
/*  845 */       if (this.maxNumColumns < 0) {
/*  846 */         for (int i = 0; i < this.layout.getRecordCount(); i++) {
/*  847 */           this.maxNumColumns = Math.max(this.maxNumColumns, this.layout.getRecord(i).getFieldCount());
/*      */         }
/*      */       }
/*      */       
/*  851 */       return this.maxNumColumns; }
/*  852 */     if (l >= this.layout.getRecordCount()) {
/*  853 */       return 1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  858 */     return this.columnMapping.getColumnCount(l, this.layout.getRecord(l).getFieldCount());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getColumnName(int layoutIdx, int col)
/*      */   {
/*  872 */     return getRealColumnName(layoutIdx, getRealColumn(layoutIdx, col));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getRealColumnName(int layoutIdx, int col)
/*      */   {
/*  885 */     String ret = null;
/*      */     
/*  887 */     if (col >= 0) {
/*      */       try {
/*  889 */         ret = this.layout.getRecord(layoutIdx).getField(col).getName();
/*      */       } catch (Exception ex1) {
/*  891 */         System.out.println("get Col " + layoutIdx + " " + col + " " + this.layout.getRecord(layoutIdx).getFieldCount() + " ~ " + ex1.getMessage());
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  902 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public IFieldDetail getLayoutField(int layoutIdx, int idx)
/*      */   {
/*  914 */     AbstractRecordDetail rec = this.layout.getRecord(layoutIdx);
/*  915 */     if (idx >= rec.getFieldCount()) {
/*  916 */       return null;
/*      */     }
/*  918 */     return rec.getField(idx);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getValueAt(int layoutIdx, int row, int col)
/*      */   {
/*  932 */     int tmpCol = getRealColumn(layoutIdx, col);
/*      */     try
/*      */     {
/*  935 */       if ((row >= getRowCount()) || ((tmpCol < 0) && (tmpCol != 64771)) || (this.layout == null) || (layoutIdx > this.layout.getRecordCount()) || (tmpCol >= this.layout.getRecord(layoutIdx).getFieldCount()))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  940 */         return null;
/*      */       }
/*      */       
/*  943 */       return this.lines.getTempLineRE(row).getField(layoutIdx, tmpCol);
/*      */     } catch (Exception e) {}
/*  945 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getTextValueAt(int layoutIdx, int row, int col)
/*      */   {
/*  963 */     col = getRealColumn(layoutIdx, col);
/*      */     
/*  965 */     if ((row >= getRowCount()) || (col < 0) || (col >= this.layout.getRecord(layoutIdx).getFieldCount()))
/*      */     {
/*      */ 
/*  968 */       return null;
/*      */     }
/*  970 */     return ((AbstractLine)this.lines.get(row)).getFieldText(layoutIdx, col);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public Object getHexValueAt(int layoutIdx, int row, int col)
/*      */   {
/*  984 */     col = getRealColumn(layoutIdx, col);
/*      */     
/*  986 */     if ((row >= getRowCount()) || (col < 0) || (col >= this.layout.getRecord(layoutIdx).getFieldCount()))
/*      */     {
/*      */ 
/*  989 */       return null;
/*      */     }
/*  991 */     return ((AbstractLine)this.lines.get(row)).getFieldHex(layoutIdx, col);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setValueAt(JFrame parentFrame, int layoutIdx, int row, int col, Object val)
/*      */   {
/* 1006 */     if (row < getRowCount()) {
/* 1007 */       setValueAt(parentFrame, layoutIdx, getLine(row), row, col, val);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setValueAt(JFrame parentFrame, int layoutIndex, AbstractLine currLine, int row, int col, Object val)
/*      */   {
/* 1022 */     if (this.browse) return;
/* 1023 */     int layoutIdx = layoutIndex;
/* 1024 */     if (DisplayType.displayType(this.layout, layoutIdx) == 1) {
/* 1025 */       layoutIdx = Math.max(0, currLine.getPreferredLayoutIdx());
/*      */     }
/*      */     
/* 1028 */     col = getRealColumn(layoutIdx, col);
/* 1029 */     if (((col >= 0) || (col == 64771)) && ((layoutIdx >= this.layout.getRecordCount()) || (layoutIdx < 0) || (col < this.layout.getRecord(layoutIdx).getFieldCount())))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1036 */       if ((val instanceof DelayedFieldValue))
/*      */       {
/* 1038 */         val = ((DelayedFieldValue)val).getValue(parentFrame);
/*      */       }
/*      */       
/* 1041 */       if ((val == null) || ((layoutIdx <= this.layout.getRecordCount()) && (currLine.isDefined(layoutIdx, col)) && (val.equals(currLine.getField(layoutIdx, col)))))
/*      */       {
/*      */ 
/* 1044 */         return;
/*      */       }
/* 1046 */       if (layoutIdx >= this.layout.getRecordCount()) {
/* 1047 */         switch (DisplayType.displayType(this.layout, layoutIdx))
/*      */         {
/*      */ 
/*      */         case 2: 
/* 1051 */           String s = val.toString();
/*      */           
/* 1053 */           currLine.setData(s);
/* 1054 */           fireRowUpdated(row, null, currLine); }
/*      */         
/* 1056 */         if ((val instanceof byte[])) {
/* 1057 */           currLine.setData((byte[])val);
/*      */         }
/*      */         
/*      */ 
/*      */       }
/* 1062 */       else if (parentFrame == null) {
/*      */         try {
/* 1064 */           Object o = null;
/* 1065 */           try { o = currLine.getField(layoutIdx, col); } catch (Exception e1) {}
/* 1066 */           currLine.setField(layoutIdx, col, val);
/* 1067 */           setChangedValue(o, currLine.getField(layoutIdx, col));
/*      */           
/* 1069 */           fireRowUpdated(row, layoutIdx, col, currLine);
/*      */         } catch (Exception e) {
/* 1071 */           e.printStackTrace();
/*      */         }
/*      */       } else {
/* 1074 */         updateField(1, parentFrame, currLine, layoutIdx, row, col, val);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void setChangedValue(Object oldValue, Object newValue) {
/* 1080 */     boolean update = newValue != oldValue;
/* 1081 */     if (oldValue != null) {
/* 1082 */       update = !oldValue.equals(newValue);
/*      */     }
/* 1084 */     if (update) {
/* 1085 */       setChanged(true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setHexTextValueAt(JFrame parentFrame, int inputType, int recordIdx, int row, int col, String val)
/*      */   {
/* 1100 */     if (this.baseFile.treeTableNotify != null) {
/* 1101 */       return;
/*      */     }
/* 1103 */     AbstractLine currLine = getLine(row);
/*      */     
/*      */ 
/* 1106 */     col = getRealColumn(recordIdx, col);
/* 1107 */     String oldValue; String oldValue; if (inputType == 2) {
/* 1108 */       oldValue = currLine.getFieldText(recordIdx, col);
/*      */     } else {
/* 1110 */       oldValue = currLine.getFieldHex(recordIdx, col);
/*      */     }
/*      */     
/* 1113 */     if (val.equals(oldValue)) {
/* 1114 */       return;
/*      */     }
/*      */     
/* 1117 */     updateField(inputType, parentFrame, currLine, recordIdx, row, col, val);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void updateField(int inputType, JFrame parentFrame, AbstractLine currLine, int recordIdx, int row, int col, Object val)
/*      */   {
/* 1135 */     String iMsg = updateField_100_applyValue(inputType, currLine, recordIdx, row, col, val);
/*      */     
/* 1137 */     while ((iMsg != null) && (this.displayErrorDialog)) {
/* 1138 */       val = JOptionPane.showInputDialog(parentFrame, iMsg, LangConversion.convert(2, "Conversion Error"), 0, null, null, val);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1144 */       iMsg = null;
/* 1145 */       if (val != null) {
/* 1146 */         iMsg = updateField_100_applyValue(inputType, currLine, recordIdx, row, col, val);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String updateField_100_applyValue(int updateType, AbstractLine currLine, int layoutIdx, int row, int col, Object val)
/*      */   {
/*      */     try
/*      */     {
/* 1166 */       Object o = null;
/* 1167 */       try { o = currLine.getField(layoutIdx, col);
/*      */       } catch (Exception e1) {}
/* 1169 */       switch (updateType) {
/* 1170 */       case 2:  currLine.setFieldText(layoutIdx, col, val.toString()); break;
/* 1171 */       case 3:  currLine.setFieldHex(layoutIdx, col, val.toString()); break;
/* 1172 */       default:  currLine.setField(layoutIdx, col, val);
/*      */       }
/*      */       
/* 1175 */       setChangedValue(o, currLine.getField(layoutIdx, col));
/*      */       
/* 1177 */       fireRowUpdated(row, layoutIdx, col, currLine);
/*      */       
/* 1179 */       return null;
/*      */     } catch (RecordException cex) {
/* 1181 */       return cex.getMessage();
/*      */     } catch (Exception ex) {
/* 1183 */       ex.printStackTrace();
/* 1184 */       return ex.getMessage();
/*      */     }
/*      */   }
/*      */   
/*      */   public final void fireTableRowsInsertedLocal(int firstLine, int lastLine) {
/* 1189 */     if (this.treeTableNotify == null) {
/* 1190 */       super.fireTableRowsInserted(firstLine, lastLine);
/*      */     }
/*      */     else {
/* 1193 */       for (int i = firstLine; i <= lastLine; i++) {
/* 1194 */         AbstractLineNode node = getNode(i);
/* 1195 */         if (node == null) {
/* 1196 */           super.fireTableRowsInserted(firstLine, lastLine);
/* 1197 */           return;
/*      */         }
/* 1199 */         this.treeTableNotify.fireTreeNodesInserted(node, node.getPath(), null, null);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void fireRowUpdated(int row, int recordIdx, int fieldIdx, AbstractLine currLine)
/*      */   {
/* 1212 */     fireRowUpdated(row, this.layout.getField(recordIdx, fieldIdx), currLine);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void fireRowUpdated(int row, IFieldDetail fld, AbstractLine currLine)
/*      */   {
/* 1222 */     if (this.baseFile.treeTableNotify == null) {
/* 1223 */       tblFireRowUpdated(row, currLine);
/* 1224 */     } else if (isView()) {
/* 1225 */       this.baseFile.fireRowUpdated(row, fld, currLine);
/*      */     } else {
/* 1227 */       AbstractLineNode node = getTreeNode(currLine);
/*      */       
/* 1229 */       if (node == null) {
/* 1230 */         tblFireRowUpdated(row, currLine);
/*      */       } else {
/* 1232 */         checkForTreeDelete(node, currLine);
/* 1233 */         this.baseFile.treeTableNotify.fireTreeNodesChanged(node, node.getPath(), null, null);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private final void checkForTreeDelete(AbstractLineNode node, AbstractLine currLine) {
/* 1239 */     int option = currLine.getOption(15);
/* 1240 */     boolean updated = false;
/* 1241 */     if (option >= 1)
/*      */     {
/*      */ 
/* 1244 */       for (int i = node.getChildCount() - 1; i >= 0; i--) {
/* 1245 */         TreeNode child = node.getChildAt(i);
/*      */         AbstractLine l;
/* 1247 */         if (((child instanceof AbstractLineNode)) && ((l = ((AbstractLineNode)child).getLine()) != null)) {
/* 1248 */           if (l.getOption(16) == 1) {
/* 1249 */             deleteOneLine(l);
/* 1250 */             updated = true;
/*      */           }
/* 1252 */         } else if (child != null) {
/* 1253 */           for (int j = child.getChildCount() - 1; j >= 0; j--) {
/* 1254 */             TreeNode c = child.getChildAt(j);
/*      */             AbstractLine l;
/* 1256 */             if (((c instanceof AbstractLineNode)) && ((l = ((AbstractLineNode)c).getLine()) != null) && (l.getOption(16) == 1))
/*      */             {
/* 1258 */               deleteOneLine(l);
/* 1259 */               updated = true;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/* 1264 */       if (updated) {
/* 1265 */         super.fireTableDataChanged();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void tblFireRowUpdated(int row, AbstractLine currLine)
/*      */   {
/* 1272 */     if (this.view) {
/* 1273 */       int baseRecordNumber = this.baseFile.indexOf(currLine);
/* 1274 */       this.baseFile.fireTableRowsUpdated(baseRecordNumber, baseRecordNumber);
/* 1275 */     } else if (row >= 0) {
/* 1276 */       super.fireTableRowsUpdated(row, row);
/*      */     } else {
/* 1278 */       super.fireTableDataChanged();
/*      */     }
/*      */   }
/*      */   
/*      */   private AbstractLineNode getNode(int lineNumber)
/*      */   {
/* 1284 */     AbstractLine l = (AbstractLine)this.lines.get(lineNumber);
/*      */     
/* 1286 */     return getTreeNode(l);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isCellEditable(int row, int col)
/*      */   {
/* 1295 */     return (col > 1) && ((this.currLayoutIdx != this.layout.getRecordCount() + 1) || ((!getFileView().isBinaryFile()) && (Common.OPTIONS.allowTextEditting.isSelected())));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getCurrLayoutIdx()
/*      */   {
/* 1307 */     return this.currLayoutIdx;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCurrLayoutIdx(int newIdx)
/*      */   {
/* 1317 */     if ((newIdx >= 0) && (newIdx < this.layout.getRecordCount() + 6)) {
/* 1318 */       this.currLayoutIdx = newIdx;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean insertCells(int recordIdx, int row, int column, IRetrieveTable tbl)
/*      */   {
/* 1341 */     column = getRealColumn(recordIdx, column - 2);
/* 1342 */     boolean changed = false;
/* 1343 */     while ((row < this.lines.size()) && (tbl.hasMoreRows())) {
/* 1344 */       AbstractLine line = getLine(row++);
/* 1345 */       List<String> colsToInsert = tbl.nextRowAsList();
/* 1346 */       if ((line instanceof IColumnInsertDelete)) {
/* 1347 */         ((IColumnInsertDelete)line).insetColumns(column, (String[])colsToInsert.toArray(new String[colsToInsert.size()]));
/*      */         
/*      */ 
/*      */ 
/* 1351 */         changed = true;
/*      */       }
/*      */     }
/* 1354 */     if (changed)
/*      */     {
/* 1356 */       setChanged(true);
/*      */     }
/* 1358 */     return changed;
/*      */   }
/*      */   
/*      */   public void deleteCells(int recordIdx, int[] recNums, int[] colNums)
/*      */   {
/* 1363 */     if ((this.layout.getOption(12) == 1) && (recordIdx >= 0) && (recordIdx < this.layout.getRecordCount()))
/*      */     {
/* 1365 */       for (int i = 0; i < colNums.length; i++) {
/* 1366 */         colNums[i] = getRealColumn(recordIdx, colNums[i] - 2);
/*      */       }
/* 1368 */       Arrays.sort(colNums);
/* 1369 */       for (int row : recNums) {
/* 1370 */         AbstractLine line = getLine(row);
/* 1371 */         if ((line instanceof IColumnInsertDelete)) {
/* 1372 */           ((IColumnInsertDelete)line).deleteColumns(colNums);
/*      */         }
/*      */       }
/* 1375 */       this.baseFile.fireTableDataChanged();
/* 1376 */       setChanged(true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void deleteLine(int recNum)
/*      */   {
/* 1387 */     if (this.lines.size() >= recNum) {
/* 1388 */       if (this.view)
/*      */       {
/*      */ 
/*      */ 
/* 1392 */         this.baseFile.deleteOneLine((AbstractLine)this.lines.get(recNum));
/*      */       } else {
/* 1394 */         fireTableRowsDeleted(recNum, recNum);
/*      */         
/* 1396 */         deleteNode((AbstractLine)this.lines.get(recNum));
/* 1397 */         this.lines.remove(recNum);
/*      */       }
/* 1399 */       setChanged(true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void deleteLines(int[] recNums)
/*      */   {
/* 1411 */     if (this.view) {
/* 1412 */       if (this.baseFile.treeTableNotify == null) {
/* 1413 */         int[] baseRecNums = new int[recNums.length];
/*      */         
/* 1415 */         for (int i = 0; i < baseRecNums.length; i++) {
/* 1416 */           baseRecNums[i] = this.baseFile.indexOf(this.lines.get(recNums[i]));
/*      */         }
/*      */         
/* 1419 */         deleteLinesFromView(recNums);
/* 1420 */         this.baseFile.deleteLinesFromView(baseRecNums);
/*      */       }
/*      */       else {
/* 1423 */         deleteLinesFromView(recNums);
/* 1424 */         for (int i = 0; i < recNums.length; i++) {
/* 1425 */           AbstractLine l = (AbstractLine)this.lines.get(recNums[i]);
/* 1426 */           this.baseFile.deleteOneLine(l);
/*      */         }
/*      */       }
/*      */     } else {
/* 1430 */       deleteLinesFromView(recNums);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void deleteLinesFromView(int[] recNums)
/*      */   {
/* 1441 */     if ((recNums != null) && (recNums.length > 0))
/*      */     {
/* 1443 */       Arrays.sort(recNums);
/* 1444 */       setChanged(true);
/*      */       
/* 1446 */       int start = recNums[(recNums.length - 1)];
/* 1447 */       int end = recNums[(recNums.length - 1)];
/*      */       
/* 1449 */       for (int i = recNums.length - 2; (i >= 0) && (recNums[i] >= 0); i--) {
/* 1450 */         if (start - 1 == recNums[i]) {
/* 1451 */           start--;
/* 1452 */         } else if (start != recNums[i]) {
/* 1453 */           fireTableRowsDeleted(start, end);
/*      */           
/* 1455 */           start = recNums[i];
/* 1456 */           end = recNums[i];
/*      */         }
/*      */       }
/*      */       
/* 1460 */       if (end >= 0)
/*      */       {
/* 1462 */         fireTableRowsDeleted(start, end);
/*      */       }
/*      */       
/*      */ 
/* 1466 */       int last = 64205;
/* 1467 */       for (i = recNums.length - 1; i >= 0; i--)
/*      */       {
/* 1469 */         if ((recNums[i] >= 0) && (recNums[i] < this.lines.size()) && (recNums[i] != last)) {
/* 1470 */           if (this.nodes != null) {
/* 1471 */             deleteNode((AbstractLine)this.lines.get(recNums[i]));
/*      */           }
/* 1473 */           this.lines.remove(recNums[i]);
/* 1474 */           last = recNums[i];
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void deleteLine(AbstractLine line)
/*      */   {
/* 1497 */     if (this.view) {
/* 1498 */       this.baseFile.deleteOneLine(line);
/*      */     } else {
/* 1500 */       deleteOneLine(line);
/*      */     }
/*      */   }
/*      */   
/*      */   private final void deleteOneLine(AbstractLine line)
/*      */   {
/* 1506 */     deleteNode(line);
/* 1507 */     if (line.getTreeDetails().getParentLine() != null) {
/* 1508 */       line.getTreeDetails().getParentLine().getTreeDetails().removeChild(line);
/*      */     } else {
/* 1510 */       int num = this.lines.indexOf(line);
/* 1511 */       if (num >= 0) {
/*      */         try {
/* 1513 */           fireTableRowsDeleted(num, num);
/*      */         } catch (Exception e) {
/* 1515 */           e.printStackTrace();
/*      */         }
/*      */         
/* 1518 */         this.lines.remove(num);
/*      */       }
/*      */     }
/*      */     
/* 1522 */     setChanged(true);
/*      */   }
/*      */   
/*      */   private void deleteNode(AbstractLine line)
/*      */   {
/* 1527 */     AbstractLineNode node = getTreeNode(line);
/*      */     
/* 1529 */     if (node != null) {
/* 1530 */       if (this.treeTableNotify != null) {
/* 1531 */         this.treeTableNotify.fireTreeNodesRemoved(node);
/*      */       }
/* 1533 */       node.removeFromParent();
/*      */     }
/*      */   }
/*      */   
/*      */   public void removeLineFromView(int lineNumber) {
/* 1538 */     if (this.view) {
/* 1539 */       this.lines.remove(lineNumber);
/*      */     } else {
/* 1541 */       deleteLine(lineNumber);
/*      */     }
/*      */   }
/*      */   
/*      */   public final AbstractLineNode getTreeNode(AbstractLine line) {
/* 1546 */     AbstractLineNode ret = null;
/* 1547 */     if (this.nodes != null) {
/* 1548 */       ret = (AbstractLineNode)this.nodes.get(line);
/*      */     }
/*      */     
/* 1551 */     return ret;
/*      */   }
/*      */   
/*      */   public final void setNodeForLine(AbstractLine line, AbstractLineNode node) {
/* 1555 */     if (this.nodes == null) {
/* 1556 */       defineNodes();
/*      */     }
/* 1558 */     this.nodes.put(line, node);
/*      */   }
/*      */   
/*      */   private synchronized void defineNodes() {
/* 1562 */     if (this.nodes == null) {
/* 1563 */       this.nodes = new WeakHashMap(this.lines.size());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final AbstractLine repeatLine(int lineNumber)
/*      */   {
/* 1587 */     if ((isView()) || (this.treeTableNotify == null)) {
/* 1588 */       return stdRepeatLine(lineNumber);
/*      */     }
/* 1590 */     return repeatLine((AbstractLine)this.lines.get(lineNumber));
/*      */   }
/*      */   
/*      */   public final AbstractLine repeatLine(AbstractLine line)
/*      */   {
/* 1595 */     AbstractLine newLine = null;
/* 1596 */     int idx = this.lines.indexOf(line);
/* 1597 */     if (line == null) {
/* 1598 */       Common.logMsg("No Physical Line, so can not repeat the line", null);
/* 1599 */     } else if ((isView()) || ((this.treeTableNotify == null) && (idx >= 0))) {
/* 1600 */       if (idx >= 0) {
/* 1601 */         newLine = stdRepeatLine(idx);
/*      */       } else {
/* 1603 */         newLine = this.baseFile.repeatLine(line);
/*      */       }
/*      */     } else {
/* 1606 */       switch (checkInsertOk(line.getTreeDetails().getParentLine(), line.getTreeDetails().getChildDefinitionInParent())) {
/*      */       case 1: 
/* 1608 */         AbstractLine parent = line.getTreeDetails().getParentLine();
/* 1609 */         int childIdx = line.getTreeDetails().getChildDefinitionInParent().getChildIndex();
/* 1610 */         int loc = parent.getTreeDetails().getLines(childIdx).indexOf(line);
/*      */         
/* 1612 */         newLine = line.getNewDataLine();
/* 1613 */         insert(parent, newLine, loc);
/* 1614 */         break;
/*      */       case 3: 
/* 1616 */         Common.logMsg("You can not Repeat the root Segment !!!", null);
/* 1617 */         break;
/*      */       case 4: 
/* 1619 */         Common.logMsgRaw(LangConversion.convert("Only one {0} is allowed !!!", line.getTreeDetails().getChildDefinitionInParent().getName()), null);
/*      */       }
/*      */       
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1627 */     return newLine;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void insert(AbstractLine parent, AbstractLine newLine, int loc)
/*      */   {
/* 1638 */     AbstractChildDetails childDef = newLine.getTreeDetails().getChildDefinitionInParent();
/* 1639 */     switch (checkInsertOk(parent, childDef)) {
/*      */     case 1: 
/*      */       AbstractLineNode node;
/* 1642 */       if (parent == null) {
/* 1643 */         if (loc < 0) {
/* 1644 */           this.lines.add(newLine);
/*      */         } else {
/* 1646 */           this.lines.add(loc, newLine);
/*      */         }
/* 1648 */         if (this.treeTableNotify != null) {
/* 1649 */           int RecordIdx = newLine.getPreferredLayoutIdx();
/* 1650 */           String name = "root";
/* 1651 */           if (RecordIdx > 0) {
/* 1652 */             name = getLayout().getRecord(RecordIdx).getRecordName();
/*      */           }
/*      */           
/*      */ 
/*      */ 
/* 1657 */           node = ((AbstractLineNode)this.treeTableNotify.getRoot()).insertNode(loc, name, this.baseFile, newLine);
/* 1658 */           this.treeTableNotify.fireTreeNodesInserted(node);
/*      */         } else {
/* 1660 */           fireTableRowsInsertedLocal(loc, loc);
/*      */         }
/*      */       } else {
/* 1663 */         parent.getTreeDetails().addChild(newLine, loc);
/*      */         
/*      */         AbstractLineNode pn;
/* 1666 */         if ((this.baseFile.treeTableNotify != null) && ((pn = getTreeNode(parent)) != null))
/*      */         {
/* 1668 */           node = pn.insert(newLine, -1, loc);
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1685 */       break;
/*      */     case 3: 
/* 1687 */       Common.logMsg("You can not add a second root segment !!!", null);
/* 1688 */       break;
/*      */     case 4: 
/* 1690 */       Common.logMsgRaw(LangConversion.convert("Only one {0} is allowed !!!", newLine.getTreeDetails().getChildDefinitionInParent().getName()), null);
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int checkInsertOk(AbstractLine parent, AbstractChildDetails childDef)
/*      */   {
/* 1699 */     int ret = 1;
/*      */     
/* 1701 */     if (parent == null) {
/* 1702 */       if (!this.allowMultipleRecords) {
/* 1703 */         ret = 3;
/*      */       }
/* 1705 */     } else if (childDef == null) {
/* 1706 */       ret = 5;
/*      */     }
/* 1708 */     else if ((parent.getTreeDetails().getChildCount() <= childDef.getChildIndex()) || (parent.getTreeDetails().getChildDetails(childDef.getChildIndex()) != childDef))
/*      */     {
/* 1710 */       ret = 5;
/* 1711 */     } else if ((!childDef.isRepeated()) && (parent.getTreeDetails().hasLines(childDef.getChildIndex())))
/*      */     {
/* 1713 */       ret = 4;
/*      */     }
/*      */     
/*      */ 
/* 1717 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */   private final AbstractLine stdRepeatLine(int lineNumber)
/*      */   {
/*      */     AbstractLine newLine;
/*      */     
/*      */     AbstractLine newLine;
/* 1726 */     if (isView()) {
/* 1727 */       int l = this.baseFile.indexOf(this.lines.get(lineNumber));
/* 1728 */       newLine = this.baseFile.repeatLine(l);
/*      */     } else {
/* 1730 */       newLine = ((AbstractLine)this.lines.get(lineNumber)).getNewDataLine();
/* 1731 */       setChanged(true);
/*      */     }
/* 1733 */     if (newLine != null) {
/* 1734 */       this.lines.add(lineNumber + 1, newLine);
/* 1735 */       fireTableRowsInsertedLocal(lineNumber + 1, lineNumber + 1);
/*      */     }
/* 1737 */     return newLine;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void copyLines(int[] recNums)
/*      */   {
/* 1749 */     int num = recNums.length;
/* 1750 */     int limit = getLineHoldLimit();
/*      */     
/* 1752 */     if (num > limit) {
/* 1753 */       num = limit;
/* 1754 */       Common.logMsgRaw(LangConversion.convert("Copy limit of {0} exceeded; only the first {1} lines copied", new Object[] { Integer.valueOf(limit), Integer.valueOf(limit) }), null);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1761 */     copySrc = newDataStore((num > 5000) || ((num > 50) && (!(this.baseFile.lines instanceof ArrayList))), num, 1L, null, null);
/*      */     
/* 1763 */     IProgressDisplay pd = newProgressDisplay((recNums.length < 50000) || (SwingUtilities.isEventDispatchThread()), "Copying " + getFileNameNoDirectory(), UtMessages.COPIED, recNums.length, 50000);
/*      */     
/*      */     try
/*      */     {
/* 1767 */       this.lines.extractLinesRE(copySrc, recNums, pd);
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*      */ 
/* 1773 */       pd.done();
/*      */     }
/*      */     
/* 1776 */     doCompress(recNums[0]);
/*      */     
/* 1778 */     GcManager.doGcIfNeccessary(0.5D);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void setCopyRecords(IDataStore<AbstractLine> copySrc)
/*      */   {
/* 1787 */     copySrc = copySrc;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void pasteLines(final int pos)
/*      */   {
/* 1796 */     if (copySrc != null) {
/* 1797 */       if (copySrc.size() < 50000) {
/* 1798 */         pasteLinesI(pos);
/*      */       } else {
/* 1800 */         Common.runOptionalyInBackground(new Runnable()
/*      */         {
/*      */           public void run() {
/* 1803 */             FileView.this.pasteLinesI(pos);
/*      */           }
/*      */         });
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public final void pasteLinesI(int pos) {
/* 1811 */     AbstractLine l = null;
/*      */     
/* 1813 */     if ((pos >= 0) && (pos < this.lines.size())) {
/* 1814 */       l = getLine(pos);
/*      */     }
/* 1816 */     pasteLines(pos, l);
/*      */   }
/*      */   
/*      */   private final IDataStore<AbstractLine> pasteLines(int pos, AbstractLine line)
/*      */   {
/* 1821 */     IDataStore<AbstractLine> ret = copySrc;
/* 1822 */     if ((copySrc != null) && (copySrc.size() > 0)) {
/* 1823 */       if ((this.treeTableNotify == null) || (pos < 0) || (getLine(pos).getTreeDetails().getParentLine() == null))
/*      */       {
/* 1825 */         ret = pasteTableLines(pos);
/*      */       } else {
/* 1827 */         ret = pasteTreeLines(line, false);
/*      */       }
/*      */     }
/* 1830 */     return ret;
/*      */   }
/*      */   
/*      */   private final IDataStore<AbstractLine> pasteTableLines(int pos) {
/*      */     IDataStore<AbstractLine> cpy;
/*      */     IDataStore<AbstractLine> cpy;
/* 1836 */     if (this.view) {
/* 1837 */       int lineNum = Math.max(0, pos);
/* 1838 */       AbstractLine line = null;
/* 1839 */       int baseRecordNumber = this.baseFile.getRowCount();
/*      */       
/* 1841 */       if (lineNum < this.lines.size()) {
/* 1842 */         line = (AbstractLine)this.lines.get(lineNum);
/* 1843 */         baseRecordNumber = this.baseFile.indexOf(line);
/*      */       }
/*      */       IDataStore<AbstractLine> cpy;
/* 1846 */       if (pos < 0) {
/* 1847 */         cpy = this.baseFile.pasteLines(baseRecordNumber - 1, null);
/*      */       } else {
/* 1849 */         cpy = this.baseFile.pasteLines(baseRecordNumber, line);
/*      */       }
/*      */     } else {
/* 1852 */       cpy = copySrc;
/*      */     }
/*      */     
/* 1855 */     return doPaste(pos, cpy);
/*      */   }
/*      */   
/*      */   public final IDataStore<AbstractLine> pasteTreeLines(LinePosition pos)
/*      */   {
/* 1860 */     return pasteTreeLines(pos.line, pos.before);
/*      */   }
/*      */   
/*      */   private final IDataStore<AbstractLine> pasteTreeLines(AbstractLine pos, boolean prev)
/*      */   {
/* 1865 */     IDataStore<AbstractLine> ret = null;
/* 1866 */     if ((copySrc != null) && (copySrc.size() > 0) && (((AbstractLine)copySrc.get(0)).getLayout() == this.layout))
/*      */     {
/* 1868 */       copySrc.setLayoutRE(this.layout);
/*      */       
/* 1870 */       ret = pasteTreeLines(pos, copySrc, prev);
/* 1871 */       setChanged(true);
/*      */     }
/*      */     
/* 1874 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final IDataStore<AbstractLine> pasteTreeLines(AbstractLine pos, IDataStore<AbstractLine> copySource, boolean prev)
/*      */   {
/* 1883 */     AbstractLine parent = null;
/*      */     
/*      */ 
/* 1886 */     IDataStore<AbstractLine> ret = copySource;
/*      */     
/* 1888 */     if (copySource.size() > 0) {
/* 1889 */       IDataStore<AbstractLine> accepted = DataStoreStd.newStore(((AbstractLine)copySource.get(0)).getLayout(), copySource.size());
/*      */       
/* 1891 */       int arrayPos = -1;
/*      */       
/* 1893 */       if (pos != null) {
/* 1894 */         parent = pos.getTreeDetails().getParentLine();
/* 1895 */         arrayPos = pos.getTreeDetails().getParentIndex() + 1;
/* 1896 */         if ((prev) && (arrayPos > 0)) {
/* 1897 */           arrayPos--;
/*      */         }
/*      */       }
/*      */       
/* 1901 */       int p = -1;
/* 1902 */       if ((pos == null) || (prev)) {
/* 1903 */         p = 0;
/*      */       }
/* 1905 */       int idx = this.lines.indexOf(pos);
/* 1906 */       if ((idx >= 0) && (!prev)) {
/* 1907 */         idx++;
/*      */       }
/* 1909 */       for (int i = 0; i < copySource.size(); i++) {
/* 1910 */         AbstractChildDetails childDef = ((AbstractLine)copySource.get(i)).getTreeDetails().getChildDefinitionInParent();
/* 1911 */         if (checkInsertOk(pos, childDef) == 1) {
/* 1912 */           accepted.add(copySource.get(i));
/* 1913 */           insert(pos, (AbstractLine)copySource.get(i), p++);
/* 1914 */           p = inc(p);
/* 1915 */         } else if (checkInsertOk(parent, childDef) == 1) {
/* 1916 */           if (parent == null) {
/* 1917 */             accepted.add(copySource.get(i));
/* 1918 */             insert(null, (AbstractLine)copySource.get(i), idx);
/* 1919 */             idx = inc(idx);
/*      */           } else {
/* 1921 */             int id = -1;
/* 1922 */             if (pos.getTreeDetails().getChildDefinitionInParent() == childDef) {
/* 1923 */               id = arrayPos++;
/*      */             }
/* 1925 */             accepted.add(copySource.get(i));
/* 1926 */             insert(parent, (AbstractLine)copySource.get(i), id);
/*      */           }
/*      */         } else {
/* 1929 */           String name = "";
/*      */           try {
/* 1931 */             name = this.layout.getRecord(((AbstractLine)copySource.get(i)).getPreferredLayoutIdx()).getRecordName();
/*      */           }
/*      */           catch (Exception e) {}
/* 1934 */           Common.logMsg(30, "Can not paste", name + ":  " + ((AbstractLine)copySource.get(i)).getFullLine(), null);
/*      */         }
/*      */       }
/*      */       
/* 1938 */       ret = accepted;
/*      */     }
/*      */     
/* 1941 */     return ret;
/*      */   }
/*      */   
/*      */   private int inc(int val) {
/* 1945 */     if (val >= 0) {
/* 1946 */       val++;
/*      */     }
/* 1948 */     return val;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private IDataStore<AbstractLine> doPaste(int pos, IDataStore<AbstractLine> newLines)
/*      */   {
/* 1961 */     IDataStore<AbstractLine> ret = newLines;
/* 1962 */     int cpySize = newLines.size();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1967 */     if (isView()) {
/* 1968 */       this.lines.addAll(Math.min(pos + 1, this.lines.size()), newLines);
/*      */ 
/*      */ 
/*      */     }
/* 1972 */     else if (cpySize > 0)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1978 */       pos = Math.min(pos, this.lines.size() - 1);
/* 1979 */       IProgressDisplay pd = newProgressDisplay(SwingUtilities.isEventDispatchThread(), "Pasting", UtMessages.PASTE, newLines.size(), 50000);
/*      */       try {
/* 1981 */         this.lines.addCopyRE(pos + 1, newLines, pd);
/*      */       } finally {
/* 1983 */         pd.done();
/*      */       }
/*      */       
/* 1986 */       doCompress(pos);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2016 */       ret = new DataStoreRange(this.lines, pos + 1, cpySize);
/*      */     }
/*      */     
/* 2019 */     setChanged(true);
/* 2020 */     fireTableRowsInsertedLocal(pos + 1, pos + cpySize);
/* 2021 */     GcManager.doGcIfNeccessary(0.5D);
/*      */     
/* 2023 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final int newLine(int pos, int adj)
/*      */   {
/* 2036 */     if (this.view) {
/* 2037 */       int basePos = this.baseFile.newLine(getBasePosition(pos), adj);
/*      */       
/* 2039 */       pos = addLineInternal(pos + adj, this.baseFile.getLine(basePos));
/*      */     } else {
/* 2041 */       if (this.ioProvider == null) {
/* 2042 */         this.ioProvider = LineIOProvider.getInstance();
/*      */       }
/* 2044 */       pos = addLineInternal(pos + adj, this.ioProvider.getLineProvider(this.layout).getLine(this.layout));
/*      */     }
/*      */     
/*      */ 
/* 2048 */     fireTableRowsInsertedLocal(pos, pos);
/*      */     
/* 2050 */     return pos;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final int addLine(int pos, AbstractLine line)
/*      */   {
/* 2065 */     if (this.view) {
/* 2066 */       int p = this.baseFile.getRowCount();
/* 2067 */       if ((pos >= 0) && (pos < this.lines.size())) {
/* 2068 */         p = this.baseFile.indexOf(this.lines.get(pos));
/* 2069 */         if (pos < 0) {
/* 2070 */           p = this.baseFile.getRowCount();
/*      */         }
/*      */       }
/*      */       
/* 2074 */       p = this.baseFile.addLine(p, line);
/* 2075 */       line = this.baseFile.getLine(p);
/*      */     }
/* 2077 */     int ret = addLineInternal(pos - 1, line);
/* 2078 */     fireTableRowsInsertedLocal(ret, ret);
/* 2079 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final int addLines(int pos, int adj, AbstractLine[] linesToAdd)
/*      */   {
/* 2092 */     int initialPos = pos + adj;
/* 2093 */     pos += adj;
/* 2094 */     if (this.view) {
/* 2095 */       linesToAdd = (AbstractLine[])linesToAdd.clone();
/* 2096 */       this.baseFile.addLines(getBasePosition(pos - adj), adj, linesToAdd);
/* 2097 */       for (int i = 0; i < linesToAdd.length; i++) {
/* 2098 */         pos = addLineInternal(pos, linesToAdd[i]);
/* 2099 */         if (i == 0) {
/* 2100 */           initialPos = pos;
/*      */         }
/*      */       }
/*      */     }
/*      */     else {
/* 2105 */       for (int i = 0; i < linesToAdd.length; i++) {
/* 2106 */         pos = addLineInternal(pos, linesToAdd[i]);
/* 2107 */         linesToAdd[i] = ((AbstractLine)this.lines.get(pos));
/* 2108 */         if (i == 0) {
/* 2109 */           initialPos = pos;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2114 */     fireTableRowsInsertedLocal(initialPos, initialPos + linesToAdd.length - 1);
/*      */     
/*      */ 
/* 2117 */     return pos;
/*      */   }
/*      */   
/*      */   private int getBasePosition(int pos)
/*      */   {
/* 2122 */     int baseRecordNumber = this.baseFile.getRowCount();
/* 2123 */     if ((this.lines.size() > 0) && (pos < this.lines.size())) {
/* 2124 */       baseRecordNumber = this.baseFile.indexOf(this.lines.get(pos));
/*      */     }
/* 2126 */     return baseRecordNumber;
/*      */   }
/*      */   
/*      */   public final AbstractLine[] createLines(int count) {
/* 2130 */     AbstractLine[] ret = new AbstractLine[count];
/*      */     
/* 2132 */     if (this.baseFile.ioProvider == null) {
/* 2133 */       this.baseFile.ioProvider = LineIOProvider.getInstance();
/*      */     }
/*      */     
/* 2136 */     for (int i = 0; i < count; i++) {
/* 2137 */       ret[i] = this.baseFile.ioProvider.getLineProvider(this.layout).getLine(this.layout);
/*      */     }
/*      */     
/* 2140 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int addLineInternal(int pos, AbstractLine line)
/*      */   {
/* 2165 */     if ((this.lines.size() == 0) || (pos >= this.lines.size() - 1)) {
/* 2166 */       pos = this.lines.size();
/* 2167 */       this.lines.add(line);
/*      */     } else {
/* 2169 */       pos++;
/* 2170 */       this.lines.add(pos, line);
/*      */     }
/*      */     
/* 2173 */     return pos;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void replaceAll(String searchFor, String replaceWith, FilePosition pos, boolean ignoreCase, int operator)
/*      */     throws RecordException
/*      */   {
/* 2198 */     pos.col = 0;
/* 2199 */     pos.row = 0;
/*      */     
/* 2201 */     while (replace(searchFor, replaceWith, pos, ignoreCase, operator, false)) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean replace(String searchFor, String replaceWith, FilePosition pos, boolean ignoreCase, int operator, boolean eofCheck)
/*      */     throws RecordException
/*      */   {
/* 2228 */     find(searchFor, pos, ignoreCase, operator, eofCheck);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2235 */     if (pos.found)
/*      */     {
/*      */ 
/* 2238 */       int col = getRealColumn(pos.recordId, pos.currentFieldNumber);
/*      */       String s;
/* 2240 */       if (operator == 0) {
/* 2241 */         String s = ((AbstractLine)this.lines.get(pos.row)).getField(pos.recordId, col).toString();
/* 2242 */         StringBuffer b = new StringBuffer(s);
/*      */         
/* 2244 */         b.replace(pos.col, pos.col + searchFor.length(), replaceWith);
/* 2245 */         s = b.toString();
/*      */       } else {
/* 2247 */         s = replaceWith;
/*      */       }
/*      */       
/* 2250 */       AbstractLine updateLine = pos.currentLine;
/*      */       
/* 2252 */       if (updateLine == null) {
/* 2253 */         updateLine = (AbstractLine)this.lines.get(pos.row);
/*      */       }
/* 2255 */       updateLine.setField(pos.recordId, col, s);
/* 2256 */       setChanged(true);
/*      */       
/* 2258 */       pos.adjustPosition(replaceWith.length(), operator);
/*      */     }
/* 2260 */     return (pos.found) && (pos.row >= 0) && (pos.row < this.lines.size());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void find(String searchFor, FilePosition pos, boolean ignoreCase, int operator, boolean eofCheck)
/*      */   {
/* 2280 */     String icSearchFor = searchFor;
/* 2281 */     pos.found = false;
/*      */     
/* 2283 */     BigDecimal testNumber = Compare.getNumericValue(operator, searchFor);
/* 2284 */     boolean anyWhereInTheField = (operator == 0) || (operator == 2);
/*      */     
/* 2286 */     boolean normalSearch = operator == 0;
/*      */     
/*      */ 
/* 2289 */     if (ignoreCase) {
/* 2290 */       icSearchFor = searchFor.toUpperCase();
/*      */     }
/*      */     
/*      */ 
/* 2294 */     PositionIncrement inc = PositionIncrement.newIncrement(pos, this.lines, eofCheck);
/* 2295 */     if (anyWhereInTheField)
/*      */     {
/* 2297 */       while ((inc.isValidPosition()) && (!contains(ignoreCase, inc.pos, icSearchFor, normalSearch))) {
/* 2298 */         inc.nextPosition();
/*      */       }
/*      */     }
/*      */     
/* 2302 */     while ((inc.isValidPosition()) && (!cmp(ignoreCase, inc.pos, icSearchFor, testNumber, operator))) {
/* 2303 */       inc.nextPosition();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean cmp(boolean ignoreCase, FilePosition pos, String testValue, BigDecimal testNumber, int operator)
/*      */   {
/* 2325 */     int col = getRealColumn(pos.recordId, pos.currentFieldNumber);
/* 2326 */     String s = getFieldValue(pos, col);
/* 2327 */     boolean normalSearch = false;
/*      */     
/*      */ 
/*      */ 
/* 2331 */     if ((pos.col > 0) && (pos.col != Integer.MAX_VALUE)) {
/* 2332 */       return false;
/*      */     }
/*      */     
/* 2335 */     switch (operator) {
/* 2336 */     case 1:  normalSearch = true;
/*      */     case 3: 
/* 2338 */       if (ignoreCase) {
/* 2339 */         pos.found = (s.equalsIgnoreCase(testValue) == normalSearch);
/*      */       } else {
/* 2341 */         pos.found = (s.equals(testValue) == normalSearch);
/*      */       }
/* 2343 */       break;
/*      */     case 4: 
/* 2345 */       pos.found = ((s != null) && (s.startsWith(testValue)));
/* 2346 */       break;
/*      */     case 5: 
/*      */     case 6: 
/*      */     case 7: 
/*      */     case 8: 
/*      */     case 9: 
/* 2352 */       pos.found = cmpToNum(s, testNumber, Compare.OPERATOR_COMPARATOR_VALUES[(operator - 5)]);
/*      */       
/* 2354 */       break;
/*      */     case 10: 
/*      */     case 11: 
/*      */     case 12: 
/*      */     case 13: 
/* 2359 */       int[] vals = Compare.OPERATOR_COMPARATOR_VALUES[(operator - 10)];
/*      */       int v;
/* 2361 */       int v; if (ignoreCase) {
/* 2362 */         v = s.compareToIgnoreCase(testValue);
/*      */       } else {
/* 2364 */         v = s.compareTo(testValue);
/*      */       }
/* 2366 */       if (v > 0) {
/* 2367 */         v = 1;
/* 2368 */       } else if (v < 0) {
/* 2369 */         v = -1;
/*      */       }
/*      */       
/* 2372 */       pos.found = ((v == vals[0]) || (v == vals[1]));
/*      */     }
/*      */     
/*      */     
/* 2376 */     if (pos.found) {
/* 2377 */       pos.col = 0;
/*      */     }
/* 2379 */     return pos.found;
/*      */   }
/*      */   
/*      */   private boolean cmpToNum(String s, BigDecimal testValue, int[] vals) {
/* 2383 */     int v = -121;
/* 2384 */     BigDecimal fldValue = null;
/*      */     try
/*      */     {
/* 2387 */       fldValue = new BigDecimal(s);
/*      */     }
/*      */     catch (Exception e) {}
/* 2390 */     if ((fldValue == null) && (testValue == null)) {
/* 2391 */       v = 0;
/* 2392 */     } else { if (fldValue == null)
/* 2393 */         return false;
/* 2394 */       if (testValue == null) {
/* 2395 */         v = -1;
/*      */       } else {
/* 2397 */         v = fldValue.compareTo(testValue);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 2403 */     return (v == vals[0]) || (v == vals[1]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean contains(boolean ignoreCase, FilePosition pos, String testValue, boolean normalSearch)
/*      */   {
/* 2425 */     int col = getRealColumn(pos.recordId, pos.currentFieldNumber);
/* 2426 */     String s = getFieldValue(pos, col);
/*      */     
/* 2428 */     int fromIndex = Integer.MAX_VALUE;
/*      */     
/*      */ 
/* 2431 */     if (pos.isForward()) {
/* 2432 */       fromIndex = 0;
/*      */     }
/*      */     
/* 2435 */     if ((pos.col > 0) && (pos.col != Integer.MAX_VALUE)) {
/* 2436 */       fromIndex = pos.col;
/*      */     }
/*      */     
/* 2439 */     if (pos.isForward()) {
/* 2440 */       if (ignoreCase) {
/* 2441 */         pos.col = s.toUpperCase().indexOf(testValue.toUpperCase(), fromIndex);
/*      */       } else {
/* 2443 */         pos.col = s.indexOf(testValue, fromIndex);
/*      */       }
/*      */     }
/* 2446 */     else if (ignoreCase) {
/* 2447 */       pos.col = s.toUpperCase().lastIndexOf(testValue.toUpperCase(), fromIndex);
/*      */     } else {
/* 2449 */       pos.col = s.lastIndexOf(testValue, fromIndex);
/*      */     }
/*      */     
/* 2452 */     pos.found = (pos.col >= 0 == normalSearch);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2459 */     return pos.found;
/*      */   }
/*      */   
/*      */   private String getFieldValue(FilePosition pos, int col) {
/* 2463 */     AbstractLine l = pos.currentLine;
/* 2464 */     String s = "";
/* 2465 */     if ((l == null) && (pos.row >= 0) && (pos.row < this.lines.size())) {
/* 2466 */       l = this.lines.getTempLineRE(pos.row);
/*      */     }
/*      */     
/* 2469 */     pos.layoutIdxUsed = -121;
/* 2470 */     if (l != null) {
/*      */       try {
/* 2472 */         if (pos.getFieldId() == -101) {
/* 2473 */           s = toStr(l.getFullLine());
/* 2474 */         } else if ((pos.currentLine != null) && (pos.getFieldId() == -102)) {
/* 2475 */           pos.layoutIdxUsed = l.getPreferredLayoutIdx();
/* 2476 */           s = toStr(l.getField(l.getPreferredLayoutIdx(), col));
/*      */         }
/*      */         else {
/* 2479 */           pos.layoutIdxUsed = pos.recordId;
/* 2480 */           s = toStr(l.getField(pos.recordId, col));
/*      */         }
/*      */       } catch (Exception e) {
/* 2483 */         e.printStackTrace();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 2488 */     return s;
/*      */   }
/*      */   
/*      */   private String toStr(Object o) {
/* 2492 */     String s = "";
/* 2493 */     if (o != null) {
/* 2494 */       s = o.toString();
/*      */     }
/* 2496 */     return s;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final AbstractLine getLine(int lineNum)
/*      */   {
/* 2508 */     return (AbstractLine)this.lines.get(lineNum);
/*      */   }
/*      */   
/*      */   public final void setLine(int lineNum, AbstractLine l) {
/* 2512 */     boolean changed = (lineNum < 0) || (lineNum >= this.lines.size()) || (this.lines.get(lineNum) != l);
/*      */     
/* 2514 */     this.lines.set(lineNum, l);
/* 2515 */     setChanged(changed);
/* 2516 */     tblFireRowUpdated(lineNum, (AbstractLine)this.lines.get(lineNum));
/*      */   }
/*      */   
/*      */   public final AbstractLine getTempLine(int lineNum)
/*      */   {
/* 2521 */     return this.lines.getTempLineRE(lineNum);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public final boolean isBrowse()
/*      */   {
/* 2528 */     return this.browse;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean isChanged()
/*      */   {
/* 2536 */     if (isView()) {
/* 2537 */       return this.baseFile.isChanged();
/*      */     }
/* 2539 */     return this.changeStatus != 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setChanged(boolean fileChanged)
/*      */   {
/* 2549 */     if (isView()) {
/* 2550 */       this.baseFile.setChanged(fileChanged);
/*      */     }
/*      */     
/* 2553 */     if (fileChanged) {
/* 2554 */       this.changeStatus = 3;
/*      */     } else {
/* 2556 */       this.changeStatus = 1;
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isSaveAvailable()
/*      */   {
/* 2562 */     return this.saveAvailable;
/*      */   }
/*      */   
/*      */   public boolean isTreeViewAvailable() {
/* 2566 */     return ((this.lines instanceof DataStoreStd)) || ((this.lines != null) && (this.lines.size() < Common.OPTIONS.filterLimit.get()));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void setFrame(JFrame aFrame)
/*      */   {
/* 2574 */     this.frame = aFrame;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isBinaryFile()
/*      */   {
/* 2582 */     return this.layout.isBinary();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final AbstractLayoutDetails getLayout()
/*      */   {
/* 2591 */     return this.layout;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void setLayout(AbstractLayoutDetails layout)
/*      */   {
/* 2599 */     this.layout = layout;
/* 2600 */     checkIfTextFile();
/* 2601 */     this.lines.setLayoutRE(layout);
/*      */     
/* 2603 */     this.maxNumColumns = -1;
/* 2604 */     this.columnMapping = NULL_MAPPING;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeFile()
/*      */     throws IOException, RecordException
/*      */   {
/* 2615 */     if (this.view) {
/* 2616 */       this.baseFile.writeFile();
/* 2617 */     } else if (this.lines == null) {
/* 2618 */       Common.logMsgRaw(INTERNAL_ERROR_LINES_CLEARED_SAVE_IS_NOT_POSSIBLE, null);
/*      */     }
/*      */     else
/*      */     {
/* 2622 */       this.changeStatus = 2;
/* 2623 */       saveFile(this.lines, this.fileName, this.toSave, new PropertyChangeListener()
/*      */       {
/*      */ 
/*      */         public void propertyChange(PropertyChangeEvent arg0)
/*      */         {
/* 2628 */           if (FileView.this.changeStatus == 2) {
/* 2629 */             FileView.this.toSave = false;
/* 2630 */             FileView.this.changeStatus = 1;
/* 2631 */             FileView.this.dropCompletedWriters();
/*      */           }
/*      */         }
/*      */       });
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeFile(String outFile)
/*      */     throws IOException, RecordException
/*      */   {
/* 2651 */     writeLinesToFile(outFile, this.lines);
/* 2652 */     if (("".equals(this.fileName)) && (!isView())) {
/* 2653 */       this.fileName = outFile;
/* 2654 */       setChanged(false);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeFile(String outFile, int[] lines2write)
/*      */     throws IOException, RecordException
/*      */   {
/* 2670 */     writeLinesToFile(outFile, getLines(lines2write));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void writeLinesToFile(String outFile, List<AbstractLine> lines2write)
/*      */     throws IOException, RecordException
/*      */   {
/* 2685 */     boolean sameName = outFile.equals(this.fileName);
/* 2686 */     PropertyChangeListener chg = null;
/*      */     
/* 2688 */     if ((!sameName) && ("\\".equals(Common.FILE_SEPERATOR))) {
/* 2689 */       sameName = outFile.equalsIgnoreCase(this.fileName);
/*      */     }
/*      */     
/* 2692 */     this.toSave &= sameName;
/*      */     
/* 2694 */     if (sameName) {
/* 2695 */       this.changeStatus = 2;
/* 2696 */       chg = new PropertyChangeListener()
/*      */       {
/*      */         public void propertyChange(PropertyChangeEvent arg0)
/*      */         {
/* 2700 */           if (FileView.this.changeStatus == 2) {
/* 2701 */             FileView.this.toSave = false;
/* 2702 */             FileView.this.changeStatus = 1;
/*      */           }
/*      */         }
/*      */       };
/*      */     }
/*      */     
/* 2708 */     saveFile(lines2write, outFile, this.toSave, chg);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void saveFile(List<AbstractLine> pLines, String pFileName, boolean backup, PropertyChangeListener chgListner)
/*      */     throws IOException, RecordException
/*      */   {
/* 2730 */     boolean isGZip = checkIfGZip(pFileName);
/* 2731 */     AbstractLineWriter writer = this.ioProvider.getLineWriter(this.layout.getFileStructure(), this.layout.getFontName());
/* 2732 */     FileWriter fileWriter = new FileWriter(pLines, this.layout, pFileName, backup, isGZip, writer);
/*      */     
/* 2734 */     dropCompletedWriters();
/*      */     
/* 2736 */     if (pLines.size() < 50000) {
/* 2737 */       fileWriter.doWrite();
/* 2738 */       if (chgListner != null) {
/* 2739 */         chgListner.propertyChange(null);
/*      */       }
/*      */     } else {
/*      */       try {
/* 2743 */         FileWriterBackground fw = new FileWriterBackground(fileWriter);
/*      */         
/* 2745 */         if (chgListner != null) {
/* 2746 */           fw.addPropertyChangeListener(chgListner);
/*      */         }
/* 2748 */         this.writers.add(new WeakReference(fileWriter));
/* 2749 */         fw.addPropertyChangeListener(this.saveDoneListner);
/* 2750 */         fw.execute();
/*      */       } catch (NoClassDefFoundError e) {
/* 2752 */         fileWriter.doWrite();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void dropCompletedWriters() {
/* 2758 */     for (int i = this.writers.size() - 1; i >= 0; i--) {
/* 2759 */       if ((((WeakReference)this.writers.get(i)).get() == null) || (((FileWriter)((WeakReference)this.writers.get(i)).get()).isDone())) {
/* 2760 */         this.writers.remove(i);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int getLineHoldLimit()
/*      */   {
/* 2797 */     int limit = Integer.MAX_VALUE;
/* 2798 */     if (!(this.lines instanceof DataStoreStd)) {
/* 2799 */       limit = Common.OPTIONS.filterLimit.get();
/*      */     }
/* 2801 */     return limit;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public FileView getFilteredView(FilterDetails filter)
/*      */   {
/* 2813 */     if (filter.isNormalFilter() != FilterDetails.FT_NORMAL) {
/* 2814 */       return getFilteredView(filter, filter.getGroupHeader());
/*      */     }
/* 2816 */     ViewDataStore selected = new ViewDataStore(this.layout, this.lines instanceof DataStoreStd, this.frame, this.baseFile.lines);
/*      */     
/*      */ 
/* 2819 */     boolean filterNonPrefered = getFilterNonPref(filter);
/*      */     
/* 2821 */     FilterFieldBaseList list = filter.getFilterFieldListMdl();
/* 2822 */     IDataStoreIterator it = getIterator();
/*      */     
/*      */ 
/* 2825 */     IProgressDisplay pd = newProgressDisplay((this.lines.size() < 50000) || (SwingUtilities.isEventDispatchThread()), "Filtering " + getFileNameNoDirectory(), UtMessages.FILTER, this.lines.size(), 50000);
/*      */     
/*      */     try
/*      */     {
/* 2829 */       int count = 0;int sel = 0;
/* 2830 */       while ((it.hasNext()) && (selected.continueProcessing())) {
/* 2831 */         AbstractLine line = it.nextTempRE();
/* 2832 */         if (check(filterNonPrefered, filter, list, line, false) >= 0) {
/* 2833 */           selected.add(it.currentLineRE());
/* 2834 */           sel++;
/*      */         }
/* 2836 */         if (!pd.updateProgress(count++, sel))
/*      */         {
/*      */           break;
/*      */ 
/*      */         }
/*      */         
/*      */       }
/*      */       
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/*      */ 
/* 2849 */       pd.done();
/*      */     }
/*      */     
/*      */ 
/* 2853 */     doCompress(0);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2874 */     if (selected.getSelectedLines().size() > 0) {
/* 2875 */       return new FileView(selected.getSelectedLines(), this.baseFile, new FieldMapping(filter.getFieldMap(), getFieldCounts()));
/*      */     }
/*      */     
/*      */ 
/* 2879 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public FileView getFilteredView(FilterDetails filter, int groupHeader)
/*      */   {
/* 2891 */     ViewDataStore selected = new ViewDataStore(this.layout, this.lines instanceof DataStoreStd, this.frame, this.baseFile.lines);
/*      */     
/* 2893 */     ArrayList<AbstractLine> groupLines = new ArrayList();
/*      */     
/* 2895 */     boolean filterNonPrefered = getFilterNonPref(filter);
/*      */     
/* 2897 */     FilterFieldBaseList list = filter.getFilterFieldListMdl();
/* 2898 */     IDataStoreIterator it = getIterator();
/* 2899 */     RecordSel groupSelection = list.getGroupRecordSelection();
/* 2900 */     int count = 0;
/*      */     
/* 2902 */     while (it.hasNext()) {
/* 2903 */       AbstractLine line = (AbstractLine)it.next();
/* 2904 */       count++;
/* 2905 */       if (line.getPreferredLayoutIdxAlt() == groupHeader) {
/* 2906 */         if (filter.isInGroup(line.getPreferredLayoutIdxAlt())) {
/* 2907 */           groupLines.add(line);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2915 */     IProgressDisplay pd = newProgressDisplay((this.lines.size() < 50000) || (SwingUtilities.isEventDispatchThread()), "Filtering " + getFileNameNoDirectory(), UtMessages.FILTER, this.lines.size(), 50000);
/*      */     try {
/* 2917 */       while ((it.hasNext()) && (selected.continueProcessing())) {
/* 2918 */         AbstractLine line = it.nextTempRE();
/* 2919 */         if (line.getPreferredLayoutIdxAlt() == groupHeader) {
/* 2920 */           processGroup(selected, filterNonPrefered, filter, groupSelection, groupLines);
/*      */         }
/* 2922 */         if (filter.isInGroup(line.getPreferredLayoutIdxAlt())) {
/* 2923 */           groupLines.add(it.currentLineRE());
/*      */         }
/*      */         
/* 2926 */         if (!pd.updateProgress(count++, selected.size())) {
/*      */           break;
/*      */         }
/*      */       }
/*      */     } finally {
/* 2931 */       pd.done();
/*      */     }
/*      */     
/*      */ 
/* 2935 */     processGroup(selected, filterNonPrefered, filter, groupSelection, groupLines);
/* 2936 */     doCompress(0);
/*      */     
/* 2938 */     if (selected.getSelectedLines().size() > 0) {
/* 2939 */       return new FileView(selected.getSelectedLines(), this.baseFile, new FieldMapping(filter.getFieldMap(), getFieldCounts()));
/*      */     }
/*      */     
/*      */ 
/* 2943 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void processGroup(ViewDataStore selected, boolean filterNonPrefered, FilterDetails filter, RecordSel groupSelection, ArrayList<AbstractLine> groupLines)
/*      */   {
/* 2952 */     FilterFieldBaseList list = filter.getFilterFieldListMdl();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 2957 */     if (groupSelection.isSelected(groupLines))
/*      */     {
/*      */ 
/* 2960 */       for (int i = 0; i < groupLines.size(); i++) {
/* 2961 */         AbstractLine l = (AbstractLine)groupLines.get(i);
/* 2962 */         int recId = l.getPreferredLayoutIdx();
/* 2963 */         if (recId < 0) {
/* 2964 */           recId = check(filterNonPrefered, filter, list, l, true);
/*      */         }
/*      */         
/* 2967 */         if (filter.isInclude(recId)) {
/* 2968 */           selected.add(l);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2973 */     groupLines.clear();
/*      */   }
/*      */   
/*      */   private int[] getFieldCounts() {
/* 2977 */     int[] rows = new int[this.layout.getRecordCount()];
/*      */     
/* 2979 */     for (int i = 0; i < this.layout.getRecordCount(); i++) {
/* 2980 */       rows[i] = getLayoutColumnCount(i);
/*      */     }
/*      */     
/* 2983 */     return rows;
/*      */   }
/*      */   
/*      */   private boolean getFilterNonPref(FilterDetails filter) {
/* 2987 */     boolean filterNonPrefered = false;
/*      */     
/* 2989 */     if (this.layout.getRecordCount() > 1) {
/* 2990 */       for (int k = 0; (!filterNonPrefered) && (k < this.layout.getRecordCount()); k++) {
/* 2991 */         filterNonPrefered = (filter.isInclude(k)) && (this.layout.getRecord(k).getOption(1) == 0);
/*      */       }
/*      */     }
/*      */     
/* 2995 */     return filterNonPrefered;
/*      */   }
/*      */   
/*      */   private IDataStoreIterator getIterator() {
/*      */     IDataStoreIterator it;
/*      */     IDataStoreIterator it;
/* 3001 */     if (this.layout.hasChildren()) {
/* 3002 */       it = new TreeIteratorForward(this.lines, null);
/*      */     } else {
/* 3004 */       it = new DataStoreIterator(this.lines);
/*      */     }
/* 3006 */     return it;
/*      */   }
/*      */   
/*      */   private int check(boolean filterNonPrefered, FilterDetails filter, FilterFieldBaseList list, AbstractLine line, boolean allRecs)
/*      */   {
/* 3011 */     int ret = Integer.MIN_VALUE;
/* 3012 */     int recordType = line.getPreferredLayoutIdxAlt();
/*      */     
/* 3014 */     if ((filterNonPrefered) && (recordType == Integer.MIN_VALUE)) {
/* 3015 */       for (int k = 0; k < this.layout.getRecordCount(); k++) {
/* 3016 */         if (((allRecs) || (filter.isInclude(k))) && (this.layout.getRecord(k).getOption(1) == 0))
/*      */         {
/* 3018 */           if (getFilteredView_MatchesFilter(k, list, line)) {
/* 3019 */             ret = k;
/* 3020 */             break;
/*      */           }
/*      */         }
/*      */       }
/* 3024 */     } else if (((allRecs) || (filter.isInclude(recordType))) && (getFilteredView_MatchesFilter(recordType, list, line))) {
/* 3025 */       ret = recordType;
/*      */     } else {
/* 3027 */       ret = -1 * recordType - 1;
/*      */     }
/* 3029 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */   private boolean getFilteredView_MatchesFilter(int recordType, FilterFieldBaseList list, AbstractLine line)
/*      */   {
/* 3035 */     return list.getRecordSelection(recordType).isSelected(line);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public FileView getView()
/*      */   {
/* 3045 */     return new FileView(this.lines.newDataStoreRE(), this.baseFile, this.columnMapping);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public FileView getView(int[] rows)
/*      */   {
/* 3056 */     if ((rows == null) || (rows.length == 0)) {
/* 3057 */       return null;
/*      */     }
/*      */     
/* 3060 */     return new FileView(this.lines.newDataStoreRE(rows), this.baseFile, this.columnMapping);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final FileView getViewOfErrorRecords()
/*      */   {
/* 3073 */     DataStoreStd<AbstractLine> selectedLines = DataStoreStd.newStore(this.layout);
/* 3074 */     TreeIteratorForward it = new TreeIteratorForward(this.lines, null);
/*      */     
/* 3076 */     while (it.hasNext()) {
/* 3077 */       AbstractLine line = it.next();
/* 3078 */       if (line.isError()) {
/* 3079 */         selectedLines.add(line);
/*      */       }
/*      */     }
/*      */     
/* 3083 */     if (selectedLines.size() == 0) {
/* 3084 */       return null;
/*      */     }
/* 3086 */     return new FileView(selectedLines, this.baseFile, this.columnMapping);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public FileView getView(List<AbstractLine> list)
/*      */   {
/* 3098 */     if ((list == null) || (list.size() == 0)) {
/* 3099 */       return null;
/*      */     }
/*      */     
/*      */     IDataStore<AbstractLine> ds;
/* 3103 */     if ((this.lines instanceof DataStoreLarge)) {
/* 3104 */       IDataStore<AbstractLine> ds = new DataStoreLargeView(this.lines, new int[0]);
/* 3105 */       ds.addAll(list);
/*      */     } else {
/* 3107 */       ds = DataStoreStd.newStore(this.layout, list);
/*      */     }
/*      */     
/* 3110 */     return new FileView(ds, this.baseFile, this.columnMapping);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getRealColumn(int layoutIndex, int inColumn)
/*      */   {
/* 3120 */     int ret = this.columnMapping.getRealColumn(layoutIndex, inColumn);
/*      */     
/* 3122 */     ret = this.layout.getAdjFieldNumber(layoutIndex, ret);
/*      */     
/* 3124 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isFileRead()
/*      */   {
/* 3132 */     return this.fileRead;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getMsg()
/*      */   {
/* 3140 */     return this.msg;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int indexOf(Object line)
/*      */   {
/* 3152 */     return this.lines.indexOf(line);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void tableChanged(TableModelEvent event)
/*      */   {
/* 3161 */     if (this.lines == null) {
/* 3162 */       this.baseFile.removeTableModelListener(this);
/* 3163 */       return;
/*      */     }
/* 3165 */     if (this.view) {
/* 3166 */       int lastRow = event.getLastRow();
/* 3167 */       int firstRow = Math.max(0, event.getFirstRow());
/*      */       
/* 3169 */       switch (event.getType())
/*      */       {
/*      */       case 1: 
/*      */         break;
/*      */       case -1: 
/* 3174 */         if (lastRow - firstRow + 1 > 0) {
/* 3175 */           int[] recNums = new int[lastRow - firstRow + 1];
/*      */           
/*      */ 
/* 3178 */           for (int i = firstRow; i <= lastRow; i++) {
/* 3179 */             recNums[(i - firstRow)] = this.lines.indexOf(this.baseFile.getLine(i));
/*      */           }
/*      */           
/*      */ 
/* 3183 */           deleteLinesFromView(recNums); }
/* 3184 */         break;
/*      */       
/*      */       default: 
/* 3187 */         if ((this.layout != this.baseFile.getLayout()) || (event.getFirstRow() < 0)) {
/* 3188 */           setLayout(this.baseFile.getLayout());
/* 3189 */           fireTableStructureChanged();
/*      */         } else {
/* 3191 */           fireTableDataChanged();
/*      */         }
/*      */         break;
/*      */       }
/* 3195 */       if ((this.lines instanceof IDataStoreView)) {
/* 3196 */         ((IDataStoreView)this.lines).tableChangedUpdateRE(event);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getFileName()
/*      */   {
/* 3208 */     if (isView()) {
/* 3209 */       return this.baseFile.getFileName();
/*      */     }
/* 3211 */     return this.fileName;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getFileNameNoDirectory()
/*      */   {
/* 3221 */     if (isView()) {
/* 3222 */       return this.baseFile.getFileNameNoDirectory();
/*      */     }
/* 3224 */     if (this.altName != null) {
/* 3225 */       return this.altName;
/*      */     }
/* 3227 */     return Common.stripDirectory(this.fileName);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public FileView getBaseFile()
/*      */   {
/* 3237 */     return this.baseFile;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isView()
/*      */   {
/* 3247 */     return this.view;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean checkIfGZip(String fileName2test)
/*      */   {
/* 3261 */     return fileName2test.toUpperCase().endsWith(".GZ");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public AbstractLineIOProvider getIoProvider()
/*      */   {
/* 3269 */     return this.ioProvider;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void sort(LineCompare compare)
/*      */   {
/* 3278 */     this.lines.sortRE(compare);
/*      */     
/* 3280 */     sortNotify();
/*      */     
/* 3282 */     doCompress(0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void sort(int[] rows, LineCompare compare)
/*      */   {
/* 3290 */     this.lines.sortRE(rows, compare);
/* 3291 */     sortNotify();
/*      */     
/* 3293 */     if (rows.length > 20000) {
/* 3294 */       doCompress(rows[(rows.length - 1)]);
/*      */     }
/*      */   }
/*      */   
/*      */   public void oldSort(int[] rows, LineCompare compare)
/*      */   {
/* 3300 */     AbstractLine[] rowsToSort = new AbstractLine[rows.length];
/*      */     
/* 3302 */     for (int i = 0; i < rows.length; i++) {
/* 3303 */       rowsToSort[i] = ((AbstractLine)this.lines.get(rows[i]));
/*      */     }
/*      */     
/* 3306 */     Arrays.sort(rowsToSort, compare);
/*      */     
/*      */ 
/*      */ 
/* 3310 */     for (i = 0; i < rows.length; i++) {
/* 3311 */       this.lines.set(rows[i], rowsToSort[i]);
/*      */     }
/*      */     
/* 3314 */     sortNotify();
/*      */   }
/*      */   
/*      */ 
/*      */   private void sortNotify()
/*      */   {
/* 3320 */     this.changeStatus = 3;
/* 3321 */     if (this.treeTableNotify == null) {
/* 3322 */       fireTableDataChanged();
/* 3323 */     } else if (this.lines.size() > 0) {
/* 3324 */       Object rootObject = this.treeTableNotify.getRoot();
/*      */       
/* 3326 */       if ((rootObject instanceof AbstractLineNode))
/*      */       {
/* 3328 */         int[] childIndices = new int[this.lines.size()];
/* 3329 */         AbstractLineNode[] children = new AbstractLineNode[this.lines.size()];
/* 3330 */         AbstractLineNode root = (AbstractLineNode)rootObject;
/* 3331 */         synchronized (rootObject) {
/* 3332 */           root.removeAllChildren();
/*      */           
/* 3334 */           for (int i = 0; i < getRowCount(); i++) {
/* 3335 */             AbstractLineNode node = getTreeNode((AbstractLine)this.lines.get(i));
/* 3336 */             childIndices[i] = i;
/* 3337 */             children[i] = node;
/*      */             
/* 3339 */             if (node != null) {
/* 3340 */               root.add(node);
/*      */             }
/*      */           }
/*      */         }
/* 3344 */         this.treeTableNotify.fireTreeNodesChanged(root, root.getPath(), childIndices, children);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public Iterator<AbstractLine> iterator()
/*      */   {
/* 3352 */     if (this.layout.hasChildren()) {
/* 3353 */       return new TreeIteratorForward(this.lines, (AbstractLine)this.lines.get(0));
/*      */     }
/*      */     
/* 3356 */     return this.lines.listIterator();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public final List<AbstractLine> getLines()
/*      */   {
/* 3363 */     return this.lines;
/*      */   }
/*      */   
/*      */   public final List<AbstractLine> getLines(int[] lineNumbers) {
/* 3367 */     ArrayList<AbstractLine> returnLines = new ArrayList(lineNumbers.length);
/*      */     
/*      */ 
/* 3370 */     for (int i = 0; i < lineNumbers.length; i++) {
/* 3371 */       if ((lineNumbers[i] >= 0) && (lineNumbers[i] < this.lines.size())) {
/* 3372 */         returnLines.add(this.lines.get(lineNumbers[i]));
/*      */       }
/*      */     }
/* 3375 */     return returnLines;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public final void setDisplayErrorDialog(boolean newDisplayErrorDialog)
/*      */   {
/* 3382 */     this.displayErrorDialog = newDisplayErrorDialog;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public final boolean isAllowMultipleRecords()
/*      */   {
/* 3389 */     return this.allowMultipleRecords;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public final void setAllowMultipleRecords(boolean allowMultipleRecords)
/*      */   {
/* 3396 */     this.allowMultipleRecords = allowMultipleRecords;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public final TreeTableNotify getTreeTableNotify()
/*      */   {
/* 3403 */     return this.treeTableNotify;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public final void setTreeTableNotify(TreeTableNotify newTreeTableNotify)
/*      */   {
/* 3410 */     this.treeTableNotify = newTreeTableNotify;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void addTreeModelListener(TreeModelListener l)
/*      */   {
/* 3417 */     if (isView()) {
/* 3418 */       this.baseFile.addTreeModelListener(l);
/* 3419 */     } else if (this.treeTableNotify != null) {
/* 3420 */       this.treeTableNotify.addTreeModelListener(l);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeTreeModelListener(TreeModelListener l)
/*      */   {
/* 3429 */     if (isView()) {
/* 3430 */       this.baseFile.removeTreeModelListener(l);
/* 3431 */     } else if (this.treeTableNotify != null) {
/* 3432 */       this.treeTableNotify.removeTreeModelListener(l);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void treeNodesChanged(TreeModelEvent arg0)
/*      */   {
/* 3443 */     invokeLaterDataChanged();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void treeNodesInserted(TreeModelEvent arg0)
/*      */   {
/* 3451 */     invokeLaterDataChanged();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void treeNodesRemoved(TreeModelEvent arg0)
/*      */   {
/* 3459 */     invokeLaterDataChanged();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void treeStructureChanged(TreeModelEvent arg0)
/*      */   {
/* 3467 */     invokeLaterDataChanged();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void notifyOfChange(AbstractLine line)
/*      */   {
/* 3475 */     if (this.baseFile.treeTableNotify == null) {
/* 3476 */       invokeLaterDataChanged();
/*      */     } else {
/* 3478 */       this.baseFile.fireRowUpdated(0, null, line);
/*      */     }
/*      */   }
/*      */   
/*      */   private void invokeLaterDataChanged()
/*      */   {
/* 3484 */     SwingUtilities.invokeLater(new Runnable()
/*      */     {
/*      */ 
/*      */ 
/*      */       public void run()
/*      */       {
/*      */ 
/* 3491 */         FileView.this.baseFile.fireTableDataChanged();
/*      */       }
/*      */     });
/*      */   }
/*      */   
/*      */   private IDataStore checkDataStore4ModeListner(IDataStore s) {
/* 3497 */     if ((s instanceof TableModelListener)) {
/* 3498 */       addTableModelListener((TableModelListener)s);
/*      */     }
/* 3500 */     return s;
/*      */   }
/*      */   
/*      */   private void newLines(int noLines, long bytes, AbstractLineReader<AbstractLayoutDetails> reader, String fname)
/*      */   {
/* 3505 */     if ((this.lines != null) && ((this.lines instanceof TableModelListener))) {
/* 3506 */       removeTableModelListener((TableModelListener)this.lines);
/*      */     }
/* 3508 */     this.lines = newDataStore(useBigFileModel(bytes), noLines, bytes, reader, fname);
/*      */   }
/*      */   
/*      */   public final IDataStore<AbstractLine> newDataStore(boolean useBigFileMdl, int noLines, long bytes, AbstractLineReader<AbstractLayoutDetails> reader, String fname)
/*      */   {
/* 3513 */     if (this.layout == null) {
/* 3514 */       return new DataStoreStd.DataStoreStdBinary(this.layout, noLines);
/*      */     }
/* 3516 */     if ((useBigFileMdl) && (this.layout.getOption(7) == 1)) {
/* 3517 */       AbstractLayoutDetails l = (LayoutDetail)this.layout;
/*      */       
/* 3519 */       int fileStructure = l.getFileStructure();
/* 3520 */       if (l.getOption(3) == 4) {
/* 3521 */         System.out.println("Editing using Char-Line Big memory Model - this will reduce functionality !!!");
/*      */         
/*      */ 
/* 3524 */         return new DataStoreLarge((LayoutDetail)this.layout, 3, 100000);
/*      */       }
/*      */       
/*      */ 
/* 3528 */       if ((fileStructure == 21) || (fileStructure == 22) || (l.getLayoutType() == 2) || (fileStructure == 51) || (fileStructure == 52))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 3533 */         System.out.println("\nEditing using Big Variable Length memory Model - this will reduce functionality !!!");
/*      */         
/*      */ 
/* 3536 */         return new DataStoreLarge((LayoutDetail)this.layout, 2, 100000);
/*      */       }
/*      */       
/*      */ 
/* 3540 */       if (l.getOption(8) == 1) {
/* 3541 */         System.out.println("Editing using Big Fixed Length memory Model - this will reduce functionality !!!");
/*      */         
/*      */ 
/* 3544 */         return new DataStoreLarge((LayoutDetail)this.layout, 1, this.layout.getMaximumRecordLength());
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 3549 */       System.out.println("Editing using Big Variable Length memory Model - this will reduce functionality !!!");
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 3554 */       int type = 2;
/* 3555 */       IByteReader r = null;
/*      */       
/* 3557 */       char largeOpt = Common.OPTIONS.largeVbOption.get();
/* 3558 */       if ((reader != null) && ((reader instanceof LineReaderWrapper)) && (fileStructure != 5) && ((largeOpt == 'T') || ((largeOpt == 'Y') && (bytes > Runtime.getRuntime().totalMemory()))))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3564 */         type = 5;
/* 3565 */         r = ((LineReaderWrapper)reader).getByteReader();
/*      */       }
/*      */       
/* 3568 */       return new DataStoreLarge((LayoutDetail)this.layout, type, this.layout.getMaximumRecordLength(), r, fname);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 3579 */     return checkDataStore4ModeListner(DataStoreStd.newStore(this.layout, noLines));
/*      */   }
/*      */   
/*      */   private static IProgressDisplay newProgressDisplay(boolean useEmpty, String heading, ReMsg msg, int total, int checkCountAt) {
/* 3583 */     if (useEmpty) {
/* 3584 */       return EMPTY_PROGRESS;
/*      */     }
/*      */     
/* 3587 */     return new ProgressDialog(heading, msg, total, checkCountAt);
/*      */   }
/*      */   
/*      */   public final boolean useBigFileModel(long bytes)
/*      */   {
/* 3592 */     if ((this.layout != null) && (this.layout.getOption(7) == 1)) {
/* 3593 */       if (this.layout.getOption(3) == 4) {
/* 3594 */         bytes *= 2L;
/*      */       }
/* 3596 */       return bytes > this.memoryCompare;
/*      */     }
/* 3598 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean[] getFieldVisibility(int recordIdx)
/*      */   {
/* 3607 */     return this.columnMapping.getFieldVisibility(recordIdx);
/*      */   }
/*      */   
/*      */   public boolean isSimpleCsvFile() {
/* 3611 */     return (this.layout.getRecordCount() == 1) && ((this.layout.getFileStructure() == 51) || (this.layout.getRecord(0).getRecordType() == 2) || (this.layout.getRecord(0).getRecordType() == 3));
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void doCompress(final int pos)
/*      */   {
/* 3618 */     if ((((this.lines instanceof DataStoreLarge)) && (((DataStoreLarge)this.lines).getFileDetails().isOkToCompress(2))) || (((copySrc instanceof DataStoreLarge)) && (((DataStoreLarge)copySrc).getFileDetails().isOkToCompress(2))))
/*      */     {
/* 3620 */       new Thread(new Runnable()
/*      */       {
/*      */ 
/*      */         public void run()
/*      */         {
/* 3625 */           if ((FileView.copySrc instanceof DataStoreLarge)) {
/* 3626 */             ((DataStoreLarge)FileView.copySrc).doCompress(1, -1);
/*      */           }
/* 3628 */           if ((FileView.this.lines instanceof DataStoreLarge)) {
/* 3629 */             ((DataStoreLarge)FileView.this.lines).doCompress(4, pos);
/*      */           }
/*      */         }
/*      */       }).start();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public FileView getFileView()
/*      */   {
/* 3641 */     return this;
/*      */   }
/*      */   
/*      */   public boolean isDocumentViewAvailable(boolean colorView) {
/* 3645 */     return (this.lines.isTextViewPossibleRE()) && (this.layout.getOption(10) == 1) && (this.textFile);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void checkIfTextFile()
/*      */   {
/* 3652 */     for (int i = 0; i < this.layout.getRecordCount(); i++) {
/* 3653 */       AbstractRecordDetail record = this.layout.getRecord(i);
/* 3654 */       for (int j = 0; j < record.getFieldCount(); j++) {
/* 3655 */         if (TypeManager.getInstance().getType(record.getField(j).getType()).isBinary()) {
/* 3656 */           this.textFile = false;
/* 3657 */           return;
/*      */         }
/*      */       }
/*      */     }
/* 3661 */     this.textFile = true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public DataStoreContent asDocumentContent()
/*      */   {
/* 3676 */     if (this.lines.isTextViewPossibleRE()) {
/* 3677 */       return new DataStoreContent(this, this.lines.getTextInterfaceRE());
/*      */     }
/* 3679 */     return null; }
/*      */   
/*      */   private class ChkStore implements CheckStore { long checkRecsAt;
/*      */     long checkAdj;
/* 3683 */     long count = 0L;
/*      */     
/*      */     private ChkStore() {
/* 3686 */       int len = FileView.this.layout.getMaximumRecordLength();
/*      */       
/* 3688 */       this.checkRecsAt = calcAdj(len);
/* 3689 */       this.checkAdj = this.checkRecsAt;
/*      */     }
/*      */     
/*      */     private long calcAdj(long len) {
/* 3693 */       if (len == 0L) {
/* 3694 */         len = 50L;
/*      */       }
/*      */       
/*      */ 
/* 3698 */       return Math.max(10000L, FileView.this.memoryCompare / (len * 10L) * 11L / 5L);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void checkDatasStore(int numLines)
/*      */     {
/* 3706 */       this.count += numLines;
/* 3707 */       if (this.count > this.checkRecsAt) {
/* 3708 */         long bytes = FileView.this.lines.getSpaceRE();
/* 3709 */         int size = FileView.this.lines.size();
/*      */         
/* 3711 */         if (FileView.this.useBigFileModel(bytes)) {
/* 3712 */           IDataStore<AbstractLine> newDataStore = FileView.this.newDataStore(true, FileView.this.lines.size(), bytes, null, "");
/* 3713 */           for (int i = 0; i < size; i++) {
/* 3714 */             newDataStore.add(FileView.this.lines.get(i));
/* 3715 */             FileView.this.lines.set(i, null);
/*      */           }
/* 3717 */           FileView.this.lines = newDataStore;
/* 3718 */           this.checkRecsAt = 2147483646L;
/* 3719 */           this.count = 0L;
/*      */         } else {
/* 3721 */           this.checkAdj = calcAdj(bytes / size);
/*      */           
/* 3723 */           this.checkRecsAt += this.checkAdj;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/FileView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */