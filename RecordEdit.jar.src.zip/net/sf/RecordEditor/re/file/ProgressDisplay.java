/*    */ package net.sf.RecordEditor.re.file;
/*    */ 
/*    */ import java.awt.Container;
/*    */ import java.io.PrintStream;
/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.JProgressBar;
/*    */ import javax.swing.JTextArea;
/*    */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*    */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProgressDisplay
/*    */ {
/* 17 */   private JFrame frame = null;
/*    */   
/* 19 */   private JTextArea area = new JTextArea();
/*    */   
/*    */   private JProgressBar progressBar;
/*    */   
/*    */   private final String frameName;
/*    */   
/*    */ 
/*    */   public ProgressDisplay(String action, String name)
/*    */   {
/* 28 */     this.frameName = (action + " " + name);
/*    */   }
/*    */   
/*    */   public void updateDisplay(String msg, int progress) {
/* 32 */     this.area.setText(msg + "          ");
/* 33 */     System.out.println(msg);
/* 34 */     init();
/* 35 */     this.progressBar.setValue(progress);
/*    */   }
/*    */   
/*    */   public void done()
/*    */   {
/* 40 */     if ((this.frame != null) && (this.frame.isVisible())) {
/* 41 */       this.frame.setVisible(false);
/*    */     }
/*    */   }
/*    */   
/*    */   private void init() {
/* 46 */     if (this.frame == null) {
/* 47 */       synchronized (this.area) {
/* 48 */         if (this.frame == null) {
/* 49 */           this.frame = new JFrame(this.frameName);
/* 50 */           BasePanel pnl = new BasePanel();
/*    */           
/* 52 */           this.frame.setDefaultCloseOperation(2);
/*    */           
/* 54 */           this.progressBar = new JProgressBar(0, 100);
/* 55 */           this.progressBar.setValue(0);
/*    */           
/*    */ 
/* 58 */           pnl.addComponentRE(1, 5, -2.0D, BasePanel.GAP1, 2, 2, this.progressBar);
/*    */           
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 64 */           this.area.setFont(SwingUtils.getMonoSpacedFont());
/* 65 */           pnl.addComponentRE(1, 5, -2.0D, BasePanel.GAP1, 2, 2, this.area);
/*    */           
/*    */ 
/*    */ 
/*    */ 
/* 70 */           this.frame.getContentPane().add(pnl);
/* 71 */           this.frame.pack();
/*    */           
/*    */ 
/* 74 */           this.frame.setVisible(true);
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/ProgressDisplay.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */