/*     */ package net.sf.RecordEditor.re.file;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.event.TableModelEvent;
/*     */ import javax.swing.event.TableModelListener;
/*     */ import javax.swing.text.AbstractDocument.Content;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import javax.swing.text.Segment;
/*     */ import javax.swing.undo.UndoableEdit;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.RecordEditor.utils.fileStorage.DataStorePosition;
/*     */ import net.sf.RecordEditor.utils.fileStorage.IDataStore;
/*     */ import net.sf.RecordEditor.utils.fileStorage.IDataStorePosition;
/*     */ import net.sf.RecordEditor.utils.fileStorage.ITextInterface;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ZOld_DataStoreContent
/*     */   implements AbstractDocument.Content, TableModelListener
/*     */ {
/*     */   public static final int INSERT = 121;
/*     */   public static final int UPDATE = 122;
/*     */   public static final int DELETE = 123;
/*     */   private final FileView fileView;
/*     */   private final IDataStore<? extends AbstractLine> datastore;
/*     */   private final ITextInterface ti;
/*  38 */   private final ArrayList<RefDataStore> positions = new ArrayList(150);
/*     */   
/*     */ 
/*  41 */   private long lastClearedTime = 0L;
/*  42 */   private int checkMethod = 0;
/*     */   
/*  44 */   private DocumentUpdateListner documentUpdateListner = null;
/*     */   
/*  46 */   private boolean notifyDocument = true;
/*     */   
/*     */ 
/*     */   public ZOld_DataStoreContent(FileView file, ITextInterface ti)
/*     */   {
/*  51 */     this.datastore = ti.getDataStore();
/*  52 */     this.ti = ti;
/*  53 */     this.fileView = file;
/*  54 */     file.addTableModelListener(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IDataStorePosition createPosition(int offset)
/*     */     throws BadLocationException
/*     */   {
/*  66 */     return register(this.ti.getTextPosition(offset));
/*     */   }
/*     */   
/*     */   private IDataStorePosition register(DataStorePosition pos)
/*     */   {
/*  71 */     if (pos == null) return pos;
/*  72 */     RefDataStore r = new RefDataStore(pos);
/*  73 */     IDataStorePosition ret = (IDataStorePosition)r.get();
/*     */     
/*  75 */     int firstKey = getValidPosIndex(0, 0, this.positions.size() - 1);
/*  76 */     int lastKey = getValidPosIndex(this.positions.size() - 1, 0, this.positions.size() - 1);
/*  77 */     int offset = pos.getOffset();
/*  78 */     if ((this.positions.size() == 0) || (((RefDataStore)this.positions.get(lastKey)).pos.getOffset() < offset))
/*     */     {
/*  80 */       this.positions.add(r);
/*  81 */     } else if (((RefDataStore)this.positions.get(firstKey)).pos.getOffset() >= offset)
/*     */     {
/*  83 */       ret = addPosition(firstKey, r);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 108 */       int key = findPosByKey(offset, true);
/* 109 */       if (key < 0) {
/* 110 */         linearSearch(r, offset);
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 116 */         ret = addPosition(key, r);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 138 */     return ret;
/*     */   }
/*     */   
/*     */   private IDataStorePosition linearSearch(RefDataStore r, int offset) {
/* 142 */     IDataStorePosition pos = (IDataStorePosition)r.get();
/*     */     
/* 144 */     int idx = getValidPosIndex(0, 0, this.positions.size() - 1);
/*     */     
/* 146 */     while ((idx < this.positions.size()) && (((RefDataStore)this.positions.get(idx)).pos.getOffset() < offset)) {
/* 147 */       idx = getValidPosIndex(idx++, idx, this.positions.size() - 1);
/*     */     }
/*     */     
/* 150 */     pos = addPosition(idx, r);
/*     */     
/* 152 */     return pos;
/*     */   }
/*     */   
/*     */   private IDataStorePosition addPosition(int idx, RefDataStore r) {
/* 156 */     int where = r.pos.getOffset();
/*     */     
/* 158 */     if (idx >= this.positions.size())
/*     */     {
/* 160 */       this.positions.add(r);
/* 161 */     } else if (((RefDataStore)this.positions.get(idx)).pos.getOffset() == where) {
/* 162 */       IDataStorePosition p = (IDataStorePosition)((RefDataStore)this.positions.get(idx)).get();
/* 163 */       if (p != null)
/*     */       {
/* 165 */         return p;
/*     */       }
/* 167 */       this.positions.set(idx, r);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 172 */       this.positions.add(idx, r);
/*     */     }
/* 174 */     return (IDataStorePosition)r.get();
/*     */   }
/*     */   
/*     */   public IDataStorePosition createTempPosition(int offset) {
/* 178 */     IDataStorePosition pos = findPosition(offset, true);
/* 179 */     if (pos != null) {
/* 180 */       return pos;
/*     */     }
/* 182 */     return this.ti.getTextPosition(offset);
/*     */   }
/*     */   
/*     */   public IDataStorePosition getLinePosition(int lineNo) {
/* 186 */     return getLinePosition(lineNo, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IDataStorePosition getLinePosition(int lineNo, boolean register)
/*     */   {
/* 195 */     DataStorePosition linePosition = this.ti.getPositionByLineNumber(lineNo);
/* 196 */     IDataStorePosition ret = linePosition;
/* 197 */     if (register) {
/* 198 */       ret = register(linePosition);
/*     */     }
/* 200 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */   private IDataStorePosition findPosition(int searchValue, boolean offset)
/*     */   {
/* 206 */     IDataStorePosition ret = null;
/*     */     
/* 208 */     int key = findPosByKey(searchValue, offset);
/* 209 */     IDataStorePosition chk1; if ((key >= 0) && (key < this.positions.size()) && ((chk1 = (IDataStorePosition)((RefDataStore)this.positions.get(key)).get()) != null))
/*     */     {
/* 211 */       DataStorePosition chk = ((RefDataStore)this.positions.get(key)).pos;
/* 212 */       if (((offset) && (chk.getOffset() == searchValue)) || ((!offset) && (chk.getLineNumberRE() == searchValue) && (chk.getPositionInLineRE() == 0)))
/*     */       {
/* 214 */         if (chk.getLineRE() == this.datastore.get(chk.getLineNumberRE())) {
/*     */           try {
/* 216 */             chk.updatePositionRE();
/* 217 */             ret = chk1;
/*     */           } catch (Exception e) {
/* 219 */             this.positions.remove(key);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 225 */     return ret;
/*     */   }
/*     */   
/*     */   private int findPosByKey(int searchValue, boolean offset)
/*     */   {
/* 230 */     synchronized (this.positions)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 235 */       clearIfNecessary();
/* 236 */       int low = 0;
/*     */       
/*     */ 
/* 239 */       if (this.positions.size() == 0) { return 0;
/*     */       }
/* 241 */       int high = this.positions.size() - 1;
/*     */       
/* 243 */       if (calcCompare(searchValue, offset, ((RefDataStore)this.positions.get(0)).pos) >= 0) {
/* 244 */         return 0;
/*     */       }
/*     */       
/* 247 */       int v = calcCompare(searchValue, offset, ((RefDataStore)this.positions.get(high)).pos);
/* 248 */       if (v == 0)
/* 249 */         return high;
/* 250 */       if (v < 0) {
/* 251 */         return high + 1;
/*     */       }
/*     */       
/* 254 */       while (high > low) {
/* 255 */         int mid = (high + low) / 2;
/*     */         
/*     */ 
/* 258 */         DataStorePosition p = ((RefDataStore)this.positions.get(mid)).pos;
/*     */         
/* 260 */         v = calcCompare(searchValue, offset, p);
/*     */         
/* 262 */         if (high - 1 <= low)
/*     */         {
/*     */ 
/* 265 */           if (v <= 0) {
/* 266 */             low = mid;
/* 267 */             if (v < 0) {
/* 268 */               v = calcCompare(searchValue, offset, ((RefDataStore)this.positions.get(high)).pos);
/* 269 */               if (v >= 0) {
/* 270 */                 low = high;
/*     */               }
/*     */               
/*     */             }
/*     */             
/*     */           }
/*     */           
/*     */         }
/* 278 */         else if (v < 0) {
/* 279 */           low = mid;
/* 280 */         } else if (v > 0) {
/* 281 */           high = mid;
/*     */         } else {
/* 283 */           return mid;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 298 */       return low;
/*     */     }
/*     */   }
/*     */   
/*     */   private int calcCompare(int searchValue, boolean offset, DataStorePosition p) { int v;
/*     */     int v;
/* 304 */     if (offset) {
/* 305 */       int x = p.getOffset();
/*     */       
/* 307 */       v = x == searchValue ? 0 : x < searchValue ? -1 : 1;
/*     */     }
/*     */     else {
/* 310 */       v = Integer.compare(p.lineNumber, searchValue);
/* 311 */       if ((v == 0) && (p.positionInLine > 0)) {
/* 312 */         v = 1;
/*     */       }
/*     */     }
/*     */     
/* 316 */     return v;
/*     */   }
/*     */   
/*     */ 
/*     */   private void clearIfNecessary()
/*     */   {
/* 322 */     if (this.positions.size() == 0) { return;
/*     */     }
/* 324 */     if ((System.nanoTime() - this.lastClearedTime > 300000000L) || (!((RefDataStore)this.positions.get(0)).pos.isValidPositionRE()) || (!((RefDataStore)this.positions.get(this.positions.size() - 1)).pos.isValidPositionRE()))
/*     */     {
/*     */ 
/*     */ 
/* 328 */       clearUnusedPositions();
/* 329 */       return;
/*     */     }
/*     */     
/* 332 */     if (this.positions.size() > 16) {
/* 333 */       int count = 0;
/*     */       
/* 335 */       switch (this.checkMethod)
/*     */       {
/*     */       case 0: 
/* 338 */         int en = Math.max(0, this.positions.size() - 8);
/*     */         
/* 340 */         for (int i = this.positions.size() - 1; i >= en; i--) {
/* 341 */           if (((RefDataStore)this.positions.get(i)).get() == null) {
/* 342 */             count++;
/* 343 */             this.positions.remove(i);
/*     */           }
/*     */         }
/* 346 */         break;
/*     */       case 1: 
/* 348 */         for (int i = 7; i >= 0; i--) {
/* 349 */           if (((RefDataStore)this.positions.get(i)).get() == null) {
/* 350 */             count++;
/* 351 */             this.positions.remove(i);
/*     */           }
/*     */         }
/*     */         
/* 355 */         break;
/*     */       case 2: 
/* 357 */         int a = this.positions.size() / 8;
/* 358 */         for (int i = this.positions.size() - 1; i >= 0; i -= a) {
/* 359 */           if (((RefDataStore)this.positions.get(i)).get() == null) {
/* 360 */             count++;
/* 361 */             this.positions.remove(i);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 366 */       if (count >= 3) {
/* 367 */         clearUnusedPositions();
/*     */       }
/*     */       
/* 370 */       this.checkMethod = ((this.checkMethod + 1) % 3);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public final void clearUnusedPositions()
/*     */   {
/* 377 */     for (int i = this.positions.size() - 1; i >= 0; i--) {
/* 378 */       if ((((RefDataStore)this.positions.get(i)).get() == null) || (!((RefDataStore)this.positions.get(i)).pos.isValidPositionRE())) {
/* 379 */         this.positions.remove(i);
/*     */       }
/*     */     }
/* 382 */     this.lastClearedTime = System.nanoTime();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private int getValidPosIndex(int idx, int min, int max)
/*     */   {
/* 389 */     while ((idx >= min) && (idx < this.positions.size()) && (idx <= max) && (((RefDataStore)this.positions.get(idx)).get() == null)) {
/* 390 */       this.positions.remove(idx);
/* 391 */       if ((idx >= this.positions.size()) || (idx > max)) {
/* 392 */         idx--;
/*     */       }
/*     */     }
/*     */     
/* 396 */     return idx;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int length()
/*     */   {
/* 405 */     return (int)Math.min(this.ti.length(), 2147473647L);
/*     */   }
/*     */   
/*     */   public int numberOfLines()
/*     */   {
/* 410 */     return this.datastore.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UndoableEdit insertString(int where, String str)
/*     */     throws BadLocationException
/*     */   {
/* 420 */     printLines();
/*     */     try {
/* 422 */       DataStorePosition start = this.ti.getTextPosition(where);
/*     */       
/* 424 */       String tmpStr = str;
/*     */       
/* 426 */       ArrayList<String> lines = new ArrayList();
/* 427 */       AbstractLine line1 = (AbstractLine)this.datastore.get(start.lineNumber);
/* 428 */       String s1 = line1.getFullLine();
/* 429 */       String s2 = "";
/*     */       
/*     */ 
/* 432 */       if (start.positionInLine == 0) {
/* 433 */         s2 = s1;
/* 434 */         s1 = "";
/* 435 */       } else if (start.positionInLine < s1.length()) {
/* 436 */         s2 = s1.substring(start.positionInLine);
/* 437 */         s1 = s1.substring(0, start.positionInLine);
/*     */       }
/*     */       int idx;
/* 440 */       while ((idx = tmpStr.indexOf('\n')) >= 0) {
/* 441 */         lines.add(tmpStr.substring(0, idx));
/* 442 */         tmpStr = tmpStr.substring(idx + 1);
/*     */       }
/* 444 */       lines.add(tmpStr);
/*     */       
/* 446 */       int updateFrom = where;
/* 447 */       if (updateFrom == 0) {
/* 448 */         updateFrom++;
/*     */       }
/*     */       
/* 451 */       this.notifyDocument = false;
/*     */       AbstractLine l;
/* 453 */       int shift; if (lines.size() == 1) {
/* 454 */         updatePositions(updateFrom, 0, start.lineNumber, line1, str.length());
/* 455 */         line1.setData(s1 + str + s2);
/*     */       }
/*     */       else
/*     */       {
/* 459 */         int key = findPosByKey(where, true);
/*     */         
/* 461 */         ArrayList<DataStorePosition> list = new ArrayList();
/*     */         
/* 463 */         for (int i = key; i < this.positions.size(); i++) {
/* 464 */           DataStorePosition p = ((RefDataStore)this.positions.get(i)).pos;
/* 465 */           if (p.lineNumber > start.lineNumber)
/*     */             break;
/* 467 */           if ((p.positionInLine >= start.positionInLine) && ((p.lineNumber > 0) || (p.positionInLine > 0)))
/*     */           {
/* 469 */             list.add(p);
/*     */           }
/*     */         }
/*     */         
/* 473 */         line1.setData(s1 + (String)lines.get(0));
/* 474 */         AbstractLine[] newLines = this.fileView.createLines(lines.size() - 1);
/* 475 */         for (int i = 1; i < lines.size() - 1; i++) {
/* 476 */           newLines[(i - 1)].setData((String)lines.get(i));
/*     */         }
/* 478 */         newLines[(newLines.length - 1)].setData((String)lines.get(lines.size() - 1) + s2);
/*     */         
/*     */ 
/* 481 */         idx = this.fileView.addLines(start.lineNumber + 1, -1, newLines);
/*     */         
/*     */ 
/* 484 */         if (idx >= 0) {
/* 485 */           l = this.fileView.getLine(idx);
/* 486 */           shift = ((String)lines.get(lines.size() - 1)).length() - start.positionInLine;
/* 487 */           for (DataStorePosition pp : list) {
/* 488 */             pp.line = l;
/* 489 */             pp.lineNumber = idx;
/* 490 */             pp.setLookupRequiredRE();
/* 491 */             pp.positionInLine += shift;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 496 */       printLines();
/*     */       
/* 498 */       this.fileView.fireTableRowsUpdated(start.lineNumber, start.lineNumber + lines.size());
/* 499 */       if ((str != null) || (!"".equals(str))) {
/* 500 */         this.fileView.setChanged(true);
/*     */       }
/*     */     } finally {
/* 503 */       this.notifyDocument = true;
/*     */     }
/* 505 */     printLines();
/* 506 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void printLines() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UndoableEdit remove(int where, int nitems)
/*     */     throws BadLocationException
/*     */   {
/* 527 */     DataStorePosition start = this.ti.getTextPosition(where);
/* 528 */     DataStorePosition fin = this.ti.getTextPosition(where + nitems);
/*     */     
/* 530 */     AbstractLine line1 = (AbstractLine)this.datastore.get(start.lineNumber);
/* 531 */     AbstractLine line2 = (AbstractLine)this.datastore.get(fin.lineNumber);
/* 532 */     String s1 = line1.getFullLine();
/* 533 */     String s2 = line2.getFullLine();
/*     */     
/*     */ 
/*     */ 
/*     */     int st;
/*     */     
/*     */ 
/*     */     int en;
/*     */     
/*     */ 
/* 543 */     if ((start.positionInLine == 0) && (fin.positionInLine < s2.length())) {
/* 544 */       int st = start.lineNumber;
/* 545 */       int en = fin.lineNumber - 1;
/*     */       
/*     */ 
/* 548 */       updateRemovedPositions(where, nitems, line2, 0, fin.lineNumber);
/* 549 */       updatePositions(where, nitems, fin.lineNumber, line2, -fin.positionInLine);
/*     */       
/* 551 */       line2.setData(s2.substring(fin.positionInLine));
/* 552 */       this.fileView.fireTableRowsUpdated(fin.lineNumber, fin.lineNumber);
/*     */     } else {
/* 554 */       if (fin.positionInLine >= s2.length()) {
/* 555 */         s2 = "";
/*     */       } else {
/* 557 */         s2 = s2.substring(fin.positionInLine);
/*     */       }
/*     */       
/* 560 */       st = start.lineNumber + 1;
/* 561 */       en = fin.lineNumber;
/*     */       
/*     */ 
/* 564 */       updateRemovedPositions(where, nitems, line1, start.positionInLine, start.lineNumber);
/* 565 */       updatePositions(where, nitems, start.lineNumber, line1, start.positionInLine - fin.positionInLine);
/*     */       
/* 567 */       line1.setData(s1.substring(0, start.positionInLine) + s2);
/* 568 */       this.fileView.fireTableRowsUpdated(st, st);
/*     */     }
/*     */     
/* 571 */     if (st <= en) {
/* 572 */       int[] recNums = new int[en - st + 1];
/* 573 */       for (int i = st; i <= en; i++) {
/* 574 */         recNums[(i - st)] = i;
/*     */       }
/* 576 */       this.fileView.deleteLines(recNums);
/*     */     }
/*     */     
/* 579 */     if (nitems > 0) {
/* 580 */       this.fileView.setChanged(true);
/*     */     }
/* 582 */     return null;
/*     */   }
/*     */   
/*     */   private void updateRemovedPositions(int where, int nitems, AbstractLine line, int newOffset, int lineNo)
/*     */   {
/* 587 */     int key = Math.min(findPosByKey(where + nitems, true), this.positions.size() - 1);
/*     */     
/*     */ 
/* 590 */     for (int i = key; i >= 0; i--)
/*     */     {
/* 592 */       if (((RefDataStore)this.positions.get(i)).get() == null) {
/* 593 */         this.positions.remove(i);
/*     */       } else {
/* 595 */         DataStorePosition p = ((RefDataStore)this.positions.get(i)).pos;
/* 596 */         if (p.getOffset() < where) {
/*     */           break;
/*     */         }
/*     */         
/*     */ 
/* 601 */         p.line = line;
/* 602 */         p.lineNumber = lineNo;
/* 603 */         p.positionInLine = newOffset;
/* 604 */         p.setLookupRequiredRE();
/*     */       }
/*     */     }
/* 607 */     this.fileView.fireTableRowsUpdated(lineNo, lineNo);
/*     */   }
/*     */   
/*     */   private void updatePositions(int where, int nitems, int lineNum, AbstractLine line, int shift) {
/* 611 */     int key = findPosByKey(where + nitems, true);
/*     */     
/* 613 */     DataStorePosition pos = this.ti.getTextPosition(where + nitems);
/*     */     
/* 615 */     for (int i = key; i < this.positions.size(); i++) {
/* 616 */       DataStorePosition p = ((RefDataStore)this.positions.get(i)).pos;
/* 617 */       if (p.lineNumber > pos.lineNumber)
/*     */         break;
/* 619 */       if (p.positionInLine >= pos.positionInLine)
/*     */       {
/*     */ 
/* 622 */         p.lineNumber = lineNum;
/* 623 */         p.line = line;
/* 624 */         p.positionInLine += shift;
/* 625 */         p.setLookupRequiredRE();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getString(int where, int len)
/*     */     throws BadLocationException
/*     */   {
/* 635 */     Segment s = new Segment();
/* 636 */     getChars(where, len, s);
/* 637 */     return new String(s.array, s.offset, s.count);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void getChars(int where, int len, Segment txt)
/*     */     throws BadLocationException
/*     */   {
/* 648 */     DataStorePosition start = this.ti.getTextPosition(where);
/* 649 */     DataStorePosition fin = this.ti.getTextPosition(where + len);
/*     */     
/* 651 */     AbstractLine line1 = (AbstractLine)this.datastore.get(start.lineNumber);
/* 652 */     String s1 = line1.getFullLine() + "\n";
/*     */     
/* 654 */     if (fin == null) {
/* 655 */       txt.array = new char[0];
/* 656 */       txt.count = 0;
/* 657 */       txt.offset = 0;
/* 658 */       txt.offset = 0;
/* 659 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 672 */     if (start.lineNumber == fin.lineNumber)
/*     */     {
/* 674 */       String s = s1.substring(start.positionInLine, Math.min(fin.positionInLine, s1.length()));
/*     */       
/*     */ 
/* 677 */       txt.array = s.toCharArray();
/* 678 */       txt.count = txt.array.length;
/* 679 */       txt.offset = 0;
/* 680 */       return;
/*     */     }
/*     */     
/* 683 */     AbstractLine line2 = (AbstractLine)this.datastore.get(fin.lineNumber);
/* 684 */     String s2 = line2.getFullLine() + '\n';
/* 685 */     if (start.positionInLine >= s1.length()) {
/* 686 */       s1 = "";
/* 687 */     } else if (start.positionInLine > 0) {
/* 688 */       s1 = s1.substring(start.positionInLine);
/*     */     }
/*     */     
/* 691 */     if (fin.positionInLine == 0) {
/* 692 */       s2 = "";
/* 693 */     } else if (fin.positionInLine < s2.length()) {
/* 694 */       s2 = s2.substring(0, fin.positionInLine);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 699 */     StringBuffer b = new StringBuffer(s1);
/*     */     
/* 701 */     for (int i = start.lineNumber + 1; i < fin.lineNumber; i++) {
/* 702 */       b.append(((AbstractLine)this.datastore.get(i)).getFullLine()).append('\n');
/*     */     }
/*     */     
/* 705 */     b.append(s2);
/*     */     
/* 707 */     txt.array = b.toString().toCharArray();
/* 708 */     txt.count = b.length();
/* 709 */     txt.offset = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void tableChanged(TableModelEvent event)
/*     */   {
/* 718 */     int type = 122;
/* 719 */     switch (event.getType())
/*     */     {
/*     */     case 1: 
/* 722 */       updateLinePos(event.getFirstRow() + 1, event.getLastRow() - event.getFirstRow() + 1);
/*     */       
/* 724 */       type = 121;
/* 725 */       break;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     case -1: 
/* 732 */       int en = updateLinePos(event.getLastRow() + 1, event.getFirstRow() - event.getLastRow() - 1);
/*     */       
/* 734 */       int newRow = event.getFirstRow();
/* 735 */       int posInLine = 0;
/* 736 */       AbstractLine l = null;
/*     */       
/* 738 */       type = 123;
/*     */       
/* 740 */       if (event.getLastRow() + 1 < this.datastore.size()) {
/* 741 */         l = (AbstractLine)this.datastore.get(event.getLastRow() + 1);
/* 742 */       } else if ((event.getFirstRow() - 1 >= 0) && (event.getFirstRow() - 1 < this.datastore.size())) {
/* 743 */         newRow--;
/* 744 */         l = (AbstractLine)this.datastore.get(newRow);
/* 745 */         posInLine = l.getFullLine().length();
/* 746 */       } else if (this.datastore.size() > 0) {
/* 747 */         newRow = this.datastore.size() - 1;
/* 748 */         l = (AbstractLine)this.datastore.get(newRow);
/* 749 */         posInLine = l.getFullLine().length();
/*     */       }
/*     */       
/*     */ 
/* 753 */       for (int i = Math.min(en, this.positions.size() - 1); i >= 0; i--) {
/* 754 */         DataStorePosition p = ((RefDataStore)this.positions.get(i)).pos;
/*     */         
/*     */ 
/* 757 */         if (p.lineNumber < event.getFirstRow()) break;
/* 758 */         if (p.lineNumber <= event.getLastRow()) {
/* 759 */           p.lineNumber = newRow;
/* 760 */           p.positionInLine = posInLine;
/* 761 */           p.setLookupRequiredRE();
/* 762 */           p.line = l;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 769 */       break;
/*     */     default: 
/* 771 */       updateLinePos(event.getFirstRow(), 0);
/*     */     }
/*     */     
/* 774 */     if ((this.documentUpdateListner != null) && (this.notifyDocument)) {
/* 775 */       this.documentUpdateListner.fireUpdate(type, event.getFirstRow(), Math.min(this.fileView.getRowCount() - 1, event.getLastRow()));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int updateLinePos(int firstLine, int amount)
/*     */   {
/* 784 */     for (int i = this.positions.size() - 1; i >= 0; i--) {
/* 785 */       DataStorePosition p = ((RefDataStore)this.positions.get(i)).pos;
/*     */       
/* 787 */       if (p.lineNumber < firstLine) {
/* 788 */         return i;
/*     */       }
/*     */       
/*     */ 
/* 792 */       p.lineNumber = Math.max(p.lineNumber + amount, 0);
/* 793 */       p.setLookupRequiredRE();
/*     */     }
/*     */     
/* 796 */     return -1;
/*     */   }
/*     */   
/*     */   public final boolean checkPositionSequence(String s)
/*     */   {
/* 801 */     int last = -1;
/* 802 */     DataStorePosition lastP = null;
/*     */     
/*     */ 
/* 805 */     for (int i = 0; i < this.positions.size(); i++) {
/* 806 */       DataStorePosition p = ((RefDataStore)this.positions.get(i)).pos;
/*     */       
/* 808 */       if (p.isValidPositionRE())
/*     */       {
/*     */ 
/* 811 */         if (last > p.lineNumber * 1000 + p.positionInLine) {
/* 812 */           System.out.println();
/* 813 */           System.out.println();
/* 814 */           System.out.println(" ------   Error at: " + i + "\t Line Number: " + p.lineNumber + " " + p.positionInLine + " ~ " + last + " > " + (p.lineNumber * 1000 + p.positionInLine));
/*     */           
/* 816 */           if (lastP != null) {
/* 817 */             System.out.println(" ------             \t Line Number: " + lastP.lineNumber + " " + lastP.positionInLine + " ~ " + last);
/*     */           }
/*     */           
/* 820 */           System.out.println(" ------ " + s);
/* 821 */           System.out.println();
/* 822 */           printPositions(64537);
/* 823 */           return false;
/*     */         }
/* 825 */         lastP = p;
/* 826 */         last = p.lineNumber * 1000 + p.positionInLine;
/*     */       }
/*     */     }
/* 829 */     return true;
/*     */   }
/*     */   
/*     */   public void printPositions(int offset) {
/* 833 */     if (this.positions.size() > 0) {
/* 834 */       int last = -1;
/* 835 */       boolean error = false;
/*     */       
/*     */ 
/* 838 */       System.out.println("***** Positions: " + offset);
/* 839 */       for (int i = 0; i < this.positions.size(); i++) {
/* 840 */         String s = " ";
/* 841 */         if (((RefDataStore)this.positions.get(i)).get() == null) {
/* 842 */           s = "^";
/*     */         }
/* 844 */         DataStorePosition p = ((RefDataStore)this.positions.get(i)).pos;
/* 845 */         System.out.print("\t" + p.lineNumber + '~' + p.positionInLine + s);
/* 846 */         if (last > p.lineNumber * 1000 + p.positionInLine) {
/* 847 */           System.out.print(" ");
/* 848 */           error = true;
/*     */         }
/* 850 */         last = p.lineNumber * 1000 + p.positionInLine;
/*     */       }
/* 852 */       System.out.println();
/* 853 */       if (error) {
/* 854 */         System.out.println(" ============== Error");
/* 855 */         System.out.println();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setDocumentUpdateListner(DocumentUpdateListner document)
/*     */   {
/* 864 */     this.documentUpdateListner = document;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public FileView getFileView()
/*     */   {
/* 871 */     return this.fileView;
/*     */   }
/*     */   
/*     */   private static class RefDataStore extends WeakReference<IDataStorePosition> {
/*     */     private final DataStorePosition pos;
/*     */     
/*     */     public RefDataStore(DataStorePosition referent) {
/* 878 */       this(new ZOld_DataStoreContent.DelegateDSPosition(referent));
/*     */     }
/*     */     
/*     */     public RefDataStore(ZOld_DataStoreContent.DelegateDSPosition referent) {
/* 882 */       super();
/* 883 */       this.pos = referent.pos;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class DelegateDSPosition implements IDataStorePosition {
/*     */     private final DataStorePosition pos;
/*     */     
/*     */     public DelegateDSPosition(DataStorePosition pos) {
/* 891 */       this.pos = pos;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getOffset()
/*     */     {
/* 899 */       return this.pos.getOffset();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public long getLineStartRE()
/*     */     {
/* 907 */       return this.pos.getLineStartRE();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getPositionInLineRE()
/*     */     {
/* 915 */       return this.pos.getPositionInLineRE();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getLineNumberRE()
/*     */     {
/* 923 */       return this.pos.getLineNumberRE();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public AbstractLine getLineRE()
/*     */     {
/* 931 */       return this.pos.getLineRE();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/ZOld_DataStoreContent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */