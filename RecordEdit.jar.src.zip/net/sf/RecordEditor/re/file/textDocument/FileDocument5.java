/*     */ package net.sf.RecordEditor.re.file.textDocument;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.io.PrintStream;
/*     */ import javax.swing.event.DocumentEvent.EventType;
/*     */ import javax.swing.text.AbstractDocument;
/*     */ import javax.swing.text.AbstractDocument.AttributeContext;
/*     */ import javax.swing.text.AbstractDocument.DefaultDocumentEvent;
/*     */ import javax.swing.text.AttributeSet;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import javax.swing.text.Document;
/*     */ import javax.swing.text.Element;
/*     */ import javax.swing.text.Position;
/*     */ import javax.swing.text.SimpleAttributeSet;
/*     */ import javax.swing.text.Style;
/*     */ import javax.swing.text.StyleConstants;
/*     */ import javax.swing.text.StyleContext;
/*     */ import javax.swing.text.StyledDocument;
/*     */ import net.sf.JRecord.Common.IFieldDetail;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail.FieldDetails;
/*     */ import net.sf.RecordEditor.re.file.DataStoreContent;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.fileStorage.IDataStorePosition;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileDocument5
/*     */   extends AbstractDocument
/*     */   implements StyledDocument, Element, IReDocument
/*     */ {
/*     */   public static final String tabSizeAttribute = "tabSize";
/*  71 */   private static StyleContext styleContext = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String mainStyleName = "MainStyle";
/*     */   
/*     */ 
/*     */ 
/*     */   private static final String colorStyle = "Style";
/*     */   
/*     */ 
/*     */ 
/*     */   private static Style mainStyle;
/*     */   
/*     */ 
/*     */ 
/*     */   private final DataStoreContent dsContent;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public FileDocument5(DataStoreContent dsc, boolean colorFields)
/*     */   {
/*  95 */     super(dsc);
/*  96 */     putProperty("tabSize", Integer.valueOf(8));
/*  97 */     this.dsContent = dsc;
/*  98 */     this.dsContent.setDocumentUpdateListner(this);
/*     */   }
/*     */   
/*     */ 
/*     */   public static AbstractDocument.AttributeContext getAttributeContext(boolean colorFields)
/*     */   {
/* 104 */     if (colorFields) {
/* 105 */       if (styleContext == null) {
/* 106 */         styleContext = new StyleContext();
/* 107 */         Style defaultStyle = styleContext.getStyle("default");
/*     */         
/*     */ 
/* 110 */         mainStyle = styleContext.addStyle("MainStyle", defaultStyle);
/*     */         
/*     */ 
/*     */ 
/* 114 */         StyleConstants.setFontFamily(mainStyle, "monospaced");
/* 115 */         StyleConstants.setFontSize(mainStyle, SwingUtils.STANDARD_FONT_HEIGHT);
/*     */         
/* 117 */         for (int j = 0; j < 4; j++) {
/* 118 */           Style cwStyle = styleContext.addStyle("Style" + j, null);
/* 119 */           StyleConstants.setFontFamily(cwStyle, "monospaced");
/* 120 */           StyleConstants.setForeground(cwStyle, colors[j]);
/* 121 */           if (j % 2 == 1) {
/* 122 */             StyleConstants.setBackground(cwStyle, Color.YELLOW);
/*     */           }
/*     */         }
/*     */       }
/* 126 */       return styleContext;
/*     */     }
/* 128 */     return StyleContext.getDefaultStyleContext();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Element getDefaultRootElement()
/*     */   {
/* 139 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Element getParagraphElement(int pos)
/*     */   {
/* 149 */     IDataStorePosition p = this.dsContent.getLinePositionByOffset(pos);
/* 150 */     if (p == null) {
/* 151 */       p = this.dsContent.getLinePositionByOffset(pos);
/*     */     }
/* 153 */     return new LineElement(this, p);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLength()
/*     */   {
/* 163 */     return this.dsContent.length();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Position createPosition(int offs)
/*     */     throws BadLocationException
/*     */   {
/* 190 */     if (this.dsContent != null) {
/* 191 */       return this.dsContent.createPosition(offs);
/*     */     }
/* 193 */     return super.createPosition(offs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Element[] getRootElements()
/*     */   {
/* 205 */     Element[] e = new Element[1];
/* 206 */     e[0] = getDefaultRootElement();
/* 207 */     return e;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final DataStoreContent getDataStoreContent()
/*     */   {
/* 237 */     return this.dsContent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Style addStyle(String nm, Style parent)
/*     */   {
/* 250 */     StyleContext styles = (StyleContext)getAttributeContext();
/* 251 */     return styles.addStyle(nm, parent);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeStyle(String nm)
/*     */   {
/* 259 */     StyleContext styles = (StyleContext)getAttributeContext();
/* 260 */     styles.removeStyle(nm);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Style getStyle(String nm)
/*     */   {
/* 268 */     StyleContext styles = (StyleContext)getAttributeContext();
/* 269 */     return styles.getStyle(nm);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCharacterAttributes(int offset, int length, AttributeSet s, boolean replace) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParagraphAttributes(int offset, int length, AttributeSet s, boolean replace) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLogicalStyle(int pos, Style s) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Style getLogicalStyle(int p)
/*     */   {
/* 307 */     return mainStyle;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Element getCharacterElement(int pos)
/*     */   {
/* 317 */     int ei1 = getElementIndex(pos);
/* 318 */     if (ei1 >= 0) {
/* 319 */       Element element = getElement(ei1);
/* 320 */       int ei2 = element.getElementIndex(pos);
/* 321 */       if (ei2 >= 0) {
/* 322 */         System.out.println(" ~~> Color Element " + pos + " / " + ei1 + " " + ei2);
/* 323 */         return element.getElement(ei2);
/*     */       }
/* 325 */       return element;
/*     */     }
/* 327 */     System.out.println(" ~~> Color Element " + pos + " / " + ei1 + "  not found ");
/* 328 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Color getForeground(AttributeSet attr)
/*     */   {
/* 336 */     StyleContext styles = (StyleContext)getAttributeContext();
/* 337 */     System.out.println(" ~~> getForeground " + styles.getForeground(attr));
/* 338 */     return styles.getForeground(attr);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Color getBackground(AttributeSet attr)
/*     */   {
/* 346 */     StyleContext styles = (StyleContext)getAttributeContext();
/* 347 */     return styles.getBackground(attr);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Font getFont(AttributeSet attr)
/*     */   {
/* 357 */     StyleContext styles = (StyleContext)getAttributeContext();
/* 358 */     return styles.getFont(attr);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Document getDocument()
/*     */   {
/* 371 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Element getParentElement()
/*     */   {
/* 379 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 387 */     return "section";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AttributeSet getAttributes()
/*     */   {
/* 395 */     return SimpleAttributeSet.EMPTY;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getStartOffset()
/*     */   {
/* 403 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getEndOffset()
/*     */   {
/* 411 */     return this.dsContent.length() + 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getElementIndex(int offset)
/*     */   {
/* 419 */     if (offset < 0)
/*     */     {
/* 421 */       return -1;
/*     */     }
/*     */     
/* 424 */     IDataStorePosition pos = this.dsContent.createTempPosition(offset);
/* 425 */     if (pos == null)
/*     */     {
/* 427 */       return this.dsContent.numberOfLines() - 1;
/*     */     }
/*     */     
/* 430 */     return pos.getLineNumberRE();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getElementCount()
/*     */   {
/* 444 */     return this.dsContent.numberOfLines();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Element getElement(int index)
/*     */   {
/* 455 */     return new LineElement(this, this.dsContent.getPositionByLineNumber(index));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isLeaf()
/*     */   {
/* 463 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void fireUpdate(int type, int firstLine, int lastLine)
/*     */   {
/* 472 */     IDataStorePosition lastPos = this.dsContent.getPositionByLineNumber(lastLine, false);
/* 473 */     int count; int where; int count; if ((firstLine < 0) || (lastLine < 0)) {
/* 474 */       int where = 0;
/* 475 */       count = this.dsContent.length();
/*     */     } else {
/* 477 */       IDataStorePosition startPos = this.dsContent.getPositionByLineNumber(firstLine, false);
/*     */       
/* 479 */       where = startPos.getOffset();
/* 480 */       count = lastPos.getOffset() + lastPos.getLineRE().getFullLine().length() - where + 2;
/*     */     }
/*     */     
/*     */ 
/* 484 */     switch (type) {
/* 485 */     case 121:  super.fireInsertUpdate(new AbstractDocument.DefaultDocumentEvent(this, where, count, DocumentEvent.EventType.INSERT)); break;
/* 486 */     case 123:  super.fireRemoveUpdate(new AbstractDocument.DefaultDocumentEvent(this, where, count, DocumentEvent.EventType.REMOVE)); break;
/*     */     
/*     */     case 122: 
/* 489 */       super.fireChangedUpdate(new AbstractDocument.DefaultDocumentEvent(this, where, Math.min(this.dsContent.length() - where, count + 20), DocumentEvent.EventType.CHANGE));
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */   private static class LineElement
/*     */     implements Element
/*     */   {
/*     */     protected FileDocument5 doc;
/*     */     
/*     */     protected IDataStorePosition pos;
/*     */     
/*     */     public LineElement(FileDocument5 doc, IDataStorePosition pos)
/*     */     {
/* 504 */       this.doc = doc;
/* 505 */       this.pos = pos;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Document getDocument()
/*     */     {
/* 513 */       return this.doc;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Element getParentElement()
/*     */     {
/* 521 */       return this.doc;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getName()
/*     */     {
/* 529 */       return "paragraph";
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public AttributeSet getAttributes()
/*     */     {
/* 537 */       return this.doc.getAttributes();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getStartOffset()
/*     */     {
/* 545 */       return (int)this.pos.getLineStartRE();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getEndOffset()
/*     */     {
/* 553 */       return (int)this.pos.getLineStartRE() + this.pos.getLineRE().getFullLine().length() + 1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getElementIndex(int offset)
/*     */     {
/* 561 */       return -1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getElementCount()
/*     */     {
/* 569 */       return 0;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Element getElement(int index)
/*     */     {
/* 577 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isLeaf()
/*     */     {
/* 585 */       return true;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class ColorLineElement extends FileDocument5.LineElement {
/*     */     private AbstractLayoutDetails schema;
/*     */     
/*     */     public ColorLineElement(FileDocument5 doc, IDataStorePosition pos) {
/* 593 */       super(pos);
/* 594 */       this.schema = doc.dsContent.getFileView().getLayout();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getElementIndex(int offset)
/*     */     {
/* 603 */       int schemaIndex = getSchemaIndex();
/* 604 */       if ((schemaIndex < 0) || (schemaIndex >= this.schema.getRecordCount())) {
/* 605 */         return 0;
/*     */       }
/*     */       
/* 608 */       AbstractRecordDetail rec = this.schema.getRecord(schemaIndex);
/*     */       
/*     */ 
/* 611 */       for (int i = 0; i < rec.getFieldCount(); i++) {
/* 612 */         AbstractRecordDetail.FieldDetails field = rec.getField(i);
/* 613 */         if ((offset >= field.getPos()) && (offset < field.getPos() + field.getLen())) {
/* 614 */           return i;
/*     */         }
/*     */       }
/* 617 */       return 0;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getElementCount()
/*     */     {
/* 625 */       int schemaIndex = getSchemaIndex();
/* 626 */       if ((schemaIndex < 0) || (schemaIndex >= this.schema.getRecordCount())) {
/* 627 */         return 0;
/*     */       }
/* 629 */       return this.schema.getRecord(schemaIndex).getFieldCount();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Element getElement(int index)
/*     */     {
/* 637 */       int schemaIndex = getSchemaIndex();
/* 638 */       if ((schemaIndex < 0) || (schemaIndex >= this.schema.getRecordCount()) || (index < 0) || (index >= this.schema.getRecord(schemaIndex).getFieldCount()))
/*     */       {
/* 640 */         return null;
/*     */       }
/* 642 */       return new FileDocument5.FieldElement(this, this.schema.getRecord(schemaIndex).getField(index), index);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isLeaf()
/*     */     {
/* 650 */       return getElementCount() > 0;
/*     */     }
/*     */     
/*     */     private int getSchemaIndex()
/*     */     {
/* 655 */       FileView v = this.doc.dsContent.getFileView();
/* 656 */       return v.getLine(this.pos.getLineNumberRE()).getPreferredLayoutIdx();
/*     */     }
/*     */   }
/*     */   
/* 660 */   private static Color[] colors = { Color.BLACK, Color.BLUE, Color.DARK_GRAY, Color.ORANGE };
/*     */   
/*     */ 
/*     */   private static class FieldElement
/*     */     implements Element
/*     */   {
/*     */     private SimpleAttributeSet attr;
/*     */     private final FileDocument5.ColorLineElement parent;
/*     */     private final IFieldDetail field;
/*     */     private final int index;
/*     */     
/*     */     public FieldElement(FileDocument5.ColorLineElement parent, IFieldDetail field, int idx)
/*     */     {
/* 673 */       this.parent = parent;
/* 674 */       this.field = field;
/* 675 */       this.index = idx;
/*     */       
/* 677 */       this.attr = new SimpleAttributeSet();
/*     */       
/* 679 */       this.attr.addAttribute(StyleConstants.Foreground, FileDocument5.colors[(this.index % FileDocument5.colors.length)]);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Document getDocument()
/*     */     {
/* 687 */       return this.parent.doc;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Element getParentElement()
/*     */     {
/* 695 */       return this.parent;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getName()
/*     */     {
/* 703 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public AttributeSet getAttributes()
/*     */     {
/* 711 */       return this.attr;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getStartOffset()
/*     */     {
/* 719 */       return this.field.getPos();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getEndOffset()
/*     */     {
/* 727 */       return this.field.getPos() + this.field.getLen();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getElementIndex(int offset)
/*     */     {
/* 735 */       return 0;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getElementCount()
/*     */     {
/* 743 */       return 0;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Element getElement(int index)
/*     */     {
/* 751 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isLeaf()
/*     */     {
/* 759 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/textDocument/FileDocument5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */