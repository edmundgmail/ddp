package net.sf.RecordEditor.re.file.textDocument;

import javax.swing.text.Document;
import net.sf.RecordEditor.re.file.DataStoreContent;
import net.sf.RecordEditor.re.file.DocumentUpdateListner;

public abstract interface IReDocument
  extends Document, DocumentUpdateListner
{
  public abstract DataStoreContent getDataStoreContent();
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/textDocument/IReDocument.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */