/*     */ package net.sf.RecordEditor.re.file.textDocument;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.io.PrintStream;
/*     */ import javax.swing.event.DocumentEvent.EventType;
/*     */ import javax.swing.text.AbstractDocument;
/*     */ import javax.swing.text.AbstractDocument.AttributeContext;
/*     */ import javax.swing.text.AbstractDocument.DefaultDocumentEvent;
/*     */ import javax.swing.text.AttributeSet;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import javax.swing.text.Document;
/*     */ import javax.swing.text.Element;
/*     */ import javax.swing.text.Position;
/*     */ import javax.swing.text.SimpleAttributeSet;
/*     */ import javax.swing.text.Style;
/*     */ import javax.swing.text.StyleConstants;
/*     */ import javax.swing.text.StyleContext;
/*     */ import javax.swing.text.StyledDocument;
/*     */ import net.sf.JRecord.Common.IFieldDetail;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail.FieldDetails;
/*     */ import net.sf.RecordEditor.re.file.DataStoreContent;
/*     */ import net.sf.RecordEditor.re.file.DocumentUpdateListner;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.fileStorage.IDataStorePosition;
/*     */ import net.sf.RecordEditor.utils.fileStorage.ITextInterface;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileDocument4
/*     */   extends AbstractDocument
/*     */   implements StyledDocument, Element, DocumentUpdateListner
/*     */ {
/*  67 */   private static int callcount = 0;
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String tabSizeAttribute = "tabSize";
/*     */   
/*     */ 
/*  74 */   private static StyleContext styleContext = null;
/*     */   
/*     */   private static final String mainStyleName = "MainStyle";
/*     */   private static final String colorStyle = "Style";
/*     */   private static Style mainStyle;
/*  79 */   private static Color[] colors = { Color.BLACK, Color.BLUE, Color.DARK_GRAY, Color.ORANGE };
/*  80 */   private static Style[] fieldStyles = new Style[colors.length];
/*     */   
/*     */   private final DataStoreContent dsContent;
/*     */   private final boolean colorFields;
/*  84 */   static SimpleAttributeSet[] stdAttr = { new SimpleAttributeSet(), new SimpleAttributeSet(), new SimpleAttributeSet(), new SimpleAttributeSet() };
/*     */   
/*  86 */   static { StyleConstants.setForeground(stdAttr[0], Color.GREEN);
/*  87 */     StyleConstants.setForeground(stdAttr[1], Color.BLUE);
/*  88 */     StyleConstants.setForeground(stdAttr[2], Color.RED);
/*  89 */     StyleConstants.setForeground(stdAttr[3], Color.BLACK);
/*  90 */     StyleConstants.setFontFamily(stdAttr[0], "Courier New");
/*  91 */     StyleConstants.setFontFamily(stdAttr[1], "Courier New");
/*  92 */     StyleConstants.setFontFamily(stdAttr[2], "Courier New");
/*  93 */     StyleConstants.setFontFamily(stdAttr[3], "Courier New");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FileDocument4(FileView f, ITextInterface c)
/*     */   {
/* 102 */     this(new DataStoreContent(f, c), false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FileDocument4(DataStoreContent dsc, boolean colorFields)
/*     */   {
/* 112 */     super(dsc, getAttributeContext(colorFields));
/* 113 */     putProperty("tabSize", Integer.valueOf(8));
/* 114 */     this.dsContent = dsc;
/* 115 */     this.dsContent.setDocumentUpdateListner(this);
/* 116 */     this.colorFields = colorFields;
/*     */   }
/*     */   
/*     */   public static AbstractDocument.AttributeContext getAttributeContext(boolean colorFields)
/*     */   {
/* 121 */     if (colorFields) {
/* 122 */       if (styleContext == null) {
/* 123 */         styleContext = new StyleContext();
/* 124 */         Style defaultStyle = styleContext.getStyle("default");
/*     */         
/*     */ 
/* 127 */         mainStyle = styleContext.addStyle("MainStyle", defaultStyle);
/*     */         
/*     */ 
/*     */ 
/* 131 */         StyleConstants.setFontFamily(mainStyle, "monospaced");
/* 132 */         StyleConstants.setFontSize(mainStyle, SwingUtils.STANDARD_FONT_HEIGHT);
/*     */         
/* 134 */         for (int j = 0; j < 4; j++) {
/* 135 */           Style cwStyle = styleContext.addStyle("Style" + j, null);
/* 136 */           StyleConstants.setFontFamily(cwStyle, "monospaced");
/* 137 */           StyleConstants.setForeground(cwStyle, colors[j]);
/* 138 */           if (j % 2 == 1) {
/* 139 */             StyleConstants.setBackground(cwStyle, Color.YELLOW);
/*     */           }
/*     */           
/* 142 */           fieldStyles[j] = cwStyle;
/*     */         }
/*     */       }
/* 145 */       return styleContext;
/*     */     }
/* 147 */     return StyleContext.getDefaultStyleContext();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Element getDefaultRootElement()
/*     */   {
/* 157 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Element getParagraphElement(int pos)
/*     */   {
/* 167 */     IDataStorePosition p = this.dsContent.createTempPosition(pos);
/* 168 */     return getElement(p.getLineNumberRE());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLength()
/*     */   {
/* 185 */     return this.dsContent.length();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Position createPosition(int offs)
/*     */     throws BadLocationException
/*     */   {
/* 212 */     if (this.dsContent != null) {
/* 213 */       return this.dsContent.createPosition(offs);
/*     */     }
/* 215 */     return super.createPosition(offs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Element[] getRootElements()
/*     */   {
/* 227 */     Element[] e = new Element[1];
/* 228 */     e[0] = getDefaultRootElement();
/* 229 */     return e;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Style addStyle(String nm, Style parent)
/*     */   {
/* 247 */     StyleContext styles = (StyleContext)getAttributeContext();
/* 248 */     return styles.addStyle(nm, parent);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeStyle(String nm)
/*     */   {
/* 256 */     StyleContext styles = (StyleContext)getAttributeContext();
/* 257 */     styles.removeStyle(nm);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Style getStyle(String nm)
/*     */   {
/* 265 */     StyleContext styles = (StyleContext)getAttributeContext();
/* 266 */     return styles.getStyle(nm);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Style getLogicalStyle(int p)
/*     */   {
/* 314 */     return mainStyle;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Element getCharacterElement(int pos)
/*     */   {
/* 322 */     int ei1 = getElementIndex(pos);
/* 323 */     if (ei1 >= 0) {
/* 324 */       int ei2 = getElement(ei1).getElementIndex(pos);
/* 325 */       if (ei2 >= 0) {
/* 326 */         System.out.println(" ~~> Color Element " + pos + " / " + ei1 + " " + ei2);
/* 327 */         return getElement(ei1).getElement(ei2);
/*     */       }
/*     */     }
/* 330 */     System.out.println(" ~~> Color Element " + pos + " / " + ei1 + "  not found ");
/* 331 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Color getForeground(AttributeSet attr)
/*     */   {
/* 339 */     StyleContext styles = (StyleContext)getAttributeContext();
/* 340 */     System.out.println(" ~~> getForeground " + styles.getForeground(attr));
/* 341 */     return styles.getForeground(attr);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Color getBackground(AttributeSet attr)
/*     */   {
/* 349 */     StyleContext styles = (StyleContext)getAttributeContext();
/* 350 */     return styles.getBackground(attr);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Font getFont(AttributeSet attr)
/*     */   {
/* 360 */     StyleContext styles = (StyleContext)getAttributeContext();
/* 361 */     return styles.getFont(attr);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Document getDocument()
/*     */   {
/* 375 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Element getParentElement()
/*     */   {
/* 383 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 391 */     return "section";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AttributeSet getAttributes()
/*     */   {
/* 399 */     return SimpleAttributeSet.EMPTY;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getStartOffset()
/*     */   {
/* 407 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getEndOffset()
/*     */   {
/* 415 */     return this.dsContent.length() + 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getElementIndex(int offset)
/*     */   {
/* 423 */     if (offset < 0)
/*     */     {
/* 425 */       return -1;
/*     */     }
/*     */     
/* 428 */     IDataStorePosition pos = this.dsContent.createTempPosition(offset);
/* 429 */     if (pos == null)
/*     */     {
/* 431 */       return this.dsContent.numberOfLines() - 1;
/*     */     }
/*     */     
/* 434 */     return pos.getLineNumberRE();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getElementCount()
/*     */   {
/* 448 */     return this.dsContent.numberOfLines();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Element getElement(int index)
/*     */   {
/* 456 */     IDataStorePosition linePosition = this.dsContent.getPositionByLineNumber(index);
/* 457 */     if (linePosition == null) {
/* 458 */       System.out.println("Error Getting LineNo: " + index + " " + this.dsContent.numberOfLines());
/* 459 */       return null;
/*     */     }
/* 461 */     if (this.colorFields) {
/* 462 */       return new ColorLineElement(this, linePosition);
/*     */     }
/* 464 */     System.out.println(" ~  + lineElement");
/* 465 */     return new LineElement(this, linePosition);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isLeaf()
/*     */   {
/* 473 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void fireUpdate(int type, int firstLine, int lastLine)
/*     */   {
/* 482 */     IDataStorePosition lastPos = this.dsContent.getPositionByLineNumber(lastLine, false);
/* 483 */     int count; int where; int count; if ((firstLine < 0) || (lastLine < 0)) {
/* 484 */       int where = 0;
/* 485 */       count = this.dsContent.length();
/*     */     } else {
/* 487 */       IDataStorePosition startPos = this.dsContent.getPositionByLineNumber(firstLine, false);
/*     */       
/* 489 */       where = startPos.getOffset();
/* 490 */       count = lastPos.getOffset() + lastPos.getLineRE().getFullLine().length() - where + 2;
/*     */     }
/*     */     
/*     */ 
/* 494 */     switch (type) {
/* 495 */     case 121:  super.fireInsertUpdate(new AbstractDocument.DefaultDocumentEvent(this, where, count, DocumentEvent.EventType.INSERT)); break;
/* 496 */     case 123:  super.fireRemoveUpdate(new AbstractDocument.DefaultDocumentEvent(this, where, count, DocumentEvent.EventType.REMOVE)); break;
/*     */     
/*     */     case 122: 
/* 499 */       super.fireChangedUpdate(new AbstractDocument.DefaultDocumentEvent(this, where, Math.min(this.dsContent.length() - where, count + 20), DocumentEvent.EventType.CHANGE));
/*     */     }
/*     */   }
/*     */   
/*     */   public void setCharacterAttributes(int offset, int length, AttributeSet s, boolean replace) {}
/*     */   
/*     */   public void setParagraphAttributes(int offset, int length, AttributeSet s, boolean replace) {}
/*     */   
/*     */   public void setLogicalStyle(int pos, Style s) {}
/*     */   
/*     */   private static abstract class LeafElement
/*     */     implements Element
/*     */   {
/*     */     public AttributeSet getAttributes()
/*     */     {
/* 514 */       return SimpleAttributeSet.EMPTY;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getElementIndex(int offset)
/*     */     {
/* 523 */       return -1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getElementCount()
/*     */     {
/* 531 */       return 0;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Element getElement(int index)
/*     */     {
/* 539 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isLeaf()
/*     */     {
/* 547 */       return true;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class LineElement extends FileDocument4.LeafElement
/*     */   {
/*     */     protected FileDocument4 doc;
/*     */     protected IDataStorePosition pos;
/*     */     
/*     */     public LineElement(FileDocument4 doc, IDataStorePosition pos) {
/* 557 */       super();
/* 558 */       this.doc = doc;
/* 559 */       this.pos = pos;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Document getDocument()
/*     */     {
/* 567 */       return this.doc;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Element getParentElement()
/*     */     {
/* 575 */       return this.doc;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getName()
/*     */     {
/* 583 */       return "paragraph";
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public AttributeSet getAttributes()
/*     */     {
/* 591 */       return SimpleAttributeSet.EMPTY;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getStartOffset()
/*     */     {
/* 599 */       return (int)this.pos.getLineStartRE();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getEndOffset()
/*     */     {
/* 607 */       return (int)this.pos.getLineStartRE() + this.pos.getLineRE().getFullLine().length() + 1;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class ColorLineElement
/*     */     extends FileDocument4.LineElement
/*     */   {
/*     */     private AbstractLayoutDetails schema;
/*     */     SimpleAttributeSet attr;
/*     */     
/*     */     public ColorLineElement(FileDocument4 doc, IDataStorePosition pos)
/*     */     {
/* 619 */       super(pos);
/* 620 */       this.schema = doc.dsContent.getFileView().getLayout();
/*     */       
/* 622 */       this.attr = new SimpleAttributeSet();
/*     */       
/* 624 */       this.attr.addAttributes(FileDocument4.mainStyle);
/* 625 */       if (pos.getLineNumberRE() % 2 == 1) {
/* 626 */         StyleConstants.setBackground(this.attr, Color.YELLOW);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getElementIndex(int offset)
/*     */     {
/* 636 */       int schemaIndex = getSchemaIndex();
/* 637 */       if ((schemaIndex < 0) || (schemaIndex >= this.schema.getRecordCount())) {
/* 638 */         return 0;
/*     */       }
/*     */       
/* 641 */       AbstractRecordDetail rec = this.schema.getRecord(schemaIndex);
/*     */       
/* 643 */       int fieldCount = rec.getFieldCount();
/*     */       
/* 645 */       for (int i = 0; i < fieldCount; i++) {
/* 646 */         AbstractRecordDetail.FieldDetails field = rec.getField(i);
/* 647 */         if ((offset >= field.getPos()) && (offset < field.getPos() + field.getLen())) {
/* 648 */           return i;
/*     */         }
/*     */       }
/* 651 */       return fieldCount;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public AttributeSet getAttributes()
/*     */     {
/* 661 */       return this.attr;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getElementCount()
/*     */     {
/* 670 */       int schemaIndex = getSchemaIndex();
/* 671 */       if ((schemaIndex < 0) || (schemaIndex >= this.schema.getRecordCount())) {
/* 672 */         return 0;
/*     */       }
/* 674 */       return this.schema.getRecord(schemaIndex).getFieldCount() + 1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Element getElement(int index)
/*     */     {
/* 682 */       int schemaIndex = getSchemaIndex();
/* 683 */       if ((schemaIndex < 0) || (schemaIndex >= this.schema.getRecordCount()) || (index < 0))
/*     */       {
/*     */ 
/* 686 */         return null; }
/* 687 */       if (index >= this.schema.getRecord(schemaIndex).getFieldCount()) {
/* 688 */         AbstractRecordDetail.FieldDetails field = this.schema.getRecord(schemaIndex).getField(this.schema.getRecord(schemaIndex).getFieldCount() - 1);
/* 689 */         int st = getStartOffset() + field.getPos() + field.getLen() - 1;
/*     */         
/* 691 */         return new FileDocument4.LineEndElement(this, st, getEndOffset());
/*     */       }
/*     */       
/* 694 */       return new FileDocument4.FieldElement(this, this.schema.getRecord(schemaIndex).getField(index), index);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isLeaf()
/*     */     {
/* 702 */       return false;
/*     */     }
/*     */     
/*     */     private int getSchemaIndex()
/*     */     {
/* 707 */       FileView v = this.doc.dsContent.getFileView();
/* 708 */       return v.getLine(this.pos.getLineNumberRE()).getPreferredLayoutIdx();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class FieldElement
/*     */     extends FileDocument4.LeafElement
/*     */   {
/*     */     private SimpleAttributeSet attr;
/*     */     
/*     */     private final FileDocument4.ColorLineElement parent;
/*     */     private final IFieldDetail field;
/*     */     private final int index;
/*     */     
/*     */     public FieldElement(FileDocument4.ColorLineElement parent, IFieldDetail field, int idx)
/*     */     {
/* 724 */       super();
/* 725 */       this.parent = parent;
/* 726 */       this.field = field;
/* 727 */       this.index = idx;
/*     */       
/* 729 */       this.attr = new SimpleAttributeSet();
/*     */       
/*     */ 
/*     */ 
/* 733 */       this.attr.addAttributes(FileDocument4.stdAttr[(idx % FileDocument4.stdAttr.length)]);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Document getDocument()
/*     */     {
/* 742 */       return this.parent.doc;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Element getParentElement()
/*     */     {
/* 751 */       return this.parent;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getName()
/*     */     {
/* 760 */       return "content";
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public AttributeSet getAttributes()
/*     */     {
/* 774 */       return this.attr;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getStartOffset()
/*     */     {
/* 787 */       return this.parent.getStartOffset() + this.field.getPos() - 1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getEndOffset()
/*     */     {
/* 796 */       return getStartOffset() + this.field.getLen();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private static class LineEndElement
/*     */     extends FileDocument4.LeafElement
/*     */   {
/*     */     private final FileDocument4.ColorLineElement parent;
/*     */     private final int where;
/*     */     private final int end;
/*     */     
/*     */     public LineEndElement(FileDocument4.ColorLineElement parent, int where, int end)
/*     */     {
/* 810 */       super();
/* 811 */       this.parent = parent;
/* 812 */       this.where = where;
/* 813 */       this.end = end;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Document getDocument()
/*     */     {
/* 821 */       return this.parent.doc;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Element getParentElement()
/*     */     {
/* 829 */       return this.parent;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getName()
/*     */     {
/* 837 */       return "content";
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getStartOffset()
/*     */     {
/* 846 */       return this.where;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getEndOffset()
/*     */     {
/* 854 */       return this.end;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/textDocument/FileDocument4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */