/*     */ package net.sf.RecordEditor.re.file.textDocument;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import javax.swing.event.DocumentEvent.EventType;
/*     */ import javax.swing.text.AbstractDocument;
/*     */ import javax.swing.text.AbstractDocument.DefaultDocumentEvent;
/*     */ import javax.swing.text.AttributeSet;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import javax.swing.text.Document;
/*     */ import javax.swing.text.Element;
/*     */ import javax.swing.text.Position;
/*     */ import javax.swing.text.SimpleAttributeSet;
/*     */ import javax.swing.text.StyleConstants;
/*     */ import net.sf.JRecord.Common.IFieldDetail;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail.FieldDetails;
/*     */ import net.sf.RecordEditor.re.file.DataStoreContent;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.fileStorage.IDataStorePosition;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FileDocument3
/*     */   extends AbstractDocument
/*     */   implements IReDocument, Element
/*     */ {
/*     */   public static final String tabSizeAttribute = "tabSize";
/*     */   private final DataStoreContent dsContent;
/*     */   
/*     */   public FileDocument3(DataStoreContent dsc, boolean colorFields)
/*     */   {
/*  87 */     super(dsc);
/*  88 */     putProperty("tabSize", Integer.valueOf(8));
/*  89 */     this.dsContent = dsc;
/*  90 */     this.dsContent.setDocumentUpdateListner(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Element getDefaultRootElement()
/*     */   {
/* 102 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Element getParagraphElement(int pos)
/*     */   {
/* 112 */     IDataStorePosition p = this.dsContent.getLinePositionByOffset(pos);
/* 113 */     return new LineElement(this, p);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLength()
/*     */   {
/* 123 */     return this.dsContent.length();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Position createPosition(int offs)
/*     */     throws BadLocationException
/*     */   {
/* 150 */     if (this.dsContent != null) {
/* 151 */       return this.dsContent.createPosition(offs);
/*     */     }
/* 153 */     return super.createPosition(offs);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Element[] getRootElements()
/*     */   {
/* 165 */     Element[] e = new Element[1];
/* 166 */     e[0] = getDefaultRootElement();
/* 167 */     return e;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final DataStoreContent getDataStoreContent()
/*     */   {
/* 197 */     return this.dsContent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Document getDocument()
/*     */   {
/* 210 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Element getParentElement()
/*     */   {
/* 218 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName()
/*     */   {
/* 226 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AttributeSet getAttributes()
/*     */   {
/* 234 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getStartOffset()
/*     */   {
/* 242 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getEndOffset()
/*     */   {
/* 250 */     return this.dsContent.length() + 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getElementIndex(int offset)
/*     */   {
/* 258 */     if (offset < 0)
/*     */     {
/* 260 */       return -1;
/*     */     }
/*     */     
/* 263 */     IDataStorePosition pos = this.dsContent.createTempPosition(offset);
/* 264 */     if (pos == null)
/*     */     {
/* 266 */       return this.dsContent.numberOfLines() - 1;
/*     */     }
/*     */     
/* 269 */     return pos.getLineNumberRE();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getElementCount()
/*     */   {
/* 283 */     return this.dsContent.numberOfLines();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Element getElement(int index)
/*     */   {
/* 294 */     return new LineElement(this, this.dsContent.getPositionByLineNumber(index));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isLeaf()
/*     */   {
/* 302 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void fireUpdate(int type, int firstLine, int lastLine)
/*     */   {
/* 311 */     IDataStorePosition lastPos = this.dsContent.getPositionByLineNumber(lastLine, false);
/* 312 */     int count; int where; int count; if ((firstLine < 0) || (lastLine < 0)) {
/* 313 */       int where = 0;
/* 314 */       count = this.dsContent.length();
/*     */     } else {
/* 316 */       IDataStorePosition startPos = this.dsContent.getPositionByLineNumber(firstLine, false);
/*     */       
/* 318 */       where = startPos.getOffset();
/* 319 */       count = lastPos.getOffset() + lastPos.getLineRE().getFullLine().length() - where + 2;
/*     */     }
/*     */     
/*     */ 
/* 323 */     switch (type) {
/* 324 */     case 121:  super.fireInsertUpdate(new AbstractDocument.DefaultDocumentEvent(this, where, count, DocumentEvent.EventType.INSERT)); break;
/* 325 */     case 123:  super.fireRemoveUpdate(new AbstractDocument.DefaultDocumentEvent(this, where, count, DocumentEvent.EventType.REMOVE)); break;
/*     */     
/*     */     case 122: 
/* 328 */       super.fireChangedUpdate(new AbstractDocument.DefaultDocumentEvent(this, where, Math.min(this.dsContent.length() - where, count + 20), DocumentEvent.EventType.CHANGE));
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */   private static class LineElement
/*     */     implements Element
/*     */   {
/*     */     protected FileDocument3 doc;
/*     */     
/*     */     protected IDataStorePosition pos;
/*     */     
/*     */     public LineElement(FileDocument3 doc, IDataStorePosition pos)
/*     */     {
/* 343 */       this.doc = doc;
/* 344 */       this.pos = pos;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Document getDocument()
/*     */     {
/* 352 */       return this.doc;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Element getParentElement()
/*     */     {
/* 360 */       return this.doc;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getName()
/*     */     {
/* 368 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public AttributeSet getAttributes()
/*     */     {
/* 376 */       return this.doc.getAttributes();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getStartOffset()
/*     */     {
/* 384 */       return (int)this.pos.getLineStartRE();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getEndOffset()
/*     */     {
/* 392 */       return (int)this.pos.getLineStartRE() + this.pos.getLineRE().getFullLine().length() + 1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getElementIndex(int offset)
/*     */     {
/* 400 */       return -1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getElementCount()
/*     */     {
/* 408 */       return 0;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Element getElement(int index)
/*     */     {
/* 416 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isLeaf()
/*     */     {
/* 424 */       return true;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class ColorLineElement extends FileDocument3.LineElement {
/*     */     private AbstractLayoutDetails schema;
/*     */     
/*     */     public ColorLineElement(FileDocument3 doc, IDataStorePosition pos) {
/* 432 */       super(pos);
/* 433 */       this.schema = doc.dsContent.getFileView().getLayout();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getElementIndex(int offset)
/*     */     {
/* 442 */       int schemaIndex = getSchemaIndex();
/* 443 */       if ((schemaIndex < 0) || (schemaIndex >= this.schema.getRecordCount())) {
/* 444 */         return 0;
/*     */       }
/*     */       
/* 447 */       AbstractRecordDetail rec = this.schema.getRecord(schemaIndex);
/*     */       
/*     */ 
/* 450 */       for (int i = 0; i < rec.getFieldCount(); i++) {
/* 451 */         AbstractRecordDetail.FieldDetails field = rec.getField(i);
/* 452 */         if ((offset >= field.getPos()) && (offset < field.getPos() + field.getLen())) {
/* 453 */           return i;
/*     */         }
/*     */       }
/* 456 */       return 0;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getElementCount()
/*     */     {
/* 464 */       int schemaIndex = getSchemaIndex();
/* 465 */       if ((schemaIndex < 0) || (schemaIndex >= this.schema.getRecordCount())) {
/* 466 */         return 0;
/*     */       }
/* 468 */       return this.schema.getRecord(schemaIndex).getFieldCount();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Element getElement(int index)
/*     */     {
/* 476 */       int schemaIndex = getSchemaIndex();
/* 477 */       if ((schemaIndex < 0) || (schemaIndex >= this.schema.getRecordCount()) || (index < 0) || (index >= this.schema.getRecord(schemaIndex).getFieldCount()))
/*     */       {
/* 479 */         return null;
/*     */       }
/* 481 */       return new FileDocument3.FieldElement(this, this.schema.getRecord(schemaIndex).getField(index), index);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isLeaf()
/*     */     {
/* 489 */       return getElementCount() > 0;
/*     */     }
/*     */     
/*     */     private int getSchemaIndex()
/*     */     {
/* 494 */       FileView v = this.doc.dsContent.getFileView();
/* 495 */       return v.getLine(this.pos.getLineNumberRE()).getPreferredLayoutIdx();
/*     */     }
/*     */   }
/*     */   
/* 499 */   private static Color[] colors = { Color.BLACK, Color.BLUE, Color.DARK_GRAY, Color.ORANGE };
/*     */   
/*     */ 
/*     */   private static class FieldElement
/*     */     implements Element
/*     */   {
/*     */     private SimpleAttributeSet attr;
/*     */     private final FileDocument3.ColorLineElement parent;
/*     */     private final IFieldDetail field;
/*     */     private final int index;
/*     */     
/*     */     public FieldElement(FileDocument3.ColorLineElement parent, IFieldDetail field, int idx)
/*     */     {
/* 512 */       this.parent = parent;
/* 513 */       this.field = field;
/* 514 */       this.index = idx;
/*     */       
/* 516 */       this.attr = new SimpleAttributeSet();
/*     */       
/* 518 */       this.attr.addAttribute(StyleConstants.Foreground, FileDocument3.colors[(this.index % FileDocument3.colors.length)]);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Document getDocument()
/*     */     {
/* 526 */       return this.parent.doc;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Element getParentElement()
/*     */     {
/* 534 */       return this.parent;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getName()
/*     */     {
/* 542 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public AttributeSet getAttributes()
/*     */     {
/* 550 */       return this.attr;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getStartOffset()
/*     */     {
/* 558 */       return this.field.getPos();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getEndOffset()
/*     */     {
/* 566 */       return this.field.getPos() + this.field.getLen();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getElementIndex(int offset)
/*     */     {
/* 574 */       return 0;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getElementCount()
/*     */     {
/* 582 */       return 0;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Element getElement(int index)
/*     */     {
/* 590 */       return null;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isLeaf()
/*     */     {
/* 598 */       return true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/textDocument/FileDocument3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */