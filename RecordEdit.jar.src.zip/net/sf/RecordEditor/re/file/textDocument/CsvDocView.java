/*     */ package net.sf.RecordEditor.re.file.textDocument;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import javax.swing.text.Document;
/*     */ import javax.swing.text.Element;
/*     */ import javax.swing.text.PlainView;
/*     */ import javax.swing.text.Segment;
/*     */ import javax.swing.text.Utilities;
/*     */ import net.sf.JRecord.Common.AbstractFieldValue;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.RecordEditor.re.file.DataStoreContent;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.fileStorage.IDataStorePosition;
/*     */ import net.sf.RecordEditor.utils.swing.color.ColorGroupManager;
/*     */ import net.sf.RecordEditor.utils.swing.color.IColorGroup;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CsvDocView
/*     */   extends PlainView
/*     */ {
/*  27 */   private IColorGroup colorGrp = ColorGroupManager.getInstance().get(0);
/*  28 */   private IColorGroup spclColorGrp = ColorGroupManager.getInstance().get(1);
/*  29 */   private IReDocument doc = null;
/*     */   
/*     */   private DataStoreContent dsContent;
/*     */   private AbstractLayoutDetails schema;
/*     */   private String quote;
/*     */   
/*     */   public CsvDocView(Element elem)
/*     */   {
/*  37 */     super(elem);
/*     */   }
/*     */   
/*     */   private void setDocument()
/*     */   {
/*     */     Document document;
/*  43 */     if ((this.doc == null) && (((document = getDocument()) instanceof FileDocument5)))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  49 */       this.doc = ((IReDocument)document);
/*  50 */       this.dsContent = this.doc.getDataStoreContent();
/*  51 */       this.schema = this.dsContent.getFileView().getLayout();
/*  52 */       this.quote = this.schema.getQuote();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int drawUnselectedText(Graphics g, int x, int y, int p0, int p1)
/*     */     throws BadLocationException
/*     */   {
/*  63 */     setDocument();
/*  64 */     if (this.doc == null) { return x;
/*     */     }
/*  66 */     Segment segment = getLineBuffer();
/*  67 */     IDataStorePosition pos = this.dsContent.createTempPosition(p0);
/*     */     
/*     */     AbstractLine line;
/*  70 */     if ((pos == null) || ((line = pos.getLineRE()) == null)) {
/*  71 */       return x;
/*     */     }
/*     */     AbstractLine line;
/*  74 */     int t1 = p0;
/*     */     
/*  76 */     int idx = 0;
/*  77 */     int recId = 0;
/*  78 */     int soFar = 0;
/*  79 */     long lineStart = pos.getLineStartRE();
/*  80 */     AbstractLayoutDetails layout = pos.getLineRE().getLayout();
/*     */     
/*  82 */     int sepLength = layout.getDelimiter().length();
/*     */     
/*  84 */     this.doc.getText(p0, p1 - p0, segment);
/*  85 */     int initialOffset = segment.offset;
/*  86 */     int initialCount = segment.count;
/*     */     
/*     */ 
/*  89 */     if (layout.getRecordCount() > 1) {
/*  90 */       recId = line.getPreferredLayoutIdx();
/*     */     }
/*     */     
/*  93 */     int[] lengths = new int[layout.getRecord(recId).getFieldCount()];
/*     */     
/*  95 */     if ((this.quote == null) || ("".equals(this.quote))) {
/*  96 */       for (int i = 0; i < lengths.length; i++) {
/*  97 */         lengths[i] = line.getFieldValue(recId, i).asString().length();
/*     */       }
/*     */     } else {
/* 100 */       String delimiter = this.schema.getDelimiter();
/* 101 */       String chk = this.quote + delimiter;
/* 102 */       String tl = line.getFullLine();
/* 103 */       boolean quoteLen1 = this.quote.length() == 1;
/*     */       
/* 105 */       int st = 0;
/*     */       
/* 107 */       for (int i = 0; i < lengths.length; i++) {
/* 108 */         String tf = line.getFieldValue(recId, i).asString();
/* 109 */         int fl = tf.length();
/* 110 */         if ((st + fl < tl.length()) && (tl.charAt(st) == this.quote.charAt(0)) && ((quoteLen1) || (tl.substring(st).startsWith(this.quote))))
/*     */         {
/* 112 */           int search = tl.indexOf(chk, st + fl);
/* 113 */           if (search >= st) {
/* 114 */             fl = search - st + this.quote.length();
/*     */           } else {
/* 116 */             fl = tl.length() - st;
/*     */           }
/*     */         }
/* 119 */         fl = Math.min(fl, tl.length() - st);
/* 120 */         lengths[i] = fl;
/* 121 */         st = Math.min(tl.length(), st + fl + delimiter.length());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 126 */     while ((idx < lengths.length) && (p0 - lineStart >= soFar + lengths[idx])) {
/* 127 */       soFar += lengths[idx] + sepLength;
/* 128 */       idx++;
/*     */     }
/*     */     
/* 131 */     soFar = 0;
/* 132 */     while ((idx < lengths.length) && (p1 - lineStart > t1 - p0))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 141 */       int colorIdx = idx % this.colorGrp.size();
/*     */       
/* 143 */       segment.offset = (initialOffset + t1 - p0);
/* 144 */       segment.count = Math.min(p1 - t1, lengths[idx]);
/* 145 */       x = writeText(g, x, y, t1, segment, this.colorGrp.getForegroundColor(colorIdx), this.colorGrp.getBackgroundColor(colorIdx));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 156 */       t1 += segment.count;
/* 157 */       idx++;
/*     */       
/*     */ 
/* 160 */       if (soFar < initialCount)
/*     */       {
/*     */ 
/*     */ 
/* 164 */         segment.offset = (initialOffset + t1 - p0);
/* 165 */         segment.count = Math.min(p1 - t1, sepLength);
/*     */         
/* 167 */         x = writeText(g, x, y, t1, segment, this.spclColorGrp.getForegroundColor(0), this.spclColorGrp.getBackgroundColor(0));
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 172 */         t1 += sepLength;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 177 */     if (t1 < p1) {
/* 178 */       g.setColor(Color.RED);
/* 179 */       segment.offset = (initialOffset + t1 - p0);
/* 180 */       segment.count = (p1 - t1);
/*     */       
/* 182 */       x = Utilities.drawTabbedText(segment, x, y, g, this, t1);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 204 */     return x;
/*     */   }
/*     */   
/*     */   private int writeText(Graphics g, int x, int y, int t1, Segment segment, Color foreground, Color backgroundColor)
/*     */   {
/* 209 */     if (backgroundColor != null) {
/* 210 */       g.setColor(backgroundColor);
/* 211 */       FontMetrics fontMetrics = g.getFontMetrics();
/* 212 */       int fontHeight = fontMetrics.getHeight();
/*     */       
/* 214 */       int tabbedTextWidth = Utilities.getTabbedTextWidth(segment, fontMetrics, x, this, t1);
/* 215 */       g.fillRect(x, y - y % fontHeight, tabbedTextWidth, fontHeight);
/*     */     }
/*     */     
/*     */ 
/* 219 */     if (foreground == null) {
/* 220 */       g.setColor(Color.BLACK);
/*     */     } else {
/* 222 */       g.setColor(foreground);
/*     */     }
/* 224 */     x = Utilities.drawTabbedText(segment, x, y, g, this, t1);
/* 225 */     return x;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/textDocument/CsvDocView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */