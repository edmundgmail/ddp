/*    */ package net.sf.RecordEditor.re.file.textDocument;
/*    */ 
/*    */ import javax.swing.text.Element;
/*    */ import javax.swing.text.StyledEditorKit;
/*    */ import javax.swing.text.View;
/*    */ import javax.swing.text.ViewFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CsvEditorKit
/*    */   extends StyledEditorKit
/*    */ {
/*    */   public static final String TEXT_CSV = "text/csv";
/* 15 */   private ViewFactory viewFactory = new ViewFactory() {
/*    */     public View create(Element elem) {
/* 17 */       return new CsvDocView(elem);
/*    */     }
/*    */   };
/*    */   
/*    */   public ViewFactory getViewFactory()
/*    */   {
/* 23 */     return this.viewFactory;
/*    */   }
/*    */   
/*    */   public String getContentType()
/*    */   {
/* 28 */     return "text/csv";
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/textDocument/CsvEditorKit.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */