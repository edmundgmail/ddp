/*     */ package net.sf.RecordEditor.re.file.textDocument;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.io.PrintStream;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import javax.swing.text.Document;
/*     */ import javax.swing.text.Element;
/*     */ import javax.swing.text.PlainView;
/*     */ import javax.swing.text.Segment;
/*     */ import javax.swing.text.Utilities;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail.FieldDetails;
/*     */ import net.sf.RecordEditor.re.file.DataStoreContent;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.fileStorage.IDataStorePosition;
/*     */ import net.sf.RecordEditor.utils.swing.color.ColorGroupManager;
/*     */ import net.sf.RecordEditor.utils.swing.color.IColorGroup;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FixedDocView
/*     */   extends PlainView
/*     */ {
/*  29 */   IColorGroup colorGrp = ColorGroupManager.getInstance().get(0);
/*  30 */   private IReDocument doc = null;
/*     */   private DataStoreContent dsContent;
/*     */   private int[][] start;
/*     */   private int[][] len;
/*     */   
/*     */   public FixedDocView(Element elem) {
/*  36 */     super(elem);
/*     */   }
/*     */   
/*     */   private void setDocument()
/*     */   {
/*     */     Document document;
/*  42 */     if ((this.doc == null) && (((document = getDocument()) instanceof FileDocument5))) {
/*  43 */       this.doc = ((IReDocument)document);
/*  44 */       this.dsContent = this.doc.getDataStoreContent();
/*     */       
/*  46 */       AbstractLayoutDetails layout = this.dsContent.getFileView().getLayout();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*  51 */       this.start = new int[layout.getRecordCount()][];
/*  52 */       this.len = new int[this.start.length][];
/*     */       
/*  54 */       for (int i = 0; i < this.start.length; i++) {
/*  55 */         AbstractRecordDetail record = layout.getRecord(i);
/*  56 */         int fieldCount = record.getFieldCount();
/*  57 */         this.start[i] = new int[fieldCount];
/*  58 */         this.len[i] = new int[fieldCount];
/*  59 */         for (int j = 0; j < fieldCount; j++) {
/*  60 */           AbstractRecordDetail.FieldDetails field = record.getField(j);
/*  61 */           this.start[i][j] = (field.getPos() - 1);
/*  62 */           this.len[i][j] = field.getLen();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int drawUnselectedText(Graphics g, int x, int y, int p0, int p1)
/*     */     throws BadLocationException
/*     */   {
/*  75 */     setDocument();
/*  76 */     if (this.doc == null) { return x;
/*     */     }
/*  78 */     Segment segment = getLineBuffer();
/*  79 */     IDataStorePosition pos = this.dsContent.createTempPosition(p0);
/*     */     
/*     */     AbstractLine line;
/*  82 */     if ((pos == null) || ((line = pos.getLineRE()) == null)) {
/*  83 */       return x;
/*     */     }
/*     */     AbstractLine line;
/*  86 */     int t1 = p0;
/*     */     
/*  88 */     int idx = 0;
/*  89 */     int recId = 0;
/*  90 */     long lineStart = pos.getLineStartRE();
/*     */     
/*     */ 
/*  93 */     this.doc.getText(p0, p1 - p0, segment);
/*     */     
/*  95 */     int initialOffset = segment.offset;
/*     */     
/*     */ 
/*  98 */     if (this.start.length > 1) {
/*  99 */       recId = line.getPreferredLayoutIdx();
/*     */     }
/*     */     
/*     */ 
/* 103 */     while ((idx < this.start[recId].length) && (p0 - lineStart >= this.start[recId][idx] + this.len[recId][idx])) {
/* 104 */       idx++;
/*     */     }
/*     */     
/* 107 */     System.out.println();
/* 108 */     System.out.println("Screen: ");
/* 109 */     while ((idx < this.start[recId].length) && (p1 - lineStart > this.start[recId][idx])) {
/* 110 */       if (t1 < this.start[recId][idx]) {
/* 111 */         g.setColor(Color.BLACK);
/* 112 */         segment.offset = (initialOffset + t1 - p0);
/* 113 */         segment.count = (this.start[recId][idx] - t1);
/*     */         
/* 115 */         x = Utilities.drawTabbedText(segment, x, y, g, this, t1);
/* 116 */         System.out.print("##... ");
/* 117 */         t1 = this.start[recId][idx];
/*     */       }
/*     */       
/* 120 */       System.out.print("\t" + idx);
/* 121 */       int colorIdx = idx % this.colorGrp.size();
/* 122 */       Color backgroundColor = this.colorGrp.getBackgroundColor(colorIdx);
/*     */       
/* 124 */       segment.offset = (initialOffset + t1 - p0);
/* 125 */       segment.count = Math.min(p1 - t1, this.len[recId][idx]);
/*     */       
/* 127 */       x = writeText(g, x, y, t1, segment, this.colorGrp.getForegroundColor(colorIdx), backgroundColor);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 148 */       t1 += segment.count;
/* 149 */       idx++;
/*     */     }
/*     */     
/* 152 */     segment.offset = (initialOffset + t1 - p0);
/* 153 */     if ((t1 < p1) && ((p1 - t1 > 1) || (segment.charAt(0) != '\n')))
/*     */     {
/* 155 */       segment.count = (p1 - t1);
/* 156 */       g.setColor(Color.RED);
/* 157 */       System.out.println("##--- " + t1 + " " + p1 + (segment.charAt(0) == '\n') + " " + (segment.charAt(0) == '\r'));
/* 158 */       x = Utilities.drawTabbedText(segment, x, y, g, this, t1);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 179 */     return x;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private int writeText(Graphics g, int x, int y, int t1, Segment segment, Color foreground, Color backgroundColor)
/*     */   {
/* 186 */     if (backgroundColor != null) {
/* 187 */       g.setColor(backgroundColor);
/* 188 */       FontMetrics fontMetrics = g.getFontMetrics();
/* 189 */       int fontHeight = fontMetrics.getHeight();
/*     */       
/* 191 */       int tabbedTextWidth = Utilities.getTabbedTextWidth(segment, fontMetrics, x, this, t1);
/* 192 */       g.fillRect(x, y - y % fontHeight, tabbedTextWidth, fontHeight);
/*     */     }
/*     */     
/*     */ 
/* 196 */     if (foreground == null) {
/* 197 */       g.setColor(Color.BLACK);
/*     */     } else {
/* 199 */       g.setColor(foreground);
/*     */     }
/* 201 */     x = Utilities.drawTabbedText(segment, x, y, g, this, t1);
/* 202 */     return x;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/textDocument/FixedDocView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */