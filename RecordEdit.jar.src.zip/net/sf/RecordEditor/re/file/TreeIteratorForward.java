/*    */ package net.sf.RecordEditor.re.file;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.sf.JRecord.Details.AbstractLine;
/*    */ import net.sf.RecordEditor.utils.ExpandLineTree;
/*    */ import net.sf.RecordEditor.utils.fileStorage.IDataStoreIterator;
/*    */ 
/*    */ public class TreeIteratorForward
/*    */   implements IDataStoreIterator
/*    */ {
/*    */   private List<? extends AbstractLine> list;
/* 13 */   private ArrayList<AbstractLine> expandedLine = null;
/* 14 */   private int currentLine = 0;
/* 15 */   private int currentChild = 0;
/*    */   
/*    */   private AbstractLine last;
/*    */   
/*    */ 
/*    */   public TreeIteratorForward(List<? extends AbstractLine> lines, AbstractLine firstLine)
/*    */   {
/* 22 */     this.list = lines;
/*    */     
/* 24 */     if ((lines != null) && (lines.size() != 0))
/*    */     {
/* 26 */       if (firstLine == null) {
/* 27 */         this.expandedLine = ExpandLineTree.expandTree((AbstractLine)this.list.get(this.currentLine));
/*    */       } else {
/* 29 */         this.expandedLine = ExpandLineTree.expandFrom(firstLine);
/* 30 */         this.currentLine = this.list.indexOf(ExpandLineTree.getRootLine(firstLine));
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean hasNext()
/*    */   {
/* 39 */     return (this.expandedLine != null) && (this.list != null) && ((this.currentLine < this.list.size() - 1) || (this.currentChild < this.expandedLine.size()));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public AbstractLine nextTempRE()
/*    */   {
/* 47 */     return next();
/*    */   }
/*    */   
/*    */   public AbstractLine currentLineRE()
/*    */   {
/* 52 */     return this.last;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public AbstractLine next()
/*    */   {
/* 60 */     if (this.currentChild >= this.expandedLine.size()) {
/* 61 */       this.expandedLine = ExpandLineTree.expandTree((AbstractLine)this.list.get(++this.currentLine));
/* 62 */       this.currentChild = 0;
/*    */     }
/* 64 */     this.last = ((AbstractLine)this.expandedLine.get(this.currentChild++));
/* 65 */     return this.last;
/*    */   }
/*    */   
/*    */   public void remove() {}
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/TreeIteratorForward.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */