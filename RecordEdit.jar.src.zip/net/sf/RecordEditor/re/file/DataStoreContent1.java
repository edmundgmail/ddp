/*     */ package net.sf.RecordEditor.re.file;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.event.TableModelEvent;
/*     */ import javax.swing.event.TableModelListener;
/*     */ import javax.swing.text.AbstractDocument.Content;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import javax.swing.text.Segment;
/*     */ import javax.swing.undo.UndoableEdit;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.RecordEditor.utils.fileStorage.DataStorePosition;
/*     */ import net.sf.RecordEditor.utils.fileStorage.IDataStore;
/*     */ import net.sf.RecordEditor.utils.fileStorage.IDataStorePosition;
/*     */ import net.sf.RecordEditor.utils.fileStorage.ITextInterface;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DataStoreContent1
/*     */   implements AbstractDocument.Content, TableModelListener
/*     */ {
/*     */   private final FileView file;
/*     */   private final IDataStore<? extends AbstractLine> datastore;
/*     */   private final ITextInterface ti;
/*  26 */   private final ArrayList<WeakReference<DataStorePosition>> positions = new ArrayList(50);
/*     */   
/*     */ 
/*     */ 
/*     */   public DataStoreContent1(FileView file, ITextInterface ti)
/*     */   {
/*  32 */     this.datastore = ti.getDataStore();
/*  33 */     this.ti = ti;
/*  34 */     this.file = file;
/*  35 */     file.addTableModelListener(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public IDataStorePosition createPosition(int offset)
/*     */     throws BadLocationException
/*     */   {
/*  43 */     DataStorePosition pos = findPosition(offset, true);
/*  44 */     if (pos != null) {
/*  45 */       return pos;
/*     */     }
/*  47 */     return register(this.ti.getTextPosition(offset));
/*     */   }
/*     */   
/*     */   private DataStorePosition register(DataStorePosition pos) {
/*  51 */     WeakReference<DataStorePosition> r = new WeakReference(pos);
/*     */     
/*  53 */     int firstKey = getValidPosIndex(0, 0, this.positions.size() - 1);
/*  54 */     int lastKey = getValidPosIndex(this.positions.size() - 1, 0, this.positions.size() - 1);
/*  55 */     int offset = pos.getOffset();
/*  56 */     IDataStorePosition p; if ((this.positions.size() == 0) || (((p = (IDataStorePosition)((WeakReference)this.positions.get(lastKey)).get()) != null) && (p.getOffset() < offset))) {
/*  57 */       System.out.print(" 6)");
/*  58 */       this.positions.add(r); } else { IDataStorePosition p;
/*  59 */       if (((p = (IDataStorePosition)((WeakReference)this.positions.get(firstKey)).get()) != null) && (p.getOffset() > offset)) {
/*  60 */         System.out.print(" 7)");
/*  61 */         this.positions.add(0, r);
/*  62 */       } else if (this.positions.size() < 6) {
/*  63 */         boolean toAdd = true;
/*     */         
/*  65 */         System.out.print("linear search ... " + this.positions.size());
/*     */         
/*  67 */         for (int i = 1; i < this.positions.size(); i++) {
/*  68 */           p = (IDataStorePosition)((WeakReference)this.positions.get(i)).get();
/*  69 */           if ((p != null) && (p.getOffset() >= offset)) {
/*  70 */             pos = addPosition(i, r);
/*  71 */             toAdd = false;
/*  72 */             System.out.print("." + i + '^');
/*  73 */             break;
/*     */           }
/*     */         }
/*     */         
/*  77 */         if (toAdd) {
/*  78 */           System.out.print(" 5)");
/*  79 */           this.positions.add(r);
/*     */         }
/*     */       } else {
/*  82 */         if (pos.lineNumber == 0) {
/*  83 */           System.out.print(" ");
/*     */         }
/*  85 */         int key = findPosByKey(offset, true);
/*  86 */         if (key < 0) {
/*  87 */           linearSearch(r, offset);
/*  88 */         } else if (key >= this.positions.size()) {
/*  89 */           System.out.println(" --- At end ");
/*  90 */           int idx = getValidPosIndex(this.positions.size() - 1, 0, this.positions.size() - 1);
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  98 */           pos = addPosition(idx, r);
/*     */         } else {
/* 100 */           pos = addPosition(key, r);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 107 */     if ((this.positions.size() > 30) && (this.positions.size() % 30 == 0))
/*     */     {
/* 109 */       System.out.println("     ------ Printing Positions ------");
/* 110 */       System.out.println();
/*     */       
/* 112 */       for (int i = 0; i < this.positions.size(); i++) {
/* 113 */         DataStorePosition pp = (DataStorePosition)((WeakReference)this.positions.get(i)).get();
/* 114 */         if (pp != null) {
/* 115 */           System.out.println("\t" + pp.lineNumber + "\t" + pp.getLineStartRE() + "\t" + pp.positionInLine + "\t" + pp.getOffset());
/*     */         }
/*     */       }
/* 118 */       System.out.println();
/*     */     } else {
/* 120 */       int last = -1;
/* 121 */       System.out.println("***** Positions: " + offset);
/* 122 */       for (int i = 0; i < this.positions.size(); i++) {
/* 123 */         IDataStorePosition p = (IDataStorePosition)((WeakReference)this.positions.get(i)).get();
/* 124 */         if (p != null) {
/* 125 */           System.out.print("\t" + p.getOffset());
/* 126 */           if (last == p.getOffset()) {
/* 127 */             System.out.print(" ");
/*     */           }
/* 129 */           last = p.getOffset();
/*     */         }
/*     */       }
/* 132 */       System.out.println();
/*     */     }
/* 134 */     return pos;
/*     */   }
/*     */   
/*     */   private IDataStorePosition linearSearch(WeakReference<DataStorePosition> r, int offset) {
/* 138 */     IDataStorePosition pos = (IDataStorePosition)r.get();
/* 139 */     System.out.println(" --- error insert ");
/* 140 */     int idx = getValidPosIndex(0, 0, this.positions.size() - 1);
/*     */     
/* 142 */     while ((idx < this.positions.size()) && (((DataStorePosition)((WeakReference)this.positions.get(idx)).get()).getOffset() < offset)) {
/* 143 */       idx = getValidPosIndex(idx++, idx, this.positions.size() - 1);
/*     */     }
/*     */     
/* 146 */     pos = addPosition(idx, r);
/*     */     
/* 148 */     return pos;
/*     */   }
/*     */   
/*     */   private DataStorePosition addPosition(int idx, WeakReference<DataStorePosition> r) {
/* 152 */     int where = ((DataStorePosition)r.get()).getOffset();
/*     */     
/* 154 */     if (idx >= this.positions.size()) {
/* 155 */       System.out.print(" 1)");
/* 156 */       this.positions.add(r); } else { DataStorePosition p;
/* 157 */       if (((p = (DataStorePosition)((WeakReference)this.positions.get(idx)).get()) != null) && (p.getOffset() == where)) {
/* 158 */         System.out.print(" 2)");
/* 159 */         return p;
/*     */       }
/* 161 */       System.out.print(" 3)");
/*     */       
/* 163 */       this.positions.add(idx, r);
/*     */     }
/* 165 */     return (DataStorePosition)r.get();
/*     */   }
/*     */   
/*     */   public IDataStorePosition createTempPosition(int offset) throws BadLocationException {
/* 169 */     IDataStorePosition pos = findPosition(offset, true);
/* 170 */     if (pos != null) {
/* 171 */       return pos;
/*     */     }
/* 173 */     return this.ti.getTextPosition(offset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IDataStorePosition getLinePosition(int lineNo)
/*     */   {
/* 182 */     IDataStorePosition pos = findPosition(lineNo, false);
/* 183 */     if (pos != null) {
/* 184 */       return pos;
/*     */     }
/* 186 */     return register(this.ti.getPositionByLineNumber(lineNo));
/*     */   }
/*     */   
/*     */   private DataStorePosition findPosition(int searchValue, boolean offset)
/*     */   {
/* 191 */     DataStorePosition ret = null;
/* 192 */     int key = findPosByKey(searchValue, offset);
/* 193 */     DataStorePosition chk; if ((key >= 0) && (key < this.positions.size()) && ((chk = getStorePositionByIndex(key)) != null) && (
/* 194 */       ((offset) && (chk.getOffset() == searchValue)) || ((!offset) && (chk.lineNumber == searchValue) && (chk.positionInLine == 0))))
/*     */     {
/* 196 */       if (chk.line == this.datastore.get(chk.lineNumber)) {
/*     */         try {
/* 198 */           chk.updatePositionRE();
/* 199 */           ret = chk;
/*     */         } catch (Exception e) {
/* 201 */           this.positions.remove(key);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 207 */     return ret;
/*     */   }
/*     */   
/*     */   private int findPosByKey(int searchValue, boolean offset)
/*     */   {
/* 212 */     synchronized (this.positions)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 217 */       clearIfNecessary();
/* 218 */       int low = getValidPosIndex(0, 0, this.positions.size() - 1);
/*     */       
/*     */ 
/* 221 */       if (this.positions.size() == 0) { return 0;
/*     */       }
/* 223 */       int high = this.positions.size();
/*     */       
/* 225 */       while (high > low) {
/* 226 */         high = getValidPosIndex(high, low, this.positions.size() - 1);
/* 227 */         int mid = getValidPosIndex((high + low) / 2, low, high);
/*     */         
/* 229 */         if (mid >= this.positions.size() - 1) {
/* 230 */           return low;
/*     */         }
/* 232 */         DataStorePosition p = (DataStorePosition)((WeakReference)this.positions.get(mid)).get();
/* 233 */         if ((mid < low) || (p == null)) {
/* 234 */           return Math.max(0, mid);
/*     */         }
/*     */         
/* 237 */         int v = calcCompare(searchValue, offset, p);
/*     */         
/* 239 */         if (high - 1 <= low) {
/* 240 */           System.out.print("**" + v + " ");
/* 241 */           if (v < 0) {
/* 242 */             low++;
/*     */           }
/*     */         }
/* 245 */         else if (v < 0) {
/* 246 */           low = mid;
/* 247 */         } else if (v > 0) {
/* 248 */           high = mid;
/*     */         } else {
/* 250 */           return mid;
/*     */         }
/*     */       }
/*     */       
/* 254 */       if (low + 1 == this.positions.size()) {
/* 255 */         System.out.print("..");
/* 256 */         DataStorePosition p = (DataStorePosition)((WeakReference)this.positions.get(low)).get();
/* 257 */         if ((p != null) && (calcCompare(searchValue, offset, p) > 0)) {
/* 258 */           low++;
/*     */         }
/*     */       }
/* 261 */       return low;
/*     */     }
/*     */   }
/*     */   
/*     */   private int calcCompare(int searchValue, boolean offset, DataStorePosition p) { int v;
/*     */     int v;
/* 267 */     if (offset) {
/* 268 */       v = Integer.compare(p.getOffset(), searchValue);
/*     */     } else {
/* 270 */       v = Integer.compare(p.lineNumber, searchValue);
/* 271 */       if ((v == 0) && (p.positionInLine > 0)) {
/* 272 */         v = 1;
/*     */       }
/*     */     }
/*     */     
/* 276 */     return v;
/*     */   }
/*     */   
/*     */   private void clearIfNecessary()
/*     */   {
/* 281 */     int en = Math.max(0, this.positions.size() - 8);
/* 282 */     int count = 0;
/*     */     
/* 284 */     for (int i = this.positions.size() - 1; i >= en; i--) {
/* 285 */       if (getStorePositionByIndex(i) == null) {
/* 286 */         count++;
/*     */       }
/*     */     }
/*     */     
/* 290 */     if (count >= 3) {
/* 291 */       for (int i = Math.min(en, this.positions.size() - 1); i >= 0; i--) {
/* 292 */         getStorePositionByIndex(i);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private DataStorePosition getValidPosition(int idx)
/*     */   {
/* 301 */     DataStorePosition ret = null;
/* 302 */     getValidPosIndex(idx, idx, this.positions.size() - 1);
/*     */     
/* 304 */     if (idx < this.positions.size()) {
/* 305 */       ret = (DataStorePosition)((WeakReference)this.positions.get(idx)).get();
/*     */     }
/*     */     
/* 308 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private int getValidPosIndex(int idx, int min, int max)
/*     */   {
/* 315 */     while ((idx >= min) && (idx < this.positions.size()) && (idx <= max) && (((WeakReference)this.positions.get(idx)).get() == null)) {
/* 316 */       this.positions.remove(idx);
/* 317 */       if ((idx >= this.positions.size()) || (idx > max)) {
/* 318 */         idx--;
/*     */       }
/*     */     }
/*     */     
/* 322 */     return idx;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int length()
/*     */   {
/* 331 */     return (int)this.ti.length();
/*     */   }
/*     */   
/*     */   public int numberOfLines()
/*     */   {
/* 336 */     return this.datastore.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public UndoableEdit insertString(int where, String str)
/*     */     throws BadLocationException
/*     */   {
/* 345 */     DataStorePosition start = this.ti.getTextPosition(where);
/* 346 */     String[] lines = str.split("\n");
/* 347 */     AbstractLine line1 = (AbstractLine)this.datastore.get(start.lineNumber);
/* 348 */     String s1 = line1.getFullLine();
/* 349 */     String s2 = "";
/* 350 */     if (start.positionInLine == 0) {
/* 351 */       s2 = s1;
/* 352 */       s1 = "";
/* 353 */     } else if (start.positionInLine < s1.length()) {
/* 354 */       s2 = s1.substring(start.positionInLine);
/* 355 */       s1 = s1.substring(0, start.positionInLine); }
/*     */     int idx;
/*     */     AbstractLine l;
/* 358 */     int shift; if (lines.length == 1) {
/* 359 */       line1.setData(s1 + str + s2);
/* 360 */       updatePositions(where, 0, str.length());
/*     */     }
/*     */     else
/*     */     {
/* 364 */       int key = findPosByKey(where, true);
/*     */       
/* 366 */       ArrayList<DataStorePosition> list = new ArrayList();
/*     */       
/* 368 */       for (int i = key; i < this.positions.size(); i++) {
/* 369 */         DataStorePosition p = getValidPosition(i);
/* 370 */         if (p != null)
/*     */         {
/* 372 */           if (p.lineNumber > start.lineNumber)
/*     */             break;
/* 374 */           if (p.positionInLine >= start.positionInLine) {
/* 375 */             list.add(p);
/*     */           }
/*     */         }
/*     */       }
/* 379 */       line1.setData(s1 + lines[0]);
/* 380 */       for (int i = 1; i < lines.length - 1; i++) {
/* 381 */         addLine(start.lineNumber + i - 1, lines[i]);
/*     */       }
/* 383 */       idx = addLine(start.lineNumber + lines.length - 1, lines[(lines.length - 1)] + s2);
/*     */       
/* 385 */       if (idx >= 0) {
/* 386 */         l = this.file.getLine(idx);
/* 387 */         shift = lines[(lines.length - 1)].length() - start.positionInLine;
/* 388 */         for (DataStorePosition pp : list) {
/* 389 */           pp.line = l;
/* 390 */           pp.lineNumber = idx;
/* 391 */           pp.setLookupRequiredRE();
/* 392 */           pp.positionInLine += shift;
/*     */         }
/*     */       }
/*     */     }
/* 396 */     return null;
/*     */   }
/*     */   
/*     */   private int addLine(int pos, String data)
/*     */   {
/* 401 */     int idx = this.file.newLine(pos, 1);
/* 402 */     if (idx >= 0) {
/* 403 */       this.file.getLine(idx).setData(data);
/*     */     }
/*     */     
/* 406 */     return idx;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UndoableEdit remove(int where, int nitems)
/*     */     throws BadLocationException
/*     */   {
/* 416 */     DataStorePosition start = this.ti.getTextPosition(where);
/* 417 */     DataStorePosition fin = this.ti.getTextPosition(where + nitems);
/*     */     
/* 419 */     AbstractLine line1 = (AbstractLine)this.datastore.get(start.lineNumber);
/* 420 */     AbstractLine line2 = (AbstractLine)this.datastore.get(fin.lineNumber);
/* 421 */     String s1 = line1.getFullLine();
/* 422 */     String s2 = line2.getFullLine();
/*     */     
/*     */ 
/*     */ 
/*     */     int st;
/*     */     
/*     */ 
/*     */     int en;
/*     */     
/*     */ 
/* 432 */     if ((start.positionInLine == 0) && (fin.positionInLine < s2.length())) {
/* 433 */       int st = start.lineNumber;
/* 434 */       int en = fin.lineNumber - 1;
/* 435 */       line2.setData(s2.substring(fin.positionInLine));
/*     */       
/* 437 */       updatePositions(where, nitems, -fin.positionInLine);
/* 438 */       updateRemovedPositions(where, nitems, line2, 0, fin.lineNumber);
/*     */     } else {
/* 440 */       if (fin.positionInLine >= s2.length()) {
/* 441 */         s2 = "";
/*     */       } else {
/* 443 */         s2 = s2.substring(fin.positionInLine);
/*     */       }
/*     */       
/* 446 */       st = start.lineNumber + 1;
/* 447 */       en = fin.lineNumber;
/* 448 */       line1.setData(s1.substring(0, start.positionInLine) + s2);
/*     */       
/* 450 */       updatePositions(where, nitems, start.positionInLine - fin.positionInLine);
/* 451 */       updateRemovedPositions(where, nitems, line1, start.positionInLine, start.lineNumber);
/*     */     }
/*     */     
/* 454 */     if (st <= en) {
/* 455 */       int[] recNums = new int[en - st + 1];
/* 456 */       for (int i = st; i <= en; i++) {
/* 457 */         recNums[(i - st)] = i;
/*     */       }
/* 459 */       this.file.deleteLines(recNums);
/*     */     }
/*     */     
/* 462 */     return null;
/*     */   }
/*     */   
/*     */   private void updateRemovedPositions(int where, int nitems, AbstractLine line, int newOffset, int lineNo)
/*     */   {
/* 467 */     int key = findPosByKey(where + nitems, true);
/*     */     
/*     */ 
/* 470 */     for (int i = key; i >= 0; i--) {
/* 471 */       DataStorePosition p = getStorePositionByIndex(i);
/* 472 */       if (p != null) {
/* 473 */         if (p.getOffset() < where) {
/*     */           break;
/*     */         }
/* 476 */         p.line = line;
/* 477 */         p.lineNumber = lineNo;
/* 478 */         p.positionInLine = newOffset;
/* 479 */         p.setLookupRequiredRE();
/*     */       }
/*     */     }
/* 482 */     this.file.fireTableRowsUpdated(lineNo, lineNo);
/*     */   }
/*     */   
/*     */   private void updatePositions(int where, int nitems, int shift) {
/* 486 */     int key = findPosByKey(where + nitems, true);
/*     */     
/* 488 */     DataStorePosition pos = this.ti.getTextPosition(where + nitems);
/*     */     
/* 490 */     for (int i = key; i < this.positions.size(); i++) {
/* 491 */       DataStorePosition p = getValidPosition(i);
/* 492 */       if (p != null)
/*     */       {
/* 494 */         if (p.lineNumber > pos.lineNumber)
/*     */           break;
/* 496 */         if (p.positionInLine >= pos.positionInLine) {
/* 497 */           p.positionInLine += shift;
/* 498 */           p.setLookupRequiredRE();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public String getString(int where, int len)
/*     */     throws BadLocationException
/*     */   {
/* 508 */     Segment s = new Segment();
/* 509 */     getChars(where, len, s);
/* 510 */     return new String(s.array, s.offset, s.count);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void getChars(int where, int len, Segment txt)
/*     */     throws BadLocationException
/*     */   {
/* 521 */     DataStorePosition start = this.ti.getTextPosition(where);
/* 522 */     DataStorePosition fin = this.ti.getTextPosition(where + len);
/*     */     
/* 524 */     AbstractLine line1 = (AbstractLine)this.datastore.get(start.lineNumber);
/* 525 */     String s1 = line1.getFullLine() + "\n";
/*     */     
/* 527 */     if (fin == null) { return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 538 */     if (start.lineNumber == fin.lineNumber) {
/* 539 */       String s = s1.substring(start.positionInLine, Math.min(fin.positionInLine, s1.length()));
/*     */       
/* 541 */       txt.array = s.toCharArray();
/* 542 */       txt.count = txt.array.length;
/* 543 */       txt.offset = 0;
/* 544 */       return;
/*     */     }
/*     */     
/* 547 */     AbstractLine line2 = (AbstractLine)this.datastore.get(fin.lineNumber);
/* 548 */     String s2 = line2.getFullLine();
/* 549 */     if (start.positionInLine >= s1.length()) {
/* 550 */       s1 = "";
/* 551 */     } else if (start.positionInLine > 0) {
/* 552 */       s1 = s1.substring(start.positionInLine);
/*     */     }
/*     */     
/* 555 */     if (fin.positionInLine == 0) {
/* 556 */       s2 = "";
/* 557 */     } else if (fin.positionInLine < s2.length() - 1) {
/* 558 */       s2 = s2.substring(0, fin.positionInLine);
/*     */     }
/*     */     
/* 561 */     StringBuffer b = new StringBuffer(s1);
/*     */     
/* 563 */     for (int i = start.lineNumber + 1; i < fin.lineNumber - 1; i++) {
/* 564 */       b.append(((AbstractLine)this.datastore.get(i)).getFullLine()).append('\n');
/*     */     }
/*     */     
/* 567 */     b.append(s2);
/*     */     
/* 569 */     txt.array = b.toString().toCharArray();
/* 570 */     txt.count = b.length();
/* 571 */     txt.offset = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void tableChanged(TableModelEvent event)
/*     */   {
/* 580 */     switch (event.getType()) {
/*     */     case 1: 
/* 582 */       updateLinePos(event.getFirstRow(), event.getLastRow() - event.getFirstRow() + 1);
/*     */       
/*     */ 
/*     */ 
/* 586 */       break;
/*     */     case -1: 
/* 588 */       System.out.println("Delete: " + event.getFirstRow() + " " + event.getLastRow());
/* 589 */       int en = updateLinePos(event.getLastRow() + 1, event.getFirstRow() - event.getLastRow() - 1);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 599 */       for (int i = en; i >= 0; i--) {
/* 600 */         DataStorePosition p = getStorePositionByIndex(i);
/* 601 */         if (p != null) {
/* 602 */           System.out.println("\t" + i + " " + p.lineNumber + " " + p.getLineStartRE() + " " + p.positionInLine);
/* 603 */           if (p.lineNumber < event.getFirstRow()) break;
/* 604 */           this.positions.remove(i);
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 609 */           System.out.println("\tDelete " + i);
/*     */         }
/*     */       }
/* 612 */       break;
/*     */     default: 
/* 614 */       updateLinePos(event.getFirstRow(), 0);
/*     */     }
/*     */   }
/*     */   
/*     */   private int updateLinePos(int firstLine, int amount)
/*     */   {
/* 620 */     System.out.println();
/* 621 */     System.out.println("Adjust Lines: " + firstLine + "\t " + amount);
/* 622 */     System.out.println();
/* 623 */     for (int i = this.positions.size() - 1; i >= 0; i--) {
/* 624 */       DataStorePosition p = getStorePositionByIndex(i);
/* 625 */       if (p != null) {
/* 626 */         if (p.lineNumber < firstLine) {
/* 627 */           return i;
/*     */         }
/* 629 */         System.out.println("\t" + p.lineNumber + "\t" + Math.max(p.lineNumber + amount, firstLine));
/* 630 */         p.lineNumber = Math.max(p.lineNumber + amount, firstLine);
/* 631 */         p.setLookupRequiredRE();
/*     */       }
/*     */     }
/*     */     
/* 635 */     return 0;
/*     */   }
/*     */   
/*     */   private DataStorePosition getStorePositionByIndex(int idx) {
/* 639 */     DataStorePosition p = (DataStorePosition)((WeakReference)this.positions.get(idx)).get();
/* 640 */     if (p == null) {
/* 641 */       this.positions.remove(idx);
/*     */     }
/* 643 */     return p;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/DataStoreContent1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */