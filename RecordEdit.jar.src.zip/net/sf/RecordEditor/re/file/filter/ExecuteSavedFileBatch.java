/*    */ package net.sf.RecordEditor.re.file.filter;
/*    */ 
/*    */ import net.sf.RecordEditor.jibx.JibxCall;
/*    */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ 
/*    */ 
/*    */ public class ExecuteSavedFileBatch<details>
/*    */ {
/*    */   private final Class dtlsClass;
/*    */   private final AbstractExecute<details> action;
/*    */   
/*    */   public ExecuteSavedFileBatch(Class detailsClass, AbstractExecute<details> action)
/*    */   {
/* 15 */     this.dtlsClass = detailsClass;
/* 16 */     this.action = action;
/*    */   }
/*    */   
/*    */   public AbstractFileDisplay execAction(boolean run, String fileName)
/*    */   {
/*    */     try
/*    */     {
/* 23 */       return execActionRaw(run, fileName);
/*    */     } catch (NoClassDefFoundError e) {
/* 25 */       e.printStackTrace();
/* 26 */       Common.logMsg("Jibx Call Failed: Class not loaded", null);
/*    */     } catch (Exception ex) {
/* 28 */       ex.printStackTrace();
/* 29 */       Common.logMsg("Execute Error", ex);
/*    */     }
/* 31 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */   public AbstractFileDisplay execActionRaw(boolean run, String fileName)
/*    */     throws Exception
/*    */   {
/* 38 */     JibxCall<details> jibx = new JibxCall(this.dtlsClass);
/*    */     
/*    */ 
/*    */ 
/* 42 */     details saveDetails = jibx.marshal(fileName);
/*    */     
/* 44 */     if (run) {
/* 45 */       return this.action.execute(saveDetails);
/*    */     }
/* 47 */     this.action.executeDialog(saveDetails);
/*    */     
/* 49 */     return null;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/filter/ExecuteSavedFileBatch.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */