/*      */ package net.sf.RecordEditor.re.file.filter;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import javax.swing.DefaultComboBoxModel;
/*      */ import javax.swing.JTextField;
/*      */ import javax.swing.table.AbstractTableModel;
/*      */ import net.sf.JRecord.Common.IFieldDetail;
/*      */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*      */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*      */ import net.sf.JRecord.Details.AbstractRecordDetail.FieldDetails;
/*      */ import net.sf.RecordEditor.jibx.compare.FieldTest;
/*      */ import net.sf.RecordEditor.jibx.compare.Layout;
/*      */ import net.sf.RecordEditor.jibx.compare.Record;
/*      */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*      */ import net.sf.RecordEditor.utils.swing.Combo.ComboOption;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class FilterDetails
/*      */ {
/*   46 */   public static int FT_NORMAL = 1;
/*      */   
/*   48 */   public static int FT_GROUP = 3;
/*      */   
/*      */ 
/*   51 */   private static final String[] LAYOUT_GROUP_COLUMN_HEADINGS = LangConversion.convertColHeading("Filter Record Selection", new String[] { "Record", "In Group", "Include" });
/*      */   
/*      */ 
/*   54 */   private static final String[] LAYOUT_COLUMN_HEADINGS = { LAYOUT_GROUP_COLUMN_HEADINGS[0], LAYOUT_GROUP_COLUMN_HEADINGS[2] };
/*      */   
/*   56 */   private static final String[] TWO_LAYOUT_COLUMN_HEADINGS = { LAYOUT_GROUP_COLUMN_HEADINGS[0], LangConversion.convert(5, "Equivalent Record") };
/*      */   
/*      */ 
/*      */ 
/*   60 */   private static final String[] FIELD_COLUMN_HEADINGS = LangConversion.convertColHeading("Filter Field Selection", new String[] { "Field", "Include" });
/*      */   
/*      */   private ComboOption[] recordOptions;
/*      */   
/*      */   private static final int INCLUDE_INDEX = 1;
/*      */   
/*      */   private static final int IN_GROUP_INDEX = 1;
/*      */   
/*      */   private static final int GROUP_INCLUDE_INDEX = 2;
/*      */   
/*      */   private static final int SEQUENCE_INDEX = 1;
/*      */   
/*      */   private final AbstractLayoutDetails layout;
/*      */   private AbstractLayoutDetails layout2;
/*      */   private boolean[] inGroup;
/*      */   private int[] recordNo;
/*      */   private int[][] fields;
/*   77 */   private int layoutIndex = 0;
/*      */   
/*   79 */   private JTextField messageFld = new JTextField();
/*      */   
/*      */   private FilterFieldBaseList filterFields;
/*      */   
/*   83 */   private FilterFieldList filterFieldsL2 = null;
/*      */   
/*      */   private FilterFieldList filterFieldsL2a;
/*      */   private FieldList fieldList;
/*   87 */   private boolean twoLayouts = false;
/*      */   
/*      */ 
/*      */ 
/*      */   private int filterType;
/*      */   
/*      */ 
/*      */   private int groupHeader;
/*      */   
/*      */ 
/*      */ 
/*      */   public FilterDetails(AbstractLayoutDetails group, int filterType)
/*      */   {
/*  100 */     this.layout = group;
/*  101 */     this.filterType = filterType;
/*      */     
/*  103 */     init();
/*      */   }
/*      */   
/*      */   private void init() {
/*  107 */     int count = this.layout.getRecordCount();
/*      */     
/*  109 */     this.recordNo = new int[count];
/*  110 */     this.fields = new int[count][];
/*  111 */     if (this.filterType == FT_NORMAL) {
/*  112 */       this.filterFields = new FilterFieldList(this.layout);
/*      */     } else {
/*  114 */       this.filterFields = new FilterFieldGroupList(this.layout);
/*      */       
/*  116 */       this.inGroup = new boolean[count];
/*  117 */       for (int i = 0; i < count; i++) {
/*  118 */         this.inGroup[i] = true;
/*      */       }
/*      */     }
/*      */     
/*  122 */     for (int i = 0; i < count; i++) {
/*  123 */       this.recordNo[i] = 0;
/*      */       
/*  125 */       this.fields[i] = null;
/*      */     }
/*      */   }
/*      */   
/*      */   public ComboOption[] getRecordOptions()
/*      */   {
/*  131 */     return this.recordOptions;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final int[][] getFieldMap()
/*      */   {
/*  141 */     int[][] ret = (int[][])null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  146 */     for (int i = 0; i < this.fields.length; i++) {
/*  147 */       if (this.fields[i] != null) {
/*  148 */         int count = 0;
/*      */         
/*      */ 
/*  151 */         for (int j = 0; j < this.fields[i].length; j++) {
/*  152 */           if (this.fields[i][j] >= 0) {
/*  153 */             count++;
/*      */           }
/*      */         }
/*      */         
/*  157 */         if (count > 0) {
/*  158 */           if (ret == null)
/*      */           {
/*  160 */             ret = new int[this.fields.length][];
/*      */           }
/*      */           
/*  163 */           ret[i] = new int[count];
/*      */           
/*  165 */           int k = 0;
/*      */           
/*      */ 
/*  168 */           for (j = 0; j < this.fields[i].length; j++) {
/*  169 */             if (this.fields[i][j] >= 0) {
/*  170 */               ret[i][(k++)] = j;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  177 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public AbstractTableModel getLayoutListMdl()
/*      */   {
/*  187 */     if (this.twoLayouts)
/*  188 */       return new TwoLayoutList();
/*  189 */     if (this.filterType == FT_GROUP) {
/*  190 */       return new GroupLayoutList();
/*      */     }
/*  192 */     return new LayoutList();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JTextField getMessageFld()
/*      */   {
/*  202 */     return this.messageFld;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setMessageFld(JTextField messageFld)
/*      */   {
/*  210 */     this.messageFld = messageFld;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public AbstractTableModel getFieldListMdl()
/*      */   {
/*  220 */     this.fieldList = new FieldList(null);
/*  221 */     return this.fieldList;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public FilterFieldBaseList getFilterFieldListMdl()
/*      */   {
/*  231 */     return this.filterFields;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public DefaultComboBoxModel getComboModelLayout2()
/*      */   {
/*  238 */     return this.filterFieldsL2.getFieldModel();
/*      */   }
/*      */   
/*      */ 
/*      */   public DefaultComboBoxModel getComboModelLayout2a()
/*      */   {
/*  244 */     return this.filterFieldsL2a.getFieldModel();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getLayoutIndex()
/*      */   {
/*  253 */     return this.layoutIndex;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLayoutIndex(int pLayoutIndex)
/*      */   {
/*  264 */     this.filterFields.setLayoutIndex(pLayoutIndex);
/*  265 */     if (this.filterFieldsL2 != null)
/*      */     {
/*  267 */       this.filterFieldsL2.setLayoutIndex(this.recordNo[pLayoutIndex]);
/*  268 */       this.filterFieldsL2a.setLayoutIndex(this.recordNo[pLayoutIndex]);
/*      */     }
/*      */     
/*  271 */     this.layoutIndex = pLayoutIndex;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getFilterType()
/*      */   {
/*  279 */     return this.filterType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int isNormalFilter()
/*      */   {
/*  286 */     return this.filterType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setNormalFilter(int isNormalFilter)
/*      */   {
/*  293 */     this.filterType = isNormalFilter;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int getGroupHeader()
/*      */   {
/*  300 */     return this.groupHeader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setGroupHeader(int groupHeader)
/*      */   {
/*  307 */     this.groupHeader = groupHeader;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean isInclude(int index)
/*      */   {
/*  333 */     if ((index < 0) || (index >= this.recordNo.length)) {
/*  334 */       return false;
/*      */     }
/*      */     
/*  337 */     return this.recordNo[index] >= 0;
/*      */   }
/*      */   
/*      */   public final boolean isInGroup(int index)
/*      */   {
/*  342 */     if ((this.inGroup == null) || (index < 0) || (index >= this.inGroup.length)) {
/*  343 */       return false;
/*      */     }
/*      */     
/*  346 */     return this.inGroup[index];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Layout getExternalLayout()
/*      */   {
/*  355 */     Layout tmpLayoutSelection = new Layout();
/*      */     
/*  357 */     boolean allSelected = true;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  367 */     int[][] fieldInc = getFieldMap();
/*      */     
/*  369 */     tmpLayoutSelection.name = this.layout.getLayoutName();
/*      */     
/*  371 */     if (this.filterType == FT_GROUP) {
/*  372 */       if ((this.groupHeader >= 0) && (this.groupHeader < this.layout.getRecordCount())) {
/*  373 */         tmpLayoutSelection.groupHeader = this.layout.getRecord(this.groupHeader).getRecordName();
/*      */       }
/*      */       
/*  376 */       Record rec = new Record();
/*  377 */       rec.fieldTest = new ArrayList(20);
/*  378 */       for (int j = 0; j < 20; j++) {
/*  379 */         FilterField filterFld = this.filterFields.getFilterField(0, j);
/*  380 */         if (filterFld.getFieldNumber() >= 0) {
/*  381 */           FieldTest test = new FieldTest();
/*  382 */           if (filterFld.getBooleanOperator() == 0) {
/*  383 */             test.booleanOperator = "Or";
/*      */           }
/*  385 */           AbstractRecordDetail recordDetail = this.layout.getRecord(filterFld.getRecordNumber());
/*  386 */           test.recordName = recordDetail.getRecordName();
/*  387 */           test.fieldName = recordDetail.getField(filterFld.getRecFieldNumber()).getName();
/*  388 */           test.operator = Compare.getOperatorAsString(filterFld.getOperator());
/*  389 */           test.groupOperator = filterFld.getGrouping();
/*  390 */           test.value = filterFld.getValue();
/*  391 */           rec.fieldTest.add(test);
/*  392 */           allSelected = false;
/*      */         }
/*      */       }
/*  395 */       tmpLayoutSelection.getRecords().add(rec);
/*  396 */       for (int i = 0; i < this.layout.getRecordCount(); i++) {
/*  397 */         rec = getExternalRecord(i, fieldInc);
/*  398 */         allSelected = (allSelected) && (rec.fields != null) && (isInclude(i));
/*  399 */         tmpLayoutSelection.getRecords().add(rec);
/*      */       }
/*      */     } else {
/*  402 */       for (int i = 0; i < this.layout.getRecordCount(); i++) {
/*  403 */         if (isInclude(i)) {
/*  404 */           Record rec = getExternalRecord(i, fieldInc);
/*  405 */           allSelected = (allSelected) && (rec.fields == null);
/*      */           
/*  407 */           AbstractRecordDetail recordDetail = this.layout.getRecord(i);
/*  408 */           rec.name = recordDetail.getRecordName();
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  436 */           if (!this.twoLayouts) {
/*  437 */             rec.fieldTest = new ArrayList(20);
/*  438 */             for (int j = 0; j < 20; j++) {
/*  439 */               FilterField filterFld = this.filterFields.getFilterField(i, j);
/*  440 */               if (filterFld.getFieldNumber() >= 0) {
/*  441 */                 FieldTest test = new FieldTest();
/*  442 */                 if (filterFld.getBooleanOperator() == 0) {
/*  443 */                   test.booleanOperator = "Or";
/*      */                 }
/*  445 */                 test.fieldName = recordDetail.getField(filterFld.getFieldNumber()).getName();
/*  446 */                 test.operator = Compare.getOperatorAsString(filterFld.getOperator());
/*  447 */                 test.value = filterFld.getValue();
/*  448 */                 rec.fieldTest.add(test);
/*  449 */                 allSelected = false;
/*      */               }
/*      */             }
/*      */           }
/*      */           
/*  454 */           tmpLayoutSelection.getRecords().add(rec);
/*      */         } else {
/*  456 */           allSelected = false;
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  463 */     if (allSelected) {
/*  464 */       tmpLayoutSelection.records = null;
/*      */     }
/*  466 */     return tmpLayoutSelection;
/*      */   }
/*      */   
/*      */   private Record getExternalRecord(int idx, int[][] fieldInc) {
/*  470 */     Record rec = new Record();
/*      */     
/*      */ 
/*  473 */     AbstractRecordDetail recordDetail = this.layout.getRecord(idx);
/*  474 */     rec.name = recordDetail.getRecordName();
/*      */     
/*  476 */     boolean allFields = !this.twoLayouts;
/*  477 */     if ((allFields) && (fieldInc != null) && (fieldInc[idx] != null)) {
/*  478 */       allFields = fieldInc[idx].length == recordDetail.getFieldCount();
/*  479 */       for (int j = 0; (j < recordDetail.getFieldCount()) && (allFields); j++) {
/*  480 */         if (fieldInc[idx][j] != j) {
/*  481 */           allFields = false;
/*      */         }
/*      */       }
/*      */     }
/*      */     int j;
/*  486 */     if (!allFields)
/*      */     {
/*  488 */       if ((fieldInc != null) && (idx < fieldInc.length) && (fieldInc[idx] != null)) {
/*  489 */         rec.fields = new String[fieldInc[idx].length];
/*  490 */         for (j = 0; j < fieldInc[idx].length;)
/*      */         {
/*  492 */           rec.fields[j] = recordDetail.getField(this.layout.getAdjFieldNumber(idx, fieldInc[idx][j])).getName();j++; continue;
/*      */           
/*      */ 
/*  495 */           rec.fields = new String[recordDetail.getFieldCount()];
/*  496 */           for (int j = 0; j < rec.fields.length; j++) {
/*  497 */             rec.fields[j] = recordDetail.getField(j).getName();
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  502 */     if (this.filterType == FT_GROUP) {
/*  503 */       rec.include = Boolean.valueOf(isInclude(idx));
/*  504 */       rec.inGroup = Boolean.valueOf(isInGroup(idx));
/*      */     }
/*  506 */     return rec;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final Layout getExternalLayout2()
/*      */   {
/*  516 */     Layout tmpLayoutSelection = new Layout();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  522 */     int[][] fieldInc = getFieldMap();
/*      */     
/*  524 */     tmpLayoutSelection.name = this.layout2.getLayoutName();
/*  525 */     for (int i = 0; i < this.layout.getRecordCount(); i++) {
/*  526 */       if ((isInclude(i)) && (fieldInc != null) && (fieldInc[i] != null)) {
/*  527 */         Record rec = new Record();
/*      */         
/*  529 */         int idx = this.recordNo[i];
/*      */         
/*  531 */         AbstractRecordDetail recordDetail = this.layout2.getRecord(idx);
/*  532 */         rec.name = recordDetail.getRecordName();
/*      */         
/*  534 */         rec.fields = new String[fieldInc[i].length];
/*  535 */         for (int j = 0; j < fieldInc[i].length; j++) {
/*  536 */           rec.fields[j] = recordDetail.getField(this.fields[i][fieldInc[i][j]]).getName();
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*  542 */         tmpLayoutSelection.getRecords().add(rec);
/*      */       }
/*      */     }
/*      */     
/*  546 */     return tmpLayoutSelection;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void updateFromExternalLayout(Layout values)
/*      */   {
/*  558 */     int start = 0;
/*      */     
/*      */ 
/*      */ 
/*  562 */     this.filterType = FT_NORMAL;
/*  563 */     if ((values.groupHeader != null) && (!"".equals(values.groupHeader))) {
/*  564 */       this.groupHeader = this.layout.getRecordIndex(values.groupHeader);
/*      */       
/*  566 */       if (this.groupHeader >= 0) {
/*  567 */         this.filterType = FT_GROUP;
/*  568 */         start = 1;
/*      */       }
/*      */     }
/*      */     
/*  572 */     if ((values.records == null) || (values.records.size() == 0))
/*      */     {
/*  574 */       init();
/*      */     } else {
/*  576 */       for (int i = 0; i < this.recordNo.length; i++) {
/*  577 */         String s = this.layout.getRecord(i).getRecordName();
/*  578 */         this.recordNo[i] = -1;
/*  579 */         for (int j = start; j < values.records.size(); j++) {
/*  580 */           Record rec = (Record)values.records.get(j);
/*  581 */           if (rec.name.equalsIgnoreCase(s)) {
/*  582 */             if ((rec.include == null) || (rec.include.booleanValue())) {
/*  583 */               this.recordNo[i] = 0;
/*      */             }
/*  585 */             if (this.inGroup != null) {
/*  586 */               this.inGroup[i] = ((rec.inGroup == null) || (rec.inGroup.booleanValue()) ? 1 : false);
/*      */             }
/*  588 */             if ((rec.fields == null) || (rec.fields.length == 0)) {
/*  589 */               this.fields[i] = null;
/*      */             } else {
/*  591 */               initFieldRow(i);
/*      */               
/*  593 */               for (int k = 0; k < rec.fields.length; k++) {
/*  594 */                 int idx = this.layout.getRecord(i).getFieldIndex(rec.fields[k]);
/*  595 */                 this.fields[i][idx] = 0;
/*      */               }
/*      */             }
/*      */             
/*  599 */             if ((rec.fieldTest == null) || (rec.fieldTest.size() <= 0)) break;
/*  600 */             AbstractRecordDetail recDtl = this.layout.getRecord(i);
/*      */             
/*  602 */             for (int k = 0; k < rec.fieldTest.size(); k++) {
/*  603 */               FieldTest tst = (FieldTest)rec.fieldTest.get(k);
/*  604 */               FilterField filterFld = new FilterField(this.filterType == FT_GROUP);
/*  605 */               filterFld.setFieldNumber(recDtl.getFieldIndex(tst.fieldName));
/*  606 */               filterFld.setOperator(Compare.getOperator(tst.operator));
/*  607 */               filterFld.setValue(tst.value);
/*      */               
/*  609 */               if ("Or".equalsIgnoreCase(tst.booleanOperator)) {
/*  610 */                 filterFld.setBooleanOperator(0);
/*      */               }
/*      */               
/*  613 */               this.filterFields.setFilterField(i, k, filterFld);
/*      */             }
/*  615 */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  623 */     if ((this.filterType == FT_GROUP) && (values.records != null) && (values.records.size() >= 0) && (((Record)values.records.get(0)).fieldTest != null))
/*      */     {
/*      */ 
/*  626 */       for (int k = 0; k < ((Record)values.records.get(0)).fieldTest.size(); k++) {
/*  627 */         FieldTest tst = (FieldTest)((Record)values.records.get(0)).fieldTest.get(k);
/*  628 */         int recNo = this.layout.getRecordIndex(tst.recordName);
/*  629 */         FilterField filterFld = FilterField.newGroupFilterFields();
/*  630 */         if (recNo >= 0) {
/*  631 */           filterFld.setFieldNumber(recNo, this.layout.getRecord(recNo).getFieldIndex(tst.fieldName));
/*      */         }
/*  633 */         filterFld.setOperator(Compare.getOperator(tst.operator));
/*  634 */         filterFld.setValue(tst.value);
/*  635 */         filterFld.setGrouping(tst.groupOperator);
/*      */         
/*  637 */         if ("Or".equalsIgnoreCase(tst.booleanOperator)) {
/*  638 */           filterFld.setBooleanOperator(0);
/*      */         }
/*      */         
/*  641 */         this.filterFields.setFilterField(0, k, filterFld);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void initFieldRow(int row)
/*      */   {
/*  648 */     int len = this.layout.getRecord(row).getFieldCount();
/*      */     
/*  650 */     this.fields[row] = new int[len];
/*      */     
/*  652 */     for (int k = 0; k < len; k++) {
/*  653 */       this.fields[row][k] = -1;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void set2Layouts(boolean is2layouts)
/*      */   {
/*  662 */     this.twoLayouts = is2layouts;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void set2ndLayout(AbstractLayoutDetails dtl)
/*      */   {
/*  671 */     this.twoLayouts = true;
/*      */     
/*  673 */     if ((this.layout2 != dtl) && (dtl != null)) {
/*  674 */       this.layout2 = dtl;
/*      */       
/*  676 */       this.filterFieldsL2 = new FilterFieldList(this.layout2);
/*  677 */       this.filterFieldsL2a = new FilterFieldList(this.layout2);
/*      */       
/*  679 */       this.recordOptions = new ComboOption[this.layout2.getRecordCount() + 1];
/*  680 */       this.recordOptions[0] = new ComboOption(-121, " ");
/*  681 */       for (int i = 1; i < this.recordOptions.length; i++) {
/*  682 */         this.recordOptions[i] = new ComboOption(i - 1, this.layout2.getRecord(i - 1).getRecordName());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public final void set2ndLayout(AbstractLayoutDetails dtl, Layout values1, Layout values2)
/*      */   {
/*  691 */     set2ndLayout(dtl);
/*      */     int i;
/*  693 */     if (dtl.getRecordCount() > 0)
/*      */     {
/*      */ 
/*      */ 
/*  697 */       for (i = 0; i < this.recordNo.length; i++) {
/*  698 */         this.recordNo[i] = -1;
/*      */       }
/*  700 */       if ((values2.records == null) || (values2.records.size() == 0)) {
/*  701 */         for (i = 0; i < this.recordNo.length;) {
/*  702 */           setUpRecord(i);i++; continue;
/*      */           
/*      */ 
/*  705 */           for (i = 0; i < values1.records.size(); i++) {
/*      */             try {
/*  707 */               Record recDiff1 = (Record)values1.records.get(i);
/*  708 */               Record recDiff2 = (Record)values2.records.get(i);
/*  709 */               int idx1 = this.layout.getRecordIndex(recDiff1.name);
/*  710 */               int idx2 = this.layout2.getRecordIndex(recDiff2.name);
/*  711 */               if ((idx1 >= 0) && (idx2 >= 0)) {
/*  712 */                 this.recordNo[idx1] = idx2;
/*  713 */                 if ((recDiff1.fields == null) || (recDiff1.fields.length == 0) || (recDiff2.fields == null) || (recDiff2.fields.length == 0))
/*      */                 {
/*  715 */                   setUpRecord(idx1);
/*      */                 } else {
/*  717 */                   int end = Math.min(recDiff1.fields.length, recDiff2.fields.length);
/*  718 */                   AbstractRecordDetail rec1 = this.layout.getRecord(idx1);
/*  719 */                   AbstractRecordDetail rec2 = this.layout2.getRecord(idx2);
/*      */                   
/*  721 */                   this.fields[idx1] = getInitialisedArray(rec1.getFieldCount());
/*  722 */                   for (int j = 0; j < end; j++) {
/*  723 */                     int fIdx1 = rec1.getFieldIndex(recDiff1.fields[j]);
/*  724 */                     int fIdx2 = rec2.getFieldIndex(recDiff2.fields[j]);
/*  725 */                     int ii = this.layout.getUnAdjFieldNumber(idx1, fIdx1);
/*  726 */                     if ((fIdx1 >= 0) && (ii >= 0)) {
/*  727 */                       this.fields[idx1][ii] = fIdx2;
/*      */                     }
/*      */                   }
/*      */                 }
/*      */               }
/*      */             } catch (Exception e) {
/*  733 */               e.printStackTrace();
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void setUpRecord(int i)
/*      */   {
/*  746 */     String l1 = this.layout.getRecord(i).getRecordName().toLowerCase();
/*      */     
/*  748 */     for (int j = 0; j < this.layout2.getRecordCount(); j++) {
/*  749 */       String l2 = this.layout2.getRecord(j).getRecordName().toLowerCase();
/*      */       
/*  751 */       if ((l1.indexOf(l2) >= 0) || (l2.indexOf(l1) >= 0)) {
/*  752 */         this.recordNo[i] = j;
/*  753 */         updateRecordsFields(i);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  770 */         break;
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private boolean updateRecordsFields(int rowIndex)
/*      */   {
/*  779 */     boolean tableUpdated = false;
/*  780 */     AbstractRecordDetail rec1 = this.layout.getRecord(rowIndex);
/*  781 */     AbstractRecordDetail rec2 = this.layout2.getRecord(this.recordNo[rowIndex]);
/*      */     
/*      */ 
/*  784 */     if (rec2 != null)
/*      */     {
/*      */ 
/*  787 */       String[] names = new String[rec2.getFieldCount()];
/*  788 */       for (int i = 0; i < rec2.getFieldCount(); i++) {
/*  789 */         names[i] = standardiseName(rec2.getField(i).getName());
/*      */       }
/*      */       
/*  792 */       for (i = 0; i < rec1.getFieldCount(); i++)
/*      */       {
/*  794 */         int k = this.layout.getAdjFieldNumber(rowIndex, i);
/*  795 */         String s = standardiseName(rec1.getField(k).getName());
/*  796 */         for (int j = 0; j < names.length; j++) {
/*  797 */           if (names[j].equals(s))
/*      */           {
/*  799 */             if (this.fields[rowIndex] == null) {
/*  800 */               initFieldRow(rowIndex);
/*      */             }
/*  802 */             this.fields[rowIndex][i] = j;
/*  803 */             tableUpdated = true;
/*  804 */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  810 */     return tableUpdated;
/*      */   }
/*      */   
/*      */   private int[] getInitialisedArray(int size)
/*      */   {
/*  815 */     int[] ret = new int[size];
/*      */     
/*  817 */     for (int i = 0; i < size; i++) {
/*  818 */       ret[i] = -1;
/*      */     }
/*      */     
/*  821 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private abstract class BaseLayoutList
/*      */     extends AbstractTableModel
/*      */   {
/*      */     private final String[] layoutColumnHeadings;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public BaseLayoutList(String[] layoutColumnHeadings)
/*      */     {
/*  838 */       this.layoutColumnHeadings = layoutColumnHeadings;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public final int getColumnCount()
/*      */     {
/*  846 */       return this.layoutColumnHeadings.length;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public final String getColumnName(int columnIndex)
/*      */     {
/*  857 */       return this.layoutColumnHeadings[columnIndex];
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public final int getRowCount()
/*      */     {
/*  865 */       return FilterDetails.this.layout.getRecordCount();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public final boolean isCellEditable(int rowIndex, int columnIndex)
/*      */     {
/*  873 */       return columnIndex >= 1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void setValueAt(Object aValue, int rowIndex, int columnIndex)
/*      */     {
/*  882 */       FilterDetails.this.recordNo[rowIndex] = -121;
/*      */       
/*  884 */       if (aValue != null)
/*      */       {
/*  886 */         if ((aValue instanceof Integer)) {
/*  887 */           FilterDetails.this.recordNo[rowIndex] = ((Integer)aValue).intValue();
/*      */           
/*  889 */           if (FilterDetails.this.filterFieldsL2 != null) {
/*  890 */             FilterDetails.this.filterFieldsL2.setLayoutIndex(FilterDetails.this.recordNo[rowIndex]);
/*  891 */             FilterDetails.this.filterFieldsL2a.setLayoutIndex(FilterDetails.this.recordNo[rowIndex]);
/*      */             
/*      */ 
/*  894 */             if (FilterDetails.this.fields[rowIndex] == null) {
/*  895 */               if (FilterDetails.this.updateRecordsFields(rowIndex)) {
/*  896 */                 FilterDetails.this.fieldList.fireTableDataChanged();
/*      */               }
/*  898 */             } else if (FilterDetails.this.recordNo[rowIndex] < 0) {
/*  899 */               FilterDetails.this.fields[rowIndex] = null;
/*  900 */               FilterDetails.this.fieldList.fireTableDataChanged();
/*      */             }
/*      */             
/*      */           }
/*      */         }
/*  905 */         else if ((aValue instanceof ComboOption)) {
/*  906 */           FilterDetails.this.recordNo[rowIndex] = ((ComboOption)aValue).index;
/*      */           
/*  908 */           if (FilterDetails.this.filterFieldsL2 != null) {
/*  909 */             FilterDetails.this.filterFieldsL2.setLayoutIndex(FilterDetails.this.recordNo[rowIndex]);
/*  910 */             FilterDetails.this.filterFieldsL2a.setLayoutIndex(FilterDetails.this.recordNo[rowIndex]);
/*      */             
/*      */ 
/*  913 */             if (FilterDetails.this.fields[rowIndex] == null) {
/*  914 */               if (FilterDetails.this.updateRecordsFields(rowIndex)) {
/*  915 */                 FilterDetails.this.fieldList.fireTableDataChanged();
/*      */               }
/*  917 */             } else if (FilterDetails.this.recordNo[rowIndex] < 0) {
/*  918 */               FilterDetails.this.fields[rowIndex] = null;
/*  919 */               FilterDetails.this.fieldList.fireTableDataChanged();
/*      */             }
/*      */             
/*      */           }
/*      */         }
/*  924 */         else if (((Boolean)aValue).booleanValue()) {
/*  925 */           FilterDetails.this.recordNo[rowIndex] = 0;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private class LayoutList
/*      */     extends FilterDetails.BaseLayoutList
/*      */   {
/*      */     public LayoutList()
/*      */     {
/*  941 */       super(FilterDetails.LAYOUT_COLUMN_HEADINGS);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public Object getValueAt(int rowIndex, int columnIndex)
/*      */     {
/*  950 */       if (columnIndex == 1) {
/*  951 */         return Boolean.valueOf(FilterDetails.this.recordNo[rowIndex] >= 0);
/*      */       }
/*  953 */       return FilterDetails.this.layout.getRecord(rowIndex).getRecordName();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private class TwoLayoutList
/*      */     extends FilterDetails.BaseLayoutList
/*      */   {
/*      */     public TwoLayoutList()
/*      */     {
/*  967 */       super(FilterDetails.TWO_LAYOUT_COLUMN_HEADINGS);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public Object getValueAt(int rowIndex, int columnIndex)
/*      */     {
/*  977 */       if (columnIndex == 1) {
/*  978 */         if (FilterDetails.this.recordNo[rowIndex] < 0)
/*  979 */           return FilterDetails.this.recordOptions[0];
/*  980 */         if (FilterDetails.this.recordNo[rowIndex] + 1 >= FilterDetails.this.recordOptions.length) {
/*  981 */           return null;
/*      */         }
/*  983 */         return FilterDetails.this.recordOptions[(FilterDetails.this.recordNo[rowIndex] + 1)];
/*      */       }
/*  985 */       return FilterDetails.this.layout.getRecord(rowIndex).getRecordName();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private class GroupLayoutList
/*      */     extends FilterDetails.BaseLayoutList
/*      */   {
/*      */     public GroupLayoutList()
/*      */     {
/*  999 */       super(FilterDetails.LAYOUT_GROUP_COLUMN_HEADINGS);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public Object getValueAt(int rowIndex, int columnIndex)
/*      */     {
/* 1009 */       switch (columnIndex) {
/*      */       case 1: 
/* 1011 */         return Boolean.valueOf(FilterDetails.this.inGroup[rowIndex]);
/*      */       case 2: 
/* 1013 */         return Boolean.valueOf(FilterDetails.this.recordNo[rowIndex] >= 0);
/*      */       }
/* 1015 */       return FilterDetails.this.layout.getRecord(rowIndex).getRecordName();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void setValueAt(Object aValue, int rowIndex, int columnIndex)
/*      */     {
/* 1025 */       if (columnIndex == 1) {
/* 1026 */         if ((aValue instanceof Boolean)) {
/* 1027 */           FilterDetails.this.inGroup[rowIndex] = ((Boolean)aValue).booleanValue();
/*      */         }
/*      */       } else {
/* 1030 */         super.setValueAt(aValue, rowIndex, columnIndex);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private String standardiseName(String name)
/*      */   {
/* 1041 */     if (name == null) {
/* 1042 */       return null;
/*      */     }
/* 1044 */     StringBuffer b = new StringBuffer(name.toLowerCase());
/*      */     
/*      */ 
/* 1047 */     for (int i = name.length() - 1; i >= 0; i--) {
/* 1048 */       char c = b.charAt(i);
/* 1049 */       if ((c == ' ') || (c == '-') || (c == '_')) {
/* 1050 */         b.deleteCharAt(i);
/*      */       }
/*      */     }
/*      */     
/* 1054 */     return b.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private class FieldList
/*      */     extends AbstractTableModel
/*      */   {
/*      */     private FieldList() {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public int getColumnCount()
/*      */     {
/* 1070 */       return FilterDetails.FIELD_COLUMN_HEADINGS.length;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public String getColumnName(int columnIndex)
/*      */     {
/* 1078 */       if ((FilterDetails.this.twoLayouts) && (columnIndex == 1)) {
/* 1079 */         return LangConversion.convert(5, "Equivalent Field");
/*      */       }
/* 1081 */       return FilterDetails.FIELD_COLUMN_HEADINGS[columnIndex];
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public int getRowCount()
/*      */     {
/* 1089 */       AbstractRecordDetail rec = FilterDetails.this.layout.getRecord(FilterDetails.this.layoutIndex);
/* 1090 */       if (rec == null) {
/* 1091 */         return 0;
/*      */       }
/* 1093 */       return rec.getFieldCount();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public Object getValueAt(int rowIndex, int columnIndex)
/*      */     {
/* 1102 */       if (columnIndex == 1) {
/* 1103 */         if (FilterDetails.this.twoLayouts)
/*      */         {
/*      */ 
/* 1106 */           if ((FilterDetails.this.fields[FilterDetails.this.layoutIndex] == null) || (FilterDetails.this.fields[FilterDetails.this.layoutIndex][rowIndex] < 0) || (FilterDetails.this.recordNo[FilterDetails.this.layoutIndex] < 0))
/*      */           {
/* 1108 */             return "";
/*      */           }
/* 1110 */           return FilterDetails.this.layout2.getRecord(FilterDetails.this.recordNo[FilterDetails.this.layoutIndex]).getField(FilterDetails.this.fields[FilterDetails.this.layoutIndex][rowIndex]).getName();
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1118 */         if ((FilterDetails.this.fields[FilterDetails.this.layoutIndex] == null) || (FilterDetails.this.fields[FilterDetails.this.layoutIndex][rowIndex] >= 0))
/*      */         {
/* 1120 */           return Boolean.TRUE;
/*      */         }
/* 1122 */         return Boolean.FALSE;
/*      */       }
/* 1124 */       return FilterDetails.this.layout.getAdjField(FilterDetails.this.layoutIndex, rowIndex).getName();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public boolean isCellEditable(int rowIndex, int columnIndex)
/*      */     {
/* 1132 */       return columnIndex == 1;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void setValueAt(Object aValue, int rowIndex, int columnIndex)
/*      */     {
/* 1141 */       int fieldNo = -1;
/* 1142 */       int defaultVal = 0;
/*      */       
/*      */       boolean isDefaultValue;
/* 1145 */       if (FilterDetails.this.twoLayouts) {
/* 1146 */         if ((aValue != null) && (!"".equals(aValue)) && (FilterDetails.this.layoutIndex >= 0) && (FilterDetails.this.layoutIndex < FilterDetails.this.recordNo.length) && (FilterDetails.this.recordNo[FilterDetails.this.layoutIndex] >= 0))
/*      */         {
/* 1148 */           int idx = FilterDetails.this.recordNo[FilterDetails.this.layoutIndex];
/*      */           
/*      */ 
/* 1151 */           fieldNo = FilterDetails.this.layout2.getRecord(idx).getFieldIndex(aValue.toString());
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1157 */         boolean isDefaultValue = fieldNo < 0;
/* 1158 */         defaultVal = -1;
/*      */       } else {
/* 1160 */         isDefaultValue = (aValue == null) || (aValue.getClass() != Boolean.class) || (((Boolean)aValue).booleanValue());
/*      */         
/*      */ 
/*      */ 
/* 1164 */         if (isDefaultValue) {
/* 1165 */           fieldNo = 0;
/*      */         }
/*      */       }
/*      */       
/* 1169 */       if ((FilterDetails.this.fields[FilterDetails.this.layoutIndex] != null) || (!isDefaultValue)) {
/* 1170 */         if (isDefaultValue) {
/* 1171 */           FilterDetails.this.fields[FilterDetails.this.layoutIndex][rowIndex] = fieldNo;
/*      */         } else {
/*      */           try {
/* 1174 */             if (FilterDetails.this.fields[FilterDetails.this.layoutIndex] == null)
/*      */             {
/*      */ 
/* 1177 */               int len = FilterDetails.this.layout.getRecord(FilterDetails.this.layoutIndex).getFieldCount();
/* 1178 */               FilterDetails.this.fields[FilterDetails.this.layoutIndex] = new int[len];
/* 1179 */               for (int j = 0; j < len; j++) {
/* 1180 */                 FilterDetails.this.fields[FilterDetails.this.layoutIndex][j] = defaultVal;
/*      */               }
/*      */             }
/*      */             
/* 1184 */             FilterDetails.this.fields[FilterDetails.this.layoutIndex][rowIndex] = fieldNo;
/*      */           } catch (Exception e) {
/* 1186 */             FilterDetails.this.messageFld.setText("Invalid Field Include: " + e.getMessage());
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/filter/FilterDetails.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */