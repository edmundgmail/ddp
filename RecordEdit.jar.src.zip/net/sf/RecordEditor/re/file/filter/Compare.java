/*     */ package net.sf.RecordEditor.re.file.filter;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.swing.Combo.ComboStdOption;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Compare
/*     */ {
/*  12 */   public static int RECORD_MULTIPLE = 100000;
/*     */   
/*     */   public static final int OP_CONTAINS = 0;
/*     */   
/*     */   public static final int OP_EQUALS = 1;
/*     */   public static final int OP_DOESNT_CONTAIN = 2;
/*     */   public static final int OP_NOT_EQUALS = 3;
/*     */   public static final int OP_STARTS_WITH = 4;
/*     */   public static final int OP_NUMERIC_GT = 5;
/*     */   public static final int OP_NUMERIC_GE = 6;
/*     */   public static final int OP_NUMERIC_LT = 7;
/*     */   public static final int OP_NUMERIC_LE = 8;
/*     */   public static final int OP_NUMERIC_EQ = 9;
/*     */   public static final int OP_TEXT_GT = 10;
/*     */   public static final int OP_TEXT_GE = 11;
/*     */   public static final int OP_TEXT_LT = 12;
/*     */   public static final int OP_TEXT_LE = 13;
/*     */   public static final int OP_LAST_OPERATOR = 13;
/*  30 */   public static final String[] OPERATOR_SEARCH_OPTIONS = { "Contains", " = ", "Doesn't Contain", " <> ", "Starts With", ">", ">=", "<", "<= ", "= (Numeric)", "> (Text)", ">= (Text)", "< (Text)", "<= (Text)" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  39 */   public static final String[] OPERATOR_STRING_VALUES = { "Contains", " = ", "Doesn't Contain", " <> ", "Starts With", ">", ">=", "<", "<= ", "= (Numeric)", "> (Numeric)", ">= (Numeric)", "< (Numeric)", "<= (Numeric)", "= (Text)", "> (Text)", ">= (Text)", "< (Text)", "<= (Text)", "Is Empty" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  51 */   public static final ComboStdOption[] GROUPING_OPERATORS = { getOption(1, "First"), getOption(2, "Last"), getOption(4, "Minimum"), getOption(3, "Maximum"), getOption(5, "Sum"), getOption(6, "Average"), getOption(7, "Any of"), getOption(8, "All of") };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  63 */   public static final String[] OPERATOR_STRING_FOREIGN_VALUES = convertForeign(OPERATOR_STRING_VALUES);
/*     */   
/*     */   protected static final int cGT = 1;
/*     */   
/*     */   protected static final int cEQ = 0;
/*     */   protected static final int cLT = -1;
/*     */   public static final int cNULL = -121;
/*  70 */   public static final int[][] OPERATOR_COMPARATOR_VALUES = { { 1, -121 }, { 1, 0 }, { -1, -121 }, { -1, 0 }, { 0, -121 } };
/*     */   
/*     */ 
/*     */   private static final boolean isNumericCompare(int operator)
/*     */   {
/*  75 */     return (operator >= 5) && (operator <= 9);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final BigDecimal getNumericValue(int op, String val)
/*     */   {
/*  87 */     BigDecimal testNumber = null;
/*     */     
/*  89 */     if (isNumericCompare(op)) {
/*     */       try {
/*  91 */         testNumber = new BigDecimal(val);
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*  95 */     return testNumber;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getOperatorAsString(int op)
/*     */   {
/* 104 */     return OPERATOR_STRING_VALUES[op];
/*     */   }
/*     */   
/*     */   public static int getOperator(String op) {
/* 108 */     return getOperator(op, 0, OPERATOR_STRING_VALUES);
/*     */   }
/*     */   
/*     */   public static int getForeignOperator(String op, int ret) {
/* 112 */     return getOperator(op, ret, OPERATOR_STRING_FOREIGN_VALUES);
/*     */   }
/*     */   
/*     */   public static int getOperator(String op, int ret, String[] operatorValues)
/*     */   {
/* 117 */     for (int i = 0; i < operatorValues.length; i++) {
/* 118 */       if (operatorValues[i].equalsIgnoreCase(op))
/*     */       {
/* 120 */         ret = i;
/* 121 */         break;
/*     */       }
/*     */     }
/*     */     
/* 125 */     return ret;
/*     */   }
/*     */   
/*     */   public static String[] getSearchOptionsForeign() {
/* 129 */     return convertForeign(OPERATOR_SEARCH_OPTIONS);
/*     */   }
/*     */   
/*     */   public static String[] convertForeign(String[] a) {
/* 133 */     String[] b = new String[a.length];
/* 134 */     for (int i = 0; i < a.length; i++) {
/* 135 */       b[i] = a[i];
/* 136 */       if (a[i].trim().length() > 2) {
/* 137 */         b[i] = LangConversion.convert(10, a[i]);
/*     */       }
/*     */     }
/*     */     
/* 141 */     return b;
/*     */   }
/*     */   
/*     */   private static ComboStdOption<Integer> getOption(int key, String value) {
/* 145 */     return new ComboStdOption(Integer.valueOf(key), LangConversion.convert(10, value), value);
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/filter/Compare.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */