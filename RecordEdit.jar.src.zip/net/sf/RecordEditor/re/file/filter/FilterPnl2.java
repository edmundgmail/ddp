/*     */ package net.sf.RecordEditor.re.file.filter;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.io.PrintStream;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.DefaultCellEditor;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JSplitPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.table.AbstractTableModel;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.RecordEditor.jibx.compare.EditorTask;
/*     */ import net.sf.RecordEditor.jibx.compare.Layout;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.msg.UtMessages;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMsg;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.CheckBoxTableRender;
/*     */ import net.sf.RecordEditor.utils.swing.ComboBoxRender;
/*     */ import net.sf.RecordEditor.utils.swing.LayoutCombo;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.swing.saveRestore.ISaveDetails;
/*     */ import net.sf.RecordEditor.utils.swing.saveRestore.IUpdateDetails;
/*     */ import net.sf.RecordEditor.utils.swing.saveRestore.SaveLoadPnl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FilterPnl2
/*     */   extends BaseHelpPanel
/*     */   implements ActionListener, ISaveDetails<EditorTask>
/*     */ {
/*  82 */   private static final int FIRST_COLUMN_WIDTH = SwingUtils.STANDARD_FONT_WIDTH * 35;
/*  83 */   private static final int SECOND_COLUMN_WIDTH = SwingUtils.STANDARD_FONT_WIDTH * 9;
/*     */   
/*  85 */   protected static final int FIELD_VALUE_ROW_HEIGHT = SwingUtils.COMBO_TABLE_ROW_HEIGHT;
/*  86 */   protected static final int FIELD_NAME_WIDTH = SwingUtils.STANDARD_FONT_WIDTH * 22;
/*  87 */   private static final int AND_WIDTH = SwingUtils.STANDARD_FONT_WIDTH * 5;
/*  88 */   private static final int CASE_SENSTIVE_WIDTH = SwingUtils.STANDARD_FONT_WIDTH * 10;
/*  89 */   private static final int OPERATOR_WIDTH = CASE_SENSTIVE_WIDTH;
/*  90 */   private static final int VALUE_WIDTH = FIELD_NAME_WIDTH;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 100 */   private BaseHelpPanel pnl2 = new BaseHelpPanel("Filter");
/* 101 */   private BaseHelpPanel pnl3 = new BaseHelpPanel("Fields");
/*     */   
/*     */ 
/*     */ 
/*     */   private LayoutCombo groupStartCombo;
/*     */   
/*     */ 
/* 108 */   private JPanel recordOptionPanel = new JPanel();
/* 109 */   private JPanel fieldOptionPanel = new JPanel();
/* 110 */   protected final JTable recordTbl = new JTable();
/* 111 */   private JTable fieldTbl = new JTable();
/* 112 */   private JTable filterFieldTbl = new JTable();
/*     */   
/*     */   private AbstractTableModel recordMdl;
/*     */   private AbstractTableModel fieldMdl;
/*     */   private FilterFieldBaseList filterFieldMdl;
/* 117 */   private JLabel fieldHeadingLbl = new JLabel();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 122 */   private JButton execute = SwingUtils.newButton("Filter", Common.getRecordIcon(1));
/*     */   
/* 124 */   private JTextField msgTxt = new JTextField();
/*     */   
/* 126 */   private JButton checkAllRecordsBtn = SwingUtils.newButton("Check Records");
/* 127 */   private JButton uncheckAllRecordsBtn = SwingUtils.newButton("Uncheck Records");
/*     */   
/* 129 */   private JButton checkAllFieldsBtn = SwingUtils.newButton("Check Fields");
/* 130 */   private JButton uncheckAllFieldsBtn = SwingUtils.newButton("Uncheck Fields");
/*     */   
/*     */ 
/*     */   private FilterDetails filter;
/*     */   
/*     */   private AbstractLayoutDetails recordLayout;
/*     */   
/*     */   private final SaveLoadPnl<EditorTask> savePnl;
/*     */   
/* 139 */   private boolean toInit = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 145 */   private final MouseAdapter fieldMouseListner = new MouseAdapter()
/*     */   {
/*     */ 
/*     */     public void mousePressed(MouseEvent m)
/*     */     {
/*     */       try
/*     */       {
/* 152 */         int col = FilterPnl2.this.filterFieldTbl.columnAtPoint(m.getPoint());
/* 153 */         int row = FilterPnl2.this.filterFieldTbl.rowAtPoint(m.getPoint());
/* 154 */         int tblCol = FilterPnl2.this.filterFieldTbl.getColumnModel().getColumn(col).getModelIndex();
/*     */         
/* 156 */         if ((tblCol == 1) || (tblCol == 0)) {
/* 157 */           FilterField rec = FilterPnl2.this.filterFieldMdl.getFilterField(row);
/*     */           
/*     */ 
/*     */ 
/* 161 */           FilterPnl2.this.filterFieldMdl.setValueAt(Integer.valueOf(1 - rec.getBooleanOperator()), row, tblCol);
/*     */           
/* 163 */           FilterPnl2.this.filterFieldMdl.fireTableRowsUpdated(row, row);
/* 164 */           System.out.print(" ## " + row);
/*     */         }
/*     */       }
/*     */       catch (Exception e) {
/* 168 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FilterPnl2(AbstractLayoutDetails layout, int filterType, IUpdateDetails<EditorTask> updPnl)
/*     */   {
/* 191 */     this.savePnl = new SaveLoadPnl(this, updPnl, Parameters.getFileName("FilterSaveDirectory"), EditorTask.class);
/*     */     
/*     */ 
/*     */ 
/* 195 */     setRecordLayout(layout, 0, filterType);
/*     */   }
/*     */   
/*     */ 
/*     */   public final void setRecordLayout(AbstractLayoutDetails layout, int heightOverhead, int filterType)
/*     */   {
/* 201 */     this.recordLayout = layout;
/*     */     
/*     */ 
/* 204 */     setupScreenFields(filterType);
/*     */     
/* 206 */     if (this.toInit)
/*     */     {
/*     */ 
/*     */ 
/* 210 */       int maxTblColWidth = ReFrame.getDesktopWidth() / 4;
/* 211 */       int desktopHeight = ReFrame.getDesktopHeight() - 50 - heightOverhead - 2 * (int)BasePanel.GAP1;
/*     */       
/*     */ 
/*     */ 
/* 215 */       desktopHeight -= SwingUtils.BUTTON_HEIGHT + 6;
/*     */       
/*     */ 
/* 218 */       desktopHeight -= SwingUtils.BUTTON_HEIGHT * 3;
/*     */       
/*     */ 
/* 221 */       registerComponentRE(this.pnl2);
/*     */       
/*     */ 
/* 224 */       this.pnl2.setBorder(BorderFactory.createEmptyBorder());
/* 225 */       this.pnl3.setBorder(BorderFactory.createEmptyBorder());
/*     */       
/*     */ 
/*     */ 
/* 229 */       if (filterType == FilterDetails.FT_GROUP)
/*     */       {
/* 231 */         this.groupStartCombo = new LayoutCombo(this.recordLayout, false, false);
/* 232 */         this.pnl2.addLineRE("Group Starts with", this.groupStartCombo);
/*     */         
/* 234 */         this.pnl2.setGapRE(BasePanel.GAP1);
/*     */       }
/* 236 */       if (layout.getRecordCount() > 1) {
/* 237 */         int maxHeight = desktopHeight / 3;
/*     */         
/* 239 */         maxHeight = desktopHeight / 4;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 244 */         this.pnl2.addComponentRE(1, 3, this.recordOptionPanel.getPreferredSize().getHeight(), BasePanel.GAP, 2, 2, this.recordOptionPanel);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 249 */         int height = SwingUtils.calculateTableHeight(this.recordTbl.getRowCount(), maxHeight);
/* 250 */         this.pnl2.setHeightRE(SwingUtils.BUTTON_HEIGHT + 6);
/*     */         
/*     */ 
/* 253 */         desktopHeight -= height + SwingUtils.BUTTON_HEIGHT + 6;
/* 254 */         this.pnl2.addComponentRE(1, 3, height, BasePanel.GAP1, 2, 2, this.recordTbl);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 259 */         this.pnl2.setComponentName(this.recordTbl, "RecordSelection");
/* 260 */         Common.calcColumnWidths(this.recordTbl, 0, maxTblColWidth);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 265 */       this.pnl2.addComponentRE(1, 3, this.fieldOptionPanel.getPreferredSize().getHeight(), BasePanel.GAP, 2, 2, this.fieldOptionPanel);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 271 */       this.pnl2.setHeightRE(SwingUtils.BUTTON_HEIGHT + 6);
/*     */       
/*     */ 
/*     */ 
/* 275 */       int rows = this.fieldTbl.getRowCount();
/* 276 */       for (int i = 0; i < this.recordLayout.getRecordCount(); i++) {
/* 277 */         rows = Math.max(rows, this.recordLayout.getRecord(i).getFieldCount());
/*     */       }
/* 279 */       int height = SwingUtils.calculateTableHeight(rows, desktopHeight / 2);
/* 280 */       desktopHeight -= height;
/*     */       
/* 282 */       this.pnl2.addComponentRE(1, 3, height, BasePanel.GAP1, 2, 2, this.fieldTbl);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 287 */       this.pnl3.addHeadingComponentRE(this.fieldHeadingLbl);
/* 288 */       this.pnl3.setGapRE(BasePanel.GAP1);
/*     */       
/* 290 */       this.pnl3.addComponentRE(1, 5, -1.0D, 3.0D, 2, 2, this.filterFieldTbl);
/*     */       
/*     */ 
/*     */ 
/* 294 */       this.pnl3.setComponentName(this.filterFieldTbl, "FieldRelationship");
/* 295 */       this.filterFieldTbl.addMouseListener(this.fieldMouseListner);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 305 */       this.pnl2.setComponentName(this.fieldTbl, "FieldSelection");
/*     */       
/*     */ 
/*     */ 
/* 309 */       Common.calcColumnWidths(this.fieldTbl, 0, maxTblColWidth);
/*     */       
/*     */ 
/* 312 */       Dimension d = this.pnl2.getPreferredSize();
/* 313 */       int leftWidth = Math.min(d.width, this.pnl2.getMinimumSize().width + 15);
/* 314 */       int rightWidth = Math.max(this.pnl3.getPreferredSize().width, Math.min(this.filterFieldTbl.getPreferredSize().width + 35, ReFrame.getDesktopWidth() - leftWidth - 50));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 327 */       this.pnl2.setPreferredSize(new Dimension(leftWidth, d.height));
/* 328 */       this.pnl3.setPreferredSize(new Dimension(rightWidth, this.pnl3.getPreferredSize().height));
/* 329 */       JSplitPane sp = new JSplitPane(1, this.pnl2, this.pnl3);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 335 */       setGapRE(0.0D);
/* 336 */       setHelpURLre(Common.formatHelpURL("HlpRe06.htm"));
/* 337 */       addComponentRE(0, 6, -1.0D, BasePanel.GAP, 2, 2, sp);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 342 */       setGapRE(BasePanel.GAP0);
/*     */       
/*     */ 
/*     */ 
/* 346 */       addLineRE("", this.savePnl.panel, this.execute);
/* 347 */       setHeightRE(BasePanel.GAP1 * 2.0D);
/* 348 */       setGapRE(BasePanel.GAP0);
/*     */       
/*     */ 
/* 351 */       addMessage(this.msgTxt);
/* 352 */       this.fieldHeadingLbl.setText(UtMessages.FIELD_SELECTION.get(this.recordLayout.getRecord(0).getRecordName()));
/* 353 */       super.done();
/* 354 */       this.toInit = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final AbstractLayoutDetails getRecordLayout()
/*     */   {
/* 363 */     return this.recordLayout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setupScreenFields(int filterType)
/*     */   {
/* 372 */     this.filter = new FilterDetails(this.recordLayout, filterType);
/* 373 */     this.filter.setMessageFld(this.msgTxt);
/* 374 */     this.filter.set2Layouts(false);
/*     */     
/*     */ 
/* 377 */     this.fieldMdl = this.filter.getFieldListMdl();
/* 378 */     this.filterFieldMdl = this.filter.getFilterFieldListMdl();
/* 379 */     this.recordMdl = this.filter.getLayoutListMdl();
/*     */     
/* 381 */     this.recordTbl.setModel(this.recordMdl);
/* 382 */     this.fieldTbl.setModel(this.fieldMdl);
/*     */     
/*     */ 
/* 385 */     this.filterFieldTbl.setModel(this.filterFieldMdl);
/* 386 */     buildFieldFilterTable();
/*     */     
/*     */ 
/* 389 */     setRecordTableDetails(this.recordTbl);
/* 390 */     setFieldTableDetails(this.fieldTbl);
/*     */     
/* 392 */     this.recordOptionPanel.add(this.uncheckAllRecordsBtn);
/* 393 */     this.recordOptionPanel.add(this.checkAllRecordsBtn);
/*     */     
/* 395 */     this.fieldOptionPanel.add(this.uncheckAllFieldsBtn);
/* 396 */     this.fieldOptionPanel.add(this.checkAllFieldsBtn);
/*     */     
/*     */ 
/* 399 */     if (this.toInit) {
/* 400 */       this.recordTbl.addMouseListener(new MouseAdapter() {
/*     */         public void mousePressed(MouseEvent m) {
/* 402 */           int idx = FilterPnl2.this.recordTbl.getSelectedRow();
/*     */           
/* 404 */           if ((idx >= 0) && (idx < FilterPnl2.this.recordTbl.getRowCount()))
/*     */           {
/* 406 */             Common.stopCellEditing(FilterPnl2.this.filterFieldTbl);
/*     */             
/* 408 */             FilterPnl2.this.filter.setLayoutIndex(idx);
/* 409 */             FilterPnl2.this.fieldMdl.fireTableDataChanged();
/*     */             
/* 411 */             FilterPnl2.this.filterFieldMdl.fireTableDataChanged();
/*     */             
/*     */ 
/* 414 */             FilterPnl2.this.fieldHeadingLbl.setText(UtMessages.FIELD_SELECTION.get(FilterPnl2.this.recordLayout.getRecord(idx).getRecordName()));
/*     */           }
/*     */           
/*     */         }
/* 418 */       });
/* 419 */       this.uncheckAllRecordsBtn.addActionListener(this);
/* 420 */       this.checkAllRecordsBtn.addActionListener(this);
/* 421 */       this.uncheckAllFieldsBtn.addActionListener(this);
/* 422 */       this.checkAllFieldsBtn.addActionListener(this);
/*     */       
/*     */ 
/* 425 */       registerComponentRE(this.uncheckAllRecordsBtn);
/* 426 */       registerComponentRE(this.checkAllRecordsBtn);
/* 427 */       registerComponentRE(this.uncheckAllFieldsBtn);
/* 428 */       registerComponentRE(this.checkAllFieldsBtn);
/*     */     }
/*     */     else {
/* 431 */       this.recordMdl.fireTableDataChanged();
/* 432 */       this.fieldMdl.fireTableDataChanged();
/*     */       
/*     */ 
/* 435 */       this.filterFieldMdl.fireTableDataChanged();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setRecordTableDetails(JTable tbl)
/*     */   {
/* 447 */     setTableDetails(tbl);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setFieldTableDetails(JTable tbl)
/*     */   {
/* 455 */     setTableDetails(tbl);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setTableDetails(JTable tbl)
/*     */   {
/* 466 */     setTableDetailsCol0(tbl);
/*     */     
/* 468 */     for (int i = 1; i < tbl.getColumnCount(); i++) {
/* 469 */       TableColumn tc = tbl.getColumnModel().getColumn(i);
/* 470 */       tc.setCellRenderer(new CheckBoxTableRender());
/* 471 */       tc.setCellEditor(new DefaultCellEditor(new JCheckBox()));
/* 472 */       tc.setPreferredWidth(SECOND_COLUMN_WIDTH);
/*     */     }
/*     */   }
/*     */   
/*     */   protected final void setTableDetailsCol0(JTable tbl)
/*     */   {
/* 478 */     tbl.setAutoResizeMode(0);
/* 479 */     tbl.getColumnModel().getColumn(0).setPreferredWidth(FIRST_COLUMN_WIDTH);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void buildFieldFilterTable()
/*     */   {
/* 489 */     DefaultComboBoxModel operatorMdl = new DefaultComboBoxModel(Compare.OPERATOR_STRING_FOREIGN_VALUES);
/*     */     
/* 491 */     ComboBoxRender operatorRendor = new ComboBoxRender(operatorMdl);
/* 492 */     TableCellRenderer fieldRendor = this.filter.getFilterFieldListMdl().getTableCellRender();
/*     */     
/* 494 */     this.filterFieldTbl.setAutoResizeMode(0);
/* 495 */     this.filterFieldTbl.setRowHeight(FIELD_VALUE_ROW_HEIGHT);
/* 496 */     TableColumnModel tcm = this.filterFieldTbl.getColumnModel();
/*     */     
/* 498 */     TableColumn tc = tcm.getColumn(0);
/* 499 */     tc.setPreferredWidth(AND_WIDTH);
/* 500 */     tc = tcm.getColumn(1);
/* 501 */     tc.setPreferredWidth(AND_WIDTH);
/*     */     
/* 503 */     tc = tcm.getColumn(2);
/* 504 */     tc.setPreferredWidth(FIELD_NAME_WIDTH);
/* 505 */     tc.setCellRenderer(fieldRendor);
/* 506 */     tc.setCellEditor(this.filter.getFilterFieldListMdl().getTableCellEditor());
/*     */     
/* 508 */     tc = tcm.getColumn(3);
/* 509 */     tc.setPreferredWidth(CASE_SENSTIVE_WIDTH);
/* 510 */     tc.setCellRenderer(new CheckBoxTableRender());
/* 511 */     tc.setCellEditor(new DefaultCellEditor(new JCheckBox()));
/*     */     
/*     */ 
/* 514 */     int opId = 4;
/* 515 */     int valueId = 5;
/*     */     
/* 517 */     if (this.filter.getFilterType() == FilterDetails.FT_GROUP) {
/* 518 */       opId = 5;
/* 519 */       valueId = 6;
/*     */       
/* 521 */       tc = tcm.getColumn(4);
/* 522 */       tc.setPreferredWidth(OPERATOR_WIDTH);
/* 523 */       tc.setCellRenderer(new ComboBoxRender(Compare.GROUPING_OPERATORS));
/* 524 */       tc.setCellEditor(new DefaultCellEditor(new JComboBox(Compare.GROUPING_OPERATORS)));
/*     */     }
/*     */     
/*     */ 
/* 528 */     tc = tcm.getColumn(opId);
/* 529 */     tc.setPreferredWidth(OPERATOR_WIDTH);
/* 530 */     tc.setCellRenderer(operatorRendor);
/* 531 */     tc.setCellEditor(new DefaultCellEditor(new JComboBox(Compare.OPERATOR_STRING_FOREIGN_VALUES)));
/*     */     
/*     */ 
/*     */ 
/* 535 */     tcm.getColumn(valueId).setPreferredWidth(VALUE_WIDTH);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void actionPerformed(ActionEvent event)
/*     */   {
/* 545 */     stopTblEdit();
/*     */     
/* 547 */     if (event.getSource() == this.uncheckAllFieldsBtn) {
/* 548 */       updateIncludeFlag(Boolean.FALSE);
/* 549 */     } else if (event.getSource() == this.checkAllFieldsBtn) {
/* 550 */       updateIncludeFlag(Boolean.TRUE);
/* 551 */     } else if (event.getSource() == this.uncheckAllRecordsBtn) {
/* 552 */       updateRecordFlag(Boolean.FALSE);
/* 553 */     } else if (event.getSource() == this.checkAllRecordsBtn) {
/* 554 */       updateRecordFlag(Boolean.TRUE);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EditorTask getSaveDetails()
/*     */   {
/* 575 */     stopTblEdit();
/*     */     
/* 577 */     return new EditorTask().setFilter(getFilter().getExternalLayout());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void update(Layout values)
/*     */   {
/* 585 */     getFilter().updateFromExternalLayout(values);
/* 586 */     fireDataChanged();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void updateRecordFlag(Boolean val)
/*     */   {
/* 596 */     for (int i = this.recordTbl.getRowCount() - 1; i >= 0; i--) {
/* 597 */       this.recordTbl.setValueAt(val, i, 1);
/*     */     }
/* 599 */     this.recordMdl.fireTableDataChanged();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void updateIncludeFlag(Boolean val)
/*     */   {
/* 611 */     for (int i = this.fieldTbl.getRowCount() - 1; i >= 0; i--) {
/* 612 */       this.fieldMdl.setValueAt(val, i, 1);
/*     */     }
/* 614 */     this.fieldMdl.fireTableDataChanged();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final JTextField getMessageFld()
/*     */   {
/* 625 */     return this.msgTxt;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final FilterDetails getFilter()
/*     */   {
/* 633 */     stopTblEdit();
/*     */     
/* 635 */     if (this.groupStartCombo != null) {
/* 636 */       this.filter.setGroupHeader(getGroupRecordId());
/*     */     }
/*     */     
/*     */ 
/* 640 */     return this.filter;
/*     */   }
/*     */   
/*     */   public final void fireDataChanged() {
/* 644 */     if (this.fieldMdl != null) {
/* 645 */       this.fieldMdl.fireTableDataChanged();
/* 646 */       this.filterFieldMdl.fireTableDataChanged();
/*     */       
/* 648 */       this.recordMdl.fireTableDataChanged();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void stopTblEdit()
/*     */   {
/* 655 */     Common.stopCellEditing(this.recordTbl);
/* 656 */     Common.stopCellEditing(this.fieldTbl);
/*     */     
/*     */ 
/* 659 */     Common.stopCellEditing(this.filterFieldTbl);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getGroupRecordId()
/*     */   {
/* 673 */     if (this.groupStartCombo != null) {
/* 674 */       return this.groupStartCombo.getLayoutIndex();
/*     */     }
/* 676 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final JButton getExecute()
/*     */   {
/* 684 */     return this.execute;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/filter/FilterPnl2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */