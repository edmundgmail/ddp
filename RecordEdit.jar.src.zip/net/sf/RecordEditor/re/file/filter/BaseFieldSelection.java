/*     */ package net.sf.RecordEditor.re.file.filter;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.DefaultCellEditor;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.table.AbstractTableModel;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.CheckBoxTableRender;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseFieldSelection
/*     */   extends BaseHelpPanel
/*     */   implements ActionListener
/*     */ {
/*  66 */   private static final int FIRST_COLUMN_WIDTH = SwingUtils.STANDARD_FONT_WIDTH * 35;
/*  67 */   private static final int SECOND_COLUMN_WIDTH = SwingUtils.STANDARD_FONT_WIDTH * 9;
/*     */   
/*  69 */   protected static final int FIELD_VALUE_ROW_HEIGHT = SwingUtils.COMBO_TABLE_ROW_HEIGHT;
/*  70 */   protected static final int FIELD_NAME_WIDTH = SwingUtils.STANDARD_FONT_WIDTH * 22;
/*     */   
/*     */ 
/*  73 */   private BaseHelpPanel pnl2 = new BaseHelpPanel("Filter");
/*     */   
/*  75 */   private JPanel recordOptionPanel = new JPanel();
/*  76 */   private JPanel fieldOptionPanel = new JPanel();
/*  77 */   private final JTable recordTbl = new JTable();
/*  78 */   private JTable fieldTbl = new JTable();
/*     */   
/*     */   private AbstractTableModel recordMdl;
/*     */   
/*     */   private AbstractTableModel fieldMdl;
/*     */   
/*  84 */   private JButton execute = SwingUtils.newButton("Filter", Common.getRecordIcon(1));
/*     */   
/*  86 */   private JTextField msgTxt = new JTextField();
/*     */   
/*  88 */   private JButton checkAllRecordsBtn = SwingUtils.newButton("Check Records");
/*  89 */   private JButton uncheckAllRecordsBtn = SwingUtils.newButton("Uncheck Records");
/*     */   
/*  91 */   private JButton checkAllFieldsBtn = SwingUtils.newButton("Check Fields");
/*  92 */   private JButton uncheckAllFieldsBtn = SwingUtils.newButton("Uncheck Fields");
/*     */   
/*     */   private FilterDetails filter;
/*     */   
/*     */   private AbstractLayoutDetails recordLayout;
/*     */   
/*  98 */   private boolean toInit = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setRecordLayout(AbstractLayoutDetails layout, AbstractLayoutDetails layout2, boolean is2ndLayout, int heightOverhead)
/*     */   {
/* 134 */     this.recordLayout = layout;
/*     */     
/*     */ 
/* 137 */     setupScreenFields(is2ndLayout, layout2);
/*     */     
/* 139 */     if (this.toInit)
/*     */     {
/* 141 */       int desktopHeight = ReFrame.getDesktopHeight() - 50 - heightOverhead - 2 * (int)BasePanel.GAP1;
/*     */       
/*     */ 
/* 144 */       if (!is2ndLayout) {
/* 145 */         desktopHeight -= SwingUtils.BUTTON_HEIGHT + 6;
/*     */       }
/*     */       
/* 148 */       registerComponentRE(this.pnl2);
/*     */       
/* 150 */       this.pnl2.setBorder(BorderFactory.createEmptyBorder());
/*     */       
/*     */ 
/* 153 */       if ((getClass() != BaseFieldSelection.class) || (is2ndLayout) || (layout.getRecordCount() > 1))
/*     */       {
/*     */ 
/* 156 */         int maxHeight = desktopHeight / 3;
/*     */         int height;
/* 158 */         int height; if (is2ndLayout) {
/* 159 */           this.pnl2.addHelpBtnRE(SwingUtils.getHelpButton());
/* 160 */           height = SwingUtils.calculateComboTableHeight(this.recordTbl.getRowCount(), maxHeight);
/*     */         } else {
/* 162 */           this.pnl2.addHelpBtnRE(this.recordOptionPanel, SwingUtils.getHelpButton());
/* 163 */           height = SwingUtils.calculateTableHeight(this.recordTbl.getRowCount(), maxHeight);
/*     */         }
/* 165 */         this.pnl2.setHeightRE(SwingUtils.BUTTON_HEIGHT + 6);
/*     */         
/* 167 */         desktopHeight -= height + SwingUtils.BUTTON_HEIGHT + 6;
/* 168 */         this.pnl2.addComponentRE(1, 5, height, BasePanel.GAP1, 2, 2, this.recordTbl);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 173 */         this.pnl2.setComponentName(this.recordTbl, "RecordSelection");
/*     */       }
/*     */       
/*     */ 
/* 177 */       if (!is2ndLayout) {
/* 178 */         this.pnl2.addLineRE("", this.fieldOptionPanel);
/* 179 */         this.pnl2.setHeightRE(SwingUtils.BUTTON_HEIGHT + 6);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 184 */       int height = desktopHeight * 4 / 5;
/*     */       
/* 186 */       this.pnl2.addComponentRE(1, 5, height, 3.0D, 2, 2, this.fieldTbl);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 191 */       this.pnl2.setComponentName(this.fieldTbl, "FieldSelection");
/*     */       
/* 193 */       setGapRE(0.0D);
/* 194 */       setHelpURLre(Common.formatHelpURL("HlpRe06.htm"));
/* 195 */       addComponentRE(0, 6, -1.0D, BasePanel.GAP, 2, 2, new JScrollPane(this.pnl2));
/*     */       
/*     */ 
/* 198 */       addMessage(this.msgTxt);
/* 199 */       super.done();
/* 200 */       this.toInit = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final AbstractLayoutDetails getRecordLayout()
/*     */   {
/* 209 */     return this.recordLayout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setupScreenFields(boolean is2ndLayout, AbstractLayoutDetails layout2)
/*     */   {
/* 220 */     this.filter = new FilterDetails(this.recordLayout, FilterDetails.FT_NORMAL);
/* 221 */     this.filter.setMessageFld(this.msgTxt);
/* 222 */     this.filter.set2Layouts(is2ndLayout);
/* 223 */     if (is2ndLayout) {
/* 224 */       this.filter.set2ndLayout(layout2);
/*     */     }
/*     */     
/* 227 */     this.fieldMdl = this.filter.getFieldListMdl();
/* 228 */     this.recordMdl = this.filter.getLayoutListMdl();
/*     */     
/* 230 */     this.recordTbl.setModel(this.recordMdl);
/* 231 */     this.fieldTbl.setModel(this.fieldMdl);
/*     */     
/*     */ 
/* 234 */     setRecordTableDetails(this.recordTbl);
/* 235 */     setFieldTableDetails(this.fieldTbl);
/*     */     
/* 237 */     this.recordOptionPanel.add(this.uncheckAllRecordsBtn);
/* 238 */     this.recordOptionPanel.add(this.checkAllRecordsBtn);
/*     */     
/* 240 */     this.fieldOptionPanel.add(this.uncheckAllFieldsBtn);
/* 241 */     this.fieldOptionPanel.add(this.checkAllFieldsBtn);
/*     */     
/*     */ 
/* 244 */     if (this.toInit) {
/* 245 */       this.recordTbl.addMouseListener(new MouseAdapter() {
/*     */         public void mousePressed(MouseEvent m) {
/* 247 */           int idx = BaseFieldSelection.this.recordTbl.getSelectedRow();
/*     */           
/* 249 */           if ((idx >= 0) && (idx < BaseFieldSelection.this.recordTbl.getRowCount())) {
/* 250 */             BaseFieldSelection.this.filter.setLayoutIndex(idx);
/* 251 */             BaseFieldSelection.this.fieldMdl.fireTableDataChanged();
/*     */           }
/*     */           
/*     */         }
/* 255 */       });
/* 256 */       this.uncheckAllRecordsBtn.addActionListener(this);
/* 257 */       this.checkAllRecordsBtn.addActionListener(this);
/* 258 */       this.uncheckAllFieldsBtn.addActionListener(this);
/* 259 */       this.checkAllFieldsBtn.addActionListener(this);
/*     */       
/*     */ 
/* 262 */       registerComponentRE(this.uncheckAllRecordsBtn);
/* 263 */       registerComponentRE(this.checkAllRecordsBtn);
/* 264 */       registerComponentRE(this.uncheckAllFieldsBtn);
/* 265 */       registerComponentRE(this.checkAllFieldsBtn);
/*     */     }
/*     */     else {
/* 268 */       this.recordMdl.fireTableDataChanged();
/* 269 */       this.fieldMdl.fireTableDataChanged();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setRecordTableDetails(JTable tbl)
/*     */   {
/* 280 */     setTableDetails(tbl);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setFieldTableDetails(JTable tbl)
/*     */   {
/* 288 */     setTableDetails(tbl);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setTableDetails(JTable tbl)
/*     */   {
/* 297 */     DefaultCellEditor includeEditor = new DefaultCellEditor(new JCheckBox());
/*     */     
/*     */ 
/* 300 */     setTableDetailsCol0(tbl);
/*     */     
/* 302 */     TableColumn tc = tbl.getColumnModel().getColumn(1);
/* 303 */     tc.setCellRenderer(new CheckBoxTableRender());
/* 304 */     tc.setCellEditor(includeEditor);
/* 305 */     tc.setPreferredWidth(SECOND_COLUMN_WIDTH);
/*     */   }
/*     */   
/*     */   protected final void setTableDetailsCol0(JTable tbl)
/*     */   {
/* 310 */     tbl.setAutoResizeMode(0);
/* 311 */     tbl.getColumnModel().getColumn(0).setPreferredWidth(FIRST_COLUMN_WIDTH);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void actionPerformed(ActionEvent event)
/*     */   {
/* 322 */     stopTblEdit();
/*     */     
/* 324 */     if (event.getSource() == this.uncheckAllFieldsBtn) {
/* 325 */       updateIncludeFlag(Boolean.FALSE);
/* 326 */     } else if (event.getSource() == this.checkAllFieldsBtn) {
/* 327 */       updateIncludeFlag(Boolean.TRUE);
/* 328 */     } else if (event.getSource() == this.uncheckAllRecordsBtn) {
/* 329 */       updateRecordFlag(Boolean.FALSE);
/* 330 */     } else if (event.getSource() == this.checkAllRecordsBtn) {
/* 331 */       updateRecordFlag(Boolean.TRUE);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void updateRecordFlag(Boolean val)
/*     */   {
/* 355 */     for (int i = this.recordTbl.getRowCount() - 1; i >= 0; i--) {
/* 356 */       this.recordTbl.setValueAt(val, i, 1);
/*     */     }
/* 358 */     this.recordMdl.fireTableDataChanged();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void updateIncludeFlag(Boolean val)
/*     */   {
/* 370 */     for (int i = this.fieldTbl.getRowCount() - 1; i >= 0; i--) {
/* 371 */       this.fieldMdl.setValueAt(val, i, 1);
/*     */     }
/* 373 */     this.fieldMdl.fireTableDataChanged();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final JTextField getMessageFld()
/*     */   {
/* 381 */     return this.msgTxt;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final FilterDetails getFilter()
/*     */   {
/* 389 */     stopTblEdit();
/*     */     
/* 391 */     return this.filter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final JTable getRecordTbl()
/*     */   {
/* 398 */     return this.recordTbl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final JTable getFieldTbl()
/*     */   {
/* 406 */     return this.fieldTbl;
/*     */   }
/*     */   
/*     */ 
/*     */   private void stopTblEdit()
/*     */   {
/* 412 */     Common.stopCellEditing(this.recordTbl);
/* 413 */     Common.stopCellEditing(this.fieldTbl);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final JButton getExecute()
/*     */   {
/* 421 */     return this.execute;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/filter/BaseFieldSelection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */