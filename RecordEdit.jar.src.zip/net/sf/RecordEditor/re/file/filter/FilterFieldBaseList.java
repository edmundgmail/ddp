/*     */ package net.sf.RecordEditor.re.file.filter;
/*     */ 
/*     */ import javax.swing.table.AbstractTableModel;
/*     */ import javax.swing.table.TableCellEditor;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import net.sf.JRecord.Common.FieldDetail;
/*     */ import net.sf.JRecord.Common.IFieldDetail;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.JRecord.detailsSelection.FieldSelect;
/*     */ import net.sf.JRecord.detailsSelection.FieldSelectX;
/*     */ import net.sf.JRecord.detailsSelection.RecordSel;
/*     */ import net.sf.RecordEditor.utils.RecordGroupSelectionBuilder;
/*     */ import net.sf.RecordEditor.utils.RecordSelectionBuilder;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.swing.Combo.ComboStdOption;
/*     */ import net.sf.RecordEditor.utils.swing.Combo.IComboOption;
/*     */ 
/*     */ 
/*     */ public abstract class FilterFieldBaseList
/*     */   extends AbstractTableModel
/*     */ {
/*  23 */   protected static FieldSelect TRUE_SELECT = ;
/*     */   
/*     */ 
/*     */   public static final int NUMBER_FIELD_FILTER_ROWS = 20;
/*     */   
/*  28 */   private static final FilterField NULL_FILTER_FIELD_STD = FilterField.newStandardFilterFields();
/*  29 */   private static final FilterField NULL_FILTER_FIELD_GROUP = FilterField.newGroupFilterFields();
/*     */   
/*     */   private final String[] fieldFilterColumnHeadings;
/*     */   protected FilterField[][] filterFields;
/*  33 */   private RecordSel[] recSel = null;
/*     */   
/*     */   protected AbstractLayoutDetails layout;
/*  36 */   private int layoutIndex = 0;
/*     */   
/*     */   private final boolean useGroup;
/*     */   
/*     */   private final FilterField nullFilterField;
/*     */   
/*     */   private IComboOption<Integer>[] groupingOptions;
/*     */   
/*     */ 
/*     */   public FilterFieldBaseList(String[] columnNames, boolean useGroup)
/*     */   {
/*  47 */     this.fieldFilterColumnHeadings = columnNames;
/*  48 */     this.useGroup = useGroup;
/*     */     
/*  50 */     if (useGroup) {
/*  51 */       ComboStdOption<Integer>[] ga = Compare.GROUPING_OPERATORS;
/*  52 */       this.nullFilterField = NULL_FILTER_FIELD_GROUP;
/*  53 */       this.groupingOptions = new IComboOption[14];
/*     */       
/*  55 */       for (int i = 0; i < ga.length; i++) {
/*  56 */         this.groupingOptions[((Integer)ga[i].key).intValue()] = ga[i];
/*     */       }
/*     */     } else {
/*  59 */       this.nullFilterField = NULL_FILTER_FIELD_STD;
/*     */     }
/*     */     
/*  62 */     if (Common.TEST_MODE) {
/*  63 */       this.fieldFilterColumnHeadings[0] = "Or";
/*  64 */       this.fieldFilterColumnHeadings[1] = "And";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int getFieldLayoutIndex()
/*     */   {
/*  73 */     if (this.useGroup) {
/*  74 */       return 0;
/*     */     }
/*  76 */     return this.layoutIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getLayoutIndex()
/*     */   {
/*  83 */     return this.layoutIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLayoutIndex(int pLayoutIndex)
/*     */   {
/*  91 */     this.layoutIndex = pLayoutIndex;
/*     */   }
/*     */   
/*     */   public RecordSel getGroupRecordSelection()
/*     */   {
/*  96 */     buildGroupRecordSelections();
/*  97 */     return this.recSel[0];
/*     */   }
/*     */   
/*     */   public RecordSel getRecordSelection(int layoutIdx)
/*     */   {
/* 102 */     buildRecordSelections();
/* 103 */     return this.recSel[layoutIdx];
/*     */   }
/*     */   
/*     */   public boolean isSelectionTests(int layoutIdx) {
/* 107 */     buildRecordSelections();
/* 108 */     return this.recSel[layoutIdx] != TRUE_SELECT;
/*     */   }
/*     */   
/*     */   public void setRecordSelection(int layoutIdx, RecordSel rSel)
/*     */   {
/* 113 */     buildRecordSelections();
/* 114 */     this.recSel[layoutIdx] = rSel;
/*     */   }
/*     */   
/*     */   private void buildRecordSelections()
/*     */   {
/* 119 */     if (this.recSel == null)
/*     */     {
/*     */ 
/*     */ 
/* 123 */       this.recSel = new RecordSel[this.layout.getRecordCount()];
/* 124 */       for (int i = 0; i < this.recSel.length; i++) {
/* 125 */         this.recSel[i] = TRUE_SELECT;
/* 126 */         RecordSelectionBuilder b = null;
/* 127 */         if ((this.filterFields != null) && (this.filterFields[i] != null)) {
/* 128 */           for (int j = 0; j < this.filterFields[i].length; j++) {
/* 129 */             FilterField ff = this.filterFields[i][j];
/* 130 */             if ((ff != null) && (this.filterFields[i][j].getFieldNumber() >= 0)) {
/* 131 */               AbstractRecordDetail rec = this.layout.getRecord(i);
/* 132 */               if (b == null) {
/* 133 */                 IFieldDetail[] fields = new IFieldDetail[rec.getFieldCount()];
/* 134 */                 for (int k = 0; k < fields.length; k++) {
/* 135 */                   fields[k] = rec.getField(k);
/*     */                 }
/* 137 */                 b = new RecordSelectionBuilder(fields);
/*     */               }
/*     */               
/* 140 */               b.add(ff.getBooleanOperator(), rec.getField(this.layout.getAdjFieldNumber(i, ff.getFieldNumber())), Compare.OPERATOR_STRING_VALUES[ff.getOperator()], ff.getValue(), !ff.getIgnoreCase().booleanValue());
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 149 */         if (b != null) {
/* 150 */           this.recSel[i] = b.build();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void buildGroupRecordSelections()
/*     */   {
/* 158 */     if (this.recSel == null)
/*     */     {
/*     */ 
/*     */ 
/* 162 */       this.recSel = new RecordSel[1];
/*     */       
/* 164 */       this.recSel[0] = TRUE_SELECT;
/* 165 */       RecordGroupSelectionBuilder b = null;
/* 166 */       if ((this.filterFields != null) && (this.filterFields[0] != null)) {
/* 167 */         for (int j = 0; j < this.filterFields[0].length; j++) {
/* 168 */           FilterField ff = this.filterFields[0][j];
/* 169 */           if ((ff != null) && (this.filterFields[0][j].getFieldNumber() >= 0)) {
/* 170 */             if (b == null) {
/* 171 */               IFieldDetail[][] fields = new FieldDetail[this.layout.getRecordCount()][];
/* 172 */               for (int i = 0; i < fields.length; i++) {
/* 173 */                 AbstractRecordDetail rec = this.layout.getRecord(i);
/* 174 */                 fields[i] = new FieldDetail[rec.getFieldCount()];
/* 175 */                 for (int k = 0; k < fields[i].length; k++) {
/* 176 */                   fields[i][k] = rec.getField(k);
/*     */                 }
/*     */               }
/* 179 */               b = new RecordGroupSelectionBuilder(fields);
/*     */             }
/*     */             
/* 182 */             int recordNumber = ff.getRecordNumber();
/* 183 */             b.add(ff.getBooleanOperator(), recordNumber, ff.getRecFieldNumber(), Compare.OPERATOR_STRING_VALUES[ff.getOperator()], ff.getGrouping(), ff.getValue(), !ff.getIgnoreCase().booleanValue());
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 194 */       if (b != null) {
/* 195 */         this.recSel[0] = b.build();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public FilterField getFilterField(int idx)
/*     */   {
/* 202 */     return getFilterField(this.layoutIndex, idx);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FilterField getFilterField(int layoutIdx, int idx)
/*     */   {
/* 215 */     if ((this.filterFields[layoutIdx] == null) || (this.filterFields[layoutIdx][idx] == null))
/*     */     {
/* 217 */       return this.nullFilterField;
/*     */     }
/*     */     
/* 220 */     return this.filterFields[layoutIdx][idx];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFilterField(int layoutIdx, int fieldIdx, FilterField value)
/*     */   {
/* 231 */     ensureArrayOk(layoutIdx, fieldIdx);
/*     */     
/* 233 */     this.filterFields[layoutIdx][fieldIdx] = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getColumnCount()
/*     */   {
/* 240 */     return this.fieldFilterColumnHeadings.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getColumnName(int columnIndex)
/*     */   {
/* 247 */     return this.fieldFilterColumnHeadings[columnIndex];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getRowCount()
/*     */   {
/* 254 */     return 20;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object getValueAt(int rowIndex, int columnIndex)
/*     */   {
/* 261 */     FilterField fld = this.nullFilterField;
/*     */     
/* 263 */     int recIndex = getFieldLayoutIndex();
/*     */     
/* 265 */     if ((this.filterFields[recIndex] != null) && (this.filterFields[recIndex][rowIndex] != null))
/*     */     {
/* 267 */       fld = this.filterFields[recIndex][rowIndex];
/*     */     }
/*     */     
/* 270 */     switch (columnIndex) {
/*     */     case 0: 
/*     */     case 1: 
/* 273 */       if (rowIndex == 0) {
/* 274 */         return "";
/*     */       }
/*     */       break;
/*     */     case 2: 
/* 278 */       if (!this.useGroup)
/*     */       {
/* 280 */         if (fld.getFieldNumber() == -1) {
/* 281 */           return null;
/*     */         }
/* 283 */         return this.layout.getAdjField(recIndex, fld.getFieldNumber()).getName();
/*     */       }
/*     */       break;
/*     */     case 4: 
/* 287 */       if (this.useGroup) {
/* 288 */         int g = fld.getGrouping();
/* 289 */         if ((this.groupingOptions != null) && (g >= 0) && (g < this.groupingOptions.length) && (this.groupingOptions[g] != null)) {
/* 290 */           return this.groupingOptions[g];
/*     */         }
/*     */       }
/*     */       break;
/*     */     }
/* 295 */     return fld.getField(columnIndex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isCellEditable(int rowIndex, int columnIndex)
/*     */   {
/* 302 */     return columnIndex >= 2;
/*     */   }
/*     */   
/*     */   public void clearRecordSelection() {
/* 306 */     this.recSel = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValueAt(Object aValue, int rowIndex, int columnIndex)
/*     */   {
/* 314 */     int recIndex = getFieldLayoutIndex();
/* 315 */     if ((aValue == null) && ((this.filterFields[recIndex] == null) || (this.filterFields[recIndex][rowIndex] == null)))
/*     */     {
/*     */ 
/* 318 */       return;
/*     */     }
/*     */     
/* 321 */     this.recSel = null;
/* 322 */     ensureArrayOk(recIndex, rowIndex);
/*     */     
/* 324 */     if (this.filterFields[recIndex][rowIndex] == null) {
/* 325 */       this.filterFields[recIndex][rowIndex] = new FilterField(this.useGroup);
/*     */     }
/*     */     
/* 328 */     if ((this.useGroup) || (columnIndex != 2)) {
/* 329 */       this.filterFields[recIndex][rowIndex].setField(columnIndex, aValue);
/*     */     } else {
/* 331 */       int res = -1;
/* 332 */       if ((aValue != null) && (!"".equals(aValue.toString())))
/*     */       {
/* 334 */         String val = aValue.toString();
/*     */         
/* 336 */         for (int i = 0; i < getFieldCount(recIndex); i++) {
/* 337 */           if (val.equalsIgnoreCase(this.layout.getAdjField(recIndex, i).getName())) {
/* 338 */             res = i;
/* 339 */             break;
/*     */           }
/*     */         }
/*     */       }
/* 343 */       this.filterFields[recIndex][rowIndex].setFieldNumber(res);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void ensureArrayOk(int layoutIdx, int fieldIndex)
/*     */   {
/* 354 */     if (this.filterFields[layoutIdx] == null) {
/* 355 */       this.filterFields[layoutIdx] = new FilterField[20];
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final int getFieldCount(int recordIdx)
/*     */   {
/* 365 */     if ((recordIdx < 0) || (recordIdx >= this.layout.getRecordCount())) {
/* 366 */       return -1;
/*     */     }
/* 368 */     return this.layout.getRecord(recordIdx).getFieldCount();
/*     */   }
/*     */   
/*     */   public abstract TableCellRenderer getTableCellRender();
/*     */   
/*     */   public abstract TableCellEditor getTableCellEditor();
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/filter/FilterFieldBaseList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */