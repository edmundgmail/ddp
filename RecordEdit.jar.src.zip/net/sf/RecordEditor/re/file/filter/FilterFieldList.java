/*     */ package net.sf.RecordEditor.re.file.filter;
/*     */ 
/*     */ import javax.swing.DefaultCellEditor;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ import javax.swing.table.TableCellEditor;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import net.sf.JRecord.Common.IFieldDetail;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.swing.ComboBoxRender;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilterFieldList
/*     */   extends FilterFieldBaseList
/*     */ {
/*  32 */   protected static final String[] FIELD_FILTER_COLUMN_HEADINGS = LangConversion.convertColHeading("Filter Selecton Field Values", new String[] { "", "", "Field", "Ignore Case", "Operator", "Value" });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  37 */   private int modelIndex = -1;
/*  38 */   DefaultComboBoxModel[] fieldModels = { new DefaultComboBoxModel(), new DefaultComboBoxModel() };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FilterFieldList(AbstractLayoutDetails recordLayout)
/*     */   {
/*  48 */     super(FIELD_FILTER_COLUMN_HEADINGS, false);
/*     */     
/*     */ 
/*  51 */     this.layout = recordLayout;
/*     */     
/*  53 */     this.filterFields = new FilterField[recordLayout.getRecordCount()][];
/*  54 */     for (int i = 0; i < this.filterFields.length; i++)
/*     */     {
/*  56 */       this.filterFields[i] = null;
/*     */     }
/*     */     
/*  59 */     assignComboOptions();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLayoutIndex(int pLayoutIndex)
/*     */   {
/*  67 */     super.setLayoutIndex(pLayoutIndex);
/*     */     
/*  69 */     assignComboOptions();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void assignComboOptions()
/*     */   {
/*  79 */     for (int j = 0; j < this.fieldModels.length; j++) {
/*  80 */       this.fieldModels[j].removeAllElements();
/*     */       
/*  82 */       this.fieldModels[j].addElement("");
/*     */       
/*  84 */       for (int i = 0; i < getFieldCount(getLayoutIndex()); i++) {
/*  85 */         this.fieldModels[j].addElement(this.layout.getAdjField(getLayoutIndex(), i).getName());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DefaultComboBoxModel getFieldModel()
/*     */   {
/*  97 */     if (this.modelIndex - 1 < this.fieldModels.length) {
/*  98 */       this.modelIndex += 1;
/*     */     }
/* 100 */     return this.fieldModels[this.modelIndex];
/*     */   }
/*     */   
/*     */   public TableCellRenderer getTableCellRender()
/*     */   {
/* 105 */     return new ComboBoxRender(this.fieldModels[0]);
/*     */   }
/*     */   
/*     */   public TableCellEditor getTableCellEditor()
/*     */   {
/* 110 */     return new DefaultCellEditor(new ComboBoxRender(this.fieldModels[1]));
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/filter/FilterFieldList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */