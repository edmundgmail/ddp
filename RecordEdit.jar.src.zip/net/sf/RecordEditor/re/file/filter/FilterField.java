/*     */ package net.sf.RecordEditor.re.file.filter;
/*     */ 
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.swing.Combo.ComboStdOption;
/*     */ import net.sf.RecordEditor.utils.swing.Combo.IComboOption;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FilterField
/*     */ {
/*     */   public static final int NULL_FIELD = -1;
/*     */   public static final int FLD_OR_VAL = 0;
/*     */   public static final int FLD_AND_VAL = 1;
/*     */   public static final int FLD_FIELD_NUMBER = 2;
/*     */   public static final int FLD_CASE_SENSITIVE = 3;
/*     */   public static final int FLD_OPERATOR = 4;
/*     */   public static final int FLD_VALUE = 5;
/*     */   public static final int FLD_GROUPING = 4;
/*     */   public static final int FLD_GROUP_OPERATOR = 5;
/*     */   public static final int FLD_GROUP_VALUE = 6;
/*  46 */   public static final int[] STANDARD_FIELDS = { 0, 1, 2, 3, 5, 6 };
/*     */   
/*     */ 
/*  49 */   public static final int[] GROUPING_FIELDS = { 0, 1, 2, 3, 4, 5, 6 };
/*     */   
/*     */ 
/*     */ 
/*  53 */   private final String[] OR_LIST = { LangConversion.convert(2, "Or"), "" };
/*  54 */   private final String[] AND_LIST = { "", LangConversion.convert(2, "And") };
/*     */   
/*  56 */   private int booleanOperator = 1;
/*  57 */   private int fieldNumber = -1;
/*  58 */   private Boolean ignoreCase = Boolean.TRUE;
/*  59 */   private int grouping = 1;
/*  60 */   private int operator = 0;
/*  61 */   private String value = "";
/*     */   
/*     */   public final int[] fieldsUsed;
/*     */   
/*     */   public static FilterField newStandardFilterFields()
/*     */   {
/*  67 */     return new FilterField(false);
/*     */   }
/*     */   
/*     */   public static FilterField newGroupFilterFields() {
/*  71 */     return new FilterField(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FilterField(boolean useGroup)
/*     */   {
/*  83 */     if (useGroup) {
/*  84 */       this.fieldsUsed = GROUPING_FIELDS;
/*     */     } else {
/*  86 */       this.fieldsUsed = STANDARD_FIELDS;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setField(int fieldIndex, Object newValue)
/*     */   {
/* 101 */     if ((newValue instanceof IComboOption)) {
/* 102 */       newValue = ((ComboStdOption)newValue).key;
/*     */     }
/* 104 */     if ((fieldIndex >= 0) && (fieldIndex < this.fieldsUsed.length)) {
/* 105 */       int idx = this.fieldsUsed[fieldIndex];
/* 106 */       switch (idx) {
/* 107 */       case 0:  this.booleanOperator = searchArray(newValue, this.OR_LIST); break;
/* 108 */       case 1:  this.booleanOperator = searchArray(newValue, this.AND_LIST); break;
/* 109 */       case 2:  this.fieldNumber = (asInt(newValue) - 1); break;
/* 110 */       case 3:  this.ignoreCase = ((Boolean)newValue); break;
/* 111 */       case 4:  this.grouping = asInt(newValue); break;
/*     */       case 5: 
/* 113 */         this.operator = Compare.getForeignOperator(newValue.toString(), 0);
/* 114 */         break;
/*     */       case 6: 
/* 116 */         this.value = newValue.toString();
/* 117 */         break;
/*     */       }
/*     */       
/*     */     }
/*     */   }
/*     */   
/*     */   private int asInt(Object newValue)
/*     */   {
/* 125 */     if ((newValue instanceof Integer)) {
/* 126 */       return ((Integer)newValue).intValue();
/*     */     }
/* 128 */     return Integer.parseInt(newValue.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getField(int fieldIndex)
/*     */   {
/* 142 */     if ((fieldIndex >= 0) && (fieldIndex < this.fieldsUsed.length)) {
/* 143 */       int idx = this.fieldsUsed[fieldIndex];
/*     */       
/* 145 */       switch (idx) {
/* 146 */       case 0:  return this.OR_LIST[this.booleanOperator];
/* 147 */       case 1:  return this.AND_LIST[this.booleanOperator];
/* 148 */       case 2:  return Integer.valueOf(this.fieldNumber + 1);
/* 149 */       case 3:  return this.ignoreCase;
/* 150 */       case 4:  return Integer.valueOf(this.grouping);
/* 151 */       case 5:  return Compare.OPERATOR_STRING_FOREIGN_VALUES[this.operator];
/* 152 */       case 6:  return this.value;
/*     */       }
/*     */       
/*     */     }
/* 156 */     return null;
/*     */   }
/*     */   
/*     */   private int searchArray(Object val, String[] array)
/*     */   {
/* 161 */     if ((val instanceof Number)) {
/* 162 */       return ((Number)val).intValue();
/*     */     }
/*     */     
/* 165 */     String v = null;
/* 166 */     if (val != null) {
/* 167 */       v = val.toString();
/*     */     }
/* 169 */     for (int i = 0; i < array.length; i++) {
/* 170 */       if (array[i].equalsIgnoreCase(v)) {
/* 171 */         return i;
/*     */       }
/*     */     }
/* 174 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Boolean getIgnoreCase()
/*     */   {
/* 184 */     return this.ignoreCase;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFieldNumber()
/*     */   {
/* 194 */     return this.fieldNumber;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRecordNumber()
/*     */   {
/* 204 */     return (this.fieldNumber - 1) / Compare.RECORD_MULTIPLE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRecFieldNumber()
/*     */   {
/* 212 */     return (this.fieldNumber - 1) % Compare.RECORD_MULTIPLE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFieldNumber(int val)
/*     */   {
/* 221 */     this.fieldNumber = val;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFieldNumber(int recNo, int fldNo)
/*     */   {
/* 230 */     this.fieldNumber = (Compare.RECORD_MULTIPLE * recNo + fldNo + 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getOperator()
/*     */   {
/* 241 */     return this.operator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getValue()
/*     */   {
/* 250 */     return this.value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setOperator(int operator)
/*     */   {
/* 259 */     this.operator = operator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setValue(String value)
/*     */   {
/* 268 */     this.value = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getBooleanOperator()
/*     */   {
/* 277 */     return this.booleanOperator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBooleanOperator(int booleanOperator)
/*     */   {
/* 286 */     this.booleanOperator = booleanOperator;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getGrouping()
/*     */   {
/* 295 */     return this.grouping;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setGrouping(int grouping)
/*     */   {
/* 304 */     this.grouping = grouping;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/filter/FilterField.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */