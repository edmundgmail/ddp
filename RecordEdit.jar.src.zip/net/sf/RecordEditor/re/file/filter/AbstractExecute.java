package net.sf.RecordEditor.re.file.filter;

import net.sf.RecordEditor.re.display.AbstractFileDisplay;

public abstract interface AbstractExecute<details>
{
  public abstract AbstractFileDisplay execute(details paramdetails);
  
  public abstract void executeDialog(details paramdetails);
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/filter/AbstractExecute.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */