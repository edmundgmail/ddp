/*     */ package net.sf.RecordEditor.re.file.filter;
/*     */ 
/*     */ import java.awt.Container;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.io.File;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.SwingUtilities;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExecuteSavedFile<details>
/*     */   extends ReFrame
/*     */   implements ActionListener
/*     */ {
/*  24 */   private JFileChooser fileChooser = new JFileChooser();
/*     */   
/*  26 */   private JButton runBtn = SwingUtils.newButton("Run");
/*  27 */   private JButton runDialogBtn = SwingUtils.newButton("Run Dialog");
/*     */   
/*     */ 
/*     */   private final ExecuteSavedFileBatch<details> execSaveBatch;
/*     */   
/*     */ 
/*  33 */   public final KeyAdapter keyListner = new KeyAdapter()
/*     */   {
/*     */ 
/*     */     public final void keyReleased(KeyEvent event)
/*     */     {
/*     */ 
/*  39 */       if (event.getKeyCode() == 10)
/*     */       {
/*  41 */         SwingUtils.clickOpenBtn(ExecuteSavedFile.this.fileChooser, false);
/*     */         
/*  43 */         ExecuteSavedFile.this.fileChooser.approveSelection();
/*     */         
/*     */ 
/*  46 */         ExecuteSavedFile.this.execAction(true);
/*     */       }
/*  48 */       else if (event.getKeyCode() == 27) {
/*  49 */         ExecuteSavedFile.this.doDefaultCloseAction();
/*     */       }
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExecuteSavedFile(String docName, String formName, Object data, String dir, AbstractExecute<details> executeAction, Class detailsClass)
/*     */   {
/*  66 */     super(docName, formName, data);
/*  67 */     BasePanel pnl = new BaseHelpPanel();
/*     */     
/*  69 */     this.execSaveBatch = new ExecuteSavedFileBatch(detailsClass, executeAction);
/*     */     
/*  71 */     this.fileChooser.setDialogType(1);
/*     */     
/*  73 */     if (dir != null) {
/*  74 */       if ((dir.endsWith("/")) || (dir.endsWith("\\"))) {
/*  75 */         dir = dir + "*";
/*     */       }
/*  77 */       this.fileChooser.setSelectedFile(new File(dir));
/*     */     }
/*     */     
/*     */ 
/*  81 */     this.fileChooser.setControlButtonsAreShown(false);
/*     */     
/*     */ 
/*  84 */     pnl.addComponentRE(1, 5, -1.0D, BasePanel.GAP1, 2, 2, this.fileChooser);
/*     */     
/*     */ 
/*     */ 
/*  88 */     SwingUtils.addKeyListnerToContainer(pnl, this.keyListner);
/*     */     
/*  90 */     pnl.setGapRE(BasePanel.GAP3);
/*  91 */     pnl.addLineRE("", null, this.runDialogBtn);
/*  92 */     pnl.setGapRE(BasePanel.GAP1);
/*  93 */     pnl.addLineRE("", null, this.runBtn);
/*  94 */     pnl.setGapRE(BasePanel.GAP2);
/*     */     
/*  96 */     getContentPane().add(pnl);
/*  97 */     pack();
/*     */     
/*  99 */     this.runBtn.addActionListener(this);
/* 100 */     this.runDialogBtn.addActionListener(this);
/*     */     
/* 102 */     setVisible(true);
/*     */     
/* 104 */     super.setToMaximum(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void actionPerformed(ActionEvent e)
/*     */   {
/*     */     try
/*     */     {
/* 122 */       SwingUtils.clickOpenBtn(this.fileChooser, true);
/* 123 */       this.fileChooser.approveSelection();
/*     */     }
/*     */     catch (Exception ex) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 132 */     execAction(e.getSource() == this.runBtn);
/*     */   }
/*     */   
/*     */   public void execAction(final boolean run)
/*     */   {
/* 137 */     if ((run) && (SwingUtilities.isEventDispatchThread())) {
/* 138 */       Common.runOptionalyInBackground(new Runnable() {
/*     */         public void run() {
/* 140 */           ExecuteSavedFile.this.executeAction(run);
/*     */         }
/*     */       });
/*     */     } else
/* 144 */       executeAction(run);
/*     */   }
/*     */   
/*     */   public void executeAction(boolean run) {
/*     */     try {
/* 149 */       this.execSaveBatch.execActionRaw(run, this.fileChooser.getSelectedFile().getPath());
/*     */       
/* 151 */       setClosed(true);
/*     */     } catch (NoClassDefFoundError e) {
/* 153 */       e.printStackTrace();
/* 154 */       Common.logMsg("Jibx Call Failed: Class not loaded", null);
/*     */     } catch (Exception ex) {
/* 156 */       ex.printStackTrace();
/* 157 */       Common.logMsg("Execute Error", ex);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/filter/ExecuteSavedFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */