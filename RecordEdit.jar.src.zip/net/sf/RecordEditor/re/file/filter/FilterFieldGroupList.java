/*    */ package net.sf.RecordEditor.re.file.filter;
/*    */ 
/*    */ import javax.swing.table.TableCellEditor;
/*    */ import javax.swing.table.TableCellRenderer;
/*    */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*    */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*    */ import net.sf.JRecord.Details.AbstractRecordDetail.FieldDetails;
/*    */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*    */ import net.sf.RecordEditor.utils.swing.treeCombo.TreeComboItem;
/*    */ import net.sf.RecordEditor.utils.swing.treeCombo.TreeComboRendor;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FilterFieldGroupList
/*    */   extends FilterFieldBaseList
/*    */ {
/* 33 */   protected static final String[] FIELD_FILTER_COLUMN_HEADINGS = LangConversion.convertColHeading("Filter Selecton Field Values", new String[] { "", "", "Field", "Ignore Case", "Group by function", "Operator", "Value" });
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private TreeComboItem[] recordFields;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public FilterFieldGroupList(AbstractLayoutDetails recordLayout)
/*    */   {
/* 47 */     super(FIELD_FILTER_COLUMN_HEADINGS, true);
/*    */     
/*    */ 
/* 50 */     this.layout = recordLayout;
/*    */     
/* 52 */     this.filterFields = new FilterField[recordLayout.getRecordCount()][];
/* 53 */     for (int i = 0; i < this.filterFields.length; i++)
/*    */     {
/* 55 */       this.filterFields[i] = null;
/*    */     }
/*    */     
/* 58 */     this.recordFields = new TreeComboItem[recordLayout.getRecordCount()];
/*    */     
/* 60 */     for (i = 0; i < this.recordFields.length; i++) {
/* 61 */       this.recordFields[i] = getRecordFields(i, recordLayout.getRecord(i));
/*    */     }
/*    */   }
/*    */   
/*    */   private TreeComboItem getRecordFields(int idx, AbstractRecordDetail rec)
/*    */   {
/* 67 */     TreeComboItem[] children = new TreeComboItem[rec.getFieldCount()];
/* 68 */     int pref = idx * Compare.RECORD_MULTIPLE + 2;
/* 69 */     for (int i = 0; i < children.length; i++) {
/* 70 */       children[i] = new TreeComboItem(Integer.valueOf(pref + i), rec.getField(i).getName(), "");
/*    */     }
/*    */     
/* 73 */     return new TreeComboItem(Integer.valueOf(pref - 1), rec.getRecordName(), "", children);
/*    */   }
/*    */   
/*    */ 
/*    */   public TableCellRenderer getTableCellRender()
/*    */   {
/* 79 */     return new TreeComboRendor(this.recordFields);
/*    */   }
/*    */   
/*    */   public TableCellEditor getTableCellEditor()
/*    */   {
/* 84 */     return new TreeComboRendor(this.recordFields);
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/filter/FilterFieldGroupList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */