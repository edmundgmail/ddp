package net.sf.RecordEditor.re.file;

public abstract interface CheckStore
{
  public abstract void checkDatasStore(int paramInt);
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/CheckStore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */