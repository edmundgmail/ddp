package net.sf.RecordEditor.re.file;

public abstract interface AbstractTreeFrame<LNode extends AbstractLineNode>
{
  public abstract LNode getRoot();
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/AbstractTreeFrame.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */