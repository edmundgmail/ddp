/*     */ package net.sf.RecordEditor.re.file;
/*     */ 
/*     */ import java.awt.Container;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JProgressBar;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.SwingUtilities;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMsg;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.swing.common.IProgressDisplay;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProgressDialog
/*     */   implements IProgressDisplay
/*     */ {
/*     */   private static final long INTERVAL = 750000000L;
/*  26 */   private JDialog frame = null;
/*     */   
/*  28 */   private JTextArea area = new JTextArea();
/*     */   
/*     */   private JProgressBar progressBar;
/*     */   private final String frameName;
/*     */   private ReMsg message;
/*  33 */   private int max = 100; private int checkCountAt; private int countSinceCheck = 0;
/*  34 */   private long lastTime = System.nanoTime() - 675000000L;
/*  35 */   private boolean cont = true;
/*     */   
/*     */   public ProgressDialog(String heading, ReMsg msg, int total, int checkCountAt) {
/*  38 */     this.frameName = heading;
/*  39 */     this.message = msg;
/*  40 */     this.max = total;
/*  41 */     this.checkCountAt = checkCountAt;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean updateProgress(final int count, final int other)
/*     */   {
/*  57 */     if (this.countSinceCheck++ > this.checkCountAt) {
/*  58 */       long time = System.nanoTime();
/*  59 */       this.countSinceCheck = 0;
/*  60 */       if (time - this.lastTime > 750000000L)
/*     */       {
/*  62 */         this.lastTime = time;
/*     */         
/*     */ 
/*  65 */         SwingUtilities.invokeLater(new Runnable() {
/*     */           public void run() {
/*  67 */             ProgressDialog.this.area.setText(ProgressDialog.this.message.get(new Object[] { Integer.valueOf(count), Integer.valueOf(ProgressDialog.this.max), Integer.valueOf(other) }) + "             ");
/*  68 */             ProgressDialog.this.init();
/*     */             
/*  70 */             ProgressDialog.this.progressBar.setValue(count);
/*     */           }
/*     */         });
/*     */       }
/*     */     }
/*  75 */     return this.cont;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void done()
/*     */   {
/*  83 */     if ((this.frame != null) && (this.frame.isVisible())) {
/*  84 */       this.frame.setVisible(false);
/*     */     }
/*     */   }
/*     */   
/*     */   private void init() {
/*  89 */     if (this.frame == null) {
/*  90 */       synchronized (this.area) {
/*  91 */         if (this.frame == null) {
/*  92 */           this.frame = new JDialog((JFrame)null, this.frameName);
/*  93 */           BasePanel pnl = new BasePanel();
/*     */           
/*  95 */           this.frame.setDefaultCloseOperation(2);
/*     */           
/*  97 */           this.progressBar = new JProgressBar(0, this.max);
/*  98 */           this.progressBar.setValue(0);
/*     */           
/*     */ 
/* 101 */           pnl.addComponentRE(1, 5, -2.0D, BasePanel.GAP1, 2, 2, this.progressBar);
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 107 */           this.area.setFont(SwingUtils.getMonoSpacedFont());
/* 108 */           pnl.addComponentRE(1, 5, -2.0D, BasePanel.GAP1, 2, 2, this.area);
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 113 */           this.frame.getContentPane().add(pnl);
/* 114 */           this.frame.pack();
/*     */           
/*     */ 
/* 117 */           this.frame.setVisible(true);
/* 118 */           this.frame.addWindowListener(new WindowAdapter()
/*     */           {
/*     */             public void windowClosed(WindowEvent e)
/*     */             {
/* 122 */               ProgressDialog.this.cont = false;
/* 123 */               super.windowClosed(e);
/*     */             }
/*     */           });
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/ProgressDialog.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */