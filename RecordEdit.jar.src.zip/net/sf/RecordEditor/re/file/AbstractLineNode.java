package net.sf.RecordEditor.re.file;

import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreeNode;
import net.sf.JRecord.Details.AbstractLayoutDetails;
import net.sf.JRecord.Details.AbstractLine;

public abstract interface AbstractLineNode
  extends MutableTreeNode
{
  public abstract void add(MutableTreeNode paramMutableTreeNode);
  
  public abstract AbstractLayoutDetails getLayout();
  
  public abstract AbstractLine getLine();
  
  public abstract FileView getView();
  
  public abstract void setSummaryLine(AbstractLine paramAbstractLine, String paramString);
  
  public abstract String getLineType();
  
  public abstract TreeNode[] getPath();
  
  public abstract int getDefaultLineNumber();
  
  public abstract int getLineNumber();
  
  public abstract String getSortValue();
  
  public abstract void removeFromParent();
  
  public abstract <X extends AbstractLineNode> X insert(AbstractLine paramAbstractLine, int paramInt1, int paramInt2);
  
  public abstract void removeAllChildren();
  
  public abstract AbstractLineNode insertNode(int paramInt, String paramString, FileView paramFileView, AbstractLine paramAbstractLine);
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/AbstractLineNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */