package net.sf.RecordEditor.re.file;

public abstract interface DocumentUpdateListner
{
  public abstract void fireUpdate(int paramInt1, int paramInt2, int paramInt3);
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/DocumentUpdateListner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */