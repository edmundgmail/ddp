/*     */ package net.sf.RecordEditor.re.file;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FieldMapping
/*     */ {
/*   9 */   private int[][] columnMapping = (int[][])null;
/*     */   
/*     */ 
/*     */   private int[] colLengths;
/*     */   
/*     */ 
/*     */   private int[] totalColumnLengths;
/*     */   
/*     */ 
/*     */   public FieldMapping(int[] columnLengths)
/*     */   {
/*  20 */     this.colLengths = columnLengths;
/*  21 */     this.totalColumnLengths = ((int[])columnLengths.clone());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FieldMapping(int[][] remapColumns, int[] numCols)
/*     */   {
/*  30 */     this.columnMapping = remapColumns;
/*  31 */     this.totalColumnLengths = numCols;
/*     */     
/*  33 */     if (this.columnMapping == null) {
/*  34 */       this.colLengths = new int[0];
/*     */     } else {
/*  36 */       this.colLengths = new int[remapColumns.length];
/*  37 */       for (int i = 0; i < this.colLengths.length; i++) {
/*  38 */         this.colLengths[i] = numCols[i];
/*  39 */         if (this.columnMapping[i] != null) {
/*  40 */           this.colLengths[i] = this.columnMapping[i].length;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void resetMapping(int[] columnLengths) {
/*  47 */     this.colLengths = columnLengths;
/*  48 */     this.columnMapping = ((int[][])null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColumnCount(int recordIdx, int defaultColumnCount)
/*     */   {
/*  59 */     if ((this.colLengths != null) && (recordIdx < this.colLengths.length)) {
/*  60 */       defaultColumnCount = this.colLengths[recordIdx];
/*     */     }
/*  62 */     return defaultColumnCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getRealColumn(int recordIdx, int inRow)
/*     */   {
/*  71 */     int ret = inRow;
/*     */     
/*  73 */     if ((inRow >= 0) && (this.columnMapping != null) && (this.columnMapping[recordIdx] != null) && (inRow < this.columnMapping[recordIdx].length))
/*     */     {
/*     */ 
/*     */ 
/*  77 */       ret = this.columnMapping[recordIdx][inRow];
/*     */     }
/*     */     
/*  80 */     return ret;
/*     */   }
/*     */   
/*     */   public final int getAdjColumn(int recordIdx, int inRow) {
/*  84 */     int ret = inRow;
/*     */     
/*  86 */     if ((inRow >= 0) && (this.columnMapping != null) && (this.columnMapping[recordIdx] != null) && (this.columnMapping[recordIdx].length > 0))
/*     */     {
/*     */ 
/*     */ 
/*  90 */       ret = 0;
/*  91 */       while ((ret < this.columnMapping[recordIdx].length) && (this.columnMapping[recordIdx][ret] < inRow)) {
/*  92 */         ret++;
/*     */       }
/*     */     }
/*     */     
/*  96 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void hideColumn(int recordIdx, int row)
/*     */   {
/* 106 */     int[] cols = getRemapCols(recordIdx);
/* 107 */     boolean found = false;
/*     */     
/* 109 */     for (int i = 0; i < this.colLengths[recordIdx]; i++) {
/* 110 */       if (cols[i] == row) {
/* 111 */         found = true;
/* 112 */         this.colLengths[recordIdx] -= 1;
/*     */       }
/* 114 */       if ((found) && (i < cols.length - 1)) {
/* 115 */         cols[i] = cols[(i + 1)];
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void showColumn(int recordIdx, int row)
/*     */   {
/* 126 */     int[] cols = getRemapCols(recordIdx);
/* 127 */     boolean searching = true;
/*     */     
/* 129 */     for (int i = 0; (cols[i] <= row) && (i < this.colLengths[recordIdx]); i++) {
/* 130 */       if (cols[i] == row) {
/* 131 */         searching = false;
/* 132 */         break;
/*     */       }
/*     */     }
/*     */     
/* 136 */     if (searching) {
/* 137 */       cols[this.colLengths[recordIdx]] = row;
/*     */       
/* 139 */       for (int i = this.colLengths[recordIdx] - 1; (i >= 0) && (cols[i] > row); i--) {
/* 140 */         cols[(i + 1)] = cols[i];
/* 141 */         cols[i] = row;
/*     */       }
/* 143 */       this.colLengths[recordIdx] += 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private int[] getRemapCols(int idx)
/*     */   {
/* 150 */     if (this.columnMapping == null) {
/* 151 */       this.columnMapping = new int[this.colLengths.length][];
/*     */     }
/*     */     
/* 154 */     if (this.columnMapping[idx] == null) {
/* 155 */       this.columnMapping[idx] = new int[this.colLengths[idx]];
/*     */       
/* 157 */       for (int i = 0; i < this.colLengths[idx]; i++) {
/* 158 */         this.columnMapping[idx][i] = i;
/*     */       }
/*     */     }
/*     */     
/* 162 */     return this.columnMapping[idx];
/*     */   }
/*     */   
/*     */   public boolean[] getFieldVisibility(int recordIdx) {
/* 166 */     boolean[] ret = null;
/*     */     
/* 168 */     if ((this.colLengths != null) && (recordIdx < this.colLengths.length)) {
/* 169 */       int size = this.colLengths[recordIdx];
/* 170 */       if ((this.totalColumnLengths != null) && (recordIdx < this.totalColumnLengths.length)) {
/* 171 */         size = this.totalColumnLengths[recordIdx];
/*     */       }
/*     */       
/* 174 */       if ((this.columnMapping == null) || (this.columnMapping[recordIdx] == null)) {
/* 175 */         ret = initArray(size, true);
/*     */       } else {
/* 177 */         if (this.columnMapping[recordIdx].length > size) {
/* 178 */           size = this.columnMapping[recordIdx].length;
/*     */         }
/* 180 */         ret = initArray(size, false);
/* 181 */         for (int i = 0; i < this.colLengths[recordIdx]; i++) {
/* 182 */           ret[this.columnMapping[recordIdx][i]] = true;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 187 */     return ret;
/*     */   }
/*     */   
/*     */   private boolean[] initArray(int size, boolean value) {
/* 191 */     boolean[] array = new boolean[size];
/* 192 */     for (int i = 0; i < size; i++) {
/* 193 */       array[i] = value;
/*     */     }
/* 195 */     return array;
/*     */   }
/*     */   
/*     */   public void setFieldVisibilty(int recordIndex, boolean[] fieldVisible) {
/* 199 */     if (fieldVisible == null) return;
/* 200 */     boolean allFields = true;
/*     */     
/* 202 */     for (int i = 0; i < fieldVisible.length; i++) {
/* 203 */       if (fieldVisible[i] == 0) {
/* 204 */         allFields = false;
/* 205 */         break;
/*     */       }
/*     */     }
/*     */     
/* 209 */     if (allFields) {
/* 210 */       if ((this.columnMapping != null) && (this.columnMapping[recordIndex] != null)) {
/* 211 */         this.columnMapping[recordIndex] = null;
/* 212 */         this.colLengths[recordIndex] = fieldVisible.length;
/*     */       }
/*     */     } else {
/* 215 */       int count = 0;
/* 216 */       if (this.columnMapping == null) {
/* 217 */         this.columnMapping = new int[this.colLengths.length][];
/*     */       }
/*     */       
/* 220 */       if (this.columnMapping[recordIndex] == null) {
/* 221 */         this.columnMapping[recordIndex] = new int[Math.max(fieldVisible.length, this.colLengths[recordIndex])];
/*     */       }
/*     */       
/* 224 */       for (int i = 0; i < fieldVisible.length; i++) {
/* 225 */         if (fieldVisible[i] != 0) {
/* 226 */           this.columnMapping[recordIndex][(count++)] = i;
/*     */         }
/*     */       }
/* 229 */       this.colLengths[recordIndex] = count;
/*     */     }
/*     */   }
/*     */   
/*     */   public static int getAdjColumn(FieldMapping mapping, int recordIdx, int inRow) {
/* 234 */     if (mapping != null) {
/* 235 */       return mapping.getAdjColumn(recordIdx, inRow);
/*     */     }
/* 237 */     return inRow;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/FieldMapping.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */