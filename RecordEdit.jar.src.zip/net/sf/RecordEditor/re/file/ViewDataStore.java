/*    */ package net.sf.RecordEditor.re.file;
/*    */ 
/*    */ import javax.swing.JFrame;
/*    */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*    */ import net.sf.JRecord.Details.AbstractLine;
/*    */ import net.sf.RecordEditor.utils.fileStorage.DataStoreLarge;
/*    */ import net.sf.RecordEditor.utils.fileStorage.DataStoreLargeView;
/*    */ import net.sf.RecordEditor.utils.fileStorage.DataStoreStd;
/*    */ import net.sf.RecordEditor.utils.fileStorage.IDataStore;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ViewDataStore
/*    */ {
/*    */   private final IDataStore<AbstractLine> selectedLines;
/* 16 */   private boolean cont = true;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ViewDataStore(AbstractLayoutDetails layout, boolean standardDataStore, JFrame currentFrame, IDataStore<AbstractLine> parentStore)
/*    */   {
/* 25 */     if ((parentStore instanceof DataStoreLarge)) {
/* 26 */       this.selectedLines = new DataStoreLargeView(parentStore, new int[0]);
/*    */     } else {
/* 28 */       this.selectedLines = DataStoreStd.newStore(layout);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public final void add(AbstractLine line)
/*    */   {
/* 43 */     this.selectedLines.add(line);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int size()
/*    */   {
/* 70 */     return this.selectedLines.size();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public IDataStore<AbstractLine> getSelectedLines()
/*    */   {
/* 77 */     return this.selectedLines;
/*    */   }
/*    */   
/*    */   public final boolean continueProcessing() {
/* 81 */     return this.cont;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/ViewDataStore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */