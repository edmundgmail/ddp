/*    */ package net.sf.RecordEditor.re.file;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.swing.SwingWorker;
/*    */ import net.sf.JRecord.Common.RecordException;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileWriterBackground
/*    */   extends SwingWorker<Void, Void>
/*    */ {
/*    */   FileWriter writer;
/*    */   
/*    */   public FileWriterBackground(FileWriter pWriter)
/*    */     throws RecordException
/*    */   {
/* 18 */     this.writer = pWriter;
/*    */   }
/*    */   
/*    */   protected Void doInBackground() throws IOException
/*    */   {
/*    */     try {
/* 24 */       doWrite();
/*    */     } catch (IOException e) {
/* 26 */       e.printStackTrace();
/* 27 */       Common.logMsg("Write Failed: " + e, e);
/* 28 */       throw e;
/*    */     } catch (RuntimeException e) {
/* 30 */       e.printStackTrace();
/* 31 */       Common.logMsg("Write Failed: " + e, e);
/* 32 */       throw e;
/*    */     } catch (Exception e) {
/* 34 */       e.printStackTrace();
/* 35 */       Common.logMsg("Write Failed: " + e, e);
/* 36 */       throw new RuntimeException(e);
/*    */     }
/*    */     
/* 39 */     return null;
/*    */   }
/*    */   
/*    */   public void doWrite() throws IOException {
/* 43 */     this.writer.doWrite();
/*    */     
/* 45 */     firePropertyChange("Finished", null, null);
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/FileWriterBackground.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */