/*     */ package net.sf.RecordEditor.re.file;
/*     */ 
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FilePosition
/*     */ {
/*     */   public static final int END_OF_COLUMN = Integer.MAX_VALUE;
/*     */   public static final int ALL_FIELDS_IDX = -1;
/*     */   public int lineCount;
/*     */   public int row;
/*     */   public int col;
/*     */   public int recordId;
/*     */   private int fieldId;
/*  34 */   public boolean found = false;
/*     */   public int currentFieldNumber;
/*  36 */   public int layoutIdxUsed = -121;
/*     */   
/*  38 */   public AbstractLine currentLine = null;
/*     */   
/*     */   private boolean forward;
/*     */   
/*     */   private int inc;
/*     */   private int initCol;
/*  44 */   private boolean readPending = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FilePosition(int theRow, int theCol, int theRecord, int theField, boolean forwardDirection, int numberOfLines)
/*     */   {
/*  60 */     setAll(theRow, theCol, theRecord, theField, forwardDirection, numberOfLines);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAll(int theRow, int theCol, int theRecord, int theField, boolean forwardDirection, int numberOfLines)
/*     */   {
/*  76 */     setForward(forwardDirection);
/*  77 */     setFieldId(theField);
/*  78 */     this.row = theRow;
/*  79 */     this.col = theCol;
/*  80 */     this.recordId = theRecord;
/*  81 */     this.lineCount = numberOfLines;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void adjustPosition(int length, int operator)
/*     */   {
/*  94 */     this.readPending = false;
/*  95 */     if ((this.col < 0) || (this.col == Integer.MAX_VALUE) || (operator == 1)) {
/*  96 */       adjustPosField();
/*  97 */     } else if (this.forward) {
/*  98 */       this.col += length;
/*     */     } else {
/* 100 */       this.col -= 1;
/* 101 */       if (this.col <= 0) {
/* 102 */         adjustPosField();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void adjustPosField()
/*     */   {
/* 116 */     if (this.fieldId == -102) {
/* 117 */       this.currentFieldNumber += this.inc;
/* 118 */       if (this.currentFieldNumber < 0) {
/* 119 */         this.row += this.inc;
/* 120 */         this.readPending = true;
/*     */       }
/*     */     } else {
/* 123 */       this.row += this.inc;
/* 124 */       this.readPending = true;
/*     */     }
/* 126 */     this.col = this.initCol;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getFieldId()
/*     */   {
/* 133 */     return this.fieldId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setFieldId(int newFieldId)
/*     */   {
/* 140 */     int nFieldId = newFieldId;
/*     */     
/* 142 */     if (nFieldId == -1) {
/* 143 */       nFieldId = -102;
/* 144 */     } else if (nFieldId < -1) {
/* 145 */       nFieldId = -101;
/* 146 */       this.currentFieldNumber = -101;
/*     */     }
/*     */     
/* 149 */     if (this.fieldId != nFieldId) {
/* 150 */       this.col = this.initCol;
/* 151 */       this.currentFieldNumber = newFieldId;
/*     */     }
/* 153 */     this.fieldId = nFieldId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setLineCount(int lineCount)
/*     */   {
/* 160 */     this.lineCount = lineCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isForward()
/*     */   {
/* 167 */     return this.forward;
/*     */   }
/*     */   
/*     */   public void gotoStart() {
/* 171 */     if (this.forward) {
/* 172 */       this.row = -1;
/*     */     } else {
/* 174 */       this.row = this.lineCount;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void setForward(boolean pForward)
/*     */   {
/* 181 */     this.forward = pForward;
/*     */     
/* 183 */     this.inc = -1;
/* 184 */     this.initCol = Integer.MAX_VALUE;
/* 185 */     if (pForward) {
/* 186 */       this.inc = 1;
/* 187 */       this.initCol = 0;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void nextRow()
/*     */   {
/* 195 */     this.row += this.inc;
/* 196 */     this.col = this.initCol;
/*     */   }
/*     */   
/*     */   public void resetCol() {
/* 200 */     this.col = this.initCol;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void nextField()
/*     */   {
/* 207 */     this.currentFieldNumber += this.inc;
/*     */     
/* 209 */     this.col = this.initCol;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isValidFieldNum(int maxField)
/*     */   {
/* 221 */     return (this.currentFieldNumber >= 0) && (this.currentFieldNumber < maxField);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isReadPending()
/*     */   {
/* 229 */     return this.readPending;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void setReadPending(boolean readPending)
/*     */   {
/* 236 */     this.readPending = readPending;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/FilePosition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */