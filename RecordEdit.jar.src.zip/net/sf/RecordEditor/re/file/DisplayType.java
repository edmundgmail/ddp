/*    */ package net.sf.RecordEditor.re.file;
/*    */ 
/*    */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*    */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*    */ 
/*    */ public class DisplayType
/*    */ {
/*    */   public static final int NORMAL = 0;
/*    */   public static final int PREFFERED = 1;
/*    */   public static final int FULL_LINE = 2;
/*    */   public static final int HEX_LINE = 3;
/*    */   private static final int FULL_LINE_INC = 1;
/*    */   
/*    */   public static int displayType(AbstractLayoutDetails layout, int idx)
/*    */   {
/* 16 */     int ret = 0;
/* 17 */     if (idx == layout.getRecordCount()) {
/* 18 */       ret = 1;
/* 19 */     } else if (idx == layout.getRecordCount() + 1) {
/* 20 */       ret = 2;
/* 21 */     } else if (idx > layout.getRecordCount() + 1) {
/* 22 */       ret = 3;
/*    */     }
/*    */     
/* 25 */     return ret;
/*    */   }
/*    */   
/*    */   public static int displayTypePrint(AbstractLayoutDetails layout, int idx) {
/* 29 */     int ret = 0;
/* 30 */     if ((idx == layout.getRecordCount()) || (isTreeStructure(layout))) {
/* 31 */       ret = 1;
/* 32 */     } else if (idx == layout.getRecordCount() + 1) {
/* 33 */       ret = 2;
/* 34 */     } else if (idx > layout.getRecordCount() + 1) {
/* 35 */       ret = 3;
/*    */     }
/*    */     
/* 38 */     return ret;
/*    */   }
/*    */   
/* 41 */   public static int getFieldCount(AbstractLayoutDetails layout, int idx) { int ret = layout.getRecord(idx).getFieldCount();
/* 42 */     if (isTreeStructure(layout)) {
/* 43 */       ret = getMaxFields(layout);
/*    */     }
/*    */     
/* 46 */     return ret;
/*    */   }
/*    */   
/*    */   public static boolean isTreeStructure(AbstractLayoutDetails layout) {
/* 50 */     return (layout.isXml()) || (layout.hasChildren());
/*    */   }
/*    */   
/*    */   public static int getMaxFields(AbstractLayoutDetails layout) {
/* 54 */     return layout.getRecord(getRecordMaxFields(layout)).getFieldCount();
/*    */   }
/*    */   
/*    */   public static int getRecordMaxFields(AbstractLayoutDetails layout) {
/* 58 */     int idx = 0;
/* 59 */     int fields = -1;
/*    */     
/* 61 */     for (int i = 0; i < layout.getRecordCount(); i++) {
/* 62 */       if (fields < layout.getRecord(i).getFieldCount()) {
/* 63 */         idx = i;
/* 64 */         fields = layout.getRecord(i).getFieldCount();
/*    */       }
/*    */     }
/* 67 */     return idx;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/DisplayType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */