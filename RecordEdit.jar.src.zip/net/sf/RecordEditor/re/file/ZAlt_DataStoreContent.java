/*      */ package net.sf.RecordEditor.re.file;
/*      */ 
/*      */ import java.io.PrintStream;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.TreeMap;
/*      */ import javax.swing.event.TableModelEvent;
/*      */ import javax.swing.event.TableModelListener;
/*      */ import javax.swing.text.AbstractDocument.Content;
/*      */ import javax.swing.text.BadLocationException;
/*      */ import javax.swing.text.Segment;
/*      */ import javax.swing.undo.UndoableEdit;
/*      */ import net.sf.JRecord.Details.AbstractLine;
/*      */ import net.sf.RecordEditor.utils.fileStorage.DataStorePosition;
/*      */ import net.sf.RecordEditor.utils.fileStorage.IDataStore;
/*      */ import net.sf.RecordEditor.utils.fileStorage.IDataStorePosition;
/*      */ import net.sf.RecordEditor.utils.fileStorage.ITextInterface;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ZAlt_DataStoreContent
/*      */   implements AbstractDocument.Content, TableModelListener
/*      */ {
/*      */   public static final int INSERT = 121;
/*      */   public static final int UPDATE = 122;
/*      */   public static final int DELETE = 123;
/*      */   private final FileView fileView;
/*      */   private final IDataStore<? extends AbstractLine> datastore;
/*      */   private final ITextInterface ti;
/*   48 */   TreeMap<AbstractLine, RefDataStore> positionMap = new TreeMap();
/*   49 */   private long lastClearedTime = 0L;
/*   50 */   private int checkMethod = 0;
/*      */   
/*   52 */   private DocumentUpdateListner documentUpdateListner = null;
/*      */   
/*   54 */   private boolean notifyDocument = true;
/*      */   
/*      */ 
/*      */   public ZAlt_DataStoreContent(FileView file, ITextInterface ti)
/*      */   {
/*   59 */     this.datastore = ti.getDataStore();
/*   60 */     this.ti = ti;
/*   61 */     this.fileView = file;
/*   62 */     file.addTableModelListener(this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public IDataStorePosition createPosition(int offset)
/*      */     throws BadLocationException
/*      */   {
/*   74 */     return register(this.ti.getTextPosition(offset));
/*      */   }
/*      */   
/*      */   private IDataStorePosition register(DataStorePosition pos)
/*      */   {
/*   79 */     if (pos == null) return pos;
/*   80 */     RefDataStore r = new RefDataStore(pos);
/*   81 */     IDataStorePosition ret = (IDataStorePosition)r.get();
/*   82 */     AbstractLine key = pos.getLineRE();
/*      */     
/*   84 */     RefDataStore lookupRef = getNext((RefDataStore)this.positionMap.get(key));
/*      */     
/*      */ 
/*   87 */     if (lookupRef != null)
/*      */     {
/*      */ 
/*   90 */       RefDataStore ref = lookupRef;
/*      */       do {
/*   92 */         IDataStorePosition lookupPos = (IDataStorePosition)r.get();
/*   93 */         if ((lookupPos != null) && (lookupPos.getLineRE() == ret.getLineRE()) && (lookupPos.getPositionInLineRE() == ret.getPositionInLineRE()))
/*      */         {
/*   95 */           return lookupPos;
/*      */         }
/*   97 */       } while (getNext(ref) != null);
/*   98 */       r.next = lookupRef;
/*      */     }
/*      */     
/*  101 */     this.positionMap.put(key, r);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  166 */     return ret;
/*      */   }
/*      */   
/*      */   private RefDataStore getNext(RefDataStore r) {
/*  170 */     if ((r == null) || (r.get() != null)) {
/*  171 */       return r;
/*      */     }
/*  173 */     while ((r.next != null) && (r.next.get() == null)) {
/*  174 */       r.next = r.next.next;
/*      */     }
/*  176 */     return r.next;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public IDataStorePosition createTempPosition(int offset)
/*      */   {
/*  221 */     return this.ti.getTextPosition(offset);
/*      */   }
/*      */   
/*      */   public IDataStorePosition getLinePosition(int lineNo) {
/*  225 */     return getLinePosition(lineNo, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public IDataStorePosition getLinePosition(int lineNo, boolean register)
/*      */   {
/*  234 */     DataStorePosition linePosition = this.ti.getPositionByLineNumber(lineNo);
/*  235 */     IDataStorePosition ret = linePosition;
/*  236 */     if (register) {
/*  237 */       ret = register(linePosition);
/*      */     }
/*  239 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int calcCompare(int searchValue, boolean offset, DataStorePosition p)
/*      */   {
/*      */     int v;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     int v;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  343 */     if (offset) {
/*  344 */       int x = p.getOffset();
/*      */       
/*  346 */       v = x == searchValue ? 0 : x < searchValue ? -1 : 1;
/*      */     }
/*      */     else {
/*  349 */       v = Integer.compare(p.lineNumber, searchValue);
/*  350 */       if ((v == 0) && (p.positionInLine > 0)) {
/*  351 */         v = 1;
/*      */       }
/*      */     }
/*      */     
/*  355 */     return v;
/*      */   }
/*      */   
/*      */ 
/*      */   private void clearIfNecessary()
/*      */   {
/*  361 */     if (System.nanoTime() - this.lastClearedTime > 300000000L)
/*      */     {
/*  363 */       clearUnusedPositions();
/*  364 */       return;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public final void clearUnusedPositions()
/*      */   {
/*  371 */     Set<Map.Entry<AbstractLine, RefDataStore>> entrySet = this.positionMap.entrySet();
/*      */     
/*      */ 
/*  374 */     for (Map.Entry<AbstractLine, RefDataStore> e : entrySet) {
/*  375 */       RefDataStore r = getNext((RefDataStore)e.getValue());
/*  376 */       if (r == null) {
/*  377 */         this.positionMap.remove(e.getKey());
/*      */       }
/*      */       else {
/*  380 */         while ((r.next != null) && (r.next.get() == null)) {
/*  381 */           r.next = r.next.next;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int length()
/*      */   {
/*  408 */     return (int)Math.min(this.ti.length(), 2147473647L);
/*      */   }
/*      */   
/*      */   public int numberOfLines()
/*      */   {
/*  413 */     return this.datastore.size();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UndoableEdit insertString(int where, String str)
/*      */     throws BadLocationException
/*      */   {
/*  423 */     printLines();
/*      */     try {
/*  425 */       DataStorePosition start = this.ti.getTextPosition(where);
/*      */       
/*  427 */       String tmpStr = str;
/*      */       
/*  429 */       ArrayList<String> lines = new ArrayList();
/*  430 */       AbstractLine line1 = (AbstractLine)this.datastore.get(start.lineNumber);
/*  431 */       String s1 = line1.getFullLine();
/*  432 */       String s2 = "";
/*      */       
/*      */ 
/*  435 */       if (start.positionInLine == 0) {
/*  436 */         s2 = s1;
/*  437 */         s1 = "";
/*  438 */       } else if (start.positionInLine < s1.length()) {
/*  439 */         s2 = s1.substring(start.positionInLine);
/*  440 */         s1 = s1.substring(0, start.positionInLine);
/*      */       }
/*      */       int idx;
/*  443 */       while ((idx = tmpStr.indexOf('\n')) >= 0) {
/*  444 */         lines.add(tmpStr.substring(0, idx));
/*  445 */         tmpStr = tmpStr.substring(idx + 1);
/*      */       }
/*  447 */       lines.add(tmpStr);
/*      */       
/*  449 */       int updateFrom = where;
/*  450 */       if (updateFrom == 0) {
/*  451 */         updateFrom++;
/*      */       }
/*      */       
/*  454 */       this.notifyDocument = false;
/*      */       AbstractLine l;
/*  456 */       int shift; if (lines.size() == 1) {
/*  457 */         updatePositions(updateFrom, 0, start.lineNumber, line1, str.length());
/*  458 */         line1.setData(s1 + str + s2);
/*      */       } else {
/*  460 */         RefDataStore refDS = getNext((RefDataStore)this.positionMap.get(line1));
/*      */         
/*  462 */         ArrayList<DataStorePosition> list = new ArrayList();
/*      */         
/*  464 */         while (refDS != null) {
/*  465 */           DataStorePosition p = refDS.pos;
/*  466 */           if ((p.positionInLine >= start.positionInLine) && ((p.lineNumber > 0) || (p.positionInLine > 0)))
/*      */           {
/*  468 */             list.add(p);
/*      */           }
/*  470 */           refDS = getNext(refDS);
/*      */         }
/*      */         
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  489 */         line1.setData(s1 + (String)lines.get(0));
/*  490 */         AbstractLine[] newLines = this.fileView.createLines(lines.size() - 1);
/*  491 */         for (int i = 1; i < lines.size() - 1; i++) {
/*  492 */           newLines[(i - 1)].setData((String)lines.get(i));
/*      */         }
/*  494 */         newLines[(newLines.length - 1)].setData((String)lines.get(lines.size() - 1) + s2);
/*      */         
/*      */ 
/*  497 */         idx = this.fileView.addLines(start.lineNumber + 1, -1, newLines);
/*      */         
/*      */ 
/*  500 */         if (idx >= 0) {
/*  501 */           l = this.fileView.getLine(idx);
/*  502 */           shift = ((String)lines.get(lines.size() - 1)).length() - start.positionInLine;
/*  503 */           for (DataStorePosition pp : list) {
/*  504 */             pp.line = l;
/*  505 */             pp.lineNumber = idx;
/*  506 */             pp.setLookupRequiredRE();
/*  507 */             pp.positionInLine += shift;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*  512 */       printLines();
/*      */       
/*  514 */       this.fileView.fireTableRowsUpdated(start.lineNumber, start.lineNumber + lines.size());
/*  515 */       if ((str != null) || (!"".equals(str))) {
/*  516 */         this.fileView.setChanged(true);
/*      */       }
/*      */     } finally {
/*  519 */       this.notifyDocument = true;
/*      */     }
/*  521 */     printLines();
/*  522 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void printLines() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UndoableEdit remove(int where, int nitems)
/*      */     throws BadLocationException
/*      */   {
/*  543 */     DataStorePosition start = this.ti.getTextPosition(where);
/*  544 */     DataStorePosition fin = this.ti.getTextPosition(where + nitems);
/*      */     
/*  546 */     AbstractLine line1 = (AbstractLine)this.datastore.get(start.lineNumber);
/*  547 */     AbstractLine line2 = (AbstractLine)this.datastore.get(fin.lineNumber);
/*  548 */     String s1 = line1.getFullLine();
/*  549 */     String s2 = line2.getFullLine();
/*      */     
/*      */ 
/*      */ 
/*      */     int st;
/*      */     
/*      */ 
/*      */     int en;
/*      */     
/*      */ 
/*  559 */     if ((start.positionInLine == 0) && (fin.positionInLine < s2.length())) {
/*  560 */       int st = start.lineNumber;
/*  561 */       int en = fin.lineNumber - 1;
/*      */       
/*      */ 
/*  564 */       updateRemovedPositions(where, nitems, line2, 0, fin.lineNumber);
/*  565 */       updatePositions(where, nitems, fin.lineNumber, line2, -fin.positionInLine);
/*      */       
/*  567 */       line2.setData(s2.substring(fin.positionInLine));
/*  568 */       this.fileView.fireTableRowsUpdated(fin.lineNumber, fin.lineNumber);
/*      */     } else {
/*  570 */       if (fin.positionInLine >= s2.length()) {
/*  571 */         s2 = "";
/*      */       } else {
/*  573 */         s2 = s2.substring(fin.positionInLine);
/*      */       }
/*      */       
/*  576 */       st = start.lineNumber + 1;
/*  577 */       en = fin.lineNumber;
/*      */       
/*      */ 
/*  580 */       updateRemovedPositions(where, nitems, line1, start.positionInLine, start.lineNumber);
/*  581 */       updatePositions(where, nitems, start.lineNumber, line1, start.positionInLine - fin.positionInLine);
/*      */       
/*  583 */       line1.setData(s1.substring(0, start.positionInLine) + s2);
/*  584 */       this.fileView.fireTableRowsUpdated(st, st);
/*      */     }
/*      */     
/*  587 */     if (st <= en) {
/*  588 */       int[] recNums = new int[en - st + 1];
/*  589 */       for (int i = st; i <= en; i++) {
/*  590 */         recNums[(i - st)] = i;
/*      */       }
/*  592 */       this.fileView.deleteLines(recNums);
/*      */     }
/*      */     
/*  595 */     if (nitems > 0) {
/*  596 */       this.fileView.setChanged(true);
/*      */     }
/*  598 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   private void updateRemovedPositions(int where, int nitems, AbstractLine line, int newOffset, int lineNo)
/*      */   {
/*  604 */     RefDataStore refDS = getNext((RefDataStore)this.positionMap.get(line));
/*      */     
/*      */ 
/*  607 */     while (refDS != null) {
/*  608 */       DataStorePosition p = refDS.pos;
/*  609 */       p.line = line;
/*  610 */       p.lineNumber = lineNo;
/*  611 */       p.positionInLine = newOffset;
/*  612 */       p.setLookupRequiredRE();
/*  613 */       refDS = getNext(refDS);
/*      */     }
/*  615 */     this.fileView.fireTableRowsUpdated(lineNo, lineNo);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void updatePositions(int where, int nitems, int lineNum, AbstractLine line, int shift)
/*      */   {
/*  642 */     RefDataStore refDS = getNext((RefDataStore)this.positionMap.get(line));
/*      */     
/*      */ 
/*  645 */     while (refDS != null) {
/*  646 */       DataStorePosition p = refDS.pos;
/*  647 */       p.lineNumber = lineNum;
/*  648 */       p.line = line;
/*  649 */       p.positionInLine += shift;
/*  650 */       p.setLookupRequiredRE();
/*  651 */       refDS = getNext(refDS);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getString(int where, int len)
/*      */     throws BadLocationException
/*      */   {
/*  679 */     Segment s = new Segment();
/*  680 */     getChars(where, len, s);
/*  681 */     return new String(s.array, s.offset, s.count);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void getChars(int where, int len, Segment txt)
/*      */     throws BadLocationException
/*      */   {
/*  692 */     DataStorePosition start = this.ti.getTextPosition(where);
/*  693 */     DataStorePosition fin = this.ti.getTextPosition(where + len);
/*      */     
/*  695 */     AbstractLine line1 = (AbstractLine)this.datastore.get(start.lineNumber);
/*  696 */     String s1 = line1.getFullLine() + "\n";
/*      */     
/*  698 */     if (fin == null) {
/*  699 */       txt.array = new char[0];
/*  700 */       txt.count = 0;
/*  701 */       txt.offset = 0;
/*  702 */       txt.offset = 0;
/*  703 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  716 */     if (start.lineNumber == fin.lineNumber)
/*      */     {
/*  718 */       String s = s1.substring(start.positionInLine, Math.min(fin.positionInLine, s1.length()));
/*      */       
/*      */ 
/*  721 */       txt.array = s.toCharArray();
/*  722 */       txt.count = txt.array.length;
/*  723 */       txt.offset = 0;
/*  724 */       return;
/*      */     }
/*      */     
/*  727 */     AbstractLine line2 = (AbstractLine)this.datastore.get(fin.lineNumber);
/*  728 */     String s2 = line2.getFullLine() + '\n';
/*  729 */     if (start.positionInLine >= s1.length()) {
/*  730 */       s1 = "";
/*  731 */     } else if (start.positionInLine > 0) {
/*  732 */       s1 = s1.substring(start.positionInLine);
/*      */     }
/*      */     
/*  735 */     if (fin.positionInLine == 0) {
/*  736 */       s2 = "";
/*  737 */     } else if (fin.positionInLine < s2.length()) {
/*  738 */       s2 = s2.substring(0, fin.positionInLine);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  743 */     StringBuffer b = new StringBuffer(s1);
/*      */     
/*  745 */     for (int i = start.lineNumber + 1; i < fin.lineNumber; i++) {
/*  746 */       b.append(((AbstractLine)this.datastore.get(i)).getFullLine()).append('\n');
/*      */     }
/*      */     
/*  749 */     b.append(s2);
/*      */     
/*  751 */     txt.array = b.toString().toCharArray();
/*  752 */     txt.count = b.length();
/*  753 */     txt.offset = 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void tableChanged(TableModelEvent event)
/*      */   {
/*  762 */     int type = 122;
/*  763 */     switch (event.getType())
/*      */     {
/*      */     case 1: 
/*  766 */       updateLinePos(event.getFirstRow() + 1, event.getLastRow() - event.getFirstRow() + 1);
/*      */       
/*  768 */       type = 121;
/*  769 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     case -1: 
/*  775 */       updateDeleteLinePos(event.getLastRow() + 1, event.getFirstRow() - event.getLastRow() - 1);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  813 */       break;
/*      */     default: 
/*  815 */       updateLinePos(event.getFirstRow(), 0);
/*      */     }
/*      */     
/*  818 */     if ((this.documentUpdateListner != null) && (this.notifyDocument)) {
/*  819 */       this.documentUpdateListner.fireUpdate(type, event.getFirstRow(), Math.min(this.fileView.getRowCount() - 1, event.getLastRow()));
/*      */     }
/*      */   }
/*      */   
/*      */   protected final void updateLinePos(int firstLine, int amount) {
/*  824 */     EntryIterator ei = new EntryIterator(null);
/*      */     
/*      */ 
/*  827 */     while (ei.hasNext()) {
/*  828 */       RefDataStore r = getNext(ei.next());
/*  829 */       DataStorePosition p = r.pos;
/*  830 */       if (p.getLineNumberRE() >= firstLine) {
/*  831 */         updateLine(r, p, amount);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void updateDeleteLinePos(int firstLine, int lastLine)
/*      */   {
/*  854 */     int amount = lastLine - firstLine - 1;
/*  855 */     EntryIterator ei = new EntryIterator(null);
/*  856 */     RefDataStore toInsert = null;
/*      */     
/*      */ 
/*      */ 
/*  860 */     int newRow = firstLine;
/*  861 */     int posInLine = 0;
/*  862 */     AbstractLine l = null;
/*      */     
/*      */ 
/*  865 */     if (lastLine + 1 < this.datastore.size()) {
/*  866 */       l = (AbstractLine)this.datastore.get(lastLine + 1);
/*  867 */     } else if ((lastLine - 1 >= 0) && (lastLine - 1 < this.datastore.size())) {
/*  868 */       newRow--;
/*  869 */       l = (AbstractLine)this.datastore.get(newRow);
/*  870 */       posInLine = l.getFullLine().length();
/*  871 */     } else if (this.datastore.size() > 0) {
/*  872 */       newRow = this.datastore.size() - 1;
/*  873 */       l = (AbstractLine)this.datastore.get(newRow);
/*  874 */       posInLine = l.getFullLine().length();
/*      */     }
/*      */     
/*      */ 
/*  878 */     while (ei.hasNext()) {
/*  879 */       RefDataStore r = getNext(ei.next());
/*  880 */       DataStorePosition p = r.pos;
/*  881 */       int lineNum = p.getLineNumberRE();
/*  882 */       if (lineNum > lastLine) {
/*  883 */         updateLine(r, p, amount);
/*  884 */       } else if (lineNum >= firstLine) {
/*  885 */         RefDataStore holdR = r;
/*      */         RefDataStore lastR;
/*  887 */         do { lastR = r;
/*  888 */           p = r.pos;
/*      */           
/*  890 */           p.lineNumber = newRow;
/*  891 */           p.positionInLine = posInLine;
/*  892 */           p.setLookupRequiredRE();
/*  893 */           p.line = l;
/*  894 */         } while ((r = getNext(r)) != null);
/*  895 */         lastR.next = toInsert;
/*  896 */         toInsert = holdR;
/*  897 */         this.positionMap.remove(holdR.pos.line);
/*      */       }
/*      */     }
/*      */     
/*  901 */     if (toInsert != null) {
/*  902 */       this.positionMap.put(l, toInsert);
/*      */     }
/*      */   }
/*      */   
/*      */   private void updateLine(RefDataStore r, DataStorePosition p, int amount)
/*      */   {
/*  908 */     p.lineNumber = Math.max(p.lineNumber + amount, 0);
/*  909 */     while ((r = getNext(r)) != null) {
/*  910 */       p = r.pos;
/*  911 */       p.lineNumber = Math.max(p.lineNumber + amount, 0);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void printPositions(int offset)
/*      */   {
/*  951 */     EntryIterator ei = new EntryIterator(null);
/*      */     
/*      */ 
/*  954 */     System.out.println("***** Positions: " + offset);
/*  955 */     while (ei.hasNext()) {
/*  956 */       RefDataStore r = getNext(ei.next());
/*  957 */       while (r != null) { IDataStorePosition p;
/*  958 */         if ((p = (IDataStorePosition)r.get()) != null) {
/*  959 */           System.out.print("\t" + p.getLineNumberRE() + '~' + p.getPositionInLineRE());
/*      */         }
/*  961 */         r = getNext(r);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDocumentUpdateListner(DocumentUpdateListner document)
/*      */   {
/*  972 */     this.documentUpdateListner = document;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public FileView getFileView()
/*      */   {
/*  979 */     return this.fileView;
/*      */   }
/*      */   
/*      */   private static class RefDataStore extends WeakReference<IDataStorePosition> {
/*      */     private final DataStorePosition pos;
/*  984 */     public RefDataStore next = null;
/*      */     
/*  986 */     public RefDataStore(DataStorePosition referent) { this(new ZAlt_DataStoreContent.DelegateDSPosition(referent)); }
/*      */     
/*      */     public RefDataStore(ZAlt_DataStoreContent.DelegateDSPosition referent)
/*      */     {
/*  990 */       super();
/*  991 */       this.pos = referent.pos;
/*      */     }
/*      */   }
/*      */   
/*      */   private static class DelegateDSPosition implements IDataStorePosition {
/*      */     private final DataStorePosition pos;
/*      */     
/*      */     public DelegateDSPosition(DataStorePosition pos) {
/*  999 */       this.pos = pos;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public int getOffset()
/*      */     {
/* 1007 */       return this.pos.getOffset();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public long getLineStartRE()
/*      */     {
/* 1015 */       return this.pos.getLineStartRE();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public int getPositionInLineRE()
/*      */     {
/* 1023 */       return this.pos.getPositionInLineRE();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public int getLineNumberRE()
/*      */     {
/* 1031 */       return this.pos.getLineNumberRE();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public AbstractLine getLineRE()
/*      */     {
/* 1039 */       return this.pos.getLineRE();
/*      */     }
/*      */   }
/*      */   
/*      */   private class EntryIterator implements Iterator<ZAlt_DataStoreContent.RefDataStore>
/*      */   {
/* 1045 */     Iterator<Map.Entry<AbstractLine, ZAlt_DataStoreContent.RefDataStore>> entrylist = ZAlt_DataStoreContent.this.positionMap.entrySet().iterator();
/* 1046 */     ZAlt_DataStoreContent.RefDataStore next = null;
/*      */     
/*      */ 
/*      */     private EntryIterator() {}
/*      */     
/*      */     public boolean hasNext()
/*      */     {
/* 1053 */       getNextEntry();
/* 1054 */       return this.next != null;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public ZAlt_DataStoreContent.RefDataStore next()
/*      */     {
/* 1062 */       getNextEntry();
/*      */       
/* 1064 */       ZAlt_DataStoreContent.RefDataStore ret = this.next;
/* 1065 */       this.next = null;
/* 1066 */       return ret;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     private void getNextEntry()
/*      */     {
/* 1073 */       while ((this.entrylist.hasNext()) && (this.next == null)) {
/* 1074 */         Map.Entry<AbstractLine, ZAlt_DataStoreContent.RefDataStore> e = (Map.Entry)this.entrylist.next();
/* 1075 */         ZAlt_DataStoreContent.RefDataStore r1 = (ZAlt_DataStoreContent.RefDataStore)e.getValue();
/* 1076 */         ZAlt_DataStoreContent.RefDataStore rp = ZAlt_DataStoreContent.this.getNext(r1);
/* 1077 */         if (rp == null) {
/* 1078 */           ZAlt_DataStoreContent.this.positionMap.remove(e.getKey());
/*      */         } else {
/* 1080 */           this.next = rp;
/* 1081 */           if (r1 != rp) {
/* 1082 */             ZAlt_DataStoreContent.this.positionMap.put(e.getKey(), rp);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */     public void remove() {}
/*      */   }
/*      */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/ZAlt_DataStoreContent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */