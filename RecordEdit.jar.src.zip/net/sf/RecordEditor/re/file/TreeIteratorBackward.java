/*    */ package net.sf.RecordEditor.re.file;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import net.sf.JRecord.Details.AbstractLine;
/*    */ import net.sf.RecordEditor.utils.ExpandLineTree;
/*    */ 
/*    */ public class TreeIteratorBackward
/*    */   implements Iterator<AbstractLine>
/*    */ {
/*    */   private List<? extends AbstractLine> list;
/* 13 */   private ArrayList<AbstractLine> expandedLine = null;
/*    */   
/*    */   private int currentLine;
/*    */   
/*    */   private int currentChild;
/*    */   
/*    */   public TreeIteratorBackward(List<? extends AbstractLine> lines, AbstractLine lastLine)
/*    */   {
/* 21 */     this.list = lines;
/*    */     
/* 23 */     if ((lines != null) && (lines.size() != 0))
/*    */     {
/*    */ 
/* 26 */       if (lastLine == null) {
/* 27 */         this.expandedLine = ExpandLineTree.expandTree((AbstractLine)this.list.get(this.currentLine++));
/* 28 */         this.currentLine = (this.list.size() - 1);
/*    */       } else {
/* 30 */         this.expandedLine = ExpandLineTree.expandTo(lastLine);
/* 31 */         this.currentLine = this.list.indexOf(ExpandLineTree.getRootLine(lastLine));
/*    */       }
/*    */       
/* 34 */       this.currentChild = (this.expandedLine.size() - 1);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean hasNext()
/*    */   {
/* 43 */     return (this.expandedLine != null) && (this.list != null) && ((this.currentLine > 0) || (this.currentChild >= 0));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public AbstractLine next()
/*    */   {
/* 52 */     if (this.currentChild <= 0) {
/* 53 */       this.expandedLine = ExpandLineTree.expandTree((AbstractLine)this.list.get(--this.currentLine));
/* 54 */       this.currentChild = (this.expandedLine.size() - 1);
/*    */     }
/* 56 */     return (AbstractLine)this.expandedLine.get(this.currentChild--);
/*    */   }
/*    */   
/*    */   public void remove() {}
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/TreeIteratorBackward.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */