/*      */ package net.sf.RecordEditor.re.file;
/*      */ 
/*      */ import java.io.PrintStream;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.util.ArrayList;
/*      */ import javax.swing.event.TableModelEvent;
/*      */ import javax.swing.event.TableModelListener;
/*      */ import javax.swing.text.AbstractDocument.Content;
/*      */ import javax.swing.text.BadLocationException;
/*      */ import javax.swing.text.Segment;
/*      */ import javax.swing.undo.UndoableEdit;
/*      */ import net.sf.JRecord.Details.AbstractLine;
/*      */ import net.sf.RecordEditor.utils.fileStorage.DataStorePosition;
/*      */ import net.sf.RecordEditor.utils.fileStorage.IDataStore;
/*      */ import net.sf.RecordEditor.utils.fileStorage.IDataStorePosition;
/*      */ import net.sf.RecordEditor.utils.fileStorage.ITextInterface;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class DataStoreContent
/*      */   implements AbstractDocument.Content, TableModelListener
/*      */ {
/*      */   public static final int INSERT = 121;
/*      */   public static final int UPDATE = 122;
/*      */   public static final int DELETE = 123;
/*      */   private final FileView fileView;
/*      */   private final IDataStore<? extends AbstractLine> datastore;
/*      */   private final ITextInterface ti;
/*   37 */   private final ArrayList<RefDataStore> positions = new ArrayList(150);
/*      */   
/*      */ 
/*   40 */   private long lastClearedTime = 0L;
/*   41 */   private int checkMethod = 0;
/*      */   
/*   43 */   private DocumentUpdateListner documentUpdateListner = null;
/*      */   
/*   45 */   private boolean notifyDocument = true;
/*      */   
/*      */ 
/*      */   public DataStoreContent(FileView file, ITextInterface ti)
/*      */   {
/*   50 */     this.datastore = ti.getDataStore();
/*   51 */     this.ti = ti;
/*   52 */     this.fileView = file;
/*   53 */     file.addTableModelListener(this);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public IDataStorePosition createPosition(int offset)
/*      */     throws BadLocationException
/*      */   {
/*   65 */     return register(this.ti.getTextPosition(offset));
/*      */   }
/*      */   
/*      */   private IDataStorePosition register(DataStorePosition pos)
/*      */   {
/*   70 */     if (pos == null) return pos;
/*   71 */     RefDataStore r = new RefDataStore(pos);
/*   72 */     IDataStorePosition ret = (IDataStorePosition)r.get();
/*      */     
/*   74 */     int firstKey = getValidPosIndex(0, 0, this.positions.size() - 1);
/*   75 */     int lastKey = getValidPosIndex(this.positions.size() - 1, 0, this.positions.size() - 1);
/*   76 */     int offset = pos.getOffset();
/*   77 */     if ((this.positions.size() == 0) || (((RefDataStore)this.positions.get(lastKey)).pos.getOffset() < offset))
/*      */     {
/*   79 */       this.positions.add(r);
/*   80 */     } else if (((RefDataStore)this.positions.get(firstKey)).pos.getOffset() >= offset)
/*      */     {
/*   82 */       ret = addPosition(firstKey, r);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  107 */       int key = findPosByKey(offset, true);
/*  108 */       if (key < 0) {
/*  109 */         linearSearch(r, offset);
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*  115 */         ret = addPosition(key, r);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  137 */     return ret;
/*      */   }
/*      */   
/*      */   private IDataStorePosition linearSearch(RefDataStore r, int offset) {
/*  141 */     IDataStorePosition pos = (IDataStorePosition)r.get();
/*      */     
/*  143 */     int idx = getValidPosIndex(0, 0, this.positions.size() - 1);
/*      */     
/*  145 */     while ((idx < this.positions.size()) && (((RefDataStore)this.positions.get(idx)).pos.getOffset() < offset)) {
/*  146 */       idx = getValidPosIndex(idx++, idx, this.positions.size() - 1);
/*      */     }
/*      */     
/*  149 */     pos = addPosition(idx, r);
/*      */     
/*  151 */     return pos;
/*      */   }
/*      */   
/*      */   private IDataStorePosition addPosition(int idx, RefDataStore r) {
/*  155 */     int where = r.pos.getOffset();
/*      */     
/*  157 */     if (idx >= this.positions.size())
/*      */     {
/*  159 */       this.positions.add(r);
/*  160 */     } else if (((RefDataStore)this.positions.get(idx)).pos.getOffset() == where) {
/*  161 */       IDataStorePosition p = (IDataStorePosition)((RefDataStore)this.positions.get(idx)).get();
/*  162 */       if (p != null)
/*      */       {
/*  164 */         return p;
/*      */       }
/*  166 */       this.positions.set(idx, r);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*  171 */       this.positions.add(idx, r);
/*      */     }
/*  173 */     return (IDataStorePosition)r.get();
/*      */   }
/*      */   
/*      */   public IDataStorePosition createTempPosition(int offset) {
/*  177 */     IDataStorePosition pos = findPosition(offset, true);
/*  178 */     if (pos != null) {
/*  179 */       return pos;
/*      */     }
/*  181 */     return this.ti.getTextPosition(offset);
/*      */   }
/*      */   
/*      */   public IDataStorePosition getPositionByLineNumber(int lineNo) {
/*  185 */     return getPositionByLineNumber(lineNo, true);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public IDataStorePosition getPositionByLineNumber(int lineNo, boolean register)
/*      */   {
/*  194 */     DataStorePosition linePosition = this.ti.getPositionByLineNumber(lineNo);
/*  195 */     IDataStorePosition ret = linePosition;
/*  196 */     if (register) {
/*  197 */       ret = register(linePosition);
/*      */     }
/*  199 */     return ret;
/*      */   }
/*      */   
/*      */   public IDataStorePosition getLinePositionByOffset(long offset) {
/*  203 */     DataStorePosition linePosition = this.ti.getTextPosition(offset);
/*  204 */     linePosition.positionInLine = 0;
/*      */     
/*  206 */     return register(linePosition);
/*      */   }
/*      */   
/*      */ 
/*      */   private IDataStorePosition findPosition(int searchValue, boolean offset)
/*      */   {
/*  212 */     IDataStorePosition ret = null;
/*      */     
/*  214 */     int key = findPosByKey(searchValue, offset);
/*  215 */     IDataStorePosition chk1; if ((key >= 0) && (key < this.positions.size()) && ((chk1 = (IDataStorePosition)((RefDataStore)this.positions.get(key)).get()) != null))
/*      */     {
/*  217 */       DataStorePosition chk = ((RefDataStore)this.positions.get(key)).pos;
/*  218 */       if (((offset) && (chk.getOffset() == searchValue)) || ((!offset) && (chk.getLineNumberRE() == searchValue) && (chk.getPositionInLineRE() == 0)))
/*      */       {
/*  220 */         if (chk.getLineRE() == this.datastore.get(chk.getLineNumberRE())) {
/*      */           try {
/*  222 */             chk.updatePositionRE();
/*  223 */             ret = chk1;
/*      */           } catch (Exception e) {
/*  225 */             this.positions.remove(key);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  231 */     return ret;
/*      */   }
/*      */   
/*      */   private int findPosByKey(int searchValue, boolean offset)
/*      */   {
/*  236 */     synchronized (this.positions)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*  241 */       clearIfNecessary();
/*  242 */       int low = 0;
/*      */       
/*      */ 
/*  245 */       if (this.positions.size() == 0) { return 0;
/*      */       }
/*  247 */       int high = this.positions.size() - 1;
/*      */       
/*  249 */       if (calcCompare(searchValue, offset, ((RefDataStore)this.positions.get(0)).pos) >= 0) {
/*  250 */         return 0;
/*      */       }
/*      */       
/*  253 */       int v = calcCompare(searchValue, offset, ((RefDataStore)this.positions.get(high)).pos);
/*  254 */       if (v == 0)
/*  255 */         return high;
/*  256 */       if (v < 0) {
/*  257 */         return high + 1;
/*      */       }
/*      */       
/*  260 */       while (high > low) {
/*  261 */         int mid = (high + low) / 2;
/*      */         
/*      */ 
/*  264 */         DataStorePosition p = ((RefDataStore)this.positions.get(mid)).pos;
/*      */         
/*  266 */         v = calcCompare(searchValue, offset, p);
/*      */         
/*  268 */         if (high - 1 <= low)
/*      */         {
/*      */ 
/*  271 */           if (v <= 0) {
/*  272 */             low = mid;
/*  273 */             if (v < 0) {
/*  274 */               v = calcCompare(searchValue, offset, ((RefDataStore)this.positions.get(high)).pos);
/*  275 */               if (v >= 0) {
/*  276 */                 low = high;
/*      */               }
/*      */               
/*      */             }
/*      */             
/*      */           }
/*      */           
/*      */         }
/*  284 */         else if (v < 0) {
/*  285 */           low = mid;
/*  286 */         } else if (v > 0) {
/*  287 */           high = mid;
/*      */         } else {
/*  289 */           return mid;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  304 */       return low;
/*      */     }
/*      */   }
/*      */   
/*      */   private int calcCompare(int searchValue, boolean offset, DataStorePosition p) { int v;
/*      */     int v;
/*  310 */     if (offset) {
/*  311 */       int x = p.getOffset();
/*      */       
/*  313 */       v = x == searchValue ? 0 : x < searchValue ? -1 : 1;
/*      */     }
/*      */     else {
/*  316 */       v = Integer.compare(p.lineNumber, searchValue);
/*  317 */       if ((v == 0) && (p.positionInLine > 0)) {
/*  318 */         v = 1;
/*      */       }
/*      */     }
/*      */     
/*  322 */     return v;
/*      */   }
/*      */   
/*      */ 
/*      */   private void clearIfNecessary()
/*      */   {
/*  328 */     if (this.positions.size() == 0) { return;
/*      */     }
/*  330 */     if ((System.nanoTime() - this.lastClearedTime > 300000000L) || (!((RefDataStore)this.positions.get(0)).pos.isValidPositionRE()) || (!((RefDataStore)this.positions.get(this.positions.size() - 1)).pos.isValidPositionRE()))
/*      */     {
/*      */ 
/*      */ 
/*  334 */       clearUnusedPositions();
/*  335 */       return;
/*      */     }
/*      */     
/*  338 */     if (this.positions.size() > 16) {
/*  339 */       int count = 0;
/*      */       
/*  341 */       switch (this.checkMethod)
/*      */       {
/*      */       case 0: 
/*  344 */         int en = Math.max(0, this.positions.size() - 8);
/*      */         
/*  346 */         for (int i = this.positions.size() - 1; i >= en; i--) {
/*  347 */           if (((RefDataStore)this.positions.get(i)).get() == null) {
/*  348 */             count++;
/*  349 */             this.positions.remove(i);
/*      */           }
/*      */         }
/*  352 */         break;
/*      */       case 1: 
/*  354 */         for (int i = 7; i >= 0; i--) {
/*  355 */           if (((RefDataStore)this.positions.get(i)).get() == null) {
/*  356 */             count++;
/*  357 */             this.positions.remove(i);
/*      */           }
/*      */         }
/*      */         
/*  361 */         break;
/*      */       case 2: 
/*  363 */         int a = this.positions.size() / 8;
/*  364 */         for (int i = this.positions.size() - 1; i >= 0; i -= a) {
/*  365 */           if (((RefDataStore)this.positions.get(i)).get() == null) {
/*  366 */             count++;
/*  367 */             this.positions.remove(i);
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*  372 */       if (count >= 3) {
/*  373 */         clearUnusedPositions();
/*      */       }
/*      */       
/*  376 */       this.checkMethod = ((this.checkMethod + 1) % 3);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public final void clearUnusedPositions()
/*      */   {
/*  383 */     for (int i = this.positions.size() - 1; i >= 0; i--) {
/*  384 */       if ((((RefDataStore)this.positions.get(i)).get() == null) || (!((RefDataStore)this.positions.get(i)).pos.isValidPositionRE())) {
/*  385 */         this.positions.remove(i);
/*      */       }
/*      */     }
/*  388 */     this.lastClearedTime = System.nanoTime();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private int getValidPosIndex(int idx, int min, int max)
/*      */   {
/*  395 */     while ((idx >= min) && (idx < this.positions.size()) && (idx <= max) && (((RefDataStore)this.positions.get(idx)).get() == null)) {
/*  396 */       this.positions.remove(idx);
/*  397 */       if ((idx >= this.positions.size()) || (idx > max)) {
/*  398 */         idx--;
/*      */       }
/*      */     }
/*      */     
/*  402 */     return idx;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int length()
/*      */   {
/*  411 */     return (int)Math.min(this.ti.length(), 2147473647L);
/*      */   }
/*      */   
/*      */   public int numberOfLines()
/*      */   {
/*  416 */     return this.datastore.size();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UndoableEdit insertString(int where, String str)
/*      */     throws BadLocationException
/*      */   {
/*  426 */     printLines();
/*      */     try {
/*  428 */       DataStorePosition start = this.ti.getTextPosition(where);
/*      */       
/*  430 */       String tmpStr = str;
/*      */       
/*  432 */       ArrayList<String> lines = new ArrayList();
/*  433 */       AbstractLine line1 = (AbstractLine)this.datastore.get(start.lineNumber);
/*  434 */       String s1 = line1.getFullLine();
/*  435 */       String s2 = "";
/*      */       
/*      */ 
/*  438 */       if (start.positionInLine == 0) {
/*  439 */         s2 = s1;
/*  440 */         s1 = "";
/*  441 */       } else if (start.positionInLine < s1.length()) {
/*  442 */         s2 = s1.substring(start.positionInLine);
/*  443 */         s1 = s1.substring(0, start.positionInLine);
/*      */       }
/*      */       int idx;
/*  446 */       while ((idx = tmpStr.indexOf('\n')) >= 0) {
/*  447 */         lines.add(tmpStr.substring(0, idx));
/*  448 */         tmpStr = tmpStr.substring(idx + 1);
/*      */       }
/*  450 */       lines.add(tmpStr);
/*      */       
/*  452 */       int updateFrom = where;
/*  453 */       if (updateFrom == 0) {
/*  454 */         updateFrom++;
/*      */       }
/*      */       
/*  457 */       this.notifyDocument = false;
/*      */       AbstractLine l;
/*  459 */       int shift; if (lines.size() == 1)
/*      */       {
/*  461 */         updateRemovedPositions(updateFrom, 0, line1, 0, start.lineNumber, str.length(), false);
/*  462 */         line1.setData(s1 + str + s2);
/*      */       }
/*      */       else
/*      */       {
/*  466 */         int key = findPosByKey(where, true);
/*      */         
/*  468 */         ArrayList<DataStorePosition> list = new ArrayList();
/*      */         
/*  470 */         for (int i = key; i < this.positions.size(); i++) {
/*  471 */           DataStorePosition p = ((RefDataStore)this.positions.get(i)).pos;
/*  472 */           if (p.lineNumber > start.lineNumber)
/*      */             break;
/*  474 */           if ((p.positionInLine >= start.positionInLine) && ((p.lineNumber > 0) || (p.positionInLine > 0)))
/*      */           {
/*  476 */             list.add(p);
/*      */           }
/*      */         }
/*      */         
/*  480 */         line1.setData(s1 + (String)lines.get(0));
/*  481 */         AbstractLine[] newLines = this.fileView.createLines(lines.size() - 1);
/*  482 */         for (int i = 1; i < lines.size() - 1; i++) {
/*  483 */           newLines[(i - 1)].setData((String)lines.get(i));
/*      */         }
/*  485 */         newLines[(newLines.length - 1)].setData((String)lines.get(lines.size() - 1) + s2);
/*      */         
/*      */ 
/*  488 */         idx = this.fileView.addLines(start.lineNumber + 1, -1, newLines);
/*      */         
/*      */ 
/*  491 */         if ((idx >= 0) && (list.size() > 0))
/*      */         {
/*      */ 
/*  494 */           l = this.fileView.getLine(idx);
/*      */           
/*  496 */           shift = ((String)lines.get(lines.size() - 1)).length() - start.positionInLine;
/*  497 */           for (DataStorePosition pp : list) {
/*  498 */             pp.line = l;
/*  499 */             pp.lineNumber = idx;
/*  500 */             pp.setLookupRequiredRE();
/*  501 */             pp.positionInLine += shift;
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*  506 */       printLines();
/*      */       
/*  508 */       this.fileView.fireTableRowsUpdated(start.lineNumber, start.lineNumber + lines.size());
/*  509 */       if ((str != null) || (!"".equals(str))) {
/*  510 */         this.fileView.setChanged(true);
/*      */       }
/*      */     } finally {
/*  513 */       this.notifyDocument = true;
/*      */     }
/*  515 */     printLines();
/*  516 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void printLines() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public UndoableEdit remove(int where, int nitems)
/*      */     throws BadLocationException
/*      */   {
/*  537 */     DataStorePosition start = this.ti.getTextPosition(where);
/*  538 */     DataStorePosition fin = this.ti.getTextPosition(where + nitems);
/*      */     
/*  540 */     AbstractLine line1 = (AbstractLine)this.datastore.get(start.lineNumber);
/*  541 */     AbstractLine line2 = (AbstractLine)this.datastore.get(fin.lineNumber);
/*  542 */     String s1 = line1.getFullLine();
/*  543 */     String s2 = line2.getFullLine();
/*      */     
/*      */ 
/*      */ 
/*      */     int st;
/*      */     
/*      */ 
/*      */     int en;
/*      */     
/*      */ 
/*  553 */     if ((start.positionInLine == 0) && (fin.positionInLine < s2.length())) {
/*  554 */       int st = start.lineNumber;
/*  555 */       int en = fin.lineNumber - 1;
/*      */       
/*      */ 
/*  558 */       updateRemovedPositions(where, nitems, line2, 0, fin.lineNumber, -fin.positionInLine, true);
/*      */       
/*      */ 
/*  561 */       line2.setData(s2.substring(fin.positionInLine));
/*  562 */       this.fileView.fireTableRowsUpdated(fin.lineNumber, fin.lineNumber);
/*      */     } else {
/*  564 */       if (fin.positionInLine >= s2.length()) {
/*  565 */         s2 = "";
/*      */       } else {
/*  567 */         s2 = s2.substring(fin.positionInLine);
/*      */       }
/*      */       
/*  570 */       st = start.lineNumber + 1;
/*  571 */       en = fin.lineNumber;
/*      */       
/*      */ 
/*  574 */       updateRemovedPositions(where, nitems, line1, start.positionInLine, start.lineNumber, start.positionInLine - fin.positionInLine, true);
/*      */       
/*      */ 
/*  577 */       line1.setData(s1.substring(0, start.positionInLine) + s2);
/*  578 */       this.fileView.fireTableRowsUpdated(st, st);
/*      */     }
/*      */     
/*  581 */     if (st <= en) {
/*  582 */       int[] recNums = new int[en - st + 1];
/*  583 */       for (int i = st; i <= en; i++) {
/*  584 */         recNums[(i - st)] = i;
/*      */       }
/*  586 */       this.fileView.deleteLines(recNums);
/*      */     }
/*      */     
/*  589 */     if (nitems > 0) {
/*  590 */       this.fileView.setChanged(true);
/*      */     }
/*  592 */     return null;
/*      */   }
/*      */   
/*      */   private void updateRemovedPositions(int where, int nitems, AbstractLine line, int newOffset, int lineNo, int shift, boolean doPrev)
/*      */   {
/*  597 */     int key = findPosByKey(where + nitems, true);
/*  598 */     if (key >= 0) {
/*  599 */       int start = key;
/*      */       
/*      */ 
/*  602 */       DataStorePosition pos = this.ti.getTextPosition(where + nitems);
/*      */       
/*  604 */       if ((doPrev) && (key < this.positions.size()) && (((RefDataStore)this.positions.get(key)).pos.getOffset() >= where)) {
/*  605 */         start++;
/*      */       }
/*      */       
/*  608 */       for (int i = start; i < this.positions.size(); i++) {
/*  609 */         DataStorePosition p = ((RefDataStore)this.positions.get(i)).pos;
/*  610 */         if (p.lineNumber > pos.lineNumber)
/*      */           break;
/*  612 */         if (p.positionInLine >= pos.positionInLine)
/*      */         {
/*      */ 
/*  615 */           p.lineNumber = lineNo;
/*  616 */           p.line = line;
/*  617 */           p.positionInLine += shift;
/*  618 */           p.setLookupRequiredRE();
/*      */         }
/*      */       }
/*      */       
/*  622 */       if (doPrev) {
/*  623 */         key = Math.min(key, this.positions.size() - 1);
/*  624 */         for (int i = key; i >= 0; i--)
/*      */         {
/*  626 */           if (((RefDataStore)this.positions.get(i)).get() == null) {
/*  627 */             this.positions.remove(i);
/*      */           } else {
/*  629 */             DataStorePosition p = ((RefDataStore)this.positions.get(i)).pos;
/*  630 */             if (p.getOffset() < where) {
/*      */               break;
/*      */             }
/*      */             
/*      */ 
/*  635 */             p.line = line;
/*  636 */             p.lineNumber = lineNo;
/*  637 */             p.positionInLine = newOffset;
/*  638 */             p.setLookupRequiredRE();
/*      */           }
/*      */         }
/*      */       }
/*      */       
/*  643 */       this.fileView.fireTableRowsUpdated(lineNo, lineNo);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String getString(int where, int len)
/*      */     throws BadLocationException
/*      */   {
/*  699 */     Segment s = new Segment();
/*  700 */     getChars(where, len, s);
/*  701 */     return s.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void getChars(int where, int len, Segment txt)
/*      */     throws BadLocationException
/*      */   {
/*  711 */     if (len <= 0) {
/*  712 */       txt.array = null;
/*  713 */       return;
/*      */     }
/*      */     
/*  716 */     DataStorePosition start = this.ti.getTextPosition(where);
/*  717 */     DataStorePosition fin = this.ti.getTextPosition(where + len);
/*      */     
/*  719 */     AbstractLine line1 = (AbstractLine)this.datastore.get(start.lineNumber);
/*  720 */     String s1 = line1.getFullLine() + "\n";
/*      */     
/*  722 */     if (fin == null) {
/*  723 */       txt.array = new char[0];
/*  724 */       txt.count = 0;
/*  725 */       txt.offset = 0;
/*  726 */       txt.offset = 0;
/*  727 */       return;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  740 */     if (start.lineNumber == fin.lineNumber)
/*      */     {
/*  742 */       String s = s1.substring(start.positionInLine, Math.min(fin.positionInLine, s1.length()));
/*      */       
/*      */ 
/*  745 */       txt.array = s.toCharArray();
/*  746 */       txt.count = txt.array.length;
/*  747 */       txt.offset = 0;
/*  748 */       return;
/*      */     }
/*      */     
/*  751 */     AbstractLine line2 = (AbstractLine)this.datastore.get(fin.lineNumber);
/*  752 */     String s2 = line2.getFullLine() + '\n';
/*  753 */     if (start.positionInLine >= s1.length()) {
/*  754 */       s1 = "";
/*  755 */     } else if (start.positionInLine > 0) {
/*  756 */       s1 = s1.substring(start.positionInLine);
/*      */     }
/*      */     
/*  759 */     if (fin.positionInLine == 0) {
/*  760 */       s2 = "";
/*  761 */     } else if (fin.positionInLine < s2.length()) {
/*  762 */       s2 = s2.substring(0, fin.positionInLine);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  767 */     StringBuffer b = new StringBuffer(s1);
/*      */     
/*  769 */     for (int i = start.lineNumber + 1; i < fin.lineNumber; i++) {
/*  770 */       b.append(((AbstractLine)this.datastore.get(i)).getFullLine()).append('\n');
/*      */     }
/*      */     
/*  773 */     b.append(s2);
/*      */     
/*  775 */     txt.array = b.toString().toCharArray();
/*  776 */     txt.count = b.length();
/*  777 */     txt.offset = 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void tableChanged(TableModelEvent event)
/*      */   {
/*  786 */     int type = 122;
/*  787 */     switch (event.getType())
/*      */     {
/*      */     case 1: 
/*  790 */       updateLinePos(event.getFirstRow() + 1, event.getLastRow() - event.getFirstRow() + 1);
/*      */       
/*  792 */       type = 121;
/*  793 */       break;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     case -1: 
/*  800 */       int en = updateLinePos(event.getLastRow() + 1, event.getFirstRow() - event.getLastRow() - 1);
/*      */       
/*  802 */       int newRow = event.getFirstRow();
/*  803 */       int posInLine = 0;
/*  804 */       AbstractLine l = null;
/*      */       
/*  806 */       type = 123;
/*      */       
/*  808 */       if (event.getLastRow() + 1 < this.datastore.size()) {
/*  809 */         l = (AbstractLine)this.datastore.get(event.getLastRow() + 1);
/*  810 */       } else if ((event.getFirstRow() - 1 >= 0) && (event.getFirstRow() - 1 < this.datastore.size())) {
/*  811 */         newRow--;
/*  812 */         l = (AbstractLine)this.datastore.get(newRow);
/*  813 */         posInLine = l.getFullLine().length();
/*  814 */       } else if (this.datastore.size() > 0) {
/*  815 */         newRow = this.datastore.size() - 1;
/*  816 */         l = (AbstractLine)this.datastore.get(newRow);
/*  817 */         posInLine = l.getFullLine().length();
/*      */       }
/*      */       
/*      */ 
/*  821 */       for (int i = Math.min(en, this.positions.size() - 1); i >= 0; i--) {
/*  822 */         DataStorePosition p = ((RefDataStore)this.positions.get(i)).pos;
/*      */         
/*      */ 
/*  825 */         if (p.lineNumber < event.getFirstRow()) break;
/*  826 */         if (p.lineNumber <= event.getLastRow()) {
/*  827 */           p.lineNumber = newRow;
/*  828 */           p.positionInLine = posInLine;
/*  829 */           p.setLookupRequiredRE();
/*  830 */           p.line = l;
/*      */         }
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  837 */       break;
/*      */     default: 
/*  839 */       updateLinePos(event.getFirstRow(), 0);
/*      */     }
/*      */     
/*  842 */     if ((this.documentUpdateListner != null) && (this.notifyDocument)) {
/*  843 */       this.documentUpdateListner.fireUpdate(type, event.getFirstRow(), Math.min(this.fileView.getRowCount() - 1, event.getLastRow()));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private int updateLinePos(int firstLine, int amount)
/*      */   {
/*  852 */     for (int i = this.positions.size() - 1; i >= 0; i--) {
/*  853 */       if (((RefDataStore)this.positions.get(i)).get() == null) {
/*  854 */         this.positions.remove(i);
/*      */       } else {
/*  856 */         DataStorePosition p = ((RefDataStore)this.positions.get(i)).pos;
/*      */         
/*  858 */         if (p.lineNumber < firstLine) {
/*  859 */           return i;
/*      */         }
/*      */         
/*      */ 
/*  863 */         p.lineNumber = Math.max(p.lineNumber + amount, 0);
/*  864 */         p.setLookupRequiredRE();
/*      */       }
/*      */     }
/*      */     
/*  868 */     return -1;
/*      */   }
/*      */   
/*      */   public final boolean checkPositionSequence(String s)
/*      */   {
/*  873 */     int last = -1;
/*  874 */     DataStorePosition lastP = null;
/*      */     
/*      */ 
/*  877 */     for (int i = 0; i < this.positions.size(); i++) {
/*  878 */       DataStorePosition p = ((RefDataStore)this.positions.get(i)).pos;
/*      */       
/*  880 */       if (p.isValidPositionRE())
/*      */       {
/*      */ 
/*  883 */         if (last > p.lineNumber * 1000 + p.positionInLine) {
/*  884 */           System.out.println();
/*  885 */           System.out.println();
/*  886 */           System.out.println(" ------   Error at: " + i + "\t Line Number: " + p.lineNumber + " " + p.positionInLine + " ~ " + last + " > " + (p.lineNumber * 1000 + p.positionInLine));
/*      */           
/*  888 */           if (lastP != null) {
/*  889 */             System.out.println(" ------             \t Line Number: " + lastP.lineNumber + " " + lastP.positionInLine + " ~ " + last);
/*      */           }
/*      */           
/*  892 */           System.out.println(" ------ " + s);
/*  893 */           System.out.println();
/*  894 */           printPositions((int)p.lineStart - 50, (int)p.lineStart + 200);
/*  895 */           return false;
/*      */         }
/*  897 */         lastP = p;
/*  898 */         last = p.lineNumber * 1000 + p.positionInLine;
/*      */       }
/*      */     }
/*  901 */     return true;
/*      */   }
/*      */   
/*      */   public void printPositions(int offset) {
/*  905 */     if (this.positions.size() > 0) {
/*  906 */       int last = -1;
/*  907 */       boolean error = false;
/*      */       
/*      */ 
/*  910 */       System.out.println("***** Positions: " + offset);
/*  911 */       for (int i = 0; i < this.positions.size(); i++) {
/*  912 */         String s = " ";
/*  913 */         if (((RefDataStore)this.positions.get(i)).get() == null) {
/*  914 */           s = "^";
/*      */         }
/*  916 */         DataStorePosition p = ((RefDataStore)this.positions.get(i)).pos;
/*  917 */         System.out.print("\t" + p.lineNumber + '~' + p.positionInLine + s);
/*  918 */         if (last > p.lineNumber * 1000 + p.positionInLine) {
/*  919 */           System.out.print(" ");
/*  920 */           error = true;
/*      */         }
/*  922 */         last = p.lineNumber * 1000 + p.positionInLine;
/*      */       }
/*  924 */       System.out.println();
/*  925 */       if (error) {
/*  926 */         System.out.println(" ============== Error");
/*  927 */         System.out.println();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void printPositions(int start, int end)
/*      */   {
/*  935 */     if (this.positions.size() > 0) {
/*  936 */       int last = -1;
/*  937 */       boolean error = false;
/*      */       
/*      */ 
/*  940 */       System.out.println("***** Positions: " + start);
/*  941 */       for (int i = 0; i < this.positions.size(); i++) {
/*  942 */         String s = " ";
/*  943 */         DataStorePosition p = ((RefDataStore)this.positions.get(i)).pos;
/*  944 */         if ((p.lineStart + p.positionInLine >= start) && (p.lineStart < end)) {
/*  945 */           if (((RefDataStore)this.positions.get(i)).get() == null) {
/*  946 */             s = "^";
/*      */           }
/*  948 */           System.out.print("\t" + p.lineNumber + '~' + p.positionInLine + s);
/*  949 */           if (last > p.lineNumber * 1000 + p.positionInLine) {
/*  950 */             System.out.print(" ");
/*  951 */             error = true;
/*      */           }
/*  953 */           if (i % 25 == 0) System.out.println();
/*      */         }
/*  955 */         last = p.lineNumber * 1000 + p.positionInLine;
/*      */       }
/*  957 */       System.out.println();
/*  958 */       if (error) {
/*  959 */         System.out.println(" ============== Error");
/*  960 */         System.out.println();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setDocumentUpdateListner(DocumentUpdateListner document)
/*      */   {
/*  969 */     this.documentUpdateListner = document;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public FileView getFileView()
/*      */   {
/*  976 */     return this.fileView;
/*      */   }
/*      */   
/*      */   private static class RefDataStore extends WeakReference<IDataStorePosition> {
/*      */     private final DataStorePosition pos;
/*      */     
/*      */     public RefDataStore(DataStorePosition referent) {
/*  983 */       this(new DataStoreContent.DelegateDSPosition(referent));
/*      */     }
/*      */     
/*      */     public RefDataStore(DataStoreContent.DelegateDSPosition referent) {
/*  987 */       super();
/*  988 */       this.pos = referent.pos;
/*      */     }
/*      */   }
/*      */   
/*      */   private static class DelegateDSPosition implements IDataStorePosition {
/*      */     private final DataStorePosition pos;
/*      */     
/*      */     public DelegateDSPosition(DataStorePosition pos) {
/*  996 */       this.pos = pos;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public int getOffset()
/*      */     {
/* 1004 */       return this.pos.getOffset();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public long getLineStartRE()
/*      */     {
/* 1012 */       return this.pos.getLineStartRE();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public int getPositionInLineRE()
/*      */     {
/* 1020 */       return this.pos.getPositionInLineRE();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public int getLineNumberRE()
/*      */     {
/* 1028 */       return this.pos.getLineNumberRE();
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public AbstractLine getLineRE()
/*      */     {
/* 1036 */       return this.pos.getLineRE();
/*      */     }
/*      */   }
/*      */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/DataStoreContent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */