/*     */ package net.sf.RecordEditor.re.file;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.nio.file.CopyOption;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Paths;
/*     */ import java.nio.file.StandardCopyOption;
/*     */ import java.util.List;
/*     */ import java.util.zip.GZIPOutputStream;
/*     */ import net.sf.JRecord.Common.RecordException;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.IO.AbstractLineWriter;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.fileStorage.DataStoreLarge;
/*     */ import net.sf.RecordEditor.utils.fileStorage.IDataStore;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions.InternalBoolOption;
/*     */ 
/*     */ 
/*     */ public class FileWriter
/*     */ {
/*     */   private static final long INTERVAL = 1500000000L;
/*     */   private List<AbstractLine> lines;
/*     */   private String fileName;
/*     */   private boolean backup;
/*     */   private boolean isGZip;
/*     */   private AbstractLineWriter writer;
/*     */   private AbstractLayoutDetails layout;
/*     */   private long lastTime;
/*     */   private int count;
/*  36 */   private boolean done = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FileWriter(List<AbstractLine> pLines, AbstractLayoutDetails pLayout, String pFileName, boolean pBackup, boolean pIsGZip, AbstractLineWriter pWriter)
/*     */     throws RecordException
/*     */   {
/*  46 */     this.lines = pLines;
/*  47 */     this.layout = pLayout;
/*  48 */     this.fileName = pFileName;
/*  49 */     this.backup = pBackup;
/*  50 */     this.isGZip = pIsGZip;
/*  51 */     this.writer = pWriter;
/*     */     
/*  53 */     if (this.writer == null) {
/*  54 */       throw new RecordException("No file writer available");
/*     */     }
/*     */   }
/*     */   
/*     */   public void doWrite()
/*     */     throws IOException
/*     */   {
/*  61 */     String oFname = this.fileName + ".~tmp~";
/*  62 */     int defaultBufSize = 65536;
/*  63 */     long totalSize = this.lines.size() * (this.layout.getMaximumRecordLength() > 0 ? this.layout.getMaximumRecordLength() : 20);
/*  64 */     int bufSize = calcBufferSize(defaultBufSize, totalSize);
/*     */     
/*  66 */     if ((Common.OPTIONS.overWriteOutputFile.isSelected()) || (!this.backup)) {
/*  67 */       if ((this.backup) && (Parameters.JAVA_VERSION > 6.9999D)) {
/*  68 */         copyFile(this.fileName, this.fileName + "~");
/*     */       }
/*     */       
/*  71 */       write(this.fileName, defaultBufSize, bufSize);
/*  72 */       return;
/*     */     }
/*     */     
/*  75 */     write(oFname, defaultBufSize, bufSize);
/*     */     try
/*     */     {
/*  78 */       if ((this.lines instanceof DataStoreLarge)) {
/*  79 */         ((DataStoreLarge)this.lines).rename(this.fileName, this.fileName + "~");
/*  80 */       } else if (this.backup) {
/*  81 */         Parameters.renameFile(this.fileName);
/*     */       }
/*     */     } catch (Exception e2) {
/*  84 */       e2.printStackTrace();
/*     */     }
/*     */     
/*  87 */     this.lines = null;
/*     */     
/*     */     try
/*     */     {
/*  91 */       Parameters.renameFile(oFname, this.fileName);
/*     */     } catch (Exception e) {
/*  93 */       e.printStackTrace();
/*  94 */       Common.logMsg("Error renaming new file to old file, file not saved:\n" + e, e);
/*     */       
/*  96 */       copyFile(oFname, this.fileName);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void copyFile(String oFname, String newName)
/*     */   {
/* 108 */     if (Parameters.JAVA_VERSION > 6.9999D) {
/*     */       try {
/* 110 */         Files.copy(Paths.get(oFname, new String[0]), Paths.get(newName, new String[0]), new CopyOption[] { StandardCopyOption.REPLACE_EXISTING });
/*     */       } catch (Throwable e1) {
/* 112 */         e1.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void write(String oFname, int defaultBufSize, int bufSize) throws IOException {
/* 118 */     if (this.isGZip) {
/* 119 */       FileOutputStream fs = new FileOutputStream(oFname);
/* 120 */       this.writer.open(new GZIPOutputStream(fs, bufSize));
/*     */       
/* 122 */       writeToFile(this.writer, this.lines);
/* 123 */       fs.close();
/* 124 */     } else if (defaultBufSize == bufSize) {
/* 125 */       this.writer.open(oFname);
/* 126 */       writeToFile(this.writer, this.lines);
/*     */     } else {
/* 128 */       FileOutputStream fs = new FileOutputStream(oFname);
/* 129 */       this.writer.open(new BufferedOutputStream(fs, bufSize));
/* 130 */       writeToFile(this.writer, this.lines);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeToFile(AbstractLineWriter writer, List<AbstractLine> pLines)
/*     */     throws IOException
/*     */   {
/* 145 */     int i = 0;
/*     */     
/* 147 */     System.out.println("Starting to write the file !!!");
/*     */     
/* 149 */     ProgressDisplay progress = null;
/*     */     
/* 151 */     this.lastTime = System.nanoTime();
/* 152 */     int numLines = pLines.size();
/*     */     try
/*     */     {
/* 155 */       if (numLines > 30000) {
/* 156 */         progress = new ProgressDisplay("Writing", this.fileName);
/* 157 */         System.out.println("  -- Adding Progress !!!");
/*     */       }
/*     */       
/* 160 */       writer.setLayout(this.layout);
/*     */       
/* 162 */       if ((pLines instanceof IDataStore))
/*     */       {
/* 164 */         IDataStore ds = (IDataStore)pLines;
/* 165 */         System.out.println("  -- Is a datastore");
/*     */         
/* 167 */         for (i = 0; i < pLines.size(); i++) {
/* 168 */           writer.write(ds.getTempLineRE(i));
/* 169 */           check(progress, i, numLines);
/*     */         }
/*     */       } else {
/* 172 */         System.out.println("  -- Is a List");
/* 173 */         for (i = 0; i < pLines.size(); i++) {
/* 174 */           writer.write((AbstractLine)pLines.get(i));
/* 175 */           check(progress, i, numLines);
/*     */         }
/*     */       }
/* 178 */       System.out.println("  -- File Written");
/*     */     } catch (IOException e) {
/* 180 */       System.out.println();
/* 181 */       System.out.println("    **** Line:" + i + "IOError: " + e);
/* 182 */       System.out.println();
/*     */     } catch (RuntimeException e) {
/* 184 */       System.out.println();
/* 185 */       System.out.println("    **** Line: " + i + "RunTime Error: " + e);
/* 186 */       System.out.println();
/*     */     } finally {
/* 188 */       writer.close();
/*     */       
/* 190 */       if (progress != null) {
/* 191 */         progress.done();
/*     */       }
/*     */       
/* 194 */       this.done = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void check(ProgressDisplay progress, int soFar, int total)
/*     */   {
/* 201 */     if ((progress != null) && (this.count++ > 2000)) {
/* 202 */       this.count = 0;
/*     */       
/* 204 */       long t = System.nanoTime();
/*     */       
/*     */ 
/* 207 */       if (t - this.lastTime > 1500000000L) {
/* 208 */         double ratio = soFar / total;
/* 209 */         progress.updateDisplay(" Written: " + soFar + "\n   Total: " + total, (int)(100.0D * ratio));
/*     */         
/*     */ 
/*     */ 
/* 213 */         this.lastTime = t;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isDone()
/*     */   {
/* 223 */     return this.done;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static int calcBufferSize(int bufSize, long fileLength)
/*     */   {
/* 232 */     if (fileLength > 600000000L) {
/* 233 */       bufSize = 4194304;
/* 234 */     } else if (fileLength > 30000000L) {
/* 235 */       bufSize = 1048576;
/* 236 */     } else if (fileLength > 5000000L) {
/* 237 */       bufSize = 262144;
/*     */     }
/* 239 */     return bufSize;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/file/FileWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */