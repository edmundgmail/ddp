package net.sf.RecordEditor.re.openFile;

import javax.swing.JMenu;
import net.sf.RecordEditor.utils.LayoutConnection;
import net.sf.RecordEditor.utils.swing.BasePanel;

public abstract interface OpenFileInterface
  extends LayoutConnection
{
  public abstract BasePanel getPanel();
  
  public abstract JMenu getRecentFileMenu();
  
  public abstract JMenu getRecentDirectoryMenu();
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/openFile/OpenFileInterface.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */