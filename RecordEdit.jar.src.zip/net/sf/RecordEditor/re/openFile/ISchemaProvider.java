package net.sf.RecordEditor.re.openFile;

import net.sf.JRecord.Details.AbstractLayoutDetails;

public abstract interface ISchemaProvider
{
  public abstract AbstractLayoutDetails getRecordLayout(String paramString1, String paramString2);
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/openFile/ISchemaProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */