/*     */ package net.sf.RecordEditor.re.openFile;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.params.BoolOpt;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions.IntOpt;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions.InternalBoolOption;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.FileTreeComboItem;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.IFileLists;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RecentFiles
/*     */   implements IFileLists
/*     */ {
/*     */   public static final int RECENT_FILE_LIST = 25;
/*     */   public static final int DIRECTORY_LIST_SIZE = 14;
/*     */   public static final int RF_NONE = -1;
/*     */   public static final int RF_VELOCITY = 4;
/*     */   public static final int RF_XSLT = 5;
/*     */   public static final int RF_SCRIPT = 6;
/*     */   private static final int RF_FILE_MODE = -2;
/*     */   private static final int RF_DIRECTORY_MODE = -3;
/*     */   private static final int FILE_HISTORY = 800;
/*     */   private static final int HASH_MAP_SIZE = 1200;
/*  49 */   private static final int LAUNCH_EDITOR_MATCH_NUMBER = 5 - Common.OPTIONS.launchIfMatch.get();
/*     */   private static final String DIRECTORY_STRING = "<directories>";
/*     */   private static final String EXTENSION_STRING = "<extensions>";
/*     */   private static final String EXTENSION_VELOCITY = "<velocity>";
/*     */   private static final String EXTENSION_XSLT = "<xslt>";
/*     */   private static final String EXTENSION_SCRIPT = "<script>";
/*  55 */   private static final String[] EXTENSION_NAME = { null, null, null, null, "<velocity>", "<xslt>", "<script>" };
/*     */   
/*     */   private static final String SEPERATOR = "\t\t";
/*     */   
/*     */   private final String recentFileName;
/*     */   
/*  61 */   private String lastFile = null;
/*  62 */   private int lastIdx = 0;
/*     */   
/*     */ 
/*  65 */   private int fileNum = 0;
/*     */   
/*  67 */   private boolean checkDirs = true;
/*     */   
/*     */ 
/*     */ 
/*  71 */   private ArrayList<HashMap<String, String>> recentMap = new ArrayList(5);
/*     */   
/*  73 */   private int[] truncSizes = { Integer.MAX_VALUE, Common.OPTIONS.significantCharInFiles3.get(), Common.OPTIONS.significantCharInFiles2.get(), Common.OPTIONS.significantCharInFiles1.get() };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  78 */   private boolean editorLaunch = false;
/*     */   
/*  80 */   private String[] fileNames = new String['̠'];
/*  81 */   private String[] layouts = new String['̠'];
/*  82 */   private String[] directory = new String['̠'];
/*  83 */   private int[] prevFiles = new int[25];
/*  84 */   private ArrayList<String> directories = new ArrayList(16);
/*     */   
/*     */   private FormatFileName selection;
/*     */   
/*  88 */   private ArrayList<ChangeListener> changeListners = new ArrayList();
/*     */   
/*  90 */   private static RecentFiles mainRecentFile = null;
/*     */   
/*  92 */   private static RecentFiles last = null;
/*     */   
/*     */ 
/*     */   private final boolean layoutHasFileVars;
/*     */   
/*     */ 
/*     */   private final String defaultDirectory;
/*     */   
/*     */ 
/*     */ 
/*     */   public RecentFiles(String fileName, FormatFileName layoutSelection, boolean hasFileVars, String defaultDirectory)
/*     */   {
/* 104 */     this.layoutHasFileVars = hasFileVars;
/* 105 */     this.defaultDirectory = defaultDirectory;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 113 */     for (int i = 0; i < EXTENSION_NAME.length; i++) {
/* 114 */       this.recentMap.add(new HashMap(1200));
/*     */     }
/*     */     
/* 117 */     HashMap<String, String> extensionMap = (HashMap)this.recentMap.get(4);
/*     */     
/* 119 */     this.recentFileName = fileName;
/* 120 */     this.selection = layoutSelection;
/* 121 */     this.fileNum = 0;
/*     */     
/* 123 */     last = this;
/* 124 */     if (mainRecentFile == null) {
/* 125 */       mainRecentFile = this;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 130 */       FileReader br = new FileReader(this.recentFileName);
/* 131 */       BufferedReader r = new BufferedReader(br);
/* 132 */       int mode = -2;
/*     */       String l;
/* 134 */       while ((l = r.readLine()) != null) {
/* 135 */         StringTokenizer t = new StringTokenizer(l, "\t\t");
/* 136 */         if (t.hasMoreElements()) {
/* 137 */           String recentFileNormal = t.nextToken();
/* 138 */           String recentFile = correctCase(recentFileNormal);
/*     */           
/* 140 */           if ((recentFile != null) && (!"".equals(recentFile))) {
/* 141 */             if (recentFile.toLowerCase().equals("<directories>")) {
/* 142 */               mode = -3;
/* 143 */             } else if (recentFile.toLowerCase().equals("<extensions>")) {
/* 144 */               String s = t.nextToken();
/*     */               
/* 146 */               mode = 4;
/* 147 */               if (s != null) {
/* 148 */                 if (s.toLowerCase().equals("<xslt>")) {
/* 149 */                   mode = 5;
/* 150 */                 } else if (s.toLowerCase().equals("<script>"))
/* 151 */                   mode = 6;
/*     */               }
/* 153 */               extensionMap = (HashMap)this.recentMap.get(mode);
/*     */             } else {
/* 155 */               switch (mode) {
/*     */               case -3: 
/* 157 */                 if ((this.directories.size() < 14) && (l != null) && ((l = l.trim()).length() > 0)) {
/* 158 */                   this.directories.add(Parameters.expandVars(l));
/*     */                 }
/*     */                 break;
/*     */               case -2: 
/* 162 */                 if (t.hasMoreElements()) {
/* 163 */                   String recentLayout = t.nextToken();
/*     */                   
/* 165 */                   if ((hasFileVars) && (recentLayout != null))
/*     */                   {
/* 167 */                     recentLayout = Parameters.expandVars(recentLayout);
/*     */                   }
/* 169 */                   String dir = "";
/* 170 */                   if (t.hasMoreElements()) {
/* 171 */                     dir = t.nextToken();
/* 172 */                     if (dir != null) {
/* 173 */                       dir = Parameters.expandVars(dir);
/*     */                     }
/*     */                   }
/*     */                   
/* 177 */                   storeFile(dir, recentFileNormal, recentLayout);
/*     */                 }
/*     */                 
/*     */ 
/*     */                 break;
/*     */               default: 
/* 183 */                 if (t.hasMoreElements()) {
/* 184 */                   String extension = t.nextToken();
/*     */                   
/* 186 */                   if ((extension != null) && (!"".equals(extension))) {
/* 187 */                     extensionMap.put(recentFile, extension);
/*     */                   }
/*     */                 }
/*     */                 break;
/*     */               }
/*     */               
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 197 */       r.close();
/* 198 */       br.close();
/* 199 */       buildRecentList();
/*     */     } catch (Exception e) {
/* 201 */       for (i = this.fileNum; i < 800; i++) {
/* 202 */         this.fileNames[i] = null;
/* 203 */         this.directory[i] = null;
/*     */       }
/* 205 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void putFileLayout(String fileName, String layoutName)
/*     */   {
/* 217 */     String strippedName = Common.stripDirectory(fileName);
/*     */     
/* 219 */     if ((strippedName != null) && (!"".equals(strippedName)) && (layoutName != null) && (!"".equals(layoutName)) && (!"FileWizard".equalsIgnoreCase(layoutName)))
/*     */     {
/* 221 */       String dir = fileName.substring(0, fileName.length() - strippedName.length() - 1);
/*     */       
/* 223 */       if (correctCase(strippedName).equals(this.lastFile)) {
/* 224 */         this.layouts[this.lastIdx] = layoutName;
/* 225 */         putLayout(strippedName, layoutName);
/*     */       } else {
/* 227 */         storeFile(dir, strippedName, layoutName);
/* 228 */         buildRecentList();
/*     */       }
/*     */       
/* 231 */       if ((dir != null) && (dir.length() > 0) && (this.directories.size() >= 0)) {
/* 232 */         if (Common.IS_WINDOWS) {
/* 233 */           for (int i = this.directories.size() - 1; i >= 0; i--) {
/* 234 */             if (dir.equalsIgnoreCase((String)this.directories.get(i))) {
/* 235 */               this.directories.remove(i);
/*     */             }
/*     */           }
/*     */         } else {
/* 239 */           this.directories.remove(dir);
/*     */         }
/* 241 */         this.directories.add(0, dir);
/*     */         
/* 243 */         while (this.directories.size() > 14) {
/* 244 */           this.directories.remove(this.directories.size() - 1);
/*     */         }
/*     */       }
/* 247 */       save();
/*     */     }
/*     */   }
/*     */   
/*     */   public void putFileExtension(int type, String filename, String ext, String defaultExt)
/*     */   {
/* 253 */     String strippedName = correctCase(Common.stripDirectory(filename));
/* 254 */     if (isExtensionType(type)) {
/* 255 */       if (ext.equals(defaultExt)) {
/* 256 */         if (((HashMap)this.recentMap.get(type)).containsKey(strippedName)) {
/* 257 */           ((HashMap)this.recentMap.get(type)).remove(strippedName);
/* 258 */           save();
/*     */         }
/*     */       } else {
/* 261 */         ((HashMap)this.recentMap.get(type)).put(strippedName, ext);
/* 262 */         save();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void save()
/*     */   {
/*     */     try
/*     */     {
/* 274 */       FileWriter wr = new FileWriter(this.recentFileName);
/* 275 */       BufferedWriter w = new BufferedWriter(wr);
/*     */       
/* 277 */       for (int i = this.fileNum; i < 800; i++) {
/* 278 */         if (this.fileNames[i] != null) {
/* 279 */           w.write(this.fileNames[i] + "\t\t" + getLayout(i) + "\t\t" + getDirectory(i));
/* 280 */           w.newLine();
/*     */         }
/*     */       }
/* 283 */       for (i = 0; i <= this.fileNum; i++) {
/* 284 */         if (this.fileNames[i] != null) {
/* 285 */           w.write(this.fileNames[i] + "\t\t" + getLayout(i) + "\t\t" + getDirectory(i));
/* 286 */           w.newLine();
/*     */         }
/*     */       }
/*     */       
/* 290 */       saveDirectories(w);
/* 291 */       saveExtensions(w, 4);
/* 292 */       saveExtensions(w, 5);
/* 293 */       saveExtensions(w, 6);
/*     */       
/* 295 */       w.close();
/* 296 */       wr.close();
/*     */     } catch (Exception e) {
/* 298 */       e.printStackTrace();
/*     */     }
/*     */     
/* 301 */     notifyChgListners();
/*     */   }
/*     */   
/*     */   private String getLayout(int i) {
/* 305 */     String r = this.layouts[i];
/* 306 */     if ((this.layoutHasFileVars) && (r != null)) {
/* 307 */       r = Parameters.encodeVars(r);
/*     */     }
/* 309 */     return r;
/*     */   }
/*     */   
/* 312 */   private String getDirectory(int i) { String r = this.directory[i];
/* 313 */     if (r != null) {
/* 314 */       r = Parameters.encodeVars(r);
/*     */     }
/* 316 */     return r;
/*     */   }
/*     */   
/*     */   private void saveDirectories(BufferedWriter w) throws IOException {
/* 320 */     if (this.directories.size() > 0) {
/* 321 */       w.write("<directories>");
/* 322 */       w.write("\t\t");
/* 323 */       w.write("");
/* 324 */       w.newLine();
/*     */       
/* 326 */       for (String s : this.directories) {
/* 327 */         w.write(Parameters.encodeVars(s));
/* 328 */         w.newLine();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void saveExtensions(BufferedWriter w, int mode) throws IOException {
/* 334 */     w.write("<extensions>");
/* 335 */     w.write("\t\t");
/* 336 */     w.write(EXTENSION_NAME[mode]);
/* 337 */     w.newLine();
/*     */     
/* 339 */     for (Map.Entry<String, String> e : ((HashMap)this.recentMap.get(mode)).entrySet()) {
/* 340 */       w.write((String)e.getKey());
/* 341 */       w.write("\t\t");
/* 342 */       w.write((String)e.getValue());
/* 343 */       w.newLine();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLayoutName(String fileName, File f)
/*     */   {
/* 354 */     String strippedFile = correctCase(Common.stripDirectory(fileName));
/*     */     
/* 356 */     this.editorLaunch = false;
/*     */     
/*     */ 
/*     */ 
/* 360 */     for (int i = 0; i < this.truncSizes.length; i++)
/*     */     {
/* 362 */       String recentLayout = (String)((HashMap)this.recentMap.get(i)).get(adj4lookup(i, strippedFile));
/* 363 */       if ((recentLayout != null) && (!"".equals(recentLayout))) {
/* 364 */         this.editorLaunch = (i < LAUNCH_EDITOR_MATCH_NUMBER);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 370 */         return recentLayout;
/*     */       }
/*     */     }
/*     */     
/* 374 */     String s = strippedFile.toLowerCase();
/* 375 */     if ((f.exists()) && (f.length() > 0L)) {
/* 376 */       if ((s.endsWith("xml")) || (s.endsWith("xls")))
/* 377 */         return this.selection.formatLayoutName("XML - Build Layout");
/* 378 */       if (s.endsWith("csv"))
/* 379 */         return this.selection.formatLayoutName("Generic CSV - enter details");
/* 380 */       if (s.endsWith(".po"))
/* 381 */         return this.selection.formatLayoutName("GetText_PO");
/* 382 */       if (s.endsWith(".properties"))
/* 383 */         return this.selection.formatLayoutName("TipDetails");
/* 384 */       if ((Common.OPTIONS.fileWizardAvailable.isSelected()) && (Common.OPTIONS.useFileWizard.isSelected()))
/*     */       {
/* 386 */         return this.selection.formatLayoutName("FileWizard");
/*     */       }
/*     */     }
/* 389 */     return "";
/*     */   }
/*     */   
/*     */   public String getFileExtension(int type, String filename, String defaultExt)
/*     */   {
/* 394 */     String strippedName = correctCase(Common.stripDirectory(filename));
/* 395 */     if ((isExtensionType(type)) && (((HashMap)this.recentMap.get(type)).containsKey(strippedName))) {
/* 396 */       return (String)((HashMap)this.recentMap.get(type)).get(strippedName);
/*     */     }
/*     */     
/* 399 */     return defaultExt;
/*     */   }
/*     */   
/*     */   private boolean isExtensionType(int type) {
/* 403 */     return (type >= this.truncSizes.length) || (type < this.recentMap.size());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void storeFile(String dir, String filename, String layout)
/*     */   {
/* 414 */     putLayout(filename, layout);
/*     */     
/* 416 */     this.fileNames[this.fileNum] = filename;
/* 417 */     this.directory[this.fileNum] = dir;
/* 418 */     this.layouts[this.fileNum] = layout;
/*     */     
/* 420 */     this.lastIdx = this.fileNum;
/* 421 */     this.lastFile = correctCase(filename);
/* 422 */     this.fileNum += 1;
/* 423 */     if (this.fileNum >= 800) {
/* 424 */       this.fileNum = 0;
/*     */     }
/*     */   }
/*     */   
/*     */   private void buildRecentList() {
/* 429 */     int st = this.fileNum;
/* 430 */     int i = this.fileNum - 1;
/* 431 */     int j = 0;
/* 432 */     HashMap<String, String> used = new HashMap();
/*     */     
/* 434 */     while ((j < this.prevFiles.length) && (i != st)) {
/* 435 */       if (i < 0) {
/* 436 */         i = 799;
/*     */       }
/*     */       
/* 439 */       if ((this.directory[i] != null) && (!"".equals(this.directory[i])) && (this.fileNames[i] != null) && (!"".equals(this.fileNames[i])) && (!used.containsKey(this.fileNames[i])))
/*     */       {
/*     */ 
/* 442 */         used.put(this.fileNames[i], this.fileNames[i]);
/*     */         
/* 444 */         this.prevFiles[(j++)] = i;
/*     */       }
/* 446 */       i--;
/*     */     }
/*     */     
/*     */ 
/* 450 */     for (i = j; i < this.prevFiles.length; i++) {
/* 451 */       this.prevFiles[i] = -1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void putLayout(String filename, String layout)
/*     */   {
/* 463 */     String lookup = correctCase(filename);
/* 464 */     for (int i = 0; i < this.truncSizes.length; i++)
/*     */     {
/*     */ 
/*     */ 
/* 468 */       ((HashMap)this.recentMap.get(i)).put(adj4lookup(i, lookup), layout);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String adj4lookup(int idx, String fileName)
/*     */   {
/* 484 */     return fileName.substring(0, Math.min(fileName.length(), this.truncSizes[idx]));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String correctCase(String fileName)
/*     */   {
/* 497 */     if ((fileName != null) && ("\\".equals(Common.FILE_SEPERATOR))) {
/* 498 */       return fileName.toLowerCase();
/*     */     }
/* 500 */     return fileName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isEditorLaunch()
/*     */   {
/* 507 */     return this.editorLaunch;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRecentFileName(int idx)
/*     */   {
/* 516 */     String ret = "";
/* 517 */     if ((idx >= 0) && (idx < this.prevFiles.length) && (this.prevFiles[idx] >= 0)) {
/* 518 */       String s = this.fileNames[this.prevFiles[idx]];
/* 519 */       if (s != null) {
/* 520 */         ret = s;
/*     */       }
/*     */     }
/*     */     
/* 524 */     return ret;
/*     */   }
/*     */   
/*     */   public String getRecentFullFileName(int idx) {
/* 528 */     String ret = "";
/* 529 */     if ((idx >= 0) && (idx < this.prevFiles.length) && (this.prevFiles[idx] >= 0)) {
/* 530 */       String s = this.directory[this.prevFiles[idx]] + Common.FILE_SEPERATOR + this.fileNames[this.prevFiles[idx]];
/* 531 */       if (s != null) {
/* 532 */         ret = s;
/*     */       }
/*     */     }
/*     */     
/* 536 */     return ret;
/*     */   }
/*     */   
/*     */   private String getRecentDirectory(int idx) {
/* 540 */     String ret = "";
/* 541 */     if ((idx >= 0) && (idx < this.prevFiles.length) && (this.prevFiles[idx] >= 0)) {
/* 542 */       String s = this.directory[this.prevFiles[idx]];
/* 543 */       if (s != null) {
/* 544 */         ret = s;
/*     */       }
/*     */     }
/*     */     
/* 548 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getRecentLayoutName(int idx)
/*     */   {
/* 558 */     String ret = "";
/* 559 */     if ((idx >= 0) && (idx < this.prevFiles.length) && (this.prevFiles[idx] >= 0)) {
/* 560 */       String s = this.layouts[this.prevFiles[idx]];
/* 561 */       if (s != null) {
/* 562 */         ret = s;
/*     */       }
/*     */     }
/*     */     
/* 566 */     return ret;
/*     */   }
/*     */   
/*     */   private void notifyChgListners() {
/* 570 */     for (ChangeListener l : this.changeListners) {
/* 571 */       l.stateChanged(null);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addChangeListner(ChangeListener l) {
/* 576 */     this.changeListners.add(l);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static RecentFiles getLast()
/*     */   {
/* 583 */     return last;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final List<FileTreeComboItem> getFileComboList()
/*     */   {
/* 593 */     int len = Math.min(25, 15);
/* 594 */     List<FileTreeComboItem> list = new ArrayList(len);
/*     */     
/*     */ 
/*     */ 
/* 598 */     for (int i = 0; i < len; i++) {
/* 599 */       String s = getRecentFullFileName(i);
/* 600 */       File f; if ((!"".equals(s)) && ((f = new File(s)).exists())) {
/* 601 */         list.add(new FileTreeComboItem(Integer.valueOf(i), f));
/*     */       }
/*     */     }
/*     */     
/* 605 */     return list;
/*     */   }
/*     */   
/*     */   public final String getLastDirectory() {
/* 609 */     List<File> l = getDirectoryList();
/* 610 */     String s = null;
/* 611 */     if ((l.size() > 0) && (l.get(0) != null)) {
/* 612 */       s = ((File)l.get(0)).getPath();
/* 613 */       if (!s.endsWith("*")) {
/* 614 */         s = s + "*";
/*     */       }
/*     */     }
/* 617 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final List<File> getDirectoryList()
/*     */   {
/* 624 */     if ((this.checkDirs) && (this.directories.size() < 14)) {
/* 625 */       int size = 10;
/* 626 */       HashSet<String> used = new HashSet(size * 2);
/* 627 */       String last = "";
/*     */       
/* 629 */       for (String d : this.directories) {
/* 630 */         used.add(d);
/*     */       }
/*     */       
/* 633 */       for (int i = 0; i < 25; i++) {
/* 634 */         String s = getRecentDirectory(i);
/* 635 */         if ((s != null) && (s.length() > 0) && (!s.equals(last)) && 
/* 636 */           (!used.contains(s))) {
/* 637 */           used.add(s);
/* 638 */           this.directories.add(s);
/*     */           
/* 640 */           if (this.directories.size() >= 13) {
/*     */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 648 */     this.checkDirs = false;
/*     */     
/* 650 */     ArrayList<File> ret = new ArrayList(this.directories.size());
/* 651 */     for (String d : this.directories) {
/* 652 */       ret.add(new File(d));
/*     */     }
/*     */     
/*     */     File f;
/* 656 */     if ((ret.size() == 0) && (this.defaultDirectory != null) && (this.defaultDirectory.length() > 0) && ((f = new File(this.defaultDirectory)).isDirectory()) && (f.exists()))
/*     */     {
/* 658 */       ret.add(f);
/*     */     }
/* 660 */     return ret;
/*     */   }
/*     */   
/*     */   public static final RecentFiles getMainRecentFile() {
/* 664 */     return mainRecentFile;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/openFile/RecentFiles.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */