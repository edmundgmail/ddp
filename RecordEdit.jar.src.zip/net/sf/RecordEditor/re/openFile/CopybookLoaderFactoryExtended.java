/*    */ package net.sf.RecordEditor.re.openFile;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import net.sf.JRecord.Common.Conversion;
/*    */ import net.sf.JRecord.Common.RecordException;
/*    */ import net.sf.JRecord.Details.DefaultLineProvider;
/*    */ import net.sf.JRecord.External.BaseCopybookLoader;
/*    */ import net.sf.JRecord.External.CopybookLoaderFactory;
/*    */ import net.sf.JRecord.External.ExternalRecord;
/*    */ import net.sf.JRecord.External.ToExternalRecord;
/*    */ import net.sf.JRecord.Log.AbsSSLogger;
/*    */ import net.sf.RecordEditor.re.util.csv.GenericCsvReader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CopybookLoaderFactoryExtended
/*    */   extends CopybookLoaderFactory
/*    */ {
/* 24 */   private static CopybookLoaderFactory instance = new CopybookLoaderFactoryExtended();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void registerAll()
/*    */   {
/* 41 */     registerStandardLoaders1();
/* 42 */     register("Generic Csv", GenericCsv.class, "");
/*    */     
/* 44 */     registerStandardLoaders2();
/* 45 */     this.csv1 -= 1;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public static final CopybookLoaderFactory getInstance()
/*    */   {
/* 52 */     return instance;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static class GenericCsv
/*    */     extends BaseCopybookLoader
/*    */   {
/*    */     public ExternalRecord loadCopyBook(String copyBookFile, int splitCopybookOption, int dbIdx, String font, int binFormat, int systemId, AbsSSLogger log)
/*    */       throws IOException, RecordException
/*    */     {
/* 68 */       GenericCsvReader r = new GenericCsvReader(new DefaultLineProvider());
/* 69 */       r.open(copyBookFile);
/*    */       
/* 71 */       r.read();
/*    */       
/* 73 */       r.close();
/*    */       
/* 75 */       return ToExternalRecord.getInstance().getExternalRecord(r.getLayout(), Conversion.getCopyBookId(copyBookFile), systemId);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/openFile/CopybookLoaderFactoryExtended.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */