/*    */ package net.sf.RecordEditor.re.openFile;
/*    */ 
/*    */ import net.sf.RecordEditor.utils.CopyBookInterface;
/*    */ 
/*    */ public class LayoutSelectionDBCreator implements AbstractLayoutSelectCreator<LayoutSelectionDB>
/*    */ {
/*    */   private CopyBookInterface cpyInterface;
/*    */   
/*    */   public LayoutSelectionDBCreator(CopyBookInterface copyBookInterface) {
/* 10 */     this.cpyInterface = copyBookInterface;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public LayoutSelectionDB create()
/*    */   {
/* 19 */     LayoutSelectionDB ret = new LayoutSelectionDB(this.cpyInterface, true);
/*    */     
/* 21 */     ret.setLoadFromFile(true);
/*    */     
/* 23 */     return ret;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/openFile/LayoutSelectionDBCreator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */