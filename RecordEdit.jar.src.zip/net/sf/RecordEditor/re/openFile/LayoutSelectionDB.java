/*     */ package net.sf.RecordEditor.re.openFile;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextArea;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.RecordEditor.utils.CopyBookInterface;
/*     */ import net.sf.RecordEditor.utils.LayoutItem;
/*     */ import net.sf.RecordEditor.utils.SystemItem;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.msg.UtMessages;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMsg;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.TreeComboFileSelect;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LayoutSelectionDB
/*     */   extends AbstractLayoutSelection
/*     */   implements ActionListener
/*     */ {
/*  39 */   private static final String ALL_SYSTEMS = LangConversion.convertComboItms("Layout Selection", "<All>");
/*  40 */   private JComboBox dbCombo = new JComboBox();
/*  41 */   private JComboBox systemCombo = new JComboBox();
/*  42 */   private JComboBox layoutCombo = new JComboBox();
/*  43 */   private JTextArea description = new JTextArea();
/*  44 */   private JTextArea message = null;
/*     */   
/*  46 */   private JButton reload = SwingUtils.newButton("Reload from DB", Common.getRecordIcon(42));
/*     */   
/*     */ 
/*     */ 
/*  50 */   private ArrayList<SystemItem> systems = new ArrayList();
/*  51 */   private ArrayList<LayoutItem> layouts = new ArrayList();
/*     */   
/*  53 */   private int[] layoutId = null;
/*     */   
/*     */ 
/*  56 */   private boolean dbLink = true;
/*     */   
/*     */   private CopyBookInterface copyBookInterface;
/*     */   
/*  60 */   private String lastLayoutName = "";
/*  61 */   private AbstractLayoutDetails lastLayout = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LayoutSelectionDB(CopyBookInterface pInterfaceToCopyBooks, boolean doPrimingRead)
/*     */   {
/*  73 */     boolean free = Common.isSetDoFree(false);
/*  74 */     int con = Common.getConnectionIndex();
/*     */     
/*  76 */     this.copyBookInterface = pInterfaceToCopyBooks;
/*     */     
/*     */ 
/*  79 */     loadDBs();
/*  80 */     if (con < this.dbCombo.getItemCount()) {
/*  81 */       this.dbCombo.setSelectedIndex(con);
/*     */     }
/*     */     
/*  84 */     loadSystems();
/*  85 */     this.copyBookInterface.loadLayouts(this.layouts);
/*  86 */     loadLayoutCombo();
/*     */     
/*  88 */     this.reload.addActionListener(this);
/*     */     
/*  90 */     this.dbCombo.addActionListener(this);
/*  91 */     this.systemCombo.addActionListener(this);
/*  92 */     this.layoutCombo.addActionListener(this);
/*  93 */     Common.setDoFree(free, con);
/*     */   }
/*     */   
/*     */   public LayoutSelectionDB(CopyBookInterface pInterfaceToCopyBooks, JTextArea messageFld, boolean doPrimingRead)
/*     */   {
/*  98 */     this(pInterfaceToCopyBooks, doPrimingRead);
/*     */     
/* 100 */     this.message = messageFld;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addLayoutSelection(BasePanel pnl, TreeComboFileSelect file, JPanel goPanel, JButton layoutCreate1, JButton layoutCreate2)
/*     */   {
/* 111 */     JButton tmpBtn = new JButton("XX");
/* 112 */     pnl.addLineRE("Data Base", this.dbCombo, this.reload);
/* 113 */     pnl.addLineRE("System", this.systemCombo, tmpBtn);
/* 114 */     pnl.addLineRE("Record Layout", this.layoutCombo, layoutCreate1);
/* 115 */     if (layoutCreate2 != null) {
/* 116 */       pnl.addLineRE("", null, layoutCreate2);
/*     */     }
/* 118 */     pnl.setGapRE(BasePanel.GAP1);
/* 119 */     pnl.addLineRE("Description", this.description, goPanel);
/*     */     
/* 121 */     double size = 0.0D;
/* 122 */     if (goPanel != null) {
/*     */       try {
/* 124 */         size = goPanel.getPreferredSize().getHeight();
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/* 128 */     pnl.setHeightRE(Math.max(BasePanel.NORMAL_HEIGHT * 3.0D + 3.0D, size));
/*     */     
/* 130 */     tmpBtn.setVisible(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void loadDBs()
/*     */   {
/* 140 */     String[] dbs = Common.getSourceId();
/*     */     
/* 142 */     for (int i = 0; (i < dbs.length) && (dbs[i] != null) && (!dbs[i].equals("")); i++) {
/* 143 */       this.dbCombo.addItem(dbs[i]);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void loadLayoutCombo()
/*     */   {
/* 154 */     int size = this.layouts.size();
/* 155 */     int sysIdx = this.systemCombo.getSelectedIndex();
/*     */     
/* 157 */     if ((this.layoutId == null) || (this.layoutId.length < size)) {
/* 158 */       this.layoutId = new int[size];
/*     */     }
/*     */     
/* 161 */     this.layoutCombo.removeAllItems();
/* 162 */     if (sysIdx <= 0) {
/* 163 */       for (int i = 0; i < size; i++) {
/* 164 */         LayoutItem layout = (LayoutItem)this.layouts.get(i);
/* 165 */         this.layoutCombo.addItem(layout.getRecordName());
/* 166 */         this.layoutId[i] = i;
/*     */       }
/*     */     }
/* 169 */     int sys = ((SystemItem)this.systems.get(sysIdx - 1)).systemId;
/*     */     
/* 171 */     int j = 0;
/* 172 */     for (int i = 0; i < size; i++) {
/* 173 */       LayoutItem layout = (LayoutItem)this.layouts.get(i);
/* 174 */       if (layout.getSystem() == sys) {
/* 175 */         this.layoutCombo.addItem(layout.getRecordName());
/* 176 */         this.layoutId[(j++)] = i;
/*     */       }
/*     */     }
/*     */     
/* 180 */     setDescription();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setDescription()
/*     */   {
/*     */     try
/*     */     {
/* 190 */       int idx = this.layoutId[this.layoutCombo.getSelectedIndex()];
/* 191 */       this.description.setText(((LayoutItem)this.layouts.get(idx)).getDescription());
/*     */     } catch (Exception ex) {
/* 193 */       this.description.setText("");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void loadSystems()
/*     */   {
/* 206 */     this.systemCombo.removeAllItems();
/*     */     
/* 208 */     this.systemCombo.addItem(ALL_SYSTEMS);
/*     */     
/* 210 */     this.dbLink = true;
/*     */     try {
/* 212 */       this.systems = this.copyBookInterface.getSystems();
/*     */     } catch (Exception ex) {
/* 214 */       if (this.message != null) {
/* 215 */         this.message.setText(ex.getMessage());
/* 216 */         this.message.setCaretPosition(1);
/*     */       }
/* 218 */       ex.printStackTrace();
/* 219 */       this.systems = new ArrayList();
/* 220 */       this.dbLink = false;
/*     */     }
/*     */     
/* 223 */     int num = this.systems.size();
/* 224 */     for (int i = 0; i < num; i++) {
/* 225 */       SystemItem dtls = (SystemItem)this.systems.get(i);
/* 226 */       this.systemCombo.addItem(dtls.description);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void actionPerformed(ActionEvent e)
/*     */   {
/* 237 */     if (e.getSource() == this.dbCombo) {
/* 238 */       Common.setConnectionId(this.dbCombo.getSelectedIndex());
/*     */       
/* 240 */       reload();
/* 241 */     } else if (e.getSource() == this.systemCombo) {
/* 242 */       loadLayoutCombo();
/* 243 */     } else if (e.getSource() == this.layoutCombo) {
/* 244 */       setDescription();
/* 245 */     } else if (e.getSource() == this.reload) {
/* 246 */       reload();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final AbstractLayoutDetails getRecordLayout(String fileName)
/*     */   {
/* 257 */     return getRecordLayout((String)this.layoutCombo.getSelectedItem(), fileName);
/*     */   }
/*     */   
/*     */ 
/*     */   public void forceLayoutReload()
/*     */   {
/* 263 */     this.lastLayoutName = "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final AbstractLayoutDetails getRecordLayout(String layoutName, String fileName)
/*     */   {
/* 272 */     AbstractLayoutDetails ret = null;
/*     */     
/* 274 */     if ((layoutName == null) || (layoutName.equals(""))) {
/* 275 */       Common.logMsg("No Layout Entered", null);
/* 276 */     } else if ((this.loadFromFile) && (this.lastLayoutName.equals(layoutName))) {
/* 277 */       ret = this.lastLayout;
/*     */     }
/*     */     else {
/* 280 */       this.lastLayout = this.copyBookInterface.getLayout(layoutName);
/*     */       
/*     */ 
/*     */ 
/* 284 */       if (this.lastLayout == null) {
/* 285 */         this.message.setText(UtMessages.LAYOUT_CANT_BE_LOADED.get(layoutName) + "\n " + this.copyBookInterface.getMessage());
/*     */       }
/*     */       else
/*     */       {
/* 289 */         this.lastLayoutName = layoutName;
/* 290 */         this.lastLayout = getFileBasedLayout(fileName, this.lastLayout);
/*     */       }
/* 292 */       ret = this.lastLayout;
/*     */     }
/* 294 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reload()
/*     */   {
/* 303 */     this.lastLayoutName = "";
/* 304 */     this.lastLayout = null;
/*     */     
/* 306 */     loadSystems();
/*     */     
/* 308 */     this.layouts.clear();
/* 309 */     if (this.dbLink) {
/* 310 */       this.copyBookInterface.loadLayouts(this.layouts);
/*     */     }
/* 312 */     loadLayoutCombo();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JComboBox getDbCombo()
/*     */   {
/* 319 */     return this.dbCombo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JComboBox getLayoutCombo()
/*     */   {
/* 326 */     return this.layoutCombo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public JComboBox getSystemCombo()
/*     */   {
/* 333 */     return this.systemCombo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getLayoutName()
/*     */   {
/* 340 */     Object o = this.layoutCombo.getSelectedItem();
/* 341 */     if (o == null) {
/* 342 */       return null;
/*     */     }
/*     */     
/* 345 */     return this.layoutCombo.getSelectedItem().toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean setLayoutName(String layoutName)
/*     */   {
/* 352 */     int size = this.layouts.size();
/*     */     
/* 354 */     for (int i = 0; i < size; i++) {
/* 355 */       LayoutItem layout = (LayoutItem)this.layouts.get(i);
/* 356 */       if (layout.getRecordName().equalsIgnoreCase(layoutName)) {
/* 357 */         this.systemCombo.setSelectedIndex(0);
/* 358 */         this.layoutCombo.setSelectedItem(layoutName);
/* 359 */         return true;
/*     */       }
/*     */     }
/* 362 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMessage(JTextArea message)
/*     */   {
/* 370 */     this.message = message;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getDataBaseNames()
/*     */   {
/* 379 */     return Common.getSourceId();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDatabaseIdx(int idx)
/*     */   {
/* 388 */     if (this.dbCombo != null) {
/*     */       try {
/* 390 */         this.dbCombo.setSelectedIndex(idx);
/*     */       } catch (Exception e) {
/* 392 */         e.printStackTrace();
/*     */       }
/*     */     }
/* 395 */     Common.setConnectionId(idx);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getDatabaseIdx()
/*     */   {
/* 403 */     return this.dbCombo.getSelectedIndex();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDatabaseName()
/*     */   {
/* 411 */     return this.dbCombo.getSelectedItem().toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isFileBasedLayout()
/*     */   {
/* 419 */     return false;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/openFile/LayoutSelectionDB.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */