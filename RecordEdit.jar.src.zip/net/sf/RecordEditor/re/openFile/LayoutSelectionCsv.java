/*     */ package net.sf.RecordEditor.re.openFile;
/*     */ 
/*     */ import java.io.File;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTabbedPane;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.RecordEditor.re.util.csv.CsvTabPane;
/*     */ import net.sf.RecordEditor.re.util.csv.FilePreview;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.FileSelectCombo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LayoutSelectionCsv
/*     */   extends LayoutSelectionBasicGenerated
/*     */ {
/*  23 */   private CsvTabPane csvPane = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addLayoutSelection(BasePanel pnl, JPanel goPanel, JButton layoutCreate1, JButton layoutCreate2, FileSelectCombo layoutFile)
/*     */   {
/*  58 */     setupFields();
/*     */     
/*  60 */     pnl.addComponentRE(1, 5, -1.0D, BasePanel.GAP, 2, 2, this.csvPane.tab);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void notifyFileNameChanged(String newFileName)
/*     */   {
/*  69 */     this.csvPane.readCheckPreview(new File(newFileName), true, null);
/*     */   }
/*     */   
/*     */ 
/*     */   public String getLayoutName()
/*     */   {
/*  75 */     FilePreview selectedCsvDetails = this.csvPane.getSelectedCsvDetails();
/*  76 */     return "CsvSchema~" + this.csvPane.tab.getSelectedIndex() + "~" + selectedCsvDetails.getFileDescription();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final AbstractLayoutDetails getRecordLayout(String fileName)
/*     */   {
/*  88 */     FilePreview selectedCsvDetails = this.csvPane.getSelectedCsvDetails();
/*  89 */     return selectedCsvDetails.getLayout(selectedCsvDetails.getFontName(), null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setupFields()
/*     */   {
/* 112 */     if (this.csvPane == null) {
/* 113 */       this.csvPane = new CsvTabPane(this.message, false, false, false);
/* 114 */       this.csvPane.setGoVisible(false);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/openFile/LayoutSelectionCsv.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */