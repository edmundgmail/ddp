/*     */ package net.sf.RecordEditor.re.openFile;
/*     */ 
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JPanel;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.RecordEditor.po.def.PoLayoutMgr;
/*     */ import net.sf.RecordEditor.tip.def.TipLayoutMgr;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.FileSelectCombo;
/*     */ 
/*     */ public class LayoutSelectionPoTipCreator
/*     */   implements AbstractLayoutSelectCreator<LayoutSelectionBasicGenerated>
/*     */ {
/*     */   private final boolean isPo;
/*     */   
/*     */   public static LayoutSelectionPoTipCreator newPoCreator()
/*     */   {
/*  18 */     return new LayoutSelectionPoTipCreator(true);
/*     */   }
/*     */   
/*     */   public static LayoutSelectionPoTipCreator newTipCreator()
/*     */   {
/*  23 */     return new LayoutSelectionPoTipCreator(false);
/*     */   }
/*     */   
/*     */   private LayoutSelectionPoTipCreator(boolean isPo)
/*     */   {
/*  28 */     this.isPo = isPo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LayoutSelectionBasicGenerated create()
/*     */   {
/*  37 */     if (this.isPo) {
/*  38 */       return new LayoutSelectionPo();
/*     */     }
/*  40 */     return new LayoutSelectionTip();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class LayoutSelectionPo
/*     */     extends LayoutSelectionBasicGenerated
/*     */   {
/*     */     protected void addLayoutSelection(BasePanel pnl, JPanel goPanel, JButton layoutCreate1, JButton layoutCreate2, FileSelectCombo layoutFile) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void notifyFileNameChanged(String newFileName) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getLayoutName()
/*     */     {
/*  69 */       return "PoSchema~";
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public final AbstractLayoutDetails getRecordLayout(String fileName)
/*     */     {
/*  79 */       return PoLayoutMgr.getPoLayout();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class LayoutSelectionTip
/*     */     extends LayoutSelectionBasicGenerated
/*     */   {
/*     */     protected void addLayoutSelection(BasePanel pnl, JPanel goPanel, JButton layoutCreate1, JButton layoutCreate2, FileSelectCombo layoutFile) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void notifyFileNameChanged(String newFileName) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getLayoutName()
/*     */     {
/* 107 */       return "TipSchema~";
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public final AbstractLayoutDetails getRecordLayout(String fileName)
/*     */     {
/* 117 */       return TipLayoutMgr.getTipLayout();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/openFile/LayoutSelectionPoTipCreator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */