/*     */ package net.sf.RecordEditor.re.openFile;
/*     */ 
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextArea;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.TreeComboFileSelect;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractLayoutSelection
/*     */   extends ReadLayout
/*     */   implements FormatFileName, ISchemaProvider
/*     */ {
/*  31 */   private StartActionInterface executeAction = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void addLayoutSelection(BasePanel paramBasePanel, TreeComboFileSelect paramTreeComboFileSelect, JPanel paramJPanel, JButton paramJButton1, JButton paramJButton2);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFileNameField(TreeComboFileSelect fileNameField) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract String[] getDataBaseNames();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setDatabaseIdx(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract int getDatabaseIdx();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract String getDatabaseName();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void reload();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean setLayoutName(String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void notifyFileNameChanged(String newFileName) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract String getLayoutName();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract AbstractLayoutDetails getRecordLayout(String paramString);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract AbstractLayoutDetails getRecordLayout(String paramString1, String paramString2);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setMessage(JTextArea paramJTextArea);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract boolean isFileBasedLayout();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void forceLayoutReload() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String formatLayoutName(String layoutName)
/*     */   {
/* 131 */     return layoutName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setExecuteAction(StartActionInterface executeAction)
/*     */   {
/* 138 */     this.executeAction = executeAction;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void loadFile(boolean pBrowse)
/*     */   {
/* 146 */     if (this.executeAction == null) {
/* 147 */       Common.logMsgRaw("", null);
/*     */     } else {
/* 149 */       this.executeAction.loadFile(pBrowse);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/openFile/AbstractLayoutSelection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */