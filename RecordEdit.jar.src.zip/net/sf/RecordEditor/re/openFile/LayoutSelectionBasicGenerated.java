/*     */ package net.sf.RecordEditor.re.openFile;
/*     */ 
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextArea;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.FileSelectCombo;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.TreeComboFileSelect;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class LayoutSelectionBasicGenerated
/*     */   extends AbstractLayoutSelection
/*     */ {
/*     */   protected static final String SEPERATOR = "~";
/*  23 */   protected JTextArea message = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addLayoutSelection(BasePanel pnl, TreeComboFileSelect file, JPanel goPanel, JButton layoutCreate1, JButton layoutCreate2)
/*     */   {
/*  33 */     addLayoutSelection(pnl, goPanel, layoutCreate1, layoutCreate2, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addLayoutSelection(BasePanel pnl, JPanel goPanel, FileSelectCombo layoutFile)
/*     */   {
/*  44 */     addLayoutSelection(pnl, goPanel, null, null, layoutFile);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void addLayoutSelection(BasePanel paramBasePanel, JPanel paramJPanel, JButton paramJButton1, JButton paramJButton2, FileSelectCombo paramFileSelectCombo);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void forceLayoutReload() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final AbstractLayoutDetails getRecordLayout(String layoutName, String fileName)
/*     */   {
/*  71 */     setLayoutName(layoutName);
/*  72 */     return getRecordLayout(fileName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void reload() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean setLayoutName(String layoutName)
/*     */   {
/*  86 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setMessage(JTextArea message)
/*     */   {
/*  95 */     this.message = message;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String[] getDataBaseNames()
/*     */   {
/* 104 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setDatabaseIdx(int idx) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getDatabaseIdx()
/*     */   {
/* 121 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getDatabaseName()
/*     */   {
/* 129 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String formatLayoutName(String layoutName)
/*     */   {
/* 137 */     return layoutName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isFileBasedLayout()
/*     */   {
/* 147 */     return false;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/openFile/LayoutSelectionBasicGenerated.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */