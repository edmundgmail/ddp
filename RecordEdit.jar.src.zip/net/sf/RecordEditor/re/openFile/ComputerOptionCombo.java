/*    */ package net.sf.RecordEditor.re.openFile;
/*    */ 
/*    */ import javax.swing.JComboBox;
/*    */ import net.sf.JRecord.Numeric.ConversionManager;
/*    */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ComputerOptionCombo
/*    */   extends JComboBox
/*    */ {
/*    */   private static final String[] COMPUTER_OPTIONS;
/*    */   private static final String[] COMPUTER_OPTIONS_FOREIGN;
/*    */   private static final int[] COMPUTER_CONVERSION;
/*    */   
/*    */   static
/*    */   {
/* 42 */     ConversionManager manager = ConversionManager.getInstance();
/* 43 */     int count = manager.getNumberOfEntries();
/* 44 */     String[] tmpOptions = new String[count];
/* 45 */     String[] tmpForeignOptions = new String[count];
/* 46 */     int[] tmpConversions = new int[count];
/* 47 */     String mgrName = manager.getManagerName();
/*    */     
/* 49 */     for (int i = 0; i < count; i++) {
/* 50 */       tmpOptions[i] = manager.getName(i);
/* 51 */       tmpConversions[i] = manager.getKey(i);
/* 52 */       tmpForeignOptions[i] = LangConversion.convertId(10, mgrName + "_" + tmpConversions[i], tmpOptions[i]);
/*    */     }
/*    */     
/*    */ 
/* 56 */     COMPUTER_OPTIONS = tmpOptions;
/* 57 */     COMPUTER_OPTIONS_FOREIGN = tmpForeignOptions;
/* 58 */     COMPUTER_CONVERSION = tmpConversions;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public ComputerOptionCombo()
/*    */   {
/* 65 */     super(COMPUTER_OPTIONS_FOREIGN);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getSelectedValue()
/*    */   {
/* 74 */     return COMPUTER_CONVERSION[getSelectedIndex()];
/*    */   }
/*    */   
/*    */   public void setSelectedValue(int value) {
/* 78 */     for (int i = 0; i < COMPUTER_OPTIONS.length; i++) {
/* 79 */       if (COMPUTER_CONVERSION[i] == value) {
/* 80 */         setSelectedIndex(i);
/* 81 */         return;
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public void setEnglishText(Object itm)
/*    */   {
/* 89 */     if (itm != null) {
/* 90 */       String s = itm.toString();
/* 91 */       for (int i = 0; i < COMPUTER_OPTIONS.length; i++) {
/* 92 */         if (s.equals(COMPUTER_OPTIONS[i])) {
/* 93 */           super.setSelectedItem(COMPUTER_OPTIONS_FOREIGN[i]);
/* 94 */           return;
/*    */         }
/*    */       }
/*    */     }
/* 98 */     super.setSelectedItem(itm);
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/openFile/ComputerOptionCombo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */