/*    */ package net.sf.RecordEditor.re.openFile;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LayoutSelectionFileCreator
/*    */   implements AbstractLayoutSelectCreator<LayoutSelectionFile>
/*    */ {
/*    */   public LayoutSelectionFile create()
/*    */   {
/* 11 */     LayoutSelectionFile ret = new LayoutSelectionFile();
/*    */     
/* 13 */     ret.setLoadFromFile(true);
/* 14 */     return ret;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/openFile/LayoutSelectionFileCreator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */