package net.sf.RecordEditor.re.openFile;

public abstract interface FormatFileName
{
  public abstract String formatLayoutName(String paramString);
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/openFile/FormatFileName.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */