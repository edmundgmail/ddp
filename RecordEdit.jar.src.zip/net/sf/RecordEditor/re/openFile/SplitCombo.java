/*    */ package net.sf.RecordEditor.re.openFile;
/*    */ 
/*    */ import javax.swing.JComboBox;
/*    */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SplitCombo
/*    */   extends JComboBox
/*    */ {
/* 24 */   private static final String[] SPLIT_OPTIONS = LangConversion.convertComboItms("Cobol Split options", new String[] { "No Split", "On Redefine", "On 01 level", "At highest repeating Level" });
/*    */   
/*    */ 
/* 27 */   private static final int[] SPLIT_CONVERSION = { 0, 1, 2, 3 };
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public SplitCombo()
/*    */   {
/* 38 */     super(SPLIT_OPTIONS);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getSelectedValue()
/*    */   {
/* 47 */     return SPLIT_CONVERSION[getSelectedIndex()];
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/openFile/SplitCombo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */