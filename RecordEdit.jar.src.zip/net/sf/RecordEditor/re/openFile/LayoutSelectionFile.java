/*     */ package net.sf.RecordEditor.re.openFile;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.LayoutDetail;
/*     */ import net.sf.JRecord.External.CopybookLoader;
/*     */ import net.sf.JRecord.External.CopybookLoaderFactory;
/*     */ import net.sf.JRecord.External.ExternalRecord;
/*     */ import net.sf.JRecord.IO.LineIOProvider;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.edit.ManagerRowList;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions.FileNameOpt;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions.StringOpt;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.BmKeyedComboBox;
/*     */ import net.sf.RecordEditor.utils.swing.BmKeyedComboModel;
/*     */ import net.sf.RecordEditor.utils.swing.ComboBoxs.DelimiterCombo;
/*     */ import net.sf.RecordEditor.utils.swing.ComboBoxs.ManagerCombo;
/*     */ import net.sf.RecordEditor.utils.swing.ComboBoxs.QuoteCombo;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.FileSelectCombo;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.TreeComboFileSelect;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LayoutSelectionFile
/*     */   extends AbstractLayoutSelection
/*     */ {
/*     */   private static final String OLD_SEPERATOR = ",,";
/*     */   private static final String SEPERATOR = "~";
/*     */   private static final int MODE_NORMAL = 0;
/*     */   private static final int MODE_1ST_COBOL = 1;
/*     */   private static final int MODE_2ND_COBOL = 2;
/*     */   private static final int TAB_CSV_IDX = 8;
/*  48 */   private ManagerCombo loaderOptions = null;
/*     */   
/*     */   private FileSelectCombo copybookFile;
/*     */   private BmKeyedComboBox fileStructure;
/*  52 */   private BmKeyedComboModel structureModel = new BmKeyedComboModel(new ManagerRowList(LineIOProvider.getInstance(), false));
/*     */   
/*     */   private SplitCombo splitOption;
/*     */   
/*     */   private ComputerOptionCombo numericFormat;
/*     */   
/*     */   private DelimiterCombo fieldSeparator;
/*     */   private QuoteCombo quote;
/*  60 */   private JTextArea message = null;
/*     */   
/*  62 */   private String lastFileName = "";
/*  63 */   private String lastLayoutDetails = "";
/*  64 */   private String lastCopybookName = "";
/*     */   
/*     */ 
/*     */   private AbstractLayoutDetails lastLayout;
/*     */   
/*  69 */   private int mode = 0;
/*     */   
/*     */   private ChangeListener copybookFocusListner;
/*     */   
/*  73 */   private String fileParamKey = "SchemaFiles.";
/*     */   
/*     */ 
/*     */ 
/*     */   public LayoutSelectionFile() {}
/*     */   
/*     */ 
/*     */ 
/*     */   public LayoutSelectionFile(boolean isCobol)
/*     */   {
/*  83 */     if (isCobol) {
/*  84 */       this.mode = 1;
/*  85 */       this.fileParamKey = "CobolCpy.";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addLayoutSelection(BasePanel pnl, TreeComboFileSelect file, JPanel goPanel, JButton layoutCreate1, JButton layoutCreate2)
/*     */   {
/*  95 */     addLayoutSelection(pnl, goPanel, layoutCreate1, layoutCreate2, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addLayoutSelection(BasePanel pnl, JPanel goPanel, FileSelectCombo layoutFile)
/*     */   {
/* 106 */     addLayoutSelection(pnl, goPanel, null, null, layoutFile);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addLayoutSelection(BasePanel pnl, JPanel goPanel, JButton layoutCreate1, JButton layoutCreate2, FileSelectCombo layoutFile)
/*     */   {
/* 119 */     setupFields();
/*     */     
/* 121 */     if ("".equals(this.copybookFile.getText())) {
/* 122 */       this.copybookFile.setText(Common.OPTIONS.DEFAULT_COPYBOOK_DIRECTORY.get());
/*     */     }
/*     */     
/* 125 */     this.fileStructure.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent e) {
/* 128 */         LayoutSelectionFile.this.setEditable();
/*     */       }
/*     */     });
/*     */     
/*     */ 
/* 133 */     if (layoutFile != null) {
/* 134 */       this.loaderOptions.setSelectedIndex(1);
/* 135 */       this.copybookFile = layoutFile;
/*     */       
/* 137 */       pnl.addLineRE("Output File Structure", this.fileStructure);
/* 138 */       pnl.addLineRE("Output Numeric Format", this.numericFormat);
/* 139 */       this.mode = 2;
/* 140 */     } else if (this.mode == 1) {
/* 141 */       this.loaderOptions.setSelectedIndex(1);
/*     */       
/* 143 */       pnl.addLineRE("Copybook", this.copybookFile);
/*     */       
/* 145 */       pnl.addLineRE("Input File Structure", this.fileStructure);
/* 146 */       pnl.addLineRE("Input Numeric Format", this.numericFormat);
/*     */     } else {
/* 148 */       pnl.addLineRE("File Structure", this.fileStructure);
/*     */       
/* 150 */       this.loaderOptions.setEnglish(Common.OPTIONS.COPYBOOK_READER.get());
/* 151 */       pnl.addLineRE("Copybook Type", this.loaderOptions);
/* 152 */       pnl.addLineRE("Split Copybook", this.splitOption);
/*     */       
/* 154 */       pnl.setGapRE(BasePanel.GAP0);
/* 155 */       pnl.addLineRE("Copybook", this.copybookFile);
/* 156 */       pnl.setGapRE(BasePanel.GAP0);
/*     */       
/* 158 */       pnl.addLineRE("Numeric Format", this.numericFormat);
/*     */       
/* 160 */       pnl.addLineRE("Field Seperator", this.fieldSeparator);
/* 161 */       pnl.addLineRE("Quote", this.quote);
/* 162 */       pnl.setGapRE(BasePanel.GAP1);
/* 163 */       pnl.addLineRE("", null, goPanel);
/* 164 */       if (goPanel != null) {
/* 165 */         pnl.setHeightRE(Math.max(BasePanel.NORMAL_HEIGHT * 3.0D, goPanel.getPreferredSize().getHeight()));
/*     */       }
/*     */       
/* 168 */       this.copybookFocusListner = new ChangeListener() {
/*     */         public void stateChanged(ChangeEvent e) {
/* 170 */           LayoutSelectionFile.this.checkCopybookType();
/*     */         }
/*     */         
/* 173 */       };
/* 174 */       this.copybookFile.addTextChangeListner(this.copybookFocusListner);
/* 175 */       checkCopybookType();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 183 */     setEditable();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setEditable()
/*     */   {
/* 193 */     int fileStruc = ((Integer)this.fileStructure.getSelectedItem()).intValue();
/* 194 */     boolean copybookRequired = LineIOProvider.getInstance().isCopyBookFileRequired(fileStruc);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 204 */     this.loaderOptions.setEnabled(copybookRequired);
/* 205 */     this.copybookFile.setEnabled(copybookRequired);
/* 206 */     this.splitOption.setEnabled(copybookRequired);
/*     */     
/* 208 */     this.fieldSeparator.setEnabled(fileStruc == 51);
/* 209 */     this.quote.setEnabled(fileStruc == 51);
/*     */     
/* 211 */     this.numericFormat.setEnabled((fileStruc != 51) && (fileStruc != 52) && (fileStruc != 62));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getLayoutName()
/*     */   {
/* 221 */     return this.copybookFile.getText() + "~" + this.loaderOptions.getSelectedIndex() + "~" + this.fileStructure.getSelectedIndex() + "~" + this.splitOption.getSelectedIndex() + "~" + this.numericFormat.getSelectedIndex() + "~" + this.fieldSeparator.getSelectedIndex() + "~" + this.quote.getSelectedIndex();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void forceLayoutReload()
/*     */   {
/* 232 */     this.lastLayoutDetails = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final AbstractLayoutDetails getRecordLayout(String fileName)
/*     */   {
/* 241 */     AbstractLayoutDetails ret = null;
/*     */     
/* 243 */     String layoutName = this.copybookFile.getText();
/*     */     
/* 245 */     int fileStruc = ((Integer)this.fileStructure.getSelectedItem()).intValue();
/*     */     
/* 247 */     if ((this.loadFromFile) && (this.lastLayoutDetails != null) && (this.lastLayoutDetails.equalsIgnoreCase(layoutName)) && (((this.lastFileName != null) && (this.lastFileName.equals(fileName))) || (this.lastFileName == fileName)))
/*     */     {
/* 249 */       ret = this.lastLayout;
/* 250 */     } else if (!LineIOProvider.getInstance().isCopyBookFileRequired(fileStruc)) {
/* 251 */       ret = buildLayoutFromSample(fileStruc, this.fileStructure.getSelectedIndex() == 8, getFontName(), this.fieldSeparator.getSelectedEnglish(), fileName);
/*     */       
/*     */ 
/* 254 */       this.lastLayoutDetails = layoutName;
/* 255 */       this.lastLayout = ret;
/* 256 */     } else if ((layoutName == null) || ("".equals(layoutName))) {
/* 257 */       setMessageText("You must enter a Record Layout name ", this.copybookFile);
/*     */     } else {
/*     */       try {
/* 260 */         ret = getRecordLayout_readLayout(layoutName, fileName);
/*     */         
/* 262 */         if ((this.loadFromFile) && (ret != null) && (!LineIOProvider.getInstance().isCopyBookFileRequired(ret.getFileStructure())))
/*     */         {
/*     */ 
/* 265 */           ret = getFileBasedLayout(fileName, ret);
/*     */         }
/*     */         
/* 268 */         this.lastLayoutDetails = layoutName;
/* 269 */         this.lastFileName = fileName;
/* 270 */         this.lastLayout = ret;
/*     */       } catch (Exception e) {
/* 272 */         setMessageText("You must enter a copybook name ", this.copybookFile);
/*     */         
/* 274 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */     
/* 278 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final AbstractLayoutDetails getRecordLayout(String layoutName, String fileName)
/*     */   {
/* 288 */     setLayoutName(layoutName);
/* 289 */     return getRecordLayout(fileName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private LayoutDetail getRecordLayout_readLayout(String copyBookFile, String filename)
/*     */   {
/* 300 */     LayoutDetail ret = null;
/*     */     
/*     */     try
/*     */     {
/* 304 */       int loaderIdx = this.loaderOptions.getSelectedIndex();
/* 305 */       CopybookLoaderFactory factory = CopybookLoaderFactoryExtended.getInstance();
/* 306 */       CopybookLoader loader = factory.getLoader(loaderIdx);
/* 307 */       int structure = ((Integer)this.fileStructure.getSelectedItem()).intValue();
/* 308 */       int split = this.splitOption.getSelectedValue();
/* 309 */       int numFormat = this.numericFormat.getSelectedValue();
/* 310 */       String font = getFontName();
/* 311 */       String copy = copyBookFile;
/* 312 */       if ((factory.isBasedOnInputFile(loaderIdx)) && (new File(filename).exists())) {
/* 313 */         copy = filename;
/*     */       }
/*     */       
/* 316 */       File f = new File(copy);
/* 317 */       if (f.exists()) {
/* 318 */         ExternalRecord rec = loader.loadCopyBook(copy, split, 0, font, numFormat, 0, Common.getLogger());
/*     */         
/*     */ 
/*     */ 
/* 322 */         if ((rec.getFileStructure() != 51) && (rec.getFileStructure() != 54) && (rec.getFileStructure() != 55) && (rec.getFileStructure() != 52))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 327 */           if ((rec.getFileStructure() != 62) && (rec.getFileStructure() != 61) && (rec.getFileStructure() != 22) && (structure != 0))
/*     */           {
/*     */ 
/*     */ 
/*     */ 
/* 332 */             rec.setFileStructure(structure);
/*     */           }
/*     */         }
/* 335 */         ret = rec.asLayoutDetail();
/*     */       }
/*     */       else {
/* 338 */         System.out.println("Record Layout file does not exist: " + copy);
/* 339 */         setMessageText("Record Layout file does not exist: " + copy, this.copybookFile);
/*     */       }
/*     */     } catch (Exception e) {
/* 342 */       System.out.println("Error: " + e.getMessage());
/* 343 */       setMessageText("Error: " + e.getMessage(), null);
/* 344 */       e.printStackTrace();
/*     */     }
/*     */     
/* 347 */     return ret;
/*     */   }
/*     */   
/*     */   private String getFontName() {
/* 351 */     int numFormat = this.numericFormat.getSelectedValue();
/* 352 */     String font = "";
/* 353 */     if (numFormat == 1) {
/* 354 */       font = "cp037";
/*     */     }
/* 356 */     return font;
/*     */   }
/*     */   
/*     */ 
/*     */   public void reload()
/*     */   {
/* 362 */     this.lastLayoutDetails = "";
/* 363 */     this.lastLayout = null;
/*     */   }
/*     */   
/*     */   public boolean setLayoutName(String layoutName)
/*     */   {
/* 368 */     StringTokenizer t = new StringTokenizer(layoutName, "~");
/*     */     
/* 370 */     if (t.countTokens() < 5) {
/* 371 */       t = new StringTokenizer(layoutName, ",,");
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 377 */       setupFields();
/* 378 */       this.copybookFile.setText(t.nextToken());
/*     */       
/* 380 */       int loader = getIntToken(t);
/* 381 */       this.fileStructure.setSelectedIndex(getIntToken(t));
/* 382 */       int split = getIntToken(t);
/*     */       
/* 384 */       if (this.mode == 0) {
/* 385 */         this.loaderOptions.setSelectedIndex(loader);
/* 386 */         this.splitOption.setSelectedIndex(split);
/*     */       } else {
/* 388 */         this.loaderOptions.setSelectedIndex(1);
/*     */       }
/* 390 */       this.numericFormat.setSelectedIndex(getIntToken(t));
/* 391 */       this.fieldSeparator.setSelectedIndex(getIntToken(t));
/* 392 */       this.quote.setSelectedIndex(getIntToken(t));
/*     */     } catch (Exception e) {
/* 394 */       e.printStackTrace();
/*     */     }
/* 396 */     setEditable();
/*     */     
/* 398 */     return false;
/*     */   }
/*     */   
/*     */   private void setupFields()
/*     */   {
/* 403 */     if (this.loaderOptions == null)
/*     */     {
/*     */ 
/* 406 */       this.loaderOptions = ManagerCombo.newCopybookLoaderCombo();
/* 407 */       this.copybookFile = new FileSelectCombo(this.fileParamKey, 25, true, false);
/*     */       
/* 409 */       this.fileStructure = new BmKeyedComboBox(this.structureModel, false);
/* 410 */       this.splitOption = new SplitCombo();
/* 411 */       this.numericFormat = new ComputerOptionCombo();
/* 412 */       this.fieldSeparator = DelimiterCombo.NewDelimComboWithDefault();
/*     */       
/* 414 */       this.quote = QuoteCombo.newCombo();
/*     */       
/*     */ 
/* 417 */       String s = Common.OPTIONS.DEFAULT_IO_NAME.get();
/* 418 */       if (!"".equals(s)) {
/* 419 */         this.fileStructure.setSelectedDisplay(s);
/*     */       }
/* 421 */       s = Common.OPTIONS.DEFAULT_BIN_NAME.get();
/* 422 */       if (!"".equals(s)) {
/* 423 */         this.numericFormat.setEnglishText(s);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void checkCopybookType()
/*     */   {
/* 432 */     String fname = this.copybookFile.getText();
/*     */     
/* 434 */     if ((fname != null) && (!fname.equals(this.lastCopybookName))) {
/* 435 */       int loaderType = CopybookLoaderFactoryExtended.getLoaderType(fname);
/*     */       
/* 437 */       if (loaderType >= 0) {
/* 438 */         this.loaderOptions.setSelectedIndex(loaderType);
/*     */       }
/*     */       
/* 441 */       this.lastCopybookName = fname;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int getIntToken(StringTokenizer t)
/*     */   {
/* 452 */     int ret = 0;
/*     */     
/* 454 */     if (t.hasMoreElements()) {
/* 455 */       String s = t.nextToken();
/*     */       try
/*     */       {
/* 458 */         ret = Integer.parseInt(s);
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*     */     
/* 463 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMessage(JTextArea message)
/*     */   {
/* 471 */     this.message = message;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getDataBaseNames()
/*     */   {
/* 480 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDatabaseIdx(int idx) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getDatabaseIdx()
/*     */   {
/* 497 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDatabaseName()
/*     */   {
/* 505 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String formatLayoutName(String layoutName)
/*     */   {
/* 513 */     String name = layoutName;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 520 */     return Common.OPTIONS.DEFAULT_COPYBOOK_DIRECTORY.getNoStar() + name + ".Xml" + "~" + "2" + "~" + "0" + "~" + "0" + "~" + "0" + "~" + "0" + "~" + "0";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void setMessageText(String text, JComponent component)
/*     */   {
/* 527 */     if (this.message == null) {
/* 528 */       System.err.println();
/* 529 */       System.err.println(LangConversion.convert("Error:") + " " + text);
/* 530 */       System.err.println("================================================================");
/* 531 */       System.err.println();
/*     */     } else {
/* 533 */       if (component != null) {
/* 534 */         component.requestFocus();
/*     */       }
/* 536 */       this.message.setText(text);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final FileSelectCombo getCopybookFile()
/*     */   {
/* 544 */     return this.copybookFile;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isFileBasedLayout()
/*     */   {
/* 553 */     return true;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/openFile/LayoutSelectionFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */