/*    */ package net.sf.RecordEditor.re.openFile;
/*    */ 
/*    */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*    */ import net.sf.JRecord.Details.LayoutDetail;
/*    */ import net.sf.JRecord.Details.RecordDetail;
/*    */ import net.sf.JRecord.IO.AbstractLineIOProvider;
/*    */ import net.sf.JRecord.IO.AbstractLineReader;
/*    */ import net.sf.RecordEditor.re.util.ReIOProvider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReadLayout
/*    */ {
/* 20 */   protected boolean loadFromFile = false;
/*    */   
/*    */ 
/*    */ 
/*    */   public final AbstractLayoutDetails buildLayoutFromSample(int fileStruc, boolean isCSV, String fontname, String delimiter, String filename)
/*    */   {
/* 26 */     int layoutType = 2;
/* 27 */     if (fileStruc == 62) {
/* 28 */       layoutType = 6;
/*    */     }
/*    */     
/* 31 */     LayoutDetail ret = new LayoutDetail("", new RecordDetail[0], "", layoutType, null, "", fontname, null, fileStruc);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 36 */     if (isCSV) {
/* 37 */       ret.setDelimiter(delimiter);
/*    */     }
/* 39 */     return getFileBasedLayout(filename, ret);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public final AbstractLayoutDetails getFileBasedLayout(String fileName, AbstractLayoutDetails layout)
/*    */   {
/* 52 */     AbstractLayoutDetails ret = layout;
/*    */     
/* 54 */     AbstractLineIOProvider ioProvider = ReIOProvider.getInstance();
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 62 */     if ((this.loadFromFile) && (fileName != null) && (!"".equals(fileName)) && (!ioProvider.isCopyBookFileRequired(layout.getFileStructure())))
/*    */     {
/* 64 */       AbstractLineReader reader = ioProvider.getLineReader(layout, null);
/*    */       try {
/* 66 */         reader.open(fileName, layout);
/* 67 */         reader.read();
/* 68 */         if (layout.isXml()) {
/* 69 */           int i = 0;
/* 70 */           while ((reader.read() != null) && (i++ < 1000)) {}
/*    */         }
/*    */         
/*    */ 
/* 74 */         ret = reader.getLayout();
/*    */       }
/*    */       catch (Exception e) {}
/*    */     }
/* 78 */     return ret;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public final ReadLayout setLoadFromFile(boolean newLoadFromFile)
/*    */   {
/* 87 */     this.loadFromFile = newLoadFromFile;
/* 88 */     return this;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/openFile/ReadLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */