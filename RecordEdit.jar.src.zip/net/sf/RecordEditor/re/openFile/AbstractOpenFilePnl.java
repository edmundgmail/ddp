/*     */ package net.sf.RecordEditor.re.openFile;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import net.sf.JRecord.Common.RecordException;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.IO.AbstractLineIOProvider;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.params.BoolOpt;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions.FileNameOpt;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.HelpWindow;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.FileTreeComboItem;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.TreeComboFileSelect;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractOpenFilePnl
/*     */   extends BaseHelpPanel
/*     */   implements ChangeListener, StartActionInterface
/*     */ {
/*     */   public static final int OLD_FORMAT = 1;
/*     */   public static final int NEW_FILE_FORMAT = 2;
/*     */   protected final TreeComboFileSelect fileName;
/*     */   protected RecentFiles recent;
/*  72 */   private static final int FRAME_WIDTH = SwingUtils.STANDARD_FONT_WIDTH * 73;
/*     */   
/*  74 */   protected JTextArea message = new JTextArea();
/*     */   
/*     */ 
/*     */   protected AbstractLayoutDetails fileDescription;
/*     */   
/*     */   private final AbstractLineIOProvider ioProvider;
/*     */   
/*     */   private Rectangle frameSize;
/*     */   
/*  83 */   private boolean doListener = true;
/*     */   
/*     */   private AbstractLayoutSelection layoutSelection;
/*     */   
/*     */   private JButton lCreate1;
/*     */   
/*     */   private JButton lCreate2;
/*     */   
/*     */   private final int format;
/*  92 */   private static String LOAD_ERROR = LangConversion.convert("Error Loading File:") + " ";
/*     */   
/*  94 */   private boolean lookupRecentLayouts = true;
/*     */   
/*     */ 
/*  97 */   private KeyAdapter listner = new KeyAdapter()
/*     */   {
/*     */ 
/*     */     public final void keyReleased(KeyEvent event)
/*     */     {
/*     */ 
/* 103 */       if (event.getKeyCode() == 10) {
/* 104 */         AbstractOpenFilePnl.this.loadFile(false);
/*     */       }
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractOpenFilePnl(int pFormat, String pInFile, AbstractLineIOProvider pIoProvider, JButton layoutCreate1, JButton layoutCreate2, String propertiesFiles, String helpScreen, AbstractLayoutSelection newLayoutSelection)
/*     */   {
/* 135 */     this.format = pFormat;
/* 136 */     this.ioProvider = pIoProvider;
/* 137 */     this.recent = new RecentFiles(propertiesFiles, newLayoutSelection, newLayoutSelection.isFileBasedLayout(), Common.OPTIONS.DEFAULT_FILE_DIRECTORY.getNoStar());
/*     */     
/*     */ 
/* 140 */     this.layoutSelection = newLayoutSelection;
/* 141 */     this.lCreate1 = layoutCreate1;
/* 142 */     this.lCreate2 = layoutCreate2;
/*     */     
/* 144 */     this.fileName = new TreeComboFileSelect(true, false, true, getRecentList(), this.recent.getDirectoryList());
/*     */     
/* 146 */     this.layoutSelection.setMessage(this.message);
/*     */     
/* 148 */     init_100_RecentFiles(pInFile);
/* 149 */     init_200_ScreenFields();
/* 150 */     init_300_BldScreen(helpScreen);
/*     */   }
/*     */   
/*     */   protected final List<FileTreeComboItem> getRecentList() {
/* 154 */     return this.recent.getFileComboList();
/*     */   }
/*     */   
/*     */   protected List<File> getRecentDirectoryList() {
/* 158 */     return this.recent.getDirectoryList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void init_100_RecentFiles(String pInFile)
/*     */   {
/* 166 */     Common.setCurrClass(this);
/*     */     
/* 168 */     if ((pInFile == null) || ("".equals(pInFile)))
/*     */     {
/* 170 */       this.fileName.setText(Common.OPTIONS.DEFAULT_FILE_DIRECTORY.getWithStar());
/*     */     } else {
/* 172 */       this.fileName.setText(pInFile);
/* 173 */       updateLayoutForFile(pInFile);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void init_200_ScreenFields()
/*     */   {
/* 181 */     Common.setBounds1(HelpWindow.HELP_FRAME, "Help");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 192 */     this.fileName.addTextChangeListner(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_300_BldScreen(String helpScreen)
/*     */   {
/* 205 */     addReKeyListener(this.listner);
/*     */     
/* 207 */     if (this.format == 1) {
/* 208 */       addHelpBtnRE(SwingUtils.getHelpButton());
/*     */     }
/* 210 */     setHelpURLre(Common.formatHelpURL(helpScreen));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void done()
/*     */   {
/* 219 */     setGapRE(BasePanel.GAP1);
/* 220 */     addFileName(this);
/* 221 */     setGapRE(BasePanel.GAP2);
/*     */     
/* 223 */     addLayoutSelection();
/*     */     
/* 225 */     addMessage(new JScrollPane(this.message));
/* 226 */     setHeightRE(BasePanel.NORMAL_HEIGHT * 4.0D);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 232 */     super.done();
/*     */     
/* 234 */     setBounds(getY(), getX(), FRAME_WIDTH, getHeight());
/* 235 */     this.frameSize = getBounds();
/*     */   }
/*     */   
/*     */   protected void addFileName(BaseHelpPanel pnl)
/*     */   {
/* 240 */     if (this.format == 2) {
/* 241 */       pnl.addLine3to5("File", this.fileName);
/* 242 */     } else if (Common.OPTIONS.addFileSearchBtn.isSelected()) {
/* 243 */       pnl.addLineRE("File", this.fileName);
/*     */     } else {
/* 245 */       pnl.addLineRE("File", this.fileName);
/*     */     }
/*     */   }
/*     */   
/*     */   protected void addLayoutSelection()
/*     */   {
/* 251 */     getLayoutSelection().addLayoutSelection(this, this.fileName, getGoPanel(), this.lCreate1, this.lCreate2);
/* 252 */     setGapRE(BasePanel.GAP2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTheBounds()
/*     */   {
/* 260 */     setBounds(this.frameSize);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void loadFile(boolean pBrowse)
/*     */   {
/* 273 */     String sFileName = this.fileName.getText();
/*     */     
/* 275 */     if (sFileName.equals("")) {
/* 276 */       String s = LangConversion.convert("Please Enter a file name");
/* 277 */       Common.logMsgRaw(s, null);
/* 278 */       this.message.setText(s);
/* 279 */     } else if ((!Common.OPTIONS.asterixInFileName.isSelected()) && (sFileName.indexOf('*') >= 0)) {
/* 280 */       String s = LangConversion.convert("invalid filename (* present) ~") + " " + sFileName;
/* 281 */       Common.logMsgRaw(s, null);
/* 282 */       this.message.setText(s);
/*     */     }
/*     */     else {
/* 285 */       File f = new File(sFileName).getParentFile();
/* 286 */       if (!f.exists()) {
/* 287 */         String s = LangConversion.convert("Directory Does not exist:") + " " + f.getPath();
/* 288 */         Common.logMsgRaw(s, null);
/* 289 */         this.message.setText(s);
/*     */       } else {
/* 291 */         this.fileDescription = getLayoutSelection().getRecordLayout(sFileName);
/* 292 */         if (this.fileDescription != null) {
/*     */           try {
/* 294 */             this.fileDescription.getOption(2);
/* 295 */             processFile(sFileName, this.fileDescription, this.ioProvider, pBrowse);
/*     */ 
/*     */           }
/*     */           catch (IOException ioe)
/*     */           {
/* 300 */             stdError(ioe);
/*     */           } catch (RecordException e) {
/* 302 */             stdError(e);
/*     */           } catch (RuntimeException e) {
/* 304 */             String errorMsg = e.getMessage();
/* 305 */             if (errorMsg == null) {
/* 306 */               Common.logMsgRaw("", e);
/*     */             } else {
/* 308 */               JOptionPane.showInternalMessageDialog(this, errorMsg);
/* 309 */               Common.logMsgRaw(errorMsg, null);
/*     */             }
/*     */             
/* 312 */             e.printStackTrace();
/*     */           } catch (Exception e) {
/* 314 */             String s = LOAD_ERROR + e.getMessage();
/* 315 */             Common.logMsgRaw(s, e);
/* 316 */             this.message.setText(s);
/* 317 */             e.printStackTrace();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected abstract void processFile(String paramString, AbstractLayoutDetails paramAbstractLayoutDetails, AbstractLineIOProvider paramAbstractLineIOProvider, boolean paramBoolean)
/*     */     throws Exception;
/*     */   
/*     */ 
/*     */   private void stdError(Exception e)
/*     */   {
/* 331 */     String s = LOAD_ERROR + e.getMessage();
/* 332 */     Common.logMsgRaw(s, null);
/* 333 */     this.message.setText(s);
/* 334 */     e.printStackTrace();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getCurrentLayout()
/*     */   {
/* 343 */     return getLayoutSelection().getLayoutName();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setLayout(String recentLayout)
/*     */   {
/* 352 */     getLayoutSelection().setLayoutName(recentLayout);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public JTextArea getMessage()
/*     */   {
/* 360 */     return this.message;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract JPanel getGoPanel();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void stateChanged(ChangeEvent e)
/*     */   {
/* 394 */     if ((this.doListener) && (e == null)) {
/* 395 */       updateLayoutForFile(this.fileName.getText());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void updateLayoutForFile(String pFile)
/*     */   {
/* 404 */     String recentLayout = this.recent.getLayoutName(pFile, new File(pFile));
/*     */     
/* 406 */     if ((!this.lookupRecentLayouts) || (recentLayout == null) || ("".equals(recentLayout))) {
/* 407 */       getLayoutSelection().notifyFileNameChanged(pFile);
/*     */     } else {
/* 409 */       setLayout(recentLayout);
/* 410 */       if (this.recent.isEditorLaunch()) {
/* 411 */         loadFile(false);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getCurrentFileName()
/*     */   {
/* 420 */     return this.fileName.getText();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractLayoutSelection getLayoutSelection()
/*     */   {
/* 428 */     return this.layoutSelection;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void setDoListener(boolean doListener)
/*     */   {
/* 435 */     this.doListener = doListener;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void setLookupRecentLayouts(boolean lookupRecentLayouts)
/*     */   {
/* 442 */     this.lookupRecentLayouts = lookupRecentLayouts;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/openFile/AbstractOpenFilePnl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */