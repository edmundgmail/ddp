/*     */ package net.sf.RecordEditor.re.openFile;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.io.File;
/*     */ import java.util.HashSet;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import net.sf.RecordEditor.utils.BasicLayoutCallback;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RecentFilesList
/*     */   implements ChangeListener
/*     */ {
/*     */   private final boolean generateDirMenu;
/*  22 */   private JMenu menu = SwingUtils.newMenu("Recent Files");
/*  23 */   private JMenu directoryMenu = null;
/*     */   private RecentFiles recentFiles;
/*     */   private BasicLayoutCallback connection;
/*  26 */   private FileAction[] actions = new FileAction[25];
/*  27 */   private DirectoryAction[] dirActions = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public RecentFilesList(RecentFiles recentfiles, BasicLayoutCallback callback)
/*     */   {
/*  34 */     this(recentfiles, callback, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public RecentFilesList(RecentFiles recentfiles, BasicLayoutCallback callback, boolean generateDirectoryMenu)
/*     */   {
/*  43 */     this.recentFiles = recentfiles;
/*  44 */     this.connection = callback;
/*  45 */     this.generateDirMenu = generateDirectoryMenu;
/*     */     
/*  47 */     this.recentFiles.addChangeListner(this);
/*     */     
/*  49 */     if (generateDirectoryMenu) {
/*  50 */       this.directoryMenu = SwingUtils.newMenu("Recent Directories");
/*  51 */       this.dirActions = new DirectoryAction[25];
/*     */     }
/*     */     
/*  54 */     stateChanged(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void stateChanged(ChangeEvent e)
/*     */   {
/*  66 */     if (this.generateDirMenu) {
/*  67 */       HashSet<String> usedDirs = new HashSet();
/*  68 */       int j = 0;
/*  69 */       boolean changed = false;
/*  70 */       for (int i = 0; i < 25; i++) {
/*  71 */         String s = new File(this.recentFiles.getRecentFullFileName(i)).getParent();
/*  72 */         if ((s != null) && (!"".equals(s)) && (!usedDirs.contains(s)))
/*     */         {
/*     */ 
/*  75 */           if (this.dirActions[j] == null) {
/*  76 */             this.dirActions[j] = new DirectoryAction(s);
/*  77 */             this.directoryMenu.add(new JMenuItem(this.dirActions[i]));
/*  78 */             changed = true;
/*     */           } else {
/*  80 */             this.dirActions[j].putValue("Name", s);
/*  81 */             this.dirActions[j].dir = s;
/*     */           }
/*  83 */           j++;
/*  84 */           usedDirs.add(s);
/*     */         }
/*     */       }
/*     */       
/*  88 */       if ((changed) && (Common.NIMBUS_LAF)) {
/*  89 */         this.directoryMenu.repaint();
/*     */       }
/*     */     }
/*     */     
/*  93 */     boolean changed = false;
/*  94 */     for (int i = 0; i < 25; i++) {
/*  95 */       String s = this.recentFiles.getRecentFileName(i);
/*  96 */       if ((s != null) && (!"".equals(s))) {
/*  97 */         if (this.actions[i] == null) {
/*  98 */           this.actions[i] = new FileAction(i, s);
/*  99 */           this.menu.add(new JMenuItem(this.actions[i]));
/* 100 */           changed = true;
/*     */         } else {
/* 102 */           this.actions[i].putValue("Name", s);
/*     */         }
/*     */       }
/*     */     }
/* 106 */     if ((changed) && (Common.NIMBUS_LAF)) {
/* 107 */       this.menu.repaint();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final JMenu getMenu()
/*     */   {
/* 132 */     return this.menu;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final JMenu getDirectoryMenu()
/*     */   {
/* 139 */     return this.directoryMenu;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public RecentFiles getRecentFiles()
/*     */   {
/* 146 */     return this.recentFiles;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private class FileAction
/*     */     extends AbstractAction
/*     */   {
/*     */     private int id;
/*     */     
/*     */ 
/*     */     public FileAction(int idx, String s)
/*     */     {
/* 159 */       super();
/* 160 */       this.id = idx;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/*     */       try
/*     */       {
/* 170 */         RecentFilesList.this.connection.setRecordLayout(-1, RecentFilesList.this.recentFiles.getRecentLayoutName(this.id), RecentFilesList.this.recentFiles.getRecentFullFileName(this.id));
/*     */       }
/*     */       catch (Exception ex) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private class DirectoryAction
/*     */     extends AbstractAction
/*     */   {
/*     */     private String dir;
/*     */     
/*     */ 
/*     */ 
/*     */     public DirectoryAction(String dir)
/*     */     {
/* 188 */       super();
/*     */       
/* 190 */       this.dir = dir;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/*     */       try
/*     */       {
/* 200 */         RecentFilesList.this.connection.setRecordLayout(-1, null, this.dir);
/*     */       }
/*     */       catch (Exception ex) {}
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/openFile/RecentFilesList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */