/*    */ package net.sf.RecordEditor.re.util;
/*    */ 
/*    */ import javax.swing.JComboBox;
/*    */ import net.sf.JRecord.IO.LineIOProvider;
/*    */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*    */ import net.sf.RecordEditor.utils.swing.Combo.ComboOption;
/*    */ 
/*    */ public class FileStructureDtls
/*    */ {
/*    */   private static final ComboOption[] FILE_STRUCTURES;
/*    */   
/*    */   static
/*    */   {
/* 14 */     int[] structures = { 4, 5, 7, 8, 2, 9, 11 };
/*    */     
/* 16 */     LineIOProvider p = ReIOProvider.getInstance();
/* 17 */     int idx = 0;
/*    */     
/* 19 */     FILE_STRUCTURES = new ComboOption[structures.length];
/*    */     
/* 21 */     for (int structure : structures) {
/* 22 */       FILE_STRUCTURES[(idx++)] = new ComboOption(structure, LangConversion.convertId(12, p.getManagerName() + "_" + structure, p.getInternalStructureName(structure)));
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static String getStructureName(int structure)
/*    */   {
/* 33 */     LineIOProvider p = ReIOProvider.getInstance();
/* 34 */     return p.getInternalStructureName(structure);
/*    */   }
/*    */   
/*    */   public static int getComboIndex(int structure)
/*    */   {
/* 39 */     for (int i = 0; i < FILE_STRUCTURES.length; i++) {
/* 40 */       if (FILE_STRUCTURES[i].index == structure) {
/* 41 */         return i;
/*    */       }
/*    */     }
/* 44 */     return 0;
/*    */   }
/*    */   
/*    */ 
/*    */   public static JComboBox getFileStructureCombo()
/*    */   {
/* 50 */     return new JComboBox(FILE_STRUCTURES);
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/util/FileStructureDtls.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */