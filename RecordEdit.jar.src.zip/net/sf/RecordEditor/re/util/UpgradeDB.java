/*      */ package net.sf.RecordEditor.re.util;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.PrintStream;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import javax.swing.JOptionPane;
/*      */ import net.sf.JRecord.External.Def.BasicConversion;
/*      */ import net.sf.JRecord.External.ExternalRecord;
/*      */ import net.sf.JRecord.External.RecordEditorCsvLoader;
/*      */ import net.sf.JRecord.External.RecordEditorXmlLoader;
/*      */ import net.sf.JRecord.Log.AbsSSLogger;
/*      */ import net.sf.RecordEditor.layoutEd.utils.LeMessages;
/*      */ import net.sf.RecordEditor.re.db.Record.ChildRecordsRec;
/*      */ import net.sf.RecordEditor.re.db.Record.ExtendedRecordDB;
/*      */ import net.sf.RecordEditor.re.db.Record.RecordRec;
/*      */ import net.sf.RecordEditor.utils.common.Common;
/*      */ import net.sf.RecordEditor.utils.common.ReConnection;
/*      */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*      */ import net.sf.RecordEditor.utils.msg.UtMessages;
/*      */ import net.sf.RecordEditor.utils.screenManager.ReMainFrame;
/*      */ import net.sf.RecordEditor.utils.screenManager.ReMsg;
/*      */ import net.sf.RecordEditor.utils.screenManager.ReMsgId;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class UpgradeDB
/*      */ {
/*   57 */   private static final String DATABASE_UPGRADED = LangConversion.convert("Database Upgraded to Version") + " ";
/*      */   
/*   59 */   private static String VERSION_692B = "0069200";
/*   60 */   private static String VERSION_700 = "0070000";
/*   61 */   private static String VERSION_800 = "0080000";
/*   62 */   private static String VERSION_801 = "0080001";
/*   63 */   private static String VERSION_90 = "0090000";
/*   64 */   private static String VERSION_93 = "0093000";
/*   65 */   private static String VERSION_931 = "0093100";
/*   66 */   private static String VERSION_932 = "0093200";
/*   67 */   private static String VERSION_94 = "0094000";
/*   68 */   private static String VERSION_95C = "0095001";
/*   69 */   private static String VERSION_95D = "0095002";
/*   70 */   private static String VERSION_95E = "0095003";
/*   71 */   private static String VERSION_96Ha = "0096001";
/*   72 */   private static String VERSION_96H = "0096002";
/*      */   
/*   74 */   private static String LATEST_VERSION = VERSION_96H;
/*   75 */   private static String VERSION_KEY = "-101";
/*      */   
/*      */   private List<LayoutDef> holdLayoutDetails;
/*      */   
/*   79 */   private static String SQL_GET_VERION = "Select DETAILS from TBL_TI_INTTBLS  where   TBLID  = " + VERSION_KEY + "   and  TBLKEY  = " + VERSION_KEY + "   and DETAILS >= '" + VERSION_692B + "'";
/*      */   private int[] unknownStructure;
/*      */   private String[] unknownFonts;
/*      */   private String[] unknownNames;
/*      */   private String unknownLine1Pt1;
/*      */   private String unknownLine1Pt2;
/*      */   private String unknownLine2;
/*      */   private String unknownFormatLines;
/*      */   private String updateRecordSep;
/*      */   private String insertSQL;
/*      */   private String deleteTbl;
/*      */   private String insertTbl;
/*      */   private String insertRecord;
/*      */   private String insertRF;
/*      */   private String[] sql55;
/*      */   private String[] sql61b;
/*      */   private String[] sql69;
/*      */   private String[] sql71;
/*      */   private String[] updateVersion;
/*      */   private String[] sql8001;
/*      */   private String[] sql90;
/*      */   private String[] sql93a;
/*      */   private String[] sql93;
/*      */   private String[] sql94;
/*      */   private String[] sql95c;
/*      */   private String[] sql96h_1;
/*      */   private String[] sql96h_2;
/*      */   private int[] types96h;
/*      */   private String fileWizardXmlLayout;
/*      */   private String deleteExample;
/*      */   
/*      */   public UpgradeDB()
/*      */   {
/*   77 */     this.holdLayoutDetails = new ArrayList();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*   85 */     this.unknownStructure = new int[] { 4, 5, 8, 7, 9, 90 };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*   90 */     this.unknownFonts = new String[] { "cp037", "cp037", "", "", "", "utf-8", "utf-16" };
/*      */     
/*      */ 
/*   93 */     this.unknownNames = new String[] { "Mainframe VB", "Mainframe VB Dump", "Open Cobol VB", "Fujitsu VB", "Text IO", "Text UTF-8", "Text UTF-16" };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  102 */     this.unknownLine1Pt1 = "Record\t";
/*  103 */     this.unknownLine1Pt2 = "\t1\t<Tab>\t0\t\tY\t";
/*  104 */     this.unknownLine2 = "1\t1\tData\t\t81\t0\t0\t";
/*      */     
/*  106 */     this.unknownFormatLines = "Record\t21\t1\t<Tab>\t0\t\tY\tUnknown Format\n1\t1\tUnknown\t\t0\t0\t0\t";
/*      */     
/*      */ 
/*  109 */     this.updateRecordSep = "Update TBL_R_RECORDS set RECSEPLIST = 'default' where RECORDTYPE <> 10";
/*      */     
/*      */ 
/*  112 */     this.insertSQL = "insert into TBL_TI_INTTBLS (TBLID,TBLKEY,DETAILS) values ";
/*  113 */     this.deleteTbl = "delete from TBL_TI_INTTBLS where ";
/*  114 */     this.insertTbl = "insert into Tbl_T_Table (TblId, TblName, TblDescription) values ";
/*      */     
/*      */ 
/*  117 */     this.insertRecord = "INSERT INTO Tbl_R_Records (RecordId,RecordName,Description,RecordType,System,ListChar,CopyBook,Delimiter,Quote,PosRecInd,RecSepList,RecordSep,ExternalId,Canonical_Name,Record_Style,File_Structure) VALUES ";
/*      */     
/*      */ 
/*      */ 
/*  121 */     this.insertRF = "INSERT INTO Tbl_RF_RecordFields (RecordId,SubKey,FieldPos,FieldLength,FieldName,Description,FieldType,DecimalPos,DefaultValue,CobolName,FormatDescription,Cell_Format,Parameter) VALUES ";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  136 */     this.sql55 = new String[] { this.insertTbl + "(4, 'FileStructure', " + "'File Structures, " + "\n user File Structures should have a" + "\n Row Key > 1000')", this.insertTbl + "(5, 'Formats', 'Table Cell Formatting')", this.insertSQL + "(3,101,'General')", this.insertSQL + "(4,0,'Default Reader')", this.insertSQL + "(4,2,'Fixed Length Binary')", this.insertSQL + "(4,3,'Line based Binary')", this.insertSQL + "(4,4,'Mainframe VB (rdw based) Binary')", this.insertSQL + "(4,5,'Mainframe VB Dump: includes Block length')", this.insertSQL + "(4,51,'Delimited, names first line')", this.insertSQL + "(5,0,'No Format')" };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  178 */     this.sql61b = new String[] { this.deleteTbl + "TBLID = 1 and TBLKEY in (2, 3, 9, 10, 41, 71, 72, 73, 74, 75, 110, 111, 112, 115, 116, 117)", this.deleteTbl + "TBLID = 2 and TBLKEY in (6)", this.deleteTbl + "TBLID = 3 and TBLKEY in (9, 99, 101, 102)", this.deleteTbl + "TBLID = 4 and TBLKEY in (0, 1, 2, 3, 4, 5, 7, 51," + 52 + "61, 62)", this.deleteTbl + "TBLID = 5 and TBLKEY in (1, 2, 3, 4, 15)", this.insertSQL + "(1,9,'Num Sign Separate Leading')", this.insertSQL + "(1,10,'Num Sign Separate Trailing')", this.insertSQL + "(1,41,'Fujitsu Zoned Numeric')", this.insertSQL + "(4,0,'Default Reader')", this.insertSQL + "(1,71,'Date - Format in Parameter field')", this.insertSQL + "(1,72,'Date - YYMMDD')", this.insertSQL + "(1,73,'Date - YYYYMMDD')", this.insertSQL + "(1,74,'Date - DDMMYY')", this.insertSQL + "(1,75,'Date - DDMMYYYY')", this.insertSQL + "(1,111,'Checkbox Y/N')", this.insertSQL + "(1,112,'Checkbox T/F')", this.insertSQL + "(1,3,'Char Null padded')", this.insertSQL + "(1,2,'Char Null terminated')", this.insertSQL + "(1," + 116 + ",'XML Name Tag')", this.insertSQL + "(1," + 115 + ",'CSV array')", this.insertSQL + "(1," + 110 + ",'Check Box True / Space')", this.insertSQL + "(1," + 117 + ",'Edit Multi Line field')", this.insertSQL + "(2," + 6 + ",'XML')", this.insertSQL + "(3,9,'Other')", this.insertSQL + "(3,99,'Generic')", this.insertSQL + "(3,101,'CSV')", this.insertSQL + "(3,102,'XML')", this.insertSQL + "(4,1,'Text IO')", this.insertSQL + "(4,2,'Fixed Length Binary')", this.insertSQL + "(4,3,'Line based Binary')", this.insertSQL + "(4,4,'Mainframe VB (rdw based) Binary')", this.insertSQL + "(4,5,'Mainframe VB Dump: includes Block length')", this.insertSQL + "(4,7,'Fujitsu Variable Binary')", this.insertSQL + "(4,51,'Delimited, names first line')", this.insertSQL + "(4," + 52 + ",'Generic CSV (Choose details at run time)')", this.insertSQL + "(4," + 62 + ",'XML - Build Layout')", this.insertSQL + "(4," + 61 + ",'XML - Existing Layout')", this.insertSQL + "(5,1,'Checkbox - use Parameter')", this.insertSQL + "(5,2,'Date - Format in Parameter field')", this.insertSQL + "(5,3,'Date - DDMMYYYY')", this.insertSQL + "(5,4,'Date - YYYYMMDD')", this.insertSQL + "(5," + 15 + ",'ComboBox Format, (combo name in parameter)')", this.insertRecord + "(70,'zzzCsvTest3','Tab Delimited file with CSV array fields',2,101,'Y','','<Tab>','',0,'default','\n',0,'',0,0);", this.insertRecord + "(71,'zzzCsvTest4','Tab Delimited file with CSV array fields',2,101,'Y','','<Tab>','\"',0,'default','\n',0,'',0,0);", this.insertRecord + "(72,'XML - Build Layout','XML file, build the layout based on the files contents'" + ",6,101,'Y','','|','''',0,'default','\n',0,'',0,62);", this.insertRecord + "(73,'zzzCsvTest5','| Delimited file with CSV array fields',2,101,'Y','','|','''',0,'default','\n',0,'',0,0);", this.insertRecord + "(74,'Generic CSV - enter details','Generic CSV - user supplies details',2,101,'Y','','|','',0,'default','\n',0,'',0,52);", this.insertRF + "(70,1,1,0,'Field 1','',0,0,'','',null,0,'');", this.insertRF + "(70,2,2,0,'Array 1 (; and :)','',115,0,'','',null,0,'//:/;/');", this.insertRF + "(70,3,3,0,'Field 3','',0,0,'','',null,0,'');", this.insertRF + "(70,4,4,0,'Array 2 (;)','',115,0,'','',null,0,'//;/');", this.insertRF + "(70,5,5,0,'Field 5','',0,0,'','',null,0,'');", this.insertRF + "(70,6,6,0,'Array 3 (:)','',115,0,'','',null,0,'//:/');", this.insertRF + "(70,7,7,0,'Field 7','',0,0,'','',null,0,'');", this.insertRF + "(71,1,1,0,'Field 1','',0,0,'','',null,0,'');", this.insertRF + "(71,2,2,0,'Array 1 (; and |)','',115,0,'','',null,0,'//|/;/');", this.insertRF + "(71,3,3,0,'Field 3','',0,0,'','',null,0,'');", this.insertRF + "(71,4,4,0,'Array 2 (;)','',115,0,'','',null,0,'//;/');", this.insertRF + "(71,5,5,0,'Field 5','',0,0,'','',null,0,'');", this.insertRF + "(71,6,6,0,'Array 3 (:)','',115,0,'','',null,0,'//:/');", this.insertRF + "(71,7,7,0,'Array 4 (|)','',115,0,'','',null,0,'//|/');", this.insertRF + "(72,1,1,0,'Dummy','1 field is Required for the layout to load'" + ",0,0,'','',null,0,'');", this.insertRF + "(73,1,1,0,'Field 1','',0,0,'','',null,0,'');", this.insertRF + "(73,2,2,0,'Array 1 (; and colon)','',115,0,'','',null,0,'//:/;/');", this.insertRF + "(73,3,3,0,'Field 3','',0,0,'','',null,0,'');", this.insertRF + "(73,4,4,0,'Array 2 (;)','',115,0,'','',null,0,'//;/');", this.insertRF + "(73,5,5,0,'Field 5','',0,0,'','',null,0,'');", this.insertRF + "(73,6,6,0,'Array 3 (colon)','',115,0,'','',null,0,'//:/');", this.insertRF + "(73,7,7,0,'Field 7','',0,0,'','',null,0,'');", this.insertRF + "(74,1,1,0,'Field 1','',0,0,'','',null,0,'');", "Create Table Tbl_C_Combos (Combo_Id   INTEGER, System     smallint, Combo_Name varchar(30), Column_Type smallint);", "CREATE UNIQUE INDEX Tbl_C_Combos_PK  ON Tbl_C_Combos(Combo_Id);", "CREATE UNIQUE INDEX Tbl_C_Combos_PK1 ON Tbl_C_Combos(Combo_Name);", "Create Table Tbl_CI_ComboItems (Combo_Id   INTEGER, Combo_Code varchar(30), Combo_Value varchar(60) );", "CREATE UNIQUE INDEX Tbl_CI_ComboItems_PK ON Tbl_CI_ComboItems(Combo_Id, Combo_Code);" };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  285 */     this.sql69 = new String[] { this.deleteTbl + "TBLID = 1 and TBLKEY in (" + 36 + "," + 35 + "," + 19 + "," + 20 + ")", this.deleteTbl + "TBLID = 4 and TBLKEY in (" + 8 + "," + 55 + "," + 54 + ")", this.deleteTbl + "TBLID = 1 and TBLKEY in (" + 80 + "," + 81 + "," + 37 + "," + 38 + ")", this.deleteTbl + "TBLID = 5 and TBLKEY in (" + 21 + ")", this.insertSQL + "(1," + 35 + ",'Binary Integer Big Endian (Mainframe?)');", this.insertSQL + "(1," + 36 + ",'Positive Integer (Big Endian)');", this.insertSQL + "(4," + 8 + ",'Open Cobol VB');", this.insertSQL + "(4," + 55 + ",'Unicode Csv Names o First Line');", this.insertSQL + "(4," + 54 + ",'Bin Csv Names o First Line ');", this.insertSQL + "(1," + 81 + ",'Char Rest of Record');", this.insertSQL + "(1," + 37 + ",'RM Cobol Comp');", this.insertSQL + "(1," + 38 + ",'RM Cobol Positive Comp');", this.insertSQL + "(1," + 19 + ",'Number any decimal');", this.insertSQL + "(1," + 20 + ",'Number (+ve) any decimal');", this.insertSQL + "(5," + 21 + ",'Bold Format')" };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  312 */     this.sql71 = new String[] { "Drop Table Tbl_RS2_SubRecords", "Drop Table Tbl_RFS_FieldSelection", "Create Table Tbl_RS2_SubRecords (RECORDID   INTEGER, Child_Key          INTEGER, Child_Record       INTEGER, Field_Start        INTEGER, Field_Name         varchar(30), Field_Value        varchar(30), PARENT_RECORDID    INTEGER, Operator_Sequence  smallint, Default_Record     char(1), Child_Name         char(30), Child_Id           INTEGER )", "CREATE UNIQUE INDEX Tbl_RS2_SubRecordsPK  ON Tbl_RS2_SubRecords(RECORDID, Child_Key);", "Create Table Tbl_RFS_FieldSelection (RECORDID         INTEGER, Child_Key        smallint, Field_No         smallint, Boolean_Operator smallint, Field_Name       varchar(30), Operator         char(2), Field_Value      varchar(30) )", "CREATE UNIQUE INDEX Tbl_RFS_FieldSelectionPK  ON Tbl_RFS_FieldSelection(RECORDID, Child_Key, Field_No);" };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  341 */     this.updateVersion = new String[] { this.deleteTbl + "TBLID = " + VERSION_KEY + " and TBLKEY = " + VERSION_KEY + ";", this.insertSQL + "(" + VERSION_KEY + ", " + VERSION_KEY + ", " };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  346 */     this.sql8001 = new String[] { this.deleteTbl + "TBLID = 3 and TBLKEY in (103)", this.insertSQL + "(3, 103, 'System Layouts')" };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  351 */     this.sql90 = new String[] { this.deleteTbl + "TBLID = 1 and TBLKEY in (" + 109 + "," + 118 + ")", this.insertSQL + "(1," + 109 + ",'CheckBox Y/null');", this.insertSQL + "(1," + 118 + ",'Char Multi Line');" };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  361 */     this.sql93a = new String[] { "ALTER TABLE TBL_TI_INTTBLS alter column DETAILS VARCHAR(60);" };
/*      */     
/*      */ 
/*      */ 
/*  365 */     this.sql93 = new String[] { this.deleteTbl + "TBLID = 1 and TBLKEY in (" + 39 + "," + 22 + "," + 33 + "," + 23 + "," + 24 + "," + 25 + "," + 26 + "," + 27 + "," + 28 + "," + 29 + "," + 42 + "," + 43 + "," + 19 + "," + 20 + ");", this.insertSQL + "(1," + 39 + ",'Binary Integer Big Endian (only +ve )');", this.insertSQL + "(1," + 22 + ",'Num Assumed Decimal (+ve)');", this.insertSQL + "(1," + 33 + ",'Mainframe Packed Decimal (+ve)');", this.insertSQL + "(1," + 23 + ",'Binary Integer (only +ve)');", this.insertSQL + "(1," + 24 + ",'Zero Padded Number with sign=+/-');", this.insertSQL + "(1," + 25 + ",'Positive Zero Padded Number');", this.insertSQL + "(1," + 26 + ",'Zero Padded Number decimal=\",\"');", this.insertSQL + "(1," + 27 + ",'Zero Padded Number decimal=\",\" sign=+/-');", this.insertSQL + "(1," + 28 + ",'Zero Padded Number decimal=\",\" (only +ve)');", this.insertSQL + "(1," + 29 + ",'Num (Right Justified space padded) +/-');", this.insertSQL + "(1," + 42 + ",'Num (Right Just space padded, \",\" Decimal)');", this.insertSQL + "(1," + 43 + ",'Num (Right Just space padded, \",\" Decimal) +/-');", this.insertSQL + "(1," + 19 + ",'Number any decimal');", this.insertSQL + "(1," + 20 + ",'Number (+ve) any decimal');" };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  407 */     this.sql94 = new String[] { "Drop Table TBL_RF1_RECORDFIELDS;", "CREATE TABLE TBL_RF1_RECORDFIELDS (    RECORDID            INTEGER,    SUB_KEY             integer,    FIELD_POS           integer,    FIELD_LENGTH        integer,    FIELD_NAME          varchar(120),    FIELD_DESCRIPTION   varchar(250),    FIELD_TYPE          integer,    DECIMAL_POS         smallint,    DEFAULT_VALUE       varchar(120),    COBOL_NAME          varchar(30),    FORMAT_DESCRIPTION  varchar(250),    Cell_Format         integer,    Field_Parameter     varchar(120)  );", "CREATE UNIQUE INDEX TBL_RF1_RECORDFIELDS_PK ON TBL_RF1_RECORDFIELDS(RECORDID, SUB_KEY); " };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  430 */     this.sql95c = new String[] { this.deleteTbl + " TBLID = 1 and TBLKEY in (" + 119 + ", " + 92 + ", " + 51 + ", " + 118 + ");", this.insertSQL + "(1," + 118 + ",'Char Multi Line');", this.insertSQL + "(1," + 119 + ",'Html Field');", this.insertSQL + "(1," + 92 + ",'Array Field');" };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  448 */     this.sql96h_1 = new String[] { "ALTER TABLE TBL_TI_INTTBLS alter column DETAILS VARCHAR(75);" };
/*      */     
/*      */ 
/*      */ 
/*  452 */     this.sql96h_2 = new String[] { this.deleteTbl + " TBLID = 1 and TBLKEY in (" + 51 + ");" };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  460 */     this.types96h = new int[] { 0, 19, 20, 1, 2, 3, 4, 5, 6, 29, 42, 43, 7, 24, 8, 22, 25, 26, 27, 28, 9, 10, 11, 15, 23, 16, 17, 18, 21, 31, 33, 32, 35, 39, 36, 41, 37, 38, 114, 71, 72, 73, 74, 75, 110, 109, 111, 112, 115, 116, 117, 80, 81, 118, 119, 92 };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  546 */     this.fileWizardXmlLayout = "<?xml version=\"1.0\" ?>\n<RECORD RECORDNAME=\"FileWizard\" COPYBOOK=\"\" DELIMITER=\"&lt;Tab&gt;\" FILESTRUCTURE=\"FILE_WIZARD\" STYLE=\"0\" RECORDTYPE=\"RecordLayout\" LIST=\"Y\" QUOTE=\"\" RecSep=\"default\" LINE_NO_FIELD_NAMES=\"1\">\n\t<FIELDS><FIELD NAME=\"Dummy\" POSITION=\"1\" LENGTH=\"1\" TYPE=\"Char\"/></FIELDS>\n</RECORD>";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  552 */     this.deleteExample = " where RECORDID   in (Select r.RECORDID from TBL_R_RECORDS r where r.RECORDNAME in ('Price', 'SPL', 'Line_Test_Group', 'Mainframe FB80', 'PO Master', 'DCR0470 S14', 'DCR0470 T31', 'DCR0470 P41', 'DCR0470 I51', 'DCR0470 I52', 'SAR4180B', 'SAR4180C', 'IVR0075H', 'IVR0075S', 'ams PO Download: Detail', 'ams PO Download: Header', 'ams PO Download: Allocation', 'ams PO Download', 'ams Vendor Download', 'ams Rct Upload FH Header', 'ams Rct Upload: RH', 'ams Rct Upload: RD', 'ams Rct Upload: FT footer', 'ams Receipt (Taret Fields only)', 'ams shp Upload FH Header', 'ams shp Upload DH', 'ams shp Upload DO', 'ams shp Upload DS','ams shp Upload AP', 'ams shp Upload AR', 'ams shp Upload DP','ams shp Upload DI', 'ams shp Upload FT', 'ams Shipping Upload', 'ams Store', 'ams Receipt FH Header', 'ams Receipt RH Receipt Header', 'ams Receipt RD Recipt Product', 'ams Receipt RS Recipt Store','ams Receipt AS', 'ams Receipt SO', 'ams Receipt SC', 'ams Receipt AP','ams Receipt AR', 'ams Receipt FT File Trailer', 'ams Receipt', 'PO Head','PO Detail', 'DCR0470 S11', 'DCR0470 S12', 'PriceR 8', 'PriceR 9', 'PriceR 3', 'PriceR 1', 'PriceR F', 'PriceR 5', 'PriceR L', 'SPL End','SPL M', 'SPL 1', 'SPL 8', 'PriceR 2', 'PriceR D', 'SPL HD', 'SPL 3', 'SPL 4', 'SPL 6', 'PriceR 4', 'PriceR 6', 'SPL N', 'SAR4180A','IVR0075D', 'Line_Test_Record', 'DTAR119', 'DTAR192', 'Mainframe Text', 'DTAR107', 'DTAR020', 'DCR0470 O21','Mainframe FB80 record', 'DCR0470 S13', 'EDI Sales', 'EDI ASN (DCR0470)', 'EDI PO', 'DTAR1000 VB', 'XmplEditType1', 'XmplDecider', 'XMPLDECIDER-Product-Header', 'XMPLDECIDER-Product-Detail-1', 'XMPLDECIDER-Product-Detail-2', 'DTAR1000 VB Dump', 'Master_Record','Rental_Record', 'Transaction_Record',  'XfeDTAR020', 'XfeDTAR020_reverse','cpyComp5Sync', 'bsCompSync', 'cpyCompPositive','cpyCompSync', 'mfCompPositive', 'mfCompSync', 'Wizard_AmsPo' ))";
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void updateRecordSepList(int dbIdx)
/*      */   {
/*      */     try
/*      */     {
/*  594 */       Connection con = Common.getDBConnection(dbIdx);
/*  595 */       Statement statement = con.createStatement();
/*      */       
/*  597 */       statement.executeUpdate(this.updateRecordSep);
/*  598 */       statement.close();
/*      */     } catch (Exception e) {
/*  600 */       Common.getLogger().logException(30, e);
/*      */       
/*  602 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void upgrade55(int dbIdx)
/*      */   {
/*      */     try
/*      */     {
/*  635 */       Connection con = Common.getDBConnection(dbIdx);
/*  636 */       runSQL(con.createStatement(), this.sql55, Common.isDropSemi(dbIdx));
/*      */       
/*  638 */       addColumnToDB(con, "TBL_R_RECORDS", "File_Structure", "Int", "0");
/*  639 */       addColumnToDB(con, "Tbl_RF_RecordFields", "Cell_Format", "Int", "0");
/*  640 */       addColumnToDB(con, "Tbl_RF_RecordFields", "Parameter", "Varchar(80)", "''");
/*      */     } catch (Exception e) {
/*  642 */       Common.getLogger().logException(30, e);
/*  643 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void upgrade61b(int dbIdx)
/*      */   {
/*  671 */     genericUpgrade(dbIdx, this.sql61b, null);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void upgrade69(int dbIdx)
/*      */   {
/*  680 */     genericUpgrade(dbIdx, this.sql69, VERSION_692B);
/*      */     
/*  682 */     for (int i = 0; i < this.unknownStructure.length; i++) {
/*  683 */       addLayout(dbIdx, "Unknown " + this.unknownNames[i], this.unknownLine1Pt1 + this.unknownStructure[i] + this.unknownLine1Pt2 + this.unknownNames[i] + "\n" + this.unknownLine2, this.unknownFonts[i], 0);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  693 */     addLayout(dbIdx, "Unknown Format", this.unknownFormatLines, "", 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void addLayout(int dbIdx, String name, String txt, String font, int system)
/*      */   {
/*  701 */     byte[] bytes = txt.getBytes();
/*  702 */     ByteArrayInputStream in = new ByteArrayInputStream(bytes);
/*      */     
/*      */ 
/*  705 */     ExtendedRecordDB db = new ExtendedRecordDB();
/*  706 */     db.setConnection(new ReConnection(dbIdx));
/*  707 */     db.resetSearch();
/*  708 */     db.setSearchRecordName("=", name);
/*  709 */     db.open();
/*  710 */     RecordRec rec = db.fetch();
/*      */     
/*  712 */     if (rec != null) {
/*  713 */       db.delete(rec);
/*  714 */       Common.getLogger().logMsg(30, LeMessages.DELETE_LAYOUT.get(name));
/*      */     }
/*      */     
/*  717 */     ExternalRecord ext = ExternalRecord.getNullRecord(name, 0, font);
/*      */     
/*      */ 
/*      */ 
/*  721 */     ext.setSystem(system);
/*      */     
/*  723 */     new RecordEditorCsvLoader("\t").insertFields(Common.getLogger(), ext, new InputStreamReader(in), name, dbIdx);
/*      */     
/*      */ 
/*  726 */     rec = new RecordRec(ext);
/*  727 */     db.insert(rec);
/*  728 */     Common.getLogger().logMsg(30, LeMessages.ADD_LAYOUT.get(name));
/*  729 */     db.close();
/*      */   }
/*      */   
/*      */   public void upgrade71(int dbIdx)
/*      */   {
/*  734 */     upgrade80(dbIdx, "Tbl_RS_SubRecords");
/*      */   }
/*      */   
/*      */   public void upgrade80(int dbIdx, String tbl)
/*      */   {
/*  739 */     genericUpgrade(dbIdx, this.sql71, null);
/*      */     
/*  741 */     List<ChildRecordsRec> list = new ArrayList();
/*  742 */     String sSQL = " Select  RecordId, ChildRecord, FieldStart, Field, FieldValue, PARENT_RECORDID  from " + tbl + " Order by RecordId, ChildRecord";
/*      */     
/*      */ 
/*  745 */     String insertSQL = "Insert Into  Tbl_RS2_SubRecords  (    RecordId  , Child_Key  , Child_Record  , Field_Start  , Field_Name  , Field_Value  , PARENT_RECORDID  , Operator_Sequence  , Default_Record  , Child_Name  , Child_Id) Values (     ?   , ?   , ?   , ?   , ?, ?, ?, ?, ?, ?, ?)";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  762 */     int lastRecordId = Integer.MIN_VALUE;
/*  763 */     int childNo = 0;
/*      */     
/*  765 */     int operatorSeq = 0;
/*      */     
/*  767 */     int count = 0;
/*      */     try {
/*  769 */       Connection connect = Common.getUpdateConnection(dbIdx);
/*  770 */       ResultSet resultset = connect.createStatement().executeQuery(sSQL);
/*  771 */       PreparedStatement insertStatement = connect.prepareStatement(insertSQL);
/*      */       
/*  773 */       while (resultset.next()) {
/*  774 */         int recordId = resultset.getInt(1);
/*      */         
/*  776 */         if (recordId == lastRecordId) {
/*  777 */           childNo++;
/*      */         } else {
/*  779 */           insertChildren(lastRecordId, list, insertStatement);
/*  780 */           childNo = 0;
/*  781 */           lastRecordId = recordId;
/*      */         }
/*  783 */         int childRecord = resultset.getInt(2);
/*  784 */         int fieldStart = resultset.getInt(3);
/*  785 */         String field = resultset.getString(4);
/*  786 */         String fieldValue = resultset.getString(5);
/*  787 */         int parentId = resultset.getInt(6);
/*  788 */         list.add(new ChildRecordsRec(childRecord, fieldStart, field, fieldValue, parentId, childNo, operatorSeq, false, "", childNo));
/*      */         
/*      */ 
/*      */ 
/*  792 */         count++;
/*      */       }
/*  794 */       insertChildren(lastRecordId, list, insertStatement);
/*  795 */       Common.logMsgRaw(30, DATABASE_UPGRADED + VERSION_800 + " , child record copied " + count, null);
/*      */       
/*  797 */       insertStatement.close();
/*      */       
/*  799 */       addFileWizardReader(dbIdx);
/*      */     } catch (SQLException e) {
/*  801 */       e.printStackTrace();
/*  802 */       Common.logMsg("Database upgrade failed !!!", null);
/*      */     } finally {
/*  804 */       Common.freeConnection(dbIdx);
/*      */     }
/*      */   }
/*      */   
/*      */   public void upgrade90(int dbIdx)
/*      */   {
/*      */     try
/*      */     {
/*  812 */       genericUpgrade(dbIdx, this.sql90, null);
/*      */       
/*  814 */       loadLayout(dbIdx, "<?xml version=\"1.0\" ?><RECORD RECORDNAME=\"GetText_PO\" COPYBOOK=\"\" DELIMITER=\"&lt;Tab&gt;\" FILESTRUCTURE=\"101\" STYLE=\"0\" RECORDTYPE=\"Delimited\" LIST=\"Y\" QUOTE=\"\" RecSep=\"default\" LINE_NO_FIELD_NAMES=\"1\">\t<FIELDS>\t\t<FIELD NAME=\"msgctxt\" POSITION=\"1\" TYPE=\"118\"/>\t\t<FIELD NAME=\"msgid\" POSITION=\"2\" TYPE=\"118\"/>\t\t<FIELD NAME=\"msgstr\" POSITION=\"3\" TYPE=\"118\"/>\t\t<FIELD NAME=\"comments\" POSITION=\"4\" TYPE=\"118\"/>\t\t<FIELD NAME=\"msgidPlural\" POSITION=\"5\" TYPE=\"118\"/>\t\t<FIELD NAME=\"msgstrPlural\" POSITION=\"6\" TYPE=\"92\"/>\t\t<FIELD NAME=\"extractedComments\" POSITION=\"7\" TYPE=\"118\"/>\t\t<FIELD NAME=\"reference\" POSITION=\"8\" TYPE=\"118\"/>\t\t<FIELD NAME=\"flags\" POSITION=\"9\" TYPE=\"118\"/>\t\t<FIELD NAME=\"previousMsgctx\" POSITION=\"10\" TYPE=\"118\"/>\t\t<FIELD NAME=\"previousMsgId\" POSITION=\"11\" TYPE=\"118\"/>\t\t<FIELD NAME=\"previousMsgidPlural\" POSITION=\"12\" TYPE=\"118\"/>\t\t<FIELD NAME=\"fuzzy\" POSITION=\"13\" TYPE=\"109\"/>\t\t<FIELD NAME=\"obsolete\" POSITION=\"14\" TYPE=\"109\"/>\t</FIELDS></RECORD>", 103, false);
/*  815 */       loadLayout(dbIdx, "<?xml version=\"1.0\" ?><RECORD RECORDNAME=\"TipDetails\" COPYBOOK=\"\" DELIMITER=\"&lt;Tab&gt;\" FILESTRUCTURE=\"102\" STYLE=\"0\" RECORDTYPE=\"Delimited\"  LIST=\"Y\" QUOTE=\"\" RecSep=\"default\" LINE_NO_FIELD_NAMES=\"1\">\t<FIELDS>\t\t<FIELD NAME=\"name\" POSITION=\"1\" TYPE=\"Char\"/>\t\t<FIELD NAME=\"description\" POSITION=\"2\" TYPE=\"118\"/>\t</FIELDS></RECORD>", 103, false);
/*      */       
/*  817 */       upgradeVersion(new ReConnection(dbIdx).getConnection(), dbIdx, VERSION_90);
/*  818 */       Common.logMsgRaw(30, DATABASE_UPGRADED + VERSION_90, null);
/*      */       
/*  820 */       upgrade93(dbIdx);
/*      */     } catch (Exception e) {
/*  822 */       Common.logMsg("Error updating version flag", e);
/*      */     }
/*      */   }
/*      */   
/*      */   public void upgrade93(int dbIdx)
/*      */   {
/*      */     try
/*      */     {
/*  830 */       if (Common.alterVarChar(dbIdx)) {
/*  831 */         genericUpgrade(dbIdx, this.sql93a, null);
/*      */       }
/*  833 */       genericUpgrade(dbIdx, this.sql93, null);
/*      */       
/*  835 */       upgradeVersion(new ReConnection(dbIdx).getConnection(), dbIdx, VERSION_932);
/*  836 */       Common.logMsgRaw(30, DATABASE_UPGRADED + VERSION_932, null);
/*      */     } catch (Exception e) {
/*  838 */       Common.logMsg("Error updating version flag", e);
/*      */     }
/*      */   }
/*      */   
/*      */   public void upgrade94(int dbIdx)
/*      */   {
/*  844 */     genericUpgrade(dbIdx, this.sql94, null);
/*      */     
/*  846 */     String sSQL = " Select  RECORDID, SUBKEY, FIELDPOS, FIELDLENGTH, FIELDNAME, DESCRIPTION,   FIELDTYPE, DECIMALPOS, DEFAULTVALUE, COBOLNAME, FORMATDESCRIPTION,  Cell_Format, Parameter   from TBL_RF_RECORDFIELDS  Order by RecordId, SUBKEY";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  851 */     String insertSQL = "Insert Into  TBL_RF1_RECORDFIELDS  (    RECORDID ,  SUB_KEY ,  FIELD_POS ,  FIELD_LENGTH ,  FIELD_NAME ,  FIELD_DESCRIPTION ,  FIELD_TYPE ,  DECIMAL_POS ,  DEFAULT_VALUE ,  COBOL_NAME ,  FORMAT_DESCRIPTION ,  Cell_Format ,  Field_Parameter) Values (     ?   , ?   , ?   , ?   , ?, ?, ?, ?, ?, ?, ?, ?, ?)";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  868 */     String copySql = " INSERT INTO TBL_RF1_RECORDFIELDS           ( RECORDID, SUB_KEY, FIELD_POS, FIELD_LENGTH, FIELD_NAME, FIELD_DESCRIPTION,             FIELD_TYPE, DECIMAL_POS, DEFAULT_VALUE, COBOL_NAME, FORMAT_DESCRIPTION,             Cell_Format, Field_Parameter ) SELECT RecordId, SubKey, FieldPos, FieldLength, FieldName, Description, FieldType,        DecimalPos, DefaultValue, CobolName, FormatDescription, Cell_Format, Parameter FROM Tbl_RF_RecordFields;";
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  877 */     int count = 0;
/*      */     try
/*      */     {
/*  880 */       Connection connect = Common.getUpdateConnection(dbIdx);
/*      */       
/*  882 */       if (Common.useCopySql(dbIdx)) {
/*  883 */         PreparedStatement copyStatement = connect.prepareStatement(copySql);
/*  884 */         copyStatement.executeUpdate();
/*  885 */         count = copyStatement.getUpdateCount();
/*  886 */         System.out.println("Copy Done !!!");
/*  887 */         copyStatement.close();
/*      */       } else {
/*  889 */         ResultSet resultset = connect.createStatement().executeQuery(sSQL);
/*  890 */         PreparedStatement insertStatement = connect.prepareStatement(insertSQL);
/*      */         
/*  892 */         while (resultset.next())
/*      */         {
/*  894 */           int idx = 1;
/*  895 */           insertStatement.setInt(idx, resultset.getInt(idx++));
/*  896 */           insertStatement.setInt(idx, resultset.getInt(idx++));
/*  897 */           insertStatement.setInt(idx, resultset.getInt(idx++));
/*  898 */           insertStatement.setInt(idx, resultset.getInt(idx++));
/*  899 */           insertStatement.setString(idx, resultset.getString(idx++));
/*  900 */           insertStatement.setString(idx, resultset.getString(idx++));
/*  901 */           insertStatement.setInt(idx, resultset.getInt(idx++));
/*  902 */           insertStatement.setInt(idx, resultset.getInt(idx++));
/*  903 */           insertStatement.setString(idx, resultset.getString(idx++));
/*  904 */           insertStatement.setString(idx, resultset.getString(idx++));
/*  905 */           insertStatement.setString(idx, resultset.getString(idx++));
/*  906 */           insertStatement.setInt(idx, resultset.getInt(idx++));
/*  907 */           insertStatement.setString(idx, resultset.getString(idx++));
/*      */           
/*  909 */           insertStatement.executeUpdate();
/*  910 */           count++;
/*      */         }
/*      */         
/*      */ 
/*  914 */         insertStatement.close();
/*  915 */         resultset.close();
/*      */       }
/*  917 */       Common.logMsgRaw(30, DATABASE_UPGRADED + VERSION_94 + " , Fields copied " + count, null);
/*      */       
/*      */ 
/*  920 */       upgradeVersion(new ReConnection(dbIdx).getConnection(), dbIdx, VERSION_94);
/*      */       
/*  922 */       upgrade96(dbIdx);
/*      */     } catch (SQLException e) {
/*  924 */       e.printStackTrace();
/*  925 */       Common.logMsg("Database upgrade failed !!!", null);
/*      */     } finally {
/*  927 */       Common.freeConnection(dbIdx);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void upgrade96(int dbIdx)
/*      */   {
/*      */     try
/*      */     {
/*  943 */       if (Common.alterVarChar(dbIdx)) {
/*  944 */         genericUpgrade(dbIdx, this.sql96h_1, VERSION_96Ha);
/*      */       }
/*  946 */       upgrade96a(dbIdx);
/*      */     } catch (Exception e) {
/*  948 */       Common.logMsg("Error updating version flag", e);
/*      */     }
/*      */   }
/*      */   
/*      */   public void upgrade96a(int dbIdx) {
/*  953 */     genericUpgrade(dbIdx, this.sql95c, null);
/*  954 */     loadLayout(dbIdx, "<?xml version=\"1.0\" ?><RECORD RECORDNAME=\"GetText_PO\" COPYBOOK=\"\" DELIMITER=\"&lt;Tab&gt;\" FILESTRUCTURE=\"101\" STYLE=\"0\" RECORDTYPE=\"Delimited\" LIST=\"Y\" QUOTE=\"\" RecSep=\"default\" LINE_NO_FIELD_NAMES=\"1\">\t<FIELDS>\t\t<FIELD NAME=\"msgctxt\" POSITION=\"1\" TYPE=\"118\"/>\t\t<FIELD NAME=\"msgid\" POSITION=\"2\" TYPE=\"118\"/>\t\t<FIELD NAME=\"msgstr\" POSITION=\"3\" TYPE=\"118\"/>\t\t<FIELD NAME=\"comments\" POSITION=\"4\" TYPE=\"118\"/>\t\t<FIELD NAME=\"msgidPlural\" POSITION=\"5\" TYPE=\"118\"/>\t\t<FIELD NAME=\"msgstrPlural\" POSITION=\"6\" TYPE=\"92\"/>\t\t<FIELD NAME=\"extractedComments\" POSITION=\"7\" TYPE=\"118\"/>\t\t<FIELD NAME=\"reference\" POSITION=\"8\" TYPE=\"118\"/>\t\t<FIELD NAME=\"flags\" POSITION=\"9\" TYPE=\"118\"/>\t\t<FIELD NAME=\"previousMsgctx\" POSITION=\"10\" TYPE=\"118\"/>\t\t<FIELD NAME=\"previousMsgId\" POSITION=\"11\" TYPE=\"118\"/>\t\t<FIELD NAME=\"previousMsgidPlural\" POSITION=\"12\" TYPE=\"118\"/>\t\t<FIELD NAME=\"fuzzy\" POSITION=\"13\" TYPE=\"109\"/>\t\t<FIELD NAME=\"obsolete\" POSITION=\"14\" TYPE=\"109\"/>\t</FIELDS></RECORD>", 103, true);
/*  955 */     loadLayout(dbIdx, "<?xml version=\"1.0\" ?><RECORD RECORDNAME=\"TipDetails\" COPYBOOK=\"\" DELIMITER=\"&lt;Tab&gt;\" FILESTRUCTURE=\"102\" STYLE=\"0\" RECORDTYPE=\"Delimited\"  LIST=\"Y\" QUOTE=\"\" RecSep=\"default\" LINE_NO_FIELD_NAMES=\"1\">\t<FIELDS>\t\t<FIELD NAME=\"name\" POSITION=\"1\" TYPE=\"Char\"/>\t\t<FIELD NAME=\"description\" POSITION=\"2\" TYPE=\"118\"/>\t</FIELDS></RECORD>", 103, true);
/*      */     
/*  957 */     updateTypeNames(dbIdx, this.types96h);
/*  958 */     genericUpgrade(dbIdx, this.sql96h_2, VERSION_96H);
/*      */   }
/*      */   
/*      */ 
/*      */   public void updateTypeNames(int dbIdx, int[] types)
/*      */   {
/*  964 */     BasicConversion b = new BasicConversion();
/*  965 */     String sql = "";
/*      */     try
/*      */     {
/*  968 */       Connection con = new ReConnection(dbIdx).getConnection();
/*  969 */       Statement statement = con.createStatement();
/*  970 */       for (int i = 0; i < types.length; i++) {
/*  971 */         String typeName = b.getTypeAsString(dbIdx, types[i]);
/*  972 */         int n = 0;
/*  973 */         sql = "update TBL_TI_INTTBLS set DETAILS = '" + typeName + "' where  TBLID = 1 and TBLKEY = " + types[i] + ";";
/*      */         
/*      */         try
/*      */         {
/*  977 */           n = statement.executeUpdate(sql);
/*      */         }
/*      */         catch (Exception e) {}
/*      */         
/*      */ 
/*  982 */         if (n == 0) {
/*      */           try {
/*  984 */             sql = this.insertSQL + "(1," + types[i] + ",'" + typeName + "');";
/*  985 */             System.out.println("Insert Sql: " + sql);
/*  986 */             statement.executeUpdate(sql);
/*      */           } catch (Exception e1) {
/*  988 */             e1.printStackTrace();
/*      */           }
/*      */         }
/*      */       }
/*      */     } catch (Exception e) {
/*  993 */       Common.logMsgRaw("Sql: " + sql, e);
/*  994 */       Common.logMsgRaw("Error deleting Examples", e);
/*      */       
/*  996 */       System.out.println("Sql: " + sql);
/*  997 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */   
/*      */   public void deleteExamples(int dbIdx)
/*      */   {
/* 1003 */     String[] tbls = { "TBL_RFS_FIELDSELECTION", "TBL_RF1_RECORDFIELDS", "TBL_RS2_SUBRECORDS", "TBL_R_RECORDS" };
/* 1004 */     String sql = "";
/*      */     try {
/* 1006 */       Connection con = new ReConnection(dbIdx).getConnection();
/* 1007 */       Statement statement = con.createStatement();
/* 1008 */       for (int i = 0; i < tbls.length; i++) {
/* 1009 */         sql = "Delete from " + tbls[i] + this.deleteExample;
/* 1010 */         statement.execute(sql);
/*      */       }
/*      */     } catch (Exception e) {
/* 1013 */       Common.logMsgRaw("Sql: " + sql, e);
/* 1014 */       Common.logMsgRaw("Error deleting Examples", e);
/*      */       
/* 1016 */       System.out.println("Sql: " + sql);
/* 1017 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */   
/*      */   public final void addFileWizardReader(int dbIdx) throws SQLException
/*      */   {
/* 1023 */     Connection connect = Common.getUpdateConnection(dbIdx);
/*      */     
/* 1025 */     genericUpgrade(dbIdx, this.sql8001, null);
/*      */     try
/*      */     {
/* 1028 */       loadLayout(dbIdx, this.fileWizardXmlLayout, 103, false);
/*      */       
/* 1030 */       upgradeVersion(connect, dbIdx, VERSION_801);
/* 1031 */       Common.logMsgRaw(30, DATABASE_UPGRADED + VERSION_801, null);
/* 1032 */       System.out.println("Current Version: " + VERSION_801);
/*      */       
/* 1034 */       upgrade90(dbIdx);
/*      */     } catch (Exception e) {
/* 1036 */       Common.logMsg("Could not load FileWizardReader", e);
/* 1037 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */   
/*      */   private void loadLayout(int dbIdx, String xml, int systemId, boolean doDelete) {
/* 1042 */     this.holdLayoutDetails.add(new LayoutDef(dbIdx, xml, systemId, doDelete));
/*      */   }
/*      */   
/*      */   public final void loadHeldLayouts() {
/*      */     try {
/* 1047 */       for (LayoutDef l : this.holdLayoutDetails) {
/* 1048 */         loadALayout(l);
/*      */       }
/* 1050 */       this.holdLayoutDetails.removeAll(this.holdLayoutDetails);
/*      */     } catch (Exception e) {
/* 1052 */       Common.logMsg("Could not load Layouts: " + e.toString(), e);
/*      */     }
/*      */   }
/*      */   
/*      */   private void loadALayout(LayoutDef l) throws Exception
/*      */   {
/* 1058 */     ExternalRecord rec = RecordEditorXmlLoader.getExternalRecord(l.xml, "FileWizard");
/* 1059 */     ExtendedRecordDB db = new ExtendedRecordDB();
/*      */     
/* 1061 */     rec.setSystem(l.systemId);
/* 1062 */     System.out.println("FileStructure: " + rec.getFileStructure() + " " + new RecordRec(rec).getValue().getFileStructure() + " " + rec.getRecordStyle());
/*      */     
/*      */ 
/* 1065 */     db.setConnection(new ReConnection(l.dbIdx));
/*      */     
/* 1067 */     if (l.doDelete) {
/*      */       try {
/* 1069 */         db.resetSearch();
/* 1070 */         db.setSearchRecordName("=", rec.getRecordName());
/* 1071 */         db.open();
/* 1072 */         RecordRec rec1 = db.fetch();
/* 1073 */         if (rec1 != null) {
/* 1074 */           db.delete(rec1);
/*      */         }
/*      */       } catch (Exception e) {
/* 1077 */         e.printStackTrace();
/*      */       }
/*      */     }
/* 1080 */     db.insert(new RecordRec(rec));
/* 1081 */     db.close();
/*      */   }
/*      */   
/*      */   private void insertChildren(int recordId, List<ChildRecordsRec> list, PreparedStatement insertStatement) throws SQLException
/*      */   {
/* 1086 */     if (list.size() > 0) {
/* 1087 */       HashMap<Integer, ChildRecordsRec> lookup = new HashMap();
/*      */       
/*      */ 
/* 1090 */       for (ChildRecordsRec child : list) {
/* 1091 */         lookup.put(Integer.valueOf(child.getChildRecordId()), child);
/*      */       }
/* 1093 */       for (ChildRecordsRec child : list) {
/* 1094 */         if (child.getParentRecord() >= 0) {
/* 1095 */           ChildRecordsRec parent = (ChildRecordsRec)lookup.get(Integer.valueOf(child.getParentRecord()));
/* 1096 */           if (parent == null) {
/* 1097 */             child.setParentRecord(-1);
/*      */           } else {
/* 1099 */             child.setParentRecord(parent.getChildId());
/*      */           }
/*      */         }
/*      */         
/* 1103 */         int idx = 1;
/* 1104 */         insertStatement.setInt(idx++, recordId);
/* 1105 */         insertStatement.setInt(idx++, child.getChildKey());
/* 1106 */         insertStatement.setInt(idx++, child.getChildRecordId());
/* 1107 */         insertStatement.setInt(idx++, child.getStart());
/* 1108 */         insertStatement.setString(idx++, child.getField());
/* 1109 */         insertStatement.setString(idx++, child.getFieldValue());
/* 1110 */         insertStatement.setInt(idx++, child.getParentRecord());
/* 1111 */         insertStatement.setInt(idx++, child.getOperatorSequence());
/* 1112 */         insertStatement.setString(idx++, "N");
/* 1113 */         insertStatement.setString(idx++, "");
/* 1114 */         insertStatement.setInt(idx++, child.getChildId());
/*      */         
/* 1116 */         insertStatement.executeUpdate();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/* 1121 */       list.clear();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private boolean genericUpgrade(int dbIdx, String[] sql2run, String version)
/*      */   {
/* 1131 */     boolean ret = false;
/* 1132 */     boolean dropSemi = Common.isDropSemi(dbIdx);
/*      */     try
/*      */     {
/* 1135 */       Connection con = Common.getUpdateConnection(dbIdx);
/* 1136 */       runSQL(con.createStatement(), sql2run, dropSemi);
/*      */       
/* 1138 */       upgradeVersion(con, dbIdx, version);
/* 1139 */       Common.logMsg(30, "Upgrade SQL Run !!!", null);
/*      */       
/* 1141 */       ret = true;
/*      */     } catch (Exception e) {
/* 1143 */       Common.getLogger().logException(30, e);
/* 1144 */       e.printStackTrace();
/*      */     } finally {
/* 1146 */       Common.freeConnection(dbIdx);
/*      */     }
/*      */     
/* 1149 */     return ret;
/*      */   }
/*      */   
/*      */   private void upgradeVersion(Connection con, int dbIdx, String version) throws SQLException {
/* 1153 */     if (version != null) {
/* 1154 */       String oldVersion = getVersion(dbIdx);
/*      */       try
/*      */       {
/* 1157 */         if (Integer.parseInt(oldVersion) >= Integer.parseInt(version)) {
/* 1158 */           return;
/*      */         }
/*      */       }
/*      */       catch (Exception e) {}
/* 1162 */       String[] sql = new String[2];
/* 1163 */       sql[0] = this.updateVersion[0];
/* 1164 */       sql[1] = (this.updateVersion[1] + "'" + version + "');");
/* 1165 */       runSQL(con.createStatement(), sql, Common.isDropSemi(dbIdx));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void runSQL(Statement statement, String[] sqlToRun, boolean dropSemi)
/*      */   {
/* 1179 */     for (int i = 0; i < sqlToRun.length; i++) {
/*      */       try {
/* 1181 */         String sql = sqlToRun[i];
/* 1182 */         if ((dropSemi) && (sql.trim().endsWith(";"))) {
/* 1183 */           sql = sql.trim();
/* 1184 */           sql = sql.substring(0, sql.length() - 1);
/*      */         }
/* 1186 */         System.out.println(" ----> " + sql);
/*      */         
/* 1188 */         statement.executeUpdate(sql);
/* 1189 */         System.out.println(" ~~ Done ~~");
/*      */       } catch (Exception e) {
/* 1191 */         Common.logMsgRaw(LeMessages.SQL_ERROR.get(new Object[] { sqlToRun[i], e.getMessage() }), null);
/*      */         
/*      */ 
/*      */ 
/* 1195 */         System.out.println();
/* 1196 */         System.out.println("    SQL: " + sqlToRun[i]);
/* 1197 */         System.out.println("Message: " + e.getMessage());
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void addColumnToDB(Connection con, String table, String column, String type, String initValue)
/*      */   {
/* 1214 */     boolean upgradeDB = false;
/*      */     try
/*      */     {
/* 1217 */       ResultSet resultset = con.createStatement().executeQuery("select " + column + " from " + table);
/*      */       
/*      */ 
/*      */ 
/* 1221 */       resultset.next();
/* 1222 */       resultset.close();
/*      */     } catch (Exception e) {
/* 1224 */       upgradeDB = true;
/*      */     }
/*      */     
/* 1227 */     if (upgradeDB) {
/*      */       try {
/* 1229 */         Statement statement = con.createStatement();
/*      */         
/* 1231 */         statement.execute("ALTER TABLE " + table + " ADD " + column + " " + type);
/*      */         
/*      */ 
/*      */ 
/*      */ 
/* 1236 */         statement.execute("update " + table + " set " + column + " = " + initValue + " where " + column + " is null ");
/*      */ 
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */ 
/* 1242 */         String msg = LeMessages.ERROR_UPDATING_TABLE.get() + " " + table + " " + e.getMessage();
/*      */         
/* 1244 */         Common.getLogger().logMsg(30, msg);
/* 1245 */         System.out.println(msg);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public static boolean checkForUpdate(int dbIndex)
/*      */   {
/* 1252 */     boolean ret = false;
/*      */     
/* 1254 */     boolean free = Common.isSetDoFree(false);
/*      */     try {
/* 1256 */       String version = getVersion(dbIndex);
/* 1257 */       UpgradeDB db = new UpgradeDB();
/*      */       
/* 1259 */       if (version != null) {
/* 1260 */         System.out.print("Upgrade Version: " + version);
/* 1261 */         if (VERSION_692B.equals(version)) {
/* 1262 */           db.upgrade71(dbIndex);
/* 1263 */           db.upgrade94(dbIndex);
/* 1264 */         } else if (VERSION_700.equals(version)) {
/* 1265 */           db.upgrade80(dbIndex, "Tbl_RS1_SubRecords");
/* 1266 */           db.upgrade94(dbIndex);
/* 1267 */         } else if (VERSION_800.equals(version)) {
/* 1268 */           db.addFileWizardReader(dbIndex);
/* 1269 */           db.upgrade94(dbIndex);
/* 1270 */         } else if (VERSION_801.equals(version)) {
/* 1271 */           db.upgrade90(dbIndex);
/* 1272 */           db.upgrade94(dbIndex);
/* 1273 */         } else if ((VERSION_90.equals(version)) || (VERSION_93.equals(version)) || (VERSION_931.equals(version)) || (VERSION_932.equals(version)))
/*      */         {
/* 1275 */           db.upgrade93(dbIndex);
/* 1276 */           db.upgrade94(dbIndex);
/* 1277 */         } else if ((VERSION_94.equals(version)) || (VERSION_95C.equals(version)) || (VERSION_95D.equals(version)) || (VERSION_95E.equals(version))) {
/* 1278 */           db.upgrade96(dbIndex);
/* 1279 */         } else if (VERSION_96Ha.equals(version)) {
/* 1280 */           db.upgrade96a(dbIndex);
/* 1281 */         } else if (version.compareTo(LATEST_VERSION) > 0) {
/* 1282 */           String message = UtMessages.NEWER_DB.get(new Object[] { Common.formatVersion(version), Common.currentVersion() });
/*      */           
/* 1284 */           JOptionPane.showMessageDialog(ReMainFrame.getMasterFrame(), message);
/* 1285 */           Common.logMsg(message, null);
/*      */         }
/*      */         
/* 1288 */         db.loadHeldLayouts();
/*      */       }
/*      */       else
/*      */       {
/* 1292 */         db.upgrade69(dbIndex);
/* 1293 */         db.upgrade71(dbIndex);
/* 1294 */         db.upgrade94(dbIndex);
/*      */         
/* 1296 */         db.loadHeldLayouts();
/* 1297 */         Common.logMsgRaw(30, DATABASE_UPGRADED + VERSION_801, null);
/* 1298 */         ret = true;
/*      */       }
/*      */     } catch (Exception e) {
/* 1301 */       e.printStackTrace();
/*      */     } finally {
/* 1303 */       Common.setDoFree(free, dbIndex);
/*      */     }
/* 1305 */     return ret;
/*      */   }
/*      */   
/*      */   private static String getVersion(int dbIndex) throws SQLException {
/* 1309 */     String version = null;
/* 1310 */     ResultSet resultset = Common.getDBConnection(dbIndex).createStatement().executeQuery(SQL_GET_VERION);
/*      */     
/*      */ 
/*      */ 
/* 1314 */     if (resultset.next()) {
/* 1315 */       version = resultset.getString(1);
/* 1316 */       if (version != null) {
/* 1317 */         version = version.trim();
/*      */       }
/*      */     }
/* 1320 */     return version;
/*      */   }
/*      */   
/*      */   private static final class LayoutDef
/*      */   {
/*      */     int dbIdx;
/*      */     String xml;
/*      */     int systemId;
/*      */     boolean doDelete;
/*      */     
/*      */     public LayoutDef(int dbIdx, String xml, int systemId, boolean delete) {
/* 1331 */       this.dbIdx = dbIdx;
/* 1332 */       this.xml = xml;
/* 1333 */       this.systemId = systemId;
/* 1334 */       this.doDelete = delete;
/*      */     }
/*      */   }
/*      */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/util/UpgradeDB.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */