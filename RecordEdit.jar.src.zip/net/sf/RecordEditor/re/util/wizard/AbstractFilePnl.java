/*    */ package net.sf.RecordEditor.re.util.wizard;
/*    */ 
/*    */ import java.io.File;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.JPanel;
/*    */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*    */ import net.sf.JRecord.IO.AbstractLineIOProvider;
/*    */ import net.sf.JRecord.IO.LineIOProvider;
/*    */ import net.sf.RecordEditor.jibx.compare.BaseCopyDif;
/*    */ import net.sf.RecordEditor.re.openFile.AbstractLayoutSelection;
/*    */ import net.sf.RecordEditor.re.openFile.AbstractOpenFilePnl;
/*    */ import net.sf.RecordEditor.utils.msg.UtMessages;
/*    */ import net.sf.RecordEditor.utils.params.Parameters;
/*    */ import net.sf.RecordEditor.utils.screenManager.ReMsg;
/*    */ import net.sf.RecordEditor.utils.wizards.AbstractWizardPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractFilePnl<save extends BaseCopyDif>
/*    */   extends AbstractOpenFilePnl
/*    */   implements AbstractWizardPanel<save>
/*    */ {
/* 25 */   private JPanel goPanel = new JPanel();
/*    */   
/*    */   public AbstractFilePnl(AbstractLayoutSelection selection, String recentFiles) {
/* 28 */     super(1, "", LineIOProvider.getInstance(), null, null, Parameters.getApplicationDirectory() + recentFiles, "", selection);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public JComponent getComponent()
/*    */   {
/* 38 */     return this;
/*    */   }
/*    */   
/*    */   protected JPanel getGoPanel()
/*    */   {
/* 43 */     return this.goPanel;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void processFile(String sFileName, AbstractLayoutDetails layout, AbstractLineIOProvider lineIoProvider, boolean pBrowse)
/*    */     throws Exception
/*    */   {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected final void checkFile(String name, JComponent comp)
/*    */   {
/* 58 */     File f = new File(name);
/* 59 */     if (!f.exists()) {
/* 60 */       comp.requestFocus();
/* 61 */       throw new RuntimeException(UtMessages.FILE_DOES_NOT_EXIST.get(name)); }
/* 62 */     if (f.isDirectory()) {
/* 63 */       comp.requestFocus();
/* 64 */       throw new RuntimeException(UtMessages.DIRECTORY_NOT_ALLOWED.get(name));
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean skip()
/*    */   {
/* 73 */     return false;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/util/wizard/AbstractFilePnl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */