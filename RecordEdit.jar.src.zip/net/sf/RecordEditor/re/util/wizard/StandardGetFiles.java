/*     */ package net.sf.RecordEditor.re.util.wizard;
/*     */ 
/*     */ import net.sf.JRecord.Common.RecordRunTimeException;
/*     */ import net.sf.RecordEditor.jibx.compare.BaseCopyDif;
/*     */ import net.sf.RecordEditor.jibx.compare.Layout;
/*     */ import net.sf.RecordEditor.re.openFile.AbstractLayoutSelection;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.msg.UtMessages;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMsg;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.TreeComboFileSelect;
/*     */ 
/*     */ public class StandardGetFiles<Save extends BaseCopyDif>
/*     */   extends AbstractFilePnl<Save>
/*     */ {
/*     */   public static final int OLD = 0;
/*     */   public static final int NEW = 1;
/*  18 */   private static final String[] FILE_PROMPT = { "Old File Name", "New File Name" };
/*     */   
/*     */   private Save values;
/*     */   private AbstractLayoutSelection layoutSelection;
/*     */   int fileNo;
/*     */   private final boolean fileMustExist;
/*     */   
/*     */   public StandardGetFiles(AbstractLayoutSelection selection, int fileNumber, String recentFiles, String help, boolean fileMustExist)
/*     */   {
/*  27 */     super(selection, recentFiles);
/*     */     
/*  29 */     this.layoutSelection = selection;
/*  30 */     this.fileNo = fileNumber;
/*  31 */     this.fileMustExist = fileMustExist;
/*     */     
/*  33 */     setHelpURLre(Common.formatHelpURL(help));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Save getValues()
/*     */     throws Exception
/*     */   {
/*  43 */     net.sf.RecordEditor.jibx.compare.File fileDtl = this.values.oldFile;
/*  44 */     if (this.fileNo == 1) {
/*  45 */       fileDtl = this.values.newFile;
/*     */     }
/*     */     
/*  48 */     this.layoutSelection.forceLayoutReload();
/*  49 */     fileDtl.name = getCurrentFileName();
/*  50 */     fileDtl.getLayoutDetails().name = this.layoutSelection.getLayoutName();
/*  51 */     if (this.layoutSelection.getRecordLayout(fileDtl.name) == null) {
/*  52 */       throw new RecordRunTimeException("Layout Does not exist");
/*     */     }
/*  54 */     if (this.fileMustExist) {
/*  55 */       checkFile(fileDtl.name, this.fileName);
/*  56 */     } else if (new java.io.File(fileDtl.name).isDirectory()) {
/*  57 */       this.fileName.requestFocus();
/*  58 */       throw new RuntimeException(UtMessages.DIRECTORY_NOT_ALLOWED.get(fileDtl.name));
/*     */     }
/*     */     
/*  61 */     return this.values;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValues(Save detail)
/*     */     throws Exception
/*     */   {
/*  73 */     this.values = detail;
/*     */     
/*  75 */     net.sf.RecordEditor.jibx.compare.File fileDtl = this.values.oldFile;
/*  76 */     if (this.fileNo == 1) {
/*  77 */       fileDtl = this.values.newFile;
/*     */     }
/*     */     
/*  80 */     if (!"".equals(fileDtl.name)) {
/*  81 */       this.fileName.setText(fileDtl.name);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  88 */     String layoutName = fileDtl.getLayoutDetails().name;
/*  89 */     if (!"".equals(layoutName)) {
/*  90 */       this.layoutSelection.setLayoutName(layoutName);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addFileName(BaseHelpPanel pnl)
/*     */   {
/* 101 */     pnl.addLineRE(FILE_PROMPT[this.fileNo], this.fileName);
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/util/wizard/StandardGetFiles.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */