/*     */ package net.sf.RecordEditor.re.util.wizard;
/*     */ 
/*     */ import net.sf.RecordEditor.jibx.JibxCall;
/*     */ import net.sf.RecordEditor.jibx.compare.BaseCopyDif;
/*     */ import net.sf.RecordEditor.re.openFile.AbstractLayoutSelection;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.wizards.AbstractWizard;
/*     */ import net.sf.RecordEditor.utils.wizards.AbstractWizardPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TwoLayoutsWizard<Save extends BaseCopyDif>
/*     */   extends AbstractWizard<Save>
/*     */ {
/*  21 */   private JibxCall<Save> jibx = null;
/*     */   
/*  23 */   private AbstractLayoutSelection[] recordSelection = new AbstractLayoutSelection[2];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TwoLayoutsWizard(String id, Save definition)
/*     */   {
/*  33 */     super(id, definition);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setUpPanels(AbstractLayoutSelection selection1, AbstractLayoutSelection selection2, String recentFiles, AbstractWizardPanel<Save> finalScreen, String help, boolean secondFileRequired, boolean lookupRecentLayout)
/*     */   {
/*  43 */     AbstractWizardPanel<Save>[] pnls = new AbstractWizardPanel[4];
/*     */     
/*  45 */     int oldIdx = 0;
/*  46 */     int newIdx = 1;
/*     */     
/*  48 */     this.recordSelection[oldIdx] = selection1;
/*  49 */     this.recordSelection[newIdx] = selection2;
/*     */     
/*  51 */     StandardGetFiles firstPnl = new StandardGetFiles(this.recordSelection[oldIdx], oldIdx, recentFiles, help, true);
/*  52 */     StandardGetFiles secondPnl = new StandardGetFiles(this.recordSelection[newIdx], newIdx, recentFiles, help, secondFileRequired);
/*     */     
/*  54 */     firstPnl.setLookupRecentLayouts(lookupRecentLayout);
/*  55 */     secondPnl.setLookupRecentLayouts(lookupRecentLayout);
/*     */     
/*  57 */     pnls[0] = firstPnl;
/*  58 */     pnls[1] = secondPnl;
/*  59 */     pnls[2] = new FieldChoice(selection1, selection2, help);
/*  60 */     pnls[3] = finalScreen;
/*     */     
/*  62 */     super.setPanels(pnls);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void executeAction(int action)
/*     */   {
/*  84 */     if (action == 1) {
/*     */       try {
/*  86 */         Save diff = (BaseCopyDif)super.getActivePanel().getValues();
/*     */         
/*  88 */         if (!"".equals(diff.saveFile)) {
/*  89 */           saveJibx(diff);
/*  90 */           diff.fileSaved = true;
/*     */         }
/*     */       } catch (Exception e) {
/*  93 */         e.printStackTrace();
/*  94 */         Common.logMsgRaw(Common.FILE_SAVE_FAILED, e);
/*     */       }
/*     */     } else {
/*  97 */       super.executeAction(action);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isActionAvailable(int action)
/*     */   {
/* 106 */     if (action == 1) {
/* 107 */       return true;
/*     */     }
/* 109 */     return super.isActionAvailable(action);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void saveJibx(Save save)
/*     */     throws Exception
/*     */   {
/* 117 */     if (save == null) {
/* 118 */       return;
/*     */     }
/* 120 */     if (this.jibx == null) {
/* 121 */       this.jibx = new JibxCall(save.getClass());
/*     */     }
/*     */     
/* 124 */     this.jibx.unmarshal(save.saveFile, save);
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/util/wizard/TwoLayoutsWizard.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */