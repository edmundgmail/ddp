/*     */ package net.sf.RecordEditor.re.util.wizard;
/*     */ 
/*     */ import javax.swing.DefaultCellEditor;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import net.sf.JRecord.Common.RecordException;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.RecordEditor.jibx.compare.BaseCopyDif;
/*     */ import net.sf.RecordEditor.jibx.compare.File;
/*     */ import net.sf.RecordEditor.jibx.compare.Layout;
/*     */ import net.sf.RecordEditor.re.file.filter.BaseFieldSelection;
/*     */ import net.sf.RecordEditor.re.file.filter.FilterDetails;
/*     */ import net.sf.RecordEditor.re.openFile.AbstractLayoutSelection;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.swing.ComboBoxRender;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.wizards.AbstractWizardPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FieldChoice<save extends BaseCopyDif>
/*     */   extends BaseFieldSelection
/*     */   implements AbstractWizardPanel<save>
/*     */ {
/*     */   private save values;
/*  32 */   private String lastLayoutName1 = "";
/*  33 */   private String lastLayoutName2 = "";
/*     */   private AbstractLayoutSelection selection1;
/*     */   private AbstractLayoutSelection selection2;
/*  36 */   private boolean toInit = true;
/*     */   
/*  38 */   private AbstractLayoutDetails layout2 = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FieldChoice(AbstractLayoutSelection layoutSelection1, AbstractLayoutSelection layoutSelection2, String helpName)
/*     */   {
/*  48 */     this.selection1 = layoutSelection1;
/*  49 */     this.selection2 = layoutSelection2;
/*  50 */     if (((helpName != null ? 1 : 0) & (!"".equals(helpName) ? 1 : 0)) != 0) {
/*  51 */       setHelpURLre(Common.formatHelpURL(helpName));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setFieldTableDetails(JTable tbl)
/*     */   {
/*  60 */     ComboBoxRender fieldRendor = new ComboBoxRender(getFilter().getComboModelLayout2());
/*     */     
/*     */ 
/*     */ 
/*  64 */     setTableDetailsCol0(tbl);
/*     */     
/*  66 */     TableColumn tc = tbl.getColumnModel().getColumn(1);
/*  67 */     tc.setCellRenderer(fieldRendor);
/*  68 */     tc.setCellEditor(new DefaultCellEditor(new JComboBox(getFilter().getComboModelLayout2a())));
/*     */     
/*  70 */     tc.setPreferredWidth(FIELD_NAME_WIDTH);
/*     */     
/*  72 */     tbl.setRowHeight(FIELD_VALUE_ROW_HEIGHT);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setRecordTableDetails(JTable tbl)
/*     */   {
/*  83 */     setTableDetailsCol0(tbl);
/*     */     
/*     */ 
/*  86 */     TableColumn tc = tbl.getColumnModel().getColumn(1);
/*     */     
/*  88 */     tc.setCellRenderer(new ComboBoxRender(getFilter().getRecordOptions()));
/*     */     
/*  90 */     tc.setCellEditor(new DefaultCellEditor(new JComboBox(getFilter().getRecordOptions())));
/*     */     
/*  92 */     tc.setPreferredWidth(FIELD_NAME_WIDTH);
/*     */     
/*  94 */     tbl.setRowHeight(FIELD_VALUE_ROW_HEIGHT);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public save getValues()
/*     */     throws Exception
/*     */   {
/* 103 */     String sold = this.values.oldFile.layoutDetails.name;
/*     */     
/* 105 */     this.values.oldFile.layoutDetails = super.getFilter().getExternalLayout();
/* 106 */     this.values.oldFile.layoutDetails.name = sold;
/*     */     
/* 108 */     String snew = this.values.newFile.layoutDetails.name;
/*     */     
/* 110 */     this.values.newFile.layoutDetails = super.getFilter().getExternalLayout2();
/* 111 */     this.values.newFile.layoutDetails.name = snew;
/*     */     
/* 113 */     return this.values;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValues(save detail)
/*     */     throws Exception
/*     */   {
/* 122 */     this.values = detail;
/*     */     
/* 124 */     String newLayoutName = this.values.newFile.getLayoutDetails().name;
/* 125 */     if ((newLayoutName.startsWith("CsvSchema~")) || (!this.lastLayoutName2.equalsIgnoreCase(newLayoutName)))
/*     */     {
/* 127 */       this.lastLayoutName2 = this.values.newFile.layoutDetails.name;
/* 128 */       this.layout2 = this.selection2.getRecordLayout(this.values.newFile.name);
/* 129 */       this.toInit = true;
/* 130 */       if (this.layout2 == null) {
/* 131 */         throw new RecordException("Can not get layout for the New File");
/*     */       }
/*     */     }
/*     */     
/* 135 */     String oldLayoutName = this.values.oldFile.getLayoutDetails().name;
/* 136 */     if ((oldLayoutName.startsWith("CsvSchema~")) || (!this.lastLayoutName1.equalsIgnoreCase(oldLayoutName)))
/*     */     {
/* 138 */       super.setRecordLayout(this.selection1.getRecordLayout(this.values.oldFile.name), this.layout2, true, SwingUtils.NORMAL_FIELD_HEIGHT * 4);
/*     */       
/*     */ 
/* 141 */       this.lastLayoutName1 = this.values.oldFile.layoutDetails.name;
/* 142 */       this.toInit = true;
/*     */     }
/*     */     
/* 145 */     if (this.toInit)
/*     */     {
/* 147 */       super.getFilter().set2ndLayout(this.layout2, this.values.oldFile.layoutDetails, this.values.newFile.layoutDetails);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 152 */       setRecordTableDetails(super.getRecordTbl());
/* 153 */       setFieldTableDetails(super.getFieldTbl());
/* 154 */       this.toInit = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JComponent getComponent()
/*     */   {
/* 164 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean skip()
/*     */   {
/* 173 */     return false;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/util/wizard/FieldChoice.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */