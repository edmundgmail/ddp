/*     */ package net.sf.RecordEditor.re.util;
/*     */ 
/*     */ import net.sf.JRecord.External.ExternalRecord;
/*     */ import net.sf.JRecord.External.XmlCopybookLoader;
/*     */ import net.sf.RecordEditor.re.db.Record.ExtendedRecordDB;
/*     */ import net.sf.RecordEditor.re.db.Record.RecordRec;
/*     */ import net.sf.RecordEditor.utils.common.ReConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XmlCopybookLoaderDB
/*     */   extends XmlCopybookLoader
/*     */ {
/*  43 */   private int lastDBidx = -1;
/*     */   
/*  45 */   private ExtendedRecordDB recordDB = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void allocDBs(int dbIdx)
/*     */   {
/*  56 */     if ((this.lastDBidx != dbIdx) || (this.recordDB == null)) {
/*  57 */       this.recordDB = new ExtendedRecordDB();
/*  58 */       this.recordDB.setDoFree(false);
/*     */       
/*  60 */       this.recordDB.setConnection(new ReConnection(dbIdx));
/*  61 */     } else if (this.lastDBidx != dbIdx) {
/*  62 */       this.recordDB.fullClose();
/*  63 */       this.recordDB.setDoFree(true);
/*  64 */       this.recordDB.setDoFree(false);
/*     */       
/*  66 */       this.recordDB.setConnection(new ReConnection(dbIdx));
/*     */     }
/*     */     
/*  69 */     this.lastDBidx = dbIdx;
/*     */   }
/*     */   
/*     */   protected void freeDBs(int pDbIdx)
/*     */   {
/*  74 */     if (this.recordDB != null) {
/*  75 */       this.recordDB.close();
/*  76 */       this.recordDB.setDoFree(true);
/*  77 */       this.recordDB.setDoFree(false);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void updateRecord(String copyBook, ExternalRecord rec, boolean updateRequired)
/*     */   {
/*  98 */     this.recordDB.resetSearch();
/*  99 */     this.recordDB.setSearchArg("COPYBOOK", "=", "'" + copyBook + "'");
/*     */     
/* 101 */     this.recordDB.open();
/*     */     RecordRec oldRec;
/* 103 */     if ((oldRec = this.recordDB.fetch()) != null) {
/* 104 */       ExternalRecord oldValues = oldRec.getValue();
/* 105 */       rec.setRecordId(oldValues.getRecordId());
/* 106 */       rec.setNew(false);
/*     */       
/*     */ 
/*     */ 
/* 110 */       if (updateRequired) {
/* 111 */         rec.setUpdateStatus(3);
/*     */       } else {
/* 113 */         String oldFont = oldValues.getFontName();
/*     */         
/* 115 */         if (oldFont == null) {
/* 116 */           oldFont = "";
/*     */         }
/*     */         
/* 119 */         if (!getFontName().toUpperCase().equals(oldFont.toUpperCase())) {
/* 120 */           oldValues.setFontName(getFontName());
/* 121 */           rec = oldValues;
/* 122 */           rec.setUpdateStatus(3);
/*     */         }
/*     */       }
/*     */     } else {
/* 126 */       super.updateRecord(copyBook, rec, updateRequired);
/*     */     }
/* 128 */     this.recordDB.freeConnection();
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/util/XmlCopybookLoaderDB.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */