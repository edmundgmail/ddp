/*     */ package net.sf.RecordEditor.re.util;
/*     */ 
/*     */ import net.sf.JRecord.Details.LineProvider;
/*     */ import net.sf.JRecord.IO.AbstractLineReader;
/*     */ import net.sf.JRecord.IO.LineIOProvider;
/*     */ import net.sf.JRecord.IO.StandardLineIOProvider;
/*     */ import net.sf.RecordEditor.layoutWizard.UnknownFormatReader;
/*     */ import net.sf.RecordEditor.re.util.csv.GenericCsvReader;
/*     */ 
/*     */ public class ReIOProvider
/*     */   extends StandardLineIOProvider
/*     */ {
/*  13 */   private static ReIOProvider instance = null;
/*     */   
/*     */   private static final int numberOfEntries = 3;
/*  16 */   private static String[] names = new String[3];
/*  17 */   private static String[] externalNames = new String[3];
/*  18 */   private static int[] keys = new int[3];
/*     */   
/*     */   static
/*     */   {
/*  22 */     int i = 0;
/*     */     
/*  24 */     keys[i] = 21;externalNames[i] = "UNKNOWN_FORMAT";names[(i++)] = "Unknown Format (Choose details at run time)";
/*  25 */     keys[i] = 22;externalNames[i] = "FILE_WIZARD";names[(i++)] = "File Wizard, Generate layout at run time";
/*  26 */     keys[i] = 52;externalNames[i] = "CSV_GENERIC";names[(i++)] = "Generic CSV (Choose details at run time)";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractLineReader getLineReader(int fileStructure, LineProvider lineProvider)
/*     */   {
/*  34 */     LineProvider lLineProvider = lineProvider;
/*     */     
/*  36 */     if (lLineProvider == null) {
/*  37 */       lLineProvider = super.getLineProvider(fileStructure, "");
/*     */     }
/*     */     
/*     */ 
/*  41 */     switch (fileStructure) {
/*     */     case 52: 
/*  43 */       return new GenericCsvReader(lLineProvider);
/*     */     case 21: 
/*  45 */       return new UnknownFormatReader();
/*     */     case 22: 
/*  47 */       return new WizardReader(lLineProvider);
/*     */     }
/*  49 */     return super.getLineReader(fileStructure, lineProvider);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCopyBookFileRequired(int fileStructure)
/*     */   {
/*  68 */     return (fileStructure != 21) && (fileStructure != 22) && (fileStructure != 52);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getStructureName(int fileStructure)
/*     */   {
/*  78 */     for (int i = 0; (i < keys.length) && (keys[i] != -121); i++) {
/*  79 */       if (keys[i] == fileStructure) {
/*  80 */         return externalNames[i];
/*     */       }
/*     */     }
/*  83 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getKey(int idx)
/*     */   {
/*  92 */     return keys[idx];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName(int idx)
/*     */   {
/* 101 */     return names[idx];
/*     */   }
/*     */   
/*     */ 
/*     */   public int getStructure(String name)
/*     */   {
/* 107 */     for (int i = 0; (i < keys.length) && (keys[i] != -121); i++) {
/* 108 */       if (externalNames[i].equalsIgnoreCase(name))
/*     */       {
/* 110 */         return keys[i];
/*     */       }
/*     */     }
/* 113 */     return -121;
/*     */   }
/*     */   
/*     */   public String getStructureNameForIndex(int index)
/*     */   {
/* 118 */     return externalNames[index];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNumberOfEntries()
/*     */   {
/* 126 */     return 3;
/*     */   }
/*     */   
/*     */   public static void register()
/*     */   {
/* 131 */     if (instance == null) {
/* 132 */       instance = new ReIOProvider();
/*     */       
/* 134 */       LineIOProvider.getInstance().register(instance);
/*     */     }
/*     */   }
/*     */   
/*     */   public static LineIOProvider getInstance() {
/* 139 */     register();
/* 140 */     return LineIOProvider.getInstance();
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/util/ReIOProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */