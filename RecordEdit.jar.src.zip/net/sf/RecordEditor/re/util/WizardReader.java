/*     */ package net.sf.RecordEditor.re.util;
/*     */ 
/*     */ import java.awt.Container;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import javax.swing.JDialog;
/*     */ import net.sf.JRecord.Common.RecordException;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.LineProvider;
/*     */ import net.sf.JRecord.External.ExternalRecord;
/*     */ import net.sf.JRecord.IO.AbstractLineReader;
/*     */ import net.sf.JRecord.IO.DelegateReader;
/*     */ import net.sf.JRecord.IO.LineIOProvider;
/*     */ import net.sf.RecordEditor.layoutWizard.Details;
/*     */ import net.sf.RecordEditor.layoutWizard.FileAnalyser;
/*     */ import net.sf.RecordEditor.layoutWizard.Wizard;
/*     */ import net.sf.RecordEditor.re.openFile.RecentFiles;
/*     */ import net.sf.RecordEditor.utils.LayoutConnection;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.common.StreamUtil;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMainFrame;
/*     */ import net.sf.RecordEditor.utils.swing.EditingCancelled;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WizardReader
/*     */   extends DelegateReader
/*     */ {
/*     */   public WizardReader(LineProvider provider)
/*     */   {
/*  44 */     super(provider);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void open(InputStream inputStream, String filename, AbstractLayoutDetails pLayout)
/*     */     throws IOException, RecordException
/*     */   {
/*  56 */     open(filename, pLayout);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void open(String fileName, AbstractLayoutDetails pLayout)
/*     */     throws IOException, RecordException
/*     */   {
/*  70 */     JDialog d = new JDialog(ReMainFrame.getMasterFrame(), true);
/*  71 */     ReFrame frame = ReFrame.getActiveFrame();
/*  72 */     LayoutConnection con = null;
/*  73 */     if ((frame != null) && (frame.getContentPane() != null) && ((frame.getContentPane().getComponent(0) instanceof LayoutConnection)))
/*     */     {
/*     */ 
/*  76 */       con = (LayoutConnection)frame.getContentPane().getComponent(0);
/*     */     }
/*  78 */     Wizard wiz = new Wizard(d, Common.getConnectionIndex(), fileName, con, false);
/*     */     
/*     */ 
/*     */ 
/*  82 */     Details details = (Details)wiz.getWizardDetails();
/*     */     
/*     */ 
/*     */ 
/*  86 */     byte[] data = StreamUtil.read(new FileInputStream(fileName), 8000);
/*     */     
/*  88 */     System.out.println("Bytes Read: " + data.length);
/*  89 */     FileAnalyser analyser = FileAnalyser.getAnaylser(data, "");
/*     */     
/*     */ 
/*  92 */     details.fileStructure = analyser.getFileStructure();
/*  93 */     details.fontName = analyser.getFontName();
/*  94 */     details.recordLength = analyser.getRecordLength();
/*  95 */     details.generateFieldNames = true;
/*  96 */     details.editFile = false;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 101 */     d.setVisible(true);
/*     */     
/* 103 */     ExternalRecord r = details.createRecordLayout();
/*     */     
/* 105 */     if ((r == null) || ((r.getNumberOfRecordFields() == 0) && (r.getNumberOfRecords() == 0))) {
/* 106 */       throw new EditingCancelled();
/*     */     }
/* 108 */     AbstractLayoutDetails l = r.asLayoutDetail();
/* 109 */     AbstractLineReader reader = LineIOProvider.getInstance().getLineReader(l);
/* 110 */     reader.open(fileName, l);
/* 111 */     setReader(reader);
/*     */     try
/*     */     {
/* 114 */       if (RecentFiles.getLast() != null) {
/* 115 */         RecentFiles.getLast().putFileLayout(fileName, l.getLayoutName());
/*     */       }
/*     */     }
/*     */     catch (Exception e) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void open(InputStream inputStream, AbstractLayoutDetails layout)
/*     */     throws IOException, RecordException
/*     */   {
/* 133 */     throw new IOException("Method not supported");
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/util/WizardReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */