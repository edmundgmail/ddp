/*    */ package net.sf.RecordEditor.re.util;
/*    */ 
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import java.io.File;
/*    */ import java.io.FilenameFilter;
/*    */ import net.sf.JRecord.External.CopybookLoader;
/*    */ import net.sf.JRecord.External.CopybookLoaderFactory;
/*    */ import net.sf.RecordEditor.re.db.Record.ExtendedRecordDB;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ import net.sf.RecordEditor.utils.common.ReConnection;
/*    */ import net.sf.RecordEditor.utils.params.Parameters;
/*    */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*    */ import net.sf.RecordEditor.utils.params.ProgramOptions.FileNameOpt;
/*    */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*    */ import net.sf.RecordEditor.utils.swing.DirectoryFrame;
/*    */ 
/*    */ public class LoadXmlLayoutsIntoDB implements ActionListener
/*    */ {
/* 20 */   private DirectoryFrame loadFrame = new DirectoryFrame("Load Directory", stripStar(Common.OPTIONS.DEFAULT_COPYBOOK_DIRECTORY.get()), true, true, false);
/*    */   
/*    */ 
/*    */   private int dbIdx;
/*    */   
/*    */ 
/*    */   public LoadXmlLayoutsIntoDB(int databaseIdx)
/*    */   {
/* 28 */     this.dbIdx = databaseIdx;
/*    */     
/* 30 */     this.loadFrame.setActionListner(this);
/* 31 */     this.loadFrame.setVisible(true);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void actionPerformed(ActionEvent event)
/*    */   {
/* 40 */     String dir = this.loadFrame.getFileName();
/*    */     
/* 42 */     if ((dir == null) || ("".equals(dir))) {
/* 43 */       this.loadFrame.panel.setMessageTxtRE("You must enter a directory to load layouts from");
/* 44 */       return;
/*    */     }
/*    */     
/* 47 */     File dirFile = new File(stripStar(dir));
/*    */     
/* 49 */     if ((!dirFile.exists()) || (!dirFile.isDirectory())) {
/* 50 */       this.loadFrame.panel.setMessageRplTxtRE("{0} is not a directory !!!", dir);
/* 51 */       return;
/*    */     }
/*    */     
/* 54 */     ExtendedRecordDB dbTo = new ExtendedRecordDB();
/* 55 */     dbTo.setConnection(new ReConnection(this.dbIdx));
/* 56 */     boolean free = dbTo.isSetDoFree(false);
/*    */     
/*    */     try
/*    */     {
/* 60 */       CopybookLoader loader = CopybookLoaderFactoryDB.getInstance().getLoader(CopybookLoaderFactoryDB.RECORD_EDITOR_XML_LOADER);
/*    */       
/*    */ 
/* 63 */       FilenameFilter filter = new FilenameFilter()
/*    */       {
/*    */         public boolean accept(File dir, String name)
/*    */         {
/* 67 */           return name.toLowerCase().endsWith(".xml");
/*    */         }
/*    */       };
/*    */       
/*    */ 
/* 72 */       for (File xmlFile : dirFile.listFiles(filter)) {
/*    */         try {
/* 74 */           net.sf.JRecord.External.ExternalRecord rec = loader.loadCopyBook(xmlFile.getPath(), 0, this.dbIdx, "", 0, 0, Common.getLogger());
/*    */           
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 81 */           dbTo.checkAndUpdate(rec);
/*    */           
/* 83 */           Common.logMsg(30, "Loading", xmlFile.getPath(), null);
/*    */         } catch (Exception e) {
/* 85 */           Common.logMsgRaw(e.getMessage(), e);
/*    */         }
/*    */       }
/*    */     }
/*    */     catch (Exception e) {
/* 90 */       Common.logMsgRaw(e.getMessage(), e);
/*    */     } finally {
/* 92 */       dbTo.setDoFree(free);
/*    */     }
/*    */   }
/*    */   
/*    */   private static String stripStar(String dir) {
/* 97 */     return Parameters.dropStar(dir);
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/util/LoadXmlLayoutsIntoDB.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */