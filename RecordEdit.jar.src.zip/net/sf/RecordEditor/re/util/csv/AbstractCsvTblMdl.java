package net.sf.RecordEditor.re.util.csv;

import javax.swing.table.TableModel;

public abstract interface AbstractCsvTblMdl
  extends TableModel
{
  public static final int DERIVE_SEPERATOR = 1;
  public static final int USE_CURRENT_SEPERATOR = 2;
  
  public abstract void setupColumnCount();
  
  public abstract int getLines2display();
  
  public abstract void setLines2display(int paramInt);
  
  public abstract String getLine(int paramInt);
  
  public abstract String[] getLinesString();
  
  public abstract byte[][] getLines();
  
  public abstract int getParserType();
  
  public abstract void setParserType(int paramInt);
  
  public abstract void setQuote(String paramString);
  
  public abstract void setSeperator(String paramString);
  
  public abstract void setHideFirstLine(boolean paramBoolean);
  
  public abstract void setFieldLineNo(int paramInt);
  
  public abstract void fireTableDataChanged();
  
  public abstract void fireTableStructureChanged();
  
  public abstract void setLines(byte[][] paramArrayOfByte, String paramString);
  
  public abstract void setLines(String[] paramArrayOfString);
  
  public abstract void setFont(String paramString);
  
  public abstract CsvAnalyser getAnalyser(int paramInt);
  
  public abstract void setDataFont(byte[] paramArrayOfByte, String paramString, boolean paramBoolean);
  
  public abstract void setEmbedded(boolean paramBoolean);
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/util/csv/AbstractCsvTblMdl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */