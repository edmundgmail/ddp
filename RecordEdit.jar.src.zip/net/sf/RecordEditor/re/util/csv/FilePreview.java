package net.sf.RecordEditor.re.util.csv;

import javax.swing.JButton;
import net.sf.JRecord.Details.LayoutDetail;
import net.sf.RecordEditor.utils.swing.BaseHelpPanel;

public abstract interface FilePreview
{
  public static final int NO = 1;
  public static final int MAYBE = 2;
  public static final int YES = 3;
  public static final String SEP = "~";
  public static final String NULL_STR = "Empty";
  
  public abstract BaseHelpPanel getPanel();
  
  public abstract JButton getGoButton();
  
  public abstract boolean setData(String paramString1, byte[] paramArrayOfByte, boolean paramBoolean, String paramString2);
  
  public abstract String getSeperator();
  
  public abstract String getQuote();
  
  public abstract boolean setLines(byte[][] paramArrayOfByte, String paramString, int paramInt);
  
  public abstract void setLines(String[] paramArrayOfString, String paramString, int paramInt);
  
  public abstract int getColumnCount();
  
  public abstract String getColumnName(int paramInt);
  
  public abstract LayoutDetail getLayout(String paramString, byte[] paramArrayOfByte);
  
  public abstract String getFileDescription();
  
  public abstract void setFileDescription(String paramString);
  
  public abstract String getFontName();
  
  public abstract boolean isMyLayout(String paramString1, String paramString2, byte[] paramArrayOfByte);
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/util/csv/FilePreview.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */