/*     */ package net.sf.RecordEditor.re.util.csv;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.Rectangle;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import javax.swing.text.JTextComponent;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.LayoutDetail;
/*     */ import net.sf.JRecord.IO.AbstractLineReader;
/*     */ import net.sf.JRecord.IO.LineIOProvider;
/*     */ import net.sf.RecordEditor.po.def.PoField;
/*     */ import net.sf.RecordEditor.po.def.PoLayoutMgr;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.tip.def.TipField;
/*     */ import net.sf.RecordEditor.tip.def.TipLayoutMgr;
/*     */ import net.sf.RecordEditor.utils.StringMatch;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ public class OtherSelection
/*     */   implements FilePreview
/*     */ {
/*     */   private static final String OTHER_ID = "OTHER";
/*     */   private static final String PO_ID = "PO";
/*     */   private static final String TIP_ID = "TIPS";
/*  41 */   private static final String[] SUB_TYPES = { "PO", "TIPS", "" };
/*     */   
/*     */   private static final int TYPE_PO = 0;
/*     */   private static final int TYPE_TIP = 1;
/*     */   private static final int TYPE_OTHER = 2;
/*  46 */   private StringMatch[][] fields = { PoField.getAllfields(), TipField.getAllfields() };
/*     */   
/*     */ 
/*  49 */   private int type = 2;
/*  50 */   private BaseHelpPanel pnl = new BaseHelpPanel();
/*     */   
/*  52 */   private JLabel typeLabel = new JLabel();
/*  53 */   private JButton editBtn = SwingUtils.newButton("Edit");
/*     */   
/*  55 */   private JTable fileTable = new JTable();
/*     */   
/*     */ 
/*     */ 
/*  59 */   private String fontName = "";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte[] lastData;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public OtherSelection(JTextComponent message)
/*     */   {
/*  71 */     this.pnl.setAddFillToEnd(true);
/*     */     
/*  73 */     this.fileTable.setAutoResizeMode(0);
/*     */     
/*     */ 
/*     */ 
/*  77 */     this.pnl.addLineRE("", this.typeLabel, this.editBtn).setGapRE(BasePanel.GAP1);
/*     */     
/*     */ 
/*     */ 
/*  81 */     this.pnl.addComponentRE(1, 6, -1.0D, BasePanel.GAP, 2, 2, this.fileTable);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BaseHelpPanel getPanel()
/*     */   {
/*  91 */     return this.pnl;
/*     */   }
/*     */   
/*     */   public JButton getGoButton()
/*     */   {
/*  96 */     return this.editBtn;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean setData(String filename, byte[] data, boolean checkCharset, String layoutId)
/*     */   {
/* 102 */     if (this.lastData == data) {
/* 103 */       return this.type != 2;
/*     */     }
/* 105 */     this.lastData = data;
/*     */     
/* 107 */     analyseData(null, data);
/*     */     
/* 109 */     return buildFileLayout(filename, data);
/*     */   }
/*     */   
/*     */   private boolean buildFileLayout(String filename, byte[] data) {
/*     */     try {
/* 114 */       LayoutDetail layout = getLocalLayout(null, data);
/*     */       
/* 116 */       if (layout == null) {
/* 117 */         System.out.println("No Layout Generated !!!");
/* 118 */         this.fileTable.setVisible(false);
/* 119 */         this.editBtn.setEnabled(false);
/* 120 */         return false;
/*     */       }
/* 122 */       int fileStructure = layout.getFileStructure();
/* 123 */       this.fontName = layout.getFontName();
/*     */       
/*     */ 
/* 126 */       ByteArrayInputStream is = new ByteArrayInputStream(data);
/* 127 */       LineIOProvider iop = LineIOProvider.getInstance();
/*     */       
/* 129 */       AbstractLineReader<LayoutDetail> r = iop.getLineReader(fileStructure);
/* 130 */       FileView view = new FileView(layout, iop, false);
/*     */       
/* 132 */       int i = 0;
/*     */       
/* 134 */       r.open(is, layout);
/*     */       try { AbstractLine l;
/* 136 */         while ((i++ < 60) && ((l = r.read()) != null)) {
/* 137 */           view.add(l);
/*     */         }
/*     */       }
/*     */       catch (Exception e) {}finally
/*     */       {
/* 142 */         is.close();
/* 143 */         r.close();
/*     */       }
/*     */       
/* 146 */       this.fileTable.setModel(view);
/* 147 */       int height = SwingUtils.TABLE_ROW_HEIGHT;
/* 148 */       if (this.type == 1) {
/* 149 */         height = 3 * SwingUtils.TABLE_ROW_HEIGHT;
/*     */       }
/* 151 */       this.fileTable.setRowHeight(height);
/* 152 */       view.fireTableStructureChanged();
/*     */       
/* 154 */       TableColumnModel tcm = this.fileTable.getColumnModel();
/* 155 */       TableColumn tc = tcm.getColumn(0);
/* 156 */       HeaderRender headerRender = new HeaderRender(null);
/*     */       
/* 158 */       for (i = 2; i < tcm.getColumnCount(); i++) {
/* 159 */         tcm.getColumn(i).setHeaderRenderer(headerRender);
/*     */       }
/* 161 */       if (tc != null) {
/* 162 */         this.fileTable.getColumnModel().removeColumn(tc);
/*     */       }
/*     */       
/* 165 */       Rectangle visbleRect = this.fileTable.getVisibleRect();
/* 166 */       if ((visbleRect != null) && (visbleRect.width > 0)) {
/* 167 */         Common.calcColumnWidths(this.fileTable, 0);
/* 168 */       } else if (this.type == 1) {
/* 169 */         this.fileTable.getColumnModel().getColumn(2).setPreferredWidth(SwingUtils.CHAR_FIELD_WIDTH * 55);
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 173 */       e.printStackTrace();
/* 174 */       return false;
/*     */     }
/*     */     
/* 177 */     this.lastData = data;
/* 178 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getSeperator()
/*     */   {
/* 184 */     return "";
/*     */   }
/*     */   
/*     */   public String getQuote()
/*     */   {
/* 189 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean setLines(byte[][] newLines, String font, int numberOfLines)
/*     */   {
/* 195 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setLines(String[] newLines, String font, int numberOfLines) {}
/*     */   
/*     */ 
/*     */   public int getColumnCount()
/*     */   {
/* 205 */     return this.fileTable.getColumnCount();
/*     */   }
/*     */   
/*     */   public String getColumnName(int idx)
/*     */   {
/* 210 */     return null;
/*     */   }
/*     */   
/*     */   public LayoutDetail getLayout(String font, byte[] recordSep)
/*     */   {
/* 215 */     return getLocalLayout(font, this.lastData);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getFileDescription()
/*     */   {
/* 222 */     return "OTHER~" + SUB_TYPES[this.type] + "~" + "Empty";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFileDescription(String val) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isMyLayout(String layoutId, String filename, byte[] data)
/*     */   {
/* 248 */     setData(filename, data, false, layoutId);
/*     */     
/* 250 */     return this.type != 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private LayoutDetail getLocalLayout(String charset, byte[] data)
/*     */   {
/* 265 */     analyseData(charset, data);
/*     */     
/* 267 */     return getLayout();
/*     */   }
/*     */   
/*     */   private LayoutDetail getLayout() {
/* 271 */     LayoutDetail ret = null;
/*     */     
/* 273 */     if (this.type == 0) {
/* 274 */       ret = PoLayoutMgr.getPoLayout();
/* 275 */     } else if (this.type == 1) {
/* 276 */       ret = TipLayoutMgr.getTipLayout();
/*     */     }
/* 278 */     return ret;
/*     */   }
/*     */   
/*     */   private void analyseData(String charset, byte[] data) {
/* 282 */     this.type = 2;
/*     */     try
/*     */     {
/* 285 */       ByteArrayInputStream is = new ByteArrayInputStream(data);
/*     */       InputStreamReader ir;
/* 287 */       InputStreamReader ir; if ((charset == null) || ("".equals(charset))) {
/* 288 */         ir = new InputStreamReader(is);
/*     */       } else {
/* 290 */         ir = new InputStreamReader(is, charset);
/*     */       }
/* 292 */       BufferedReader r = new BufferedReader(ir);
/*     */       
/* 294 */       int c = 0;
/* 295 */       int[] counts = { 0, 0 };
/*     */       try {
/*     */         String s;
/* 298 */         while ((s = r.readLine()) != null) {
/* 299 */           if (!"".equals(s)) {
/* 300 */             c++;
/* 301 */             s = s.trim();
/* 302 */             for (int i = 0; i < this.fields.length; i++) {
/* 303 */               for (StringMatch m : this.fields[i]) {
/* 304 */                 if (m.isMatch(s)) {
/* 305 */                   counts[i] += 1;
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */         
/* 312 */         int idx = 0;
/* 313 */         if (counts[1] > counts[0]) {
/* 314 */           idx = 1;
/*     */         }
/*     */         
/* 317 */         if (counts[idx] * 10 > c) {
/* 318 */           this.type = idx;
/*     */         }
/*     */       }
/*     */       finally {
/* 322 */         r.close();
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 326 */       e.printStackTrace();
/*     */     }
/*     */     
/* 329 */     this.typeLabel.setText(SUB_TYPES[this.type]);
/*     */     
/* 331 */     this.typeLabel.revalidate();
/* 332 */     this.fileTable.setVisible(this.type != 2);
/* 333 */     this.editBtn.setEnabled(this.type != 2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFontName()
/*     */   {
/* 366 */     return this.fontName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLayoutFile(String lFile) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class HeaderRender
/*     */     extends JPanel
/*     */     implements TableCellRenderer
/*     */   {
/*     */     public Component getTableCellRendererComponent(JTable tbl, Object value, boolean isFldSelected, boolean hasFocus, int row, int column)
/*     */     {
/* 395 */       removeAll();
/* 396 */       setLayout(new GridLayout(2, 1));
/*     */       
/* 398 */       if ((column >= 0) && (value != null))
/*     */       {
/* 400 */         String s = (String)value;
/* 401 */         String first = s;
/* 402 */         String second = "";
/* 403 */         int pos = s.indexOf("|");
/* 404 */         if (pos > 0) {
/* 405 */           first = s.substring(pos + 1);
/* 406 */           second = s.substring(0, pos);
/*     */         }
/* 408 */         JLabel label = new JLabel(first);
/* 409 */         add(label);
/* 410 */         if (!second.equals("")) {
/* 411 */           label = new JLabel(second);
/*     */           
/* 413 */           add(label);
/*     */         }
/*     */       }
/* 416 */       setBorder(BorderFactory.createEtchedBorder());
/*     */       
/* 418 */       return this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/util/csv/OtherSelection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */