/*     */ package net.sf.RecordEditor.re.util.csv;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import javax.swing.text.JTextComponent;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.LayoutDetail;
/*     */ import net.sf.JRecord.External.CobolCopybookLoader;
/*     */ import net.sf.JRecord.External.CopybookLoader;
/*     */ import net.sf.JRecord.External.ExternalRecord;
/*     */ import net.sf.JRecord.External.RecordEditorXmlLoader;
/*     */ import net.sf.JRecord.IO.AbstractLineReader;
/*     */ import net.sf.JRecord.IO.LineIOProvider;
/*     */ import net.sf.RecordEditor.layoutWizard.Details;
/*     */ import net.sf.RecordEditor.layoutWizard.FileAnalyser;
/*     */ import net.sf.RecordEditor.layoutWizard.WizardFileLayout;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.re.openFile.ComputerOptionCombo;
/*     */ import net.sf.RecordEditor.utils.BasicLayoutCallback;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMainFrame;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.FileSelectCombo;
/*     */ 
/*     */ 
/*     */ public class SchemaSelection
/*     */   implements FilePreview, BasicLayoutCallback
/*     */ {
/*     */   private static final String FIXED_ID = "FIXED";
/*  53 */   private BaseHelpPanel pnl = new BaseHelpPanel();
/*     */   
/*  55 */   private FileSelectCombo layoutFile = new FileSelectCombo("SchemaFiles.", 25, true, false);
/*  56 */   private final JLabel dialectLbl = new JLabel("Cobol Dialect");
/*  57 */   private final ComputerOptionCombo dialectCombo = new ComputerOptionCombo();
/*     */   
/*  59 */   private JButton editBtn = SwingUtils.newButton("Edit");
/*     */   
/*  61 */   private JTable fileTable = new JTable();
/*     */   
/*     */   private JTextComponent msg;
/*     */   
/*  65 */   private String fontName = "";
/*  66 */   private String filename = "";
/*     */   private int fileStructure;
/*  68 */   private int recordLength = 100;
/*     */   
/*     */   private byte[] lastData;
/*  71 */   private String lastLayoutFile = null;
/*     */   
/*     */ 
/*     */   public SchemaSelection(JTextComponent message)
/*     */   {
/*  76 */     this.msg = message;
/*     */     
/*  78 */     JLabel layoutLbl = new JLabel("Layout File");
/*     */     
/*  80 */     this.fileTable.setAutoResizeMode(0);
/*     */     
/*  82 */     this.layoutFile.setText(Parameters.getFileName("CopybookDirectory"));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  93 */     this.pnl.addLineRE(layoutLbl, this.layoutFile).addLineRE(this.dialectLbl, this.dialectCombo).setGapRE(BasePanel.GAP1).addComponentRE(1, -99, -2.0D, BasePanel.GAP, 3, 2, this.editBtn);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 101 */     this.pnl.addComponentRE(1, -99, -1.0D, BasePanel.GAP, 2, 2, this.fileTable);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 106 */     this.layoutFile.addTextChangeListner(new ChangeListener() {
/*     */       public void stateChanged(ChangeEvent e) {
/* 108 */         if ((SchemaSelection.this.lastLayoutFile == null) || (!SchemaSelection.this.lastLayoutFile.equals(SchemaSelection.this.layoutFile.getText()))) {
/* 109 */           SchemaSelection.this.buildFileLayout(SchemaSelection.this.lastData);
/*     */         }
/* 111 */         SchemaSelection.this.setCobolVisible();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 122 */     });
/* 123 */     this.dialectCombo.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent e) {
/* 125 */         SchemaSelection.this.buildFileLayout(SchemaSelection.this.lastData);
/*     */         
/* 127 */         SchemaSelection.this.setCobolVisible();
/*     */       }
/*     */       
/* 130 */     });
/* 131 */     setCobolVisible();
/*     */   }
/*     */   
/*     */ 
/*     */   public BaseHelpPanel getPanel()
/*     */   {
/* 137 */     return this.pnl;
/*     */   }
/*     */   
/*     */   public JButton getGoButton()
/*     */   {
/* 142 */     return this.editBtn;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean setData(String filename, byte[] data, boolean checkCharset, String layoutId)
/*     */   {
/* 148 */     if (this.lastData == data) {
/* 149 */       return true;
/*     */     }
/*     */     
/* 152 */     if ((layoutId != null) && (!"".equals(layoutId))) {
/* 153 */       setFileDescription(layoutId);
/*     */     }
/*     */     
/*     */ 
/* 157 */     return buildFileLayout(data);
/*     */   }
/*     */   
/*     */   private boolean buildFileLayout(byte[] data) {
/*     */     try {
/* 162 */       LayoutDetail layout = getLocalLayout(null, data);
/*     */       
/* 164 */       this.lastLayoutFile = this.layoutFile.getText();
/*     */       
/* 166 */       if (layout == null) {
/* 167 */         FileAnalyser analyser = FileAnalyser.getAnaylser(data, "");
/* 168 */         layout = analyser.getLayoutDetails(true).asLayoutDetail();
/*     */       }
/* 170 */       if (layout == null) {
/* 171 */         System.out.println("No Layout Generated !!!");
/* 172 */         return false;
/*     */       }
/* 174 */       this.fileStructure = layout.getFileStructure();
/* 175 */       this.fontName = layout.getFontName();
/* 176 */       this.recordLength = layout.getMaximumRecordLength();
/*     */       
/* 178 */       ByteArrayInputStream is = new ByteArrayInputStream(data);
/* 179 */       LineIOProvider iop = LineIOProvider.getInstance();
/*     */       
/* 181 */       AbstractLineReader<LayoutDetail> r = iop.getLineReader(this.fileStructure);
/* 182 */       FileView view = new FileView(layout, iop, false);
/*     */       
/* 184 */       int i = 0;
/*     */       
/* 186 */       r.open(is, layout);
/*     */       try { AbstractLine l;
/* 188 */         while ((i++ < 60) && ((l = r.read()) != null)) {
/* 189 */           view.add(l);
/*     */         }
/*     */       }
/*     */       catch (Exception e) {}finally
/*     */       {
/* 194 */         r.close();
/* 195 */         is.close();
/*     */       }
/*     */       
/* 198 */       this.fileTable.setModel(view);
/* 199 */       view.fireTableStructureChanged();
/*     */       
/* 201 */       TableColumnModel tcm = this.fileTable.getColumnModel();
/* 202 */       TableColumn tc = tcm.getColumn(0);
/* 203 */       HeaderRender headerRender = new HeaderRender(null);
/*     */       
/* 205 */       for (i = 2; i < tcm.getColumnCount(); i++) {
/* 206 */         tcm.getColumn(i).setHeaderRenderer(headerRender);
/*     */       }
/* 208 */       if (tc != null) {
/* 209 */         this.fileTable.getColumnModel().removeColumn(tc);
/*     */       }
/* 211 */       r.close();
/* 212 */       is.close();
/*     */     }
/*     */     catch (Exception e) {
/* 215 */       e.printStackTrace();
/* 216 */       return false;
/*     */     }
/*     */     
/* 219 */     this.lastData = data;
/* 220 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getSeperator()
/*     */   {
/* 226 */     return "";
/*     */   }
/*     */   
/*     */   public String getQuote()
/*     */   {
/* 231 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean setLines(byte[][] newLines, String font, int numberOfLines)
/*     */   {
/* 237 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setLines(String[] newLines, String font, int numberOfLines) {}
/*     */   
/*     */ 
/*     */   public int getColumnCount()
/*     */   {
/* 247 */     return this.fileTable.getColumnCount();
/*     */   }
/*     */   
/*     */   public String getColumnName(int idx)
/*     */   {
/* 252 */     return null;
/*     */   }
/*     */   
/*     */   public LayoutDetail getLayout(String font, byte[] recordSep)
/*     */   {
/* 257 */     LayoutDetail l = getLocalLayout(font, null);
/* 258 */     if (l != null) {
/* 259 */       return l;
/*     */     }
/*     */     
/* 262 */     JDialog d = new JDialog(ReMainFrame.getMasterFrame(), true);
/* 263 */     WizardFileLayout wiz = new WizardFileLayout(d, this.filename, this, false, false);
/*     */     
/* 265 */     Details details = (Details)wiz.getWizardDetails();
/* 266 */     details.fileStructure = this.fileStructure;
/* 267 */     details.fontName = font;
/* 268 */     details.recordLength = this.recordLength;
/* 269 */     details.generateFieldNames = true;
/*     */     
/* 271 */     wiz.changePanel(1, false);
/* 272 */     if (wiz.getPanelNumber() == 1) {
/* 273 */       wiz.changePanel(1, false);
/*     */     }
/*     */     
/* 276 */     d.setVisible(true);
/*     */     
/* 278 */     ExternalRecord rec = wiz.getExternalRecord();
/* 279 */     if (rec != null) {
/*     */       try {
/* 281 */         return rec.asLayoutDetail();
/*     */       } catch (Exception e) {
/* 283 */         Common.logMsg(30, "Layout Generation Failed:", e.getMessage(), null);
/*     */       }
/*     */     }
/*     */     
/* 287 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getFileDescription()
/*     */   {
/* 294 */     return "FIXED~" + getStr(this.layoutFile.getText()) + "~" + this.dialectCombo.getSelectedIndex() + "~" + "Empty";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setFileDescription(String val)
/*     */   {
/* 301 */     StringTokenizer tok = new StringTokenizer(val, "~", false);
/*     */     try
/*     */     {
/* 304 */       tok.nextToken();
/* 305 */       this.layoutFile.setText(Parameters.expandVars(getStringTok(tok)));
/* 306 */       this.dialectCombo.setSelectedIndex(getIntTok(tok));
/*     */     }
/*     */     catch (Exception e) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isMyLayout(String layoutId, String filename, byte[] data)
/*     */   {
/* 318 */     boolean ret = (layoutId != null) && (layoutId.startsWith("FIXED"));
/* 319 */     if (ret) {
/* 320 */       setData(filename, data, false, layoutId);
/*     */     }
/*     */     
/* 323 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRecordLayout(int layoutId, String layoutName, String filename)
/*     */   {
/* 333 */     this.layoutFile.setText(layoutName);
/*     */   }
/*     */   
/*     */ 
/*     */   private LayoutDetail getLocalLayout(String font, byte[] data)
/*     */   {
/* 339 */     String layoutFileName = this.layoutFile.getText();
/* 340 */     if (!"".equals(layoutFileName)) {
/* 341 */       File f = new File(layoutFileName);
/*     */       
/* 343 */       if ((f.exists()) && (!f.isDirectory())) {
/*     */         try {
/*     */           CopybookLoader loader;
/* 346 */           if ((isCobol()) && (CobolCopybookLoader.isAvailable())) {
/* 347 */             CopybookLoader loader = new CobolCopybookLoader();
/* 348 */             if (font == null) {
/* 349 */               FileAnalyser analyser = FileAnalyser.getAnaylserNoLengthCheck(this.lastData, "");
/* 350 */               font = analyser.getFontName();
/* 351 */               this.fileStructure = analyser.getFileStructure();
/*     */             }
/*     */           } else {
/* 354 */             loader = new RecordEditorXmlLoader();
/*     */           }
/*     */           
/* 357 */           ExternalRecord rec = loader.loadCopyBook(layoutFileName, 0, 0, font, this.dialectCombo.getSelectedValue(), 0, Common.getLogger());
/* 358 */           if (this.fileStructure >= 0) {
/* 359 */             rec.setFileStructure(this.fileStructure);
/*     */           }
/* 361 */           return rec.asLayoutDetail();
/*     */         } catch (Exception e) {
/* 363 */           this.msg.setText("Layout Gen failed: " + e.getMessage());
/*     */         }
/*     */       }
/*     */     }
/* 367 */     return null;
/*     */   }
/*     */   
/*     */   private void setCobolVisible() {
/* 371 */     boolean cobol = isCobol();
/* 372 */     this.dialectCombo.setVisible(cobol);
/* 373 */     this.dialectLbl.setVisible(cobol);
/*     */   }
/*     */   
/*     */   private boolean isCobol() {
/* 377 */     boolean ret = false;
/* 378 */     String layoutFileName = this.layoutFile.getText();
/*     */     
/* 380 */     if ((layoutFileName != null) && (!"".equals(layoutFileName)) && (!layoutFileName.toLowerCase().endsWith(".xml")))
/*     */     {
/*     */ 
/* 383 */       File f = new File(layoutFileName);
/* 384 */       if ((f.exists()) && (!f.isDirectory())) {
/*     */         try {
/* 386 */           BufferedReader r = null;
/*     */           String s;
/*     */           try {
/* 389 */             r = new BufferedReader(new FileReader(f));
/* 390 */             s = r.readLine();
/*     */           } finally {
/* 392 */             if (r != null) {
/* 393 */               r.close();
/*     */             }
/*     */           }
/* 396 */           ret = (s != null) && (!s.trim().startsWith("<"));
/*     */         }
/*     */         catch (IOException e) {}
/*     */       }
/*     */     }
/* 401 */     return ret;
/*     */   }
/*     */   
/*     */   private String getStr(String s)
/*     */   {
/* 406 */     if ((s == null) || ("".equals(s))) {
/* 407 */       s = "Empty";
/*     */     }
/*     */     
/* 410 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */   private String getStringTok(StringTokenizer tok)
/*     */   {
/* 416 */     String s = tok.nextToken();
/* 417 */     if ((s == null) || ("Empty".equals(s))) {
/* 418 */       s = "";
/*     */     }
/* 420 */     return s;
/*     */   }
/*     */   
/*     */   private int getIntTok(StringTokenizer tok) {
/* 424 */     int ret = 0;
/*     */     try {
/* 426 */       ret = Integer.parseInt(tok.nextToken());
/*     */     }
/*     */     catch (Exception e) {}
/*     */     
/* 430 */     return ret;
/*     */   }
/*     */   
/*     */   public String getFontName()
/*     */   {
/* 435 */     return this.fontName;
/*     */   }
/*     */   
/*     */   public void setLayoutFile(String lFile)
/*     */   {
/* 440 */     this.layoutFile.setText(lFile);
/*     */   }
/*     */   
/*     */   public void setFilename(String filename)
/*     */   {
/* 445 */     if (!this.filename.equals(filename)) {
/* 446 */       this.layoutFile.setText("");
/*     */     }
/* 448 */     this.filename = filename;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class HeaderRender
/*     */     extends JPanel
/*     */     implements TableCellRenderer
/*     */   {
/*     */     public Component getTableCellRendererComponent(JTable tbl, Object value, boolean isFldSelected, boolean hasFocus, int row, int column)
/*     */     {
/* 468 */       removeAll();
/* 469 */       setLayout(new GridLayout(2, 1));
/*     */       
/* 471 */       if ((column >= 0) && (value != null))
/*     */       {
/* 473 */         String s = (String)value;
/* 474 */         String first = s;
/* 475 */         String second = "";
/* 476 */         int pos = s.indexOf("|");
/* 477 */         if (pos > 0) {
/* 478 */           first = s.substring(pos + 1);
/* 479 */           second = s.substring(0, pos);
/*     */         }
/* 481 */         JLabel label = new JLabel(first);
/* 482 */         add(label);
/* 483 */         if (!second.equals("")) {
/* 484 */           label = new JLabel(second);
/*     */           
/* 486 */           add(label);
/*     */         }
/*     */       }
/* 489 */       setBorder(BorderFactory.createEtchedBorder());
/*     */       
/* 491 */       return this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/util/csv/SchemaSelection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */