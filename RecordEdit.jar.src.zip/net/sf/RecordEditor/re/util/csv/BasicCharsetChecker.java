/*    */ package net.sf.RecordEditor.re.util.csv;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BasicCharsetChecker
/*    */ {
/* 10 */   public static final HashSet<String> STANDARD_CHARS = new HashSet();
/*    */   
/*    */   static {
/* 13 */     String s = "+-.,/?\\!'\"$%&*@()[]abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
/*    */     
/* 15 */     for (int i = 0; i < s.length(); i++) {
/* 16 */       STANDARD_CHARS.add(s.substring(i, i + 1));
/*    */     }
/*    */     
/* 19 */     for (int i = 0; i < Common.FIELD_SEPARATOR_TEXT_LIST.length; i++) {
/* 20 */       STANDARD_CHARS.add(Common.FIELD_SEPARATOR_LIST1_VALUES[i]);
/*    */     }
/* 22 */     STANDARD_CHARS.add("\n");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static double getValidCharsRatio(String s)
/*    */   {
/* 31 */     int count = 0;
/* 32 */     for (int i = 0; i < s.length(); i++) {
/* 33 */       if (STANDARD_CHARS.contains(s.substring(i, i + 1))) {
/* 34 */         count++;
/*    */       }
/*    */     }
/* 37 */     return count / s.length();
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/util/csv/BasicCharsetChecker.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */