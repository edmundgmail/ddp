/*    */ package net.sf.RecordEditor.re.util.csv;
/*    */ 
/*    */ public class CharsetDetails
/*    */ {
/*    */   public final String charset;
/*    */   public final String[] likelyCharsets;
/*    */   
/*    */   public CharsetDetails(String charset, String[] likelyCharsets)
/*    */   {
/* 10 */     this.charset = charset;
/* 11 */     this.likelyCharsets = likelyCharsets;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/util/csv/CharsetDetails.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */