/*     */ package net.sf.RecordEditor.re.util.csv;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.FocusAdapter;
/*     */ import java.awt.event.FocusEvent;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JPopupMenu;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import javax.swing.text.JTextComponent;
/*     */ import net.sf.JRecord.ByteIO.ByteTextReader;
/*     */ import net.sf.JRecord.Common.Conversion;
/*     */ import net.sf.JRecord.Common.Conversion.HoldEbcidicFlag;
/*     */ import net.sf.JRecord.CsvParser.ParserManager;
/*     */ import net.sf.JRecord.Details.LayoutDetail;
/*     */ import net.sf.JRecord.Details.RecordDetail;
/*     */ import net.sf.JRecord.Details.RecordDetail.FieldDetails;
/*     */ import net.sf.RecordEditor.utils.MenuPopupListener;
/*     */ import net.sf.RecordEditor.utils.charsets.FontCombo;
/*     */ import net.sf.RecordEditor.utils.edit.ManagerRowList;
/*     */ import net.sf.RecordEditor.utils.lang.ReAbstractAction;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.BmKeyedComboBox;
/*     */ import net.sf.RecordEditor.utils.swing.BmKeyedComboModel;
/*     */ import net.sf.RecordEditor.utils.swing.ComboBoxs.DelimiterCombo;
/*     */ import net.sf.RecordEditor.utils.swing.ComboBoxs.QuoteCombo;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CsvSelectionPanel
/*     */   extends BaseHelpPanel
/*     */   implements FilePreview
/*     */ {
/*     */   public static final String NORMAL_CSV_STRING = "CSV";
/*     */   public static final String UNICODE_CSV_STRING = "UNICODECSV";
/*  57 */   private boolean isByteBased = true;
/*     */   
/*  59 */   private ParserManager parserManager = ParserManager.getInstance();
/*     */   private MenuPopupListener popup;
/*  61 */   private String lastFont = null; private String lastSeperator = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  67 */   private BmKeyedComboModel styleModel = new BmKeyedComboModel(new ManagerRowList(this.parserManager, false));
/*     */   
/*     */   public final DelimiterCombo fieldSeparatorCombo;
/*  70 */   public final JTextField fieldSepTxt = new JTextField(5);
/*  71 */   public final JTextField quoteTxt = new JTextField(5);
/*  72 */   public final QuoteCombo quoteCombo = QuoteCombo.newCombo();
/*     */   
/*     */ 
/*  75 */   private final FontCombo charsetCombo = new FontCombo();
/*     */   
/*  77 */   public BmKeyedComboBox parseType = new BmKeyedComboBox(this.styleModel, false);
/*     */   
/*  79 */   public JCheckBox fieldNamesOnLine = new JCheckBox();
/*  80 */   public JTextField nameLineNoTxt = new JTextField(5);
/*  81 */   public JCheckBox checkTypes = new JCheckBox();
/*  82 */   public JCheckBox embeddedCrJCheck = new JCheckBox();
/*     */   
/*  84 */   public JButton go = SwingUtils.newButton("Go");
/*  85 */   public JButton cancel = SwingUtils.newButton("Cancel");
/*     */   
/*  87 */   private JTable linesTbl = new JTable();
/*     */   
/*     */   private AbstractCsvTblMdl tblMdl;
/*     */   
/*     */   private JTextComponent message;
/*  92 */   private boolean doAction = true;
/*  93 */   private byte[][] dataLines = (byte[][])null;
/*     */   
/*     */   private byte[] data;
/*  96 */   private ActionListener changedAction = new ActionListener()
/*     */   {
/*     */     public void actionPerformed(ActionEvent e) {
/*  99 */       if (CsvSelectionPanel.this.doAction) {
/* 100 */         CsvSelectionPanel.this.valueChanged();
/*     */       }
/*     */     }
/*     */   };
/* 104 */   private ChangeListener changeListner = new ChangeListener()
/*     */   {
/*     */ 
/*     */ 
/*     */     public void stateChanged(ChangeEvent e)
/*     */     {
/*     */ 
/* 111 */       if ((CsvSelectionPanel.this.doAction) && (
/* 112 */         (CsvSelectionPanel.this.lastFont == null) || (!CsvSelectionPanel.this.lastFont.equals(CsvSelectionPanel.this.getFontName())))) {
/* 113 */         CsvSelectionPanel.this.setData("", CsvSelectionPanel.this.data, false, "");
/* 114 */         CsvSelectionPanel.this.valueChanged(false);
/*     */       }
/*     */     }
/*     */   };
/*     */   
/*     */ 
/* 120 */   private ActionListener fieldNamesChanged = new ActionListener()
/*     */   {
/*     */     public void actionPerformed(ActionEvent e) {
/* 123 */       if (CsvSelectionPanel.this.doAction) {
/* 124 */         CsvSelectionPanel.this.tblMdl.setSeperator(CsvSelectionPanel.this.getSeperator());
/* 125 */         CsvSelectionPanel.this.tblMdl.setHideFirstLine(CsvSelectionPanel.this.fieldNamesOnLine.isSelected());
/*     */         
/* 127 */         CsvSelectionPanel.this.valueChanged();
/*     */       }
/*     */     }
/*     */   };
/*     */   
/* 132 */   private ActionListener sepChanged = new ActionListener() {
/*     */     public void actionPerformed(ActionEvent e) {
/* 134 */       if (CsvSelectionPanel.this.doAction) {
/* 135 */         String seperator = CsvSelectionPanel.this.getSeperator();
/* 136 */         if ((!seperator.equals(CsvSelectionPanel.this.lastSeperator)) || (CsvSelectionPanel.this.embeddedCrJCheck.isSelected()))
/*     */         {
/* 138 */           CsvSelectionPanel.this.lastSeperator = seperator;
/* 139 */           CsvSelectionPanel.this.reReadData();
/*     */         }
/* 141 */         CsvSelectionPanel.this.valueChanged(false);
/*     */       }
/*     */     }
/*     */   };
/*     */   
/* 146 */   private ActionListener crChanged = new ActionListener()
/*     */   {
/*     */     public void actionPerformed(ActionEvent e) {
/* 149 */       if (CsvSelectionPanel.this.doAction) {
/* 150 */         if ((CsvSelectionPanel.this.embeddedCrJCheck.isSelected()) && ("".equals(CsvSelectionPanel.this.getQuote()))) {
/*     */           try {
/* 152 */             CsvSelectionPanel.this.doAction = false;
/*     */             
/* 154 */             CsvSelectionPanel.this.tblMdl.setEmbedded(true);
/* 155 */             CsvAnalyser anaylyser = CsvSelectionPanel.this.tblMdl.getAnalyser(1);
/*     */             
/* 157 */             if (anaylyser.getQuoteIdx() > 0) {
/* 158 */               CsvSelectionPanel.this.quoteCombo.setSelectedIndex(anaylyser.getQuoteIdx());
/*     */             }
/* 160 */             CsvSelectionPanel.this.setQuoteTxt(anaylyser.getSpecialQuote());
/*     */           } finally {
/* 162 */             CsvSelectionPanel.this.doAction = true;
/*     */           }
/*     */         }
/* 165 */         CsvSelectionPanel.this.reReadData();
/* 166 */         CsvSelectionPanel.this.valueChanged(false);
/*     */       }
/* 168 */       if ((CsvSelectionPanel.this.embeddedCrJCheck.isSelected()) && ("".equals(CsvSelectionPanel.this.getQuote()))) {
/* 169 */         CsvSelectionPanel.this.setMessageTxtRE("You must specify a quote when embedded Cr is used");
/*     */       }
/*     */     }
/*     */   };
/*     */   
/* 174 */   private FocusAdapter focusHandler = new FocusAdapter()
/*     */   {
/*     */     public void focusLost(FocusEvent e) {
/* 177 */       boolean reRead = true;
/* 178 */       String seperator = CsvSelectionPanel.this.getSeperator();
/* 179 */       if ((e.getSource() == CsvSelectionPanel.this.charsetCombo.getTextCompenent()) && ((CsvSelectionPanel.this.lastFont == null) || (!CsvSelectionPanel.this.lastFont.equals(CsvSelectionPanel.this.getFontName()))))
/*     */       {
/* 181 */         CsvSelectionPanel.this.lastFont = CsvSelectionPanel.this.getFontName();
/* 182 */         if (CsvSelectionPanel.this.dataLines == null) {
/* 183 */           CsvSelectionPanel.this.setData("", CsvSelectionPanel.this.data, false, "");
/* 184 */           reRead = false;
/*     */         } else {
/* 186 */           CsvSelectionPanel.this.setData(CsvSelectionPanel.this.dataLines, CsvSelectionPanel.this.lastFont);
/*     */         }
/* 188 */       } else if ((e.getSource() == CsvSelectionPanel.this.embeddedCrJCheck) || (((e.getSource() == CsvSelectionPanel.this.fieldSeparatorCombo) || (e.getSource() == CsvSelectionPanel.this.fieldSepTxt)) && (!seperator.equals(CsvSelectionPanel.this.lastSeperator))))
/*     */       {
/*     */ 
/* 191 */         CsvSelectionPanel.this.lastSeperator = seperator;
/* 192 */         if (CsvSelectionPanel.this.dataLines == null) {
/* 193 */           CsvSelectionPanel.this.reReadData();
/* 194 */           reRead = false;
/*     */         } else {
/* 196 */           CsvSelectionPanel.this.setData(CsvSelectionPanel.this.dataLines, CsvSelectionPanel.this.lastFont);
/*     */         }
/* 198 */       } else if ((CsvSelectionPanel.this.embeddedCrJCheck.isSelected()) && (CsvSelectionPanel.this.dataLines == null)) {
/* 199 */         CsvSelectionPanel.this.reReadData();
/* 200 */         reRead = false;
/*     */       }
/* 202 */       CsvSelectionPanel.this.valueChanged(reRead);
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */   public CsvSelectionPanel(byte[][] dataLines, String font, boolean showCancel, JTextComponent msg)
/*     */   {
/* 209 */     this(dataLines, font, showCancel, "", msg, false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public CsvSelectionPanel(byte[][] dataLines, String font, boolean showCancel, String heading, JTextComponent msg, boolean adjustableTblHeight)
/*     */   {
/* 216 */     this.fieldSeparatorCombo = DelimiterCombo.NewDelimCombo();
/* 217 */     this.message = msg;
/* 218 */     setData(dataLines, font);
/*     */     
/* 220 */     init_100_SetupFields();
/* 221 */     init_200_LayoutScreen(showCancel, heading, adjustableTblHeight);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public CsvSelectionPanel(byte[] data, String font, boolean showCancel, String heading, JTextComponent msg, boolean adjustableTblHeight)
/*     */   {
/* 228 */     this.message = msg;
/* 229 */     this.isByteBased = false;
/* 230 */     this.fieldSeparatorCombo = DelimiterCombo.NewDelimCombo();
/*     */     
/* 232 */     setData("", data, true, null);
/*     */     
/* 234 */     init_100_SetupFields();
/* 235 */     init_200_LayoutScreen(showCancel, heading, adjustableTblHeight);
/* 236 */     valueChanged(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public BaseHelpPanel getPanel()
/*     */   {
/* 244 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */   public JButton getGoButton()
/*     */   {
/* 250 */     return this.go;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getFontName()
/*     */   {
/* 256 */     String font = this.charsetCombo.getText();
/* 257 */     if ((Conversion.DEFAULT_CHARSET_DETAILS.isMultiByte) && ((font == null) || (font.length() == 0)))
/*     */     {
/* 259 */       if (this.isByteBased) {
/* 260 */         font = Conversion.getDefaultSingleByteCharacterset();
/*     */       } else {
/* 262 */         font = Conversion.DEFAULT_CHARSET_DETAILS.charset;
/*     */       }
/*     */     }
/* 265 */     return font;
/*     */   }
/*     */   
/*     */   private void setData(byte[][] dataLines, String font)
/*     */   {
/* 270 */     CsvAnalyser anaylyser = new CsvAnalyser(dataLines, -1, "", this.embeddedCrJCheck.isSelected());
/* 271 */     setUpSeperator(anaylyser);
/*     */     
/* 273 */     this.dataLines = dataLines;
/*     */     
/* 275 */     this.tblMdl = new CsvSelectionTblMdl(this.parserManager);
/* 276 */     this.tblMdl.setLines(dataLines, font);
/* 277 */     this.tblMdl.setFieldLineNo(getFieldLineNo());
/*     */     
/* 279 */     this.linesTbl.setModel(this.tblMdl);
/* 280 */     valueChanged(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean setData(String filename, byte[] data, boolean checkCharset, String layoutId)
/*     */   {
/* 290 */     if ((layoutId != null) && (!"".equals(layoutId))) {
/* 291 */       setFileDescription(layoutId);
/*     */     }
/*     */     
/* 294 */     String font = getFontName();
/*     */     
/* 296 */     boolean reRead = false;
/*     */     
/*     */ 
/* 299 */     this.data = data;
/* 300 */     if ((data == null) || (data.length == 0)) {
/* 301 */       return false;
/*     */     }
/* 303 */     this.dataLines = ((byte[][])null);
/* 304 */     this.lastFont = font;
/*     */     
/* 306 */     CharsetDetails charsetDetails = CheckEncoding.determineCharSet(data, true);
/* 307 */     if (checkCharset) {
/* 308 */       font = charsetDetails.charset;
/* 309 */       setCharset(font);
/*     */     }
/* 311 */     setCharsetCombo(charsetDetails);
/*     */     
/*     */ 
/* 314 */     setTblMdl((isBinarySep()) || (possibleBinarySep(data, font)), font);
/*     */     
/*     */ 
/* 317 */     CsvAnalyser anaylyser = this.tblMdl.getAnalyser(1);
/*     */     
/* 319 */     reRead = (this.embeddedCrJCheck.isSelected()) && (anaylyser.getQuoteIdx() > 0) && ("".equals(getQuote()));
/* 320 */     setUpSeperator(anaylyser);
/*     */     
/* 322 */     this.tblMdl.setFieldLineNo(getFieldLineNo());
/*     */     
/* 324 */     this.linesTbl.setModel(this.tblMdl);
/* 325 */     valueChanged(reRead);
/*     */     
/* 327 */     return anaylyser.isValidChars();
/*     */   }
/*     */   
/*     */   public final void setCharset(String charset)
/*     */   {
/*     */     try
/*     */     {
/* 334 */       this.charsetCombo.setText(charset);
/*     */     } finally {
/* 336 */       this.doAction = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void setCharsetCombo(CharsetDetails dtls)
/*     */   {
/* 343 */     String currCharset = getFontName();
/*     */     
/* 345 */     if ((dtls.likelyCharsets != null) && (dtls.likelyCharsets.length != 0))
/*     */     {
/*     */ 
/* 348 */       int noCharSets = dtls.likelyCharsets.length + 1;
/* 349 */       int j = 0;
/*     */       
/* 351 */       for (String c : dtls.likelyCharsets) {
/* 352 */         String trim = c.trim();
/* 353 */         if ((currCharset.equalsIgnoreCase(trim)) || (trim.length() == 0)) {
/* 354 */           noCharSets--;
/* 355 */           break;
/*     */         }
/*     */       }
/*     */       
/*     */       String[] items;
/* 360 */       if (!"".equals(currCharset)) {
/* 361 */         String[] items = new String[Math.min(10, noCharSets)];
/* 362 */         items[(j++)] = currCharset;
/*     */       } else {
/* 364 */         items = new String[Math.min(10, noCharSets - 1)];
/*     */       }
/* 366 */       for (int i = 0; (j < items.length) && (i < dtls.likelyCharsets.length); i++) {
/* 367 */         String cs = dtls.likelyCharsets[i].trim();
/* 368 */         if ((cs.length() > 0) && (!currCharset.equalsIgnoreCase(cs))) {
/* 369 */           items[(j++)] = cs;
/*     */         }
/*     */       }
/* 372 */       this.charsetCombo.setFontList(items);
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean possibleBinarySep(byte[] data, String font) {
/* 377 */     boolean ret = false;
/*     */     
/* 379 */     if (Conversion.isSingleByte(font)) {
/*     */       try {
/* 381 */         List<byte[]> l = ByteTextReader.readStream(font, new ByteArrayInputStream(data), 90);
/* 382 */         byte[][] lines = (byte[][])l.toArray(new byte[l.size()][]);
/* 383 */         String sep = CsvAnalyser.getSeperator(lines, lines.length, font);
/*     */         
/* 385 */         ret = (sep != null) && (sep.startsWith("x'"));
/*     */       } catch (IOException e) {
/* 387 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */     
/* 391 */     return ret;
/*     */   }
/*     */   
/*     */   private void reReadData()
/*     */   {
/* 396 */     if ((this.data == null) || (this.dataLines != null)) {
/* 397 */       return;
/*     */     }
/*     */     
/* 400 */     setTblMdl(isBinarySep(), getFontName());
/*     */     
/* 402 */     this.tblMdl.setFieldLineNo(getFieldLineNo());
/* 403 */     this.linesTbl.setModel(this.tblMdl);
/*     */   }
/*     */   
/*     */   private void setTblMdl(boolean useByteMdl, String font)
/*     */   {
/* 408 */     if (useByteMdl) {
/* 409 */       this.tblMdl = new CsvSelectionTblMdl(this.parserManager);
/*     */     } else {
/* 411 */       this.tblMdl = new CsvSelectionStringTblMdl(this.parserManager);
/*     */     }
/*     */     
/* 414 */     this.tblMdl.setParserType(((Integer)this.parseType.getSelectedItem()).intValue());
/* 415 */     this.tblMdl.setQuote(getQuote());
/* 416 */     this.tblMdl.setSeperator(getSeperator());
/* 417 */     this.tblMdl.setDataFont(this.data, font, this.embeddedCrJCheck.isSelected());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_100_SetupFields()
/*     */   {
/* 427 */     this.nameLineNoTxt.setText("1");
/* 428 */     this.fieldSeparatorCombo.addFocusListener(this.focusHandler);
/* 429 */     this.fieldSepTxt.addFocusListener(this.focusHandler);
/* 430 */     this.quoteCombo.addFocusListener(this.focusHandler);
/* 431 */     this.quoteTxt.addFocusListener(this.focusHandler);
/* 432 */     this.parseType.addFocusListener(this.focusHandler);
/* 433 */     this.charsetCombo.getTextCompenent().addFocusListener(this.focusHandler);
/* 434 */     this.fieldNamesOnLine.addFocusListener(this.focusHandler);
/* 435 */     this.nameLineNoTxt.addFocusListener(this.focusHandler);
/* 436 */     this.embeddedCrJCheck.addFocusListener(this.focusHandler);
/*     */     
/* 438 */     this.fieldSeparatorCombo.addActionListener(this.sepChanged);
/* 439 */     this.quoteCombo.addActionListener(this.changedAction);
/* 440 */     this.quoteTxt.addActionListener(this.changedAction);
/* 441 */     this.parseType.addActionListener(this.changedAction);
/* 442 */     this.charsetCombo.addTextChangeListner(this.changeListner);
/* 443 */     this.fieldNamesOnLine.addActionListener(this.fieldNamesChanged);
/* 444 */     this.embeddedCrJCheck.addActionListener(this.crChanged);
/*     */   }
/*     */   
/*     */   private void init_200_LayoutScreen(boolean showCancel, String heading, boolean adjustableTblHeight) {
/* 448 */     double fileTblHeight = SwingUtils.TABLE_ROW_HEIGHT * 27 / 2;
/* 449 */     JPanel fieldSeperatorPnl = init_200_bld2fieldPnl(this.fieldSeparatorCombo, this.fieldSepTxt, "FieldSep");
/* 450 */     JPanel quotePnl = init_200_bld2fieldPnl(this.quoteCombo, this.quoteTxt, "Quote");
/*     */     
/*     */ 
/* 453 */     super.setFieldToActualSize();
/* 454 */     super.setAddFillToEnd(true);
/* 455 */     BasePanel.setToCommonWidth(1, 10, new JComponent[] { this.fieldSeparatorCombo, this.quoteCombo });
/* 456 */     BasePanel.setToCommonWidth(1, 15, new JComponent[] { fieldSeperatorPnl, quotePnl, this.charsetCombo });
/*     */     
/* 458 */     if ((heading != null) && (!"".equals(heading))) {
/* 459 */       JLabel headingLabel = new JLabel("  " + heading + "  ");
/* 460 */       Font font = headingLabel.getFont();
/* 461 */       headingLabel.setBackground(Color.WHITE);
/* 462 */       headingLabel.setOpaque(true);
/* 463 */       headingLabel.setFont(new Font(font.getFamily(), 1, font.getSize() + 2));
/*     */       
/* 465 */       addHeadingComponentRE(headingLabel);
/* 466 */       setGapRE(GAP0);
/*     */     }
/* 468 */     addLineRE("Field Seperator", fieldSeperatorPnl);
/* 469 */     setGapRE(GAP1);
/*     */     
/* 471 */     addLineRE("Quote", quotePnl);
/*     */     
/* 473 */     if (!this.isByteBased) {
/* 474 */       addLineRE("Font", this.charsetCombo);
/*     */     }
/* 476 */     if (adjustableTblHeight) {
/* 477 */       fileTblHeight = -1.0D;
/* 478 */     } else if (!this.isByteBased) {
/* 479 */       fileTblHeight -= SwingUtils.TABLE_ROW_HEIGHT * 2;
/*     */     }
/* 481 */     addLineRE("Parser", this.parseType);
/* 482 */     addLineRE("Names on Line", this.fieldNamesOnLine);
/*     */     
/* 484 */     if (showCancel) {
/* 485 */       addLineRE("Line Number of Names", this.nameLineNoTxt, this.go);
/* 486 */       setGapRE(BasePanel.GAP);
/* 487 */       addLineRE("set Column Types", this.checkTypes);
/* 488 */       addLineRE("embedded New Lines", this.embeddedCrJCheck, this.cancel);
/* 489 */       setGapRE(BasePanel.GAP);
/*     */     } else {
/* 491 */       addLineRE("Line Number of Names", this.nameLineNoTxt);
/* 492 */       addLineRE("set Column Types", this.checkTypes);
/* 493 */       addLineRE("embedded New Lines", this.embeddedCrJCheck, this.go);
/* 494 */       setGapRE(BasePanel.GAP1);
/*     */     }
/*     */     
/* 497 */     addComponentRE(1, 6, fileTblHeight, BasePanel.GAP, 2, 2, this.linesTbl);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 502 */     if (this.message == null) {
/* 503 */       this.message = new JTextField();
/*     */       
/* 505 */       setGapRE(GAP1);
/* 506 */       addMessage(this.message);
/* 507 */       setHeightRE(HEIGHT_1P4);
/*     */     } else {
/* 509 */       super.setMessageRE(this.message);
/*     */     }
/*     */     
/* 512 */     this.popup = new MenuPopupListener();
/* 513 */     this.popup.setTable(this.linesTbl);
/* 514 */     this.popup.getPopup().add(new ReAbstractAction("set as Field Name Row") {
/*     */       public void actionPerformed(ActionEvent e) {
/* 516 */         int inc = 1;
/* 517 */         if ((CsvSelectionPanel.this.fieldNamesOnLine.isSelected()) && (CsvSelectionPanel.this.getFieldLineNo() == 1)) {
/* 518 */           inc = 2;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 524 */         CsvSelectionPanel.this.fieldNamesOnLine.setSelected(true);
/* 525 */         CsvSelectionPanel.this.nameLineNoTxt.setText(Integer.toString(CsvSelectionPanel.this.popup.getPopupRow() + inc));
/* 526 */         CsvSelectionPanel.this.valueChanged();
/*     */       }
/* 528 */     });
/* 529 */     this.linesTbl.addMouseListener(this.popup);
/*     */   }
/*     */   
/*     */   private JPanel init_200_bld2fieldPnl(JComponent field1, JComponent field2, String fieldName)
/*     */   {
/* 534 */     JPanel ret = new JPanel(new BorderLayout());
/*     */     
/* 536 */     JPanel pnl1 = new JPanel();
/* 537 */     JLabel orLbl = new JLabel("   or ");
/* 538 */     this.linesTbl.setAutoResizeMode(0);
/*     */     
/* 540 */     pnl1.add(orLbl);
/*     */     
/* 542 */     orLbl.setAlignmentX(0.5F);
/*     */     
/* 544 */     ret.add("West", field1);
/* 545 */     ret.add("Center", pnl1);
/*     */     
/* 547 */     ret.add("East", field2);
/* 548 */     ret.setMinimumSize(new Dimension(ret.getPreferredSize().width, SwingUtils.TABLE_ROW_HEIGHT));
/*     */     
/* 550 */     setComponentName(field2, fieldName);
/*     */     
/* 552 */     return ret;
/*     */   }
/*     */   
/*     */   private void valueChanged()
/*     */   {
/* 557 */     valueChanged(true);
/*     */   }
/*     */   
/*     */ 
/*     */   private void valueChanged(boolean reRead)
/*     */   {
/*     */     try
/*     */     {
/* 565 */       this.doAction = false;
/* 566 */       String quoteStr = getQuote();
/*     */       
/* 568 */       if (((reRead) && (this.embeddedCrJCheck.isSelected())) || (this.tblMdl == null)) {
/* 569 */         reReadData();
/*     */       } else {
/* 571 */         this.tblMdl.setParserType(((Integer)this.parseType.getSelectedItem()).intValue());
/* 572 */         this.tblMdl.setQuote(quoteStr);
/* 573 */         this.tblMdl.setSeperator(getSeperator());
/* 574 */         this.tblMdl.setFont(getFontName());
/*     */       }
/*     */       
/* 577 */       if (this.tblMdl != null) {
/* 578 */         if (this.tblMdl.getRowCount() > 0) {
/*     */           try {
/* 580 */             String l = this.tblMdl.getLine(0).trim();
/*     */             
/* 582 */             this.tblMdl.setFieldLineNo(getFieldLineNo());
/* 583 */             if ((this.fieldNamesOnLine.isSelected()) && (!"".equals(quoteStr)) && (l.startsWith(quoteStr)) && (l.endsWith(quoteStr)) && (this.parseType.getSelectedIndex() == 0))
/*     */             {
/*     */ 
/* 586 */               this.parseType.setSelectedIndex(3);
/* 587 */               this.tblMdl.setParserType(((Integer)this.parseType.getSelectedItem()).intValue());
/*     */             }
/*     */             
/* 590 */             this.tblMdl.setHideFirstLine(this.fieldNamesOnLine.isSelected());
/*     */           }
/*     */           catch (Exception e) {}
/*     */         }
/* 594 */         this.tblMdl.setupColumnCount();
/* 595 */         this.tblMdl.fireTableStructureChanged();
/*     */       }
/*     */     } catch (Exception e) {
/* 598 */       e.printStackTrace();
/*     */     } finally {
/* 600 */       this.doAction = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getSeperator()
/*     */   {
/* 611 */     String sep = this.fieldSepTxt.getText();
/*     */     
/* 613 */     if ((sep == null) || ("".equals(sep)) || (!isSepValid())) {
/* 614 */       sep = this.fieldSeparatorCombo.getSelectedEnglish();
/*     */     }
/*     */     
/* 617 */     if ("<Space>".equals(sep)) {
/* 618 */       sep = " ";
/* 619 */     } else if ("<Tab>".equals(sep)) {
/* 620 */       sep = "\t";
/* 621 */     } else if ("<Default>".equals(sep)) {
/* 622 */       sep = ",";
/*     */     }
/*     */     
/* 625 */     return sep;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isSepValid()
/*     */   {
/* 633 */     boolean ret = false;
/* 634 */     String v = this.fieldSepTxt.getText();
/* 635 */     boolean singleByte = Conversion.isSingleByte(getFontName());
/*     */     
/* 637 */     if (v.length() < 2) {
/* 638 */       ret = true;
/* 639 */     } else if ((singleByte) && (isValidTextBinarySep())) {
/*     */       try {
/* 641 */         Conversion.getByteFromHexString(v);
/* 642 */         ret = true;
/*     */       } catch (Exception e) {
/* 644 */         setMessageTxtRE("Invalid Delimiter - Invalid  hex string:", v.substring(2, 3));
/*     */       }
/* 646 */     } else if (singleByte) {
/* 647 */       setMessageTxtRE("Invalid Delimiter, should be a single character or a hex character");
/*     */     } else {
/* 649 */       setMessageTxtRE("Invalid Delimiter, should be a single character");
/*     */     }
/*     */     
/* 652 */     return ret;
/*     */   }
/*     */   
/*     */   private boolean isValidTextBinarySep() {
/* 656 */     String v = this.fieldSepTxt.getText();
/* 657 */     return (v.length() == 5) && (v.toLowerCase().startsWith("x'")) && (v.endsWith("'"));
/*     */   }
/*     */   
/*     */   private boolean isBinarySep()
/*     */   {
/* 662 */     String v = getSeperator();
/* 663 */     return (v.toLowerCase().startsWith("x'")) && (v.endsWith("'"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getQuote()
/*     */   {
/* 671 */     String q = this.quoteTxt.getText();
/* 672 */     if ((q == null) || ("".equals(q))) {
/* 673 */       return (String)this.quoteCombo.getSelectedKey();
/*     */     }
/* 675 */     return q;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean setLines(byte[][] newLines, String font, int numberOfLines)
/*     */   {
/* 685 */     CsvAnalyser analyser = new CsvAnalyser(newLines, numberOfLines, "", this.embeddedCrJCheck.isSelected());
/* 686 */     this.tblMdl.setLines(newLines, font);
/* 687 */     this.tblMdl.setLines2display(numberOfLines);
/*     */     
/* 689 */     setUpSeperator(analyser);
/* 690 */     this.tblMdl.setFieldLineNo(getFieldLineNo());
/* 691 */     valueChanged();
/*     */     
/* 693 */     return analyser.isValidChars();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLines(String[] newLines, String font, int numberOfLines)
/*     */   {
/* 705 */     this.tblMdl.setLines(newLines);
/* 706 */     this.tblMdl.setLines2display(numberOfLines);
/* 707 */     setUpSeperator(new CsvAnalyser(newLines, numberOfLines, "", this.embeddedCrJCheck.isSelected()));
/* 708 */     valueChanged();
/*     */   }
/*     */   
/*     */   private void setUpSeperator(CsvAnalyser analyse)
/*     */   {
/*     */     try {
/* 714 */       this.doAction = false;
/* 715 */       this.fieldSeparatorCombo.setSelectedIndex(analyse.getSeperatorIdx());
/* 716 */       this.fieldSepTxt.setText("");
/* 717 */       this.quoteCombo.setSelectedIndex(analyse.getQuoteIdx());
/* 718 */       this.quoteTxt.setText("");
/* 719 */       setQuoteTxt(analyse.getSpecialQuote());
/*     */       
/* 721 */       switch (analyse.getColNamesOnFirstLine()) {
/*     */       case 2: 
/* 723 */         this.fieldNamesOnLine.setSelected(false);
/* 724 */         this.nameLineNoTxt.setText("1");
/* 725 */         break;
/*     */       case 1: 
/* 727 */         this.fieldNamesOnLine.setSelected(true);
/* 728 */         this.nameLineNoTxt.setText(Integer.toString(analyse.getFieldNameLineNo()));
/*     */       }
/*     */     }
/*     */     finally {
/* 732 */       this.doAction = true;
/*     */     }
/*     */   }
/*     */   
/*     */   private void setQuoteTxt(Character c)
/*     */   {
/* 738 */     if (c != null) {
/* 739 */       this.quoteTxt.setText(c.toString());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColumnCount()
/*     */   {
/* 748 */     return this.tblMdl.getColumnCount();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getColumnName(int idx)
/*     */   {
/* 755 */     return this.tblMdl.getColumnName(idx);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LayoutDetail getLayout(String font, byte[] recordSep)
/*     */   {
/* 766 */     int numCols = getColumnCount();
/* 767 */     int ioId = 9;
/* 768 */     int format = 0;
/* 769 */     int i = 0;
/* 770 */     int fldLineNo = getFieldLineNo();
/* 771 */     boolean useThisLayout = true;
/* 772 */     String param = "";
/*     */     
/*     */ 
/*     */ 
/* 776 */     int[] fieldTypes = null;
/*     */     
/* 778 */     RecordDetail.FieldDetails[] flds = new RecordDetail.FieldDetails[numCols];
/* 779 */     RecordDetail[] recs = new RecordDetail[1];
/*     */     
/* 781 */     if (Conversion.isSingleByte(font)) {
/* 782 */       if ((this.fieldNamesOnLine.isSelected()) && (fldLineNo < 2)) {
/* 783 */         ioId = 54;
/*     */       }
/*     */     } else {
/* 786 */       ioId = 90;
/* 787 */       if ((this.fieldNamesOnLine.isSelected()) && (fldLineNo < 2)) {
/* 788 */         ioId = 55;
/*     */       }
/*     */     }
/*     */     
/* 792 */     CsvAnalyser analyser = this.tblMdl.getAnalyser(2);
/* 793 */     if ((this.checkTypes.isSelected()) || (this.parseType.getSelectedIndex() == 2) || (this.parseType.getSelectedIndex() == 5))
/*     */     {
/*     */ 
/* 796 */       fieldTypes = analyser.getTypes();
/*     */     } else {
/* 798 */       fieldTypes = analyser.getTextTypes();
/*     */     }
/*     */     
/* 801 */     for (i = 0; i < numCols; i++) {
/* 802 */       int fieldType = 0;
/* 803 */       if ((fieldTypes != null) && (i < fieldTypes.length)) {
/* 804 */         fieldType = fieldTypes[i];
/*     */       }
/* 806 */       String s = getColumnName(i);
/*     */       
/* 808 */       flds[i] = new RecordDetail.FieldDetails(s, s, fieldType, 0, font, format, param);
/*     */       
/* 810 */       flds[i].setPosOnly(i + 1);
/*     */     }
/*     */     
/*     */ 
/* 814 */     if ((fieldTypes == null) && (analyser.getColNamesOnFirstLine() != 2) && (this.linesTbl.getRowCount() == 0))
/*     */     {
/*     */ 
/* 817 */       useThisLayout = false;
/*     */     }
/*     */     
/* 820 */     recs[0] = new RecordDetail("GeneratedCsvRecord", "", "", 2, getSeperator(), getQuote(), font, flds, ((Integer)this.parseType.getSelectedItem()).intValue(), 0, this.embeddedCrJCheck.isSelected());
/*     */     
/*     */ 
/*     */ 
/* 824 */     LayoutDetail layout = new LayoutDetail("GeneratedCsv", recs, "", 2, recordSep, "", font, null, ioId);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 831 */     layout.setUseThisLayout(useThisLayout);
/* 832 */     return layout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFileDescription()
/*     */   {
/* 840 */     String csv = "UNICODECSV";
/*     */     
/* 842 */     if (this.isByteBased) {
/* 843 */       csv = "CSV";
/*     */     }
/*     */     
/*     */ 
/* 847 */     return csv + "~" + this.fieldSeparatorCombo.getSelectedIndex() + "~" + getStr(this.fieldSepTxt.getText()) + "~" + this.quoteCombo.getSelectedEnglish() + "~" + this.parseType.getSelectedIndex() + "~" + getBool(this.fieldNamesOnLine) + "~" + getBool(this.checkTypes) + "~" + getStr(getFontName()) + "~" + getStr(this.nameLineNoTxt.getText()) + "~" + getStr(this.quoteTxt.getText()) + "~" + getBool(this.embeddedCrJCheck);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFileDescription(String val)
/*     */   {
/* 866 */     StringTokenizer tok = new StringTokenizer(val, "~", false);
/*     */     try
/*     */     {
/* 869 */       this.doAction = false;
/* 870 */       System.out.print(tok.nextToken());
/* 871 */       this.fieldSeparatorCombo.setSelectedIndex(getIntTok(tok));
/* 872 */       this.fieldSepTxt.setText(getStringTok(tok));
/* 873 */       this.quoteCombo.setEnglish(getStringTok(tok));
/* 874 */       this.parseType.setSelectedIndex(getIntTok(tok));
/* 875 */       this.fieldNamesOnLine.setSelected(getBoolTok(tok));
/* 876 */       this.checkTypes.setSelected(getBoolTok(tok));
/* 877 */       this.charsetCombo.setText(getStringTok(tok));
/* 878 */       this.nameLineNoTxt.setText(getStringTok(tok));
/* 879 */       this.quoteTxt.setText(getStringTok(tok));
/* 880 */       this.embeddedCrJCheck.setSelected(getBoolTok(tok));
/*     */     }
/*     */     catch (Exception e) {}finally
/*     */     {
/* 884 */       this.doAction = true;
/*     */     }
/*     */   }
/*     */   
/*     */   private String getBool(JCheckBox chk) {
/* 889 */     String s = "N";
/* 890 */     if (chk.isSelected()) {
/* 891 */       s = "Y";
/*     */     }
/* 893 */     return s;
/*     */   }
/*     */   
/*     */   private String getStr(String s) {
/* 897 */     if ((s == null) || ("".equals(s))) {
/* 898 */       s = "Empty";
/*     */     }
/*     */     
/* 901 */     return s;
/*     */   }
/*     */   
/*     */   private int getIntTok(StringTokenizer tok) {
/* 905 */     int ret = 0;
/*     */     try {
/* 907 */       ret = Integer.parseInt(tok.nextToken());
/*     */     }
/*     */     catch (Exception e) {}
/*     */     
/*     */ 
/* 912 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean getBoolTok(StringTokenizer tok)
/*     */   {
/* 918 */     return "Y".equalsIgnoreCase(tok.nextToken());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private String getStringTok(StringTokenizer tok)
/*     */   {
/* 925 */     String s = tok.nextToken();
/* 926 */     if ((s == null) || ("Empty".equals(s))) {
/* 927 */       s = "";
/*     */     }
/* 929 */     return s;
/*     */   }
/*     */   
/*     */   private int getFieldLineNo() {
/* 933 */     int ret = 1;
/* 934 */     String s = this.nameLineNoTxt.getText();
/* 935 */     if (!"".equals(s)) {
/*     */       try {
/* 937 */         ret = Integer.parseInt(s);
/*     */         
/* 939 */         if (ret < 1) {
/* 940 */           ret = 1;
/* 941 */           setMessageTxtRE("Field Line Number should be one or more and not", s);
/*     */         }
/*     */       } catch (Exception e) {
/* 944 */         setMessageTxtRE("Invalid Field Line Number:", s);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 949 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isMyLayout(String layoutId, String filename, byte[] data)
/*     */   {
/* 958 */     return false;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/util/csv/CsvSelectionPanel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */