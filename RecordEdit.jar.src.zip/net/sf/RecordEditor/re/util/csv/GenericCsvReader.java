/*     */ package net.sf.RecordEditor.re.util.csv;
/*     */ 
/*     */ import java.awt.Container;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JTextField;
/*     */ import net.sf.JRecord.Common.RecordException;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.LineProvider;
/*     */ import net.sf.JRecord.IO.AbstractLineReader;
/*     */ import net.sf.JRecord.IO.DelegateReader;
/*     */ import net.sf.JRecord.IO.LineIOProvider;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMainFrame;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.EditingCancelled;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GenericCsvReader
/*     */   extends DelegateReader
/*     */ {
/*     */   public GenericCsvReader(LineProvider provider)
/*     */   {
/*  43 */     super(provider);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void open(InputStream inputStream, AbstractLayoutDetails layout)
/*     */     throws IOException, RecordException
/*     */   {
/*  53 */     BufferedInputStream inStream = new BufferedInputStream(inputStream);
/*     */     
/*  55 */     int bytesAvailable = inStream.available();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  60 */     if (bytesAvailable < 2) {
/*  61 */       bytesAvailable = 90112;
/*     */     }
/*  63 */     byte[] fileData = new byte[Math.min(90112, bytesAvailable)];
/*  64 */     inStream.mark(fileData.length);
/*  65 */     int len = inStream.read(fileData);
/*  66 */     inStream.reset();
/*     */     
/*  68 */     if (fileData.length > len) {
/*  69 */       byte[] t = new byte[len];
/*  70 */       System.arraycopy(fileData, 0, t, 0, len);
/*  71 */       fileData = t;
/*     */     }
/*     */     
/*  74 */     GetCsvDetails getDetails = new GetCsvDetails(fileData, layout.getFontName());
/*     */     
/*  76 */     if (getDetails.ok) {
/*  77 */       FilePreview csv = getDetails.csvTab.getSelectedCsvDetails();
/*  78 */       layout = csv.getLayout(csv.getFontName(), null);
/*     */       
/*     */ 
/*  81 */       if (layout != null) {
/*  82 */         setLayout(layout);
/*     */       }
/*     */       
/*  85 */       AbstractLineReader reader = LineIOProvider.getInstance().getLineReader(layout);
/*  86 */       reader.open(inStream, layout);
/*  87 */       reader.setLayout(layout);
/*  88 */       setReader(reader);
/*     */     } else {
/*  90 */       throw new EditingCancelled();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class GetCsvDetails
/*     */     extends JDialog
/*     */     implements ActionListener
/*     */   {
/* 109 */     public final KeyAdapter keyListner = new KeyAdapter()
/*     */     {
/*     */ 
/*     */       public final void keyReleased(KeyEvent event)
/*     */       {
/*     */ 
/* 115 */         if (event.getKeyCode() == 10) {
/* 116 */           GenericCsvReader.GetCsvDetails.this.finnished(true);
/*     */         }
/*     */       }
/*     */     };
/*     */     
/* 121 */     public final BaseHelpPanel pnl = new BaseHelpPanel();
/*     */     public final CsvTabPane csvTab;
/* 123 */     public final JTextField msgTxt = new JTextField();
/* 124 */     public boolean ok = false;
/*     */     
/*     */     public GetCsvDetails(byte[] data, String font) throws IOException {
/* 127 */       super(true);
/*     */       
/* 129 */       this.pnl.addReKeyListener(this.keyListner);
/*     */       
/* 131 */       this.csvTab = new CsvTabPane(this.msgTxt, false, false);
/* 132 */       this.csvTab.readCheckPreview(data, true, "", null);
/* 133 */       this.csvTab.readOtherTab("", data);
/*     */       
/* 135 */       this.pnl.setHelpURLre(Common.formatHelpURL("HlpRe16.htm#HDRGENERICCSV"));
/*     */       
/* 137 */       this.csvTab.csvDetails.go.addActionListener(this);
/* 138 */       this.csvTab.csvDetails.cancel.addActionListener(this);
/* 139 */       this.csvTab.unicodeCsvDetails.go.addActionListener(this);
/* 140 */       this.csvTab.unicodeCsvDetails.cancel.addActionListener(this);
/*     */       
/* 142 */       this.pnl.addComponentRE(1, 5, -2.0D, BasePanel.GAP1, 2, 2, this.csvTab.tab);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 147 */       this.pnl.addMessage(this.msgTxt);
/*     */       
/* 149 */       getContentPane().add(this.pnl);
/* 150 */       setResizable(true);
/* 151 */       pack();
/* 152 */       setVisible(true);
/* 153 */       this.csvTab.csvDetails.addReKeyListener(this.keyListner);
/* 154 */       this.csvTab.unicodeCsvDetails.addReKeyListener(this.keyListner);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/* 161 */       finnished((e.getSource() == this.csvTab.csvDetails.go) || (e.getSource() == this.csvTab.unicodeCsvDetails.go));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     private void finnished(boolean isOk)
/*     */     {
/* 168 */       this.csvTab.csvDetails.go.removeActionListener(this);
/* 169 */       this.csvTab.csvDetails.cancel.removeActionListener(this);
/* 170 */       this.csvTab.unicodeCsvDetails.go.removeActionListener(this);
/* 171 */       this.csvTab.unicodeCsvDetails.cancel.removeActionListener(this);
/* 172 */       this.ok = isOk;
/*     */       
/* 174 */       setVisible(false);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/util/csv/GenericCsvReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */