/*     */ package net.sf.RecordEditor.re.util.csv;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.util.List;
/*     */ import javax.swing.table.AbstractTableModel;
/*     */ import net.sf.JRecord.ByteIO.BaseByteTextReader;
/*     */ import net.sf.JRecord.ByteIO.ByteTextReader;
/*     */ import net.sf.JRecord.ByteIO.CsvByteReader;
/*     */ import net.sf.JRecord.Common.Conversion;
/*     */ import net.sf.JRecord.Common.RecordRunTimeException;
/*     */ import net.sf.JRecord.CsvParser.BasicCsvLineParser;
/*     */ import net.sf.JRecord.CsvParser.BinaryCsvParser;
/*     */ import net.sf.JRecord.CsvParser.CsvDefinition;
/*     */ import net.sf.JRecord.CsvParser.ICsvLineParser;
/*     */ import net.sf.JRecord.CsvParser.ParserManager;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CsvSelectionTblMdl
/*     */   extends AbstractTableModel
/*     */   implements AbstractCsvTblMdl
/*     */ {
/*     */   private static final int LINES_TO_READ = 60;
/*  30 */   private int columnCount = 1;
/*  31 */   private int lines2display = 0;
/*  32 */   private byte[][] lines = (byte[][])null;
/*  33 */   private String charset = "";
/*  34 */   private String seperator = "";
/*     */   private byte sepByte;
/*  36 */   private String quote = "";
/*     */   private ParserManager parserManager;
/*  38 */   private int parserType = 0;
/*     */   
/*  40 */   private int lines2hide = 0;
/*     */   
/*  42 */   private String[] columnNames = null;
/*     */   
/*     */   private boolean namesOnLine;
/*  45 */   private int lineNoFieldNames = 1;
/*     */   
/*  47 */   private byte[] data = null;
/*     */   private boolean embeddedCr;
/*     */   
/*     */   public CsvSelectionTblMdl()
/*     */   {
/*  52 */     this(ParserManager.getInstance());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CsvSelectionTblMdl(ParserManager theParserManager)
/*     */   {
/*  61 */     this.parserManager = theParserManager;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getColumnName(int col)
/*     */   {
/*  69 */     if ((!this.namesOnLine) || (this.columnNames == null) || (col >= this.columnNames.length) || (this.columnNames[col] == null) || ("".equals(this.columnNames[col])))
/*     */     {
/*     */ 
/*  72 */       return super.getColumnName(col);
/*     */     }
/*  74 */     return this.columnNames[col];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setupColumnCount()
/*     */   {
/*  83 */     String sep = this.seperator;
/*     */     
/*  85 */     this.columnCount = 1;
/*  86 */     if (isBinSeperator()) {
/*  87 */       for (int i = this.lines2hide; i < this.lines2display; i++) {
/*  88 */         this.columnCount = Math.max(this.columnCount, new BinaryCsvParser(this.sepByte).countTokens(this.lines[i]));
/*     */       }
/*     */     }
/*     */     else {
/*  92 */       BasicCsvLineParser parser = new BasicCsvLineParser(false);
/*  93 */       CsvDefinition csvDef = new CsvDefinition(sep, this.quote);
/*  94 */       for (int i = this.lines2hide; i < this.lines2display; i++) {
/*  95 */         this.columnCount = Math.max(this.columnCount, parser.getFieldCount(getLine(i), csvDef));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ICsvLineParser getParser()
/*     */   {
/* 107 */     return this.parserManager.get(this.parserType);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColumnCount()
/*     */   {
/* 116 */     return this.columnCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRowCount()
/*     */   {
/* 124 */     return this.lines2display - this.lines2hide;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getValueAt(int rowIndex, int columnIndex)
/*     */   {
/* 133 */     String s = "";
/* 134 */     if ((rowIndex < this.lines2display - this.lines2hide) && (columnIndex < this.columnCount))
/*     */     {
/* 136 */       if (isBinSeperator()) {
/* 137 */         s = new BinaryCsvParser(this.seperator).getValue(this.lines[(rowIndex + this.lines2hide)], columnIndex + 1, this.charset);
/*     */       }
/*     */       else {
/* 140 */         s = getParser().getField(columnIndex, getLine(rowIndex + this.lines2hide), new CsvDefinition(this.seperator, this.quote));
/*     */       }
/*     */     }
/*     */     
/* 144 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLines2display()
/*     */   {
/* 152 */     return this.lines2display;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLines2display(int lines2display)
/*     */   {
/* 160 */     this.lines2display = lines2display;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getLine(int idx)
/*     */   {
/* 175 */     return Conversion.toString(this.lines[idx], this.charset);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[][] getLines()
/*     */   {
/* 183 */     return this.lines;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDataFont(byte[] data, String font, boolean embeddedCr)
/*     */   {
/* 192 */     this.data = data;
/* 193 */     this.charset = font;
/* 194 */     this.embeddedCr = embeddedCr;
/*     */     
/* 196 */     readData();
/*     */   }
/*     */   
/*     */   private void readData() {
/* 200 */     if (this.data != null) {
/* 201 */       this.lines = new byte[60][];
/* 202 */       int i = 0;
/* 203 */       InputStream in = new ByteArrayInputStream(this.data);
/* 204 */       String quoteEsc = this.quote + this.quote;
/*     */       
/*     */       BaseByteTextReader r;
/*     */       
/*     */       BaseByteTextReader r;
/* 209 */       if (this.embeddedCr) {
/* 210 */         r = new CsvByteReader(this.charset, this.seperator, this.quote, quoteEsc, this.namesOnLine);
/*     */       } else {
/* 212 */         r = new ByteTextReader(this.charset);
/*     */       }
/*     */       try
/*     */       {
/* 216 */         r.open(in);
/*     */         byte[] b;
/* 218 */         while ((i < this.lines.length) && ((b = r.read()) != null)) {
/* 219 */           this.lines[(i++)] = b;
/*     */         }
/* 221 */         r.close();
/*     */       } catch (Exception e) {
/* 223 */         Common.logMsg(30, "Error loading CSV Preview:", e.toString(), null);
/* 224 */         e.printStackTrace();
/*     */       }
/*     */       
/* 227 */       this.lines2display = Math.max(0, i - 1);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getLinesString()
/*     */   {
/* 237 */     throw new RecordRunTimeException("Not Implemented");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLines(String[] lines)
/*     */   {
/* 245 */     throw new RecordRunTimeException("Not Implemented");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLines(byte[][] lines, String font)
/*     */   {
/* 253 */     this.charset = font;
/* 254 */     this.lines = lines;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getParserType()
/*     */   {
/* 263 */     return this.parserType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParserType(int parserType)
/*     */   {
/* 271 */     this.parserType = parserType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setQuote(String quote)
/*     */   {
/* 279 */     this.quote = quote;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEmbedded(boolean newEmbedded)
/*     */   {
/* 287 */     this.embeddedCr = newEmbedded;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFont(String font)
/*     */   {
/* 296 */     if (!this.charset.equals(font)) {
/* 297 */       this.charset = font;
/* 298 */       readData();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSeperator(String newSeperator)
/*     */   {
/* 308 */     this.seperator = newSeperator;
/*     */     
/* 310 */     if (isBinSeperator()) {
/*     */       try {
/* 312 */         this.sepByte = Conversion.getByteFromHexString(this.seperator);
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHideFirstLine(boolean hide)
/*     */   {
/* 325 */     this.columnNames = null;
/* 326 */     this.namesOnLine = hide;
/*     */     
/* 328 */     setupColumnNames();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFieldLineNo(int lineNo)
/*     */   {
/* 338 */     this.lineNoFieldNames = lineNo;
/* 339 */     setupColumnNames();
/*     */   }
/*     */   
/*     */ 
/*     */   private void setupColumnNames()
/*     */   {
/* 345 */     this.lines2hide = 0;
/* 346 */     if ((this.namesOnLine) && (this.lines[0].length >= this.lineNoFieldNames))
/*     */     {
/*     */ 
/* 349 */       if (this.lineNoFieldNames == 1) {
/* 350 */         this.lines2hide = 1;
/*     */       }
/* 352 */       if (isBinSeperator()) {
/* 353 */         BinaryCsvParser bParser = new BinaryCsvParser(this.seperator);
/* 354 */         this.columnNames = new String[bParser.countTokens(this.lines[(this.lineNoFieldNames - 1)])];
/* 355 */         for (int i = 0; i < this.columnNames.length; i++) {
/* 356 */           this.columnNames[i] = bParser.getValue(this.lines[(this.lineNoFieldNames - 1)], i + 1, this.charset);
/*     */         }
/*     */       } else {
/* 359 */         ICsvLineParser p = this.parserManager.get(this.parserType);
/* 360 */         List<String> colnames = p.getColumnNames(getLine(this.lineNoFieldNames - 1), new CsvDefinition(this.seperator, this.quote));
/* 361 */         this.columnNames = new String[colnames.size()];
/* 362 */         this.columnNames = ((String[])colnames.toArray(this.columnNames));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CsvAnalyser getAnalyser(int option)
/*     */   {
/* 374 */     if (option == 1) {
/* 375 */       return new CsvAnalyser(getLines(), getLines2display(), this.charset, this.embeddedCr);
/*     */     }
/*     */     
/* 378 */     byte b = this.sepByte;
/* 379 */     if ((this.seperator != null) && (this.seperator.length() > 0) && (!isBinSeperator()))
/*     */     {
/*     */ 
/* 382 */       b = this.seperator.getBytes()[0];
/*     */     }
/* 384 */     return new CsvAnalyser(getLines(), getLines2display(), this.charset, b, this.embeddedCr);
/*     */   }
/*     */   
/*     */   private boolean isBinSeperator() {
/* 388 */     return (this.seperator != null) && (this.seperator.toLowerCase().startsWith("x'"));
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/util/csv/CsvSelectionTblMdl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */