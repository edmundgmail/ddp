/*     */ package net.sf.RecordEditor.re.util.csv;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.util.List;
/*     */ import javax.swing.table.AbstractTableModel;
/*     */ import net.sf.JRecord.ByteIO.BaseByteTextReader;
/*     */ import net.sf.JRecord.ByteIO.ByteTextReader;
/*     */ import net.sf.JRecord.ByteIO.CsvByteReader;
/*     */ import net.sf.JRecord.Common.Conversion;
/*     */ import net.sf.JRecord.Common.RecordRunTimeException;
/*     */ import net.sf.JRecord.CsvParser.BasicCsvLineParser;
/*     */ import net.sf.JRecord.CsvParser.CsvDefinition;
/*     */ import net.sf.JRecord.CsvParser.ICsvLineParser;
/*     */ import net.sf.JRecord.CsvParser.ParserManager;
/*     */ import net.sf.JRecord.charIO.CsvCharReader;
/*     */ import net.sf.JRecord.charIO.ICharReader;
/*     */ import net.sf.JRecord.charIO.StandardCharReader;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CsvSelectionStringTblMdl
/*     */   extends AbstractTableModel
/*     */   implements AbstractCsvTblMdl
/*     */ {
/*     */   private static final int LINES_TO_READ = 60;
/*     */   private byte[] data;
/*  33 */   private int columnCount = 1;
/*  34 */   private int lines2display = 0;
/*  35 */   private String[] lines = null;
/*  36 */   private String seperator = "";
/*  37 */   private String quote = "";
/*  38 */   private String charset = "";
/*     */   private ParserManager parserManager;
/*  40 */   private int parserType = 0;
/*     */   
/*     */   private boolean namesOnLine;
/*     */   private boolean embeddedCr;
/*  44 */   private int lineNoFieldNames = 1;
/*     */   
/*  46 */   private int lines2hide = 0;
/*     */   
/*  48 */   private String[] columnNames = null;
/*     */   
/*     */   public CsvSelectionStringTblMdl()
/*     */   {
/*  52 */     this(ParserManager.getInstance());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public CsvSelectionStringTblMdl(ParserManager theParserManager)
/*     */   {
/*  60 */     this.parserManager = theParserManager;
/*     */   }
/*     */   
/*     */   public String getLine(int idx)
/*     */   {
/*  65 */     return this.lines[idx];
/*     */   }
/*     */   
/*     */   public byte[][] getLines()
/*     */   {
/*  70 */     throw new RecordRunTimeException("Not Implemented");
/*     */   }
/*     */   
/*     */   public String[] getLinesString()
/*     */   {
/*  75 */     return this.lines;
/*     */   }
/*     */   
/*     */   public int getLines2display()
/*     */   {
/*  80 */     return this.lines2display;
/*     */   }
/*     */   
/*     */   public int getParserType()
/*     */   {
/*  85 */     return this.parserType;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setHideFirstLine(boolean hide)
/*     */   {
/*  91 */     this.columnNames = null;
/*  92 */     this.namesOnLine = hide;
/*     */     
/*  94 */     setupColumnNames();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFieldLineNo(int lineNo)
/*     */   {
/* 104 */     this.lineNoFieldNames = lineNo;
/* 105 */     setupColumnNames();
/*     */   }
/*     */   
/*     */ 
/*     */   private void setupColumnNames()
/*     */   {
/* 111 */     this.lines2hide = 0;
/* 112 */     if ((this.namesOnLine) && (this.lines[0].length() >= this.lineNoFieldNames)) {
/* 113 */       if (this.lineNoFieldNames == 1) {
/* 114 */         this.lines2hide = 1;
/*     */       }
/*     */       
/* 117 */       ICsvLineParser p = this.parserManager.get(this.parserType);
/* 118 */       List<String> colnames = p.getColumnNames(getLine(this.lineNoFieldNames - 1), new CsvDefinition(this.seperator, this.quote, this.embeddedCr));
/*     */       
/* 120 */       this.columnNames = new String[colnames.size()];
/* 121 */       this.columnNames = ((String[])colnames.toArray(this.columnNames));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void setLines(byte[][] lines, String font)
/*     */   {
/* 128 */     throw new RecordRunTimeException("Not Implemented");
/*     */   }
/*     */   
/*     */   public void setLines(String[] lines)
/*     */   {
/* 133 */     this.lines = lines;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLines2display(int lines2display)
/*     */   {
/* 144 */     this.lines2display = lines2display;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setParserType(int parserType)
/*     */   {
/* 150 */     this.parserType = parserType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFont(String font)
/*     */   {
/* 158 */     if (!this.charset.equals(font)) {
/* 159 */       this.charset = font;
/* 160 */       readData();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDataFont(byte[] data, String font, boolean embeddedCr)
/*     */   {
/* 171 */     this.data = data;
/* 172 */     this.charset = font;
/* 173 */     this.embeddedCr = embeddedCr;
/*     */     
/* 175 */     readData();
/*     */   }
/*     */   
/*     */   public void setQuote(String quote)
/*     */   {
/* 180 */     this.quote = quote;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEmbedded(boolean newEmbedded)
/*     */   {
/* 188 */     this.embeddedCr = newEmbedded;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSeperator(String newSeperator)
/*     */   {
/* 196 */     this.seperator = newSeperator;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setupColumnCount()
/*     */   {
/* 202 */     String sep = this.seperator;
/* 203 */     BasicCsvLineParser parser = new BasicCsvLineParser(false);
/*     */     
/* 205 */     this.columnCount = 1;
/* 206 */     CsvDefinition csvDef = new CsvDefinition(sep, this.quote, this.embeddedCr);
/* 207 */     for (int i = 0; i < this.lines2display; i++) {
/* 208 */       this.columnCount = Math.max(this.columnCount, parser.getFieldCount(this.lines[i], csvDef));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getColumnName(int col)
/*     */   {
/* 218 */     if ((!this.namesOnLine) || (this.columnNames == null) || (col >= this.columnNames.length) || (this.columnNames[col] == null) || ("".equals(this.columnNames[col])))
/*     */     {
/*     */ 
/* 221 */       return super.getColumnName(col);
/*     */     }
/* 223 */     return this.columnNames[col];
/*     */   }
/*     */   
/*     */   public int getColumnCount()
/*     */   {
/* 228 */     return this.columnCount;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getRowCount()
/*     */   {
/* 234 */     return this.lines2display - this.lines2hide;
/*     */   }
/*     */   
/*     */   public Object getValueAt(int rowIndex, int columnIndex)
/*     */   {
/* 239 */     String s = "";
/* 240 */     if ((rowIndex < this.lines2display - this.lines2hide) && (columnIndex < this.columnCount))
/*     */     {
/* 242 */       ICsvLineParser p = getParser();
/* 243 */       s = p.getField(columnIndex, this.lines[(rowIndex + this.lines2hide)], new CsvDefinition(this.seperator, this.quote, this.embeddedCr));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 249 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CsvAnalyser getAnalyser(int option)
/*     */   {
/* 260 */     if (option == 1) {
/* 261 */       return new CsvAnalyser(this.lines, getLines2display(), this.charset, this.embeddedCr);
/*     */     }
/*     */     
/* 264 */     char b = ',';
/* 265 */     if ((this.seperator != null) && (this.seperator.length() > 0))
/*     */     {
/* 267 */       b = this.seperator.charAt(0);
/*     */     }
/* 269 */     return new CsvAnalyser(this.lines, getLines2display(), this.charset, b, this.embeddedCr);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ICsvLineParser getParser()
/*     */   {
/* 279 */     return this.parserManager.get(this.parserType);
/*     */   }
/*     */   
/*     */   private void readData()
/*     */   {
/* 284 */     if (this.data != null) {
/* 285 */       this.lines = new String[60];
/* 286 */       int i = 0;
/* 287 */       InputStream in = new ByteArrayInputStream(this.data);
/* 288 */       String quoteEsc = this.quote + this.quote;
/* 289 */       if (Conversion.isMultiByte(this.charset)) {
/*     */         ICharReader r;
/*     */         ICharReader r;
/* 292 */         if (this.embeddedCr) {
/* 293 */           r = new CsvCharReader(this.seperator, this.quote, quoteEsc, this.namesOnLine);
/*     */         } else {
/* 295 */           r = new StandardCharReader();
/*     */         }
/*     */         try
/*     */         {
/* 299 */           r.open(in, this.charset);
/*     */           
/* 301 */           while ((i < this.lines.length) && ((this.lines[i] = r.read()) != null)) {
/* 302 */             i++;
/*     */           }
/* 304 */           r.close();
/*     */         } catch (Exception e) {
/* 306 */           Common.logMsg(30, "Error loading CSV Preview:", e.toString(), null);
/* 307 */           e.printStackTrace();
/*     */         }
/*     */       }
/*     */       else {
/*     */         BaseByteTextReader r;
/*     */         BaseByteTextReader r;
/* 313 */         if (this.embeddedCr) {
/* 314 */           r = new CsvByteReader(this.charset, this.seperator, this.quote, quoteEsc, this.namesOnLine);
/*     */         } else {
/* 316 */           r = new ByteTextReader(this.charset);
/*     */         }
/*     */         try
/*     */         {
/* 320 */           r.open(in);
/*     */           byte[] b;
/* 322 */           while ((i < this.lines.length) && ((b = r.read()) != null)) {
/* 323 */             this.lines[(i++)] = Conversion.toString(b, this.charset);
/*     */           }
/* 325 */           r.close();
/*     */         } catch (Exception e) {
/* 327 */           Common.logMsg(30, "Error loading CSV Preview:", e.toString(), null);
/* 328 */           e.printStackTrace();
/*     */         }
/*     */       }
/*     */       
/* 332 */       this.lines2display = i;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/util/csv/CsvSelectionStringTblMdl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */