/*    */ package net.sf.RecordEditor.re.util.csv;
/*    */ 
/*    */ import java.nio.charset.Charset;
/*    */ import net.sf.JRecord.Common.Conversion;
/*    */ import org.mozilla.intl.chardet.nsDetector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CheckEncoding
/*    */ {
/*    */   public static CharsetDetails determineCharSet(byte[] bytes, boolean returnLikelyCharsets)
/*    */   {
/* 19 */     String s = "";
/* 20 */     nsDetector det = new nsDetector();
/* 21 */     boolean possibleUtf16 = utf16Check(bytes);
/* 22 */     boolean possibleEBCDIC = (bytes != null) && (bytes.length > 50) && (BasicCharsetChecker.getValidCharsRatio(Conversion.toString(bytes, "cp037")) > 0.8D);
/* 23 */     String[] charSets = null;
/*    */     
/* 25 */     if ((returnLikelyCharsets) || (possibleUtf16) || (possibleEBCDIC) || (utfCheck(bytes)) || (!det.isAscii(bytes, bytes.length)))
/*    */     {
/* 27 */       det.DoIt(bytes, bytes.length, false);
/* 28 */       det.DataEnd();
/* 29 */       charSets = det.getProbableCharsets();
/* 30 */       if ((charSets != null) && (charSets.length > 0)) {
/* 31 */         s = charSets[0];
/*    */         
/* 33 */         if (Charset.defaultCharset().displayName().equalsIgnoreCase(s)) {
/* 34 */           s = "";
/* 35 */           charSets[0] = "";
/*    */         }
/*    */         String t;
/* 38 */         if (("".equals(s)) && (charSets.length > 1) && (((t = charSets[1].toLowerCase()).startsWith("cp")) || ((t.startsWith("utf")) && (utfCheck(bytes)))))
/*    */         {
/*    */ 
/*    */ 
/* 42 */           s = charSets[1];
/*    */         }
/* 44 */         else if ((possibleUtf16) && (!possibleEBCDIC)) {
/* 45 */           int check = Math.min(5, charSets.length);
/* 46 */           for (int i = 0; i < check; i++) {
/* 47 */             if (charSets[i].toLowerCase().startsWith("utf-16")) {
/* 48 */               s = charSets[i];
/* 49 */               break;
/*    */             }
/*    */           }
/*    */         }
/*    */         
/* 54 */         if (possibleEBCDIC) {
/* 55 */           String[] tmp = new String[charSets.length + 1];
/* 56 */           s = "cp037";
/* 57 */           tmp[0] = s;
/* 58 */           System.arraycopy(charSets, 0, tmp, 1, charSets.length);
/* 59 */           charSets = tmp;
/*    */         }
/* 61 */       } else if (possibleEBCDIC) {
/* 62 */         s = "cp037";
/* 63 */         charSets = new String[] { s, "" };
/*    */       }
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 69 */     return new CharsetDetails(s, charSets);
/*    */   }
/*    */   
/*    */   private static boolean utfCheck(byte[] bytes) {
/* 73 */     return (bytes != null) && (bytes.length > 0) && ((bytes[0] == -1) || (bytes[0] == -2));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private static boolean utf16Check(byte[] bytes)
/*    */   {
/* 83 */     boolean ret = false;
/* 84 */     if ((bytes != null) && (bytes.length > 0)) {
/* 85 */       int count = 0;
/* 86 */       for (int i = 1; i < bytes.length; i++) {
/* 87 */         if ((bytes[i] != 0) && (bytes[(i - 1)] == 0)) {
/* 88 */           count++;
/*    */         }
/*    */       }
/*    */       
/* 92 */       ret = (count > bytes.length * 3 / 8) && (bytes.length > 15);
/*    */     }
/*    */     
/* 95 */     return ret;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/util/csv/CheckEncoding.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */