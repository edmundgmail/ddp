/*     */ package net.sf.RecordEditor.re.util.csv;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.JTree;
/*     */ import javax.swing.JViewport;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import javax.swing.text.JTextComponent;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.LayoutDetail;
/*     */ import net.sf.JRecord.External.ExternalRecord;
/*     */ import net.sf.JRecord.External.RecordEditorXmlLoader;
/*     */ import net.sf.JRecord.IO.AbstractLineReader;
/*     */ import net.sf.JRecord.IO.LineIOProvider;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.re.tree.AbstractLineNodeTreeParser;
/*     */ import net.sf.RecordEditor.re.tree.LineTreeTabelModel;
/*     */ import net.sf.RecordEditor.re.tree.TreeParserXml;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.swing.treeTable.JTreeTable;
/*     */ 
/*     */ public class XmlSelectionPanel
/*     */   extends BaseHelpPanel
/*     */   implements FilePreview
/*     */ {
/*     */   private static final String XML_ID = "XML";
/*  39 */   private static final int MINIMUM_TREE_COLUMN_WIDTH = SwingUtils.STANDARD_FONT_WIDTH * 22;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final String LAYOUT_XML_STR = "<?xml version=\"1.0\" ?><RECORD RECORDNAME=\"XML - Build Layout\" COPYBOOK=\"\" DELIMITER=\"|\" DESCRIPTION=\"XML file, build the layout based on the files contents\" FILESTRUCTURE=\"XML_Build_Layout\" STYLE=\"0\" RECORDTYPE=\"XML\" LIST=\"Y\" QUOTE=\"'\" RecSep=\"default\" LINE_NO_FIELD_NAMES=\"1\"><FIELDS><FIELD NAME=\"Dummy\" DESCRIPTION=\"1 field is Required for the layout to load\" POSITION=\"1\" TYPE=\"Char\"/></FIELDS></RECORD>";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  49 */   private static final byte[] LAYOUT_XML_BYTES = "<?xml version=\"1.0\" ?><RECORD RECORDNAME=\"XML - Build Layout\" COPYBOOK=\"\" DELIMITER=\"|\" DESCRIPTION=\"XML file, build the layout based on the files contents\" FILESTRUCTURE=\"XML_Build_Layout\" STYLE=\"0\" RECORDTYPE=\"XML\" LIST=\"Y\" QUOTE=\"'\" RecSep=\"default\" LINE_NO_FIELD_NAMES=\"1\"><FIELDS><FIELD NAME=\"Dummy\" DESCRIPTION=\"1 field is Required for the layout to load\" POSITION=\"1\" TYPE=\"Char\"/></FIELDS></RECORD>".getBytes();
/*     */   
/*     */   private JTextComponent message;
/*     */   
/*     */   private JTreeTable treeTable;
/*  54 */   private JScrollPane treeTablePane = new JScrollPane();
/*     */   
/*     */   private LineTreeTabelModel model;
/*  57 */   public JButton go = SwingUtils.newButton("Edit");
/*     */   
/*     */   private String headingStr;
/*     */   
/*     */   public XmlSelectionPanel(String heading, JTextComponent msg)
/*     */   {
/*  63 */     this.message = msg;
/*  64 */     this.headingStr = heading;
/*     */     
/*  66 */     layoutScreen();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public BaseHelpPanel getPanel()
/*     */   {
/*  74 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */   public JButton getGoButton()
/*     */   {
/*  80 */     return this.go;
/*     */   }
/*     */   
/*     */   public String getFontName()
/*     */   {
/*  85 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean setData(String filename, byte[] data, boolean checkCharset, String layoutId)
/*     */   {
/*  94 */     ByteArrayInputStream is = new ByteArrayInputStream(data);
/*  95 */     LayoutDetail layout = getLayout("", null);
/*  96 */     LineIOProvider ioProvider = LineIOProvider.getInstance();
/*     */     
/*  98 */     AbstractLineReader<LayoutDetail> reader = ioProvider.getLineReader(layout);
/*     */     
/* 100 */     AbstractLineNodeTreeParser parser = TreeParserXml.getInstance();
/* 101 */     FileView view = new FileView(layout, ioProvider, false);
/*     */     try
/*     */     {
/* 104 */       reader.open(is, layout);
/* 105 */       AbstractLine l; while ((l = reader.read()) != null) {
/* 106 */         view.add(l);
/*     */       }
/*     */       
/*     */ 
/*     */       try
/*     */       {
/* 112 */         reader.close();
/*     */       } catch (IOException e) {
/* 114 */         e.printStackTrace();
/*     */       }
/*     */       
/* 117 */       view.setLayout(reader.getLayout());
/*     */     }
/*     */     catch (Exception e) {}finally
/*     */     {
/*     */       try
/*     */       {
/* 112 */         reader.close();
/*     */       } catch (IOException e) {
/* 114 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 120 */     this.model = new LineTreeTabelModel(view, parser.parse(view), 1, view.getLayout().isMapPresent());
/* 121 */     this.treeTable = new JTreeTable(this.model);
/*     */     
/* 123 */     this.treeTable.setAutoResizeMode(0);
/*     */     
/* 125 */     this.treeTable.putClientProperty("terminateEditOnFocusLost", Boolean.TRUE);
/* 126 */     this.treeTable.getTree().setRootVisible(false);
/* 127 */     this.treeTable.getTree().setShowsRootHandles(true);
/*     */     
/*     */ 
/*     */ 
/* 131 */     removeColumn(0);
/* 132 */     removeColumn(1);
/* 133 */     removeColumn(1);
/*     */     
/*     */ 
/* 136 */     for (int i = 0; (i < this.treeTable.getTree().getRowCount()) && (this.treeTable.getTree().getRowCount() < 50); i++) {
/* 137 */       this.treeTable.getTree().expandRow(i);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 144 */     Common.calcColumnWidths(this.treeTable, 0);
/* 145 */     this.treeTablePane.getViewport().removeAll();
/* 146 */     this.treeTablePane.getViewport().add(this.treeTable);
/* 147 */     doLayout();
/*     */     
/*     */ 
/*     */ 
/* 151 */     TableColumn tc = this.treeTable.getColumnModel().getColumn(0);
/* 152 */     tc.setPreferredWidth(Math.max(tc.getPreferredWidth(), MINIMUM_TREE_COLUMN_WIDTH));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 159 */     return true;
/*     */   }
/*     */   
/*     */   private void removeColumn(int idx) {
/* 163 */     TableColumn tc = this.treeTable.getColumnModel().getColumn(idx);
/* 164 */     if (tc != null) {
/* 165 */       this.treeTable.getColumnModel().removeColumn(tc);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void layoutScreen()
/*     */   {
/* 175 */     if ((this.headingStr != null) && (!"".equals(this.headingStr))) {
/* 176 */       JLabel headingLabel = new JLabel("  " + this.headingStr + "  ");
/* 177 */       Font font = headingLabel.getFont();
/* 178 */       headingLabel.setBackground(Color.WHITE);
/* 179 */       headingLabel.setOpaque(true);
/* 180 */       headingLabel.setFont(new Font(font.getFamily(), 1, font.getSize() + 2));
/*     */       
/* 182 */       addHeadingComponentRE(headingLabel);
/* 183 */       setGapRE(GAP0);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 189 */     addLineRE("", null, this.go);
/*     */     
/*     */ 
/* 192 */     addComponentRE(1, 5, -1.0D, BasePanel.GAP, 2, 2, this.treeTablePane);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 197 */     if (this.message == null) {
/* 198 */       this.message = new JTextField();
/*     */       
/* 200 */       setGapRE(GAP1);
/* 201 */       addMessage(this.message);
/* 202 */       setHeightRE(HEIGHT_1P4);
/*     */     } else {
/* 204 */       super.setMessageRE(this.message);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getSeperator()
/*     */   {
/* 217 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getQuote()
/*     */   {
/* 241 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean setLines(byte[][] newLines, String font, int numberOfLines)
/*     */   {
/* 253 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLines(String[] newLines, String font, int numberOfLines) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColumnCount()
/*     */   {
/* 273 */     return this.treeTable.getColumnCount() - 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getColumnName(int idx)
/*     */   {
/* 280 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LayoutDetail getLayout(String font, byte[] recordSep)
/*     */   {
/* 289 */     LayoutDetail layout = null;
/* 290 */     RecordEditorXmlLoader loader = new RecordEditorXmlLoader();
/* 291 */     ByteArrayInputStream is = new ByteArrayInputStream(LAYOUT_XML_BYTES);
/*     */     try
/*     */     {
/* 294 */       layout = loader.loadCopyBook(is, "Xml Layout").asLayoutDetail();
/* 295 */       is.close();
/*     */     } catch (Exception e) {
/* 297 */       String s = LangConversion.convert("Creation of XML Description Failed");
/* 298 */       this.message.setText(s);
/* 299 */       Common.logMsgRaw(s, null);
/*     */     }
/* 301 */     return layout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFileDescription()
/*     */   {
/* 309 */     String csv = "XML";
/* 310 */     return csv + "~" + "Empty" + "~" + "Empty" + "~" + "Empty" + "~" + "Empty" + "~" + "Empty" + "~" + "Empty" + "~" + "Empty" + "~" + "Empty";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFileDescription(String val) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isMyLayout(String layoutId, String filename, byte[] data)
/*     */   {
/* 348 */     boolean ret = (layoutId != null) && (layoutId.startsWith("XML"));
/* 349 */     if (ret) {
/* 350 */       setData(filename, data, false, layoutId);
/*     */     }
/*     */     
/* 353 */     return ret;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/util/csv/XmlSelectionPanel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */