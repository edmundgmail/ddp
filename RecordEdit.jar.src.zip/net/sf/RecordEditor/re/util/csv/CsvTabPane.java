/*     */ package net.sf.RecordEditor.re.util.csv;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.zip.GZIPInputStream;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JTabbedPane;
/*     */ import javax.swing.text.JTextComponent;
/*     */ import net.sf.JRecord.Common.Conversion;
/*     */ import net.sf.RecordEditor.layoutWizard.FileAnalyser;
/*     */ import net.sf.RecordEditor.re.openFile.FormatFileName;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.common.StreamUtil;
/*     */ import net.sf.RecordEditor.utils.params.BoolOpt;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CsvTabPane
/*     */   implements FormatFileName
/*     */ {
/*     */   private static final int PREVIEW_SIZE = 524288;
/*     */   public static final int NORMAL_CSV = 0;
/*     */   public static final int UNICODE_CSV = 1;
/*     */   public static final int FIXED_FILE = 2;
/*     */   public static final int XML_FILE = 3;
/*     */   public static final int OTHER_FILE = 4;
/*  36 */   private static final byte[][] oneBlankLine = { new byte[0] };
/*     */   
/*     */ 
/*     */ 
/*  40 */   public final JTabbedPane tab = new JTabbedPane();
/*     */   
/*     */   public final CsvSelectionPanel csvDetails;
/*     */   
/*     */   public final CsvSelectionPanel unicodeCsvDetails;
/*     */   
/*     */   public final XmlSelectionPanel xmlSelectionPanel;
/*     */   public final FixedWidthSelection fixedSelectionPanel;
/*     */   public final OtherSelection otherSelectionPanel;
/*     */   private JTextComponent msgFld;
/*  50 */   private FilePreview[] csvPanels = { null, null, null, null, null };
/*     */   
/*     */   private final boolean fixedTab;
/*     */   private final boolean xmlTab;
/*  54 */   private ReFrame parentFrame = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CsvTabPane(JTextComponent msgField, boolean allowNonCsvTabs, boolean adjustableTblHeight)
/*     */   {
/*  63 */     this(msgField, allowNonCsvTabs, allowNonCsvTabs, adjustableTblHeight);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CsvTabPane(JTextComponent msgField, boolean allowFixed, boolean allowXml, boolean adjustableTblHeight)
/*     */   {
/*  73 */     this.msgFld = msgField;
/*  74 */     this.fixedTab = allowFixed;
/*  75 */     this.xmlTab = allowXml;
/*     */     
/*     */ 
/*  78 */     this.csvDetails = new CsvSelectionPanel(oneBlankLine, "", false, "File Preview", msgField, adjustableTblHeight);
/*  79 */     this.unicodeCsvDetails = new CsvSelectionPanel(oneBlankLine[0], "", false, "Unicode File Preview", msgField, adjustableTblHeight);
/*     */     
/*  81 */     this.csvPanels[0] = this.csvDetails;
/*  82 */     this.csvPanels[1] = this.unicodeCsvDetails;
/*     */     
/*  84 */     this.tab.add("Normal", this.csvDetails.getPanel());
/*  85 */     this.tab.add("Unicode", this.unicodeCsvDetails.getPanel());
/*     */     
/*  87 */     if (this.fixedTab) {
/*  88 */       this.fixedSelectionPanel = new FixedWidthSelection(this.msgFld);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*  93 */       this.csvPanels[2] = this.fixedSelectionPanel;
/*  94 */       this.tab.add("Fixed Width", this.csvPanels[2].getPanel());
/*     */     } else {
/*  96 */       this.fixedSelectionPanel = null;
/*     */     }
/*     */     
/*  99 */     if (this.xmlTab) {
/* 100 */       this.xmlSelectionPanel = new XmlSelectionPanel("Xml Preview", this.msgFld);
/* 101 */       this.otherSelectionPanel = new OtherSelection(this.msgFld);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 106 */       this.csvPanels[3] = this.xmlSelectionPanel;
/* 107 */       this.tab.add("Xml", this.csvPanels[3].getPanel());
/* 108 */       this.csvPanels[4] = this.otherSelectionPanel;
/* 109 */       this.tab.add("Other", this.csvPanels[4].getPanel());
/*     */     } else {
/* 111 */       this.xmlSelectionPanel = null;
/* 112 */       this.otherSelectionPanel = null;
/*     */     }
/*     */   }
/*     */   
/*     */   public void readOtherTab(String filename, byte[] data) throws IOException {
/*     */     try {
/* 118 */       switch (this.tab.getSelectedIndex()) {
/*     */       case 0: 
/* 120 */         this.unicodeCsvDetails.setData(filename, data, false, null);
/* 121 */         break;
/*     */       case 1: 
/* 123 */         setNormalCsv(data);
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 127 */       this.msgFld.setText("Only one tab is set: " + e.getMessage());
/* 128 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */   public void readCheckPreview(File f, boolean allowTabSwap, String layoutId)
/*     */   {
/* 134 */     if ((f != null) && (f.isFile())) {
/* 135 */       String fileName = f.getPath();
/* 136 */       if (this.fixedSelectionPanel != null) {
/* 137 */         this.fixedSelectionPanel.setFilename(fileName);
/*     */       }
/*     */       try
/*     */       {
/* 141 */         readCheckPreview(readFile(fileName), allowTabSwap, fileName, layoutId);
/*     */       } catch (IOException ex) {
/* 143 */         Common.logMsg("Error Reading File:", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void readCheckPreview(byte[] data, boolean allowTabSwap, String filename, String layoutId) throws IOException
/*     */   {
/* 150 */     String charSet = CheckEncoding.determineCharSet(data, false).charset;
/* 151 */     boolean couldBeXml = (this.xmlTab) && (maybeXml(data, charSet));
/*     */     
/* 153 */     if (allowTabSwap) {
/* 154 */       if ((layoutId != null) && (filename != null) && (!filename.toLowerCase().endsWith(".csv")))
/*     */       {
/* 156 */         int count = Math.min(this.csvPanels.length, this.tab.getTabCount());
/* 157 */         for (int i = 0; i < count; i++) {
/* 158 */           if ((this.csvPanels[i] != null) && (this.csvPanels[i].isMyLayout(layoutId, filename, data)))
/*     */           {
/*     */ 
/*     */ 
/* 162 */             this.tab.setSelectedIndex(i);
/*     */             
/*     */ 
/* 165 */             return;
/*     */           }
/*     */         }
/*     */       }
/* 169 */       if (this.xmlTab) {
/* 170 */         if (couldBeXml)
/*     */         {
/* 172 */           this.tab.setSelectedIndex(3);
/*     */ 
/*     */ 
/*     */         }
/* 176 */         else if (this.tab.getSelectedIndex() >= 3) {
/* 177 */           this.tab.setSelectedIndex(0);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 182 */       switch (this.tab.getSelectedIndex()) {
/*     */       case 0: 
/*     */       case 1: 
/*     */       case 3: 
/* 186 */         if ((!couldBeXml) && (this.xmlTab) && (Common.OPTIONS.csvSearchFixed.isSelected()) && (FileAnalyser.getTextPct(data, "") < 50) && (FileAnalyser.getTextPct(data, charSet) < 50))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 191 */           this.tab.setSelectedIndex(2);
/*     */         }
/*     */         break;
/*     */       case 2: 
/* 195 */         if ((FileAnalyser.getTextPct(data, "") >= 50) && (FileAnalyser.getTextPct(data, charSet) >= 50))
/*     */         {
/* 197 */           int idx = 1;
/* 198 */           if ("".equals(charSet)) {
/* 199 */             idx = 0;
/*     */           }
/* 201 */           this.tab.setSelectedIndex(idx);
/*     */         }
/*     */         break;
/*     */       }
/*     */       
/*     */     }
/* 207 */     switch (this.tab.getSelectedIndex()) {
/*     */     case 0: 
/* 209 */       if ((allowTabSwap) && (!"".equals(charSet))) {
/* 210 */         this.unicodeCsvDetails.setCharset(charSet);
/* 211 */         this.unicodeCsvDetails.setData(filename, data, false, layoutId);
/*     */         
/* 213 */         checkNormalCsv(data);
/*     */       } else {
/* 215 */         setNormalCsv(data);
/*     */       }
/* 217 */       break;
/*     */     case 1: 
/* 219 */       if ((allowTabSwap) && ("".equals(charSet))) {
/* 220 */         setNormalCsv(data);
/* 221 */         this.tab.setSelectedIndex(0);
/*     */       } else {
/* 223 */         this.unicodeCsvDetails.setCharset(charSet);
/* 224 */         this.unicodeCsvDetails.setData(filename, data, false, layoutId);
/*     */         
/* 226 */         if (allowTabSwap) {
/* 227 */           checkNormalCsv(data);
/*     */         }
/*     */       }
/*     */       
/*     */       break;
/*     */     case 2: 
/* 233 */       this.csvPanels[2].setData(filename, data, false, layoutId);
/*     */       
/* 235 */       break;
/*     */     case 3: 
/* 237 */       if (couldBeXml) {
/* 238 */         this.csvPanels[3].setData(filename, data, false, layoutId);
/*     */         
/* 240 */         if (this.parentFrame != null) {
/* 241 */           this.parentFrame.pack();
/*     */           
/* 243 */           System.out.println("Done pack ....");
/*     */         }
/*     */       } else {
/* 246 */         setNormalCsv(data);
/* 247 */         checkNormalCsv(data);
/*     */       }
/* 249 */       break;
/*     */     case 4: 
/* 251 */       this.otherSelectionPanel.setData(filename, data, false, layoutId);
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean maybeXml(byte[] data, String charSet)
/*     */   {
/* 285 */     byte[] check = Conversion.getBytes("<", charSet);
/* 286 */     if ((data == null) || (data.length < check.length)) { return false;
/*     */     }
/* 288 */     for (int i = 0; i < check.length; i++) {
/* 289 */       if (check[i] != data[i]) {
/* 290 */         return false;
/*     */       }
/*     */     }
/* 293 */     return true;
/*     */   }
/*     */   
/*     */   private void checkNormalCsv(byte[] data) throws IOException {
/* 297 */     if (this.unicodeCsvDetails.getColumnCount() == 1) {
/* 298 */       setNormalCsv(data);
/* 299 */       if (this.csvDetails.getColumnCount() > 1) {
/* 300 */         this.tab.setSelectedIndex(0);
/* 301 */         return;
/*     */       }
/*     */     }
/* 304 */     this.tab.setSelectedIndex(1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setNormalCsv(byte[] data)
/*     */   {
/* 318 */     this.csvDetails.setData("", data, false, "");
/*     */   }
/*     */   
/*     */ 
/*     */   private byte[] readFile(String fileName)
/*     */     throws IOException
/*     */   {
/* 325 */     FileInputStream in = null;
/*     */     byte[] data;
/*     */     try {
/* 328 */       in = new FileInputStream(fileName);
/* 329 */       if (fileName.toLowerCase().endsWith(".gz")) {
/* 330 */         GZIPInputStream inGZip = new GZIPInputStream(in);
/* 331 */         byte[] data = StreamUtil.read(inGZip, 16000);
/* 332 */         inGZip.close();
/*     */       } else {
/* 334 */         data = StreamUtil.read(in, 524288);
/*     */       }
/*     */     } finally {
/* 337 */       if (in != null) {
/* 338 */         in.close();
/*     */       }
/*     */     }
/*     */     
/* 342 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRecordLayout(int layoutId, String layoutName)
/*     */   {
/*     */     try
/*     */     {
/* 361 */       if ((layoutName != null) && (!"".equals(layoutName))) {
/* 362 */         if (layoutName.startsWith("CSV")) {
/* 363 */           this.csvDetails.setFileDescription(layoutName);
/* 364 */           this.tab.setSelectedIndex(0);
/*     */         } else {
/* 366 */           this.unicodeCsvDetails.setFileDescription(layoutName);
/* 367 */           this.tab.setSelectedIndex(1);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String formatLayoutName(String layoutName)
/*     */   {
/* 381 */     return layoutName;
/*     */   }
/*     */   
/*     */   public FilePreview getSelectedCsvDetails() {
/* 385 */     return this.csvPanels[this.tab.getSelectedIndex()];
/*     */   }
/*     */   
/*     */   public void setParentFrame(ReFrame parentFrame) {
/* 389 */     this.parentFrame = parentFrame;
/*     */   }
/*     */   
/*     */   public final void setGoVisible(boolean visible) {
/* 393 */     this.csvDetails.go.setVisible(visible);
/* 394 */     this.unicodeCsvDetails.go.setVisible(visible);
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/util/csv/CsvTabPane.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */