/*     */ package net.sf.RecordEditor.re.util.csv;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import javax.swing.text.JTextComponent;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.LayoutDetail;
/*     */ import net.sf.JRecord.External.CobolCopybookLoader;
/*     */ import net.sf.JRecord.External.CopybookLoader;
/*     */ import net.sf.JRecord.External.ExternalRecord;
/*     */ import net.sf.JRecord.External.RecordEditorXmlLoader;
/*     */ import net.sf.JRecord.IO.AbstractLineReader;
/*     */ import net.sf.JRecord.IO.LineIOProvider;
/*     */ import net.sf.RecordEditor.layoutWizard.Details;
/*     */ import net.sf.RecordEditor.layoutWizard.FileAnalyser;
/*     */ import net.sf.RecordEditor.layoutWizard.WizardFileLayout;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.re.openFile.ComputerOptionCombo;
/*     */ import net.sf.RecordEditor.utils.BasicLayoutCallback;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMainFrame;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.FileSelectCombo;
/*     */ 
/*     */ 
/*     */ public class FixedWidthSelection
/*     */   implements FilePreview, BasicLayoutCallback
/*     */ {
/*     */   private static final String FIXED_ID = "FIXED";
/*  53 */   private BaseHelpPanel pnl = new BaseHelpPanel();
/*     */   
/*  55 */   private FileSelectCombo layoutFile = new FileSelectCombo("SchemaFiles.", 25, true, false);
/*  56 */   private final JLabel dialectLbl = new JLabel("Cobol Dialect");
/*  57 */   private final ComputerOptionCombo dialectCombo = new ComputerOptionCombo();
/*     */   
/*  59 */   private JButton editBtn = SwingUtils.newButton("Edit");
/*     */   
/*  61 */   private JTable fileTable = new JTable();
/*     */   
/*     */   private JTextComponent msg;
/*     */   
/*  65 */   private String fontName = "";
/*  66 */   private String filename = "";
/*     */   private int fileStructure;
/*  68 */   private int recordLength = 100;
/*     */   
/*     */   private byte[] lastData;
/*  71 */   private String lastLayoutFile = null;
/*     */   
/*     */ 
/*     */   public FixedWidthSelection(JTextComponent message)
/*     */   {
/*  76 */     this.msg = message;
/*     */     
/*  78 */     JLabel layoutLbl = new JLabel("Layout File");
/*     */     
/*  80 */     this.fileTable.setAutoResizeMode(0);
/*     */     
/*  82 */     this.layoutFile.setText(Parameters.getFileName("CopybookDirectory"));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  93 */     this.pnl.addLine1to3(layoutLbl).addLine1to3(this.layoutFile).addLine1to3(this.dialectLbl).addLine1to3(this.dialectCombo).setGapRE(BasePanel.GAP1).addComponentRE(1, -99, -2.0D, BasePanel.GAP, 3, 2, this.editBtn);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 103 */     this.pnl.addComponentRE(1, -99, -1.0D, BasePanel.GAP, 2, 2, this.fileTable);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 108 */     this.layoutFile.addTextChangeListner(new ChangeListener() {
/*     */       public void stateChanged(ChangeEvent e) {
/* 110 */         if ((FixedWidthSelection.this.lastLayoutFile == null) || (!FixedWidthSelection.this.lastLayoutFile.equals(FixedWidthSelection.this.layoutFile.getText()))) {
/* 111 */           FixedWidthSelection.this.buildFileLayout(FixedWidthSelection.this.lastData);
/*     */         }
/* 113 */         FixedWidthSelection.this.setCobolVisible();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 124 */     });
/* 125 */     this.dialectCombo.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent e) {
/* 127 */         FixedWidthSelection.this.buildFileLayout(FixedWidthSelection.this.lastData);
/*     */         
/* 129 */         FixedWidthSelection.this.setCobolVisible();
/*     */       }
/*     */       
/* 132 */     });
/* 133 */     setCobolVisible();
/*     */   }
/*     */   
/*     */ 
/*     */   public BaseHelpPanel getPanel()
/*     */   {
/* 139 */     return this.pnl;
/*     */   }
/*     */   
/*     */   public JButton getGoButton()
/*     */   {
/* 144 */     return this.editBtn;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean setData(String filename, byte[] data, boolean checkCharset, String layoutId)
/*     */   {
/* 150 */     if (this.lastData == data) {
/* 151 */       return true;
/*     */     }
/*     */     
/* 154 */     if ((layoutId != null) && (!"".equals(layoutId))) {
/* 155 */       setFileDescription(layoutId);
/*     */     }
/*     */     
/*     */ 
/* 159 */     return buildFileLayout(data);
/*     */   }
/*     */   
/*     */   private boolean buildFileLayout(byte[] data) {
/*     */     try {
/* 164 */       LayoutDetail layout = getLocalLayout(null, data);
/*     */       
/* 166 */       this.lastLayoutFile = this.layoutFile.getText();
/*     */       
/* 168 */       if ((layout == null) && (data != null)) {
/* 169 */         FileAnalyser analyser = FileAnalyser.getAnaylser(data, "");
/* 170 */         layout = analyser.getLayoutDetails(true).asLayoutDetail();
/*     */       }
/* 172 */       if (layout == null) {
/* 173 */         System.out.println("No Layout Generated !!!");
/* 174 */         return false;
/*     */       }
/* 176 */       this.fileStructure = layout.getFileStructure();
/* 177 */       this.fontName = layout.getFontName();
/* 178 */       this.recordLength = layout.getMaximumRecordLength();
/*     */       
/* 180 */       ByteArrayInputStream is = new ByteArrayInputStream(data);
/* 181 */       LineIOProvider iop = LineIOProvider.getInstance();
/*     */       
/* 183 */       AbstractLineReader<LayoutDetail> r = iop.getLineReader(this.fileStructure);
/* 184 */       FileView view = new FileView(layout, iop, false);
/*     */       
/* 186 */       int i = 0;
/*     */       
/* 188 */       r.open(is, layout);
/*     */       try { AbstractLine l;
/* 190 */         while ((i++ < 60) && ((l = r.read()) != null)) {
/* 191 */           view.add(l);
/*     */         }
/*     */       }
/*     */       catch (Exception e) {}finally
/*     */       {
/* 196 */         r.close();
/* 197 */         is.close();
/*     */       }
/*     */       
/* 200 */       this.fileTable.setModel(view);
/* 201 */       view.fireTableStructureChanged();
/*     */       
/* 203 */       TableColumnModel tcm = this.fileTable.getColumnModel();
/* 204 */       TableColumn tc = tcm.getColumn(0);
/* 205 */       HeaderRender headerRender = new HeaderRender(null);
/*     */       
/* 207 */       for (i = 2; i < tcm.getColumnCount(); i++) {
/* 208 */         tcm.getColumn(i).setHeaderRenderer(headerRender);
/*     */       }
/* 210 */       if (tc != null) {
/* 211 */         this.fileTable.getColumnModel().removeColumn(tc);
/*     */       }
/* 213 */       r.close();
/* 214 */       is.close();
/*     */     }
/*     */     catch (Exception e) {
/* 217 */       e.printStackTrace();
/* 218 */       return false;
/*     */     }
/*     */     
/* 221 */     this.lastData = data;
/* 222 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getSeperator()
/*     */   {
/* 228 */     return "";
/*     */   }
/*     */   
/*     */   public String getQuote()
/*     */   {
/* 233 */     return "";
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean setLines(byte[][] newLines, String font, int numberOfLines)
/*     */   {
/* 239 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setLines(String[] newLines, String font, int numberOfLines) {}
/*     */   
/*     */ 
/*     */   public int getColumnCount()
/*     */   {
/* 249 */     return this.fileTable.getColumnCount();
/*     */   }
/*     */   
/*     */   public String getColumnName(int idx)
/*     */   {
/* 254 */     return null;
/*     */   }
/*     */   
/*     */   public LayoutDetail getLayout(String font, byte[] recordSep)
/*     */   {
/* 259 */     LayoutDetail l = getLocalLayout(font, null);
/* 260 */     if (l != null) {
/* 261 */       return l;
/*     */     }
/*     */     
/* 264 */     JDialog d = new JDialog(ReMainFrame.getMasterFrame(), true);
/* 265 */     WizardFileLayout wiz = new WizardFileLayout(d, this.filename, this, false, false);
/*     */     
/* 267 */     Details details = (Details)wiz.getWizardDetails();
/* 268 */     details.fileStructure = this.fileStructure;
/* 269 */     details.fontName = font;
/* 270 */     details.recordLength = this.recordLength;
/* 271 */     details.generateFieldNames = true;
/*     */     
/* 273 */     wiz.changePanel(1, false);
/* 274 */     if (wiz.getPanelNumber() == 1) {
/* 275 */       wiz.changePanel(1, false);
/*     */     }
/*     */     
/* 278 */     d.setVisible(true);
/*     */     
/* 280 */     ExternalRecord rec = wiz.getExternalRecord();
/* 281 */     if (rec != null) {
/*     */       try {
/* 283 */         return rec.asLayoutDetail();
/*     */       } catch (Exception e) {
/* 285 */         Common.logMsg(30, "Layout Generation Failed:", e.getMessage(), null);
/*     */       }
/*     */     }
/*     */     
/* 289 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getFileDescription()
/*     */   {
/* 296 */     return "FIXED~" + getStr(this.layoutFile.getText()) + "~" + this.dialectCombo.getSelectedIndex() + "~" + "Empty";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setFileDescription(String val)
/*     */   {
/* 303 */     StringTokenizer tok = new StringTokenizer(val, "~", false);
/*     */     try
/*     */     {
/* 306 */       tok.nextToken();
/* 307 */       this.layoutFile.setText(Parameters.expandVars(getStringTok(tok)));
/* 308 */       this.dialectCombo.setSelectedIndex(getIntTok(tok));
/*     */     }
/*     */     catch (Exception e) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isMyLayout(String layoutId, String filename, byte[] data)
/*     */   {
/* 320 */     boolean ret = (layoutId != null) && (layoutId.startsWith("FIXED"));
/* 321 */     if (ret) {
/* 322 */       setData(filename, data, false, layoutId);
/*     */     }
/*     */     
/* 325 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRecordLayout(int layoutId, String layoutName, String filename)
/*     */   {
/* 335 */     this.layoutFile.setText(layoutName);
/*     */   }
/*     */   
/*     */ 
/*     */   private LayoutDetail getLocalLayout(String font, byte[] data)
/*     */   {
/* 341 */     String layoutFileName = this.layoutFile.getText();
/* 342 */     if (!"".equals(layoutFileName)) {
/* 343 */       File f = new File(layoutFileName);
/*     */       
/* 345 */       if ((f.exists()) && (!f.isDirectory())) {
/*     */         try {
/*     */           CopybookLoader loader;
/* 348 */           if ((isCobol()) && (CobolCopybookLoader.isAvailable())) {
/* 349 */             CopybookLoader loader = new CobolCopybookLoader();
/* 350 */             if (font == null) {
/* 351 */               FileAnalyser analyser = FileAnalyser.getAnaylserNoLengthCheck(this.lastData, "");
/* 352 */               font = analyser.getFontName();
/* 353 */               this.fileStructure = analyser.getFileStructure();
/*     */             }
/*     */           } else {
/* 356 */             loader = new RecordEditorXmlLoader();
/*     */           }
/*     */           
/* 359 */           ExternalRecord rec = loader.loadCopyBook(layoutFileName, 0, 0, font, this.dialectCombo.getSelectedValue(), 0, Common.getLogger());
/* 360 */           if (this.fileStructure >= 0) {
/* 361 */             rec.setFileStructure(this.fileStructure);
/*     */           }
/* 363 */           return rec.asLayoutDetail();
/*     */         } catch (Exception e) {
/* 365 */           this.msg.setText("Layout Gen failed: " + e.getMessage());
/*     */         }
/*     */       }
/*     */     }
/* 369 */     return null;
/*     */   }
/*     */   
/*     */   private void setCobolVisible() {
/* 373 */     boolean cobol = isCobol();
/* 374 */     this.dialectCombo.setVisible(cobol);
/* 375 */     this.dialectLbl.setVisible(cobol);
/*     */   }
/*     */   
/*     */   private boolean isCobol() {
/* 379 */     boolean ret = false;
/* 380 */     String layoutFileName = this.layoutFile.getText();
/*     */     
/* 382 */     if ((layoutFileName != null) && (!"".equals(layoutFileName)) && (!layoutFileName.toLowerCase().endsWith(".xml")))
/*     */     {
/*     */ 
/* 385 */       File f = new File(layoutFileName);
/* 386 */       if ((f.exists()) && (!f.isDirectory())) {
/*     */         try {
/* 388 */           BufferedReader r = null;
/*     */           String s;
/*     */           try {
/* 391 */             r = new BufferedReader(new FileReader(f));
/* 392 */             s = r.readLine();
/*     */           } finally {
/* 394 */             if (r != null) {
/* 395 */               r.close();
/*     */             }
/*     */           }
/* 398 */           ret = (s != null) && (!s.trim().startsWith("<"));
/*     */         }
/*     */         catch (IOException e) {}
/*     */       }
/*     */     }
/* 403 */     return ret;
/*     */   }
/*     */   
/*     */   private String getStr(String s)
/*     */   {
/* 408 */     if ((s == null) || ("".equals(s))) {
/* 409 */       s = "Empty";
/*     */     }
/*     */     
/* 412 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */   private String getStringTok(StringTokenizer tok)
/*     */   {
/* 418 */     String s = tok.nextToken();
/* 419 */     if ((s == null) || ("Empty".equals(s))) {
/* 420 */       s = "";
/*     */     }
/* 422 */     return s;
/*     */   }
/*     */   
/*     */   private int getIntTok(StringTokenizer tok) {
/* 426 */     int ret = 0;
/*     */     try {
/* 428 */       ret = Integer.parseInt(tok.nextToken());
/*     */     }
/*     */     catch (Exception e) {}
/*     */     
/* 432 */     return ret;
/*     */   }
/*     */   
/*     */   public String getFontName()
/*     */   {
/* 437 */     return this.fontName;
/*     */   }
/*     */   
/*     */   public void setLayoutFile(String lFile)
/*     */   {
/* 442 */     this.layoutFile.setText(lFile);
/*     */   }
/*     */   
/*     */   public void setFilename(String filename)
/*     */   {
/* 447 */     if (!this.filename.equals(filename)) {
/* 448 */       this.layoutFile.setText("");
/*     */     }
/* 450 */     this.filename = filename;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class HeaderRender
/*     */     extends JPanel
/*     */     implements TableCellRenderer
/*     */   {
/*     */     public Component getTableCellRendererComponent(JTable tbl, Object value, boolean isFldSelected, boolean hasFocus, int row, int column)
/*     */     {
/* 470 */       removeAll();
/* 471 */       setLayout(new GridLayout(2, 1));
/*     */       
/* 473 */       if ((column >= 0) && (value != null))
/*     */       {
/* 475 */         String s = (String)value;
/* 476 */         String first = s;
/* 477 */         String second = "";
/* 478 */         int pos = s.indexOf("|");
/* 479 */         if (pos > 0) {
/* 480 */           first = s.substring(pos + 1);
/* 481 */           second = s.substring(0, pos);
/*     */         }
/* 483 */         JLabel label = new JLabel(first);
/* 484 */         add(label);
/* 485 */         if (!second.equals("")) {
/* 486 */           label = new JLabel(second);
/*     */           
/* 488 */           add(label);
/*     */         }
/*     */       }
/* 491 */       setBorder(BorderFactory.createEtchedBorder());
/*     */       
/* 493 */       return this;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/util/csv/FixedWidthSelection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */