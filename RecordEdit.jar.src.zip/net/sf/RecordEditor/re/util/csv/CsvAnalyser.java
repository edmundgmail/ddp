/*     */ package net.sf.RecordEditor.re.util.csv;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import net.sf.JRecord.Common.Conversion;
/*     */ import net.sf.JRecord.Types.Type;
/*     */ import net.sf.JRecord.Types.TypeManager;
/*     */ import net.sf.RecordEditor.trove.map.hash.TIntObjectHashMap;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CsvAnalyser
/*     */ {
/*     */   public static final int COLUMN_NAMES_YES = 1;
/*     */   public static final int COLUMN_NAMES_NO = 2;
/*     */   public static final int COLUMN_NAMES_MAYBE = 3;
/*  27 */   private static char[] SPECIAL_CHARS = { '~', '@', '#', '$', '%', '^', '*' };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  44 */   private int seperatorIdx = 0;
/*  45 */   private int quoteIdx = 0;
/*  46 */   private int colNamesOnFirstLine = 3;
/*  47 */   private int fieldNameLineNo = 1;
/*  48 */   private int numberOfColumns = 0;
/*  49 */   private int[] colTypes; private int[] textTypes = null;
/*  50 */   private Character specialQuote = null;
/*     */   
/*     */   private String font;
/*     */   
/*  54 */   private ArrayList<ArrayList<String>> listOfLines = null;
/*     */   
/*     */   private double ratio;
/*     */   
/*  58 */   private boolean embeddedCr = false;
/*     */   
/*     */   public CsvAnalyser(byte[][] lines, int numberOfLines, String fontname, boolean embeddedCr) {
/*  61 */     this.font = fontname;
/*  62 */     this.embeddedCr = embeddedCr;
/*     */     
/*  64 */     if (lines != null) {
/*  65 */       int noLines = lines.length;
/*     */       
/*  67 */       if ((numberOfLines >= 0) && (numberOfLines < noLines)) {
/*  68 */         noLines = numberOfLines;
/*     */       }
/*     */       
/*  71 */       byte sep = getSeperatorQuote(lines, noLines);
/*     */       
/*  73 */       this.listOfLines = getList(lines, noLines, sep);
/*     */       
/*  75 */       checkForColNames(this.listOfLines);
/*     */     }
/*     */   }
/*     */   
/*     */   public CsvAnalyser(byte[][] lines, int numberOfLines, String fontname, byte sep, boolean embeddedCr)
/*     */   {
/*  81 */     this.font = fontname;
/*  82 */     this.embeddedCr = embeddedCr;
/*     */     
/*  84 */     if (lines != null) {
/*  85 */       int noLines = lines.length;
/*     */       
/*  87 */       if ((numberOfLines >= 0) && (numberOfLines < noLines)) {
/*  88 */         noLines = numberOfLines;
/*     */       }
/*     */       
/*  91 */       this.listOfLines = getList(lines, noLines, sep);
/*     */       
/*  93 */       checkForColNames(this.listOfLines);
/*     */     }
/*     */   }
/*     */   
/*     */   public CsvAnalyser(String[] lines, int numberOfLines, String fontname, boolean embeddedCr) {
/*  98 */     this.font = fontname;
/*  99 */     this.embeddedCr = embeddedCr;
/*     */     
/* 101 */     if ((lines != null) && (lines.length > 0) && (lines[0] != null)) {
/* 102 */       int noLines = lines.length;
/* 103 */       String s = lines[0];
/*     */       
/* 105 */       if ((numberOfLines >= 0) && (numberOfLines < noLines)) {
/* 106 */         noLines = numberOfLines;
/*     */       }
/*     */       
/* 109 */       this.ratio = BasicCharsetChecker.getValidCharsRatio(s);
/*     */       
/* 111 */       char sep = getSeperatorString(lines, noLines);
/* 112 */       this.listOfLines = getList(lines, noLines, sep);
/*     */       
/* 114 */       checkForColNames(this.listOfLines);
/*     */     }
/*     */   }
/*     */   
/*     */   public CsvAnalyser(String[] lines, int numberOfLines, String fontname, char sep, boolean embeddedCr) {
/* 119 */     this.font = fontname;
/* 120 */     this.embeddedCr = embeddedCr;
/*     */     
/* 122 */     if ((lines != null) && (lines.length > 0) && (lines[0] != null)) {
/* 123 */       int noLines = lines.length;
/* 124 */       String s = lines[0];
/*     */       
/* 126 */       if ((numberOfLines >= 0) && (numberOfLines < noLines)) {
/* 127 */         noLines = numberOfLines;
/*     */       }
/*     */       
/* 130 */       this.ratio = BasicCharsetChecker.getValidCharsRatio(s);
/*     */       
/* 132 */       this.listOfLines = getList(lines, noLines, sep);
/*     */       
/* 134 */       checkForColNames(this.listOfLines);
/*     */     }
/*     */   }
/*     */   
/*     */   private ArrayList<ArrayList<String>> getList(byte[][] lines, int noLines, byte sep) {
/* 139 */     ArrayList<ArrayList<String>> listOfLines = new ArrayList(noLines);
/*     */     
/*     */ 
/*     */ 
/* 143 */     for (int i = 0; i < noLines; i++) {
/* 144 */       int st = 0;
/* 145 */       ArrayList<String> line = new ArrayList();
/*     */       
/* 147 */       if (lines[i] != null) {
/* 148 */         for (int j = 0; j < lines[i].length; j++) {
/* 149 */           if (lines[i][j] == sep) {
/* 150 */             line.add(getField(lines[i], st, j));
/* 151 */             st = j + 1;
/*     */           }
/*     */         }
/* 154 */         line.add(getField(lines[i], st, lines[i].length));
/*     */       }
/*     */       
/* 157 */       listOfLines.add(line);
/*     */     }
/* 159 */     return listOfLines;
/*     */   }
/*     */   
/*     */   private String getField(byte[] line, int st, int en)
/*     */   {
/* 164 */     String ret = "";
/* 165 */     if (en > st) {
/*     */       try {
/* 167 */         ret = Conversion.getString(line, st, en, this.font);
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*     */     
/* 172 */     return ret;
/*     */   }
/*     */   
/*     */   private ArrayList<ArrayList<String>> getList(String[] lines, int noLines, char sep) {
/* 176 */     ArrayList<ArrayList<String>> listOfLines = new ArrayList(noLines);
/*     */     
/*     */ 
/*     */ 
/* 180 */     for (int i = 0; i < noLines; i++) {
/* 181 */       int st = 0;
/* 182 */       ArrayList<String> line = new ArrayList();
/*     */       
/* 184 */       if (lines[i] != null) {
/* 185 */         for (int j = 0; j < lines[i].length(); j++) {
/* 186 */           if (lines[i].charAt(j) == sep) {
/* 187 */             line.add(getField(lines[i], st, j));
/* 188 */             st = j + 1;
/*     */           }
/*     */         }
/* 191 */         line.add(getField(lines[i], st, lines[i].length()));
/*     */       }
/*     */       
/* 194 */       listOfLines.add(line);
/*     */     }
/* 196 */     return listOfLines;
/*     */   }
/*     */   
/*     */   private String getField(String line, int st, int en) {
/* 200 */     String ret = "";
/* 201 */     if (en > st) {
/*     */       try {
/* 203 */         ret = line.substring(st, en);
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*     */     
/* 208 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private char getSeperatorString(String[] lines, int numberOfLines)
/*     */   {
/* 215 */     int[] count = new int[Common.FIELD_SEPARATOR_TEXT_LIST.length];
/* 216 */     char[] sepChars = new char[count.length];
/* 217 */     int spaceIdx = -1;
/* 218 */     if (numberOfLines < 0) {
/* 219 */       numberOfLines = lines.length;
/*     */     }
/*     */     
/* 222 */     for (int i = 0; i < count.length; i++) {
/* 223 */       count[i] = 0;
/* 224 */       sepChars[i] = Common.FIELD_SEPARATOR_LIST1_VALUES[i].charAt(0);
/* 225 */       if (sepChars[i] == ' ') {
/* 226 */         spaceIdx = i;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 231 */     for (i = 0; i < numberOfLines; i++) {
/* 232 */       if (lines[i] != null) {
/* 233 */         String s = lines[i];
/* 234 */         if (s != null) {
/* 235 */           for (int j = 0; j < s.length(); j++) {
/* 236 */             for (int k = 0; k < sepChars.length; k++) {
/* 237 */               if (sepChars[k] == s.charAt(j)) {
/* 238 */                 count[k] += 1;
/* 239 */                 break;
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 247 */     this.seperatorIdx = getSeperatorIdx(count, numberOfLines, spaceIdx);
/*     */     
/*     */ 
/* 250 */     int st = 2;
/* 251 */     char[] quoteChars = new char[Common.QUOTE_LIST.length - st];
/* 252 */     int[] quoteCount = new int[Common.QUOTE_LIST.length - st];
/*     */     
/* 254 */     char sepChar = sepChars[this.seperatorIdx];
/*     */     
/* 256 */     TIntObjectHashMap<Integer> specialCount = new TIntObjectHashMap(SPECIAL_CHARS.length * 2);
/* 257 */     for (char c : SPECIAL_CHARS) {
/* 258 */       specialCount.put(c, Integer.valueOf(0));
/*     */     }
/*     */     
/* 261 */     for (i = st; i < Common.QUOTE_LIST.length; i++) {
/* 262 */       quoteCount[(i - st)] = 0;
/* 263 */       quoteChars[(i - st)] = Common.QUOTE_LIST[i].charAt(0);
/*     */     }
/*     */     
/* 266 */     for (i = 0; i < numberOfLines; i++) {
/* 267 */       if ((lines[i] != null) && (lines[i].length() > 0)) {
/* 268 */         char last = '\000';
/*     */         
/* 270 */         char firstChar = lines[i].charAt(0);
/* 271 */         for (int j = 0; j < lines[i].length() - 1; j++) {
/* 272 */           if ((j == 0) || (j == lines[i].length() - 2) || (lines[i].charAt(j) == sepChar)) {
/* 273 */             for (int k = 0; k < quoteChars.length; k++) {
/* 274 */               if (last == quoteChars[k]) {
/* 275 */                 quoteCount[k] += 1;
/*     */               }
/*     */               
/*     */ 
/* 279 */               if (lines[i].charAt(j + 1) == quoteChars[k]) {
/* 280 */                 quoteCount[k] += 1;
/*     */               }
/*     */               
/* 283 */               if ((firstChar == last) && 
/* 284 */                 (specialCount.containsKey(firstChar))) {
/* 285 */                 specialCount.put(firstChar, Integer.valueOf(((Integer)specialCount.get(firstChar)).intValue() + 1));
/*     */               }
/*     */               
/* 288 */               firstChar = lines[i].charAt(j + 1);
/*     */             }
/*     */           }
/*     */           
/* 292 */           last = lines[i].charAt(j);
/*     */         }
/*     */         
/*     */ 
/* 296 */         if ((firstChar == lines[i].charAt(lines[i].length() - 1)) && 
/* 297 */           (specialCount.containsKey(firstChar))) {
/* 298 */           specialCount.put(firstChar, Integer.valueOf(((Integer)specialCount.get(firstChar)).intValue() + 1));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 305 */     int quoteIdxMax = getMax(quoteCount);
/*     */     
/* 307 */     this.specialQuote = null;
/* 308 */     if ((quoteCount[quoteIdxMax] > 5) || ((this.embeddedCr) && (quoteCount[quoteIdxMax] > 1)))
/*     */     {
/* 310 */       this.quoteIdx = (quoteIdxMax + st);
/*     */     } else {
/* 312 */       setSpecialQuote(lines.length * 2, specialCount);
/*     */     }
/*     */     
/* 315 */     return sepChars[this.seperatorIdx];
/*     */   }
/*     */   
/*     */   private void setSpecialQuote(int compare, TIntObjectHashMap<Integer> specialCount) {
/* 319 */     char cc = '\000';
/* 320 */     int max = -1;
/*     */     
/* 322 */     for (char c : SPECIAL_CHARS) {
/* 323 */       int v = ((Integer)specialCount.get(c)).intValue();
/* 324 */       if ((v > compare) && (v > max)) {
/* 325 */         cc = c;
/* 326 */         max = v;
/*     */       }
/*     */     }
/*     */     
/* 330 */     if (max > 0) {
/* 331 */       this.specialQuote = Character.valueOf(cc);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private byte getSeperatorQuote(byte[][] lines, int numberOfLines)
/*     */   {
/* 340 */     byte[] sepBytes = getSepBytes(this.font);
/*     */     
/* 342 */     String[] sep = Common.FIELD_SEPARATOR_LIST1_VALUES;
/*     */     
/* 344 */     int st = 2;
/* 345 */     byte[][] quoteBytes = new byte[Common.QUOTE_LIST.length - st][];
/* 346 */     int[] quoteCount = new int[Common.QUOTE_LIST.length - st];
/*     */     
/* 348 */     if (numberOfLines < 0) {
/* 349 */       numberOfLines = lines.length;
/*     */     }
/*     */     
/* 352 */     this.seperatorIdx = getSeperatorIndex(lines, numberOfLines, this.font, sepBytes);
/* 353 */     byte sepByte = sepBytes[this.seperatorIdx];
/* 354 */     if (sepByte == 0) {
/*     */       try {
/* 356 */         sepByte = Conversion.getBytes(sep[this.seperatorIdx], "")[0];
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*     */     
/*     */ 
/* 362 */     char[] byteMap = new char['Ā'];
/* 363 */     TIntObjectHashMap<Integer> specialCount = new TIntObjectHashMap(SPECIAL_CHARS.length * 2);
/* 364 */     Arrays.fill(byteMap, '\000');
/* 365 */     byte[] b = Conversion.getBytes(new String(SPECIAL_CHARS), this.font);
/*     */     
/*     */ 
/* 368 */     for (int j = 0; j < SPECIAL_CHARS.length; j++) {
/* 369 */       char c = SPECIAL_CHARS[j];
/* 370 */       specialCount.put(c, Integer.valueOf(0));
/* 371 */       byteMap[(128 + b[j])] = SPECIAL_CHARS[j];
/*     */     }
/*     */     
/*     */ 
/* 375 */     for (int i = st; i < Common.QUOTE_LIST.length; i++) {
/* 376 */       quoteCount[(i - st)] = 0;
/* 377 */       quoteBytes[(i - st)] = Conversion.getBytes(Common.QUOTE_LIST[i], this.font);
/*     */     }
/*     */     
/*     */ 
/* 381 */     for (i = 0; i < numberOfLines; i++) {
/* 382 */       if ((lines[i] != null) && (lines[i].length > 0)) {
/* 383 */         byte firstByte = lines[i][0];
/* 384 */         for (j = 0; j < lines[i].length - 1; j++) {
/* 385 */           if ((j == 0) || (lines[i][j] == sepByte)) {
/* 386 */             for (int k = 0; k < quoteBytes.length; k++) {
/* 387 */               if (equals(lines[i], j - quoteBytes[k].length, quoteBytes[k])) {
/* 388 */                 quoteCount[k] += 1;
/*     */               }
/* 390 */               if (equals(lines[i], j + 1, quoteBytes[k])) {
/* 391 */                 quoteCount[k] += 1;
/*     */               }
/*     */             }
/*     */             
/* 395 */             char c = byteMap[(128 + firstByte)];
/* 396 */             if ((j > 0) && (firstByte == lines[i][(j - 1)]) && (specialCount.contains(c))) {
/* 397 */               specialCount.put(c, Integer.valueOf(((Integer)specialCount.get(c)).intValue() + 1));
/*     */             }
/* 399 */             firstByte = lines[i][(j + 1)];
/*     */           }
/*     */         }
/* 402 */         char c = byteMap[(128 + firstByte)];
/* 403 */         if ((firstByte == lines[i][(j - 1)]) && (specialCount.contains(c))) {
/* 404 */           specialCount.put(c, Integer.valueOf(((Integer)specialCount.get(c)).intValue() + 1));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 409 */     int quoteIdxMax = getMax(quoteCount);
/*     */     
/* 411 */     if ((quoteCount[quoteIdxMax] > 5) || ((this.embeddedCr) && (quoteCount[quoteIdxMax] > 1)))
/*     */     {
/* 413 */       this.quoteIdx = (quoteIdxMax + st);
/*     */     } else {
/* 415 */       setSpecialQuote(lines.length * 2, specialCount);
/*     */     }
/*     */     
/* 418 */     return sepBytes[this.seperatorIdx];
/*     */   }
/*     */   
/*     */   private boolean equals(byte[] line, int pos, byte[] cmp) {
/* 422 */     boolean ret = false;
/* 423 */     if ((pos >= 0) && (pos + cmp.length <= line.length)) {
/* 424 */       ret = true;
/* 425 */       for (int i = 0; (i < cmp.length) && (ret); i++) {
/* 426 */         ret = line[(pos + i)] == cmp[i];
/*     */       }
/*     */     }
/* 429 */     return ret;
/*     */   }
/*     */   
/*     */   public static String getSeperator(byte[][] lines, int numberOfLines, String font)
/*     */   {
/* 434 */     byte[] sepBytes = getSepBytes(font);
/* 435 */     return Common.FIELD_SEPARATOR_LIST1_VALUES[getSeperatorIndex(lines, numberOfLines, font, sepBytes)];
/*     */   }
/*     */   
/*     */   private static byte[] getSepBytes(String font) {
/* 439 */     String[] sep = Common.FIELD_SEPARATOR_LIST1_VALUES;
/* 440 */     byte[] sepBytes = new byte[sep.length];
/* 441 */     for (int k = 0; k < sep.length; k++) {
/* 442 */       sepBytes[k] = 0;
/*     */       try {
/* 444 */         sepBytes[k] = Conversion.getCsvDelimBytes(sep[k], font)[0];
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/* 448 */     return sepBytes;
/*     */   }
/*     */   
/*     */ 
/*     */   public static int getSeperatorIndex(byte[][] lines, int numberOfLines, String font, byte[] sepBytes)
/*     */   {
/* 454 */     int[] count = new int[Common.FIELD_SEPARATOR_LIST1_VALUES.length];
/* 455 */     String[] sep = (String[])Common.FIELD_SEPARATOR_LIST1_VALUES.clone();
/* 456 */     int spaceIdx = -1;
/*     */     
/* 458 */     if (numberOfLines < 0) {
/* 459 */       numberOfLines = lines.length;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 464 */     for (int i = 0; i < count.length; i++) {
/* 465 */       count[i] = 0;
/* 466 */       if (" ".equals(sep[i])) {
/* 467 */         spaceIdx = i;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 472 */     for (i = Math.max(0, numberOfLines - 45); i < numberOfLines; i++) {
/* 473 */       if (lines[i] != null) {
/* 474 */         String s = new String(lines[i]);
/* 475 */         for (int j = 0; j < s.length(); j++) {
/* 476 */           for (int k = 0; k < sep.length; k++) {
/* 477 */             if (sep[k].startsWith("x'")) {
/* 478 */               if (lines[i][j] == sepBytes[k]) {
/* 479 */                 count[k] += 1;
/* 480 */                 break;
/*     */               }
/* 482 */             } else if (sep[k].equals(s.substring(j, j + 1))) {
/* 483 */               count[k] += 1;
/* 484 */               break;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 491 */     return getSeperatorIdx(count, numberOfLines, spaceIdx);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void checkForColNames(ArrayList<ArrayList<String>> lines)
/*     */   {
/* 503 */     this.numberOfColumns = 0;
/* 504 */     for (int i = 1; i < lines.size(); i++) {
/* 505 */       this.numberOfColumns = Math.max(this.numberOfColumns, ((ArrayList)lines.get(i)).size());
/*     */     }
/*     */     
/* 508 */     if ((lines == null) || (lines.size() == 0)) {
/* 509 */       return;
/*     */     }
/* 511 */     int m = Math.min(15, lines.size() - 1);
/*     */     
/* 513 */     while ((this.fieldNameLineNo < m) && ((lines.get(this.fieldNameLineNo - 1) == null) || (getSize((ArrayList)lines.get(this.fieldNameLineNo - 1)) < Math.min(5, this.numberOfColumns - 3))))
/*     */     {
/* 515 */       this.fieldNameLineNo += 1;
/*     */     }
/*     */     
/* 518 */     ArrayList<String> line = (ArrayList)lines.get(this.fieldNameLineNo - 1);
/* 519 */     for (i = 0; i < line.size(); i++) {
/*     */       try {
/* 521 */         Integer.parseInt((String)line.get(i));
/* 522 */         this.colNamesOnFirstLine = 2;
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*     */     
/*     */ 
/* 528 */     if (this.colNamesOnFirstLine != 2)
/*     */     {
/*     */ 
/* 531 */       int limit = (lines.size() - this.fieldNameLineNo) / 3;
/*     */       
/*     */ 
/*     */ 
/* 535 */       this.colTypes = new int[this.numberOfColumns];
/* 536 */       for (int j = 0; j < this.numberOfColumns; j++) {
/* 537 */         int noNums = 0;
/* 538 */         int crCount = 0;
/* 539 */         int htmlCount = 0;
/* 540 */         this.colTypes[j] = 0;
/* 541 */         for (i = this.fieldNameLineNo; i < lines.size(); i++) {
/* 542 */           line = (ArrayList)lines.get(i);
/*     */           
/* 544 */           if (j < line.size()) {
/* 545 */             String fieldValue = (String)line.get(j);
/*     */             try {
/* 547 */               new BigDecimal(fieldValue);
/* 548 */               noNums++;
/*     */             }
/*     */             catch (Exception e) {}
/* 551 */             if ((fieldValue.indexOf('\n') >= 0) || (fieldValue.indexOf('\r') >= 0)) {
/* 552 */               crCount++;
/*     */             }
/* 554 */             if (Conversion.isHtml(fieldValue)) {
/* 555 */               htmlCount++;
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 561 */         if ((noNums > 3) && (noNums > limit)) {
/* 562 */           this.colNamesOnFirstLine = 1;
/* 563 */           this.colTypes[j] = 19;
/* 564 */         } else if (htmlCount > limit) {
/* 565 */           this.colTypes[j] = 119;
/* 566 */         } else if (crCount > 0) {
/* 567 */           this.colTypes[j] = 117;
/*     */         }
/*     */       }
/*     */       
/* 571 */       if (this.colTypes != null) {
/* 572 */         for (int k = 0; (k < this.colTypes.length) && (this.textTypes == null); k++) {
/* 573 */           switch (this.colTypes[k]) {
/*     */           case 117: 
/*     */           case 119: 
/* 576 */             this.textTypes = new int[this.colTypes.length];
/* 577 */             TypeManager typeManager = TypeManager.getInstance();
/*     */             
/* 579 */             for (int j = 0; j < this.textTypes.length; j++) {
/* 580 */               this.textTypes[j] = this.colTypes[j];
/* 581 */               if (typeManager.getType(this.textTypes[j]).isNumeric()) {
/* 582 */                 this.textTypes[j] = 0;
/*     */               }
/*     */             }
/*     */           }
/*     */           
/*     */         }
/*     */       }
/*     */       
/* 590 */       if (lines.size() <= this.fieldNameLineNo + 4) {
/* 591 */         this.colTypes = null;
/*     */       }
/*     */     }
/*     */     
/* 595 */     if (this.quoteIdx == 0)
/*     */     {
/* 597 */       for (i = 0; i < lines.size(); i++) {
/* 598 */         line = (ArrayList)lines.get(i);
/* 599 */         for (int j = 0; j < line.size() - 1; j++) {
/* 600 */           for (int k = 2; k < Common.QUOTE_LIST.length; k++) {
/* 601 */             if ((((String)line.get(j)).startsWith(Common.QUOTE_LIST[k])) && (!((String)line.get(j)).endsWith(Common.QUOTE_LIST[k])))
/*     */             {
/* 603 */               for (int l = j + 1; l < line.size(); l++) {
/* 604 */                 if (((String)line.get(l)).endsWith(Common.QUOTE_LIST[k])) {
/* 605 */                   this.quoteIdx = k;
/* 606 */                   return;
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private int getSize(ArrayList<String> l)
/*     */   {
/* 619 */     int i = l.size() - 1;
/*     */     
/* 621 */     while ((i >= 0) && ((l.get(i) == null) || ("".equals(l.get(i))))) {
/* 622 */       i--;
/*     */     }
/*     */     
/* 625 */     return i + 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static int getSeperatorIdx(int[] array, int lineCount, int spaceIdx)
/*     */   {
/* 632 */     int idxMax = 0;
/* 633 */     int idxMax2 = 0;
/* 634 */     int max = -1;
/* 635 */     int max2 = -1;
/* 636 */     for (int i = 0; i < array.length; i++) {
/* 637 */       if (max < array[i]) {
/* 638 */         max2 = max;
/* 639 */         idxMax2 = idxMax;
/* 640 */         max = array[i];
/* 641 */         idxMax = i;
/* 642 */       } else if (max2 < array[i]) {
/* 643 */         max2 = array[i];
/* 644 */         idxMax2 = i;
/*     */       }
/*     */     }
/*     */     
/* 648 */     if ((idxMax == spaceIdx) && (array[idxMax2] >= lineCount * 2)) {
/* 649 */       idxMax = idxMax2;
/*     */     }
/*     */     
/* 652 */     return idxMax;
/*     */   }
/*     */   
/*     */ 
/*     */   private static int getMax(int[] array)
/*     */   {
/* 658 */     int idxMax = 0;
/* 659 */     int max = -1;
/* 660 */     for (int i = 0; i < array.length; i++) {
/* 661 */       if (max < array[i]) {
/* 662 */         max = array[i];
/* 663 */         idxMax = i;
/*     */       }
/*     */     }
/*     */     
/* 667 */     return idxMax;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getSeperatorIdx()
/*     */   {
/* 674 */     return this.seperatorIdx;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getQuoteIdx()
/*     */   {
/* 681 */     return this.quoteIdx;
/*     */   }
/*     */   
/*     */   public final Character getSpecialQuote() {
/* 685 */     return this.specialQuote;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getColNamesOnFirstLine()
/*     */   {
/* 692 */     return this.colNamesOnFirstLine;
/*     */   }
/*     */   
/*     */   public int getFieldNameLineNo() {
/* 696 */     return this.fieldNameLineNo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getNumberOfColumns()
/*     */   {
/* 703 */     return this.numberOfColumns;
/*     */   }
/*     */   
/*     */   public int[] getTypes()
/*     */   {
/* 708 */     int[] ret = null;
/* 709 */     if ((this.colNamesOnFirstLine != 3) && (this.colTypes != null)) {
/* 710 */       ret = (int[])this.colTypes.clone();
/*     */     }
/*     */     
/* 713 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */   public int[] getTextTypes()
/*     */   {
/* 719 */     if (this.textTypes != null) {
/* 720 */       return (int[])this.textTypes.clone();
/*     */     }
/*     */     
/* 723 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isValidChars()
/*     */   {
/* 730 */     return this.ratio > 0.75D;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/util/csv/CsvAnalyser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */