/*     */ package net.sf.RecordEditor.re.util;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import net.sf.JRecord.Types.Type;
/*     */ import net.sf.JRecord.Types.TypeChar;
/*     */ import net.sf.JRecord.Types.TypeCommaDecimalPoint;
/*     */ import net.sf.JRecord.Types.TypeManager;
/*     */ import net.sf.JRecord.Types.TypeNum;
/*     */ import net.sf.RecordEditor.re.jrecord.types.TypeDateWrapper;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.swing.AbsRowList;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.TreeComboItem;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.TreeComboRendor;
/*     */ 
/*     */ public class BuildTypeComboList
/*     */ {
/*  19 */   private static int VALID_IDX = 3;
/*     */   
/*     */   public static TreeComboRendor getTreeComboRender(TreeComboItem[] items) {
/*  22 */     return new TreeComboRendor(items);
/*     */   }
/*     */   
/*     */   public static TreeComboItem[] getList(AbsRowList typeList)
/*     */   {
/*  27 */     TypeManager m = TypeManager.getInstance();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  35 */     ArrayList<MenuDtls> subMenus = new ArrayList();
/*     */     
/*  37 */     MenuDtls charTypes = new MenuDtls("", new ArrayList());
/*     */     
/*  39 */     MenuDtls numericTypes = new MenuDtls("Numeric Types", subMenus);
/*  40 */     MenuDtls binTypes = new MenuDtls("Binary Numeric Types", subMenus);
/*  41 */     MenuDtls leftJustifiedTypes = new MenuDtls("Left Justified Numeric Types", subMenus);
/*  42 */     MenuDtls spacePaddedTypes = new MenuDtls("Right Justified Space padded Types", subMenus);
/*  43 */     MenuDtls commaDecimalTypes = new MenuDtls("Numeric Decimal point=','", subMenus);
/*     */     
/*  45 */     MenuDtls dateTypes = new MenuDtls("Date Types", subMenus);
/*  46 */     MenuDtls checkBoxTypes = new MenuDtls("Checkbox Types", subMenus);
/*  47 */     MenuDtls specialTypes = new MenuDtls("Special Char Types", subMenus);
/*  48 */     MenuDtls userTypes = new MenuDtls("locally defined Types", subMenus);
/*     */     
/*     */ 
/*     */ 
/*  52 */     String foreignLookUpId = Common.getTblLookupKey(1);
/*     */     
/*     */ 
/*  55 */     for (int i = 0; i < typeList.getSize(); i++) {
/*  56 */       int key = ((Integer)typeList.getKeyAt(i)).intValue();
/*  57 */       Object fld = typeList.getFieldAt(i);
/*  58 */       Object valid = typeList.getFieldAt(i, VALID_IDX);
/*  59 */       String s = "";
/*  60 */       if ((key == 100) || (key == 0)) {
/*  61 */         System.out.println();
/*     */       }
/*  63 */       if (fld != null) {
/*  64 */         s = fld.toString();
/*     */       }
/*     */       
/*  67 */       Type t = m.getType(key);
/*  68 */       if ((t != null) && ((valid == null) || (Boolean.TRUE.equals(valid)) || ("".equals(valid)))) {
/*  69 */         TreeComboItem tc = new TreeComboItem(Integer.valueOf(key), LangConversion.convertId(12, foreignLookUpId + key, s), s, false);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  79 */         if (key >= 1000) {
/*  80 */           if ((t instanceof TypeDateWrapper)) {
/*  81 */             dateTypes.add(tc);
/*     */           } else {
/*  83 */             userTypes.add(tc);
/*     */           }
/*     */         } else {
/*  86 */           switch (key) {
/*     */           case 2: 
/*     */           case 3: 
/*     */           case 51: 
/*     */           case 81: 
/*     */           case 92: 
/*     */           case 115: 
/*     */           case 116: 
/*     */           case 117: 
/*     */           case 118: 
/*  96 */             specialTypes.add(tc);
/*  97 */             break;
/*     */           case 32: 
/*     */           case 41: 
/* 100 */             numericTypes.add(tc);
/* 101 */             break;
/*     */           case 109: 
/*     */           case 110: 
/*     */           case 111: 
/*     */           case 112: 
/*     */           case 114: 
/* 107 */             checkBoxTypes.add(tc);
/* 108 */             break;
/*     */           default: 
/* 110 */             if ((t instanceof TypeDateWrapper)) {
/* 111 */               dateTypes.add(tc);
/* 112 */             } else if (!s.startsWith("Date ")) {
/* 113 */               if (t.isNumeric()) {
/* 114 */                 if (t.isBinary()) {
/* 115 */                   binTypes.add(tc);
/* 116 */                 } else if ((t instanceof TypeCommaDecimalPoint)) {
/* 117 */                   commaDecimalTypes.add(tc);
/* 118 */                 } else if (((t instanceof TypeChar)) && (((TypeChar)t).isLeftJustified())) {
/* 119 */                   leftJustifiedTypes.add(tc);
/* 120 */                 } else if (((t instanceof TypeNum)) && (" ".equals(((TypeNum)t).getPadChar()))) {
/* 121 */                   spacePaddedTypes.add(tc);
/*     */                 } else {
/* 123 */                   numericTypes.add(tc);
/*     */                 }
/*     */               } else
/* 126 */                 charTypes.add(tc);
/*     */             }
/*     */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 133 */     int comboSize = charTypes.items.size();
/*     */     
/* 135 */     for (MenuDtls menu : subMenus) {
/* 136 */       if (menu.items.size() > 0) {
/* 137 */         comboSize++;
/*     */       }
/*     */     }
/* 140 */     TreeComboItem[] ret = new TreeComboItem[comboSize];
/* 141 */     int idx = 0;
/* 142 */     int k = 16121;
/*     */     
/* 144 */     for (MenuDtls menu : subMenus) {
/* 145 */       if (menu.items.size() > 0) {
/* 146 */         ret[(idx++)] = bldMenu(k++, menu.name, menu.items);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 163 */     for (TreeComboItem c : charTypes.items) {
/* 164 */       ret[(idx++)] = c;
/*     */     }
/*     */     
/* 167 */     return ret;
/*     */   }
/*     */   
/*     */   private static TreeComboItem bldMenu(int key, String name, ArrayList<TreeComboItem> items)
/*     */   {
/* 172 */     TreeComboItem[] itms = new TreeComboItem[items.size()];
/* 173 */     itms = (TreeComboItem[])items.toArray(itms);
/*     */     
/* 175 */     return new TreeComboItem(Integer.valueOf(key), name, LangConversion.convert(10, name), itms);
/*     */   }
/*     */   
/*     */   private static class MenuDtls
/*     */   {
/* 180 */     final ArrayList<TreeComboItem> items = new ArrayList();
/*     */     
/*     */     final String name;
/*     */     
/*     */     public MenuDtls(String name, ArrayList<MenuDtls> dtls)
/*     */     {
/* 186 */       this.name = name;
/* 187 */       dtls.add(this);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean add(TreeComboItem e)
/*     */     {
/* 196 */       return this.items.add(e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/util/BuildTypeComboList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */