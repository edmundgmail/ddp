/*     */ package net.sf.RecordEditor.re.util;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import net.sf.JRecord.External.CobolCopybookLoader;
/*     */ import net.sf.JRecord.External.CopybookLoaderFactory;
/*     */ import net.sf.JRecord.External.Def.AbstractConversion;
/*     */ import net.sf.JRecord.External.Def.BasicConversion;
/*     */ import net.sf.JRecord.External.ExternalConversion;
/*     */ import net.sf.JRecord.External.RecordEditorXmlLoader;
/*     */ import net.sf.RecordEditor.re.db.Table.TableList;
/*     */ import net.sf.RecordEditor.re.db.Table.TypeList;
/*     */ import net.sf.RecordEditor.re.jrecord.types.ReTypeManger;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CopybookLoaderFactoryDB
/*     */   extends CopybookLoaderFactory
/*     */   implements AbstractConversion
/*     */ {
/*  42 */   public static int currentDB = -1;
/*     */   
/*     */ 
/*  45 */   private static HashMap<String, Integer>[] typeConv = new HashMap[16];
/*  46 */   private static HashMap<String, Integer>[] formatConv = new HashMap[16];
/*  47 */   private static String[][] typeNames = new String[16][];
/*  48 */   private static String[][] formatNames = new String[16][];
/*     */   
/*     */ 
/*  51 */   private BasicConversion defaultConversion = new BasicConversion();
/*     */   
/*     */   static
/*     */   {
/*  55 */     for (int i = 0; i < typeConv.length; i++) {
/*  56 */       typeConv[i] = null;
/*  57 */       formatConv[i] = null;
/*  58 */       typeNames[i] = null;
/*  59 */       formatNames[i] = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CopybookLoaderFactoryDB()
/*     */   {
/*  76 */     this(30);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private CopybookLoaderFactoryDB(int maximumNumberOfLoaders)
/*     */   {
/*  85 */     super(maximumNumberOfLoaders);
/*     */     
/*  87 */     ExternalConversion.setStandardConversion(this);
/*     */     
/*  89 */     String s1 = Parameters.getString("InvalidFileChars");
/*  90 */     String s2 = Parameters.getString("FileReplChar");
/*  91 */     ExternalConversion.setInvalidFileChars(s1, s2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void registerAll()
/*     */   {
/* 105 */     register("cb2xml XML Copybook (DB)", XmlCopybookLoaderDB.class, "");
/* 106 */     if (CobolCopybookLoader.isAvailable()) {
/* 107 */       register("Cobol Copybook (DB)", CobolCopybookLoaderDB.class, "");
/*     */     } else {
/* 109 */       register("Empty - Cobol placeholder", XmlCopybookLoaderDB.class, "");
/*     */     }
/* 111 */     register("RecordEditor XML Copybook", RecordEditorXmlLoader.class, "");
/*     */     
/* 113 */     registerStandardLoaders2();
/*     */     
/*     */ 
/*     */ 
/* 117 */     for (int i = 0; i < 20; i++) {
/* 118 */       String copybookLoaderName = Parameters.getString("CopybookLoaderName." + i);
/* 119 */       if ((copybookLoaderName != null) && (!"".equals(copybookLoaderName))) {
/*     */         try {
/* 121 */           String copybookloaderClass = Parameters.getString("CopybookloaderClass." + i);
/* 122 */           if ((copybookloaderClass != null) && (!"".equals(copybookloaderClass))) {
/*     */             try {
/* 124 */               register(copybookLoaderName, Class.forName(copybookloaderClass), "");
/*     */             } catch (Exception e) {
/* 126 */               Common.logMsgRaw(e.getMessage(), e);
/*     */             }
/*     */           }
/*     */         } catch (Exception e) {
/* 130 */           Common.logMsgRaw(e.getMessage(), e);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFormat(int idx, String format)
/*     */   {
/* 143 */     int val = 0;
/* 144 */     idx = fixDbIdx(idx);
/* 145 */     format = format.toLowerCase();
/*     */     
/* 147 */     loadTypesFormats(idx);
/* 148 */     if (typeConv[idx].containsKey(format)) {
/* 149 */       val = ((Integer)typeConv[idx].get(format)).intValue();
/*     */     }
/*     */     
/* 152 */     return val;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getType(int idx, String type)
/*     */   {
/* 162 */     type = type.toLowerCase();
/*     */     int typeVal;
/* 164 */     int typeVal; if (this.defaultConversion.isValidTypeName(type)) {
/* 165 */       typeVal = this.defaultConversion.getType(idx, type);
/*     */     } else {
/* 167 */       idx = fixDbIdx(idx);
/* 168 */       loadTypesFormats(idx);
/* 169 */       int typeVal; if (typeConv[idx].containsKey(type)) {
/* 170 */         typeVal = ((Integer)typeConv[idx].get(type)).intValue();
/*     */       } else {
/* 172 */         typeVal = this.defaultConversion.getType(idx, type);
/*     */       }
/*     */     }
/*     */     
/* 176 */     return typeVal;
/*     */   }
/*     */   
/*     */ 
/*     */   public static int fixDbIdx(int idx)
/*     */   {
/* 182 */     if (idx < 0) {
/* 183 */       idx = Common.getConnectionIndex();
/*     */     }
/* 185 */     return idx;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void loadTypesFormats(int dbIdx)
/*     */   {
/* 204 */     if (typeConv[dbIdx] == null) {
/* 205 */       ReTypeManger typeMgr = ReTypeManger.getInstance();
/*     */       
/* 207 */       TypeList types = new TypeList(dbIdx, false, false, false);
/*     */       
/*     */ 
/*     */ 
/* 211 */       typeConv[dbIdx] = new HashMap();
/* 212 */       typeNames[dbIdx] = new String[typeMgr.getNumberOfTypes()];
/*     */       
/* 214 */       types.loadData();
/* 215 */       for (int i = 0; i < types.getSize(); i++) {
/* 216 */         Integer key = (Integer)types.getKeyAt(i);
/* 217 */         String str = toString(types.getFieldAt(i));
/* 218 */         typeConv[dbIdx].put(str.toLowerCase(), key);
/* 219 */         typeConv[dbIdx].put(key.toString(), key);
/* 220 */         typeNames[dbIdx][typeMgr.getIndex(key.intValue())] = str;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 228 */       TableList formats = new TableList(dbIdx, 5, false, false, "FormatNumber.", "FormatName.", 30);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 233 */       formatConv[dbIdx] = new HashMap();
/* 234 */       formatNames[dbIdx] = new String[typeMgr.getNumberOfFormats()];
/* 235 */       formats.loadData();
/* 236 */       for (int i = 0; i < formats.getSize(); i++) {
/* 237 */         Integer key = (Integer)formats.getKeyAt(i);
/* 238 */         String str = toString(formats.getFieldAt(i));
/* 239 */         formatConv[dbIdx].put(str.toLowerCase(), key);
/* 240 */         formatConv[dbIdx].put(key.toString(), key);
/*     */         
/* 242 */         formatNames[dbIdx][typeMgr.getFormatIndex(key.intValue())] = str;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getFormatAsString(int idx, int format)
/*     */   {
/* 251 */     ReTypeManger typeMgr = ReTypeManger.getInstance();
/* 252 */     idx = fixDbIdx(idx);
/* 253 */     loadTypesFormats(idx);
/*     */     
/* 255 */     return formatNames[idx][typeMgr.getFormatIndex(format)];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getTypeAsString(int idx, int type)
/*     */   {
/* 264 */     if (this.defaultConversion.isValid(idx, type)) {
/* 265 */       return this.defaultConversion.getTypeAsString(idx, type);
/*     */     }
/* 267 */     int id = fixDbIdx(idx);
/*     */     
/* 269 */     ReTypeManger typeMgr = ReTypeManger.getInstance();
/*     */     
/* 271 */     if (id == ExternalConversion.USE_DEFAULT_DB) {
/* 272 */       id = currentDB;
/* 273 */       if (id < 0) {
/* 274 */         id = Common.getConnectionIndex();
/*     */       }
/*     */     }
/* 277 */     loadTypesFormats(id);
/*     */     
/* 279 */     return typeNames[id][typeMgr.getIndex(type)];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isValid(int idx, int type)
/*     */   {
/* 288 */     String s = getTypeAsString(idx, type);
/* 289 */     return (s != null) && (!"".equals(s));
/*     */   }
/*     */   
/*     */   public String getDialectName(int key) {
/* 293 */     return this.defaultConversion.getDialectName(key);
/*     */   }
/*     */   
/*     */   public int getDialect(String name)
/*     */   {
/* 298 */     return this.defaultConversion.getDialect(name);
/*     */   }
/*     */   
/*     */   private static String toString(Object o)
/*     */   {
/* 303 */     String ret = "";
/*     */     
/* 305 */     if (o != null) {
/* 306 */       ret = o.toString();
/*     */     }
/* 308 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static final void setCurrentDB(int currentDB)
/*     */   {
/* 315 */     currentDB = currentDB;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class CobolCopybookLoaderDB
/*     */     extends CobolCopybookLoader
/*     */   {
/*     */     public CobolCopybookLoaderDB()
/*     */     {
/* 332 */       super();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/util/CopybookLoaderFactoryDB.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */