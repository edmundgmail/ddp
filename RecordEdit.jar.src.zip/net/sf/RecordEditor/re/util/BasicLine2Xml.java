/*    */ package net.sf.RecordEditor.re.util;
/*    */ 
/*    */ import java.io.FileOutputStream;
/*    */ import javax.xml.stream.XMLOutputFactory;
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ import javax.xml.stream.XMLStreamWriter;
/*    */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*    */ import net.sf.JRecord.Details.AbstractLine;
/*    */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*    */ import net.sf.JRecord.Details.AbstractRecordDetail.FieldDetails;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ 
/*    */ 
/*    */ public abstract class BasicLine2Xml
/*    */ {
/*    */   protected XMLStreamWriter writer;
/*    */   
/*    */   public BasicLine2Xml(String fileName)
/*    */   {
/* 20 */     XMLOutputFactory f = XMLOutputFactory.newInstance();
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     try
/*    */     {
/* 28 */       this.writer = f.createXMLStreamWriter(new FileOutputStream(fileName));
/*    */     } catch (Exception e) {
/* 30 */       e.printStackTrace();
/* 31 */       Common.logMsg("Error Opening XML file:", e);
/*    */     }
/*    */   }
/*    */   
/*    */   protected final void doWork() {
/*    */     try {
/* 37 */       this.writer.writeStartDocument();
/*    */       
/* 39 */       writeDetails();
/*    */       
/* 41 */       this.writer.writeEndDocument();
/* 42 */       this.writer.close();
/*    */     } catch (Exception e) {
/* 44 */       e.printStackTrace();
/* 45 */       Common.logMsg("Error Writing XML: ", e);
/*    */     }
/*    */   }
/*    */   
/*    */   protected abstract void writeDetails() throws XMLStreamException;
/*    */   
/*    */   protected final void writeAttributes(AbstractLine line) throws XMLStreamException {
/* 52 */     if (line != null) {
/* 53 */       int pref = line.getPreferredLayoutIdx();
/* 54 */       AbstractRecordDetail rec = line.getLayout().getRecord(pref);
/* 55 */       if (rec != null) {
/* 56 */         int end = rec.getFieldCount();
/*    */         
/*    */ 
/* 59 */         for (int i = 0; i < end; i++) {
/* 60 */           Object value = line.getField(pref, i);
/* 61 */           if ((value != null) && (!"".equals(value))) {
/* 62 */             this.writer.writeAttribute(fixName(rec.getField(i).getName()), value.toString());
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   protected final String fixName(String name)
/*    */   {
/* 74 */     return name.replace(" ", "_").replace(":", "_").replace(".", "_");
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/util/BasicLine2Xml.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */