/*     */ package net.sf.RecordEditor.re.script;
/*     */ 
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.zip.GZIPInputStream;
/*     */ import net.sf.JRecord.Common.RecordException;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.DefaultLineProvider;
/*     */ import net.sf.JRecord.Details.LineProvider;
/*     */ import net.sf.JRecord.External.ExternalRecord;
/*     */ import net.sf.JRecord.IO.AbstractLineIOProvider;
/*     */ import net.sf.JRecord.IO.AbstractLineReader;
/*     */ import net.sf.JRecord.IO.LineIOProvider;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.re.script.extensions.LanguageTrans;
/*     */ import net.sf.RecordEditor.utils.TypeNameArray;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import org.apache.velocity.Template;
/*     */ import org.apache.velocity.VelocityContext;
/*     */ import org.apache.velocity.app.VelocityEngine;
/*     */ import org.apache.velocity.app.event.EventCartridge;
/*     */ import org.apache.velocity.app.event.implement.IncludeRelativePath;
/*     */ import org.apache.velocity.exception.ParseErrorException;
/*     */ import org.apache.velocity.exception.ResourceNotFoundException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RunVelocity
/*     */ {
/*  49 */   private static RunVelocity instance = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void processFile(AbstractLayoutDetails layout, String inputFile, String template, String outputFile)
/*     */     throws Exception
/*     */   {
/*  68 */     int[] records = new int[0];
/*     */     
/*  70 */     BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(outputFile), "utf8"));
/*  71 */     processFile(layout, new DefaultLineProvider(), records, inputFile, outputFile, template, writer);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  78 */     writer.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void processFile(AbstractLayoutDetails layout, LineProvider lineProvider, int[] records, String inputFile, String outputFile, String template, Writer writer)
/*     */     throws Exception
/*     */   {
/* 109 */     ArrayList<AbstractLine> recordList = new ArrayList();
/*     */     
/*     */ 
/* 112 */     VelocityContext context = new VelocityContext();
/* 113 */     AbstractLineIOProvider ioProvider = LineIOProvider.getInstance();
/* 114 */     AbstractLineReader reader = ioProvider.getLineReader(layout, lineProvider);
/*     */     
/* 116 */     ioProvider = new LineIOProvider(lineProvider);
/* 117 */     reader = ioProvider.getLineReader(layout, null);
/*     */     
/* 119 */     int recordsToCheck = 0;
/* 120 */     if (records != null) {
/* 121 */       recordsToCheck = records.length;
/*     */     }
/*     */     
/*     */ 
/* 125 */     if (inputFile.endsWith(".gz")) {
/* 126 */       reader.open(new GZIPInputStream(new FileInputStream(inputFile)), layout);
/*     */     }
/*     */     else {
/* 129 */       reader.open(inputFile, layout);
/*     */     }
/*     */     AbstractLine line;
/* 132 */     while ((line = reader.read()) != null) {
/* 133 */       int preferedLayout = line.getPreferredLayoutIdx();
/*     */       
/* 135 */       boolean saveRecord = recordsToCheck == 0;
/*     */       
/* 137 */       for (int i = 0; i < recordsToCheck; i++) {
/* 138 */         if (preferedLayout == records[i]) {
/* 139 */           saveRecord = true;
/* 140 */           break;
/*     */         }
/*     */       }
/*     */       
/* 144 */       if (saveRecord) {
/* 145 */         recordList.add(line);
/*     */       }
/*     */     }
/*     */     
/* 149 */     reader.close();
/*     */     
/* 151 */     if (recordList.size() > 0) {
/* 152 */       context.put("records", recordList);
/* 153 */       context.put("fileName", inputFile);
/* 154 */       context.put("layout", layout);
/* 155 */       context.put("recordLayout", layout);
/* 156 */       context.put("outputFile", outputFile);
/* 157 */       context.put("recordLayout", layout);
/* 158 */       context.put("typeNames", new TypeNameArray());
/* 159 */       context.put("onlyData", Boolean.TRUE);
/* 160 */       context.put("showBorder", Boolean.TRUE);
/* 161 */       context.put("recordIdx", Integer.valueOf(((AbstractLine)recordList.get(0)).getPreferredLayoutIdx()));
/*     */       
/*     */ 
/* 164 */       genSkel(template, writer, context);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void genSkel(String template, ExternalRecord layout, TypeNameArray typeNames, String outputFile, Writer writer)
/*     */     throws Exception
/*     */   {
/* 183 */     VelocityContext context = new VelocityContext();
/*     */     
/* 185 */     context.put("outputFile", outputFile);
/* 186 */     context.put("typeNames", typeNames);
/* 187 */     context.put("recordLayout", layout);
/*     */     
/* 189 */     genSkel(template, writer, context);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void genSkel(String template, AbstractLayoutDetails layout, String name, Object data, String outputFile, Writer writer)
/*     */     throws Exception
/*     */   {
/* 211 */     VelocityContext context = new VelocityContext();
/*     */     
/* 213 */     context.put("outputFile", outputFile);
/* 214 */     context.put(name, data);
/* 215 */     context.put("recordLayout", layout);
/*     */     
/* 217 */     genSkel(template, writer, context);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void genSkel(String template, ScriptData data, Writer writer)
/*     */     throws Exception
/*     */   {
/* 233 */     if (data.view != null) {
/* 234 */       VelocityContext context = new VelocityContext();
/*     */       
/* 236 */       LanguageTrans.clear();
/*     */       
/* 238 */       context.put("records", data.selectedLines);
/* 239 */       context.put("file", data.fileLines);
/* 240 */       context.put("view", data.viewLines);
/* 241 */       context.put("treeRoot", data.root);
/* 242 */       context.put("treeNodes", data.nodes);
/* 243 */       context.put("treeDepth", Integer.valueOf(data.treeDepth));
/* 244 */       context.put("fileName", data.inputFile);
/* 245 */       context.put("outputFile", data.outputFile);
/* 246 */       context.put("layout", data.view.getLayout());
/* 247 */       context.put("onlyData", Boolean.valueOf(data.onlyData));
/* 248 */       context.put("showBorder", Boolean.valueOf(data.showBorder));
/* 249 */       context.put("recordIdx", Integer.valueOf(data.recordIdx));
/* 250 */       context.put("RecordEditorData", data);
/*     */       
/* 252 */       genSkel(template, writer, context);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void genSkel(String templateFile, Writer writer, VelocityContext context)
/*     */     throws Exception
/*     */   {
/* 282 */     Template template = null;
/*     */     try
/*     */     {
/* 285 */       EventCartridge ec = new EventCartridge();
/*     */       
/* 287 */       ec.addEventHandler(new IncludeRelativePath());
/*     */       
/* 289 */       context.attachEventCartridge(ec);
/*     */     }
/*     */     catch (Exception e1) {}
/*     */     
/*     */     try
/*     */     {
/* 295 */       VelocityEngine e = new VelocityEngine();
/* 296 */       int idx = templateFile.lastIndexOf(Common.FILE_SEPERATOR);
/* 297 */       if (idx > 0) {
/* 298 */         String s1 = templateFile.substring(0, idx);
/* 299 */         e.setProperty("file.resource.loader.path", s1);
/* 300 */         templateFile = templateFile.substring(idx + 1);
/*     */       }
/*     */       
/* 303 */       e.init();
/*     */       
/*     */ 
/* 306 */       template = e.getTemplate(templateFile, "UTF8");
/*     */     } catch (ResourceNotFoundException rnfe) {
/* 308 */       String msg = LangConversion.convert("Error - cannot find template:") + " " + templateFile;
/* 309 */       Common.logMsgRaw(msg, rnfe);
/* 310 */       throw new RecordException(true, msg);
/*     */     } catch (ParseErrorException pee) {
/* 312 */       String msg = LangConversion.convert("Syntax error in template") + " " + templateFile + ":" + pee;
/*     */       
/* 314 */       Common.logMsgRaw(msg, pee);
/* 315 */       throw new RecordException(true, msg);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 325 */     if (template != null) {
/* 326 */       template.merge(context, writer);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 333 */     writer.flush();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static RunVelocity getInstance()
/*     */   {
/* 340 */     if (instance == null) {
/* 341 */       instance = new RunVelocity();
/*     */     }
/* 343 */     return instance;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/script/RunVelocity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */