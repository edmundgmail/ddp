/*    */ package net.sf.RecordEditor.re.script;
/*    */ 
/*    */ import java.awt.Container;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.swing.JButton;
/*    */ import javax.swing.JDialog;
/*    */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*    */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*    */ import net.sf.RecordEditor.re.file.FileView;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ import net.sf.RecordEditor.utils.screenManager.ReMainFrame;
/*    */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CreateRecordTree
/*    */   implements ActionListener
/*    */ {
/*    */   public final CreateRecordTreePnl treeDisplay;
/*    */   private AbstractLayoutDetails layout;
/*    */   private JDialog dialog;
/*    */   private FileView view;
/* 26 */   private boolean ok = false;
/*    */   
/*    */ 
/*    */ 
/*    */   public CreateRecordTree(FileView fileView)
/*    */   {
/* 32 */     this.view = fileView;
/*    */     
/* 34 */     this.layout = this.view.getLayout();
/*    */     
/* 36 */     this.treeDisplay = new CreateRecordTreePnl(this.layout, true);
/* 37 */     this.dialog = new JDialog(ReMainFrame.getMasterFrame(), "Get Record Hierachy");
/* 38 */     this.dialog.getContentPane().add(this.treeDisplay.panel);
/*    */     
/* 40 */     this.treeDisplay.execute.addActionListener(this);
/*    */     
/* 42 */     this.dialog.setVisible(true);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public final void actionPerformed(ActionEvent event)
/*    */   {
/* 55 */     Common.stopCellEditing(this.treeDisplay.recordTbl);
/*    */     
/* 57 */     doAction();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public final AbstractFileDisplay doAction()
/*    */   {
/* 64 */     AbstractFileDisplay ret = null;
/* 65 */     this.treeDisplay.panel.setMessageRawTxtRE("");
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     try
/*    */     {
/* 77 */       this.ok = true;
/* 78 */       this.dialog.setVisible(false);
/*    */     }
/*    */     catch (Exception e) {
/* 81 */       this.treeDisplay.panel.setMessageRawTxtRE(e.getMessage());
/* 82 */       e.printStackTrace();
/*    */     }
/*    */     
/* 85 */     return ret;
/*    */   }
/*    */   
/*    */ 
/*    */   public final boolean isOk()
/*    */   {
/* 91 */     return this.ok;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/script/CreateRecordTree.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */