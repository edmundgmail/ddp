/*    */ package net.sf.RecordEditor.re.script;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ExecDirectoryConstants
/*    */ {
/* 19 */   public final String scriptDir = "ScriptDir";
/* 20 */   public final String sortTreeDir = "SortDir";
/* 21 */   public final String sortDir = "SortDir";
/* 22 */   public final String recordTreeDir = "RecordTreeDir";
/* 23 */   public final String filterDir = "FilterDir";
/* 24 */   public final String fieldDir = "FieldDir";
/* 25 */   public final String absolute = "Absolute";
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/script/ExecDirectoryConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */