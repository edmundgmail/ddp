package net.sf.RecordEditor.re.script;

public abstract interface IEditor
{
  public abstract void loadFileName(String paramString);
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/script/IEditor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */