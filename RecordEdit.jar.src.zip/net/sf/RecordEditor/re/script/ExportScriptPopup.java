/*    */ package net.sf.RecordEditor.re.script;
/*    */ 
/*    */ import javax.swing.SwingUtilities;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*    */ import net.sf.RecordEditor.utils.params.ProgramOptions.FileNameOptWithDefault;
/*    */ 
/*    */ public class ExportScriptPopup
/*    */   extends FilePopup implements Runnable
/*    */ {
/* 11 */   private static FilePopup.FileItem[] fileList = null;
/*    */   
/*    */   private final String dir;
/*    */   
/*    */   public ExportScriptPopup(String dir)
/*    */   {
/* 17 */     super("Export via Script");
/* 18 */     setIcon(Common.getReActionIcon(58));
/* 19 */     this.dir = dir;
/*    */     
/*    */ 
/* 22 */     SwingUtilities.invokeLater(this);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void run()
/*    */   {
/*    */     try
/*    */     {
/* 32 */       fileList = getActions(fileList, this.dir, 58, "(Run Script)", new ScriptMgr());
/*    */ 
/*    */ 
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/*    */ 
/* 39 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */   
/*    */   public static final ExportScriptPopup getPopup()
/*    */   {
/* 45 */     return new ExportScriptPopup(Common.OPTIONS.DEFAULT_SCRIPT_EXPORT_DIRECTORY.get());
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/script/ExportScriptPopup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */