/*    */ package net.sf.RecordEditor.re.script.runScreen;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LanguageDetails
/*    */ {
/* 19 */   public static final LanguageDetails DEFAULT_LANGUAGE_DEF = new LanguageDetails("txt", "Text", "text/plain", null);
/*    */   
/*    */ 
/*    */ 
/*    */   public final String ext;
/*    */   
/*    */ 
/*    */   public final String langName;
/*    */   
/*    */ 
/*    */   public final String rSyntax;
/*    */   
/*    */ 
/*    */   public String scriptLangName;
/*    */   
/*    */ 
/*    */ 
/*    */   public LanguageDetails(String ext, String langName, String rSyntax, String scriptLangName)
/*    */   {
/* 38 */     this.ext = ext;
/* 39 */     this.langName = langName;
/* 40 */     this.rSyntax = rSyntax;
/* 41 */     this.scriptLangName = scriptLangName;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/script/runScreen/LanguageDetails.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */