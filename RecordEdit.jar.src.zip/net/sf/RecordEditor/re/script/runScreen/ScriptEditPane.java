/*     */ package net.sf.RecordEditor.re.script.runScreen;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import javax.swing.event.DocumentEvent;
/*     */ import javax.swing.event.DocumentListener;
/*     */ import javax.swing.text.Document;
/*     */ import net.sf.RecordEditor.utils.msg.UtMessages;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMsg;
/*     */ import net.sf.RecordEditor.utils.swing.TabWithClosePnl;
/*     */ import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;
/*     */ import org.fife.ui.rtextarea.Gutter;
/*     */ import org.fife.ui.rtextarea.RTextScrollPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ScriptEditPane
/*     */ {
/*     */   public final TabWithClosePnl tabWithClose;
/*  26 */   private File scriptFile = null;
/*  27 */   private long changeDate = 0L;
/*  28 */   private final RSyntaxTextArea textArea = new RSyntaxTextArea();
/*  29 */   private final RTextScrollPane scrollPane = new RTextScrollPane(this.textArea, true);
/*     */   
/*     */   private boolean changed;
/*     */   private final ChangeListener tabChangeListner;
/*  33 */   public final JComponent tabComponent = this.scrollPane;
/*     */   
/*  35 */   private LanguageDetails languageDetails = LanguageDetails.DEFAULT_LANGUAGE_DEF;
/*     */   
/*     */ 
/*  38 */   private DocumentListener docListner = new DocumentListener()
/*     */   {
/*     */     public void removeUpdate(DocumentEvent e)
/*     */     {
/*  42 */       ScriptEditPane.this.setChanged(true);
/*     */     }
/*     */     
/*     */     public void insertUpdate(DocumentEvent e)
/*     */     {
/*  47 */       ScriptEditPane.this.setChanged(true);
/*     */     }
/*     */     
/*     */     public void changedUpdate(DocumentEvent e)
/*     */     {
/*  52 */       ScriptEditPane.this.setChanged(true);
/*     */     }
/*     */   };
/*     */   
/*     */   public ScriptEditPane(ChangeListener tabChangeListner)
/*     */   {
/*  58 */     this.tabWithClose = new TabWithClosePnl("    ", true);
/*  59 */     this.tabChangeListner = tabChangeListner;
/*  60 */     init();
/*  61 */     setChanged(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ScriptEditPane(ChangeListener tabChangeListner, File scriptFile)
/*     */     throws IOException
/*     */   {
/*  72 */     setScriptFile(scriptFile);
/*  73 */     this.tabWithClose = new TabWithClosePnl(scriptFile.getName(), true);
/*  74 */     this.tabChangeListner = tabChangeListner;
/*  75 */     init();
/*     */     
/*  77 */     readFile(scriptFile);
/*     */     
/*  79 */     setChanged(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init()
/*     */   {
/*  89 */     this.textArea.setTabSize(3);
/*  90 */     this.textArea.setCaretPosition(0);
/*     */     
/*  92 */     this.textArea.requestFocusInWindow();
/*  93 */     this.textArea.setMarkOccurrences(true);
/*  94 */     this.textArea.setCodeFoldingEnabled(true);
/*  95 */     this.textArea.setClearWhitespaceLinesEnabled(false);
/*     */     
/*     */ 
/*     */ 
/*  99 */     Gutter gutter = this.scrollPane.getGutter();
/* 100 */     gutter.setBookmarkingEnabled(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void readFile(File scriptFile)
/*     */     throws IOException
/*     */   {
/* 113 */     StringBuilder b = new StringBuilder();
/*     */     
/* 115 */     setScriptFile(scriptFile);
/* 116 */     char[] buff = new char[' '];
/*     */     
/* 118 */     BufferedReader r = new BufferedReader(new FileReader(scriptFile), buff.length);
/*     */     try { int l;
/* 120 */       while ((l = r.read(buff)) > 0) {
/* 121 */         if (l == buff.length) {
/* 122 */           b.append(buff);
/*     */         } else {
/* 124 */           char[] buff1 = new char[l];
/* 125 */           System.arraycopy(buff, 0, buff1, 0, l);
/* 126 */           b.append(buff1);
/*     */         }
/*     */       }
/*     */     } finally {
/* 130 */       r.close();
/*     */     }
/*     */     
/* 133 */     this.textArea.setText(b.toString());
/*     */     
/* 135 */     this.tabWithClose.setTabname(scriptFile.getName());
/*     */     
/* 137 */     setChanged(false);
/*     */   }
/*     */   
/*     */   public final void clear() {
/* 141 */     this.textArea.setText("");
/* 142 */     this.tabWithClose.setTabname("");
/* 143 */     setScriptFile(null);
/* 144 */     this.tabChangeListner.stateChanged(null);
/* 145 */     setChanged(false);
/*     */   }
/*     */   
/*     */   public final boolean isEmpty() {
/* 149 */     return this.scriptFile == null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final File getScriptFile()
/*     */   {
/* 156 */     return this.scriptFile;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setScriptFile(File scriptFile)
/*     */   {
/* 164 */     this.scriptFile = scriptFile;
/* 165 */     setScriptChangeDate();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public RSyntaxTextArea getTextArea()
/*     */   {
/* 172 */     return this.textArea;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public RTextScrollPane getScrollPane()
/*     */   {
/* 179 */     return this.scrollPane;
/*     */   }
/*     */   
/*     */   private void setScriptChangeDate() {
/* 183 */     if (this.scriptFile != null) {
/* 184 */       this.changeDate = this.scriptFile.lastModified();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getText()
/*     */   {
/* 193 */     return this.textArea.getText();
/*     */   }
/*     */   
/*     */   public void checkSave() throws IOException
/*     */   {
/* 198 */     if ((this.scriptFile != null) && (this.changed)) {
/* 199 */       int opt = JOptionPane.showConfirmDialog(this.scrollPane, UtMessages.SAVE_FILE_NAME.get(this.scriptFile.getPath()), UtMessages.SAVE_FILE.get(), 0);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 205 */       if (opt == 0) {
/* 206 */         saveFile();
/*     */       } else {
/* 208 */         clear();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void saveFile() throws IOException
/*     */   {
/* 215 */     if (this.scriptFile != null) {
/* 216 */       FileWriter w = new FileWriter(this.scriptFile);
/*     */       try {
/* 218 */         w.write(getText());
/*     */       } finally {
/* 220 */         w.close();
/*     */       }
/*     */       
/* 223 */       setScriptChangeDate();
/* 224 */       setChanged(false);
/*     */     }
/*     */   }
/*     */   
/*     */   public void saveAsFile(File newFile) throws IOException
/*     */   {
/* 230 */     if (newFile != null) {
/* 231 */       FileWriter w = new FileWriter(newFile);
/*     */       try {
/* 233 */         String text = getText();
/* 234 */         w.write(text);
/*     */         
/* 236 */         setScriptFile(newFile);
/* 237 */         this.tabWithClose.setTabname(this.scriptFile.getName());
/*     */       } finally {
/* 239 */         w.flush();
/* 240 */         w.close();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isChanged()
/*     */   {
/* 250 */     return (this.changed) || ((this.scriptFile != null) && (this.changeDate != this.scriptFile.lastModified()));
/*     */   }
/*     */   
/*     */   private void setChanged(boolean b) {
/* 254 */     this.changed = b;
/*     */     
/*     */ 
/* 257 */     this.textArea.getDocument().removeDocumentListener(this.docListner);
/*     */     
/* 259 */     if (!this.changed) {
/* 260 */       this.textArea.getDocument().addDocumentListener(this.docListner);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public LanguageDetails getLanguageDetails()
/*     */   {
/* 269 */     return this.languageDetails;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setLanguageDetails(LanguageDetails langDetails)
/*     */   {
/* 292 */     this.textArea.getDocument().removeDocumentListener(this.docListner);
/*     */     
/* 294 */     this.textArea.setSyntaxEditingStyle(langDetails.rSyntax);
/* 295 */     setChanged(this.changed);
/* 296 */     this.languageDetails = langDetails;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/script/runScreen/ScriptEditPane.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */