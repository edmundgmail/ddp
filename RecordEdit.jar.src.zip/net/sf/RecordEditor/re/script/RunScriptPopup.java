/*    */ package net.sf.RecordEditor.re.script;
/*    */ 
/*    */ import java.awt.event.ActionEvent;
/*    */ import javax.swing.AbstractAction;
/*    */ import javax.swing.SwingUtilities;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*    */ import net.sf.RecordEditor.utils.params.ProgramOptions.FileNameOptWithDefault;
/*    */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*    */ 
/*    */ 
/*    */ public class RunScriptPopup
/*    */   extends FilePopup
/*    */   implements Runnable
/*    */ {
/* 16 */   private static FilePopup.FileItem[] fileList = null;
/*    */   
/*    */   private final String dir;
/*    */   
/*    */   public RunScriptPopup(String dir)
/*    */   {
/* 22 */     super("Run Script");
/*    */     
/* 24 */     setIcon(Common.getReActionIcon(59));
/* 25 */     this.dir = dir;
/*    */     
/*    */ 
/* 28 */     SwingUtilities.invokeLater(this);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void run()
/*    */   {
/* 37 */     fileList = getActions(fileList, this.dir, 59, null, new ScriptMgr());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected AbstractAction getAction(int actionId, String filename, String filePathName)
/*    */   {
/* 53 */     return new RunScript(filename, filePathName);
/*    */   }
/*    */   
/*    */ 
/*    */   public static final RunScriptPopup getPopup()
/*    */   {
/* 59 */     return new RunScriptPopup(Common.OPTIONS.DEFAULT_SCRIPT_DIRECTORY.getNoStar());
/*    */   }
/*    */   
/*    */   private static class RunScript extends AbstractAction {
/*    */     private final String filePathName;
/*    */     
/*    */     public RunScript(String name, String filePathName) {
/* 66 */       super();
/* 67 */       this.filePathName = filePathName;
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     public void actionPerformed(ActionEvent e)
/*    */     {
/*    */       try
/*    */       {
/* 80 */         ScriptData data = ScriptData.getScriptData(ReFrame.getActiveFrame(), this.filePathName);
/*    */         
/* 82 */         new ScriptMgr().runScript(this.filePathName, data);
/*    */       } catch (Exception ex) {
/* 84 */         Common.logMsg(30, "Script execution failed !!!", ex.getClass().getName() + " " + ex.getMessage(), ex);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/script/RunScriptPopup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */