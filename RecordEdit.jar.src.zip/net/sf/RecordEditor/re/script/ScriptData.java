/*     */ package net.sf.RecordEditor.re.script;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.tree.TreeNode;
/*     */ import net.sf.JRecord.Common.Conversion;
/*     */ import net.sf.JRecord.Common.RecordException;
/*     */ import net.sf.JRecord.Common.TranslateXmlChars;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.LayoutDetail;
/*     */ import net.sf.JRecord.Details.LineCompare;
/*     */ import net.sf.JRecord.Details.LineProvider;
/*     */ import net.sf.JRecord.Details.RecordDetail;
/*     */ import net.sf.JRecord.External.ExternalConversion;
/*     */ import net.sf.JRecord.IO.AbstractLineIOProvider;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplayWithFieldHide;
/*     */ import net.sf.RecordEditor.re.display.DisplayBuilderFactory;
/*     */ import net.sf.RecordEditor.re.display.DisplayDetails;
/*     */ import net.sf.RecordEditor.re.display.IDisplayBuilder;
/*     */ import net.sf.RecordEditor.re.display.IDisplayFrame;
/*     */ import net.sf.RecordEditor.re.display.IExecuteSaveAction;
/*     */ import net.sf.RecordEditor.re.file.AbstractLineNode;
/*     */ import net.sf.RecordEditor.re.file.AbstractTreeFrame;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.re.script.extensions.LanguageTrans;
/*     */ import net.sf.RecordEditor.trove.TIntArrayList;
/*     */ import net.sf.RecordEditor.utils.common.ActionConstants;
/*     */ import net.sf.RecordEditor.utils.fileStorage.DataStoreStd;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScriptData
/*     */ {
/*  50 */   private static final int[] EMPTY_ARRAY = new int[0];
/*     */   
/*     */   public static final int SELECTION_ONLY = 1;
/*     */   
/*     */   public static final int SELECTION_AND_UPDATE = 2;
/*     */   private static final String sortDescending = "Descending Constant";
/*  56 */   public final float JAVA_VERSION = Parameters.JAVA_VERSION;
/*     */   
/*  58 */   public final DisplConstants displayConstants = new DisplConstants();
/*  59 */   public final ExecDirectoryConstants executeConstansts = new ExecDirectoryConstants();
/*  60 */   public final ActionConstants actionConstants = new ActionConstants();
/*     */   public final List<AbstractLine> selectedLines;
/*     */   public final List<AbstractLine> viewLines;
/*     */   public final List<AbstractLine> fileLines;
/*     */   public final FileView view;
/*     */   public final FileView file;
/*     */   public final FileView selectedView;
/*  67 */   public final Object root; public final List<List<TreeNode>> nodes = new ArrayList();
/*     */   public final int treeDepth;
/*     */   public final boolean onlyData;
/*     */   public final boolean showBorder;
/*     */   public final int recordIdx;
/*     */   public final String inputFile;
/*     */   public String outputFile;
/*     */   private final String dir;
/*     */   private final String script;
/*     */   private final ReFrame initialActiveFrame;
/*     */   public final IDisplayFrame initialDataFrame;
/*     */   public final AbstractFileDisplay initialTab;
/*  79 */   public final String descending = "Descending Constant";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ScriptData(List<AbstractLine> selectedList, FileView view, AbstractLineNode r, boolean onlyData, boolean showBorder, int recordIdx, String outputFile, ReFrame frame, String scriptFile)
/*     */   {
/*  92 */     this.selectedLines = selectedList;
/*  93 */     this.script = scriptFile;
/*     */     
/*  95 */     this.initialActiveFrame = frame;
/*     */     
/*  97 */     FileView tmpSelected = null;
/*     */     
/*  99 */     if ((frame instanceof IDisplayFrame)) {
/* 100 */       this.initialDataFrame = ((IDisplayFrame)frame);
/* 101 */       this.initialTab = this.initialDataFrame.getActiveDisplay();
/*     */     } else {
/* 103 */       this.initialTab = DisplayDetails.getDisplayDetails(frame);
/*     */       
/* 105 */       if (this.initialTab == null) {
/* 106 */         this.initialDataFrame = null;
/*     */       } else {
/* 108 */         this.initialDataFrame = this.initialTab.getParentFrame();
/*     */       }
/*     */     }
/*     */     
/* 112 */     if (view == null) {
/* 113 */       this.viewLines = null;
/* 114 */       this.fileLines = null;
/* 115 */       this.inputFile = null;
/* 116 */       this.file = null;
/*     */     } else {
/* 118 */       this.file = view.getBaseFile();
/* 119 */       this.viewLines = Collections.unmodifiableList(view.getLines());
/* 120 */       this.fileLines = Collections.unmodifiableList(this.file.getLines());
/* 121 */       this.inputFile = view.getFileNameNoDirectory();
/*     */       
/* 123 */       if ((selectedList == null) || (selectedList.size() == 0)) {
/* 124 */         tmpSelected = view.getView(EMPTY_ARRAY);
/*     */       } else {
/* 126 */         tmpSelected = view.getView(selectedList);
/*     */       }
/*     */     }
/* 129 */     this.view = view;
/* 130 */     this.selectedView = tmpSelected;
/*     */     
/*     */ 
/* 133 */     if ((r == null) && (this.initialTab != null) && ((this.initialTab instanceof AbstractTreeFrame))) {
/* 134 */       r = ((AbstractTreeFrame)this.initialTab).getRoot();
/*     */     }
/* 136 */     this.root = r;
/* 137 */     this.treeDepth = buildNodeList(this.nodes, r, 0);
/* 138 */     this.onlyData = onlyData;
/* 139 */     this.showBorder = showBorder;
/* 140 */     this.recordIdx = recordIdx;
/* 141 */     this.outputFile = outputFile;
/*     */     
/* 143 */     this.dir = new File(view.getFileName()).getParent();
/*     */     
/* 145 */     LanguageTrans.clear();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int buildNodeList(List<List<TreeNode>> nodeList, AbstractLineNode node, int lvl)
/*     */   {
/* 156 */     if (node == null) { return lvl;
/*     */     }
/* 158 */     int ret = lvl + 1;
/* 159 */     List<TreeNode> nodes = Arrays.asList(node.getPath());
/* 160 */     if (nodes == null) {
/* 161 */       nodes = new ArrayList(1);
/* 162 */       nodes.add(node);
/*     */     }
/*     */     
/* 165 */     nodeList.add(nodes);
/* 166 */     for (int i = 0; i < node.getChildCount(); i++) {
/* 167 */       ret = Math.max(ret, buildNodeList(nodeList, (AbstractLineNode)node.getChildAt(i), lvl));
/*     */     }
/*     */     
/* 170 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String htmlCharsToVars(Object o)
/*     */   {
/* 179 */     if (o == null) return "";
/* 180 */     return TranslateXmlChars.replaceXmlCharsStr(o.toString());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String trans4getText(String type, String val)
/*     */   {
/*     */     StringBuilder b;
/*     */     
/*     */ 
/*     */ 
/* 193 */     if ("u".equalsIgnoreCase(type)) {
/* 194 */       StringTokenizer t = new StringTokenizer(val, ":");
/* 195 */       String sep = "";
/*     */       
/* 197 */       StringBuilder b = new StringBuilder();
/*     */       
/* 199 */       while (t.hasMoreTokens()) {
/* 200 */         b.append(sep);
/*     */         try {
/* 202 */           b.append(net.sf.RecordEditor.utils.lang.LangConversion.MSG_NAMES[Integer.parseInt(t.nextToken().trim())]);
/*     */         }
/*     */         catch (Exception e) {}
/* 205 */         sep = " : ";
/*     */       }
/*     */     } else {
/* 208 */       b = new StringBuilder(val);
/*     */       
/* 210 */       if ("c".equalsIgnoreCase(type)) {
/* 211 */         Conversion.replace(b, "<br>", "<br>\n# ");
/* 212 */         Conversion.replace(b, "<br/>", "<br/>\n# ");
/* 213 */         Conversion.replace(b, "<p>", "\n# <p>");
/* 214 */         Conversion.replace(b, "\n", "\n# ");
/*     */         
/* 216 */         Conversion.replace(b, "</h1>", "</h1>\n# ");
/* 217 */         Conversion.replace(b, "</h2>", "</h2>\n# ");
/* 218 */         Conversion.replace(b, "</h3>", "</h3>\n# ");
/* 219 */         Conversion.replace(b, "</ul>", "</ul>\n# ");
/* 220 */         Conversion.replace(b, "</ol>", "</ol>\n# ");
/* 221 */         Conversion.replace(b, "</table>", "<table>\n# ");
/*     */         
/* 223 */         Conversion.replace(b, "<table>", "\n# <table>");
/* 224 */         Conversion.replace(b, "<tr>", "\n# <tr>");
/* 225 */         Conversion.replace(b, "<li>", "\n# <li>");
/* 226 */         Conversion.replace(b, "<pre>", "\n# <pre>");
/*     */       }
/* 228 */       else if ("m".equalsIgnoreCase(type)) {
/* 229 */         Conversion.replace(b, "\\", "\\\\");
/* 230 */         Conversion.replace(b, "\"", "\\\"");
/* 231 */         Conversion.replace(b, "\n", "\\n\"\n\"");
/* 232 */         Conversion.replace(b, "<br>", "<br>\"\n\"");
/* 233 */         Conversion.replace(b, "<br/>", "<br/>\"\n\"");
/* 234 */         Conversion.replace(b, "<p>", "\"\n\"<p>");
/*     */         
/* 236 */         Conversion.replace(b, "</h1>", "</h1>\"\n\"");
/* 237 */         Conversion.replace(b, "</h2>", "</h2>\"\n\"");
/* 238 */         Conversion.replace(b, "</h3>", "</h3>\"\n\"");
/* 239 */         Conversion.replace(b, "</ol>", "</ol>\"\n\"");
/* 240 */         Conversion.replace(b, "</ul>", "</ul>\"\n\"");
/* 241 */         Conversion.replace(b, "</table>", "</table>\"\n\"");
/*     */         
/* 243 */         Conversion.replace(b, "<table>", "\"\n\"<table>");
/* 244 */         Conversion.replace(b, "<tr>", "\"\n\"<tr>");
/* 245 */         Conversion.replace(b, "<li>", "\"\n\"<li>");
/* 246 */         Conversion.replace(b, "<pre>", "\"\n\"<pre>");
/* 247 */       } else if ("g".equalsIgnoreCase(type)) {
/* 248 */         Conversion.replace(b, "<br>", "\n\n<br>\n\n");
/* 249 */         Conversion.replace(b, "<br/>", "\n\n<br/>\n\n");
/* 250 */         Conversion.replace(b, "<p>", "\n\n<p>\n\n");
/* 251 */         Conversion.replace(b, "<b>", "");
/* 252 */         Conversion.replace(b, "</b>", "");
/* 253 */         Conversion.replace(b, "<i>", "");
/* 254 */         Conversion.replace(b, "</i>", "");
/*     */         
/* 256 */         Conversion.replace(b, "<h1>", "<h1>\n\n");
/* 257 */         Conversion.replace(b, "<h2>", "<h2>\n\n");
/* 258 */         Conversion.replace(b, "<h3>", "<h3>\n\n");
/* 259 */         Conversion.replace(b, "</h1>", "\n\n</h1>\n\n");
/* 260 */         Conversion.replace(b, "</h2>", "\n\n</h2>\n\n");
/* 261 */         Conversion.replace(b, "</h3>", "\n\n</h3>\n\n");
/* 262 */         Conversion.replace(b, "</ol>", "</ol>\n\n");
/* 263 */         Conversion.replace(b, "</ul>", "</ul>\n\n");
/* 264 */         Conversion.replace(b, "</table>", "</table>\n\n");
/*     */         
/* 266 */         Conversion.replace(b, "<table>", "\n\n<table>");
/* 267 */         Conversion.replace(b, "<tr>", "\n\n<tr>");
/* 268 */         Conversion.replace(b, "<li>", "\n\n<li>\n\n");
/* 269 */         Conversion.replace(b, "</li>", "\n\n</li>");
/* 270 */         Conversion.replace(b, "<td>", "<td>\n\n");
/* 271 */         Conversion.replace(b, "</td>", "\n\n</td>");
/* 272 */         Conversion.replace(b, "<pre>", "\n\n<pre>\n\n");
/* 273 */         Conversion.replace(b, "</pre>", "\n\n</pre>\n\n");
/*     */       }
/*     */     }
/* 276 */     return b.toString();
/*     */   }
/*     */   
/*     */   public String getLangTrans(String lang, String key) {
/* 280 */     String ret = "";
/*     */     try
/*     */     {
/* 283 */       ret = LanguageTrans.getTrans(this.dir + "/Trans" + lang + ".txt").get(Integer.parseInt(key.trim()));
/*     */     }
/*     */     catch (Exception e) {}
/* 286 */     return ret;
/*     */   }
/*     */   
/*     */   public ReFrame getCurrentFrame() {
/* 290 */     return ReFrame.getActiveFrame();
/*     */   }
/*     */   
/*     */   public AbstractFileDisplay getCurrentEditTab() {
/* 294 */     ReFrame f = ReFrame.getActiveFrame();
/*     */     
/* 296 */     return DisplayDetails.getDisplayDetails(f);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void fireScreenChanged(boolean viewDataChanged)
/*     */   {
/* 306 */     this.view.fireTableDataChanged();
/*     */     
/* 308 */     if (viewDataChanged) {
/* 309 */       this.view.setChanged(true);
/*     */     }
/*     */   }
/*     */   
/*     */   public String ask(String message)
/*     */   {
/* 315 */     return JOptionPane.showInputDialog(this.initialActiveFrame, message);
/*     */   }
/*     */   
/*     */   public int confirmYNC(String message) {
/* 319 */     return JOptionPane.showConfirmDialog(this.initialActiveFrame, message);
/*     */   }
/*     */   
/*     */   public boolean confirmYN(String title, String message) {
/* 323 */     return JOptionPane.showConfirmDialog(this.initialActiveFrame, message, title, 0) == 0;
/*     */   }
/*     */   
/*     */   public boolean confirmOC(String title, String message)
/*     */   {
/* 328 */     return JOptionPane.showConfirmDialog(this.initialActiveFrame, message, title, 2) == 0;
/*     */   }
/*     */   
/*     */   public void showMessage(String message)
/*     */   {
/* 333 */     JOptionPane.showMessageDialog(this.initialActiveFrame, message);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<AbstractLine> getNewLineList()
/*     */   {
/* 341 */     return new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int insertLine(int position)
/*     */   {
/* 351 */     return this.view.newLine(position, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractLine newLine()
/*     */   {
/* 360 */     AbstractLayoutDetails layout = this.view.getLayout();
/*     */     
/* 362 */     return this.view.getIoProvider().getLineProvider(layout).getLine(layout);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractLine newLine(String data)
/*     */   {
/* 373 */     AbstractLayoutDetails layout = this.view.getLayout();
/* 374 */     return this.view.getIoProvider().getLineProvider(layout).getLine(layout, data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final AbstractFileDisplayWithFieldHide displayList(int displayType, String tabName, List<AbstractLine> lineList)
/*     */   {
/* 386 */     AbstractLayoutDetails layout = this.view.getLayout();
/*     */     FileView v;
/* 388 */     FileView v; if ((lineList instanceof FileView)) {
/* 389 */       v = (FileView)lineList;
/*     */     } else {
/* 391 */       v = new FileView(DataStoreStd.newStore(layout, lineList), this.view, null, false);
/*     */     }
/*     */     
/* 394 */     return displayView(displayType, tabName, v);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final AbstractFileDisplayWithFieldHide displayView(int displayType, String screenName, FileView newView)
/*     */   {
/* 407 */     AbstractLine l = null;
/* 408 */     if ((newView != null) && (newView.getRowCount() > 0)) {
/* 409 */       l = newView.getLine(0);
/*     */     }
/* 411 */     return DisplayBuilderFactory.getInstance().newDisplay(displayType, screenName, this.initialDataFrame, newView.getLayout(), newView, l);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final AbstractFileDisplay executeSavedTask(String location, String name)
/*     */   {
/* 421 */     if (this.initialTab == null) {
/* 422 */       throw new RuntimeException("No Active edit screen to act on !!!");
/*     */     }
/* 424 */     return executeSavedTask(this.initialTab, location, name);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final AbstractFileDisplay executeSavedTask(AbstractFileDisplay display, String location, String name)
/*     */   {
/* 436 */     if (display == null) {
/* 437 */       throw new RuntimeException("Display is null");
/*     */     }
/*     */     
/* 440 */     String dir = "";
/* 441 */     this.executeConstansts.getClass(); if ("ScriptDir".equalsIgnoreCase(location)) {
/* 442 */       if ((this.script != null) && (!"".equals(this.script))) {
/* 443 */         File f = new File(this.script);
/* 444 */         dir = f.getParent();
/*     */       }
/* 446 */     } else { this.executeConstansts.getClass(); if ("SortDir".equalsIgnoreCase(location)) {
/* 447 */         dir = Parameters.getFileName("SortTreeSaveDirectory");
/* 448 */       } else { this.executeConstansts.getClass(); if ("RecordTreeDir".equalsIgnoreCase(location)) {
/* 449 */           dir = Parameters.getFileName("RecordTreeSaveDirectory");
/* 450 */         } else { this.executeConstansts.getClass(); if ("FieldDir".equalsIgnoreCase(location)) {
/* 451 */             dir = Parameters.getFileName("FieldSaveDirectory");
/* 452 */           } else { this.executeConstansts.getClass(); if ("FilterDir".equalsIgnoreCase(location)) {
/* 453 */               dir = Parameters.getFileName("FilterSaveDirectory");
/* 454 */             } else { this.executeConstansts.getClass(); if (!"Absolute".equalsIgnoreCase(location))
/*     */               {
/*     */ 
/* 457 */                 throw new RuntimeException("Invalid location: " + location); }
/*     */             }
/*     */           } } } }
/* 460 */     if (!"".equals(dir)) {
/* 461 */       dir = ExternalConversion.fixDirectory(dir);
/*     */     }
/*     */     
/* 464 */     String filename = dir + name;
/*     */     
/* 466 */     if (new File(filename).exists()) {
/* 467 */       return display.getExecuteTasks().executeSavedTask(filename);
/*     */     }
/* 469 */     throw new RuntimeException("Task: " + filename + " does not exist");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void write(String fileName, List<AbstractLine> list)
/*     */     throws RecordException, IOException
/*     */   {
/* 483 */     this.view.writeLinesToFile(fileName, list);
/*     */   }
/*     */   
/*     */   public static ScriptData getScriptData(ReFrame frame, String scriptFile)
/*     */   {
/* 488 */     ScriptData data = null;
/* 489 */     FileView file = null;
/* 490 */     int recordIdx = 0;
/*     */     
/* 492 */     if (frame != null) {
/* 493 */       AbstractFileDisplay disp = DisplayDetails.getDisplayDetails(frame);
/* 494 */       if (disp != null) {
/* 495 */         file = disp.getFileView();
/* 496 */         recordIdx = disp.getLayoutIndex();
/* 497 */       } else if ((frame.getDocument() instanceof FileView)) {
/* 498 */         file = (FileView)frame.getDocument();
/*     */       }
/*     */     }
/*     */     
/* 502 */     if (file != null)
/*     */     {
/* 504 */       List<AbstractLine> selected = file.getLines();
/* 505 */       AbstractFileDisplay initialTab; AbstractFileDisplay initialTab; if ((frame instanceof IDisplayFrame)) {
/* 506 */         initialTab = ((IDisplayFrame)frame).getActiveDisplay();
/*     */       } else {
/* 508 */         initialTab = DisplayDetails.getDisplayDetails(frame);
/*     */       }
/*     */       
/* 511 */       if (initialTab != null) {
/* 512 */         selected = initialTab.getSelectedLines();
/*     */       }
/* 514 */       data = new ScriptData(selected, file, null, false, true, recordIdx, file.getFileName() + ".xxx", frame, scriptFile);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 525 */     return data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LineCompare getLineCompareAllFields(LayoutDetail layout, int recordIndex)
/*     */   {
/* 537 */     RecordDetail record = (RecordDetail)layout.getRecord(recordIndex);
/* 538 */     int[] flds = new int[record.getFieldCount()];
/* 539 */     boolean[] descending = new boolean[flds.length];
/*     */     
/* 541 */     for (int i = 0; i < flds.length; i++) {
/* 542 */       flds[i] = i;
/*     */     }
/* 544 */     Arrays.fill(descending, false);
/*     */     
/* 546 */     return new LineCompare(layout, recordIndex, flds, descending);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LineCompare getLineCompare(LayoutDetail layout, int recordIndex, String... fields)
/*     */   {
/* 560 */     if ((fields == null) || (fields.length == 0)) {
/* 561 */       return getLineCompareAllFields(layout, recordIndex);
/*     */     }
/* 563 */     int yes = 1;int no = 2;
/*     */     
/* 565 */     TIntArrayList flds = new TIntArrayList(fields.length);
/* 566 */     TIntArrayList desc = new TIntArrayList(fields.length);
/* 567 */     RecordDetail record = (RecordDetail)layout.getRecord(recordIndex);
/*     */     
/* 569 */     for (int i = 0; i < fields.length; i++) { int idx;
/* 570 */       if ((fields[i] != "Descending Constant") && ((idx = record.getFieldIndex(fields[i])) >= 0))
/*     */       {
/* 572 */         int d = no;
/* 573 */         if ((i < fields.length - 1) && (fields[(i + 1)] == "Descending Constant")) {
/* 574 */           d = yes;
/*     */         }
/* 576 */         flds.add(idx);
/* 577 */         desc.add(d);
/*     */       }
/*     */     }
/*     */     
/* 581 */     boolean[] descending = new boolean[desc.size()];
/* 582 */     for (int i = 0; i < descending.length; i++) {
/* 583 */       descending[i] = (desc.get(i) == yes ? 1 : false);
/*     */     }
/*     */     
/* 586 */     return new LineCompare(layout, recordIndex, flds.toArray(), descending);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String askForFileName(String initialFileName, boolean open)
/*     */   {
/* 598 */     JFileChooser fc = new JFileChooser();
/* 599 */     String ret = "";
/*     */     
/*     */ 
/* 602 */     fc.setSelectedFile(new File(initialFileName));
/* 603 */     int result; int result; if (open) {
/* 604 */       result = fc.showOpenDialog(null);
/*     */     } else {
/* 606 */       result = fc.showSaveDialog(null);
/*     */     }
/*     */     
/* 609 */     if (result == 0) {
/* 610 */       ret = fc.getSelectedFile().getPath();
/*     */     }
/* 612 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Integer[] getRecordHierarchy()
/*     */   {
/* 621 */     CreateRecordTree rt = new CreateRecordTree(this.view);
/*     */     
/* 623 */     if (rt.isOk()) {
/* 624 */       return rt.treeDisplay.getParent();
/*     */     }
/* 626 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class DisplConstants
/*     */   {
/* 645 */     public int ST_INITIAL_EDIT = 1;
/* 646 */     public int ST_INITIAL_BROWSE = 2;
/* 647 */     public int ST_LIST_SCREEN = 3;
/* 648 */     public int ST_RECORD_SCREEN = 4;
/* 649 */     public int ST_RECORD_TREE = 5;
/* 650 */     public int ST_CB2XML_TREE = 6;
/* 651 */     public int ST_LINES_AS_COLUMNS = 7;
/* 652 */     public int ST_LINE_TREE_CHILD = 8;
/* 653 */     public int ST_DOCUMENT = 10;
/* 654 */     public int ST_COLORED_DOCUMENT = 11;
/*     */     
/* 656 */     public int ST_LINE_TREE_CHILD_EXPAND_PROTO = 9;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/script/ScriptData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */