/*    */ package net.sf.RecordEditor.re.script.bld;
/*    */ 
/*    */ 
/*    */ public class ScriptFieldDtls
/*    */ {
/*    */   public final String name;
/*    */   
/*    */   public final String lookupName;
/*    */   
/*    */   public final int fieldNumber;
/*    */   
/*    */   public final boolean selectOn;
/*    */   
/*    */   public final boolean update;
/*    */   
/*    */   public final boolean numeric;
/*    */   
/*    */   public final boolean decimal;
/*    */   
/*    */ 
/*    */   public ScriptFieldDtls(String name, String lookupName, int fieldNumber, boolean numeric, boolean hasDecimal, boolean selectOn, boolean update)
/*    */   {
/* 23 */     this.name = name;
/* 24 */     this.lookupName = lookupName;
/* 25 */     this.fieldNumber = fieldNumber;
/* 26 */     this.numeric = numeric;
/* 27 */     this.decimal = hasDecimal;
/* 28 */     this.selectOn = selectOn;
/* 29 */     this.update = update;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public final String getName()
/*    */   {
/* 37 */     return this.name;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public final String getLookupName()
/*    */   {
/* 45 */     return this.lookupName;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public final int getFieldNumber()
/*    */   {
/* 53 */     return this.fieldNumber;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public final boolean isSelectOn()
/*    */   {
/* 61 */     return this.selectOn;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public final boolean isUpdate()
/*    */   {
/* 69 */     return this.update;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public final boolean isNumeric()
/*    */   {
/* 77 */     return this.numeric;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public final boolean isDecimal()
/*    */   {
/* 85 */     return this.decimal;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/script/bld/ScriptFieldDtls.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */