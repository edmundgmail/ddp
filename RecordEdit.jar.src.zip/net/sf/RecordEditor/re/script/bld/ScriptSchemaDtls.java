/*    */ package net.sf.RecordEditor.re.script.bld;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*    */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*    */ import net.sf.JRecord.Details.AbstractRecordDetail.FieldDetails;
/*    */ import net.sf.JRecord.Types.TypeManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ScriptSchemaDtls
/*    */ {
/*    */   public final String schemaName;
/*    */   public final int dataSource;
/* 21 */   public final List<ScriptRecordDtls> records = new ArrayList();
/*    */   
/*    */ 
/*    */   public ScriptSchemaDtls(AbstractLayoutDetails l, int dataSrc, Boolean[] incRecords, Boolean[][][] fields)
/*    */   {
/* 26 */     this.schemaName = l.getLayoutName();
/* 27 */     this.dataSource = dataSrc;
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 32 */     for (int i = 0; i < l.getRecordCount(); i++) {
/* 33 */       AbstractRecordDetail schemaRecord = l.getRecord(i);
/* 34 */       ScriptRecordDtls rec = new ScriptRecordDtls(schemaRecord.getRecordName(), i, incRecords[i].booleanValue());
/* 35 */       for (int j = 0; j < schemaRecord.getFieldCount(); j++) {
/* 36 */         AbstractRecordDetail.FieldDetails schemaField = schemaRecord.getField(j);
/* 37 */         int type = schemaField.getType();
/* 38 */         boolean numeric = TypeManager.isNumeric(type);
/* 39 */         boolean hasDecimal = (numeric) && ((schemaField.getDecimal() > 0) || (TypeManager.hasFloatingDecimal(type)));
/*    */         
/* 41 */         rec.fields.add(new ScriptFieldDtls(schemaField.getName(), schemaField.getLookupName(), j, numeric, hasDecimal, fields[i][j][0].booleanValue(), fields[i][j][1].booleanValue()));
/*    */       }
/*    */       
/* 44 */       this.records.add(rec);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public final String getSchemaName()
/*    */   {
/* 53 */     return this.schemaName;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public final int getDataSource()
/*    */   {
/* 61 */     return this.dataSource;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public final List<ScriptRecordDtls> getRecords()
/*    */   {
/* 69 */     return this.records;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/script/bld/ScriptSchemaDtls.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */