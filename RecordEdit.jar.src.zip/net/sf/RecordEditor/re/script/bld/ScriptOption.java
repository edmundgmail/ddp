/*    */ package net.sf.RecordEditor.re.script.bld;
/*    */ 
/*    */ public class ScriptOption
/*    */ {
/*    */   public final String name;
/*    */   public final String selectName;
/*    */   public final String updateName;
/*    */   public final String description;
/*    */   
/*    */   public ScriptOption(String name, String selectName, String updateName, String description, boolean use, boolean selectOn, boolean update, boolean selectOneRecord, boolean onlyOneRecord)
/*    */   {
/* 12 */     this.name = name;
/* 13 */     this.use = use;
/* 14 */     this.selectOn = selectOn;
/* 15 */     this.update = update;
/* 16 */     this.selectOneRecord = selectOneRecord;
/* 17 */     this.onlyOneRecord = onlyOneRecord;
/* 18 */     this.selectName = selectName;
/* 19 */     this.updateName = updateName;
/* 20 */     this.description = description;
/*    */   }
/*    */   
/*    */   public final boolean use;
/*    */   public final boolean selectOn;
/*    */   public final boolean update;
/*    */   public final boolean selectOneRecord;
/*    */   public final boolean onlyOneRecord;
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/script/bld/ScriptOption.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */