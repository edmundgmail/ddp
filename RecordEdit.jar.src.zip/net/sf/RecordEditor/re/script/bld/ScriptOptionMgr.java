/*    */ package net.sf.RecordEditor.re.script.bld;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.TreeMap;
/*    */ import net.sf.JRecord.Common.AbstractFieldValue;
/*    */ import net.sf.JRecord.Common.RecordException;
/*    */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*    */ import net.sf.JRecord.Details.AbstractLine;
/*    */ import net.sf.JRecord.IO.AbstractLineReader;
/*    */ import net.sf.JRecord.IO.LineIOProvider;
/*    */ import net.sf.RecordEditor.edit.util.StandardLayouts;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ import net.sf.RecordEditor.utils.params.ProgramOptions.FileNameOptWithDefault;
/*    */ 
/*    */ public class ScriptOptionMgr
/*    */ {
/* 17 */   private static ScriptOptionMgr instance = new ScriptOptionMgr();
/* 18 */   private static TreeMap<String, ScriptOption> options = new TreeMap();
/* 19 */   private static ScriptOption DEFAULT_OPTION = new ScriptOption("", "", "", "", true, true, true, false, false);
/*    */   
/*    */   static
/*    */   {
/* 23 */     AbstractLayoutDetails csvSchema = StandardLayouts.getInstance().getCsvLayoutNamesFirstLine("<tab>", null, "", false);
/*    */     
/* 25 */     AbstractLineReader r = LineIOProvider.getInstance().getLineReader(csvSchema);
/*    */     
/*    */ 
/*    */     try
/*    */     {
/* 30 */       r.open(Common.OPTIONS.velocityScriptDir.getSlashNoStar() + "scripts.csv", csvSchema);
/*    */       AbstractLine l;
/* 32 */       while ((l = r.read()) != null) {
/* 33 */         String name = l.getFieldValue(0, 0).asString().toLowerCase();
/*    */         
/* 35 */         options.put(name, new ScriptOption(name, l.getFieldValue(0, 6).asString(), l.getFieldValue(0, 7).asString(), l.getFieldValue(0, 8).asString(), true, !"n".equalsIgnoreCase(l.getFieldValue(0, 2).asString()), !"n".equalsIgnoreCase(l.getFieldValue(0, 3).asString()), "y".equalsIgnoreCase(l.getFieldValue(0, 4).asString()), "y".equalsIgnoreCase(l.getFieldValue(0, 5).asString())));
/*    */       }
/*    */       
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       return;
/*    */     }
/*    */     catch (IOException e)
/*    */     {
/* 50 */       e.printStackTrace();
/*    */     } catch (RecordException e) {
/* 52 */       e.printStackTrace();
/*    */     } finally {
/*    */       try {
/* 55 */         r.close();
/*    */       } catch (IOException e) {
/* 57 */         e.printStackTrace();
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   public ScriptOption get(String name)
/*    */   {
/* 64 */     ScriptOption ret = DEFAULT_OPTION;
/*    */     
/*    */     String key;
/* 67 */     if ((name != null) && (options.containsKey(key = name.toLowerCase()))) {
/* 68 */       ret = (ScriptOption)options.get(key);
/*    */     }
/* 70 */     return ret;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public static final ScriptOptionMgr getInstance()
/*    */   {
/* 77 */     return instance;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/script/bld/ScriptOptionMgr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */