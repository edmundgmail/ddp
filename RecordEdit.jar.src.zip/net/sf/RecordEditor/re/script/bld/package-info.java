package net.sf.RecordEditor.re.script.bld;

interface package-info {}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/script/bld/package-info.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */