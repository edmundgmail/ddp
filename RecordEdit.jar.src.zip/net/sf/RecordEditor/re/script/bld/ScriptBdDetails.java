/*     */ package net.sf.RecordEditor.re.script.bld;
/*     */ 
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.table.AbstractTableModel;
/*     */ import net.sf.JRecord.Common.IFieldDetail;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ScriptBdDetails
/*     */ {
/*  38 */   public static int FT_GROUP = 3;
/*     */   
/*     */ 
/*  41 */   private static final String[] LAYOUT_GROUP_COLUMN_HEADINGS = LangConversion.convertColHeading("Filter Record Selection", new String[] { "Record", "In Group", "Include" });
/*     */   
/*     */ 
/*  44 */   private static final String[] LAYOUT_COLUMN_HEADINGS = { LAYOUT_GROUP_COLUMN_HEADINGS[0], LAYOUT_GROUP_COLUMN_HEADINGS[2] };
/*     */   
/*     */ 
/*  47 */   private static final String[] FIELD_COLUMN_HEADINGS = LangConversion.convertColHeading("Script_Field_Selection", new String[] { "Field", "Select On", "Update" });
/*     */   
/*     */ 
/*     */   private static final int INCLUDE_INDEX = 1;
/*     */   
/*     */ 
/*     */   private static final int SELECT_INDEX = 1;
/*     */   
/*     */   private static final int UPDATE_INDEX = 2;
/*     */   
/*     */   private final AbstractLayoutDetails layout;
/*     */   
/*  59 */   public String[] columnHeading = (String[])FIELD_COLUMN_HEADINGS.clone();
/*     */   
/*     */   private Boolean[] recordSelected;
/*     */   
/*     */   private Boolean[][][] fields;
/*  64 */   private int layoutIndex = 0;
/*     */   
/*  66 */   private JTextField messageFld = new JTextField();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private FieldList fieldList;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private final ScriptOption scriptOpt;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ScriptBdDetails(AbstractLayoutDetails group, ScriptOption opt)
/*     */   {
/*  83 */     this.layout = group;
/*  84 */     this.scriptOpt = opt;
/*     */     
/*     */ 
/*  87 */     init();
/*     */   }
/*     */   
/*     */   private void init() {
/*  91 */     int count = this.layout.getRecordCount();
/*  92 */     Boolean recSel = Boolean.valueOf(count == 1);
/*     */     
/*  94 */     this.recordSelected = new Boolean[count];
/*  95 */     this.fields = new Boolean[count][][];
/*     */     
/*     */ 
/*  98 */     for (int i = 0; i < count; i++) {
/*  99 */       this.recordSelected[i] = recSel;
/*     */       
/* 101 */       this.fields[i] = new Boolean[this.layout.getRecord(i).getFieldCount()][];
/* 102 */       for (int j = 0; j < this.fields[i].length; j++) {
/* 103 */         this.fields[i][j] = new Boolean[2];
/* 104 */         this.fields[i][j][0] = Boolean.FALSE;
/* 105 */         this.fields[i][j][1] = Boolean.FALSE;
/*     */       }
/*     */     }
/*     */     
/* 109 */     if (hasValue(this.scriptOpt.selectName)) {
/* 110 */       this.columnHeading[1] = this.scriptOpt.selectName;
/*     */     }
/*     */     
/* 113 */     if (hasValue(this.scriptOpt.updateName)) {
/* 114 */       this.columnHeading[2] = this.scriptOpt.updateName;
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean hasValue(String s)
/*     */   {
/* 120 */     return (s != null) && (s.length() > 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractTableModel getLayoutListMdl()
/*     */   {
/* 136 */     return new LayoutList();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public JTextField getMessageFld()
/*     */   {
/* 146 */     return this.messageFld;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setMessageFld(JTextField messageFld)
/*     */   {
/* 154 */     this.messageFld = messageFld;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractTableModel getFieldListMdl()
/*     */   {
/* 164 */     this.fieldList = new FieldList(null);
/* 165 */     return this.fieldList;
/*     */   }
/*     */   
/*     */   public ScriptSchemaDtls getSchemaDetails(int source) {
/* 169 */     return new ScriptSchemaDtls(this.layout, source, this.recordSelected, this.fields);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLayoutIndex(int pLayoutIndex)
/*     */   {
/* 196 */     this.layoutIndex = pLayoutIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private abstract class BaseLayoutList
/*     */     extends AbstractTableModel
/*     */   {
/*     */     private final String[] layoutColumnHeadings;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public BaseLayoutList(String[] layoutColumnHeadings)
/*     */     {
/* 391 */       this.layoutColumnHeadings = layoutColumnHeadings;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public final int getColumnCount()
/*     */     {
/* 399 */       return this.layoutColumnHeadings.length;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public final String getColumnName(int columnIndex)
/*     */     {
/* 410 */       return this.layoutColumnHeadings[columnIndex];
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public final int getRowCount()
/*     */     {
/* 418 */       return ScriptBdDetails.this.layout.getRecordCount();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public final boolean isCellEditable(int rowIndex, int columnIndex)
/*     */     {
/* 426 */       return columnIndex >= 1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setValueAt(Object aValue, int rowIndex, int columnIndex)
/*     */     {
/* 435 */       ScriptBdDetails.this.recordSelected[rowIndex] = Boolean.FALSE;
/*     */       
/* 437 */       if (aValue != null)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 449 */         if ((aValue instanceof Boolean)) {
/* 450 */           ScriptBdDetails.this.recordSelected[rowIndex] = ((Boolean)aValue);
/* 451 */           if ((ScriptBdDetails.this.scriptOpt.selectOneRecord) && (ScriptBdDetails.this.recordSelected[rowIndex].booleanValue())) {
/* 452 */             for (int i = 0; i < ScriptBdDetails.this.recordSelected.length; i++) {
/* 453 */               if (i != rowIndex) {
/* 454 */                 ScriptBdDetails.this.recordSelected[rowIndex] = Boolean.FALSE;
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private class LayoutList
/*     */     extends ScriptBdDetails.BaseLayoutList
/*     */   {
/*     */     public LayoutList()
/*     */     {
/* 474 */       super(ScriptBdDetails.LAYOUT_COLUMN_HEADINGS);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Object getValueAt(int rowIndex, int columnIndex)
/*     */     {
/* 483 */       if (columnIndex == 1) {
/* 484 */         return ScriptBdDetails.this.recordSelected[rowIndex];
/*     */       }
/* 486 */       return ScriptBdDetails.this.layout.getRecord(rowIndex).getRecordName();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private class FieldList
/*     */     extends AbstractTableModel
/*     */   {
/*     */     private FieldList() {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getColumnCount()
/*     */     {
/* 603 */       return ScriptBdDetails.this.columnHeading.length;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getColumnName(int columnIndex)
/*     */     {
/* 611 */       return ScriptBdDetails.this.columnHeading[columnIndex];
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getRowCount()
/*     */     {
/* 619 */       AbstractRecordDetail rec = ScriptBdDetails.this.layout.getRecord(ScriptBdDetails.this.layoutIndex);
/* 620 */       if (rec == null) {
/* 621 */         return 0;
/*     */       }
/* 623 */       return rec.getFieldCount();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Object getValueAt(int rowIndex, int columnIndex)
/*     */     {
/* 632 */       if (columnIndex == 0) {
/* 633 */         return ScriptBdDetails.this.layout.getAdjField(ScriptBdDetails.this.layoutIndex, rowIndex).getName();
/*     */       }
/*     */       
/* 636 */       return ScriptBdDetails.this.fields[ScriptBdDetails.this.layoutIndex][rowIndex][(columnIndex - 1)];
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isCellEditable(int rowIndex, int columnIndex)
/*     */     {
/* 644 */       return columnIndex >= 1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setValueAt(Object aValue, int rowIndex, int columnIndex)
/*     */     {
/* 656 */       Boolean val = Boolean.FALSE;
/* 657 */       if (aValue != null) {
/* 658 */         if ((aValue instanceof Boolean)) {
/* 659 */           val = (Boolean)aValue;
/*     */         } else {
/* 661 */           val = Boolean.valueOf("true".equalsIgnoreCase(aValue.toString()));
/*     */         }
/*     */       }
/* 664 */       ScriptBdDetails.this.fields[ScriptBdDetails.this.layoutIndex][rowIndex][(columnIndex - 1)] = val;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/script/bld/ScriptBdDetails.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */