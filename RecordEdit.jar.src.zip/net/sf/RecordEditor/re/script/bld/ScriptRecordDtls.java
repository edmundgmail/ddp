/*    */ package net.sf.RecordEditor.re.script.bld;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ScriptRecordDtls
/*    */ {
/*    */   public final String recordName;
/*    */   public final int recordNumber;
/*    */   public final boolean included;
/* 19 */   public final List<ScriptFieldDtls> fields = new ArrayList();
/*    */   
/*    */   public ScriptRecordDtls(String recordName, int recordNumber, boolean include)
/*    */   {
/* 23 */     this.recordName = recordName;
/* 24 */     this.recordNumber = recordNumber;
/* 25 */     this.included = include;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public final String getRecordName()
/*    */   {
/* 32 */     return this.recordName;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public final int getRecordNumber()
/*    */   {
/* 39 */     return this.recordNumber;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public final boolean isIncluded()
/*    */   {
/* 46 */     return this.included;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public final List<ScriptFieldDtls> getFields()
/*    */   {
/* 53 */     return this.fields;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Iterator<ScriptFieldDtls> fieldIterator()
/*    */   {
/* 61 */     return this.fields.iterator();
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/script/bld/ScriptRecordDtls.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */