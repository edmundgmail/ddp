/*     */ package net.sf.RecordEditor.re.script.bld;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.SwingUtilities;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*     */ import net.sf.RecordEditor.re.display.DisplayDetails;
/*     */ import net.sf.RecordEditor.re.script.FilePopup;
/*     */ import net.sf.RecordEditor.re.script.IEditor;
/*     */ import net.sf.RecordEditor.re.script.ScriptMgr;
/*     */ import net.sf.RecordEditor.re.script.ValidExtensionCheck;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions.FileNameOptWithDefault;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RunScriptSkelPopup
/*     */   extends FilePopup
/*     */   implements Runnable
/*     */ {
/*  26 */   private static ValidExtensionCheck checkExtension = new ValidExtensionCheck() {
/*     */     public boolean isValidExtension(String extension) {
/*  28 */       return (extension != null) && (extension.equalsIgnoreCase("vm"));
/*     */     }
/*     */   };
/*     */   private final String dir;
/*     */   private final String extension;
/*     */   private final IEditor editor;
/*     */   
/*     */   public RunScriptSkelPopup(IEditor editor, String dir, String name, String extension, boolean runInBackground)
/*     */   {
/*  37 */     super(name);
/*     */     
/*     */ 
/*  40 */     this.dir = dir;
/*  41 */     this.editor = editor;
/*  42 */     this.extension = extension;
/*     */     
/*     */ 
/*  45 */     if (runInBackground) {
/*  46 */       SwingUtilities.invokeLater(this);
/*     */     } else {
/*  48 */       run();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void run()
/*     */   {
/*     */     try
/*     */     {
/*  59 */       getActions(null, this.dir, 59, null, checkExtension);
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */ 
/*  66 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AbstractAction getAction(int actionId, String filename, String filePathName)
/*     */   {
/*  78 */     String s = filename;
/*  79 */     if ((s != null) && (s.toLowerCase().endsWith(".vm"))) {
/*  80 */       s = s.substring(0, s.length() - 3);
/*     */     }
/*  82 */     return new GenSkel(s, filePathName);
/*     */   }
/*     */   
/*     */ 
/*     */   private class GenSkel
/*     */     extends AbstractAction
/*     */   {
/*     */     private final String filePathName;
/*     */     
/*     */     private final String name;
/*     */     
/*     */     public GenSkel(String name, String filePathName)
/*     */     {
/*  95 */       super();
/*  96 */       this.name = name;
/*  97 */       this.filePathName = filePathName;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/*     */       try
/*     */       {
/* 107 */         ReFrame activeFrame = ReFrame.getActiveFrame();
/* 108 */         AbstractFileDisplay disp = DisplayDetails.getDisplayDetails(activeFrame);
/* 109 */         if (disp != null) {
/* 110 */           new ScriptBld(activeFrame, disp, RunScriptSkelPopup.this.editor, this.filePathName, this.name, RunScriptSkelPopup.this.extension);
/*     */         }
/*     */       }
/*     */       catch (Exception ex) {
/* 114 */         Common.logMsg(30, "Script execution failed !!!", ex.getClass().getName() + " " + ex.getMessage(), ex);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 119 */         ex.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public static JMenu buildScriptMenu(IEditor ed, String name)
/*     */   {
/* 126 */     JMenu buildMenu = null;
/* 127 */     String velocityDir = Common.OPTIONS.velocityScriptDir.getNoStar();
/* 128 */     File velocityDirFile = new File(velocityDir);
/* 129 */     if ((velocityDirFile.exists()) && (velocityDirFile.isDirectory())) {
/* 130 */       File[] files = velocityDirFile.listFiles();
/* 131 */       ArrayList<File> dirFiles = new ArrayList();
/* 132 */       for (File f : files) {
/* 133 */         if (f.isDirectory()) {
/* 134 */           dirFiles.add(f);
/*     */         }
/*     */       }
/* 137 */       if (dirFiles.size() == 1) {
/* 138 */         File vmDir = (File)dirFiles.get(0);
/* 139 */         buildMenu = new RunScriptSkelPopup(ed, vmDir.getPath(), name, ScriptMgr.getExtension(vmDir.getName()), true);
/* 140 */       } else if (dirFiles.size() > 1) {
/* 141 */         buildMenu = new JMenu(name);
/* 142 */         SwingUtilities.invokeLater(new BldSubMenus(buildMenu, dirFiles, ed));
/*     */       }
/*     */     }
/* 145 */     return buildMenu;
/*     */   }
/*     */   
/*     */ 
/*     */   public static class BldSubMenus
/*     */     implements Runnable
/*     */   {
/*     */     final JMenu buildMenu;
/*     */     
/*     */     final ArrayList<File> dirFiles;
/*     */     
/*     */     final IEditor ed;
/*     */     
/*     */ 
/*     */     public BldSubMenus(JMenu buildMenu, ArrayList<File> dirFiles, IEditor ed)
/*     */     {
/* 161 */       this.buildMenu = buildMenu;
/* 162 */       this.dirFiles = dirFiles;
/* 163 */       this.ed = ed;
/*     */     }
/*     */     
/*     */ 
/*     */     public void run()
/*     */     {
/* 169 */       for (File dirs : this.dirFiles) {
/* 170 */         File[] files = dirs.listFiles();
/* 171 */         boolean addMenu = false;
/*     */         
/* 173 */         for (File f : files) {
/* 174 */           if ((f.isDirectory()) || (RunScriptSkelPopup.checkExtension.isValidExtension(f.getName()))) {
/* 175 */             addMenu = true;
/* 176 */             break;
/*     */           }
/*     */         }
/*     */         
/* 180 */         if (addMenu) {
/* 181 */           this.buildMenu.add(new RunScriptSkelPopup(this.ed, dirs.getPath(), dirs.getName(), ScriptMgr.getExtension(dirs.getName()), false));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/script/bld/RunScriptSkelPopup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */