/*     */ package net.sf.RecordEditor.re.script.bld;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.DefaultCellEditor;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JEditorPane;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.table.AbstractTableModel;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*     */ import net.sf.RecordEditor.re.editProperties.CommonCode;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.re.openFile.RecentFiles;
/*     */ import net.sf.RecordEditor.re.script.IEditor;
/*     */ import net.sf.RecordEditor.re.script.RunVelocity;
/*     */ import net.sf.RecordEditor.re.script.runScreen.ScriptRunFrame;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.msg.UtMessages;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions.FileNameOptWithDefault;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMsg;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.CheckBoxTableRender;
/*     */ import net.sf.RecordEditor.utils.swing.JFlipBtn;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.FileTreeComboItem;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.TreeComboFileSelect;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ScriptBld
/*     */   extends BaseHelpPanel
/*     */   implements ActionListener
/*     */ {
/*  89 */   private static final int FIRST_COLUMN_WIDTH = SwingUtils.STANDARD_FONT_WIDTH * 35;
/*  90 */   private static final int SECOND_COLUMN_WIDTH = SwingUtils.STANDARD_FONT_WIDTH * 9;
/*     */   
/*  92 */   protected static final int FIELD_VALUE_ROW_HEIGHT = SwingUtils.COMBO_TABLE_ROW_HEIGHT;
/*  93 */   protected static final int FIELD_NAME_WIDTH = SwingUtils.STANDARD_FONT_WIDTH * 22;
/*     */   
/*  95 */   private static final List<FileTreeComboItem> SCRIPT_FILES = new ArrayList();
/*     */   
/*  97 */   private static final String[] englishDataSrc = { "File", "View", "Selection" };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 102 */   private static final String[] DATA_SRC = LangConversion.convertComboItms("scriptUpdateSrc", englishDataSrc);
/*     */   
/* 104 */   private TreeComboFileSelect fileCombo = new TreeComboFileSelect(true, false, true, SCRIPT_FILES, ScriptRunFrame.getRecent().getDirectoryList());
/*     */   
/* 106 */   private JComboBox dataSrcCombo = new JComboBox(DATA_SRC);
/*     */   
/*     */ 
/*     */   private JEditorPane tips;
/*     */   
/* 111 */   private JPanel recordOptionPanel = new JPanel();
/* 112 */   private JPanel fieldOptionPanel = new JPanel();
/* 113 */   protected final JTable recordTbl = new JTable();
/* 114 */   private JTable fieldTbl = new JTable();
/*     */   
/*     */   private AbstractTableModel recordMdl;
/*     */   
/*     */   private AbstractTableModel fieldMdl;
/* 119 */   private JLabel fieldHeadingLbl = new JLabel();
/*     */   
/* 121 */   private JTextField msgTxt = new JTextField();
/*     */   
/* 123 */   private JFlipBtn checkAllRecordsBtn = SwingUtils.newFlipButton("Check Records", "Uncheck Records");
/*     */   
/*     */ 
/* 126 */   private JFlipBtn checkAllFieldsBtn = SwingUtils.newFlipButton("Check Select-On Fields", "Uncheck Select-On Fields");
/* 127 */   private JFlipBtn checkAllUpdateFieldsBtn = SwingUtils.newFlipButton("Check Update Fields", "Uncheck Update Fields");
/*     */   
/*     */ 
/*     */   private ScriptBdDetails filter;
/*     */   
/*     */   private AbstractLayoutDetails recordLayout;
/*     */   
/* 134 */   private JButton buildBtn = SwingUtils.newButton("Build");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final String scriptTemplate;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final IEditor editor;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final ReFrame activeDisplay;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final AbstractFileDisplay activeFileDisplay;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ReFrame frame;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final ScriptOption scriptOption;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ScriptBld(ReFrame activeDisplay, AbstractFileDisplay activeFileDisplay, IEditor editor, String scriptTemplate, String scriptName, String scriptType)
/*     */   {
/* 201 */     this.scriptTemplate = scriptTemplate;
/* 202 */     this.editor = editor;
/* 203 */     this.activeDisplay = activeDisplay;
/* 204 */     this.activeFileDisplay = activeFileDisplay;
/* 205 */     this.recordLayout = activeFileDisplay.getFileView().getLayout();
/* 206 */     this.scriptOption = ScriptOptionMgr.getInstance().get(scriptName);
/*     */     
/*     */ 
/* 209 */     String destDir = Common.OPTIONS.DEFAULT_SCRIPT_DIRECTORY.getSlashNoStar() + "UserScripts" + Common.FILE_SEPERATOR;
/* 210 */     File destFile = new File(destDir);
/* 211 */     String tmp = destDir + scriptName;
/* 212 */     if (activeFileDisplay != null) {
/* 213 */       tmp = tmp + "_" + activeFileDisplay.getFileView().getLayout().getLayoutName();
/*     */     }
/*     */     
/* 216 */     if (!destFile.exists()) {
/* 217 */       destFile.mkdirs();
/*     */     }
/*     */     
/* 220 */     this.fileCombo.setText(tmp + scriptType);
/* 221 */     this.dataSrcCombo.setSelectedIndex(1);
/*     */     
/* 223 */     this.tips = new JEditorPane("text/html", LangConversion.convertId(2, "ScriptBldTip", "<h3>Script Build</h3>This option will build a sample {0} script.<br>Just select the appropriate options", new Object[] { scriptName }) + "<p><b>Script Description:</b>" + this.scriptOption.description);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 233 */     init_100_setupFields();
/*     */     
/* 235 */     init_200_layoutScreen(0);
/*     */     
/* 237 */     init_300_finalise(scriptName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_100_setupFields()
/*     */   {
/* 246 */     this.filter = new ScriptBdDetails(this.recordLayout, this.scriptOption);
/* 247 */     this.filter.setMessageFld(this.msgTxt);
/*     */     
/*     */ 
/*     */ 
/* 251 */     this.fieldMdl = this.filter.getFieldListMdl();
/*     */     
/* 253 */     this.recordMdl = this.filter.getLayoutListMdl();
/*     */     
/* 255 */     this.recordTbl.setModel(this.recordMdl);
/* 256 */     this.fieldTbl.setModel(this.fieldMdl);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 263 */     setTableDetails(this.recordTbl);
/* 264 */     setTableDetails(this.fieldTbl);
/*     */     
/*     */ 
/* 267 */     this.recordOptionPanel.add(this.checkAllRecordsBtn);
/*     */     
/*     */ 
/* 270 */     if (this.scriptOption.selectOn) {
/* 271 */       this.fieldOptionPanel.add(this.checkAllFieldsBtn);
/*     */     }
/*     */     
/* 274 */     if (this.scriptOption.update) {
/* 275 */       this.fieldOptionPanel.add(this.checkAllUpdateFieldsBtn);
/*     */     }
/*     */     
/* 278 */     this.recordTbl.addMouseListener(new MouseAdapter() {
/*     */       public void mousePressed(MouseEvent m) {
/* 280 */         int idx = ScriptBld.this.recordTbl.getSelectedRow();
/*     */         
/* 282 */         if ((idx >= 0) && (idx < ScriptBld.this.recordTbl.getRowCount()))
/*     */         {
/*     */ 
/*     */ 
/* 286 */           ScriptBld.this.filter.setLayoutIndex(idx);
/* 287 */           ScriptBld.this.fieldMdl.fireTableDataChanged();
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 292 */           ScriptBld.this.fieldHeadingLbl.setText(UtMessages.FIELD_SELECTION.get(ScriptBld.this.recordLayout.getRecord(idx).getRecordName()));
/*     */         }
/*     */         
/*     */       }
/*     */       
/* 297 */     });
/* 298 */     this.checkAllRecordsBtn.addActionListener(this);
/* 299 */     this.checkAllFieldsBtn.addActionListener(this);
/* 300 */     this.checkAllUpdateFieldsBtn.addActionListener(this);
/* 301 */     this.buildBtn.addActionListener(this);
/*     */     
/* 303 */     if (present(this.scriptOption.selectName)) {
/* 304 */       this.checkAllFieldsBtn.setTextValues("Check all " + this.scriptOption.selectName, "UnCheck all " + this.scriptOption.selectName);
/*     */     }
/*     */     
/* 307 */     if (present(this.scriptOption.updateName)) {
/* 308 */       this.checkAllUpdateFieldsBtn.setTextValues("Check all " + this.scriptOption.updateName, "UnCheck all " + this.scriptOption.updateName);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean present(String s)
/*     */   {
/* 331 */     return (s != null) && (s.length() > 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_200_layoutScreen(int heightOverhead)
/*     */   {
/* 341 */     int maxTblColWidth = ReFrame.getDesktopWidth() / 4;
/* 342 */     int desktopHeight = ReFrame.getDesktopHeight() - 50 - heightOverhead - 2 * (int)BasePanel.GAP1;
/*     */     
/*     */ 
/*     */ 
/* 346 */     desktopHeight -= SwingUtils.BUTTON_HEIGHT + 6;
/*     */     
/*     */ 
/* 349 */     desktopHeight -= SwingUtils.BUTTON_HEIGHT * 3;
/*     */     
/*     */ 
/*     */ 
/* 353 */     addComponentRE(1, 5, CommonCode.TIP_HEIGHT / 2, BasePanel.GAP1, 2, 2, this.tips);
/*     */     
/*     */ 
/*     */ 
/* 357 */     addLineRE("Script File", this.fileCombo);
/* 358 */     addLineRE("Update", this.dataSrcCombo);
/* 359 */     if (this.recordLayout.getRecordCount() > 1)
/*     */     {
/*     */ 
/* 362 */       int maxHeight = desktopHeight / 4;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 367 */       addComponentRE(1, 3, this.recordOptionPanel.getPreferredSize().getHeight(), BasePanel.GAP, 2, 2, this.recordOptionPanel);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 372 */       int height = SwingUtils.calculateTableHeight(this.recordTbl.getRowCount(), maxHeight);
/* 373 */       setHeightRE(SwingUtils.BUTTON_HEIGHT + 6);
/*     */       
/*     */ 
/* 376 */       desktopHeight -= height + SwingUtils.BUTTON_HEIGHT + 6;
/* 377 */       addComponentRE(1, 3, height, BasePanel.GAP1, 2, 2, this.recordTbl);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 382 */       setComponentName(this.recordTbl, "RecordSelection");
/* 383 */       Common.calcColumnWidths(this.recordTbl, 0, maxTblColWidth);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 388 */     addComponentRE(1, 3, this.fieldOptionPanel.getPreferredSize().getHeight(), BasePanel.GAP, 2, 2, this.fieldOptionPanel);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 393 */     setHeightRE(SwingUtils.BUTTON_HEIGHT + 6);
/*     */     
/*     */ 
/*     */ 
/* 397 */     int rows = this.fieldTbl.getRowCount();
/* 398 */     for (int i = 0; i < this.recordLayout.getRecordCount(); i++) {
/* 399 */       rows = Math.max(rows, this.recordLayout.getRecord(i).getFieldCount());
/*     */     }
/* 401 */     int height = SwingUtils.calculateTableHeight(rows, desktopHeight / 2);
/* 402 */     desktopHeight -= height;
/*     */     
/* 404 */     addComponentRE(1, 3, height, BasePanel.GAP1, 2, 2, this.fieldTbl);
/*     */     
/*     */ 
/*     */ 
/* 408 */     setComponentName(this.fieldTbl, "FieldSelection");
/*     */     
/*     */ 
/*     */ 
/* 412 */     Common.calcColumnWidths(this.fieldTbl, 0, maxTblColWidth);
/*     */     
/*     */ 
/* 415 */     setGapRE(BasePanel.GAP0);
/* 416 */     addLineRE(null, null, this.buildBtn);
/*     */     
/* 418 */     addMessage(this.msgTxt);
/*     */   }
/*     */   
/*     */ 
/*     */   private void init_300_finalise(String scriptName)
/*     */   {
/* 424 */     FileView baseFile = this.activeFileDisplay.getFileView().getBaseFile();
/*     */     
/* 426 */     if (!this.scriptOption.update) {
/* 427 */       TableColumnModel columnModel = this.fieldTbl.getColumnModel();
/* 428 */       columnModel.removeColumn(columnModel.getColumn(2));
/*     */     }
/*     */     
/* 431 */     this.fieldHeadingLbl.setText(UtMessages.FIELD_SELECTION.get(this.recordLayout.getRecord(0).getRecordName()));
/*     */     
/* 433 */     this.frame = new ReFrame(baseFile.getFileNameNoDirectory(), "Build Script", baseFile);
/* 434 */     this.frame.addMainComponent(this);
/* 435 */     this.frame.setToMaximum(false);
/* 436 */     this.frame.setVisible(true);
/* 437 */     this.frame.setDefaultCloseOperation(2);
/* 438 */     this.frame.setToMaximum(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setTableDetails(JTable tbl)
/*     */   {
/* 467 */     setTableDetailsCol0(tbl);
/*     */     
/* 469 */     for (int i = 1; i < tbl.getColumnCount(); i++) {
/* 470 */       TableColumn tc = tbl.getColumnModel().getColumn(i);
/* 471 */       tc.setCellRenderer(new CheckBoxTableRender());
/* 472 */       tc.setCellEditor(new DefaultCellEditor(new JCheckBox()));
/* 473 */       tc.setPreferredWidth(SECOND_COLUMN_WIDTH);
/*     */     }
/*     */   }
/*     */   
/*     */   protected final void setTableDetailsCol0(JTable tbl)
/*     */   {
/* 479 */     tbl.setAutoResizeMode(0);
/* 480 */     tbl.getColumnModel().getColumn(0).setPreferredWidth(FIRST_COLUMN_WIDTH);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void actionPerformed(ActionEvent event)
/*     */   {
/* 546 */     stopTblEdit();
/*     */     
/* 548 */     if (event.getSource() == this.checkAllFieldsBtn) {
/* 549 */       updateIncludeFlag(1, Boolean.valueOf(this.checkAllFieldsBtn.isNormalState()));
/* 550 */       this.checkAllFieldsBtn.flipText();
/* 551 */     } else if (event.getSource() == this.checkAllUpdateFieldsBtn) {
/* 552 */       updateIncludeFlag(2, Boolean.valueOf(this.checkAllUpdateFieldsBtn.isNormalState()));
/* 553 */       this.checkAllUpdateFieldsBtn.flipText();
/* 554 */     } else if (event.getSource() == this.checkAllRecordsBtn) {
/* 555 */       updateRecordFlag(Boolean.valueOf(this.checkAllRecordsBtn.isNormalState()));
/* 556 */       this.checkAllRecordsBtn.flipText();
/* 557 */     } else if (event.getSource() == this.buildBtn) {
/* 558 */       RunVelocity velocity = RunVelocity.getInstance();
/* 559 */       String filename = this.fileCombo.getText();
/*     */       
/* 561 */       if (!"".equals(filename))
/*     */       {
/*     */         try
/*     */         {
/* 565 */           BufferedWriter w = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(filename)));
/*     */           try {
/* 567 */             velocity.genSkel(this.scriptTemplate, this.recordLayout, "scriptSchema", this.filter.getSchemaDetails(this.dataSrcCombo.getSelectedIndex()), filename, w);
/*     */           }
/*     */           finally
/*     */           {
/* 571 */             w.close();
/*     */           }
/*     */           
/* 574 */           Object ed = this.editor;
/* 575 */           if (this.editor == null) {
/* 576 */             ed = new ScriptRunFrame(this.activeDisplay);
/*     */           }
/* 578 */           ((IEditor)ed).loadFileName(filename);
/* 579 */           this.frame.setVisible(false);
/*     */         } catch (IOException e) {
/* 581 */           this.msgTxt.setText(e.toString());
/* 582 */           e.printStackTrace();
/*     */         } catch (Exception e) {
/* 584 */           this.msgTxt.setText(e.toString());
/* 585 */           e.printStackTrace();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void updateRecordFlag(Boolean val)
/*     */   {
/* 621 */     for (int i = this.recordTbl.getRowCount() - 1; i >= 0; i--) {
/* 622 */       this.recordTbl.setValueAt(val, i, 1);
/*     */     }
/* 624 */     this.recordMdl.fireTableDataChanged();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void updateIncludeFlag(int idx, Boolean val)
/*     */   {
/* 636 */     for (int i = this.fieldTbl.getRowCount() - 1; i >= 0; i--) {
/* 637 */       this.fieldMdl.setValueAt(val, i, idx);
/*     */     }
/* 639 */     this.fieldMdl.fireTableDataChanged();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final JTextField getMessageFld()
/*     */   {
/* 650 */     return this.msgTxt;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void fireDataChanged()
/*     */   {
/* 669 */     if (this.fieldMdl != null) {
/* 670 */       this.fieldMdl.fireTableDataChanged();
/*     */       
/*     */ 
/* 673 */       this.recordMdl.fireTableDataChanged();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void stopTblEdit()
/*     */   {
/* 680 */     Common.stopCellEditing(this.recordTbl);
/* 681 */     Common.stopCellEditing(this.fieldTbl);
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/script/bld/ScriptBld.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */