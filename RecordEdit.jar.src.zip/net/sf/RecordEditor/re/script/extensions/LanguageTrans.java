/*     */ package net.sf.RecordEditor.re.script.extensions;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import net.sf.JRecord.Common.Conversion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LanguageTrans
/*     */ {
/*  21 */   private ArrayList<String> list = new ArrayList(1500);
/*  22 */   private static String BLANK = "";
/*     */   
/*  24 */   private static final String[] SUPPRESS_AFTER = { "<h1>", "<h2>", "<h3>", "<td>" };
/*  25 */   private static final String[] SUPPRESS_BEFORE = { "</h1>", "</h2>", "</h3>" };
/*     */   
/*  27 */   private static HashMap<String, LanguageTrans> translations = new HashMap();
/*     */   
/*     */   public static LanguageTrans getTrans(String fname)
/*     */   {
/*  31 */     if (translations.containsKey(fname)) {
/*  32 */       return (LanguageTrans)translations.get(fname);
/*     */     }
/*     */     
/*  35 */     LanguageTrans t = new LanguageTrans(fname);
/*  36 */     translations.put(fname, t);
/*     */     
/*  38 */     return t;
/*     */   }
/*     */   
/*     */   private LanguageTrans(String fileName)
/*     */   {
/*     */     try
/*     */     {
/*  45 */       BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(fileName), "UTF8"));
/*  46 */       String l = BLANK;
/*  47 */       boolean suppress = false;
/*  48 */       boolean suppressNext = false;
/*  49 */       int key = 0;
/*     */       
/*     */ 
/*  52 */       for (int i = 0; i < 3000; i++)
/*  53 */         this.list.add(BLANK);
/*     */       String s;
/*  55 */       while ((s = r.readLine()) != null) {
/*  56 */         if (!"".equals(s.trim()))
/*     */         {
/*     */ 
/*  59 */           suppressNext = false;
/*  60 */           if ((s.startsWith("::")) || (s.startsWith("：："))) {
/*  61 */             if (l != BLANK) {
/*     */               try {
/*  63 */                 StringBuilder b = new StringBuilder(l);
/*  64 */                 Conversion.replace(b, "</ ", "</");
/*  65 */                 Conversion.replace(b, "\\n</h1", "</h1");
/*  66 */                 Conversion.replace(b, "\\n</h2", "</h2");
/*  67 */                 Conversion.replace(b, "\\n</h3", "</h3");
/*  68 */                 this.list.set(key, b.toString());
/*  69 */                 l = BLANK;
/*  70 */                 key = 0;
/*     */               } catch (Exception e) {
/*  72 */                 e.printStackTrace();
/*     */               }
/*     */             }
/*  75 */             int pos = s.indexOf(":", 2);
/*  76 */             int pos2 = s.indexOf("：", 2);
/*  77 */             if (pos < 0) {
/*  78 */               pos = pos2;
/*  79 */             } else if (pos2 >= 0) {
/*  80 */               pos = Math.min(pos, pos2);
/*     */             }
/*  82 */             if (pos > 2) {
/*     */               try {
/*  84 */                 key = Integer.parseInt(s.substring(2, pos).trim());
/*  85 */                 System.out.println("  >> " + key + " " + s);
/*  86 */                 l = "";
/*  87 */                 if (s.length() > pos + 2) {
/*  88 */                   l = s.substring(pos + 1);
/*     */                 }
/*     */               } catch (Exception e) {
/*  91 */                 e.printStackTrace();
/*     */               }
/*     */             } else {
/*  94 */               System.out.println(" ## > " + pos + " " + s);
/*     */             }
/*  96 */             s = r.readLine();
/*  97 */             if (s == null) {
/*     */               break;
/*     */             }
/* 100 */             suppressNext = true;
/* 101 */           } else if ((suppress) || (suppressBefore(s))) {
/* 102 */             l = l + s;
/*     */           } else {
/* 104 */             l = l + "\n" + s;
/*     */           }
/*     */           
/* 107 */           suppress = suppressNext;
/* 108 */           String t = s.toLowerCase();
/* 109 */           for (String ss : SUPPRESS_AFTER) {
/* 110 */             if (t.endsWith(ss)) {
/* 111 */               suppress = true;
/* 112 */               break;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 118 */       this.list.set(key, l);
/*     */       
/* 120 */       r.close();
/*     */     } catch (Exception e) {
/* 122 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean suppressBefore(String s) {
/* 127 */     String t = s.toLowerCase();
/* 128 */     for (String ss : SUPPRESS_BEFORE) {
/* 129 */       if (t.startsWith(ss)) {
/* 130 */         return true;
/*     */       }
/*     */     }
/* 133 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String get(int index)
/*     */   {
/* 142 */     return (String)this.list.get(index);
/*     */   }
/*     */   
/*     */   public static void clear() {
/* 146 */     translations.clear();
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/script/extensions/LanguageTrans.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */