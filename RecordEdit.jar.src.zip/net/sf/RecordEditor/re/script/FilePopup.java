/*     */ package net.sf.RecordEditor.re.script;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Comparator;
/*     */ import javax.swing.AbstractAction;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.ReMenu;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReActionActiveScreen;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilePopup
/*     */   extends ReMenu
/*     */   implements Comparator<File>
/*     */ {
/*     */   public FilePopup(String s)
/*     */   {
/*  21 */     super(s);
/*     */   }
/*     */   
/*     */ 
/*     */   protected final FileItem[] getActions(FileItem[] fileList, String filename, int actionId, String defaultName, ValidExtensionCheck checkExtension)
/*     */   {
/*  27 */     return getActions(this, fileList, filename, actionId, defaultName, checkExtension);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private final FileItem[] getActions(FilePopup popup, FileItem[] fileList, String filename, int actionId, String defaultName, ValidExtensionCheck checkExtension)
/*     */   {
/*     */     try
/*     */     {
/*  36 */       filename = Parameters.dropStar(filename);
/*  37 */       if (fileList == null) {
/*  38 */         fileList = readFiles(filename, actionId, checkExtension);
/*     */       }
/*     */       
/*  41 */       if (defaultName != null) {
/*  42 */         popup.add(new ReActionActiveScreen(defaultName, actionId, filename));
/*     */       }
/*     */       
/*  45 */       for (int i = 0; i < fileList.length; i++) {
/*  46 */         if (fileList[i].action != null) {
/*  47 */           popup.add(fileList[i].action);
/*     */         } else {
/*  49 */           FilePopup newPopup = new FilePopup(fileList[i].filename);
/*  50 */           getActions(newPopup, null, fileList[i].filePathName, actionId, null, checkExtension);
/*  51 */           newPopup.setIcon(Common.getRecordIcon(51));
/*  52 */           popup.add(newPopup);
/*     */         }
/*     */       }
/*     */     } catch (Exception e) {
/*  56 */       Common.logMsgRaw(e.getMessage(), e);
/*  57 */       e.printStackTrace();
/*     */     }
/*  59 */     return fileList;
/*     */   }
/*     */   
/*     */ 
/*     */   private FileItem[] readFiles(String dirName, int actionId, ValidExtensionCheck checkExtension)
/*     */   {
/*  65 */     File[] fileList = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  70 */     if (dirName != null) {
/*  71 */       dirName = Parameters.dropStar(dirName);
/*     */       
/*  73 */       File dir = new File(dirName);
/*     */       
/*  75 */       fileList = dir.listFiles(); }
/*     */     FileItem[] files;
/*     */     FileItem[] files;
/*  78 */     if ((fileList == null) || (fileList.length == 0)) {
/*  79 */       files = new FileItem[0];
/*     */     } else {
/*  81 */       if ((dirName != null) && (!dirName.endsWith("/")) && (!dirName.endsWith("\\"))) {
/*  82 */         dirName = dirName + Common.FILE_SEPERATOR;
/*     */       }
/*  84 */       ArrayList<FileItem> items = new ArrayList(fileList.length);
/*     */       
/*  86 */       Arrays.sort(fileList, this);
/*  87 */       for (int i = 0; i < fileList.length; i++) {
/*  88 */         String fileName = fileList[i].getName();
/*  89 */         if ((!fileName.endsWith("~")) && (!fileName.toLowerCase().endsWith(".bak"))) {
/*     */           try
/*     */           {
/*  92 */             String filePathName = fileList[i].getCanonicalPath();
/*  93 */             boolean isDirectory = fileList[i].isDirectory();
/*  94 */             boolean addDirectory = false;
/*     */             
/*  96 */             if ((isDirectory) && (checkExtension != null)) {
/*  97 */               File[] dirFiles = fileList[i].listFiles();
/*     */               
/*     */ 
/* 100 */               if ((dirFiles != null) && (dirFiles.length > 0)) {
/* 101 */                 for (File f : dirFiles) {
/* 102 */                   if ((f != null) && ((f.isDirectory()) || (checkExtension.isValidExtension(Parameters.getExtensionOnly(f.getName()))))) {
/* 103 */                     addDirectory = true;
/* 104 */                     break;
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */             
/*     */ 
/*     */ 
/* 112 */             boolean ok = (checkExtension == null) || ((isDirectory) && (addDirectory)) || (checkExtension.isValidExtension(Parameters.getExtensionOnly(fileName)));
/*     */             
/*     */ 
/*     */ 
/* 116 */             if (ok) {
/* 117 */               AbstractAction action = null;
/* 118 */               if (!isDirectory) {
/* 119 */                 action = getAction(actionId, fileName, filePathName);
/*     */               }
/*     */               
/* 122 */               items.add(new FileItem(fileName, filePathName, action));
/*     */             }
/*     */           }
/*     */           catch (Exception e)
/*     */           {
/* 127 */             e.printStackTrace();
/*     */           }
/*     */         }
/*     */       }
/* 131 */       files = new FileItem[items.size()];
/* 132 */       files = (FileItem[])items.toArray(files);
/*     */     }
/* 134 */     return files;
/*     */   }
/*     */   
/*     */   protected AbstractAction getAction(int actionId, String filename, String filePathName) {
/* 138 */     return new ReActionActiveScreen(filename, actionId, filePathName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int compare(File o1, File o2)
/*     */   {
/* 151 */     if (o1.isDirectory() == o2.isDirectory())
/* 152 */       return o1.getName().compareTo(o2.getName());
/* 153 */     if (o1.isDirectory()) {
/* 154 */       return -1;
/*     */     }
/* 156 */     return 1;
/*     */   }
/*     */   
/*     */ 
/*     */   public static final class FileItem
/*     */   {
/*     */     public final String filename;
/*     */     public final String filePathName;
/*     */     public final AbstractAction action;
/*     */     
/*     */     public FileItem(String filename, String filePathName, AbstractAction action)
/*     */     {
/* 168 */       this.filename = filename;
/* 169 */       this.filePathName = filePathName;
/* 170 */       this.action = action;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/script/FilePopup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */