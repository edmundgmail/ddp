package net.sf.RecordEditor.re.script;

public abstract interface ValidExtensionCheck
{
  public abstract boolean isValidExtension(String paramString);
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/script/ValidExtensionCheck.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */