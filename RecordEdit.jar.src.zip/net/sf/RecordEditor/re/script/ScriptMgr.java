/*     */ package net.sf.RecordEditor.re.script;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.script.ScriptContext;
/*     */ import javax.script.ScriptEngine;
/*     */ import javax.script.ScriptEngineFactory;
/*     */ import javax.script.ScriptEngineManager;
/*     */ import javax.script.ScriptException;
/*     */ import net.sf.JRecord.Common.RecordRunTimeException;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ 
/*     */ public class ScriptMgr implements ValidExtensionCheck
/*     */ {
/*  26 */   private static final List<String> languages = new ArrayList();
/*  27 */   private static Map<String, String> languageExtension = null;
/*     */   
/*     */ 
/*  30 */   private ScriptEngineManager scriptManager = new ScriptEngineManager(getClass().getClassLoader());
/*     */   
/*     */ 
/*     */   public final void runScript(String script, ScriptData data)
/*     */     throws FileNotFoundException, ScriptException, IOException
/*     */   {
/*  36 */     String ext = Parameters.getExtensionOnly(script);
/*  37 */     ScriptEngine eng = this.scriptManager.getEngineByExtension(ext);
/*  38 */     if (eng == null) {
/*  39 */       eng = this.scriptManager.getEngineByExtension("." + ext);
/*     */     }
/*  41 */     runScript(eng, script, data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void runScript(String language, String script, ScriptData data)
/*     */     throws FileNotFoundException, ScriptException
/*     */   {
/*  59 */     runScript(this.scriptManager.getEngineByName(language), script, data);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void runScript(String script, ScriptData data, String scriptText, Writer writer)
/*     */     throws FileNotFoundException, ScriptException, IOException
/*     */   {
/*  69 */     String ext = Parameters.getExtensionOnly(script);
/*  70 */     ScriptEngine eng = this.scriptManager.getEngineByExtension(ext);
/*  71 */     if (eng == null) {
/*  72 */       eng = this.scriptManager.getEngineByExtension("." + ext);
/*     */     }
/*  74 */     runScript(eng, script, new StringReader(scriptText), data, writer);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void runScript(String language, String script, ScriptData data, String scriptText, Writer writer)
/*     */     throws FileNotFoundException, ScriptException
/*     */   {
/*  94 */     runScript(this.scriptManager.getEngineByName(language), script, new StringReader(scriptText), data, writer);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private final void runScript(ScriptEngine eng, String script, ScriptData data)
/*     */     throws FileNotFoundException, ScriptException
/*     */   {
/* 102 */     StringWriter w = new StringWriter();
/* 103 */     runScript(eng, script, new java.io.FileReader(script), data, w);
/*     */     
/* 105 */     if (w.getBuffer().length() > 0) {
/* 106 */       Common.logMsg("Script: " + script + " output:\n", null);
/* 107 */       Common.logMsg(w.toString(), null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final void runScript(ScriptEngine eng, String script, Reader r, ScriptData data, Writer writer)
/*     */     throws FileNotFoundException, ScriptException
/*     */   {
/* 119 */     if (eng == null) {
/* 120 */       throw new RecordRunTimeException("No Script Engine found !!! ");
/*     */     }
/* 122 */     if (data != null) {
/* 123 */       if (data.view != null) {
/* 124 */         eng.put("records", data.selectedLines);
/* 125 */         eng.put("file", data.fileLines);
/* 126 */         eng.put("view", data.viewLines);
/* 127 */         eng.put("layout", data.view.getLayout());
/*     */       }
/*     */       
/*     */ 
/* 131 */       eng.put("treeRoot", data.root);
/* 132 */       eng.put("treeNodes", data.nodes);
/* 133 */       eng.put("treeDepth", Integer.valueOf(data.treeDepth));
/* 134 */       eng.put("fileName", data.inputFile);
/* 135 */       eng.put("outputFile", data.outputFile);
/* 136 */       eng.put("onlyData", Boolean.valueOf(data.onlyData));
/* 137 */       eng.put("showBorder", Boolean.valueOf(data.showBorder));
/* 138 */       eng.put("recordIdx", Integer.valueOf(data.recordIdx));
/* 139 */       eng.put("RecordEditorData", data);
/*     */     }
/*     */     
/* 142 */     Writer w = eng.getContext().getWriter();
/*     */     try {
/* 144 */       if (writer == null) {
/* 145 */         eng.eval(r);
/*     */       } else {
/* 147 */         eng.getContext().setWriter(writer);
/* 148 */         eng.eval(r);
/*     */       }
/* 150 */       eng.eval(r);
/*     */     } finally {
/*     */       try {
/* 153 */         r.close();
/*     */       } catch (IOException e) {
/* 155 */         e.printStackTrace();
/*     */       }
/* 157 */       eng.getContext().setWriter(w);
/* 158 */       data.fireScreenChanged(false);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getEngineNameByExtension(String extension)
/*     */   {
/* 170 */     String s = "";
/* 171 */     ScriptEngine eng = getEngineByExtension(extension);
/* 172 */     if (eng != null) {
/* 173 */       s = eng.getFactory().getLanguageName();
/*     */     }
/* 175 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ScriptEngine getEngineByExtension(String extension)
/*     */   {
/* 184 */     return this.scriptManager.getEngineByExtension(extension);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isValidExtension(String extension)
/*     */   {
/* 193 */     return (extension != null) && (this.scriptManager.getEngineByExtension(extension) != null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<String> getLanguages()
/*     */   {
/* 203 */     loadLanguages();
/* 204 */     return languages;
/*     */   }
/*     */   
/*     */   public static String getExtension(String lang)
/*     */   {
/* 209 */     loadLanguages();
/* 210 */     String ret = (String)languageExtension.get(lang.toLowerCase());
/*     */     
/* 212 */     if (ret == null) {
/* 213 */       ret = "";
/* 214 */     } else if ((ret.length() > 0) && (!ret.startsWith("."))) {
/* 215 */       ret = "." + ret;
/*     */     }
/* 217 */     return ret;
/*     */   }
/*     */   
/*     */   private static void loadLanguages() {
/* 221 */     if (languageExtension == null) {
/* 222 */       synchronized (languages) {
/* 223 */         if (languageExtension == null) {
/* 224 */           ScriptEngineManager manager = new ScriptEngineManager(ScriptMgr.class.getClassLoader());
/* 225 */           List<ScriptEngineFactory> engines = manager.getEngineFactories();
/*     */           
/* 227 */           languageExtension = new HashMap();
/* 228 */           languageExtension.put("javascript", "js");
/* 229 */           languageExtension.put("python", "py");
/* 230 */           languageExtension.put("jython", "py");
/* 231 */           languageExtension.put("jruby", "rb");
/* 232 */           languageExtension.put("ruby", "rb");
/* 233 */           for (ScriptEngineFactory engine : engines) {
/* 234 */             languages.add(engine.getLanguageName());
/* 235 */             List<String> extensions = engine.getExtensions();
/* 236 */             if ((extensions != null) && (extensions.size() > 0)) {
/* 237 */               languageExtension.put(engine.getLanguageName().toLowerCase(), extensions.get(0));
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static List<String[]> getLanguageExt()
/*     */   {
/* 252 */     List<String[]> ret = new ArrayList();
/*     */     
/* 254 */     ScriptEngineManager manager = new ScriptEngineManager(ScriptMgr.class.getClassLoader());
/* 255 */     List<ScriptEngineFactory> engines = manager.getEngineFactories();
/*     */     
/* 257 */     for (Iterator i$ = engines.iterator(); i$.hasNext();) { engine = (ScriptEngineFactory)i$.next();
/* 258 */       List<String> extensions = engine.getExtensions();
/* 259 */       for (String s : extensions) {
/* 260 */         String[] r = { s, engine.getLanguageName() };
/* 261 */         ret.add(r);
/*     */       }
/*     */     }
/*     */     ScriptEngineFactory engine;
/* 265 */     return ret;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/script/ScriptMgr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */