/*    */ package net.sf.RecordEditor.re.script;
/*    */ 
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*    */ import net.sf.RecordEditor.utils.params.ProgramOptions.FileNameOptWithDefault;
/*    */ import net.sf.RecordEditor.utils.params.ProgramOptions.InternalBoolOption;
/*    */ 
/*    */ public class XsltPopup extends FilePopup implements Runnable
/*    */ {
/* 10 */   private static FilePopup.FileItem[] fileList = null;
/*    */   
/*    */   public XsltPopup() {
/* 13 */     super("Export via Xsl Transform");
/* 14 */     setIcon(Common.getReActionIcon(56));
/*    */     
/* 16 */     javax.swing.SwingUtilities.invokeLater(this);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void run()
/*    */   {
/*    */     try
/*    */     {
/* 26 */       fileList = getActions(fileList, Common.OPTIONS.DEFAULT_XSLT_DIRECTORY.get(), 56, "(Transform)", null);
/*    */ 
/*    */ 
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/*    */ 
/* 33 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */   
/*    */   public static final XsltPopup getPopup() {
/* 38 */     XsltPopup ret = null;
/* 39 */     if (Common.OPTIONS.xsltAvailable.isSelected()) {
/* 40 */       ret = new XsltPopup();
/*    */     }
/* 42 */     return ret;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/script/XsltPopup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */