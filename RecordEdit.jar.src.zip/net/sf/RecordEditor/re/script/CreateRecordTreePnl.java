/*     */ package net.sf.RecordEditor.re.script;
/*     */ 
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.table.AbstractTableModel;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.RecordEditor.jibx.compare.EditorTask;
/*     */ import net.sf.RecordEditor.jibx.compare.RecordParent;
/*     */ import net.sf.RecordEditor.jibx.compare.RecordTree;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.edit.RecordList;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.msg.UtMessages;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMsg;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.BmKeyedComboBox;
/*     */ import net.sf.RecordEditor.utils.swing.BmKeyedComboBoxRender;
/*     */ import net.sf.RecordEditor.utils.swing.BmKeyedComboModel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.swing.saveRestore.ISaveUpdateDetails;
/*     */ import net.sf.RecordEditor.utils.swing.saveRestore.SaveLoadPnl;
/*     */ 
/*     */ public class CreateRecordTreePnl implements ISaveUpdateDetails<EditorTask>
/*     */ {
/*     */   private static final int PARENT_INDEX = 1;
/*  32 */   public static final Integer BLANK_PARENT = Integer.valueOf(-1);
/*     */   
/*  34 */   private static final String[] LAYOUT_COLUMN_HEADINGS = LangConversion.convertColHeading("Create_Record_Tree", new String[] { "Record", "Parent Record" });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  40 */   public final BaseHelpPanel panel = new BaseHelpPanel();
/*     */   
/*  42 */   private LayoutTblMdl recordMdl = new LayoutTblMdl(null);
/*  43 */   public final JTable recordTbl = new JTable(this.recordMdl);
/*     */   
/*  45 */   public final JButton execute = SwingUtils.newButton("Build", Common.getRecordIcon(18));
/*     */   
/*     */ 
/*     */   private AbstractLayoutDetails layout;
/*     */   
/*     */   private Integer[] parent;
/*     */   
/*     */ 
/*     */   public CreateRecordTreePnl()
/*     */   {
/*  55 */     init_200_FormatScreen(false, 10);
/*     */   }
/*     */   
/*     */ 
/*     */   public CreateRecordTreePnl(AbstractLayoutDetails layoutDetails, boolean addSave)
/*     */   {
/*  61 */     setLayout(layoutDetails);
/*     */     
/*  63 */     init_200_FormatScreen(addSave, this.recordTbl.getRowCount());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setLayout(AbstractLayoutDetails layoutDetails)
/*     */   {
/*  72 */     this.layout = layoutDetails;
/*  73 */     this.parent = new Integer[this.layout.getRecordCount()];
/*  74 */     for (int i = 0; i < this.parent.length; i++) {
/*  75 */       this.parent[i] = BLANK_PARENT;
/*     */     }
/*     */     
/*  78 */     init_100_ScreenFields();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final AbstractLayoutDetails getLayout()
/*     */   {
/*  85 */     return this.layout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_100_ScreenFields()
/*     */   {
/*  94 */     RecordList records = new RecordList(this.layout, false, true, true);
/*  95 */     BmKeyedComboBox editor = new BmKeyedComboBox(new BmKeyedComboModel(records), false);
/*     */     
/*  97 */     this.panel.registerComponentRE(editor);
/*     */     
/*  99 */     TableColumn tc = this.recordTbl.getColumnModel().getColumn(1);
/* 100 */     tc.setCellRenderer(new BmKeyedComboBoxRender(new BmKeyedComboModel(records), false));
/* 101 */     tc.setCellEditor(new javax.swing.DefaultCellEditor(editor));
/*     */     
/* 103 */     this.recordTbl.setRowHeight(SwingUtils.COMBO_TABLE_ROW_HEIGHT);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_200_FormatScreen(boolean addSave, int recs)
/*     */   {
/* 113 */     int height = SwingUtils.calculateComboTableHeight(recs, ReFrame.getDesktopHeight() / 2);
/*     */     
/*     */ 
/*     */ 
/* 117 */     this.panel.setHelpURLre(Common.formatHelpURL("HlpRe13.htm"));
/*     */     
/* 119 */     this.panel.addComponentRE(1, 5, height, BasePanel.GAP1, 2, 2, this.recordTbl);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 124 */     this.panel.setComponentName(this.recordTbl, "Recs");
/*     */     
/* 126 */     if (addSave) {
/* 127 */       SaveLoadPnl<EditorTask> saveLoad = new SaveLoadPnl(this, Parameters.getFileName("RecordTreeSaveDirectory"), EditorTask.class);
/*     */       
/*     */ 
/*     */ 
/* 131 */       this.panel.addLineRE("", saveLoad.panel, SwingUtils.getPanelWith(this.execute));
/*     */     }
/* 133 */     this.panel.setGapRE(BasePanel.GAP2);
/*     */     
/* 135 */     this.panel.addMessageRE();
/*     */     
/* 137 */     this.panel.done();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final EditorTask getSaveDetails()
/*     */   {
/* 151 */     RecordTree tree = new RecordTree();
/*     */     
/*     */ 
/* 154 */     Common.stopCellEditing(this.recordTbl);
/* 155 */     int size = 0;
/* 156 */     for (int i = 0; i < this.parent.length; i++) {
/* 157 */       if (this.parent[i] != BLANK_PARENT) {
/* 158 */         size++;
/*     */       }
/*     */     }
/*     */     
/* 162 */     int j = 0;
/* 163 */     tree.parentRelationship = new RecordParent[size];
/* 164 */     for (i = 0; i < this.parent.length; i++) {
/* 165 */       if (this.parent[i] != BLANK_PARENT) {
/* 166 */         tree.parentRelationship[j] = new RecordParent();
/* 167 */         tree.parentRelationship[j].recordName = this.layout.getRecord(i).getRecordName();
/*     */         
/* 169 */         tree.parentRelationship[(j++)].parentName = this.layout.getRecord(this.parent[i].intValue()).getRecordName();
/*     */       }
/*     */     }
/*     */     
/* 173 */     return new EditorTask().setRecordTree(this.layout.getLayoutName(), tree);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void update(EditorTask serialisedData)
/*     */   {
/* 185 */     if ((serialisedData == null) || (serialisedData.recordTree == null)) {
/* 186 */       Common.logMsgRaw(UtMessages.NOT_A_RECORD_TREE.get(), null);
/*     */     } else {
/* 188 */       setFromSavedDetails(serialisedData.recordTree);
/* 189 */       this.recordMdl.fireTableDataChanged();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setFromSavedDetails(EditorTask saveDetails)
/*     */   {
/* 198 */     setFromSavedDetails(saveDetails.recordTree);
/*     */   }
/*     */   
/*     */   public final void setFromSavedDetails(RecordTree recordTree)
/*     */   {
/* 203 */     RecordParent[] parentRel = recordTree.parentRelationship;
/*     */     
/* 205 */     if (parentRel != null)
/*     */     {
/* 207 */       for (int i = 0; i < parentRel.length; i++) {
/* 208 */         int idx = this.layout.getRecordIndex(parentRel[i].recordName);
/* 209 */         if (idx >= 0) {
/* 210 */           this.parent[idx] = Integer.valueOf(this.layout.getRecordIndex(parentRel[i].parentName));
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private class LayoutTblMdl
/*     */     extends AbstractTableModel
/*     */   {
/*     */     private LayoutTblMdl() {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getColumnCount()
/*     */     {
/* 232 */       return CreateRecordTreePnl.LAYOUT_COLUMN_HEADINGS.length;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getColumnName(int columnIndex)
/*     */     {
/* 240 */       return CreateRecordTreePnl.LAYOUT_COLUMN_HEADINGS[columnIndex];
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getRowCount()
/*     */     {
/* 248 */       if (CreateRecordTreePnl.this.layout == null) {
/* 249 */         return 0;
/*     */       }
/* 251 */       return CreateRecordTreePnl.this.layout.getRecordCount();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Object getValueAt(int rowIndex, int columnIndex)
/*     */     {
/* 259 */       if (columnIndex == 1) {
/* 260 */         return CreateRecordTreePnl.this.parent[rowIndex];
/*     */       }
/* 262 */       return CreateRecordTreePnl.this.layout.getRecord(rowIndex).getRecordName();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isCellEditable(int rowIndex, int columnIndex)
/*     */     {
/* 270 */       return columnIndex == 1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setValueAt(Object aValue, int rowIndex, int columnIndex)
/*     */     {
/* 279 */       if (aValue == null) {
/* 280 */         CreateRecordTreePnl.this.parent[rowIndex] = CreateRecordTreePnl.BLANK_PARENT;
/* 281 */       } else if ((aValue instanceof Integer)) {
/* 282 */         CreateRecordTreePnl.this.parent[rowIndex] = ((Integer)aValue);
/*     */       } else {
/* 284 */         CreateRecordTreePnl.this.parent[rowIndex] = new Integer(aValue.toString());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final BaseHelpPanel getPanel()
/*     */   {
/* 293 */     return this.panel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final Integer[] getParent()
/*     */   {
/* 300 */     return this.parent;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void setParent(Integer[] parent)
/*     */   {
/* 307 */     this.parent = parent;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/script/CreateRecordTreePnl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */