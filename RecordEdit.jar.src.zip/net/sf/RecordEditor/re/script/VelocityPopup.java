/*    */ package net.sf.RecordEditor.re.script;
/*    */ 
/*    */ import javax.swing.SwingUtilities;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*    */ import net.sf.RecordEditor.utils.params.ProgramOptions.FileNameOptWithDefault;
/*    */ 
/*    */ public class VelocityPopup
/*    */   extends FilePopup implements Runnable
/*    */ {
/* 11 */   private static FilePopup.FileItem[] fileList = null;
/*    */   private final String velocityDir;
/*    */   
/*    */   public VelocityPopup(String velocityDirectory)
/*    */   {
/* 16 */     super("Export via Velociy Skelton");
/* 17 */     setIcon(Common.getReActionIcon(5));
/* 18 */     this.velocityDir = velocityDirectory;
/* 19 */     SwingUtilities.invokeLater(this);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void run()
/*    */   {
/*    */     try
/*    */     {
/* 30 */       fileList = getActions(fileList, this.velocityDir, 5, "(Velocity)", null);
/*    */ 
/*    */ 
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/*    */ 
/* 37 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */   
/*    */   public static final VelocityPopup getPopup()
/*    */   {
/* 43 */     VelocityPopup ret = null;
/* 44 */     if (Common.isVelocityAvailable()) {
/* 45 */       ret = new VelocityPopup(Common.OPTIONS.DEFAULT_VELOCITY_DIRECTORY.get());
/*    */     }
/* 47 */     return ret;
/*    */   }
/*    */   
/*    */   public static final VelocityPopup getLayoutPopup() {
/* 51 */     VelocityPopup ret = null;
/* 52 */     if (Common.isVelocityAvailable()) {
/* 53 */       ret = new VelocityPopup(Common.OPTIONS.copybookVelocityDirectory.get());
/*    */     }
/* 55 */     return ret;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/script/VelocityPopup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */