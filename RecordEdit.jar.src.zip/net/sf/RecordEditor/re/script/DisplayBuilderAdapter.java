/*    */ package net.sf.RecordEditor.re.script;
/*    */ 
/*    */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*    */ import net.sf.JRecord.Details.AbstractLine;
/*    */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*    */ import net.sf.RecordEditor.re.display.AbstractFileDisplayWithFieldHide;
/*    */ import net.sf.RecordEditor.re.display.IDisplayBuilder;
/*    */ import net.sf.RecordEditor.re.display.IDisplayFrame;
/*    */ import net.sf.RecordEditor.re.file.AbstractLineNode;
/*    */ import net.sf.RecordEditor.re.file.FileView;
/*    */ import net.sf.RecordEditor.re.tree.AbstractLineNodeTreeParser;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DisplayBuilderAdapter
/*    */   implements IDisplayBuilder
/*    */ {
/*    */   public AbstractFileDisplayWithFieldHide newDisplay(int screenType, String screenName, IDisplayFrame<? extends AbstractFileDisplay> parentFrame, AbstractLayoutDetails group, FileView viewOfFile, int lineNo)
/*    */   {
/* 31 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public AbstractFileDisplayWithFieldHide newDisplay(int screenType, String screenName, IDisplayFrame<? extends AbstractFileDisplay> parentFrame, AbstractLayoutDetails group, FileView viewOfFile, AbstractLine line)
/*    */   {
/* 43 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public AbstractFileDisplayWithFieldHide newDisplay(int screenType, IDisplayFrame<? extends AbstractFileDisplay> parentFrame, AbstractLayoutDetails group, FileView viewOfFile, AbstractLineNodeTreeParser treeParser, boolean mainView, int columnsToSkip)
/*    */   {
/* 55 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public AbstractFileDisplayWithFieldHide newLineTreeChildScreen(int screenType, IDisplayFrame df, FileView viewOfFile, AbstractLineNode rootNode, boolean mainView, int columnsToSkip)
/*    */   {
/* 66 */     return null;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/re/script/DisplayBuilderAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */