/*     */ package net.sf.RecordEditor.diff;
/*     */ 
/*     */ import java.awt.Container;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import net.sf.RecordEditor.re.openFile.AbstractLayoutSelectCreator;
/*     */ import net.sf.RecordEditor.re.openFile.AbstractLayoutSelection;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MenuInternalLayout
/*     */   extends ReFrame
/*     */   implements ActionListener
/*     */ {
/*  45 */   private static final int MENU_WIDTH = SwingUtils.STANDARD_FONT_WIDTH * 57;
/*  46 */   private static final int HELP_GAP = SwingUtils.STANDARD_FONT_HEIGHT + 2;
/*     */   
/*  48 */   private JComboBox dbCombo = new JComboBox();
/*     */   
/*  50 */   private JButton fromFileBtn = new JButton("*");
/*  51 */   private JButton compare = new JButton("*");
/*     */   
/*  53 */   private JButton btnHelp = SwingUtils.getHelpButton();
/*     */   
/*  55 */   private BaseHelpPanel pnl = new BaseHelpPanel();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String rFiles;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private AbstractLayoutSelectCreator layoutCreator;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MenuInternalLayout(AbstractLayoutSelectCreator creator, String recentFiles)
/*     */   {
/*  73 */     super("", "Menu", "Compare Menu", null);
/*     */     
/*     */ 
/*  76 */     this.layoutCreator = creator;
/*  77 */     this.rFiles = recentFiles;
/*  78 */     AbstractLayoutSelection selection = this.layoutCreator.create();
/*     */     
/*     */ 
/*  81 */     this.pnl.setVerticalGap(6, HELP_GAP);
/*     */     
/*  83 */     this.pnl.setHelpURLre(Common.formatHelpURL("diff.html"));
/*     */     
/*  85 */     String[] dbs = selection.getDataBaseNames();
/*     */     
/*  87 */     this.pnl.setGapRE(BasePanel.GAP1);
/*  88 */     if (dbs != null) {
/*  89 */       for (int i = 0; (i < dbs.length) && (dbs[i] != null) && (!dbs[i].equals("")); i++) {
/*  90 */         this.dbCombo.addItem(dbs[i]);
/*     */       }
/*  92 */       this.dbCombo.setSelectedIndex(Common.getConnectionIndex());
/*  93 */       this.pnl.addLineRE("Data Base", this.dbCombo, this.btnHelp);
/*     */     }
/*     */     
/*  96 */     this.pnl.setGapRE(BasePanel.GAP3);
/*     */     
/*  98 */     this.pnl.addMenuItemRE("Run Stored Compare", this.fromFileBtn);
/*  99 */     this.pnl.setGapRE(BasePanel.GAP1);
/* 100 */     this.pnl.addMenuItemRE("Compare 2 Files", this.compare);
/*     */     
/* 102 */     this.pnl.setGapRE(BasePanel.GAP3);
/*     */     
/*     */ 
/* 105 */     this.btnHelp.addActionListener(this);
/* 106 */     this.fromFileBtn.addActionListener(this);
/* 107 */     this.compare.addActionListener(this);
/*     */     
/* 109 */     setDefaultCloseOperation(2);
/*     */     
/* 111 */     this.dbCombo.requestFocusInWindow();
/*     */     
/*     */ 
/*     */ 
/* 115 */     getContentPane().add(this.pnl);
/*     */     
/* 117 */     pack();
/*     */     
/* 119 */     setBounds(getY(), getX(), MENU_WIDTH, getHeight());
/*     */     
/* 121 */     show();
/*     */     
/* 123 */     this.dbCombo.addActionListener(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void actionPerformed(ActionEvent e)
/*     */   {
/* 134 */     if (e.getSource() == this.fromFileBtn) {
/* 135 */       new RunSavedCompare(this.layoutCreator, this.dbCombo.getSelectedIndex(), this.rFiles);
/* 136 */     } else if (e.getSource() == this.btnHelp) {
/* 137 */       this.pnl.showHelpRE();
/* 138 */     } else if (e.getSource() == this.dbCombo) {
/* 139 */       Common.setConnectionId(this.dbCombo.getSelectedIndex());
/*     */     } else {
/* 141 */       AbstractLayoutSelection selection1 = this.layoutCreator.create();
/* 142 */       AbstractLayoutSelection selection2 = this.layoutCreator.create();
/*     */       
/* 144 */       selection1.setDatabaseIdx(this.dbCombo.getSelectedIndex());
/* 145 */       selection2.setDatabaseIdx(this.dbCombo.getSelectedIndex());
/*     */       
/* 147 */       if (e.getSource() == this.compare) {
/* 148 */         new CompareInternalLayout(selection1, selection2, this.rFiles);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void executeAction(int action)
/*     */   {
/* 159 */     if (action == 23) {
/* 160 */       this.pnl.showHelpRE();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isActionAvailable(int action)
/*     */   {
/* 170 */     return action == 23;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/diff/MenuInternalLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */