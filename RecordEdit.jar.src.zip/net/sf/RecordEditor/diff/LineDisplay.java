/*     */ package net.sf.RecordEditor.diff;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.table.DefaultTableCellRenderer;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LineDisplay
/*     */   extends AbstractCompareDisplay
/*     */ {
/*  34 */   private static Color ADDED_COLOR = Color.yellow;
/*  35 */   private static Color DELETED_COLOR = Color.cyan;
/*  36 */   private static Color MODIFIED_COLOR = Color.green;
/*     */   
/*     */   private CmpLineModel model;
/*     */   
/*  40 */   private JButton[] btn = new JButton[4];
/*  41 */   private String[] moveHints = LangConversion.convertArray(11, "RecordBtns", new String[] { "Start of File", "Previous Record", "Next Record", "Last Record" });
/*     */   
/*     */ 
/*     */ 
/*  45 */   private ActionListener lineListner = new ActionListener()
/*     */   {
/*     */ 
/*     */     public void actionPerformed(ActionEvent event)
/*     */     {
/*  50 */       if (event.getSource() == LineDisplay.this.btn[0]) {
/*  51 */         LineDisplay.this.setCurrRow(0);
/*  52 */         LineDisplay.this.rowChanged();
/*  53 */       } else if (event.getSource() == LineDisplay.this.btn[1]) {
/*  54 */         if (LineDisplay.this.getCurrRow() > 0) {
/*  55 */           LineDisplay.this.setCurrRow(LineDisplay.this.getCurrRow() - 1);
/*  56 */           LineDisplay.this.rowChanged();
/*     */         }
/*  58 */       } else if (event.getSource() == LineDisplay.this.btn[2]) {
/*  59 */         if (LineDisplay.this.getCurrRow() < LineDisplay.this.displayBefore.size() - 1)
/*     */         {
/*     */ 
/*  62 */           LineDisplay.this.setCurrRow(LineDisplay.this.getCurrRow() + 1);
/*  63 */           LineDisplay.this.rowChanged();
/*     */         }
/*     */       }
/*  66 */       else if (event.getSource() == LineDisplay.this.btn[3]) {
/*  67 */         LineDisplay.this.setCurrRow(LineDisplay.this.displayBefore.size() - 1);
/*  68 */         LineDisplay.this.rowChanged();
/*     */       }
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LineDisplay(String name, AbstractLayoutDetails recordLayout, ArrayList<LineCompare> before, ArrayList<LineCompare> after, ArrayList<LineCompare> chgBefore, ArrayList<LineCompare> chgAfter, boolean primary, boolean allRows)
/*     */   {
/*  91 */     super("Record Display ", name, recordLayout, before, after, chgBefore, chgAfter, primary, allRows);
/*     */     
/*     */ 
/*  94 */     ImageIcon[] icon = Common.getArrowIcons();
/*  95 */     JPanel btnPanel = new JPanel();
/*  96 */     for (int i = 0; i < this.btn.length; i++) {
/*  97 */       this.btn[i] = new JButton("", icon[i]);
/*  98 */       btnPanel.add(this.btn[i]);
/*  99 */       this.btn[i].addActionListener(this.lineListner);
/* 100 */       this.btn[i].setToolTipText(this.moveHints[i]);
/*     */     }
/* 102 */     super.setDisplayFields(1);
/*     */     
/* 104 */     init_100_SetupJtables();
/*     */     
/* 106 */     this.pnl.addComponentRE(1, 5, -1.0D, BasePanel.GAP, 2, 2, this.tblDetails);
/*     */     
/*     */ 
/*     */ 
/* 110 */     this.pnl.addComponentRE(1, 5, -2.0D, BasePanel.GAP, 2, 2, btnPanel);
/*     */     
/*     */ 
/*     */ 
/* 114 */     addMainComponent(this.pnl);
/*     */     
/*     */ 
/* 117 */     pack();
/* 118 */     setBounds(1, 1, Math.min(getWidth() + 200, this.screenSize.width - 1), getHeight());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 123 */     this.model.setRecordIdx(Integer.MAX_VALUE);
/* 124 */     super.setLayoutIndex(this.model.getRecordIdx());
/*     */     
/* 126 */     setVisible(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_100_SetupJtables()
/*     */   {
/* 134 */     Render cellRenderer = new Render();
/* 135 */     this.model = new CmpLineModel(this.layout, this.displayBefore, this.displayAfter);
/*     */     
/* 137 */     setDisplay(this.displayType);
/* 138 */     this.tblDetails = new JTable(this.model);
/* 139 */     this.tblDetails.setAutoResizeMode(0);
/* 140 */     Common.calcColumnWidths(this.tblDetails, 0, 220);
/*     */     
/* 142 */     this.tblDetails.getColumnModel().getColumn(3).setCellRenderer(cellRenderer);
/* 143 */     this.tblDetails.getColumnModel().getColumn(4).setCellRenderer(cellRenderer);
/*     */     
/* 145 */     int tblHeight = this.layout.getOption(11);
/*     */     
/* 147 */     if ((tblHeight <= 1) && (this.displayAfter.size() > 0))
/*     */     {
/* 149 */       int i = 0;
/* 150 */       AbstractLine line; while ((line = ((LineCompare)this.displayAfter.get(i)).line) == null) {
/* 151 */         i++;
/*     */       }
/* 153 */       if (line != null) {
/* 154 */         tblHeight = line.getLayout().getOption(11);
/*     */       }
/*     */     }
/* 157 */     if (tblHeight > 1) {
/* 158 */       this.tblDetails.setRowHeight(tblHeight * SwingUtils.TABLE_ROW_HEIGHT);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDisplay(int type)
/*     */   {
/* 169 */     super.setDisplay(type);
/*     */     
/* 171 */     this.model.setCurrentRow(Math.min(this.model.getCurrentRow(), this.displayBefore.size()));
/* 172 */     this.model.setDisplayRows(this.displayBefore, this.displayAfter);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void changeLayout()
/*     */   {
/* 180 */     if (this.model != null) {
/* 181 */       this.model.setRecordIdx(getLayoutIndex());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void setDisplayFields(int fieldDisplay)
/*     */   {
/* 188 */     this.model.setDisplayChangedFields(fieldDisplay == 2);
/* 189 */     super.setDisplayFields(fieldDisplay);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCurrRow()
/*     */   {
/* 199 */     return this.model.getCurrentRow();
/*     */   }
/*     */   
/*     */   public void setCurrRow(int newRow) {
/* 203 */     this.model.setCurrentRow(newRow);
/*     */   }
/*     */   
/*     */   public void rowChanged()
/*     */   {
/* 208 */     super.setLayoutIndex(this.model.getRecordIdx());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCurrRow(int newRow, int layoutId, int fieldNum) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private class Render
/*     */     implements TableCellRenderer
/*     */   {
/* 225 */     private DefaultTableCellRenderer text = new DefaultTableCellRenderer();
/*     */     
/*     */     public Render() {
/* 228 */       this.text.setBorder(null);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Component getTableCellRendererComponent(JTable tbl, Object value, boolean isCellSelected, boolean hasFocus, int row, int column)
/*     */     {
/* 242 */       if (value == null) {
/* 243 */         this.text.setText("");
/*     */       } else {
/* 245 */         this.text.setText(value.toString());
/*     */       }
/*     */       
/* 248 */       LineCompare cmp = LineDisplay.this.model.getCurrentCompareLine();
/* 249 */       Color color = Color.WHITE;
/*     */       
/* 251 */       if (row != 0) {
/* 252 */         if ((cmp == null) || (cmp.line == null)) {
/* 253 */           if (column == 4) {
/* 254 */             color = LineDisplay.ADDED_COLOR;
/*     */           }
/* 256 */         } else if ((cmp.code == 3) && (column == 3)) {
/* 257 */           color = LineDisplay.DELETED_COLOR;
/* 258 */         } else if ((cmp.code == 2) && (LineDisplay.this.model.isFieldChanged(row)))
/*     */         {
/* 260 */           color = LineDisplay.MODIFIED_COLOR; }
/*     */       }
/* 262 */       this.text.setBackground(color);
/*     */       
/* 264 */       return this.text;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/diff/LineDisplay.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */