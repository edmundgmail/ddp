/*    */ package net.sf.RecordEditor.diff;
/*    */ 
/*    */ import net.sf.RecordEditor.jibx.compare.DiffDefinition;
/*    */ import net.sf.RecordEditor.re.openFile.AbstractLayoutSelection;
/*    */ import net.sf.RecordEditor.re.util.wizard.TwoLayoutsWizard;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompareTwoLayouts
/*    */   extends TwoLayoutsWizard<DiffDefinition>
/*    */ {
/*    */   private CmpWizardFinal finalScreen;
/*    */   
/*    */   public CompareTwoLayouts(AbstractLayoutSelection selection1, AbstractLayoutSelection selection2, String recentFiles, boolean lookupRecentLayouts)
/*    */   {
/* 27 */     this(selection1, selection2, new DiffDefinition(), recentFiles, lookupRecentLayouts);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public CompareTwoLayouts(AbstractLayoutSelection selection1, AbstractLayoutSelection selection2, DiffDefinition definition, String recentFiles, boolean lookupRecentLayouts)
/*    */   {
/* 44 */     super("Two Layout Compare", definition);
/*    */     
/* 46 */     definition.type = "TwoLayouts";
/*    */     
/* 48 */     this.finalScreen = new CmpWizardFinal(selection1, selection2, lookupRecentLayouts);
/*    */     
/* 50 */     super.setUpPanels(selection1, selection2, recentFiles, this.finalScreen, "diff3.html", true, lookupRecentLayouts);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void finished(DiffDefinition details)
/*    */   {
/* 61 */     if (this.finalScreen.isToRun()) {
/* 62 */       this.finalScreen.run();
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/diff/CompareTwoLayouts.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */