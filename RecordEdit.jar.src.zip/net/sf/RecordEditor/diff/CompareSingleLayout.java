/*     */ package net.sf.RecordEditor.diff;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import net.sf.RecordEditor.jibx.JibxCall;
/*     */ import net.sf.RecordEditor.jibx.compare.DiffDefinition;
/*     */ import net.sf.RecordEditor.jibx.compare.Layout;
/*     */ import net.sf.RecordEditor.re.openFile.AbstractLayoutSelection;
/*     */ import net.sf.RecordEditor.re.util.wizard.AbstractFilePnl;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions.FileNameOpt;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.TreeComboFileSelect;
/*     */ import net.sf.RecordEditor.utils.wizards.AbstractWizard;
/*     */ import net.sf.RecordEditor.utils.wizards.AbstractWizardPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompareSingleLayout
/*     */   extends AbstractWizard<DiffDefinition>
/*     */ {
/*     */   private CmpWizardFinal finalScreen;
/*  28 */   private JibxCall<DiffDefinition> jibx = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CompareSingleLayout(AbstractLayoutSelection selection, String recentFiles)
/*     */   {
/*  36 */     this(selection, new DiffDefinition(), recentFiles);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CompareSingleLayout(String name, AbstractLayoutSelection selection, String recentFiles)
/*     */   {
/*  49 */     this(name, selection, new DiffDefinition(), recentFiles);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CompareSingleLayout(AbstractLayoutSelection selection, DiffDefinition definition, String recentFiles)
/*     */   {
/*  63 */     this("Single Layout Compare", selection, definition, recentFiles);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CompareSingleLayout(String name, AbstractLayoutSelection selection, DiffDefinition definition, String recentFiles)
/*     */   {
/*  76 */     super(name, definition);
/*     */     
/*  78 */     AbstractWizardPanel<DiffDefinition>[] pnls = new AbstractWizardPanel[3];
/*     */     
/*  80 */     selection.setMessage(super.getMessage());
/*     */     
/*  82 */     definition.type = "SingleLayout";
/*     */     
/*  84 */     this.finalScreen = new CmpWizardFinal(selection, null, true);
/*  85 */     pnls[0] = new GetFiles(selection, recentFiles);
/*  86 */     pnls[1] = new CmpFieldSelection(selection);
/*  87 */     pnls[2] = this.finalScreen;
/*     */     
/*  89 */     super.setPanels(pnls);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void finished(DiffDefinition details)
/*     */   {
/* 100 */     if (this.finalScreen.isToRun()) {
/* 101 */       this.finalScreen.run();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void executeAction(int action)
/*     */   {
/* 111 */     if (action == 1) {
/*     */       try {
/* 113 */         DiffDefinition diff = (DiffDefinition)super.getActivePanel().getValues();
/*     */         
/* 115 */         if (!"".equals(diff.saveFile)) {
/* 116 */           getJibx().unmarshal(diff.saveFile, diff);
/* 117 */           diff.fileSaved = true;
/*     */         }
/*     */       } catch (Exception e) {
/* 120 */         e.printStackTrace();
/* 121 */         Common.logMsgRaw(Common.FILE_SAVE_FAILED, e);
/*     */       }
/*     */     } else {
/* 124 */       super.executeAction(action);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isActionAvailable(int action)
/*     */   {
/* 133 */     if (action == 1) {
/* 134 */       return true;
/*     */     }
/* 136 */     return super.isActionAvailable(action);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private JibxCall<DiffDefinition> getJibx()
/*     */   {
/* 144 */     if (this.jibx == null) {
/* 145 */       this.jibx = new JibxCall(DiffDefinition.class);
/*     */     }
/* 147 */     return this.jibx;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class GetFiles
/*     */     extends AbstractFilePnl<DiffDefinition>
/*     */   {
/* 156 */     private DiffDefinition values = new DiffDefinition();
/*     */     
/*     */ 
/* 159 */     private TreeComboFileSelect newFileName = new TreeComboFileSelect(true, false, true, getRecentList(), getRecentDirectoryList());
/*     */     private AbstractLayoutSelection layoutSelection;
/*     */     
/*     */     public GetFiles(AbstractLayoutSelection selection, String recentFiles)
/*     */     {
/* 164 */       super(recentFiles);
/*     */       
/* 166 */       this.newFileName.setText(Common.OPTIONS.DEFAULT_FILE_DIRECTORY.getWithStar());
/* 167 */       this.layoutSelection = selection;
/*     */       
/* 169 */       setHelpURLre(Common.formatHelpURL("diff2.html"));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public DiffDefinition getValues()
/*     */       throws Exception
/*     */     {
/* 179 */       this.values.oldFile.name = getCurrentFileName();
/* 180 */       this.values.newFile.name = this.newFileName.getText();
/*     */       
/* 182 */       this.values.getLayoutDetails().name = this.layoutSelection.getLayoutName();
/* 183 */       if (this.layoutSelection.getRecordLayout(getCurrentFileName()) == null)
/* 184 */         throw new RuntimeException("Layout Does not exist");
/* 185 */       if (!new java.io.File(this.values.oldFile.name).exists()) {
/* 186 */         throw new RuntimeException("Layout Does not exist");
/*     */       }
/* 188 */       checkFile(this.values.oldFile.name, this.fileName);
/* 189 */       checkFile(this.values.newFile.name, this.newFileName);
/*     */       
/* 191 */       return this.values;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setValues(DiffDefinition detail)
/*     */       throws Exception
/*     */     {
/* 200 */       System.out.println("Setting Values ... ");
/* 201 */       this.values = detail;
/*     */       
/* 203 */       if (!"".equals(this.values.oldFile.name)) {
/* 204 */         this.fileName.setText(this.values.oldFile.name);
/*     */       }
/*     */       
/* 207 */       if (!"".equals(this.values.newFile.name)) {
/* 208 */         this.newFileName.setText(this.values.newFile.name);
/*     */       }
/*     */       
/* 211 */       if (!"".equals(this.values.getLayoutDetails().name)) {
/* 212 */         this.layoutSelection.setLayoutName(this.values.getLayoutDetails().name);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     protected void addFileName(BaseHelpPanel pnl)
/*     */     {
/* 219 */       pnl.addLineRE("Old File", this.fileName);
/*     */       
/* 221 */       pnl.addLineRE("New File", this.newFileName);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/diff/CompareSingleLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */