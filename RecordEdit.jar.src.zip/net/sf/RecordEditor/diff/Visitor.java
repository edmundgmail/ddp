/*     */ package net.sf.RecordEditor.diff;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import jlibdiff.Hunk;
/*     */ import jlibdiff.HunkAdd;
/*     */ import jlibdiff.HunkChange;
/*     */ import jlibdiff.HunkDel;
/*     */ 
/*     */ public class Visitor extends jlibdiff.HunkVisitor
/*     */ {
/*     */   private LineBufferedReader oldR;
/*     */   private LineBufferedReader newR;
/*     */   private ArrayList<LineCompare> oldList;
/*     */   private ArrayList<LineCompare> newList;
/*     */   private ArrayList<LineCompare> oldChanged;
/*     */   private ArrayList<LineCompare> newChanged;
/*  17 */   private int oldPos = 1;
/*  18 */   private int newPos = 1;
/*     */   
/*  20 */   private boolean fin = false;
/*     */   
/*     */   public Visitor(LineBufferedReader oldReader, LineBufferedReader newReader)
/*     */   {
/*  24 */     int size = Math.max(oldReader.getCount(), newReader.getCount());
/*  25 */     this.oldR = oldReader;
/*  26 */     this.newR = newReader;
/*     */     
/*  28 */     this.oldList = new ArrayList(size);
/*  29 */     this.newList = new ArrayList(size);
/*     */     
/*  31 */     this.oldChanged = new ArrayList(size / 2);
/*  32 */     this.newChanged = new ArrayList(size / 2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void visitHunkAdd(HunkAdd arg0)
/*     */   {
/*  41 */     copySkipped(arg0);
/*  42 */     copyNew(arg0.lowLine(1), arg0.highLine(1), 1);
/*  43 */     copyOld(arg0.highLine(0), arg0.highLine(0), 0);
/*  44 */     addNull(this.oldList, arg0.lowLine(1), arg0.highLine(1), 1);
/*     */     
/*     */ 
/*  47 */     copy(this.newChanged, this.newR, arg0.lowLine(1), arg0.highLine(1), 1);
/*  48 */     addNull(this.oldChanged, arg0.lowLine(1), arg0.highLine(1), 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void visitHunkChange(HunkChange arg0)
/*     */   {
/*  58 */     int oldDiff = arg0.highLine(0) - arg0.lowLine(0);
/*  59 */     int newDiff = arg0.highLine(1) - arg0.lowLine(1);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  68 */     copySkipped(arg0);
/*  69 */     copyOld(arg0.lowLine(0), arg0.highLine(0), 2);
/*  70 */     copyNew(arg0.lowLine(1), arg0.highLine(1), 2);
/*     */     
/*  72 */     copy(this.oldChanged, this.oldR, arg0.lowLine(0), arg0.highLine(0), 2);
/*     */     
/*  74 */     copy(this.newChanged, this.newR, arg0.lowLine(1), arg0.highLine(1), 2);
/*     */     
/*     */ 
/*  77 */     if (oldDiff > newDiff) {
/*  78 */       int count = oldDiff - newDiff;
/*  79 */       for (int i = 1; i <= count; i++) {
/*  80 */         ((LineCompare)this.oldChanged.get(this.oldChanged.size() - i)).code = 3;
/*  81 */         ((LineCompare)this.oldList.get(this.oldList.size() - i)).code = 3;
/*     */       }
/*  83 */       addNull(this.newChanged, 1, count, 3);
/*  84 */       addNull(this.newList, 1, count, 3);
/*  85 */     } else if (oldDiff < newDiff) {
/*  86 */       int count = newDiff - oldDiff;
/*  87 */       for (int i = 1; i <= count; i++) {
/*  88 */         ((LineCompare)this.newChanged.get(this.newChanged.size() - i)).code = 1;
/*  89 */         ((LineCompare)this.newList.get(this.newList.size() - i)).code = 1;
/*     */       }
/*  91 */       addNull(this.oldChanged, 1, count, 1);
/*  92 */       addNull(this.oldList, 1, count, 1);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void visitHunkDel(HunkDel arg0)
/*     */   {
/* 104 */     copySkipped(arg0);
/* 105 */     copyOld(arg0.lowLine(0), arg0.highLine(0), 3);
/* 106 */     copyNew(arg0.highLine(1), arg0.highLine(1), 0);
/* 107 */     addNull(this.newList, arg0.lowLine(0), arg0.highLine(0), 3);
/*     */     
/*     */ 
/* 110 */     copy(this.oldChanged, this.oldR, arg0.lowLine(0), arg0.highLine(0), 3);
/* 111 */     System.out.println("Delete Add Null " + (arg0.highLine(0) - arg0.lowLine(0) + 1) + " " + arg0.highLine(0) + " " + arg0.lowLine(0));
/*     */     
/* 113 */     addNull(this.newChanged, arg0.lowLine(0), arg0.highLine(0), 3);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void copySkipped(Hunk hunk)
/*     */   {
/* 120 */     copyOld(this.oldPos, hunk.lowLine(0) - 1, 0);
/*     */     
/*     */ 
/* 123 */     copyNew(this.newPos, hunk.lowLine(1) - 1, 0);
/*     */   }
/*     */   
/*     */   private void copyOld(int start, int end, int code)
/*     */   {
/* 128 */     copy(this.oldList, this.oldR, start, end, code);
/* 129 */     this.oldPos = (end + 1);
/*     */   }
/*     */   
/*     */   private void copyNew(int start, int end, int code)
/*     */   {
/* 134 */     copy(this.newList, this.newR, start, end, code);
/*     */     
/* 136 */     this.newPos = (end + 1);
/*     */   }
/*     */   
/*     */ 
/*     */   private void copy(ArrayList<LineCompare> list, LineBufferedReader reader, int start, int end, int code)
/*     */   {
/* 142 */     for (int i = Math.max(1, start); i <= end; i++)
/*     */     {
/*     */ 
/* 145 */       list.add(new LineCompare(code, i, reader.getLine(i - 1)));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void addNull(ArrayList<LineCompare> list, int start, int end, int code)
/*     */   {
/* 152 */     for (int i = Math.max(1, start); i <= end; i++) {
/* 153 */       list.add(null);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final ArrayList<LineCompare> getOldList()
/*     */   {
/* 164 */     check();
/* 165 */     return this.oldList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final ArrayList<LineCompare> getNewList()
/*     */   {
/* 173 */     check();
/* 174 */     return this.newList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final ArrayList<LineCompare> getOldChanged()
/*     */   {
/* 182 */     check();
/* 183 */     return this.oldChanged;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final ArrayList<LineCompare> getNewChanged()
/*     */   {
/* 191 */     check();
/* 192 */     return this.newChanged;
/*     */   }
/*     */   
/*     */   private void check()
/*     */   {
/* 197 */     if (!this.fin) {
/* 198 */       this.fin = true;
/* 199 */       int oldId = 3;
/* 200 */       int newId = 1;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 205 */       if (this.oldR.getCount() == this.newR.getCount()) {
/* 206 */         oldId = 0;
/* 207 */         newId = 0;
/*     */       }
/* 209 */       copyOld(this.oldPos, this.oldR.getCount(), oldId);
/* 210 */       copyNew(this.newPos, this.newR.getCount(), newId);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/diff/Visitor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */