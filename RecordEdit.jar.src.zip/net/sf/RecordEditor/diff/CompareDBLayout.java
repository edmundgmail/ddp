/*    */ package net.sf.RecordEditor.diff;
/*    */ 
/*    */ import net.sf.RecordEditor.re.openFile.LayoutSelectionDBCreator;
/*    */ import net.sf.RecordEditor.utils.CopyBookDbReader;
/*    */ import net.sf.RecordEditor.utils.CopyBookInterface;
/*    */ import net.sf.RecordEditor.utils.screenManager.ReMainFrame;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompareDBLayout
/*    */ {
/*    */   public static final void newMenu(CopyBookInterface cpyInterface)
/*    */   {
/* 18 */     new Menu(new LayoutSelectionDBCreator(cpyInterface), "Files.txt");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public static void main(String[] args)
/*    */   {
/* 27 */     new ReMainFrame("File Compare", "", "Cmp");
/* 28 */     newMenu(CopyBookDbReader.getInstance());
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/diff/CompareDBLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */