/*    */ package net.sf.RecordEditor.diff;
/*    */ 
/*    */ import net.sf.RecordEditor.re.openFile.LayoutSelectionFileCreator;
/*    */ import net.sf.RecordEditor.utils.screenManager.ReMainFrame;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CompareFileLayout
/*    */ {
/*    */   public static final void newMenu()
/*    */   {
/* 16 */     new Menu(new LayoutSelectionFileCreator(), "CobolFiles.txt");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static void main(String[] args)
/*    */   {
/* 24 */     new ReMainFrame("File Compare", "", "Cmp");
/* 25 */     newMenu();
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/diff/CompareFileLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */