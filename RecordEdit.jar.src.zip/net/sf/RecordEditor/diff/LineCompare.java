/*    */ package net.sf.RecordEditor.diff;
/*    */ 
/*    */ import net.sf.JRecord.Details.AbstractLine;
/*    */ 
/*    */ 
/*    */ public class LineCompare
/*    */ {
/*    */   public static final int UNCHANGED = 0;
/*    */   public static final int INSERT = 1;
/*    */   public static final int CHANGED = 2;
/*    */   public static final int DELETED = 3;
/*    */   protected final AbstractLine line;
/*    */   protected int lineNo;
/*    */   protected int code;
/*    */   
/*    */   public LineCompare(int lineCode, int lineNumber, AbstractLine actualLine)
/*    */   {
/* 18 */     this.line = actualLine;
/* 19 */     this.lineNo = lineNumber;
/* 20 */     this.code = lineCode;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/diff/LineCompare.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */