/*     */ package net.sf.RecordEditor.diff;
/*     */ 
/*     */ import java.awt.Container;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.JButton;
/*     */ import net.sf.RecordEditor.re.openFile.LayoutSelectionCsvCreator;
/*     */ import net.sf.RecordEditor.re.openFile.LayoutSelectionPoTipCreator;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MenuCsv
/*     */   extends ReFrame
/*     */   implements ActionListener
/*     */ {
/*  44 */   private static final int MENU_WIDTH = SwingUtils.STANDARD_FONT_WIDTH * 57;
/*     */   
/*     */   private static final int HELP_GAP = 15;
/*     */   
/*  48 */   private JButton csvCmp = new JButton("*");
/*  49 */   private JButton poCmpBtn = new JButton("*");
/*  50 */   private JButton tipCmpBtn = new JButton("*");
/*     */   
/*     */ 
/*     */ 
/*  54 */   private BaseHelpPanel pnl = new BaseHelpPanel();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String rFiles;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MenuCsv(String recentFiles)
/*     */   {
/*  68 */     super("", "Menu", "Compare Menu", null);
/*     */     
/*     */ 
/*  71 */     this.rFiles = recentFiles;
/*     */     
/*     */ 
/*  74 */     this.pnl.setVerticalGap(6, 15.0D);
/*     */     
/*  76 */     this.pnl.setHelpURLre(Common.formatHelpURL("diff.html"));
/*     */     
/*  78 */     this.pnl.setGapRE(BasePanel.GAP2);
/*     */     
/*  80 */     this.pnl.addMenuItemRE("Csv Compare", this.csvCmp);
/*  81 */     this.pnl.setGapRE(BasePanel.GAP1);
/*  82 */     this.pnl.addMenuItemRE("GetText-Po Compare", this.poCmpBtn);
/*  83 */     this.pnl.setGapRE(BasePanel.GAP1);
/*  84 */     this.pnl.addMenuItemRE("SwingX-Tip Compare", this.tipCmpBtn);
/*     */     
/*  86 */     this.pnl.setGapRE(BasePanel.GAP3);
/*     */     
/*     */ 
/*     */ 
/*  90 */     this.poCmpBtn.addActionListener(this);
/*  91 */     this.tipCmpBtn.addActionListener(this);
/*  92 */     this.csvCmp.addActionListener(this);
/*     */     
/*  94 */     setDefaultCloseOperation(2);
/*     */     
/*     */ 
/*  97 */     getContentPane().add(this.pnl);
/*     */     
/*  99 */     pack();
/*     */     
/* 101 */     setBounds(getY(), getX(), MENU_WIDTH, getHeight());
/*     */     
/* 103 */     show();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void actionPerformed(ActionEvent e)
/*     */   {
/* 112 */     if (e.getSource() == this.csvCmp) {
/* 113 */       LayoutSelectionCsvCreator csvl = new LayoutSelectionCsvCreator();
/* 114 */       new CompareTwoLayouts(csvl.create(), csvl.create(), this.rFiles, false);
/* 115 */     } else if (e.getSource() == this.poCmpBtn) {
/* 116 */       LayoutSelectionPoTipCreator newPoCreator = LayoutSelectionPoTipCreator.newPoCreator();
/* 117 */       new CompareSingleLayout("GetText-PO Compare Wizard -", newPoCreator.create(), this.rFiles);
/* 118 */     } else if (e.getSource() == this.tipCmpBtn) {
/* 119 */       LayoutSelectionPoTipCreator newTipCreator = LayoutSelectionPoTipCreator.newTipCreator();
/* 120 */       new CompareSingleLayout("SwingX-Tip Compare Wizard -", newTipCreator.create(), this.rFiles);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void executeAction(int action)
/*     */   {
/* 131 */     if (action == 23) {
/* 132 */       this.pnl.showHelpRE();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isActionAvailable(int action)
/*     */   {
/* 143 */     return action == 23;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/diff/MenuCsv.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */