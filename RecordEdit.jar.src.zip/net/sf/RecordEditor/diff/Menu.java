/*     */ package net.sf.RecordEditor.diff;
/*     */ 
/*     */ import java.awt.Container;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import net.sf.RecordEditor.re.openFile.AbstractLayoutSelectCreator;
/*     */ import net.sf.RecordEditor.re.openFile.AbstractLayoutSelection;
/*     */ import net.sf.RecordEditor.re.openFile.LayoutSelectionCsvCreator;
/*     */ import net.sf.RecordEditor.re.openFile.LayoutSelectionPoTipCreator;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Menu
/*     */   extends ReFrame
/*     */   implements ActionListener
/*     */ {
/*  47 */   private static final int MENU_WIDTH = SwingUtils.STANDARD_FONT_WIDTH * 57;
/*     */   
/*     */   private static final int HELP_GAP = 15;
/*  50 */   private JComboBox dbCombo = new JComboBox();
/*     */   
/*  52 */   private JButton fromFileBtn = new JButton("*");
/*  53 */   private JButton singleLayout = new JButton("*");
/*  54 */   private JButton twoLayouts = new JButton("*");
/*  55 */   private JButton csvCmp = new JButton("*");
/*  56 */   private JButton csvDbCmp = new JButton("*");
/*  57 */   private JButton poCmpBtn = new JButton("*");
/*  58 */   private JButton tipCmpBtn = new JButton("*");
/*     */   
/*  60 */   private JButton btnHelp = SwingUtils.getHelpButton();
/*     */   
/*  62 */   private BaseHelpPanel pnl = new BaseHelpPanel();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String rFiles;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private AbstractLayoutSelectCreator layoutCreator;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Menu(AbstractLayoutSelectCreator creator, String recentFiles)
/*     */   {
/*  80 */     super("", "Menu", "Compare Menu", null);
/*     */     
/*     */ 
/*  83 */     this.layoutCreator = creator;
/*  84 */     this.rFiles = recentFiles;
/*  85 */     AbstractLayoutSelection selection = this.layoutCreator.create();
/*     */     
/*     */ 
/*  88 */     this.pnl.setVerticalGap(6, 15.0D);
/*     */     
/*  90 */     this.pnl.setHelpURLre(Common.formatHelpURL("diff.html"));
/*     */     
/*  92 */     String[] dbs = selection.getDataBaseNames();
/*     */     
/*  94 */     this.pnl.setGapRE(BasePanel.GAP1);
/*  95 */     if (dbs != null) {
/*  96 */       for (int i = 0; (i < dbs.length) && (dbs[i] != null) && (!dbs[i].equals("")); i++) {
/*  97 */         this.dbCombo.addItem(dbs[i]);
/*     */       }
/*  99 */       this.dbCombo.setSelectedIndex(Common.getConnectionIndex());
/* 100 */       this.pnl.addLineRE("Data Base", this.dbCombo, this.btnHelp);
/*     */     }
/*     */     
/* 103 */     this.pnl.setGapRE(BasePanel.GAP3);
/*     */     
/* 105 */     this.pnl.addMenuItemRE("Run Stored Compare", this.fromFileBtn);
/* 106 */     this.pnl.setGapRE(BasePanel.GAP1);
/* 107 */     this.pnl.addMenuItemRE("Compare Single Layout", this.singleLayout);
/* 108 */     this.pnl.setGapRE(BasePanel.GAP1);
/* 109 */     this.pnl.addMenuItemRE("Compare Different Layouts", this.twoLayouts);
/* 110 */     this.pnl.setGapRE(BasePanel.GAP1);
/* 111 */     this.pnl.addMenuItemRE("Csv Compare", this.csvCmp);
/* 112 */     this.pnl.setGapRE(BasePanel.GAP1);
/* 113 */     this.pnl.addMenuItemRE("Layout to Csv Compare", this.csvDbCmp);
/* 114 */     this.pnl.setGapRE(BasePanel.GAP1);
/* 115 */     this.pnl.addMenuItemRE("GetText-Po Compare", this.poCmpBtn);
/* 116 */     this.pnl.setGapRE(BasePanel.GAP1);
/* 117 */     this.pnl.addMenuItemRE("SwingX-Tip Compare", this.tipCmpBtn);
/*     */     
/* 119 */     this.pnl.setGapRE(BasePanel.GAP3);
/*     */     
/*     */ 
/* 122 */     this.btnHelp.addActionListener(this);
/* 123 */     this.fromFileBtn.addActionListener(this);
/* 124 */     this.singleLayout.addActionListener(this);
/* 125 */     this.twoLayouts.addActionListener(this);
/* 126 */     this.csvCmp.addActionListener(this);
/* 127 */     this.csvDbCmp.addActionListener(this);
/* 128 */     this.tipCmpBtn.addActionListener(this);
/* 129 */     this.poCmpBtn.addActionListener(this);
/*     */     
/* 131 */     setDefaultCloseOperation(2);
/*     */     
/* 133 */     this.dbCombo.requestFocusInWindow();
/*     */     
/*     */ 
/*     */ 
/* 137 */     getContentPane().add(this.pnl);
/*     */     
/* 139 */     pack();
/*     */     
/* 141 */     setBounds(getY(), getX(), MENU_WIDTH, getHeight());
/*     */     
/* 143 */     show();
/*     */     
/* 145 */     this.dbCombo.addActionListener(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void actionPerformed(ActionEvent e)
/*     */   {
/* 155 */     if (e.getSource() == this.fromFileBtn) {
/* 156 */       new RunSavedCompare(this.layoutCreator, this.dbCombo.getSelectedIndex(), this.rFiles);
/* 157 */     } else if (e.getSource() == this.btnHelp) {
/* 158 */       this.pnl.showHelpRE();
/* 159 */     } else if (e.getSource() == this.dbCombo) {
/* 160 */       Common.setConnectionId(this.dbCombo.getSelectedIndex());
/* 161 */     } else if (e.getSource() == this.csvCmp) {
/* 162 */       LayoutSelectionCsvCreator csvl = new LayoutSelectionCsvCreator();
/* 163 */       new CompareTwoLayouts(csvl.create(), csvl.create(), this.rFiles, false);
/* 164 */     } else if (e.getSource() == this.csvDbCmp) {
/* 165 */       LayoutSelectionCsvCreator csvl = new LayoutSelectionCsvCreator();
/* 166 */       AbstractLayoutSelection selection1 = this.layoutCreator.create();
/* 167 */       selection1.setDatabaseIdx(this.dbCombo.getSelectedIndex());
/*     */       
/* 169 */       new CompareTwoLayouts(selection1, csvl.create(), this.rFiles, false);
/* 170 */     } else if (e.getSource() == this.poCmpBtn) {
/* 171 */       LayoutSelectionPoTipCreator newPoCreator = LayoutSelectionPoTipCreator.newPoCreator();
/* 172 */       new CompareSingleLayout("GetText-PO Compare Wizard -", newPoCreator.create(), this.rFiles);
/* 173 */     } else if (e.getSource() == this.tipCmpBtn) {
/* 174 */       LayoutSelectionPoTipCreator newTipCreator = LayoutSelectionPoTipCreator.newTipCreator();
/* 175 */       new CompareSingleLayout("SwingX-Tip Compare Wizard -", newTipCreator.create(), this.rFiles);
/*     */     } else {
/* 177 */       AbstractLayoutSelection selection = this.layoutCreator.create();
/* 178 */       selection.setDatabaseIdx(this.dbCombo.getSelectedIndex());
/*     */       
/* 180 */       if (e.getSource() == this.singleLayout) {
/* 181 */         new CompareSingleLayout(selection, this.rFiles);
/* 182 */       } else if (e.getSource() == this.twoLayouts) {
/* 183 */         AbstractLayoutSelection selection1 = this.layoutCreator.create();
/* 184 */         selection1.setDatabaseIdx(this.dbCombo.getSelectedIndex());
/*     */         
/* 186 */         new CompareTwoLayouts(selection, selection1, this.rFiles, true);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void executeAction(int action)
/*     */   {
/* 198 */     if (action == 23) {
/* 199 */       this.pnl.showHelpRE();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isActionAvailable(int action)
/*     */   {
/* 210 */     return action == 23;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/diff/Menu.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */