/*     */ package net.sf.RecordEditor.diff;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import net.sf.RecordEditor.jibx.JibxCall;
/*     */ import net.sf.RecordEditor.jibx.compare.DiffDefinition;
/*     */ import net.sf.RecordEditor.jibx.compare.File;
/*     */ import net.sf.RecordEditor.re.openFile.AbstractLayoutSelection;
/*     */ import net.sf.RecordEditor.re.util.wizard.AbstractFilePnl;
/*     */ import net.sf.RecordEditor.re.util.wizard.FieldChoice;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions.FileNameOpt;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.TreeComboFileSelect;
/*     */ import net.sf.RecordEditor.utils.wizards.AbstractWizard;
/*     */ import net.sf.RecordEditor.utils.wizards.AbstractWizardPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CompareInternalLayout
/*     */   extends AbstractWizard<DiffDefinition>
/*     */ {
/*     */   private CmpWizardFinal finalScreen;
/*  26 */   private JibxCall<DiffDefinition> jibx = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CompareInternalLayout(AbstractLayoutSelection selection1, AbstractLayoutSelection selection2, String recentFiles)
/*     */   {
/*  37 */     this(selection1, selection2, new DiffDefinition(), recentFiles);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CompareInternalLayout(AbstractLayoutSelection selection1, AbstractLayoutSelection selection2, DiffDefinition definition, String recentFiles)
/*     */   {
/*  55 */     super("File Compare", definition);
/*     */     
/*  57 */     AbstractWizardPanel<DiffDefinition>[] pnls = new AbstractWizardPanel[3];
/*     */     
/*  59 */     selection1.setMessage(super.getMessage());
/*     */     
/*  61 */     definition.type = "TwoLayouts";
/*     */     
/*  63 */     this.finalScreen = new CmpWizardFinal(selection1, selection2, true);
/*  64 */     pnls[0] = new GetFiles(selection1, selection2, recentFiles);
/*  65 */     pnls[1] = new FieldChoice(selection1, selection2, "");
/*  66 */     pnls[2] = this.finalScreen;
/*     */     
/*  68 */     super.setPanels(pnls);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void finished(DiffDefinition details)
/*     */   {
/*  79 */     if (this.finalScreen.isToRun()) {
/*  80 */       this.finalScreen.run();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void executeAction(int action)
/*     */   {
/*  92 */     if (action == 1) {
/*     */       try {
/*  94 */         DiffDefinition diff = (DiffDefinition)super.getActivePanel().getValues();
/*     */         
/*  96 */         if (!"".equals(diff.saveFile)) {
/*  97 */           getJibx().unmarshal(diff.saveFile, diff);
/*  98 */           diff.fileSaved = true;
/*     */         }
/*     */       } catch (Exception e) {
/* 101 */         e.printStackTrace();
/* 102 */         Common.logMsgRaw(Common.FILE_SAVE_FAILED, e);
/*     */       }
/*     */     } else {
/* 105 */       super.executeAction(action);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isActionAvailable(int action)
/*     */   {
/* 114 */     if (action == 1) {
/* 115 */       return true;
/*     */     }
/* 117 */     return super.isActionAvailable(action);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private JibxCall<DiffDefinition> getJibx()
/*     */   {
/* 125 */     if (this.jibx == null) {
/* 126 */       this.jibx = new JibxCall(DiffDefinition.class);
/*     */     }
/* 128 */     return this.jibx;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class GetFiles
/*     */     extends AbstractFilePnl<DiffDefinition>
/*     */   {
/* 137 */     private DiffDefinition values = new DiffDefinition();
/*     */     
/*     */ 
/* 140 */     private TreeComboFileSelect newFileName = new TreeComboFileSelect(true, false, true, getRecentList(), getRecentDirectoryList());
/*     */     private AbstractLayoutSelection layoutSelection1;
/*     */     private AbstractLayoutSelection layoutSelection2;
/*     */     
/*     */     public GetFiles(AbstractLayoutSelection selection1, AbstractLayoutSelection selection2, String recentFiles)
/*     */     {
/* 146 */       super(recentFiles);
/*     */       
/* 148 */       this.newFileName.setText(Common.OPTIONS.DEFAULT_FILE_DIRECTORY.get());
/* 149 */       this.layoutSelection1 = selection1;
/* 150 */       this.layoutSelection2 = selection2;
/*     */       
/* 152 */       this.layoutSelection1.setFileNameField(this.fileName);
/* 153 */       this.layoutSelection2.setFileNameField(this.newFileName);
/*     */       
/* 155 */       setHelpURLre(Common.formatHelpURL("diff2.html"));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public DiffDefinition getValues()
/*     */       throws Exception
/*     */     {
/* 165 */       this.values.oldFile.name = getCurrentFileName();
/* 166 */       this.values.newFile.name = this.newFileName.getText();
/*     */       
/* 168 */       this.values.oldFile.getLayoutDetails().name = this.layoutSelection1.getLayoutName();
/* 169 */       this.values.newFile.getLayoutDetails().name = this.layoutSelection2.getLayoutName();
/*     */       
/* 171 */       return this.values;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void setValues(DiffDefinition detail)
/*     */       throws Exception
/*     */     {
/* 179 */       System.out.println("Setting Values ... ");
/* 180 */       this.values = detail;
/*     */       
/* 182 */       this.layoutSelection1.setFileNameField(this.fileName);
/* 183 */       this.layoutSelection2.setFileNameField(this.newFileName);
/* 184 */       if (!"".equals(this.values.oldFile.name)) {
/* 185 */         this.fileName.setText(this.values.oldFile.name);
/*     */       }
/*     */       
/* 188 */       if (!"".equals(this.values.newFile.name)) {
/* 189 */         this.newFileName.setText(this.values.newFile.name);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void addFileName(BaseHelpPanel pnl)
/*     */     {
/* 201 */       pnl.addLineRE("Old File", this.fileName);
/* 202 */       pnl.addLineRE("New File", this.newFileName);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/diff/CompareInternalLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */