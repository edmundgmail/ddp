/*     */ package net.sf.RecordEditor.diff;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.table.AbstractTableModel;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail.FieldDetails;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CmpTableModel
/*     */   extends AbstractTableModel
/*     */ {
/*     */   public static final int BEFORE = 0;
/*     */   public static final int AFTER = 1;
/*     */   private ArrayList<LineCompare>[] displayRows;
/*     */   private AbstractLayoutDetails description;
/*  21 */   private int colCount = 0;
/*     */   
/*  23 */   private int recordIndex = 0;
/*     */   
/*  25 */   private int additionalFields = 3;
/*  26 */   private int keyIdx = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CmpTableModel(AbstractLayoutDetails layout, ArrayList<LineCompare> displayBefore, ArrayList<LineCompare> displayAfter)
/*     */   {
/*  36 */     this.displayRows = new ArrayList[2];
/*     */     
/*  38 */     this.description = layout;
/*     */     
/*  40 */     this.displayRows[0] = displayBefore;
/*  41 */     this.displayRows[1] = displayAfter;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  47 */     for (int i = 0; i < this.description.getRecordCount(); i++) {
/*  48 */       this.colCount = Math.max(this.colCount, this.description.getRecord(i).getFieldCount());
/*     */     }
/*     */     
/*  51 */     if (layout.isMapPresent()) {
/*  52 */       this.keyIdx = this.additionalFields;
/*  53 */       this.additionalFields += 1;
/*     */     }
/*  55 */     this.colCount += this.additionalFields;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getColumnCount()
/*     */   {
/*  61 */     if (this.recordIndex >= this.description.getRecordCount()) {
/*  62 */       return this.colCount;
/*     */     }
/*     */     
/*  65 */     return this.description.getRecord(this.recordIndex).getFieldCount() + this.additionalFields;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getRowCount()
/*     */   {
/*  71 */     return this.displayRows[0].size() * 2;
/*     */   }
/*     */   
/*     */ 
/*     */   public Object getValueAt(int rowIndex, int columnIndex)
/*     */   {
/*  77 */     int row = rowIndex / 2;
/*  78 */     int idx = rowIndex - row * 2;
/*     */     
/*  80 */     if (row >= this.displayRows[idx].size()) {
/*  81 */       return "";
/*     */     }
/*  83 */     LineCompare cmp = (LineCompare)this.displayRows[idx].get(row);
/*  84 */     if ((columnIndex == 0) || (cmp == null))
/*  85 */       return "";
/*  86 */     if ((columnIndex == 1) && (idx == 0)) {
/*  87 */       if (cmp.code == 3) {
/*  88 */         return "Deleted";
/*     */       }
/*  90 */       return "Old";
/*     */     }
/*  92 */     if ((columnIndex == 1) && (idx == 1)) {
/*  93 */       if (cmp.code == 1) {
/*  94 */         return "Inserted";
/*     */       }
/*  96 */       return "New";
/*     */     }
/*  98 */     if (columnIndex == 2) {
/*  99 */       return Integer.valueOf(cmp.lineNo);
/*     */     }
/* 101 */     LineCompare before = (LineCompare)this.displayRows[0].get(row);
/*     */     
/* 103 */     int lineIdx = columnIndex - this.additionalFields;
/* 104 */     int r = this.recordIndex;
/*     */     
/* 106 */     if (columnIndex == this.keyIdx) {
/* 107 */       lineIdx = 64771;
/*     */     }
/* 109 */     if (r >= this.description.getRecordCount()) {
/* 110 */       if ((idx == 1) && (before != null)) {
/* 111 */         r = before.line.getPreferredLayoutIdx();
/*     */       } else {
/* 113 */         r = cmp.line.getPreferredLayoutIdx();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 118 */     if ((idx == 1) && (before != null) && (
/* 119 */       (lineIdx >= before.line.getLayout().getRecord(r).getFieldCount()) || (Common.trimRight(before.line.getField(r, lineIdx)).equals(Common.trimRight(cmp.line.getField(r, lineIdx))))))
/*     */     {
/*     */ 
/* 122 */       return "";
/*     */     }
/*     */     
/*     */ 
/* 126 */     if (lineIdx >= this.description.getRecord(r).getFieldCount()) {
/* 127 */       return "";
/*     */     }
/*     */     
/* 130 */     return cmp.line.getField(r, lineIdx);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getColumnName(int column)
/*     */   {
/* 137 */     String ret = "";
/* 138 */     switch (column) {
/*     */     case 0: 
/*     */     case 1: 
/*     */       break;
/*     */     case 2: 
/* 143 */       ret = LangConversion.convert(5, "Line No");
/* 144 */       break;
/*     */     
/*     */     default: 
/* 147 */       if (column == this.keyIdx) {
/* 148 */         ret = LangConversion.convert(5, "Key Field");
/*     */       } else {
/* 150 */         int r = this.recordIndex;
/* 151 */         if (r >= this.description.getRecordCount()) {
/* 152 */           r = 0;
/*     */         }
/* 154 */         if (column - this.additionalFields < this.description.getRecord(r).getFieldCount()) {
/* 155 */           ret = this.description.getRecord(r).getField(column - this.additionalFields).getName();
/*     */         }
/*     */       }
/*     */       break;
/*     */     }
/* 160 */     return ret;
/*     */   }
/*     */   
/*     */   public void setDisplayRows(ArrayList<LineCompare> displayBefore, ArrayList<LineCompare> displayAfter)
/*     */   {
/* 165 */     this.displayRows[0] = displayBefore;
/* 166 */     this.displayRows[1] = displayAfter;
/*     */     
/* 168 */     fireTableDataChanged();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected int getRecordIndex()
/*     */   {
/* 175 */     return this.recordIndex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected boolean setRecordIndex(int recordIdx)
/*     */   {
/* 182 */     int idx = Math.min(recordIdx, this.description.getRecordCount());
/*     */     
/* 184 */     if ((idx >= 0) && (this.recordIndex != idx)) {
/* 185 */       this.recordIndex = idx;
/* 186 */       fireTableStructureChanged();
/* 187 */       return true;
/*     */     }
/* 189 */     return false;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/diff/CmpTableModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */