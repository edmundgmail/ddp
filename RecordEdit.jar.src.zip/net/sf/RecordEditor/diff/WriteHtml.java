/*     */ package net.sf.RecordEditor.diff;
/*     */ 
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import net.sf.JRecord.Common.AbstractFieldValue;
/*     */ import net.sf.JRecord.Common.IFieldDetail;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail.FieldDetails;
/*     */ import net.sf.RecordEditor.jibx.compare.DiffDefinition;
/*     */ import net.sf.RecordEditor.jibx.compare.File;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WriteHtml
/*     */ {
/*     */   private static final String HTML_START = "<Body><h1>Formated Compare</h1>";
/*     */   private static final String HTML_SINGLE_TBL_START = "<p>&nbsp;<p><table border=\"1\" cellpadding=\"2\"><tr><td><b>What</b></td><td><b>Line</b></td>";
/*     */   private static final String HTML_MANY_TBL_START = "<p>&nbsp;<p>&nbsp;<table border=\"1\" cellpadding=\"2\"><tr><td><b>Field Name</b></td><td><b>Pos</b></td><td><b>Length</b></td><td><b>Old Value</b></td><td><b>New Value</b></td></tr>";
/*     */   private static final String HTML_LINE_NUMBER = "<TR><td>Line Number</td><td>&nbsp;</td><td>&nbsp;</td>";
/*     */   private static final String HTML_END = "</td></tr></table></body>";
/*  27 */   private static WriteHtml instance = new WriteHtml();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void writeSingleTbl(DiffDefinition diff, AbstractLayoutDetails recordLayout, ArrayList<LineCompare> before, ArrayList<LineCompare> after)
/*     */     throws IOException
/*     */   {
/*  36 */     BufferedWriter writer = new BufferedWriter(new FileWriter(diff.htmlFile));
/*     */     
/*     */ 
/*     */ 
/*  40 */     htmlStart(writer, diff);
/*  41 */     writer.write("<p>&nbsp;<p><table border=\"1\" cellpadding=\"2\"><tr><td><b>What</b></td><td><b>Line</b></td>");
/*  42 */     writer.newLine();
/*     */     
/*  44 */     AbstractRecordDetail rec = recordLayout.getRecord(0);
/*  45 */     for (int i = 0; i < rec.getFieldCount(); i++) {
/*  46 */       writer.write("<td><b>" + rec.getField(i).getName() + "</b></td>");
/*     */     }
/*  48 */     writer.write("</TR>");
/*  49 */     writer.newLine();
/*     */     
/*  51 */     for (i = 0; i < before.size(); i++) {
/*  52 */       LineCompare old = (LineCompare)before.get(i);
/*  53 */       LineCompare newL = (LineCompare)after.get(i);
/*  54 */       writeLineStart(writer, "old", old);
/*  55 */       int pref; if (old == null) {
/*  56 */         int pref = newL.line.getPreferredLayoutIdx();
/*  57 */         writeBlankFields(writer, pref, recordLayout);
/*     */       } else {
/*  59 */         pref = old.line.getPreferredLayoutIdx();
/*  60 */         if ((old.code == 3) || (newL == null) || (newL.line == null)) {
/*  61 */           writeStandardFields(writer, "cyan", pref, recordLayout, old);
/*     */         } else {
/*  63 */           for (int j = 0; j < recordLayout.getRecord(pref).getFieldCount(); j++) {
/*  64 */             String f1 = old.line.getFieldValue(pref, j).asString();
/*  65 */             String f2 = newL.line.getFieldValue(pref, j).asString();
/*     */             
/*  67 */             if (f1.equals(f2)) {
/*  68 */               writer.write("<TD>" + f1 + "</td>");
/*     */             } else {
/*  70 */               writer.write("<TD bgcolor=lime><b>" + f1 + "</b></td>");
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*  76 */       writeLineStart(writer, "new", newL);
/*  77 */       if (newL == null) {
/*  78 */         writeBlankFields(writer, pref, recordLayout);
/*     */       }
/*  80 */       else if ((newL.code == 1) || (old == null) || (old.line == null)) {
/*  81 */         writeStandardFields(writer, "yellow", pref, recordLayout, newL);
/*     */       } else {
/*  83 */         if (recordLayout.isMapPresent()) {
/*  84 */           String f1 = old.line.getFieldValue(pref, 64771).asString();
/*  85 */           String f2 = newL.line.getFieldValue(pref, 64771).asString();
/*  86 */           writeField(writer, f1, f2);
/*     */         }
/*  88 */         for (int j = 0; j < recordLayout.getRecord(pref).getFieldCount(); j++) {
/*  89 */           String f1 = old.line.getFieldValue(pref, j).asString();
/*  90 */           String f2 = newL.line.getFieldValue(pref, j).asString();
/*  91 */           writeField(writer, f1, f2);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*  97 */     writer.write("</td></tr></table></body>");
/*  98 */     writer.close();
/*     */   }
/*     */   
/*     */   private void writeField(BufferedWriter writer, String f1, String f2) throws IOException
/*     */   {
/* 103 */     if (f1.equals(f2)) {
/* 104 */       writer.write("<TD>&nbsp;</td>");
/*     */     } else {
/* 106 */       writer.write("<TD bgcolor=lime><b>" + f2 + "</b></td>");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void writeLineStart(BufferedWriter writer, String what, LineCompare cmp)
/*     */     throws IOException
/*     */   {
/* 114 */     writer.write("<tr><td>" + what + "</td><td>");
/* 115 */     if (cmp != null) {
/* 116 */       writer.write(cmp.lineNo + "</td>");
/*     */     } else {
/* 118 */       writer.write("&nbsp;</td>");
/*     */     }
/* 120 */     writer.newLine();
/*     */   }
/*     */   
/*     */ 
/*     */   private void writeStandardFields(BufferedWriter writer, String color, int pref, AbstractLayoutDetails recordLayout, LineCompare cmp)
/*     */     throws IOException
/*     */   {
/* 127 */     String start = "<TD>";
/* 128 */     String endField = "</td>";
/*     */     
/* 130 */     if (!"".equals(color)) {
/* 131 */       start = "<TD bgcolor=\"" + color + "\"><b>";
/* 132 */       endField = "</b></td>";
/*     */     }
/*     */     
/*     */ 
/* 136 */     for (int j = 0; j < recordLayout.getRecord(pref).getFieldCount(); j++) {
/* 137 */       writer.write(start + cmp.line.getField(pref, j) + endField);
/*     */     }
/*     */     
/* 140 */     writer.write("</tr>");writer.newLine();
/*     */   }
/*     */   
/*     */ 
/*     */   private void writeBlankFields(BufferedWriter writer, int pref, AbstractLayoutDetails recordLayout)
/*     */     throws IOException
/*     */   {
/* 147 */     if (recordLayout.isMapPresent()) {
/* 148 */       writer.write("<td>&nbsp;</td>");
/*     */     }
/*     */     
/* 151 */     for (int j = 0; j < recordLayout.getRecord(pref).getFieldCount(); j++) {
/* 152 */       writer.write("<td>&nbsp;</td>");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void writeTblChgFields(DiffDefinition diff, AbstractLayoutDetails recordLayout, ArrayList<LineCompare> before, ArrayList<LineCompare> after)
/*     */     throws IOException
/*     */   {
/* 171 */     BufferedWriter writer = new BufferedWriter(new FileWriter(diff.htmlFile));
/*     */     
/*     */ 
/*     */ 
/* 175 */     System.out.println("--> " + diff.htmlFile);
/* 176 */     htmlStart(writer, diff);
/* 177 */     for (int j = 0; j < before.size(); j++) {
/* 178 */       LineCompare l1 = (LineCompare)before.get(j);
/* 179 */       LineCompare l2 = (LineCompare)after.get(j);
/*     */       
/* 181 */       if ((l1 == null) || (l2 == null)) {
/* 182 */         writeOneRow(writer, recordLayout, l1, l2);
/*     */       } else {
/* 184 */         int pref = l1.line.getPreferredLayoutIdx();
/* 185 */         writer.write("<p>&nbsp;<p>&nbsp;<table border=\"1\" cellpadding=\"2\"><tr><td><b>Field Name</b></td><td><b>Pos</b></td><td><b>Length</b></td><td><b>Old Value</b></td><td><b>New Value</b></td></tr>");writer.newLine();
/* 186 */         writer.write("<TR><td>Line Number</td><td>&nbsp;</td><td>&nbsp;</td><td>" + l1.lineNo + "</td><td>" + l2.lineNo + "</td></tr>");
/*     */         
/* 188 */         writer.newLine();
/* 189 */         for (int i = 0; i < recordLayout.getRecord(pref).getFieldCount(); i++) {
/* 190 */           if (!l1.line.getField(pref, i).equals(l2.line.getField(pref, i))) {
/* 191 */             IFieldDetail fld = recordLayout.getRecord(pref).getField(i);
/* 192 */             writeOneFieldHeader(writer, fld, i);
/* 193 */             writer.write("<td bgcolor=lime>" + fix(l1.line.getField(pref, i)) + "</td><td bgcolor=lime>" + fix(l2.line.getField(pref, i)) + "</td></tr>");
/*     */             
/*     */ 
/* 196 */             writer.newLine();
/*     */           }
/*     */         }
/* 199 */         writer.write("</table>");writer.newLine();
/*     */       }
/*     */     }
/*     */     
/* 203 */     writer.write("</td></tr></table></body>");writer.newLine();
/* 204 */     writer.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void writeTblAllFields(DiffDefinition diff, AbstractLayoutDetails recordLayout, ArrayList<LineCompare> before, ArrayList<LineCompare> after)
/*     */     throws IOException
/*     */   {
/* 223 */     BufferedWriter writer = new BufferedWriter(new FileWriter(diff.htmlFile));
/*     */     
/* 225 */     htmlStart(writer, diff);
/* 226 */     for (int i = 0; i < before.size(); i++) {
/* 227 */       writeOneRow(writer, recordLayout, (LineCompare)before.get(i), (LineCompare)after.get(i));
/*     */     }
/*     */     
/* 230 */     writer.write("</td></tr></table></body>");
/* 231 */     writer.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeOneRow(BufferedWriter writer, AbstractLayoutDetails recordLayout, LineCompare l1, LineCompare l2)
/*     */     throws IOException
/*     */   {
/* 241 */     writer.write("<p>&nbsp;<p>&nbsp;<table border=\"1\" cellpadding=\"2\"><tr><td><b>Field Name</b></td><td><b>Pos</b></td><td><b>Length</b></td><td><b>Old Value</b></td><td><b>New Value</b></td></tr>");writer.newLine();
/* 242 */     writer.write("<TR><td>Line Number</td><td>&nbsp;</td><td>&nbsp;</td>");
/* 243 */     if (l1 == null) {
/* 244 */       int pref = l2.line.getPreferredLayoutIdx();
/* 245 */       writer.write("<td>&nbsp;</td><td>" + l2.lineNo + "</td></tr>");
/* 246 */       writer.newLine();
/* 247 */       if (recordLayout.isMapPresent()) {
/* 248 */         writeKeyFieldHeader(writer);
/* 249 */         writeNewFieldNew(writer, l2.line.getField(pref, 64771));
/*     */       }
/*     */       
/* 252 */       for (int i = 0; i < recordLayout.getRecord(pref).getFieldCount(); i++) {
/* 253 */         IFieldDetail fld = recordLayout.getRecord(pref).getField(i);
/* 254 */         writeOneFieldHeader(writer, fld, i);
/* 255 */         writeNewFieldNew(writer, l2.line.getField(pref, i));
/*     */       } }
/* 257 */     if (l2 == null) {
/* 258 */       int pref = l1.line.getPreferredLayoutIdx();
/* 259 */       writer.write("<td>" + l1.lineNo + "</td><td>&nbsp;</td></tr>");
/* 260 */       writer.newLine();
/* 261 */       if (recordLayout.isMapPresent()) {
/* 262 */         writeKeyFieldHeader(writer);
/* 263 */         writeNewFieldOld(writer, l1.line.getField(pref, 64771));
/*     */       }
/*     */       
/* 266 */       for (int i = 0; i < recordLayout.getRecord(pref).getFieldCount(); i++) {
/* 267 */         IFieldDetail fld = recordLayout.getRecord(pref).getField(i);
/* 268 */         writeOneFieldHeader(writer, fld, i);
/* 269 */         writeNewFieldOld(writer, l1.line.getField(pref, i));
/*     */       }
/*     */     }
/* 272 */     int pref = l1.line.getPreferredLayoutIdx();
/* 273 */     if (recordLayout.isMapPresent()) {
/* 274 */       writeKeyFieldHeader(writer);
/* 275 */       writeNewFieldBoth(writer, l1.line.getField(pref, 64771), l2.line.getField(pref, 64771));
/*     */     }
/*     */     
/*     */ 
/* 279 */     writer.write("<td>" + l1.lineNo + "</td><td>" + l2.lineNo + "</td></tr>");
/* 280 */     writer.newLine();
/* 281 */     for (int i = 0; i < recordLayout.getRecord(pref).getFieldCount(); i++) {
/* 282 */       IFieldDetail fld = recordLayout.getRecord(pref).getField(i);
/* 283 */       writeOneFieldHeader(writer, fld, i);
/*     */       
/* 285 */       writeNewFieldBoth(writer, l1.line.getField(pref, i), l2.line.getField(pref, i));
/*     */     }
/*     */     
/*     */ 
/* 289 */     writer.write("</table>");writer.newLine();
/*     */   }
/*     */   
/*     */   private void writeNewFieldNew(BufferedWriter writer, Object value)
/*     */     throws IOException
/*     */   {
/* 295 */     writer.write("<td>&nbsp;</td><td bgcolor=yellow>" + fix(value) + "</td></tr>");
/*     */     
/* 297 */     writer.newLine();
/*     */   }
/*     */   
/*     */ 
/*     */   private void writeNewFieldOld(BufferedWriter writer, Object value)
/*     */     throws IOException
/*     */   {
/* 304 */     writer.write("<td bgcolor=aqua>" + fix(value) + "</td><td>&nbsp;</td></tr>");
/* 305 */     writer.newLine();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void writeNewFieldBoth(BufferedWriter writer, Object value1, Object value2)
/*     */     throws IOException
/*     */   {
/* 313 */     if (value1.equals(value2)) {
/* 314 */       writer.write("<td>" + fix(value1) + "</td><td>&nbsp;</td></tr>");
/*     */     } else {
/* 316 */       writer.write("<td bgcolor=lime>" + fix(value1) + "</td><td bgcolor=lime>" + fix(value2) + "</td></tr>");
/*     */     }
/*     */     
/* 319 */     writer.newLine();
/*     */   }
/*     */   
/*     */ 
/*     */   private void htmlStart(BufferedWriter writer, DiffDefinition diff)
/*     */     throws IOException
/*     */   {
/* 326 */     writer.write("<Body><h1>Formated Compare</h1>");writer.newLine();
/* 327 */     writer.write("<p> <b>Old File: </b>" + diff.oldFile.name);writer.newLine();
/* 328 */     writer.write("<p> <b>New File: </b>" + diff.newFile.name + "<p>");writer.newLine();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeOneFieldHeader(BufferedWriter writer, IFieldDetail fld, int fieldId)
/*     */     throws IOException
/*     */   {
/* 342 */     String len = "&nbsp;";
/*     */     
/* 344 */     if (fld.getLen() >= 0) {
/* 345 */       len = Integer.toString(fld.getLen());
/*     */     }
/*     */     
/* 348 */     writer.write("<TR><td>" + fld.getName() + "</td><td>" + fld.getPos() + "</td><td>" + len + "</td>");
/*     */   }
/*     */   
/*     */ 
/*     */   private void writeKeyFieldHeader(BufferedWriter writer)
/*     */     throws IOException
/*     */   {
/* 355 */     writer.write("<TR><td>Key Field</td><td>&nbsp;</td><td>&nbsp;</td>");
/*     */   }
/*     */   
/*     */   private String fix(Object o) {
/* 359 */     if ((o == null) || ("".equals(o.toString().trim()))) {
/* 360 */       return "&nbsp;";
/*     */     }
/* 362 */     return o.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static final WriteHtml getInstance()
/*     */   {
/* 369 */     return instance;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/diff/WriteHtml.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */