/*     */ package net.sf.RecordEditor.diff;
/*     */ 
/*     */ import java.awt.Container;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.FileOutputStream;
/*     */ import java.util.Properties;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDesktopPane;
/*     */ import javax.swing.JTextArea;
/*     */ import net.sf.RecordEditor.jibx.JibxCall;
/*     */ import net.sf.RecordEditor.jibx.compare.DiffDefinition;
/*     */ import net.sf.RecordEditor.re.openFile.AbstractLayoutSelectCreator;
/*     */ import net.sf.RecordEditor.re.openFile.AbstractLayoutSelection;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMainFrame;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.FileSelectCombo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RunSavedCompare
/*     */   extends ReFrame
/*     */ {
/*     */   private static final int WIDTH_INCREASE = 175;
/*     */   private static final int HEIGHT_INCREASE = 7;
/*  37 */   private FileSelectCombo xmlFileName = new FileSelectCombo("SavedDiff.", 25, true, false);
/*  38 */   private BaseHelpPanel pnl = new BaseHelpPanel();
/*     */   
/*  40 */   private JButton runCompareDialogBtn = SwingUtils.newButton("Run Compare Dialog");
/*  41 */   private JButton runCompareBtn = SwingUtils.newButton("Run Compare");
/*  42 */   private JButton runHtmlCompareBtn = SwingUtils.newButton("Run Html Compare");
/*     */   
/*  44 */   private JTextArea message = new JTextArea();
/*     */   
/*     */ 
/*     */   private int dbIdx;
/*     */   
/*     */   private String rFiles;
/*     */   
/*     */   private AbstractLayoutSelectCreator<AbstractLayoutSelection> layoutCreator;
/*     */   
/*  53 */   private ActionListener listner = new ActionListener()
/*     */   {
/*     */ 
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/*  58 */       if (e.getSource() == RunSavedCompare.this.runCompareDialogBtn) {
/*  59 */         RunSavedCompare.this.runCompareDialog();
/*     */       } else {
/*  61 */         RunSavedCompare.this.runCompare(e.getSource() == RunSavedCompare.this.runHtmlCompareBtn);
/*     */       }
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public RunSavedCompare(AbstractLayoutSelectCreator creator, int databaseIdx, String recentFiles)
/*     */   {
/*  71 */     super("", "Run Saved Compare File:", "", null);
/*     */     
/*  73 */     this.rFiles = recentFiles;
/*     */     
/*  75 */     ReMainFrame frame = ReMainFrame.getMasterFrame();
/*  76 */     int height = frame.getDesktop().getHeight() - 1;
/*  77 */     int width = frame.getDesktop().getWidth() - 1;
/*     */     
/*  79 */     String fname = Parameters.getFileName("CompareSaveDirectory");
/*     */     
/*  81 */     this.layoutCreator = creator;
/*  82 */     this.dbIdx = databaseIdx;
/*     */     
/*  84 */     this.runCompareDialogBtn.addActionListener(this.listner);
/*  85 */     this.runCompareBtn.addActionListener(this.listner);
/*  86 */     this.runHtmlCompareBtn.addActionListener(this.listner);
/*     */     
/*  88 */     this.xmlFileName.setText(fname);
/*     */     
/*  90 */     this.pnl.setGapRE(BasePanel.GAP3);
/*  91 */     this.pnl.addLineRE("New File", this.xmlFileName);
/*  92 */     this.pnl.setGapRE(BasePanel.GAP5);
/*     */     
/*  94 */     this.pnl.addLineRE("", null, this.runCompareDialogBtn);
/*  95 */     this.pnl.setGapRE(BasePanel.GAP1);
/*  96 */     this.pnl.addLineRE("", null, this.runCompareBtn);
/*  97 */     this.pnl.setGapRE(BasePanel.GAP1);
/*  98 */     this.pnl.addLineRE("", null, this.runHtmlCompareBtn);
/*  99 */     this.pnl.setGapRE(BasePanel.GAP5);
/*     */     
/* 101 */     this.pnl.addMessage(this.message);
/*     */     
/* 103 */     super.getContentPane().add(this.pnl);
/*     */     
/* 105 */     super.pack();
/* 106 */     setBounds(getY(), getX(), Math.min(width, getWidth() + 175), Math.min(height, getHeight() + 7));
/*     */     
/*     */ 
/*     */ 
/* 110 */     super.setVisible(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void windowClosing()
/*     */   {
/* 120 */     String s = this.xmlFileName.getText();
/* 121 */     if (!"".equals(s)) {
/*     */       try {
/* 123 */         Properties p = Parameters.getProperties();
/*     */         
/* 125 */         if (!s.equals(p.getProperty("CompareSaveDirectory"))) {
/* 126 */           p.setProperty("CompareSaveDirectory", s);
/*     */           
/* 128 */           p.store(new FileOutputStream(Parameters.getPropertyFileName()), "RecordEditor");
/*     */         }
/*     */         
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 134 */         e.printStackTrace();
/*     */       }
/*     */     }
/* 137 */     super.windowClosing();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void runCompareDialog()
/*     */   {
/* 146 */     DiffDefinition def = readXml();
/*     */     
/* 148 */     runCompareDialog(def);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void runCompareDialog(DiffDefinition def)
/*     */   {
/* 156 */     if (def != null) {
/* 157 */       if ("SingleLayout".equals(def.type)) {
/* 158 */         new CompareSingleLayout(createLayout(), def, this.rFiles);
/*     */       } else {
/* 160 */         new CompareTwoLayouts(createLayout(), createLayout(), def, this.rFiles, true);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void runCompare(boolean html)
/*     */   {
/* 170 */     DiffDefinition def = readXml();
/*     */     
/* 172 */     if (def != null) {
/* 173 */       if (!"Yes".equalsIgnoreCase(def.complete)) {
/* 174 */         runCompareDialog(def);
/*     */       } else {
/*     */         try {
/* 177 */           if (html) {
/* 178 */             if ((def.htmlFile != null) && (!"".equals(def.htmlFile))) {
/* 179 */               DoCompare.getInstance().writeHtml(createLayout(), createLayout(), def);
/*     */             } else {
/* 181 */               runCompareDialog(def);
/*     */             }
/*     */           } else {
/* 184 */             DoCompare.getInstance().compare(createLayout(), createLayout(), def);
/*     */           }
/*     */         } catch (Exception e) {
/* 187 */           String s = "Error Running Compare";
/* 188 */           e.printStackTrace();
/* 189 */           this.message.setText(s);
/* 190 */           Common.logMsg(s, e);
/* 191 */           return;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private AbstractLayoutSelection createLayout() {
/* 198 */     AbstractLayoutSelection ret = this.layoutCreator.create();
/* 199 */     ret.setDatabaseIdx(this.dbIdx);
/* 200 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */   private DiffDefinition readXml()
/*     */   {
/* 206 */     DiffDefinition def = null;
/* 207 */     JibxCall<DiffDefinition> jibx = new JibxCall(DiffDefinition.class);
/* 208 */     String filename = this.xmlFileName.getText();
/*     */     
/* 210 */     if ((filename == null) || ("".equals(filename))) {
/* 211 */       this.pnl.setMessageTxtRE("You must Enter a filename");
/*     */     } else {
/*     */       try {
/* 214 */         def = (DiffDefinition)jibx.marshal(filename);
/* 215 */         def.saveFile = filename;
/*     */       } catch (Exception e) {
/* 217 */         String s = "Error Loading Record Layout";
/* 218 */         e.printStackTrace();
/* 219 */         this.pnl.setMessageTxtRE(s);
/* 220 */         Common.logMsg(s, e);
/*     */       }
/*     */     }
/*     */     
/* 224 */     return def;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/diff/RunSavedCompare.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */