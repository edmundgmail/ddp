/*     */ package net.sf.RecordEditor.diff;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.table.AbstractTableModel;
/*     */ import net.sf.JRecord.Common.IFieldDetail;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CmpLineModel
/*     */   extends AbstractTableModel
/*     */ {
/*     */   public static final int BEFORE = 0;
/*     */   public static final int AFTER = 1;
/*  20 */   private static final String[] columnNames = LangConversion.convertColHeading("Compare_Line", new String[] { "Field", "Position", "Length", "Old", "New" });
/*     */   
/*     */   private ArrayList<LineCompare>[] displayRows;
/*     */   
/*     */   private AbstractLayoutDetails description;
/*     */   
/*  26 */   private int[] changedFields = null;
/*     */   
/*     */   private static final int COLUMN_COUNT = 5;
/*     */   
/*  30 */   private int recordIdx = 0;
/*  31 */   private int currentRow = 0;
/*  32 */   private boolean displayChangedFields = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CmpLineModel(AbstractLayoutDetails layout, ArrayList<LineCompare> displayBefore, ArrayList<LineCompare> displayAfter)
/*     */   {
/*  40 */     this.displayRows = new ArrayList[2];
/*     */     
/*  42 */     this.description = layout;
/*     */     
/*  44 */     this.displayRows[0] = displayBefore;
/*  45 */     this.displayRows[1] = displayAfter;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getColumnCount()
/*     */   {
/*  52 */     return 5;
/*     */   }
/*     */   
/*     */   public int getRowCount()
/*     */   {
/*  57 */     int inc = 1;
/*  58 */     if (this.description.isMapPresent()) {
/*  59 */       inc = 2;
/*     */     }
/*  61 */     if (isAllFields()) {
/*  62 */       return this.description.getRecord(this.recordIdx).getFieldCount() + inc;
/*     */     }
/*  64 */     return getChangedFields().length + inc;
/*     */   }
/*     */   
/*     */   public Object getValueAt(int rowIndex, int columnIndex)
/*     */   {
/*  69 */     Object ret = null;
/*  70 */     int idx = columnIndex - 3;
/*  71 */     int id = getAdjustedRow(rowIndex);
/*     */     
/*  73 */     if (columnIndex < 3) {
/*  74 */       if (rowIndex == 0) {
/*  75 */         if (columnIndex == 0) {
/*  76 */           ret = "Line Number";
/*     */         }
/*  78 */       } else if ((rowIndex == 1) && (this.description.isMapPresent())) {
/*  79 */         if (columnIndex == 0) {
/*  80 */           ret = "Key Value";
/*     */         }
/*     */       } else {
/*  83 */         IFieldDetail fld = this.description.getRecord(this.recordIdx).getField(id - 1);
/*  84 */         if (columnIndex == 0) {
/*  85 */           ret = fld.getName();
/*  86 */         } else if (columnIndex == 1) {
/*  87 */           ret = Integer.valueOf(fld.getPos());
/*  88 */         } else if (fld.getLen() < 0) {
/*  89 */           ret = "";
/*     */         } else {
/*  91 */           ret = Integer.valueOf(fld.getLen());
/*     */         }
/*     */       }
/*     */     }
/*  95 */     else if (this.currentRow < this.displayRows[idx].size()) {
/*  96 */       ret = standardFields(id, idx);
/*     */     }
/*     */     
/*  99 */     return ret;
/*     */   }
/*     */   
/*     */   private Object standardFields(int rowIndex, int idx) {
/* 103 */     Object ret = null;
/* 104 */     LineCompare cmp = (LineCompare)this.displayRows[idx].get(this.currentRow);
/*     */     
/* 106 */     if (cmp == null) {
/* 107 */       ret = "";
/* 108 */     } else if (rowIndex == 0) {
/* 109 */       ret = Integer.valueOf(cmp.lineNo);
/*     */     } else {
/* 111 */       LineCompare before = (LineCompare)this.displayRows[0].get(this.currentRow);
/* 112 */       int lineIdx = rowIndex - 1;
/*     */       
/* 114 */       if ((idx == 1) && (before != null) && 
/* 115 */         (Common.trimRight(before.line.getField(this.recordIdx, lineIdx)).equals(Common.trimRight(cmp.line.getField(this.recordIdx, lineIdx)))))
/*     */       {
/* 117 */         return "";
/*     */       }
/*     */       
/*     */ 
/* 121 */       if (lineIdx >= this.description.getRecord(this.recordIdx).getFieldCount()) {
/* 122 */         return "";
/*     */       }
/*     */       
/* 125 */       ret = cmp.line.getField(this.recordIdx, lineIdx);
/*     */     }
/* 127 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int getAdjustedRow(int rowIndex)
/*     */   {
/* 138 */     int id = rowIndex;
/*     */     
/* 140 */     if ((this.description.isMapPresent()) && (rowIndex > 0)) {
/* 141 */       if (rowIndex == 1) {
/* 142 */         return 64772;
/*     */       }
/*     */       
/* 145 */       id--;
/*     */     }
/*     */     
/* 148 */     if ((this.displayChangedFields) && (id > 0) && (getChangedFields().length >= id) && (!isAllFields()))
/*     */     {
/* 150 */       id = getChangedFields()[(id - 1)];
/*     */     }
/*     */     
/* 153 */     return id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isFieldChanged(int rowIdx)
/*     */   {
/* 163 */     boolean ret = false;
/* 164 */     int row = getAdjustedRow(rowIdx);
/*     */     
/* 166 */     if ((row > 0) && (this.currentRow <= this.displayRows[0].size())) {
/* 167 */       LineCompare before = (LineCompare)this.displayRows[0].get(this.currentRow);
/* 168 */       LineCompare after = (LineCompare)this.displayRows[1].get(this.currentRow);
/* 169 */       int lineIdx = row - 1;
/*     */       
/* 171 */       if ((before != null) && (before.line != null) && (before.code == 2) && (after != null) && (after.line != null))
/*     */       {
/*     */ 
/* 174 */         if (!Common.trimRight(before.line.getField(this.recordIdx, lineIdx)).equals(Common.trimRight(after.line.getField(this.recordIdx, lineIdx))))
/*     */         {
/* 176 */           ret = true;
/*     */         }
/*     */       }
/*     */     }
/* 180 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getColumnName(int column)
/*     */   {
/* 186 */     return columnNames[column];
/*     */   }
/*     */   
/*     */   public final void setDisplayRows(ArrayList<LineCompare> displayBefore, ArrayList<LineCompare> displayAfter)
/*     */   {
/* 191 */     this.displayRows[0] = displayBefore;
/* 192 */     this.displayRows[1] = displayAfter;
/*     */     
/* 194 */     fireTableDataChanged();
/*     */   }
/*     */   
/*     */ 
/*     */   protected final int getRecordIdx()
/*     */   {
/* 200 */     return this.recordIdx;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected final boolean setRecordIdx(int recordIndex)
/*     */   {
/* 207 */     int idx = recordIndex;
/*     */     
/* 209 */     if (idx >= this.description.getRecordCount()) {
/* 210 */       LineCompare cmp = (LineCompare)this.displayRows[0].get(this.currentRow);
/* 211 */       if (cmp == null) {
/* 212 */         idx = ((LineCompare)this.displayRows[1].get(this.currentRow)).line.getPreferredLayoutIdx();
/*     */       } else {
/* 214 */         idx = cmp.line.getPreferredLayoutIdx();
/*     */       }
/*     */     }
/*     */     
/* 218 */     if ((idx >= 0) && (this.recordIdx != idx)) {
/* 219 */       this.changedFields = null;
/* 220 */       this.recordIdx = idx;
/* 221 */       fireTableDataChanged();
/* 222 */       return true;
/*     */     }
/* 224 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected final int getCurrentRow()
/*     */   {
/* 231 */     return this.currentRow;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final LineCompare getCurrentCompareLine()
/*     */   {
/* 244 */     return (LineCompare)this.displayRows[0].get(this.currentRow);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected final void setCurrentRow(int newRow)
/*     */   {
/* 251 */     if ((newRow >= 0) && (this.currentRow != newRow)) {
/* 252 */       this.currentRow = newRow;
/*     */       
/* 254 */       this.changedFields = null;
/*     */       
/* 256 */       if (!setRecordIdx(this.description.getRecordCount())) {
/* 257 */         fireTableDataChanged();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private int[] getChangedFields()
/*     */   {
/* 264 */     if (this.changedFields == null) {
/* 265 */       int size = 0;
/*     */       
/* 267 */       LineCompare before = (LineCompare)this.displayRows[0].get(this.currentRow);
/* 268 */       LineCompare after = (LineCompare)this.displayRows[1].get(this.currentRow);
/*     */       
/* 270 */       if ((before == null) || (after == null)) {
/* 271 */         this.changedFields = new int[0];
/* 272 */         return this.changedFields;
/*     */       }
/*     */       
/* 275 */       for (int i = 0; i < this.description.getRecord(this.recordIdx).getFieldCount(); i++) {
/* 276 */         if (!Common.trimRight(before.line.getField(this.recordIdx, i)).equals(Common.trimRight(after.line.getField(this.recordIdx, i))))
/*     */         {
/*     */ 
/* 279 */           size++;
/*     */         }
/*     */       }
/*     */       
/* 283 */       this.changedFields = new int[size];
/* 284 */       int j = 0;
/* 285 */       for (i = 0; i < this.description.getRecord(this.recordIdx).getFieldCount(); i++) {
/* 286 */         if (!Common.trimRight(before.line.getField(this.recordIdx, i)).equals(Common.trimRight(after.line.getField(this.recordIdx, i))))
/*     */         {
/*     */ 
/* 289 */           this.changedFields[(j++)] = (i + 1);
/*     */         }
/*     */       }
/*     */     }
/* 293 */     return this.changedFields;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean isAllFields()
/*     */   {
/* 302 */     if (!this.displayChangedFields) {
/* 303 */       return true;
/*     */     }
/*     */     
/* 306 */     LineCompare before = (LineCompare)this.displayRows[0].get(this.currentRow);
/*     */     
/* 308 */     return (before == null) || (before.code == 3) || (this.displayRows[1].get(this.currentRow) == null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setDisplayChangedFields(boolean onlyChangedFields)
/*     */   {
/* 316 */     this.displayChangedFields = onlyChangedFields;
/* 317 */     fireTableDataChanged();
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/diff/CmpLineModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */