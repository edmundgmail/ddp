/*    */ package net.sf.RecordEditor.diff;
/*    */ 
/*    */ import javax.swing.JComponent;
/*    */ import net.sf.RecordEditor.jibx.compare.DiffDefinition;
/*    */ import net.sf.RecordEditor.jibx.compare.Layout;
/*    */ import net.sf.RecordEditor.re.file.filter.BaseFieldSelection;
/*    */ import net.sf.RecordEditor.re.file.filter.FilterDetails;
/*    */ import net.sf.RecordEditor.re.openFile.AbstractLayoutSelection;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*    */ import net.sf.RecordEditor.utils.wizards.AbstractWizardPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CmpFieldSelection
/*    */   extends BaseFieldSelection
/*    */   implements AbstractWizardPanel<DiffDefinition>
/*    */ {
/*    */   private DiffDefinition values;
/*    */   private AbstractLayoutSelection selection;
/* 24 */   private String lastLayoutName = "";
/* 25 */   private boolean toInit = true;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public CmpFieldSelection(AbstractLayoutSelection layoutSelection)
/*    */   {
/* 34 */     this.selection = layoutSelection;
/*    */     
/* 36 */     setHelpURLre(Common.formatHelpURL("diff2.html"));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public JComponent getComponent()
/*    */   {
/* 44 */     return this;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public DiffDefinition getValues()
/*    */     throws Exception
/*    */   {
/* 52 */     String sold = this.values.layoutDetails.name;
/*    */     
/* 54 */     this.values.layoutDetails = super.getFilter().getExternalLayout();
/* 55 */     this.values.layoutDetails.name = sold;
/* 56 */     return this.values;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setValues(DiffDefinition detail)
/*    */     throws Exception
/*    */   {
/* 66 */     this.values = detail;
/*    */     
/* 68 */     if (!this.lastLayoutName.equalsIgnoreCase(this.values.layoutDetails.name)) {
/* 69 */       super.setRecordLayout(this.selection.getRecordLayout(this.values.layoutDetails.name), null, false, SwingUtils.NORMAL_FIELD_HEIGHT * 4);
/*    */       
/*    */ 
/*    */ 
/* 73 */       this.lastLayoutName = this.values.layoutDetails.name;
/* 74 */       this.toInit = true;
/*    */     }
/*    */     
/* 77 */     if (this.toInit) {
/* 78 */       super.getFilter().updateFromExternalLayout(this.values.layoutDetails);
/* 79 */       this.toInit = false;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean skip()
/*    */   {
/* 88 */     return false;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/diff/CmpFieldSelection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */