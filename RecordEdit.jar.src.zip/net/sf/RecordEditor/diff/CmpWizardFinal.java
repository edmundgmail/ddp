/*     */ package net.sf.RecordEditor.diff;
/*     */ 
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JRadioButton;
/*     */ import javax.swing.JTextField;
/*     */ import net.sf.RecordEditor.jibx.JibxCall;
/*     */ import net.sf.RecordEditor.jibx.compare.DiffDefinition;
/*     */ import net.sf.RecordEditor.re.openFile.AbstractLayoutSelection;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.HtmlWindow;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.FileSelectCombo;
/*     */ import net.sf.RecordEditor.utils.wizards.AbstractWizardPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CmpWizardFinal
/*     */   extends BaseHelpPanel
/*     */   implements AbstractWizardPanel<DiffDefinition>
/*     */ {
/*  37 */   private FileSelectCombo saveFileName = new FileSelectCombo("SavedDiff.", 15, false, false, true);
/*  38 */   private FileSelectCombo htmlFileName = new FileSelectCombo("HtmlOut.", 15, false, false, true);
/*     */   
/*     */   private AbstractLayoutSelection selection;
/*     */   
/*     */   private AbstractLayoutSelection selection2;
/*  43 */   private JButton saveBtn = SwingUtils.newButton("Save", Common.getRecordIcon(2));
/*  44 */   private JButton runBtn = SwingUtils.newButton("Compare");
/*  45 */   private JButton htmlBtn = SwingUtils.newButton("Compare (HTML)");
/*     */   
/*  47 */   private JRadioButton stripTrailingSpaces = SwingUtils.newRadioButton("Strip Trailing Spaces");
/*  48 */   private JRadioButton singleTblBtn = SwingUtils.newRadioButton("Single Table");
/*  49 */   private JRadioButton multipleTblsBtn = SwingUtils.newRadioButton("Table per row");
/*     */   
/*  51 */   private JRadioButton allRows = SwingUtils.newRadioButton("All Rows");
/*  52 */   private JRadioButton chgRows = SwingUtils.newRadioButton("Only Changed Rows");
/*     */   
/*  54 */   private JRadioButton allFieldsBtn = SwingUtils.newRadioButton("All Fields");
/*  55 */   private JRadioButton chgFieldsBtn = SwingUtils.newRadioButton("Only Changed Fields");
/*     */   
/*  57 */   private JCheckBox showHtmlCheckBox = SwingUtils.newCheckBox("Show Html");
/*     */   
/*  59 */   private JTextField message = new JTextField();
/*     */   
/*     */ 
/*     */   private DiffDefinition diffDetail;
/*     */   
/*  64 */   private JibxCall<DiffDefinition> jibx = null;
/*     */   
/*  66 */   private boolean toRun = true;
/*     */   
/*     */ 
/*  69 */   private AbstractAction btnAction = new AbstractAction()
/*     */   {
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/*  73 */       if (e.getSource() == CmpWizardFinal.this.runBtn) {
/*  74 */         CmpWizardFinal.this.run();
/*  75 */       } else if (e.getSource() == CmpWizardFinal.this.htmlBtn) {
/*  76 */         CmpWizardFinal.this.runHtml();
/*     */       } else {
/*  78 */         CmpWizardFinal.this.save();
/*     */       }
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CmpWizardFinal(AbstractLayoutSelection layoutSelection, AbstractLayoutSelection layoutSelection2, boolean offerSaveOption)
/*     */   {
/*  91 */     JPanel pnl = new JPanel(new GridLayout(3, 2));
/*     */     
/*  93 */     this.saveFileName.setDefaultDirectory(Parameters.getFileName("CompareSaveDirectory"));
/*     */     
/*     */ 
/*  96 */     this.selection = layoutSelection;
/*  97 */     this.selection2 = layoutSelection2;
/*     */     
/*  99 */     this.saveFileName.setText(Parameters.getFileName("CompareSaveDirectory"));
/*     */     
/* 101 */     this.showHtmlCheckBox.setSelected(true);
/*     */     
/* 103 */     this.saveBtn.addActionListener(this.btnAction);
/* 104 */     this.runBtn.addActionListener(this.btnAction);
/* 105 */     this.htmlBtn.addActionListener(this.btnAction);
/*     */     
/* 107 */     super.setHelpURLre(Common.formatHelpURL("diff2.html"));
/*     */     
/* 109 */     if (offerSaveOption) {
/* 110 */       super.addLineRE("Save File", this.saveFileName);
/* 111 */       super.setGapRE(BasePanel.GAP1);
/*     */     }
/* 113 */     super.addLineRE("Html File", this.htmlFileName);
/* 114 */     super.setGapRE(BasePanel.GAP1);
/* 115 */     super.addLineRE("", this.stripTrailingSpaces);
/* 116 */     super.setGapRE(BasePanel.GAP1);
/* 117 */     super.addLineRE("HTML options:", null);
/*     */     
/* 119 */     addRadioGrp(pnl, this.singleTblBtn, this.multipleTblsBtn);
/* 120 */     addRadioGrp(pnl, this.allRows, this.chgRows);
/* 121 */     addRadioGrp(pnl, this.allFieldsBtn, this.chgFieldsBtn);
/*     */     
/* 123 */     super.addLineRE("", pnl);
/* 124 */     super.setHeightRE(BasePanel.GAP5);
/*     */     
/* 126 */     super.addLineRE("", null, this.saveBtn);
/* 127 */     super.setGapRE(BasePanel.GAP0);
/* 128 */     super.addLineRE("", null, this.runBtn);
/* 129 */     super.setGapRE(BasePanel.GAP0);
/* 130 */     super.addLineRE("", this.showHtmlCheckBox, this.htmlBtn);
/* 131 */     super.setGapRE(BasePanel.GAP2);
/* 132 */     super.addMessage(this.message);
/* 133 */     super.setHeightRE(BasePanel.HEIGHT_1P6);
/*     */   }
/*     */   
/*     */   private void addRadioGrp(JPanel pnl, JRadioButton btn1, JRadioButton btn2) {
/* 137 */     ButtonGroup grp = new ButtonGroup();
/* 138 */     grp.add(btn1);
/* 139 */     grp.add(btn2);
/*     */     
/* 141 */     pnl.add(btn1);
/* 142 */     pnl.add(btn2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final JComponent getComponent()
/*     */   {
/* 150 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final DiffDefinition getValues()
/*     */     throws Exception
/*     */   {
/* 159 */     if (!"".equals(this.saveFileName.getText())) {
/* 160 */       this.diffDetail.saveFile = this.saveFileName.getText();
/*     */     }
/* 162 */     if (!"".equals(this.htmlFileName.getText())) {
/* 163 */       this.diffDetail.htmlFile = this.htmlFileName.getText();
/*     */     }
/*     */     
/* 166 */     this.diffDetail.stripTrailingSpaces = this.stripTrailingSpaces.isSelected();
/* 167 */     this.diffDetail.allFields = this.allFieldsBtn.isSelected();
/* 168 */     this.diffDetail.allRows = this.allRows.isSelected();
/* 169 */     this.diffDetail.singleTable = this.singleTblBtn.isSelected();
/*     */     
/*     */ 
/* 172 */     return this.diffDetail;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean skip()
/*     */   {
/* 180 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setValues(DiffDefinition detail)
/*     */     throws Exception
/*     */   {
/* 191 */     this.saveFileName.setText(detail.saveFile);
/* 192 */     this.htmlFileName.setText(detail.htmlFile);
/* 193 */     this.diffDetail = detail;
/* 194 */     this.diffDetail.fileSaved = false;
/* 195 */     this.diffDetail.complete = "YES";
/*     */     
/* 197 */     this.stripTrailingSpaces.setSelected(this.diffDetail.stripTrailingSpaces);
/* 198 */     this.allFieldsBtn.setSelected(this.diffDetail.allFields);
/* 199 */     this.chgFieldsBtn.setSelected(!this.diffDetail.allFields);
/* 200 */     this.allRows.setSelected(this.diffDetail.allRows);
/* 201 */     this.chgRows.setSelected(!this.diffDetail.allRows);
/* 202 */     this.singleTblBtn.setSelected(this.diffDetail.singleTable);
/* 203 */     this.multipleTblsBtn.setSelected(!this.diffDetail.singleTable);
/*     */   }
/*     */   
/*     */   public final void run()
/*     */   {
/*     */     try {
/* 209 */       this.message.setText("");
/* 210 */       this.diffDetail = getValues();
/*     */       
/* 212 */       DoCompare.getInstance().compare(this.selection, this.selection2, this.diffDetail);
/*     */       
/* 214 */       this.toRun = false;
/*     */     } catch (Exception e) {
/* 216 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void runHtml()
/*     */   {
/* 224 */     if ("".equals(this.htmlFileName.getText())) {
/* 225 */       setMessageTxtRE("You must enter a HTML file");
/* 226 */       this.htmlFileName.requestFocus();
/*     */     } else {
/*     */       try {
/* 229 */         this.message.setText("");
/* 230 */         this.diffDetail = getValues();
/*     */         
/* 232 */         DoCompare.getInstance().writeHtml(this.selection, this.selection2, this.diffDetail);
/*     */         
/* 234 */         if (this.showHtmlCheckBox.isSelected()) {
/* 235 */           new HtmlWindow(this.diffDetail.htmlFile, "Generated Html");
/*     */         }
/* 237 */         this.toRun = false;
/*     */       } catch (Exception e) {
/* 239 */         e.printStackTrace();
/* 240 */         Common.logMsg("Error generating HTML", e);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void save()
/*     */   {
/*     */     try
/*     */     {
/* 251 */       this.diffDetail = getValues();
/*     */       
/* 253 */       if (this.jibx == null) {
/* 254 */         this.jibx = new JibxCall(DiffDefinition.class);
/*     */       }
/* 256 */       this.jibx.unmarshal(this.diffDetail.saveFile, this.diffDetail);
/* 257 */       this.diffDetail.fileSaved = true;
/*     */     } catch (Exception e) {
/* 259 */       e.printStackTrace();
/* 260 */       Common.logMsgRaw(Common.FILE_SAVE_FAILED, e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final boolean isToRun()
/*     */   {
/* 268 */     return this.toRun;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/diff/CmpWizardFinal.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */