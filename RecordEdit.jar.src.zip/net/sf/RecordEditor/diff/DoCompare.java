/*     */ package net.sf.RecordEditor.diff;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import jlibdiff.Diff;
/*     */ import net.sf.JRecord.Common.RecordException;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.RecordEditor.jibx.compare.DiffDefinition;
/*     */ import net.sf.RecordEditor.jibx.compare.File;
/*     */ import net.sf.RecordEditor.jibx.compare.Layout;
/*     */ import net.sf.RecordEditor.re.openFile.ISchemaProvider;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DoCompare
/*     */ {
/*  18 */   private static DoCompare instance = new DoCompare();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void compare(ISchemaProvider layoutReader, ISchemaProvider layoutReader2, DiffDefinition def)
/*     */     throws Exception
/*     */   {
/*  32 */     if ("SingleLayout".equals(def.type)) {
/*  33 */       AbstractLayoutDetails dtl = getLayout(layoutReader, def.layoutDetails.name, def.oldFile.name);
/*  34 */       compare1Layout(dtl, def);
/*     */     } else {
/*  36 */       AbstractLayoutDetails dtl1 = getLayout(layoutReader, def.oldFile.layoutDetails.name, def.oldFile.name);
/*  37 */       AbstractLayoutDetails dtl2 = getLayout(layoutReader2, def.newFile.layoutDetails.name, def.newFile.name);
/*     */       
/*  39 */       compare2Layouts(dtl1, dtl2, def);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void writeHtml(ISchemaProvider layoutReader, ISchemaProvider layoutReader2, DiffDefinition def)
/*     */     throws Exception
/*     */   {
/*  56 */     Diff diff = new Diff();
/*     */     
/*     */     LineBufferedReader newReader;
/*     */     
/*     */     AbstractLayoutDetails dtl1;
/*     */     LineBufferedReader oldReader;
/*     */     LineBufferedReader newReader;
/*  63 */     if ("SingleLayout".equals(def.type)) {
/*  64 */       AbstractLayoutDetails dtl1 = getLayout(layoutReader, def.layoutDetails.name, def.oldFile.name);
/*  65 */       LineBufferedReader oldReader = new LineBufferedReader(def.oldFile.name, dtl1, null, def.layoutDetails, def.stripTrailingSpaces);
/*     */       
/*  67 */       newReader = new LineBufferedReader(def.newFile.name, dtl1, oldReader.getFilteredLayout(), def.layoutDetails, def.stripTrailingSpaces);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*  72 */       dtl1 = getLayout(layoutReader, def.oldFile.layoutDetails.name, def.oldFile.name);
/*  73 */       AbstractLayoutDetails dtl2 = getLayout(layoutReader2, def.newFile.layoutDetails.name, def.newFile.name);
/*     */       
/*  75 */       oldReader = new LineBufferedReader(def.oldFile.name, dtl1, null, def.oldFile.layoutDetails, def.stripTrailingSpaces);
/*     */       
/*  77 */       newReader = new LineBufferedReader(def.newFile.name, dtl2, null, def.newFile.layoutDetails, def.stripTrailingSpaces);
/*     */     }
/*     */     
/*     */ 
/*  81 */     Visitor vis = new Visitor(oldReader, newReader);
/*     */     
/*  83 */     diff.diffBuffer(oldReader, newReader);
/*  84 */     diff.accept(vis);
/*     */     ArrayList<LineCompare> after;
/*  86 */     ArrayList<LineCompare> before; ArrayList<LineCompare> after; if ((def.allRows) && (def.allFields)) {
/*  87 */       ArrayList<LineCompare> before = vis.getOldList();
/*  88 */       after = vis.getNewList();
/*     */     } else {
/*  90 */       before = vis.getOldChanged();
/*  91 */       after = vis.getNewChanged();
/*     */     }
/*     */     
/*  94 */     AbstractLayoutDetails dtl3 = oldReader.getFilteredLayout();
/*  95 */     if (dtl3 == null) {
/*  96 */       dtl3 = dtl1;
/*     */     }
/*  98 */     WriteHtml writeHtml = WriteHtml.getInstance();
/*  99 */     if (def.singleTable) {
/* 100 */       writeHtml.writeSingleTbl(def, dtl3, before, after);
/* 101 */     } else if (def.allFields) {
/* 102 */       writeHtml.writeTblAllFields(def, dtl3, before, after);
/*     */     } else {
/* 104 */       writeHtml.writeTblChgFields(def, dtl3, before, after);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private AbstractLayoutDetails getLayout(ISchemaProvider layoutReader, String name, String fileName)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 123 */       return layoutReader.getRecordLayout(name, fileName);
/*     */     } catch (Exception e) {
/* 125 */       String s = "Error Loading Layout:";
/* 126 */       e.printStackTrace();
/* 127 */       Common.logMsg(s, e);
/* 128 */       throw e;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final void compare1Layout(AbstractLayoutDetails dtl, DiffDefinition diffDefinition)
/*     */     throws IOException, RecordException
/*     */   {
/* 144 */     LineBufferedReader oldReader = new LineBufferedReader(diffDefinition.oldFile.name, dtl, null, diffDefinition.layoutDetails, diffDefinition.stripTrailingSpaces);
/*     */     
/* 146 */     LineBufferedReader newReader = new LineBufferedReader(diffDefinition.newFile.name, dtl, oldReader.getFilteredLayout(), diffDefinition.layoutDetails, diffDefinition.stripTrailingSpaces);
/*     */     
/*     */ 
/*     */ 
/* 150 */     compare1Layout(oldReader, newReader);
/*     */   }
/*     */   
/*     */ 
/*     */   public final void compare1Layout(LineBufferedReader oldReader, LineBufferedReader newReader)
/*     */     throws IOException
/*     */   {
/* 157 */     Diff diff = new Diff();
/* 158 */     Visitor vis = new Visitor(oldReader, newReader);
/*     */     
/*     */ 
/* 161 */     diff.diffBuffer(oldReader, newReader);
/* 162 */     diff.accept(vis);
/*     */     
/* 164 */     new TableDisplay("Single Layout Compare", oldReader.getFilteredLayout(), vis.getOldList(), vis.getNewList(), vis.getOldChanged(), vis.getNewChanged(), true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final void compare2Layouts(AbstractLayoutDetails dtl1, AbstractLayoutDetails dtl2, DiffDefinition diffDefinition)
/*     */     throws IOException, RecordException
/*     */   {
/* 183 */     Diff diff = new Diff();
/* 184 */     LineBufferedReader oldReader = new LineBufferedReader(diffDefinition.oldFile.name, dtl1, null, diffDefinition.oldFile.layoutDetails, diffDefinition.stripTrailingSpaces);
/*     */     
/* 186 */     LineBufferedReader newReader = new LineBufferedReader(diffDefinition.newFile.name, dtl2, null, diffDefinition.newFile.layoutDetails, diffDefinition.stripTrailingSpaces);
/*     */     
/*     */ 
/*     */ 
/* 190 */     Visitor vis = new Visitor(oldReader, newReader);
/*     */     
/*     */ 
/* 193 */     diff.diffBuffer(oldReader, newReader);
/* 194 */     diff.accept(vis);
/*     */     
/* 196 */     new TableDisplay("Single Layout Compare", oldReader.getFilteredLayout(), vis.getOldList(), vis.getNewList(), vis.getOldChanged(), vis.getNewChanged(), true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final DoCompare getInstance()
/*     */   {
/* 206 */     return instance;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/diff/DoCompare.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */