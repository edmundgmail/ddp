/*     */ package net.sf.RecordEditor.diff;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.sf.JRecord.Common.Conversion;
/*     */ import net.sf.JRecord.Common.RecordException;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.JRecord.IO.AbstractLineIOProvider;
/*     */ import net.sf.JRecord.IO.AbstractLineReader;
/*     */ import net.sf.JRecord.IO.LineIOProvider;
/*     */ import net.sf.RecordEditor.jibx.compare.Layout;
/*     */ import net.sf.RecordEditor.utils.ExpandLineTree;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ 
/*     */ public class LineBufferedReader
/*     */   extends BufferedReader
/*     */ {
/*  23 */   private int currLine = 0;
/*     */   
/*     */   private List<AbstractLine> lines;
/*     */   
/*     */   private AbstractLayoutDetails detail;
/*     */   
/*     */   private AbstractLayoutDetails filteredLayout;
/*     */   
/*     */   private final boolean stripSpaces;
/*     */   private ExpandLineTree expand;
/*     */   
/*     */   public LineBufferedReader(String fileName, AbstractLayoutDetails dtl, List<AbstractLine> lineArray, boolean stripTrailingSpaces)
/*     */     throws IOException, RecordException
/*     */   {
/*  37 */     super(new FileReader(fileName), 4);
/*  38 */     super.close();
/*     */     
/*  40 */     this.filteredLayout = dtl;
/*  41 */     this.detail = dtl;
/*     */     
/*  43 */     this.stripSpaces = stripTrailingSpaces;
/*     */     
/*  45 */     if (dtl.hasChildren()) {
/*  46 */       this.lines = new ArrayList(lineArray.size() * 2);
/*  47 */       this.expand = ExpandLineTree.newExpandLineTree(this.lines);
/*     */       
/*  49 */       for (AbstractLine line : lineArray) {
/*  50 */         this.expand.expand(line);
/*     */       }
/*     */     } else {
/*  53 */       this.lines = lineArray;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public LineBufferedReader(String fileName, AbstractLayoutDetails dtl, AbstractLayoutDetails newDtl, Layout layoutDef, boolean stripTrailingSpaces)
/*     */     throws IOException, RecordException
/*     */   {
/*  61 */     super(new FileReader(fileName), 4);
/*  62 */     super.close();
/*     */     
/*  64 */     boolean noFilter = (layoutDef == null) || (layoutDef.records == null) || (layoutDef.records.size() == 0);
/*     */     
/*  66 */     AbstractLineIOProvider ioProvider = LineIOProvider.getInstance();
/*     */     
/*  68 */     AbstractLineReader reader = ioProvider.getLineReader(dtl);
/*     */     
/*     */ 
/*  71 */     this.filteredLayout = dtl;
/*  72 */     this.detail = dtl;
/*  73 */     this.stripSpaces = stripTrailingSpaces;
/*     */     
/*     */ 
/*  76 */     this.lines = new ArrayList(256);
/*  77 */     if (this.detail.hasChildren()) {
/*  78 */       this.expand = ExpandLineTree.newExpandLineTree(this.lines);
/*     */     }
/*     */     
/*  81 */     reader.open(fileName, this.detail);
/*     */     
/*  83 */     if (noFilter) { AbstractLine line;
/*  84 */       while ((line = reader.read()) != null) {
/*  85 */         addLine(line);
/*     */       }
/*     */     }
/*  88 */     boolean[] include = new boolean[dtl.getRecordCount()];
/*     */     
/*     */ 
/*  91 */     this.filteredLayout = newDtl;
/*  92 */     if (newDtl == null) {
/*  93 */       this.filteredLayout = dtl.getFilteredLayout(layoutDef.getFilteredRecords());
/*     */     }
/*     */     
/*  96 */     if (this.detail.getRecordCount() == 1) { AbstractLine line;
/*  97 */       while ((line = reader.read()) != null) {
/*  98 */         List<AbstractLine> list = ExpandLineTree.expandTree(line);
/*  99 */         for (AbstractLine xLine : list) {
/* 100 */           xLine.setLayout(this.filteredLayout);
/* 101 */           this.lines.add(xLine);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 106 */     for (int j = 0; j < include.length; j++) {
/* 107 */       include[j] = (include.length == layoutDef.records.size() ? 1 : false);
/*     */     }
/*     */     
/* 110 */     if (include.length != layoutDef.records.size()) {
/* 111 */       for (j = 0; j < layoutDef.records.size(); j++) {
/* 112 */         include[dtl.getRecordIndex(((net.sf.RecordEditor.jibx.compare.Record)layoutDef.records.get(j)).name)] = true;
/*     */       }
/*     */     }
/*     */     
/*     */     AbstractLine line;
/*     */     
/* 118 */     while ((line = reader.read()) != null) {
/* 119 */       List<AbstractLine> list = ExpandLineTree.expandTree(line);
/* 120 */       for (AbstractLine xLine : list) {
/* 121 */         int idx = xLine.getPreferredLayoutIdx();
/* 122 */         if ((idx >= 0) && (idx < include.length) && (include[idx] != 0)) {
/* 123 */           xLine.setLayout(this.filteredLayout);
/* 124 */           this.lines.add(xLine);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 130 */     reader.close();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addLine(AbstractLine l)
/*     */   {
/* 138 */     if (this.detail.hasChildren()) {
/* 139 */       this.expand.expand(l);
/*     */     } else {
/* 141 */       this.lines.add(l);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {}
/*     */   
/*     */ 
/*     */   public boolean markSupported()
/*     */   {
/* 153 */     return false;
/*     */   }
/*     */   
/*     */   public int read() throws IOException
/*     */   {
/* 158 */     throw new RuntimeException("read not supported");
/*     */   }
/*     */   
/*     */   public int read(char[] cbuf, int off, int len) throws IOException
/*     */   {
/* 163 */     throw new RuntimeException("read not supported");
/*     */   }
/*     */   
/*     */   public String readLine()
/*     */     throws IOException
/*     */   {
/* 169 */     return readLine(this.currLine++);
/*     */   }
/*     */   
/*     */   public String readLine(int lineNo) throws IOException {
/* 173 */     if (lineNo < this.lines.size()) {
/* 174 */       AbstractLine line = (AbstractLine)this.lines.get(lineNo);
/* 175 */       StringBuffer buf = new StringBuffer();
/* 176 */       int pref = line.getPreferredLayoutIdx();
/*     */       
/* 178 */       if (this.detail.isMapPresent()) {
/* 179 */         Object o = line.getField(pref, 64771);
/*     */         
/* 181 */         if (o != null) {
/* 182 */           buf.append(Common.trimRight(o)).append("\t");
/*     */         }
/*     */       }
/*     */       
/* 186 */       if (this.filteredLayout.getRecord(pref) == null) {
/* 187 */         Common.logMsg("Layout Record Does not exist !!!", null);
/* 188 */       } else if (this.stripSpaces) {
/* 189 */         for (int i = 0; i < this.filteredLayout.getRecord(pref).getFieldCount(); i++) {
/* 190 */           buf.append(Common.trimRight(getField(line, pref, i))).append("\t");
/*     */         }
/*     */       } else {
/* 193 */         for (int i = 0; i < this.filteredLayout.getRecord(pref).getFieldCount(); i++) {
/* 194 */           buf.append(getField(line, pref, i)).append("\t");
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 203 */       return buf.toString();
/*     */     }
/* 205 */     return null;
/*     */   }
/*     */   
/*     */   private String getField(AbstractLine line, int recordNo, int fldNo) {
/* 209 */     Object obj = line.getField(recordNo, fldNo);
/* 210 */     if (obj == null) {
/* 211 */       obj = "";
/*     */     }
/* 213 */     String s = obj.toString();
/* 214 */     if ((s.indexOf('\t') >= 0) || (s.indexOf('\n') >= 0)) {
/* 215 */       StringBuilder b = Conversion.replace(new StringBuilder(s), "\\", "\\\\");
/* 216 */       Conversion.replace(b, "\n", "\\n");
/* 217 */       Conversion.replace(b, "\t", "\\t");
/* 218 */       s = b.toString();
/*     */     }
/*     */     
/* 221 */     return s;
/*     */   }
/*     */   
/*     */   public boolean ready() throws IOException
/*     */   {
/* 226 */     return true;
/*     */   }
/*     */   
/*     */   public void reset() throws IOException
/*     */   {
/* 231 */     this.currLine = 0;
/*     */   }
/*     */   
/*     */   public long skip(long n) throws IOException
/*     */   {
/* 236 */     throw new RuntimeException("skip not supported");
/*     */   }
/*     */   
/*     */   public int getCount() {
/* 240 */     return this.lines.size();
/*     */   }
/*     */   
/*     */   public AbstractLine getLine(int index) {
/* 244 */     return (AbstractLine)this.lines.get(index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final AbstractLayoutDetails getFilteredLayout()
/*     */   {
/* 252 */     return this.filteredLayout;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/diff/LineBufferedReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */