/*     */ package net.sf.RecordEditor.diff;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextPane;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import javax.swing.text.Style;
/*     */ import javax.swing.text.StyleConstants;
/*     */ import javax.swing.text.StyleContext;
/*     */ import javax.swing.text.StyledDocument;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TableDisplay
/*     */   extends AbstractCompareDisplay
/*     */ {
/*  33 */   private CmpTableRender render = new CmpTableRender();
/*     */   private CmpTableModel model;
/*  35 */   private JTextPane msgTxt = new JTextPane();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TableDisplay(String name, AbstractLayoutDetails recordLayout, ArrayList<LineCompare> before, ArrayList<LineCompare> after, ArrayList<LineCompare> chgBefore, ArrayList<LineCompare> chgAfter, boolean primary)
/*     */   {
/*  50 */     super("Table Display ", name, recordLayout, before, after, chgBefore, chgAfter, primary, false);
/*     */     
/*     */ 
/*  53 */     init_100_SetupJtables();
/*     */     
/*     */ 
/*     */ 
/*  57 */     if ((chgBefore.size() == 0) && (chgAfter.size() == 0)) {
/*     */       try {
/*  59 */         Style def = StyleContext.getDefaultStyleContext().getStyle("default");
/*     */         
/*  61 */         StyledDocument doc = this.msgTxt.getStyledDocument();
/*  62 */         Style bold = doc.addStyle("bold", def);
/*  63 */         StyleConstants.setBold(bold, true);
/*  64 */         StyleConstants.setFontSize(bold, 16);
/*  65 */         StyleConstants.setAlignment(bold, 1);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*  70 */         doc.insertString(doc.getLength(), "Files are Identical !!!", bold);
/*     */         
/*     */ 
/*  73 */         this.pnl.addLineRE("", this.msgTxt);
/*  74 */         this.pnl.setGapRE(BasePanel.GAP0);
/*     */       }
/*     */       catch (Exception e) {}
/*  77 */     } else if (Common.TEST_MODE) {
/*  78 */       this.pnl.addLineRE("", this.msgTxt);
/*     */     }
/*     */     
/*     */ 
/*  82 */     this.pnl.addComponentRE(1, 5, -1.0D, BasePanel.GAP, 2, 2, new JScrollPane(this.tblDetails));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  87 */     addMainComponent(this.pnl);
/*     */     
/*     */ 
/*  90 */     setBounds(1, 1, this.screenSize.width - 1, this.screenSize.height - 1);
/*     */     
/*     */ 
/*  93 */     this.model.setRecordIndex(Integer.MAX_VALUE);
/*  94 */     setTableFeatures();
/*     */     
/*  96 */     this.render.setSchemaIdx(getLayoutIndex());
/*     */     
/*  98 */     setVisible(true);
/*     */   }
/*     */   
/*     */   private void init_100_SetupJtables() {
/* 102 */     AbstractLayoutDetails l = this.layout;
/* 103 */     this.render.setList(this.displayBefore, this.displayAfter);
/* 104 */     this.model = new CmpTableModel(this.layout, this.displayBefore, this.displayAfter);
/*     */     
/* 106 */     setDisplay(2);
/* 107 */     this.tblDetails = new JTable(this.model);
/* 108 */     this.tblDetails.setAutoResizeMode(0);
/* 109 */     int tblHeight = l.getOption(11);
/*     */     
/* 111 */     if ((tblHeight <= 1) && (this.displayAfter.size() > 0)) {
/* 112 */       AbstractLine line = null;
/* 113 */       int i = 0;
/* 114 */       while ((i < this.displayAfter.size()) && ((this.displayAfter.get(i) == null) || ((line = ((LineCompare)this.displayAfter.get(i)).line) == null))) {
/* 115 */         i++;
/*     */       }
/* 117 */       if (line != null) {
/* 118 */         tblHeight = line.getLayout().getOption(11);
/*     */       }
/*     */     }
/* 121 */     if (tblHeight > 1) {
/* 122 */       this.tblDetails.setRowHeight(tblHeight * SwingUtils.TABLE_ROW_HEIGHT);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 128 */     this.tblDetails.addMouseListener(new MouseAdapter() {
/*     */       public void mousePressed(MouseEvent m) {
/* 130 */         int col = TableDisplay.this.tblDetails.columnAtPoint(m.getPoint());
/*     */         
/* 132 */         int popupRow = TableDisplay.this.tblDetails.rowAtPoint(m.getPoint());
/*     */         
/* 134 */         if (col < 2) {
/* 135 */           LineDisplay disp = new LineDisplay("Line", TableDisplay.this.layout, TableDisplay.this.fullBefore, TableDisplay.this.fullAfter, TableDisplay.this.changeBefore, TableDisplay.this.changeAfter, false, TableDisplay.this.displayType == 1);
/*     */           
/* 137 */           disp.setCurrRow(popupRow / 2);
/* 138 */           disp.setDisplay(TableDisplay.this.displayType);
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setTableFeatures()
/*     */   {
/* 148 */     Common.calcColumnWidths(this.tblDetails, 3);
/*     */     
/* 150 */     TableColumnModel colMdl = this.tblDetails.getColumnModel();
/* 151 */     colMdl.getColumn(0).setPreferredWidth(5);
/* 152 */     colMdl.getColumn(1).setPreferredWidth(50);
/*     */     
/* 154 */     for (int i = 0; i < colMdl.getColumnCount(); i++) {
/* 155 */       colMdl.getColumn(i).setCellRenderer(this.render);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDisplay(int type)
/*     */   {
/* 166 */     boolean recalcSize = this.displayBefore.size() == 0;
/* 167 */     super.setDisplay(type);
/*     */     
/* 169 */     this.render.setList(this.displayBefore, this.displayAfter);
/* 170 */     this.model.setDisplayRows(this.displayBefore, this.displayAfter);
/*     */     
/* 172 */     if ((recalcSize) && (this.tblDetails != null)) {
/* 173 */       Common.calcColumnWidths(this.tblDetails, 3);
/* 174 */       TableColumnModel colMdl = this.tblDetails.getColumnModel();
/* 175 */       colMdl.getColumn(0).setPreferredWidth(5);
/* 176 */       colMdl.getColumn(1).setPreferredWidth(50);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void changeLayout()
/*     */   {
/* 186 */     if (this.model != null) {
/* 187 */       int layoutIndex = getLayoutIndex();
/*     */       
/* 189 */       this.render.setSchemaIdx(layoutIndex);
/* 190 */       if (this.model.setRecordIndex(layoutIndex)) {
/* 191 */         setTableFeatures();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCurrRow()
/*     */   {
/* 202 */     return 0;
/*     */   }
/*     */   
/*     */   public void setCurrRow(int newRow, int layoutId, int fieldNum) {}
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/diff/TableDisplay.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */