/*     */ package net.sf.RecordEditor.diff;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDesktopPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTable.PrintMode;
/*     */ import javax.swing.event.InternalFrameAdapter;
/*     */ import javax.swing.event.InternalFrameEvent;
/*     */ import javax.swing.event.TableModelEvent;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMainFrame;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.LayoutCombo;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AbstractCompareDisplay
/*     */   extends ReFrame
/*     */ {
/*     */   public static final int USE_FULL_LIST = 1;
/*     */   public static final int USE_CHANGE_LIST = 2;
/*     */   public static final int ALL_FIELDS = 1;
/*     */   public static final int CHANGED_FIELDS = 2;
/*     */   protected Rectangle screenSize;
/*     */   protected AbstractLayoutDetails layout;
/*     */   protected JTable tblDetails;
/*  79 */   private JTable alternativeTbl = null;
/*     */   
/*     */   private LayoutCombo layoutList;
/*  82 */   private JButton fullListBtn = SwingUtils.newButton("All Included Lines");
/*  83 */   private JButton chgListBtn = SwingUtils.newButton("Changed Lines");
/*     */   private JButton allFieldsBtn;
/*     */   private JButton changedFieldsBtn;
/*     */   protected final int prefferedIndex;
/*  87 */   protected BaseHelpPanel pnl = new BaseHelpPanel();
/*     */   
/*     */   protected TableCellRenderer[] cellRenders;
/*     */   
/*  91 */   private int maxHeight = -1;
/*     */   protected int[] widths;
/*     */   protected final ArrayList<LineCompare> fullBefore;
/*     */   protected final ArrayList<LineCompare> fullAfter;
/*     */   protected final ArrayList<LineCompare> changeBefore;
/*     */   protected final ArrayList<LineCompare> changeAfter;
/*     */   protected ArrayList<LineCompare> displayBefore;
/*  98 */   protected ArrayList<LineCompare> displayAfter; protected int displayType = 2;
/*     */   
/*     */ 
/* 101 */   private ActionListener listner = new ActionListener()
/*     */   {
/*     */ 
/*     */     public final void actionPerformed(ActionEvent e)
/*     */     {
/*     */ 
/* 107 */       if (e.getSource() == AbstractCompareDisplay.this.layoutList) {
/* 108 */         AbstractCompareDisplay.this.setRowHeight();
/* 109 */         AbstractCompareDisplay.this.changeLayout();
/* 110 */       } else if (e.getSource() == AbstractCompareDisplay.this.fullListBtn) {
/* 111 */         AbstractCompareDisplay.this.setDisplay(1);
/* 112 */       } else if (e.getSource() == AbstractCompareDisplay.this.chgListBtn) {
/* 113 */         AbstractCompareDisplay.this.setDisplay(2);
/* 114 */       } else if (e.getSource() == AbstractCompareDisplay.this.allFieldsBtn) {
/* 115 */         AbstractCompareDisplay.this.setDisplayFields(1);
/* 116 */       } else if (e.getSource() == AbstractCompareDisplay.this.changedFieldsBtn) {
/* 117 */         AbstractCompareDisplay.this.setDisplayFields(2);
/*     */       }
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractCompareDisplay(String formType, String name, AbstractLayoutDetails recordLayout, ArrayList<LineCompare> before, ArrayList<LineCompare> after, ArrayList<LineCompare> chgBefore, ArrayList<LineCompare> chgAfter, boolean primary, boolean allRows)
/*     */   {
/* 142 */     super("", name, "", formType, before);
/* 143 */     setPrimaryView(primary);
/*     */     
/* 145 */     this.layout = recordLayout;
/* 146 */     this.fullBefore = before;
/* 147 */     this.fullAfter = after;
/* 148 */     this.changeBefore = chgBefore;
/* 149 */     this.changeAfter = chgAfter;
/*     */     
/* 151 */     this.displayBefore = chgBefore;
/* 152 */     this.displayAfter = chgAfter;
/* 153 */     if (allRows) {
/* 154 */       this.displayBefore = before;
/* 155 */       this.displayAfter = after;
/* 156 */       this.displayType = 1;
/*     */     }
/*     */     
/* 159 */     this.screenSize = ReMainFrame.getMasterFrame().getDesktop().getBounds();
/*     */     
/* 161 */     init(primary);
/* 162 */     this.prefferedIndex = this.layoutList.getPreferedIndex();
/* 163 */     this.layoutList.setSelectedIndex(this.prefferedIndex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init(boolean primary)
/*     */   {
/* 173 */     JPanel btnPnl = new JPanel();
/*     */     
/* 175 */     this.layoutList = new LayoutCombo(this.layout, false, false, true, false);
/*     */     
/*     */ 
/* 178 */     this.layoutList.addActionListener(this.listner);
/* 179 */     this.fullListBtn.addActionListener(this.listner);
/* 180 */     this.chgListBtn.addActionListener(this.listner);
/*     */     
/* 182 */     btnPnl.add(this.fullListBtn);
/* 183 */     btnPnl.add(this.chgListBtn);
/* 184 */     if (!primary) {
/* 185 */       this.allFieldsBtn = SwingUtils.newButton("Show All Fields");
/* 186 */       this.changedFieldsBtn = SwingUtils.newButton("Show Changed Fields");
/*     */       
/* 188 */       btnPnl.add(this.allFieldsBtn);
/* 189 */       btnPnl.add(this.changedFieldsBtn);
/*     */       
/* 191 */       this.allFieldsBtn.addActionListener(this.listner);
/* 192 */       this.changedFieldsBtn.addActionListener(this.listner);
/*     */     }
/*     */     
/*     */ 
/* 196 */     if (super.isPrimaryView()) {
/* 197 */       this.pnl.addComponent3Lines("Layouts", getLayoutList(), btnPnl);
/*     */     } else {
/* 199 */       this.pnl.addComponent3Lines("Layouts", getLayoutList(), null);
/* 200 */       this.pnl.addLineRE("", btnPnl);
/*     */     }
/*     */     
/* 203 */     this.pnl.setHeightRE(BasePanel.NORMAL_HEIGHT * 2.0D);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 209 */     setDefaultCloseOperation(2);
/*     */     
/* 211 */     addInternalFrameListener(new InternalFrameAdapter() {
/*     */       public void internalFrameClosed(InternalFrameEvent e) {
/* 213 */         AbstractCompareDisplay.this.closeWindow();
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDisplay(int type)
/*     */   {
/* 235 */     this.displayType = type;
/* 236 */     if (type == 1) {
/* 237 */       this.displayBefore = this.fullBefore;
/* 238 */       this.displayAfter = this.fullAfter;
/*     */     } else {
/* 240 */       this.displayBefore = this.changeBefore;
/* 241 */       this.displayAfter = this.changeAfter;
/*     */     }
/*     */     
/* 244 */     this.fullListBtn.setVisible(type == 2);
/* 245 */     this.chgListBtn.setVisible(type == 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDisplayFields(int fieldDisplay)
/*     */   {
/* 254 */     this.allFieldsBtn.setVisible(fieldDisplay == 2);
/* 255 */     this.changedFieldsBtn.setVisible(fieldDisplay == 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void windowClosing()
/*     */   {
/* 264 */     if (super.isPrimaryView()) {
/* 265 */       ReFrame[] allFrames = ReFrame.getAllFrames();
/* 266 */       System.out.println("closeWindow " + getName());
/*     */       
/* 268 */       for (int i = allFrames.length - 1; i >= 0; i--) {
/* 269 */         if ((allFrames[i].getDocument() == this.fullBefore) && (allFrames[i] != this))
/*     */         {
/* 271 */           allFrames[i].doDefaultCloseAction();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 276 */     super.windowClosing();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void closeWindow()
/*     */   {
/*     */     try
/*     */     {
/* 285 */       stopCellEditing();
/*     */     }
/*     */     catch (Exception ex) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void executeAction(int action)
/*     */   {
/* 301 */     stopCellEditing();
/*     */     try
/*     */     {
/* 304 */       switch (action) {
/*     */       case 23: 
/* 306 */         this.pnl.showHelpRE();
/* 307 */         break;
/*     */       case 36: 
/*     */         try {
/* 310 */           this.tblDetails.print(JTable.PrintMode.NORMAL);
/*     */         } catch (Exception e) {
/* 312 */           Common.logMsg("Printing failed (Printing requires Java 1.5)", e);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 318 */       Common.logMsg("Error Executing action:", null);
/* 319 */       Common.logMsg(e.getMessage(), e);
/* 320 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isActionAvailable(int action)
/*     */   {
/* 333 */     boolean ret = (action == 23) || (action == 36);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 339 */     return ret;
/*     */   }
/*     */   
/*     */   protected int getInsertBeforePosition()
/*     */   {
/* 344 */     return getStandardPosition() - 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int getStandardPosition()
/*     */   {
/* 354 */     int pos = getCurrRow();
/* 355 */     if (pos < 0) {
/* 356 */       pos = this.displayBefore.size() - 1;
/*     */     }
/*     */     
/* 359 */     return pos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void changeLayout();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract int getCurrRow();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void setCurrRow(int paramInt1, int paramInt2, int paramInt3);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void setLayoutIdx()
/*     */   {
/* 389 */     if (this.layout.getRecordCount() > 0)
/*     */     {
/* 391 */       int record2Use = 0;
/* 392 */       int currMax = 0;
/*     */       
/*     */ 
/* 395 */       int[] layoutCounts = new int[this.layout.getRecordCount()];
/*     */       
/*     */ 
/*     */ 
/* 399 */       for (int i = 0; i < layoutCounts.length; i++) {
/* 400 */         layoutCounts[i] = 0;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 410 */       for (i = 0; i < layoutCounts.length; i++) {
/* 411 */         if (layoutCounts[i] > currMax) {
/* 412 */           currMax = layoutCounts[i];
/* 413 */           record2Use = i;
/*     */         }
/*     */       }
/*     */       
/* 417 */       setLayoutIndex(record2Use);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSelectedRowCount()
/*     */   {
/* 427 */     return this.tblDetails.getSelectedRowCount();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int[] getSelectedRows()
/*     */   {
/* 434 */     return this.tblDetails.getSelectedRows();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void stopCellEditing()
/*     */   {
/* 443 */     Common.stopCellEditing(this.tblDetails);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final boolean hasTheFormatChanged(TableModelEvent event)
/*     */   {
/* 455 */     boolean changed = false;
/*     */     
/* 457 */     if ((event.getType() == 0) && (event.getFirstRow() < 0) && (event.getLastRow() < 0)) {}
/*     */     
/*     */ 
/*     */ 
/* 461 */     return changed;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setRowHeight()
/*     */   {
/* 470 */     if (this.maxHeight > 0) {
/* 471 */       this.tblDetails.setRowHeight(this.maxHeight);
/* 472 */       if (this.alternativeTbl != null) {
/* 473 */         this.alternativeTbl.setRowHeight(this.maxHeight);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getLayoutIndex()
/*     */   {
/* 483 */     return this.layoutList.getLayoutIndex();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setLayoutIndex(int recordIndex)
/*     */   {
/* 493 */     this.layoutList.setLayoutIndex(recordIndex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final LayoutCombo getLayoutList()
/*     */   {
/* 501 */     return this.layoutList;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setAlternativeTbl(JTable alternativeTbl)
/*     */   {
/* 512 */     this.alternativeTbl = alternativeTbl;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/diff/AbstractCompareDisplay.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */