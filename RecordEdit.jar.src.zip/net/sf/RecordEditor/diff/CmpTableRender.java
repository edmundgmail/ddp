/*     */ package net.sf.RecordEditor.diff;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.table.DefaultTableCellRenderer;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CmpTableRender
/*     */   implements TableCellRenderer
/*     */ {
/*  32 */   public static Color ADDED_COLOR = Color.yellow;
/*  33 */   public static Color DELETED_COLOR = Color.cyan;
/*  34 */   private static Color MODIFIED_LINE_COLOR = Color.orange;
/*  35 */   public static Color MODIFIED_COLOR = Color.green;
/*     */   
/*  37 */   private JButton button = new JButton();
/*  38 */   private DefaultTableCellRenderer text = new DefaultTableCellRenderer();
/*     */   
/*  40 */   private ArrayList<LineCompare> before = null; private ArrayList<LineCompare> after = null;
/*     */   
/*  42 */   private int schemaIdx = 0;
/*     */   
/*     */   public void setList(ArrayList<LineCompare> beforeList, ArrayList<LineCompare> afterList) {
/*  45 */     this.before = beforeList;
/*  46 */     this.after = afterList;
/*  47 */     this.text.setBorder(BorderFactory.createEmptyBorder());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Component getTableCellRendererComponent(JTable tbl, Object value, boolean isSelected, boolean hasFocus, int row, int column)
/*     */   {
/*  62 */     if ((column == 0) && (row % 2 == 0)) {
/*  63 */       return this.button;
/*     */     }
/*  65 */     int idx = row / 2;
/*  66 */     if ((this.before == null) || (idx >= this.before.size())) {
/*  67 */       this.text.setBackground(Color.WHITE);
/*     */     } else {
/*  69 */       LineCompare cmp = (LineCompare)this.before.get(idx);
/*     */       
/*  71 */       if (cmp == null) {
/*  72 */         this.text.setBackground(ADDED_COLOR);
/*  73 */       } else if (cmp.code == 3) {
/*  74 */         this.text.setBackground(DELETED_COLOR);
/*  75 */       } else if (cmp.code == 2) {
/*  76 */         if (column < 3) {
/*  77 */           this.text.setBackground(MODIFIED_LINE_COLOR);
/*     */         } else {
/*  79 */           Object val1 = "";
/*  80 */           Object val2 = "";
/*  81 */           int sIdx = this.schemaIdx;
/*     */           try {
/*  83 */             if (sIdx >= ((LineCompare)this.before.get(idx)).line.getLayout().getRecordCount()) {
/*  84 */               sIdx = ((LineCompare)this.before.get(idx)).line.getPreferredLayoutIdx();
/*     */             }
/*  86 */             val1 = ((LineCompare)this.before.get(idx)).line.getField(sIdx, column - 3);
/*  87 */             val2 = ((LineCompare)this.after.get(idx)).line.getField(sIdx, column - 3);
/*     */           }
/*     */           catch (Exception e) {}
/*     */           
/*     */ 
/*  92 */           if (fix(val2).equals(fix(val1))) {
/*  93 */             this.text.setBackground(MODIFIED_LINE_COLOR);
/*     */           } else {
/*  95 */             this.text.setBackground(MODIFIED_COLOR);
/*     */           }
/*     */         }
/*     */       } else {
/*  99 */         this.text.setBackground(Color.WHITE);
/*     */       }
/*     */     }
/*     */     
/* 103 */     return this.text.getTableCellRendererComponent(tbl, value, isSelected, hasFocus, row, column);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSchemaIdx(int schemaIdx)
/*     */   {
/* 116 */     this.schemaIdx = schemaIdx;
/*     */   }
/*     */   
/*     */   private String fix(Object o) {
/* 120 */     String ret = "";
/* 121 */     if (o != null) {
/* 122 */       ret = o.toString();
/*     */     }
/*     */     
/* 125 */     return ret;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/diff/CmpTableRender.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */