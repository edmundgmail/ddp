/*    */ package net.sf.RecordEditor.tip;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.Properties;
/*    */ import net.sf.JRecord.Common.FieldDetail;
/*    */ import net.sf.JRecord.Common.RecordException;
/*    */ import net.sf.JRecord.Details.AbstractLine;
/*    */ import net.sf.JRecord.Details.ArrayListLine;
/*    */ import net.sf.JRecord.Details.LayoutDetail;
/*    */ import net.sf.JRecord.Details.RecordDetail;
/*    */ import net.sf.JRecord.Details.RecordDetail.FieldDetails;
/*    */ import net.sf.JRecord.IO.AbstractLineReader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PropertiesLineReader
/*    */   extends AbstractLineReader<LayoutDetail>
/*    */ {
/*    */   private final String varPrefix;
/*    */   private Properties props;
/* 28 */   private int idx = 0;
/*    */   
/*    */ 
/*    */ 
/*    */   public PropertiesLineReader(String varPrefix)
/*    */   {
/* 34 */     this.varPrefix = varPrefix;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void open(InputStream inputStream, LayoutDetail pLayout)
/*    */     throws IOException, RecordException
/*    */   {
/* 43 */     super.setLayout(pLayout);
/*    */     
/* 45 */     this.idx = 0;
/*    */     
/* 47 */     this.props = new Properties();
/*    */     
/* 49 */     this.props.load(inputStream);
/* 50 */     pLayout.setExtraDetails(this.props);
/* 51 */     inputStream.close();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public AbstractLine read()
/*    */     throws IOException
/*    */   {
/* 59 */     boolean found = false;
/* 60 */     LayoutDetail l = (LayoutDetail)getLayout();
/* 61 */     RecordDetail r = (RecordDetail)l.getRecord(0);
/*    */     
/*    */ 
/* 64 */     ArrayListLine<FieldDetail, RecordDetail, LayoutDetail> line = new ArrayListLine(l, 0, 1);
/*    */     
/*    */ 
/* 67 */     for (int j = 0; j < 5; j++) {
/* 68 */       String v = this.varPrefix + "." + this.idx + ".";
/* 69 */       for (int i = 0; i < r.getFieldCount(); i++) {
/* 70 */         String key = v + ((RecordDetail.FieldDetails)r.getField(i)).getName();
/* 71 */         String s = this.props.getProperty(key);
/* 72 */         if (s != null) {
/*    */           try {
/* 74 */             line.setField(0, i, s);
/* 75 */             found = true;
/*    */           }
/*    */           catch (Exception e) {}
/* 78 */           this.props.remove(key);
/*    */         }
/*    */       }
/*    */       
/* 82 */       this.idx += 1;
/* 83 */       if (found) {
/* 84 */         return line;
/*    */       }
/*    */     }
/* 87 */     return null;
/*    */   }
/*    */   
/*    */   public void close()
/*    */     throws IOException
/*    */   {}
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/tip/PropertiesLineReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */