/*    */ package net.sf.RecordEditor.tip.display;
/*    */ 
/*    */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*    */ import net.sf.RecordEditor.edit.display.DisplayBuilderImp;
/*    */ import net.sf.RecordEditor.edit.display.DisplayFrame;
/*    */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*    */ import net.sf.RecordEditor.re.display.AbstractFileDisplayWithFieldHide;
/*    */ import net.sf.RecordEditor.re.display.IDisplayFrame;
/*    */ import net.sf.RecordEditor.re.file.FileView;
/*    */ import net.sf.RecordEditor.re.script.DisplayBuilderAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TipDisplayBuilder
/*    */   extends DisplayBuilderAdapter
/*    */ {
/*    */   public AbstractFileDisplayWithFieldHide newDisplay(int screenType, String screenName, IDisplayFrame<? extends AbstractFileDisplay> parentFrame, AbstractLayoutDetails group, FileView viewOfFile, int lineNo)
/*    */   {
/* 25 */     if (viewOfFile.getLayout().getFileStructure() == 102) {
/* 26 */       switch (screenType) {
/*    */       case 1: 
/*    */       case 2: 
/* 29 */         TipList tiplist = new TipList(viewOfFile, true);
/* 30 */         if ((viewOfFile.getRowCount() == 0) && (screenType == 1)) {
/* 31 */           tiplist.insertLine(0);
/*    */         }
/*    */         
/* 34 */         DisplayBuilderImp.addToScreen(parentFrame, tiplist);
/*    */         
/* 36 */         tiplist.getParentFrame().executeAction(67);
/* 37 */         return tiplist;
/*    */       
/*    */       case 3: 
/* 40 */         TipList tipList1 = new TipList(viewOfFile, viewOfFile == viewOfFile.getBaseFile());
/* 41 */         DisplayBuilderImp.addToScreen(parentFrame, tipList1);
/*    */         
/* 43 */         tipList1.getParentFrame().executeAction(67);
/* 44 */         return tipList1;
/*    */       case 4: 
/* 46 */         return (AbstractFileDisplayWithFieldHide)DisplayBuilderImp.addToScreen(parentFrame, new TipRecordScreen(viewOfFile, lineNo));
/*    */       }
/*    */     }
/* 49 */     return null;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/tip/display/TipDisplayBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */