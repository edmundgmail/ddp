/*     */ package net.sf.RecordEditor.tip.display;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Rectangle;
/*     */ import javax.swing.JEditorPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextArea;
/*     */ import net.sf.RecordEditor.edit.display.BaseDisplay;
/*     */ import net.sf.RecordEditor.edit.display.extension.IChildScreen;
/*     */ import net.sf.RecordEditor.edit.display.extension.PaneDtls;
/*     */ import net.sf.RecordEditor.edit.display.extension.SplitPaneRecord;
/*     */ import net.sf.RecordEditor.edit.display.util.LinePosition;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.tip.def.TipField;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TipChildRecordScreen
/*     */   extends BaseDisplay
/*     */   implements IChildScreen
/*     */ {
/*     */   private static final String HTML_STR = "Html";
/*     */   private static final String NAME_STR = "Name";
/*     */   private static final String DESCRIPTION_STR = "Description";
/*     */   protected SplitPaneRecord splitPane;
/*  29 */   protected final JTextArea nameTxt = new JTextArea();
/*     */   
/*  31 */   protected JEditorPane descriptionTxt = new JEditorPane("text", "");
/*  32 */   protected JEditorPane htmlEdt = new JEditorPane("text/html", "");
/*     */   
/*     */   public TipChildRecordScreen(FileView viewOfFile, int lineNo, int position)
/*     */   {
/*  36 */     super("Single PO Record", viewOfFile, false, false, false, false, false, 4);
/*     */     
/*     */ 
/*  39 */     this.splitPane = new SplitPaneRecord(NO_CLOSE_ACTION_PNL, viewOfFile, lineNo);
/*     */     
/*  41 */     if (position == 2) {
/*  42 */       this.splitPane.setFields(new PaneDtls[] { new PaneDtls("Name", TipField.name, this.nameTxt), new PaneDtls("Description", TipField.description, this.descriptionTxt), new PaneDtls("Html", TipField.description, this.htmlEdt, 1, true) }, new double[] { 0.45D, 0.45D });
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/*  48 */       this.splitPane.setFields(new PaneDtls[] { new PaneDtls("Name", TipField.name, this.nameTxt), new PaneDtls("Description", TipField.description, this.descriptionTxt, 0.25D), new PaneDtls("Html", TipField.description, this.htmlEdt, 0, PaneDtls.IS_HTML, 0.25D) }, null);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  54 */     setJTable(new JTable());
/*     */     
/*  56 */     init_200_layoutScreen();
/*     */   }
/*     */   
/*     */   private void init_200_layoutScreen()
/*     */   {
/*  61 */     this.splitPane.layoutFieldPane();
/*     */     
/*  63 */     this.actualPnl.addComponentRE(1, 3, -1.0D, BasePanel.GAP, 2, 2, this.splitPane.splitPane);
/*     */     
/*  65 */     this.actualPnl.done();
/*     */     
/*  67 */     int minWidth = Math.min(this.screenSize.width * 3 / 20, 30 * SwingUtils.CHAR_FIELD_WIDTH);
/*  68 */     this.actualPnl.setPreferredSize(new Dimension(Math.max(minWidth, this.actualPnl.getPreferredSize().width), this.actualPnl.getPreferredSize().height));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setScreenSize(boolean mainframe)
/*     */   {
/*  78 */     this.actualPnl.done();
/*     */   }
/*     */   
/*     */ 
/*     */   protected int getInsertAfterPosition()
/*     */   {
/*  84 */     return getStandardPosition();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected LinePosition getInsertAfterLine(boolean prev)
/*     */   {
/*  92 */     return super.getInsertAfterLine(this.splitPane.getCurrRow(), prev);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void fireLayoutIndexChanged() {}
/*     */   
/*     */ 
/*     */   public int getCurrRow()
/*     */   {
/* 102 */     return this.splitPane.getCurrRow();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCurrRow(int newRow)
/*     */   {
/* 110 */     this.splitPane.setCurrRow(newRow);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void flush()
/*     */   {
/* 119 */     this.splitPane.flush();
/*     */   }
/*     */   
/*     */   public void setCurrRow(int newRow, int layoutId, int fieldNum)
/*     */   {
/* 124 */     setCurrRow(newRow);
/*     */   }
/*     */   
/*     */ 
/*     */   protected BaseDisplay getNewDisplay(FileView view)
/*     */   {
/* 130 */     return null;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/tip/display/TipChildRecordScreen.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */