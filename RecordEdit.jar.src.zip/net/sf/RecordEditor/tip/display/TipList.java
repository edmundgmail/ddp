/*     */ package net.sf.RecordEditor.tip.display;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import javax.swing.JPopupMenu;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.event.TableModelListener;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import net.sf.RecordEditor.edit.display.AbstractCreateChildScreen;
/*     */ import net.sf.RecordEditor.edit.display.BaseDisplay;
/*     */ import net.sf.RecordEditor.edit.display.common.AbstractRowChangedListner;
/*     */ import net.sf.RecordEditor.edit.display.extension.EditPaneListScreen;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplayWithFieldHide;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.MenuPopupListener;
/*     */ import net.sf.RecordEditor.utils.lang.ReAbstractAction;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import org.jdesktop.swingx.JXTipOfTheDay;
/*     */ 
/*     */ public class TipList
/*     */   extends EditPaneListScreen
/*     */   implements AbstractRowChangedListner, TableModelListener, AbstractFileDisplayWithFieldHide, AbstractCreateChildScreen
/*     */ {
/*  25 */   private static final int TIP_COLUMN_WIDTH = SwingUtils.STANDARD_FONT_WIDTH * 45;
/*     */   
/*     */   public TipList(FileView viewOfFile, boolean primary) {
/*  28 */     super("Tip List", viewOfFile, primary, false, false, false, false, 4);
/*     */     
/*     */ 
/*  31 */     addTipAction(this.mainPopup);
/*  32 */     addTipAction(this.fixedPopupMenu);
/*     */   }
/*     */   
/*     */   private void addTipAction(MenuPopupListener popup)
/*     */   {
/*  37 */     popup.getPopup().addSeparator();
/*  38 */     popup.getPopup().add(new TipViewer(popup, this.fileView));
/*     */   }
/*     */   
/*     */   public void setScreenSize(boolean mainframe)
/*     */   {
/*  43 */     super.setScreenSize(mainframe);
/*     */     
/*  45 */     TableColumn tc = getJTable().getColumnModel().getColumn(1);
/*  46 */     if (tc.getPreferredWidth() > TIP_COLUMN_WIDTH) {
/*  47 */       tc.setPreferredWidth(TIP_COLUMN_WIDTH);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractFileDisplay createChildScreen(int position)
/*     */   {
/*  57 */     if (this.childScreen != null) {
/*  58 */       removeChildScreen();
/*     */     }
/*     */     
/*  61 */     this.currChildScreenPosition = position;
/*  62 */     if (position == 1) {
/*  63 */       this.childScreen = new TipChildRecordScreen(this.fileView, Math.max(0, getCurrRow()), 1);
/*     */     } else {
/*  65 */       this.childScreen = new TipChildRecordScreen(this.fileView, Math.max(0, getCurrRow()), 2);
/*     */     }
/*  67 */     setKeylistner(this.tblDetails);
/*  68 */     setKeylistner(getAlternativeTbl());
/*     */     
/*  70 */     return this.childScreen;
/*     */   }
/*     */   
/*     */ 
/*     */   protected BaseDisplay getNewDisplay(FileView view)
/*     */   {
/*  76 */     return new TipList(view, false);
/*     */   }
/*     */   
/*     */   public int getAvailableChildScreenPostion() {
/*  80 */     return 3;
/*     */   }
/*     */   
/*     */ 
/*     */   public void stopCellEditing()
/*     */   {
/*  86 */     super.stopCellEditing();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class TipViewer
/*     */     extends ReAbstractAction
/*     */   {
/*     */     private MenuPopupListener popup;
/*     */     
/*     */ 
/*     */     private FileView fileView;
/*     */     
/*     */ 
/*     */ 
/*     */     public TipViewer(MenuPopupListener popupMenu, FileView fileView)
/*     */     {
/* 104 */       super();
/* 105 */       this.popup = popupMenu;
/* 106 */       this.fileView = fileView;
/*     */     }
/*     */     
/*     */ 
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/* 112 */       JXTipOfTheDay tipOfTheDay = new JXTipOfTheDay(new TipModel(this.fileView));
/* 113 */       int row = this.popup.getPopupRow();
/* 114 */       for (int i = 0; i < row; i++) {
/* 115 */         tipOfTheDay.nextTip();
/*     */       }
/*     */       
/* 118 */       tipOfTheDay.showDialog(null);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/tip/display/TipList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */