/*    */ package net.sf.RecordEditor.tip.display;
/*    */ 
/*    */ import net.sf.JRecord.Details.AbstractLine;
/*    */ import net.sf.RecordEditor.re.file.FileView;
/*    */ import org.jdesktop.swingx.tips.TipOfTheDayModel;
/*    */ import org.jdesktop.swingx.tips.TipOfTheDayModel.Tip;
/*    */ 
/*    */ public class TipModel
/*    */   implements TipOfTheDayModel
/*    */ {
/*    */   private final FileView view;
/*    */   
/*    */   public TipModel(FileView view)
/*    */   {
/* 15 */     this.view = view;
/*    */   }
/*    */   
/*    */ 
/*    */   public int getTipCount()
/*    */   {
/* 21 */     return this.view.getRowCount();
/*    */   }
/*    */   
/*    */   public TipOfTheDayModel.Tip getTipAt(int index)
/*    */   {
/* 26 */     AbstractLine l = this.view.getLine(index);
/* 27 */     return new TipImp(l.getField(0, 0), l.getField(0, 1));
/*    */   }
/*    */   
/*    */   public static class TipImp implements TipOfTheDayModel.Tip
/*    */   {
/*    */     private final String name;
/*    */     private final String tip;
/*    */     
/*    */     public TipImp(Object name, Object tip)
/*    */     {
/* 37 */       this.name = fix(name);
/* 38 */       this.tip = fix(tip);
/*    */     }
/*    */     
/*    */     private String fix(Object o) {
/* 42 */       if (o == null) {
/* 43 */         return "";
/*    */       }
/* 45 */       return o.toString();
/*    */     }
/*    */     
/*    */     public String getTipName()
/*    */     {
/* 50 */       return this.name;
/*    */     }
/*    */     
/*    */     public Object getTip()
/*    */     {
/* 55 */       return this.tip;
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/tip/display/TipModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */