/*    */ package net.sf.RecordEditor.tip;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.util.Properties;
/*    */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*    */ import net.sf.JRecord.Details.AbstractLine;
/*    */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*    */ import net.sf.JRecord.Details.AbstractRecordDetail.FieldDetails;
/*    */ import net.sf.JRecord.Details.LayoutDetail;
/*    */ import net.sf.JRecord.IO.AbstractLineWriter;
/*    */ 
/*    */ public class PropertiesLineWriter extends AbstractLineWriter
/*    */ {
/*    */   private final String varPrefix;
/*    */   private OutputStream outStream;
/* 17 */   private AbstractLayoutDetails layout = null;
/* 18 */   private Properties props = null;
/*    */   
/* 20 */   private int idx = 1;
/*    */   
/*    */   public PropertiesLineWriter(String varPrefix) {
/* 23 */     this.varPrefix = varPrefix;
/*    */   }
/*    */   
/*    */   public void open(OutputStream outputStream)
/*    */     throws IOException
/*    */   {
/* 29 */     this.outStream = outputStream;
/* 30 */     this.props = new Properties();
/*    */   }
/*    */   
/*    */   public void write(AbstractLine line)
/*    */     throws IOException
/*    */   {
/* 36 */     if (this.layout == null) {
/* 37 */       this.layout = line.getLayout();
/* 38 */       if ((this.layout instanceof LayoutDetail)) {
/* 39 */         LayoutDetail l = (LayoutDetail)this.layout;
/* 40 */         if ((l.getExtraDetails() != null) && ((l.getExtraDetails() instanceof Properties))) {
/* 41 */           this.props = ((Properties)l.getExtraDetails());
/*    */         }
/*    */       }
/*    */     }
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 50 */     AbstractRecordDetail r = this.layout.getRecord(0);
/*    */     
/*    */ 
/* 53 */     String v = this.varPrefix + "." + this.idx + ".";
/* 54 */     for (int i = 0; i < r.getFieldCount(); i++) {
/* 55 */       Object o = line.getField(0, i);
/* 56 */       if ((o != null) && (!"".equals(o))) {
/* 57 */         this.props.put(v + r.getField(i).getName(), o);
/*    */       }
/*    */     }
/* 60 */     this.idx += 1;
/*    */   }
/*    */   
/*    */   public void close() throws IOException
/*    */   {
/* 65 */     if (this.props != null) {
/* 66 */       this.props.store(this.outStream, "Updated by RecordEditor - TipWriter");
/* 67 */       this.outStream.close();
/* 68 */       this.props = null;
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/tip/PropertiesLineWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */