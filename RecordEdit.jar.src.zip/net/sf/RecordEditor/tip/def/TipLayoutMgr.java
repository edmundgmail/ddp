/*    */ package net.sf.RecordEditor.tip.def;
/*    */ 
/*    */ import net.sf.JRecord.Common.FieldDetail;
/*    */ import net.sf.JRecord.Details.ArrayListLine;
/*    */ import net.sf.JRecord.Details.LayoutDetail;
/*    */ import net.sf.JRecord.Details.RecordDetail;
/*    */ import net.sf.JRecord.External.ExternalRecord;
/*    */ import net.sf.JRecord.External.RecordEditorXmlLoader;
/*    */ 
/*    */ 
/*    */ public class TipLayoutMgr
/*    */ {
/* 13 */   public static final LayoutDetail TIP_LAYOUT = ;
/*    */   
/*    */ 
/*    */   public static LayoutDetail getTipLayout()
/*    */   {
/* 18 */     LayoutDetail t = null;
/*    */     try
/*    */     {
/* 21 */       t = RecordEditorXmlLoader.getExternalRecord("<?xml version=\"1.0\" ?><RECORD RECORDNAME=\"TipDetails\" COPYBOOK=\"\" DELIMITER=\"&lt;Tab&gt;\" FILESTRUCTURE=\"102\" STYLE=\"0\" RECORDTYPE=\"Delimited\"  LIST=\"Y\" QUOTE=\"\" RecSep=\"default\" LINE_NO_FIELD_NAMES=\"1\">\t<FIELDS>\t\t<FIELD NAME=\"name\" POSITION=\"1\" TYPE=\"Char\"/>\t\t<FIELD NAME=\"description\" POSITION=\"2\" TYPE=\"118\"/>\t</FIELDS></RECORD>", "PO Layout").asLayoutDetail();
/*    */     } catch (Exception e) {
/* 23 */       e.printStackTrace();
/*    */     }
/*    */     
/* 26 */     return t;
/*    */   }
/*    */   
/*    */   public static int getIndexOf(String name) {
/* 30 */     int ret = -1;
/* 31 */     if (TIP_LAYOUT != null) {
/* 32 */       ret = ((RecordDetail)TIP_LAYOUT.getRecord(0)).getFieldIndex(name);
/*    */     }
/*    */     
/* 35 */     return ret;
/*    */   }
/*    */   
/*    */   public static ArrayListLine<FieldDetail, RecordDetail, LayoutDetail> getLine() {
/* 39 */     return new ArrayListLine(TIP_LAYOUT, 0, 1);
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/tip/def/TipLayoutMgr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */