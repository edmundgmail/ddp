/*    */ package net.sf.RecordEditor.tip.def;
/*    */ 
/*    */ import net.sf.RecordEditor.edit.display.extension.FieldDef;
/*    */ 
/*    */ public class TipField extends FieldDef
/*    */ {
/*  7 */   public static final FieldDef name = new TipField("Name", 0);
/*  8 */   public static final FieldDef description = new TipField("Description", 1);
/*    */   
/* 10 */   static final FieldDef[] allFields = { name, description };
/*    */   
/*    */   private final String matchChk;
/*    */   
/*    */   public static FieldDef[] getAllfields()
/*    */   {
/* 16 */     return (FieldDef[])allFields.clone();
/*    */   }
/*    */   
/*    */   private TipField(String name, int idx)
/*    */   {
/* 21 */     super(name, idx, false, false, true, false, false);
/* 22 */     this.matchChk = ("." + name.toLowerCase() + "=");
/*    */   }
/*    */   
/*    */   public boolean isMatch(String s)
/*    */   {
/* 27 */     if (s == null) {
/* 28 */       return false;
/*    */     }
/* 30 */     String lcS = s.toLowerCase();
/* 31 */     return (lcS.startsWith("tip.")) && (lcS.indexOf(this.matchChk) > 0);
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/tip/def/TipField.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */