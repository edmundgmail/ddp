/*    */ package net.sf.RecordEditor.tip;
/*    */ 
/*    */ import net.sf.JRecord.Common.RecordRunTimeException;
/*    */ import net.sf.JRecord.Details.AbstractLine;
/*    */ import net.sf.JRecord.Details.ArrayListLine;
/*    */ import net.sf.JRecord.Details.LayoutDetail;
/*    */ import net.sf.JRecord.Details.LineProvider;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TipLineProvider
/*    */   implements LineProvider<LayoutDetail, AbstractLine>
/*    */ {
/*    */   public AbstractLine getLine(LayoutDetail recordDescription)
/*    */   {
/* 21 */     return new ArrayListLine(recordDescription, 0, 1);
/*    */   }
/*    */   
/*    */   public AbstractLine getLine(LayoutDetail recordDescription, String linesText)
/*    */   {
/* 26 */     throw new RecordRunTimeException("Not Supported");
/*    */   }
/*    */   
/*    */   public AbstractLine getLine(LayoutDetail recordDescription, byte[] lineBytes)
/*    */   {
/* 31 */     throw new RecordRunTimeException("Not Supported");
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/tip/TipLineProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */