package net.sf.RecordEditor.jibx.compare;

public abstract class JiBX_MungeAdapter {}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/jibx/compare/JiBX_MungeAdapter.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */