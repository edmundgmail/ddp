/*    */ package net.sf.RecordEditor.jibx.compare;
/*    */ 
/*    */ public class File {
/*  4 */   public String name = "";
/*  5 */   public Layout layoutDetails = null;
/*    */   
/*    */   public static final String JiBX_bindingList = "|net.sf.RecordEditor.jibx.compare.JiBX_diffXmlBindingsFactory|";
/*    */   
/*    */   public Layout getLayoutDetails()
/*    */   {
/* 11 */     if (this.layoutDetails == null) {
/* 12 */       this.layoutDetails = new Layout();
/*    */     }
/* 14 */     return this.layoutDetails;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/jibx/compare/File.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */