/*   */ package net.sf.RecordEditor.jibx.compare;
/*   */ 
/*   */ import org.jibx.runtime.IUnmarshallable;
/*   */ 
/*   */ public class FieldSequence implements IUnmarshallable, org.jibx.runtime.IMarshallable {
/* 6 */   public String name = "";
/* 7 */   public String[] fields = null;
/* 8 */   public String[] fixedFields = null;
/*   */   public static final String JiBX_bindingList = "|net.sf.RecordEditor.jibx.compare.JiBX_diffXmlBindingsFactory|";
/*   */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/jibx/compare/FieldSequence.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */