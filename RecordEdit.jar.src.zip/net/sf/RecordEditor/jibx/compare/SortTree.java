/*   */ package net.sf.RecordEditor.jibx.compare;
/*   */ import org.jibx.runtime.IUnmarshallable;
/*   */ 
/* 4 */ public class SortTree implements IUnmarshallable, org.jibx.runtime.IMarshallable { public String recordName = "";
/*   */   public SortFields[] sortFields;
/*   */   public SortSummary[] sortSummary;
/*   */   public static final String JiBX_bindingList = "|net.sf.RecordEditor.jibx.compare.JiBX_diffXmlBindingsFactory|";
/*   */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/jibx/compare/SortTree.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */