/*   */ package net.sf.RecordEditor.jibx.compare;
/*   */ 
/*   */ import org.jibx.runtime.IUnmarshallable;
/*   */ 
/* 5 */ public class FieldTest implements IUnmarshallable, org.jibx.runtime.IMarshallable { public String booleanOperator = "And";
/*   */   public String recordName;
/* 7 */   public String fieldName = "";
/*   */   public int groupOperator;
/*   */   public String operator;
/*   */   public String value;
/*   */   public static final String JiBX_bindingList = "|net.sf.RecordEditor.jibx.compare.JiBX_diffXmlBindingsFactory|";
/*   */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/jibx/compare/FieldTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */