/*    */ package net.sf.RecordEditor.jibx.compare;
/*    */ 
/*    */ import org.jibx.runtime.IUnmarshallable;
/*    */ 
/*    */ public class DiffDefinition extends BaseCopyDif implements IUnmarshallable, org.jibx.runtime.IMarshallable {
/*    */   public static final String TYPE_SINGLE_LAYOUT = "SingleLayout";
/*    */   public static final String TYPE_TWO_LAYOUTS = "TwoLayouts";
/*  8 */   public String htmlFile = "";
/*    */   
/* 10 */   public boolean allRows = false;
/* 11 */   public boolean allFields = false;
/* 12 */   public boolean singleTable = false;
/*    */   public static final String JiBX_bindingList = "|net.sf.RecordEditor.jibx.compare.JiBX_diffXmlBindingsFactory|";
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/jibx/compare/DiffDefinition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */