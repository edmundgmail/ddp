/*    */ package net.sf.RecordEditor.jibx.compare;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ public class Layout implements org.jibx.runtime.IUnmarshallable, org.jibx.runtime.IMarshallable {
/*  6 */   public String name = "";
/*    */   
/*  8 */   public ArrayList<Record> records = null;
/*  9 */   public String saveFile = "";
/* 10 */   public String groupHeader = "";
/*    */   
/*    */ 
/*    */   public static final String JiBX_bindingList = "|net.sf.RecordEditor.jibx.compare.JiBX_diffXmlBindingsFactory|";
/*    */   
/*    */ 
/*    */ 
/*    */   public ArrayList<Record> getRecords()
/*    */   {
/* 19 */     if (this.records == null) {
/* 20 */       this.records = new ArrayList();
/*    */     }
/* 22 */     return this.records;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ArrayList<FilteredRecord> getFilteredRecords()
/*    */   {
/* 39 */     ArrayList<FilteredRecord> list = new ArrayList(this.records.size());
/*    */     
/*    */ 
/* 42 */     for (Record rec : getRecords()) {
/* 43 */       FilteredRecord fr = new FilteredRecord();
/* 44 */       fr.fields = rec.fields;
/* 45 */       fr.fieldTest = rec.fieldTest;
/* 46 */       fr.name = rec.name;
/*    */       
/* 48 */       list.add(fr);
/*    */     }
/* 50 */     return list;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/jibx/compare/Layout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */