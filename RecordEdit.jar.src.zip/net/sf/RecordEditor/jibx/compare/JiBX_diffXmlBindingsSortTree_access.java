package net.sf.RecordEditor.jibx.compare;

import org.jibx.runtime.IMarshaller;
import org.jibx.runtime.IUnmarshaller;

public class JiBX_diffXmlBindingsSortTree_access
  implements IUnmarshaller, IMarshaller
{}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/jibx/compare/JiBX_diffXmlBindingsSortTree_access.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */