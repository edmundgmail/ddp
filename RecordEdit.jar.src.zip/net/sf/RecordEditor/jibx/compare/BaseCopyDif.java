/*    */ package net.sf.RecordEditor.jibx.compare;
/*    */ 
/*    */ 
/*    */ public abstract class BaseCopyDif
/*    */ {
/*    */   public String type;
/*  7 */   public String complete = "NO";
/*  8 */   public Layout layoutDetails = null;
/*  9 */   public File oldFile = new File();
/* 10 */   public File newFile = new File();
/*    */   
/* 12 */   public String saveFile = "";
/*    */   
/* 14 */   public boolean stripTrailingSpaces = true;
/*    */   
/* 16 */   public boolean fileSaved = false;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Layout getLayoutDetails()
/*    */   {
/* 23 */     if (this.layoutDetails == null) {
/* 24 */       this.layoutDetails = new Layout();
/*    */     }
/* 26 */     return this.layoutDetails;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/jibx/compare/BaseCopyDif.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */