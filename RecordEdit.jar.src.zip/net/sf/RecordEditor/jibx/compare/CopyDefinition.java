/*    */ package net.sf.RecordEditor.jibx.compare;
/*    */ 
/*    */ import org.jibx.runtime.IUnmarshallable;
/*    */ 
/*    */ public class CopyDefinition extends BaseCopyDif implements IUnmarshallable, org.jibx.runtime.IMarshallable {
/*    */   public static final String STANDARD_COPY = "StandardCopy";
/*    */   public static final String COBOL_COPY = "CobolCopy";
/*    */   public static final String DELIM_COPY = "DelimCopy";
/*    */   public static final String VELOCITY_COPY = "Velocity";
/*    */   public static final String XML_COPY = "Xml";
/* 11 */   public String delimiter = ",";
/* 12 */   public String quote = "";
/* 13 */   public boolean namesOnFirstLine = true;
/* 14 */   public String velocityTemplate = "";
/* 15 */   public String font = "";
/*    */   
/* 17 */   public String fieldErrorFile = "";
/* 18 */   public int maxErrors = -1;
/*    */   
/* 20 */   public RecordTree treeDefinition = new RecordTree();
/*    */   public static final String JiBX_bindingList = "|net.sf.RecordEditor.jibx.compare.JiBX_diffXmlBindingsFactory|";
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/jibx/compare/CopyDefinition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */