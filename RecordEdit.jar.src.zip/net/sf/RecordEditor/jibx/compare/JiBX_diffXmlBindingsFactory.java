package net.sf.RecordEditor.jibx.compare;

import org.jibx.runtime.IBindingFactory;

public class JiBX_diffXmlBindingsFactory
  implements IBindingFactory
{
  private static IBindingFactory m_inst;
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/jibx/compare/JiBX_diffXmlBindingsFactory.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */