/*    */ package net.sf.RecordEditor.jibx.compare;
/*    */ 
/*    */ import org.jibx.runtime.IMarshallable;
/*    */ import org.jibx.runtime.IUnmarshallable;
/*    */ 
/*    */ public class EditorTask implements IUnmarshallable, IMarshallable
/*    */ {
/*    */   public static final String TASK_FILTER = "Filter";
/*    */   public static final String TASK_SORT_TREE = "SortTree";
/*    */   public static final String TASK_FIELD_TREE = "FieldTree";
/*    */   public static final String TASK_SORT = "Sort";
/*    */   public static final String TASK_RECORD_TREE = "RecordTree";
/*    */   public static final String TASK_VISIBLE_FIELDS = "VisibleFields";
/*    */   public static final String TASK_FIELD_SEQUENCE = "FieldSequence";
/*    */   public String type;
/* 16 */   public String layoutName = "";
/* 17 */   public Layout filter = null;
/* 18 */   public SortTree sortTree = null;
/*    */   public RecordTree recordTree;
/* 20 */   public FieldSequence fieldSequence = null;
/*    */   public static final String JiBX_bindingList = "|net.sf.RecordEditor.jibx.compare.JiBX_diffXmlBindingsFactory|";
/*    */   
/*    */   public EditorTask setFilter(Layout filterDetails) {
/* 24 */     this.type = "Filter";
/*    */     
/* 26 */     this.filter = filterDetails;
/* 27 */     this.layoutName = filterDetails.name;
/*    */     
/* 29 */     return this;
/*    */   }
/*    */   
/*    */   public EditorTask setSortTree(String id, String recordLayoutName, SortTree sortDetails)
/*    */   {
/* 34 */     this.type = id;
/*    */     
/* 36 */     this.layoutName = recordLayoutName;
/* 37 */     this.sortTree = sortDetails;
/*    */     
/* 39 */     return this;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public EditorTask setRecordTree(String recordLayoutName, RecordTree recordDetails)
/*    */   {
/* 48 */     this.type = "RecordTree";
/*    */     
/* 50 */     this.layoutName = recordLayoutName;
/* 51 */     this.recordTree = recordDetails;
/*    */     
/* 53 */     return this;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/jibx/compare/EditorTask.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */