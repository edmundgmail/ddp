/*    */ package net.sf.RecordEditor.jibx.compare;
/*    */ 
/*    */ import net.sf.JRecord.Details.RecordFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FilteredRecord
/*    */   extends Record
/*    */   implements RecordFilter
/*    */ {
/*    */   public String[] getFields()
/*    */   {
/* 13 */     return this.fields;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String getRecordName()
/*    */   {
/* 21 */     return this.name;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/jibx/compare/FilteredRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */