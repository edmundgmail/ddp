/*    */ package net.sf.RecordEditor.jibx.compare;
/*    */ 
/*    */ import org.jibx.runtime.IMarshallable;
/*    */ import org.jibx.runtime.IUnmarshallable;
/*    */ 
/*    */ public class Record implements IUnmarshallable, IMarshallable
/*    */ {
/*  8 */   public String name = "";
/*  9 */   public String[] fields = null;
/* 10 */   public Boolean include = null; public Boolean inGroup = null;
/* 11 */   public java.util.ArrayList<FieldTest> fieldTest = null;
/*    */   public static final String JiBX_bindingList = "|net.sf.RecordEditor.jibx.compare.JiBX_diffXmlBindingsFactory|";
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/jibx/compare/Record.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */