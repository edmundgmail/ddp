/*    */ package net.sf.RecordEditor.jibx;
/*    */ 
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileOutputStream;
/*    */ import org.jibx.runtime.BindingDirectory;
/*    */ import org.jibx.runtime.IBindingFactory;
/*    */ import org.jibx.runtime.IMarshallingContext;
/*    */ import org.jibx.runtime.IUnmarshallingContext;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JibxCall<xmlClass>
/*    */ {
/*    */   private Class<xmlClass> requireClass;
/*    */   
/*    */   public JibxCall(Class requiredClass)
/*    */   {
/* 27 */     this.requireClass = requiredClass;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public xmlClass marshal(String filename)
/*    */     throws Exception
/*    */   {
/*    */     try
/*    */     {
/* 39 */       FileInputStream in = new FileInputStream(filename);
/* 40 */       return 
/* 41 */         (xmlClass)BindingDirectory.getFactory(this.requireClass).createUnmarshallingContext().unmarshalDocument(in, null);
/*    */     } catch (NoClassDefFoundError e) {
/* 43 */       e.printStackTrace();
/*    */     }
/* 45 */     return null;
/*    */   }
/*    */   
/*    */   public void unmarshal(String filename, xmlClass output) throws Exception
/*    */   {
/*    */     try
/*    */     {
/* 52 */       IMarshallingContext mctx = 
/* 53 */         BindingDirectory.getFactory(this.requireClass).createMarshallingContext();
/* 54 */       mctx.setIndent(2);
/* 55 */       FileOutputStream out = new FileOutputStream(filename);
/* 56 */       mctx.marshalDocument(output, "UTF-8", null, out);
/*    */     } catch (NoClassDefFoundError e) {
/* 58 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/jibx/JibxCall.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */