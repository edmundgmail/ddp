/*    */ package net.sf.RecordEditor.copy;
/*    */ 
/*    */ import net.sf.RecordEditor.re.openFile.LayoutSelectionFileCreator;
/*    */ import net.sf.RecordEditor.utils.screenManager.ReMainFrame;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CopyFileLayout
/*    */ {
/*    */   public static final void newMenu()
/*    */   {
/* 16 */     new Menu(new LayoutSelectionFileCreator(), "CobolFiles.txt");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static void main(String[] args)
/*    */   {
/* 24 */     new ReMainFrame("File Copy", "", "Cpy");
/* 25 */     newMenu();
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/copy/CopyFileLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */