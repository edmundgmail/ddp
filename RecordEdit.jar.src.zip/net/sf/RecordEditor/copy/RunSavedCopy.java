/*     */ package net.sf.RecordEditor.copy;
/*     */ 
/*     */ import java.awt.Container;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.FileOutputStream;
/*     */ import java.util.Properties;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDesktopPane;
/*     */ import javax.swing.JTextArea;
/*     */ import net.sf.RecordEditor.jibx.JibxCall;
/*     */ import net.sf.RecordEditor.jibx.compare.CopyDefinition;
/*     */ import net.sf.RecordEditor.re.openFile.AbstractLayoutSelectCreator;
/*     */ import net.sf.RecordEditor.re.openFile.AbstractLayoutSelection;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMainFrame;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.FileSelectCombo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RunSavedCopy
/*     */   extends ReFrame
/*     */ {
/*     */   private static final int WIDTH_INCREASE = 175;
/*     */   private static final int HEIGHT_INCREASE = 7;
/*  37 */   private FileSelectCombo xmlFileName = new FileSelectCombo("SavedCpy.", 25, false, false);
/*  38 */   private BaseHelpPanel pnl = new BaseHelpPanel();
/*     */   
/*  40 */   private JButton runCompareDialogBtn = SwingUtils.newButton("Run Copy Dialog");
/*  41 */   private JButton runCompareBtn = SwingUtils.newButton("Run Copy");
/*     */   
/*     */ 
/*     */   private int dbIdx;
/*     */   
/*     */ 
/*     */   private String rFiles;
/*     */   
/*     */ 
/*     */   private AbstractLayoutSelectCreator<AbstractLayoutSelection> layoutCreator;
/*     */   
/*     */ 
/*  53 */   private ActionListener listner = new ActionListener()
/*     */   {
/*     */ 
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/*  58 */       if (e.getSource() == RunSavedCopy.this.runCompareDialogBtn) {
/*  59 */         RunSavedCopy.this.runCopyDialog();
/*     */       } else {
/*  61 */         RunSavedCopy.this.runCopy();
/*     */       }
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public RunSavedCopy(AbstractLayoutSelectCreator creator, int databaseIdx, String recentFiles)
/*     */   {
/*  71 */     super("", "Run Saved Copy File:", "", null);
/*     */     
/*  73 */     this.rFiles = recentFiles;
/*     */     
/*  75 */     ReMainFrame frame = ReMainFrame.getMasterFrame();
/*  76 */     int height = frame.getDesktop().getHeight() - 1;
/*  77 */     int width = frame.getDesktop().getWidth() - 1;
/*     */     
/*  79 */     String fname = Parameters.getFileName("CopySaveFile");
/*     */     
/*  81 */     this.layoutCreator = creator;
/*  82 */     this.dbIdx = databaseIdx;
/*     */     
/*  84 */     this.xmlFileName.setText(Parameters.getFileName("CopySaveDirectory"));
/*     */     
/*  86 */     if ((fname == null) || ("".equals(fname))) {
/*  87 */       fname = Parameters.getFileName("CopySaveDirectory");
/*     */     }
/*  89 */     this.xmlFileName.setText(fname);
/*     */     
/*  91 */     this.pnl.setGapRE(BasePanel.GAP3);
/*  92 */     this.pnl.addLineRE("New File", this.xmlFileName);
/*  93 */     this.pnl.setGapRE(BasePanel.GAP5);
/*     */     
/*  95 */     this.pnl.addLineRE("", null, this.runCompareDialogBtn);
/*  96 */     this.pnl.setGapRE(BasePanel.GAP1);
/*  97 */     this.pnl.addLineRE("", null, this.runCompareBtn);
/*  98 */     this.pnl.setGapRE(BasePanel.GAP5);
/*     */     
/* 100 */     this.pnl.addMessage(new JTextArea());
/*     */     
/* 102 */     super.getContentPane().add(this.pnl);
/*     */     
/* 104 */     super.pack();
/* 105 */     setBounds(getY(), getX(), Math.min(width, getWidth() + 175), Math.min(height, getHeight() + 7));
/*     */     
/*     */ 
/*     */ 
/* 109 */     super.setVisible(true);
/*     */     
/* 111 */     this.runCompareDialogBtn.addActionListener(this.listner);
/* 112 */     this.runCompareBtn.addActionListener(this.listner);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void windowClosing()
/*     */   {
/* 123 */     String s = this.xmlFileName.getText();
/* 124 */     if (!"".equals(s)) {
/*     */       try {
/* 126 */         Properties p = Parameters.getProperties();
/*     */         
/* 128 */         if (!s.equals(p.getProperty("CopySaveFile"))) {
/* 129 */           p.setProperty("CopySaveFile", s);
/*     */           
/* 131 */           p.store(new FileOutputStream(Parameters.getPropertyFileName()), "RecordEditor");
/*     */         }
/*     */         
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 137 */         e.printStackTrace();
/*     */       }
/*     */     }
/* 140 */     super.windowClosing();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void runCopyDialog()
/*     */   {
/* 149 */     CopyDefinition def = readXml();
/*     */     
/* 151 */     runCopyDialog(def);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void runCopyDialog(CopyDefinition def)
/*     */   {
/* 159 */     if (def != null) {
/* 160 */       if ("StandardCopy".equals(def.type)) {
/* 161 */         new CopyTwoLayouts(createLayout(), createLayout(), def, this.rFiles);
/* 162 */       } else if ("CobolCopy".equals(def.type)) {
/* 163 */         new CobolCopy(def);
/* 164 */       } else if ("DelimCopy".equals(def.type)) {
/* 165 */         new Copy2Delim(createLayout(), def);
/* 166 */       } else if ("Velocity".equals(def.type)) {
/* 167 */         new Copy2Delim(createLayout(), def);
/* 168 */       } else if ("Xml".equals(def.type)) {
/* 169 */         new Copy2Xml(createLayout(), def, this.rFiles);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void runCopy()
/*     */   {
/* 179 */     CopyDefinition def = readXml();
/*     */     
/* 181 */     if (def != null) {
/* 182 */       if (!"Yes".equalsIgnoreCase(def.complete)) {
/* 183 */         runCopyDialog(def);
/*     */       } else {
/*     */         try {
/* 186 */           DoCopy.copy(createLayout(), createLayout(), def);
/*     */         }
/*     */         catch (Exception e) {
/* 189 */           String s = "Error Running Copy";
/* 190 */           e.printStackTrace();
/* 191 */           this.pnl.setMessageTxtRE(s);
/* 192 */           Common.logMsg(s, e);
/* 193 */           return;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private AbstractLayoutSelection createLayout() {
/* 200 */     AbstractLayoutSelection ret = this.layoutCreator.create();
/* 201 */     ret.setDatabaseIdx(this.dbIdx);
/* 202 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */   private CopyDefinition readXml()
/*     */   {
/* 208 */     CopyDefinition def = null;
/* 209 */     String filename = this.xmlFileName.getText();
/*     */     
/* 211 */     if ((filename == null) || ("".equals(filename))) {
/* 212 */       this.pnl.setMessageTxtRE("You must Enter a filename");
/*     */     } else {
/*     */       try {
/* 215 */         JibxCall<CopyDefinition> jibx = new JibxCall(CopyDefinition.class);
/* 216 */         def = (CopyDefinition)jibx.marshal(filename);
/* 217 */         def.saveFile = filename;
/*     */       } catch (Exception e) {
/* 219 */         String s = "Error Loading Record Layout";
/* 220 */         e.printStackTrace();
/* 221 */         this.pnl.setMessageTxtRE(s);
/* 222 */         Common.logMsg(s, e);
/*     */       }
/*     */     }
/*     */     
/* 226 */     return def;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/copy/RunSavedCopy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */