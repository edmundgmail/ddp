/*    */ package net.sf.RecordEditor.copy;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import net.sf.RecordEditor.re.openFile.LayoutSelectionDB;
/*    */ import net.sf.RecordEditor.utils.CopyBookDbReader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BatchCopyDbLayout
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/* 22 */     if ((args == null) || (args.length == 0)) {
/* 23 */       System.out.println("You must supply a Copy definition !!! ");
/*    */     } else {
/* 25 */       CopyBookDbReader cpyInterfact = CopyBookDbReader.getInstance();
/* 26 */       LayoutSelectionDB db1 = new LayoutSelectionDB(cpyInterfact, true);
/* 27 */       LayoutSelectionDB db2 = new LayoutSelectionDB(cpyInterfact, true);
/*    */       
/* 29 */       db1.setLoadFromFile(true);
/* 30 */       db2.setLoadFromFile(false);
/*    */       
/* 32 */       new BatchCopy(db1, db2, args);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/copy/BatchCopyDbLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */