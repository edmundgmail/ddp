/*     */ package net.sf.RecordEditor.copy;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.io.PrintStream;
/*     */ import java.nio.charset.Charset;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextField;
/*     */ import net.sf.JRecord.Common.Conversion;
/*     */ import net.sf.JRecord.Common.RecordRunTimeException;
/*     */ import net.sf.RecordEditor.jibx.JibxCall;
/*     */ import net.sf.RecordEditor.jibx.compare.CopyDefinition;
/*     */ import net.sf.RecordEditor.jibx.compare.File;
/*     */ import net.sf.RecordEditor.jibx.compare.Layout;
/*     */ import net.sf.RecordEditor.re.openFile.AbstractLayoutSelection;
/*     */ import net.sf.RecordEditor.re.util.wizard.AbstractFilePnl;
/*     */ import net.sf.RecordEditor.utils.charsets.FontCombo;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions.FileNameOpt;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.ComboBoxs.DelimiterCombo;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.TreeComboFileSelect;
/*     */ import net.sf.RecordEditor.utils.wizards.AbstractWizard;
/*     */ import net.sf.RecordEditor.utils.wizards.AbstractWizardPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Copy2Delim
/*     */   extends AbstractWizard<CopyDefinition>
/*     */ {
/*     */   private CopyWizardFinalPnl finalScreen;
/*  39 */   private JibxCall<CopyDefinition> jibx = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Copy2Delim(AbstractLayoutSelection recordSelection1)
/*     */   {
/*  48 */     this(recordSelection1, new CopyDefinition());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Copy2Delim(AbstractLayoutSelection recordSelection1, CopyDefinition definition)
/*     */   {
/*  59 */     super("Copy to Delimited file", definition);
/*     */     
/*  61 */     AbstractWizardPanel<CopyDefinition>[] pnls = new AbstractWizardPanel[3];
/*     */     
/*  63 */     recordSelection1.setMessage(super.getMessage());
/*     */     
/*  65 */     definition.type = "DelimCopy";
/*     */     
/*  67 */     this.finalScreen = new CopyWizardFinalPnl(recordSelection1, null);
/*  68 */     pnls[0] = new GetFiles(recordSelection1);
/*  69 */     pnls[1] = new FieldSelection(recordSelection1, null, "");
/*  70 */     pnls[2] = this.finalScreen;
/*     */     
/*  72 */     super.setPanels(pnls);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void finished(CopyDefinition details)
/*     */   {
/*  83 */     if (this.finalScreen.isToRun()) {
/*  84 */       this.finalScreen.run();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void executeAction(int action)
/*     */   {
/*  96 */     if (action == 1) {
/*     */       try {
/*  98 */         CopyDefinition diff = (CopyDefinition)super.getActivePanel().getValues();
/*     */         
/* 100 */         if (!"".equals(diff.saveFile)) {
/* 101 */           if (this.jibx == null) {
/* 102 */             this.jibx = new JibxCall(CopyDefinition.class);
/*     */           }
/*     */           
/* 105 */           this.jibx.unmarshal(diff.saveFile, diff);
/* 106 */           diff.fileSaved = true;
/*     */         }
/*     */       } catch (Exception e) {
/* 109 */         e.printStackTrace();
/* 110 */         Common.logMsgRaw(FILE_SAVE_FAILED, e);
/*     */       }
/*     */     } else {
/* 113 */       super.executeAction(action);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isActionAvailable(int action)
/*     */   {
/* 122 */     if (action == 1) {
/* 123 */       return true;
/*     */     }
/* 125 */     return super.isActionAvailable(action);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static class GetFiles
/*     */     extends AbstractFilePnl<CopyDefinition>
/*     */   {
/* 133 */     private CopyDefinition values = new CopyDefinition();
/*     */     
/*     */ 
/* 136 */     private TreeComboFileSelect newFileName = new TreeComboFileSelect(true, false, true, getRecentList(), getRecentDirectoryList());
/*     */     
/*     */     private AbstractLayoutSelection layoutSelection1;
/*     */     
/* 140 */     private DelimiterCombo delimCombo = DelimiterCombo.NewDelimCombo();
/* 141 */     private JTextField delimTxt = new JTextField(8);
/* 142 */     private JCheckBox names1stLineChk = new JCheckBox();
/* 143 */     private JTextField quoteTxt = new JTextField();
/* 144 */     private FontCombo fontCombo = new FontCombo();
/*     */     
/*     */     public GetFiles(AbstractLayoutSelection selection1)
/*     */     {
/* 148 */       super("CobolFiles.txt");
/*     */       
/* 150 */       this.newFileName.setText(Common.OPTIONS.DEFAULT_FILE_DIRECTORY.getWithStar());
/* 151 */       this.layoutSelection1 = selection1;
/*     */       
/* 153 */       setHelpURLre(Common.formatHelpURL("diff2.html"));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public CopyDefinition getValues()
/*     */       throws Exception
/*     */     {
/* 163 */       this.values.oldFile.name = getCurrentFileName();
/* 164 */       this.values.newFile.name = this.newFileName.getText();
/*     */       
/* 166 */       this.values.oldFile.getLayoutDetails().name = this.layoutSelection1.getLayoutName();
/*     */       
/* 168 */       this.values.delimiter = getDelim();
/* 169 */       this.values.namesOnFirstLine = this.names1stLineChk.isSelected();
/* 170 */       this.values.quote = this.quoteTxt.getText();
/* 171 */       this.values.font = this.fontCombo.getText();
/*     */       
/* 173 */       if ((!"".equals(this.values.font)) && (!Charset.isSupported(this.values.font))) {
/* 174 */         this.fontCombo.requestFocus();
/* 175 */         throw new RuntimeException("font (charset) is not supported");
/*     */       }
/* 177 */       if ((this.values.delimiter.toLowerCase().startsWith("x'")) && (Conversion.isMultiByte(this.values.font))) {
/* 178 */         throw new RuntimeException("Hex field sperators are only supported for single byte charsets (fonts)");
/*     */       }
/* 180 */       if (this.layoutSelection1.getRecordLayout(getCurrentFileName()) == null) {
/* 181 */         throw new RuntimeException("Layout Does not exist");
/*     */       }
/*     */       
/* 184 */       return this.values;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void setValues(CopyDefinition detail)
/*     */       throws Exception
/*     */     {
/* 192 */       System.out.println("Setting Values ... ");
/* 193 */       this.values = detail;
/*     */       
/* 195 */       if (!"".equals(this.values.oldFile.name)) {
/* 196 */         this.fileName.setText(this.values.oldFile.name);
/*     */       }
/*     */       
/* 199 */       if (!"".equals(this.values.newFile.name)) {
/* 200 */         this.newFileName.setText(this.values.newFile.name);
/*     */       }
/*     */       
/* 203 */       if (!"".equals(this.values.oldFile.getLayoutDetails().name)) {
/* 204 */         this.layoutSelection1.setLayoutName(this.values.oldFile.getLayoutDetails().name);
/*     */       }
/*     */       
/* 207 */       this.delimTxt.setText("");
/* 208 */       this.delimCombo.setEnglish(this.values.delimiter);
/* 209 */       if ((this.values.delimiter != null) && (!this.values.delimiter.equals(this.delimCombo.getSelectedEnglish()))) {
/* 210 */         this.delimTxt.setText(this.values.delimiter);
/*     */       }
/* 212 */       this.names1stLineChk.setSelected(this.values.namesOnFirstLine);
/* 213 */       this.quoteTxt.setText(this.values.quote);
/* 214 */       this.fontCombo.setText(this.values.font);
/*     */     }
/*     */     
/*     */ 
/*     */     protected void addFileName(BaseHelpPanel pnl)
/*     */     {
/* 220 */       pnl.addLineRE("Old File", this.fileName);
/*     */       
/* 222 */       pnl.addLineRE("New File", this.newFileName);
/*     */     }
/*     */     
/*     */ 
/*     */     protected void addLayoutSelection()
/*     */     {
/* 228 */       this.layoutSelection1.addLayoutSelection(this, this.fileName, new JPanel(), null, null);
/* 229 */       JPanel delimPnl = new JPanel(new BorderLayout());
/* 230 */       JPanel orLabel = new JPanel();
/* 231 */       orLabel.add(new JLabel("or"));
/*     */       
/* 233 */       delimPnl.add("West", this.delimCombo);
/* 234 */       delimPnl.add("Center", orLabel);
/* 235 */       delimPnl.add("East", this.delimTxt);
/*     */       
/* 237 */       setGapRE(GAP3);
/* 238 */       addLineRE("Field Delimiter", delimPnl);
/* 239 */       setHeightRE(HEIGHT_1P1);
/* 240 */       setGapRE(GAP1);
/*     */       
/* 242 */       addLineRE("Names on 1st Line", this.names1stLineChk);
/* 243 */       addLineRE("Quote", this.quoteTxt);
/* 244 */       addLineRE("Font Name", this.fontCombo);
/*     */       
/* 246 */       setGapRE(GAP3);
/*     */     }
/*     */     
/*     */     private String getDelim()
/*     */     {
/* 251 */       String ret = this.delimTxt.getText();
/*     */       
/* 253 */       if ("".equals(ret)) {
/* 254 */         ret = this.delimCombo.getSelectedEnglish();
/*     */       } else {
/* 256 */         String v = this.delimTxt.getText();
/*     */         
/* 258 */         if (v.length() >= 2) {
/* 259 */           if ((v.length() == 5) && (v.toLowerCase().startsWith("x'")) && (v.endsWith("'"))) {
/*     */             try {
/* 261 */               Conversion.getByteFromHexString(v);
/*     */             } catch (Exception e) {
/* 263 */               String msg1 = LangConversion.convert(14, "Invalid Delimiter - Invalid  hex string: {0}", v.substring(2, 3));
/*     */               
/*     */ 
/*     */ 
/*     */ 
/* 268 */               throw new RuntimeException(msg1);
/*     */             }
/*     */           } else {
/* 271 */             String msg1 = "Invalid Delimiter, should be a single character or a hex character";
/*     */             
/* 273 */             throw new RecordRunTimeException(msg1);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 278 */       return ret;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/copy/Copy2Delim.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */