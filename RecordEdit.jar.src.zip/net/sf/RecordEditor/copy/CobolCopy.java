/*     */ package net.sf.RecordEditor.copy;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import javax.swing.JPanel;
/*     */ import net.sf.RecordEditor.jibx.JibxCall;
/*     */ import net.sf.RecordEditor.jibx.compare.CopyDefinition;
/*     */ import net.sf.RecordEditor.jibx.compare.File;
/*     */ import net.sf.RecordEditor.jibx.compare.Layout;
/*     */ import net.sf.RecordEditor.re.openFile.LayoutSelectionFile;
/*     */ import net.sf.RecordEditor.re.util.wizard.AbstractFilePnl;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions.FileNameOpt;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.TreeComboFileSelect;
/*     */ import net.sf.RecordEditor.utils.wizards.AbstractWizard;
/*     */ import net.sf.RecordEditor.utils.wizards.AbstractWizardPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CobolCopy
/*     */   extends AbstractWizard<CopyDefinition>
/*     */ {
/*     */   private CopyWizardFinalPnl finalScreen;
/*  27 */   private JibxCall<CopyDefinition> jibx = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CobolCopy()
/*     */   {
/*  36 */     this(new CopyDefinition());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CobolCopy(CopyDefinition definition)
/*     */   {
/*  47 */     super("Cobol Copy", definition);
/*     */     
/*  49 */     AbstractWizardPanel<CopyDefinition>[] pnls = new AbstractWizardPanel[2];
/*  50 */     LayoutSelectionFile recordSelection1 = new LayoutSelectionFile(true);
/*  51 */     LayoutSelectionFile recordSelection2 = new LayoutSelectionFile(true);
/*     */     
/*  53 */     recordSelection1.setMessage(super.getMessage());
/*     */     
/*  55 */     definition.type = "CobolCopy";
/*     */     
/*  57 */     this.finalScreen = new CopyWizardFinalPnl(recordSelection1, recordSelection2);
/*  58 */     pnls[0] = new GetFiles(recordSelection1, recordSelection2);
/*     */     
/*  60 */     pnls[1] = this.finalScreen;
/*     */     
/*  62 */     super.setPanels(pnls);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void finished(CopyDefinition details)
/*     */   {
/*  73 */     if (this.finalScreen.isToRun()) {
/*  74 */       this.finalScreen.run();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void executeAction(int action)
/*     */   {
/*  86 */     if (action == 1) {
/*     */       try {
/*  88 */         CopyDefinition diff = (CopyDefinition)super.getActivePanel().getValues();
/*     */         
/*  90 */         if (!"".equals(diff.saveFile)) {
/*  91 */           if (this.jibx == null) {
/*  92 */             this.jibx = new JibxCall(CopyDefinition.class);
/*     */           }
/*     */           
/*  95 */           this.jibx.unmarshal(diff.saveFile, diff);
/*  96 */           diff.fileSaved = true;
/*     */         }
/*     */       } catch (Exception e) {
/*  99 */         e.printStackTrace();
/* 100 */         Common.logMsgRaw(FILE_SAVE_FAILED, e);
/*     */       }
/*     */     } else {
/* 103 */       super.executeAction(action);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isActionAvailable(int action)
/*     */   {
/* 112 */     if (action == 1) {
/* 113 */       return true;
/*     */     }
/* 115 */     return super.isActionAvailable(action);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class GetFiles
/*     */     extends AbstractFilePnl<CopyDefinition>
/*     */   {
/* 127 */     private CopyDefinition values = new CopyDefinition();
/*     */     
/*     */ 
/* 130 */     private TreeComboFileSelect newFileName = new TreeComboFileSelect(true, false, true, this.recent);
/*     */     private LayoutSelectionFile layoutSelection1;
/*     */     private LayoutSelectionFile layoutSelection2;
/*     */     
/*     */     public GetFiles(LayoutSelectionFile selection1, LayoutSelectionFile selection2) {
/* 135 */       super("CobolFiles.txt");
/*     */       
/* 137 */       String s = Common.OPTIONS.DEFAULT_FILE_DIRECTORY.getWithStar();
/*     */       
/* 139 */       this.newFileName.setText(s);
/* 140 */       this.layoutSelection1 = selection1;
/* 141 */       this.layoutSelection2 = selection2;
/*     */       
/* 143 */       this.layoutSelection1.setLayoutName(Common.OPTIONS.DEFAULT_COBOL_DIRECTORY.get());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public CopyDefinition getValues()
/*     */       throws Exception
/*     */     {
/* 154 */       this.values.oldFile.name = getCurrentFileName();
/* 155 */       this.values.newFile.name = this.newFileName.getText();
/*     */       
/* 157 */       this.values.oldFile.getLayoutDetails().name = this.layoutSelection1.getLayoutName();
/* 158 */       this.values.newFile.getLayoutDetails().name = this.layoutSelection2.getLayoutName();
/* 159 */       if (this.layoutSelection1.getRecordLayout(getCurrentFileName()) == null) {
/* 160 */         throw new RuntimeException("Layout Does not exist");
/*     */       }
/*     */       
/* 163 */       return this.values;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void setValues(CopyDefinition detail)
/*     */       throws Exception
/*     */     {
/* 171 */       System.out.println("Setting Values ... ");
/* 172 */       this.values = detail;
/*     */       
/* 174 */       if (!"".equals(this.values.oldFile.name)) {
/* 175 */         this.fileName.setText(this.values.oldFile.name);
/*     */       }
/*     */       
/* 178 */       if (!"".equals(this.values.newFile.name)) {
/* 179 */         this.newFileName.setText(this.values.newFile.name);
/*     */       }
/*     */       
/* 182 */       if (!"".equals(this.values.oldFile.getLayoutDetails().name)) {
/* 183 */         this.layoutSelection1.setLayoutName(this.values.oldFile.getLayoutDetails().name);
/*     */       }
/*     */       
/* 186 */       if (!"".equals(this.values.newFile.getLayoutDetails().name)) {
/* 187 */         this.layoutSelection2.setLayoutName(this.values.newFile.getLayoutDetails().name);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void addFileName(BaseHelpPanel pnl)
/*     */     {
/* 199 */       pnl.addLineRE("Old File", this.fileName);
/*     */       
/* 201 */       pnl.addLineRE("New File", this.newFileName);
/*     */     }
/*     */     
/*     */ 
/*     */     protected void addLayoutSelection()
/*     */     {
/* 207 */       this.layoutSelection1.addLayoutSelection(this, this.fileName, new JPanel(), null, null);
/* 208 */       setGapRE(GAP3);
/* 209 */       this.layoutSelection2.addLayoutSelection(this, getGoPanel(), this.layoutSelection1.getCopybookFile());
/* 210 */       setGapRE(GAP3);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/copy/CobolCopy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */