/*    */ package net.sf.RecordEditor.copy;
/*    */ 
/*    */ import net.sf.RecordEditor.re.openFile.LayoutSelectionDBCreator;
/*    */ import net.sf.RecordEditor.utils.CopyBookDbReader;
/*    */ import net.sf.RecordEditor.utils.CopyBookInterface;
/*    */ import net.sf.RecordEditor.utils.screenManager.ReMainFrame;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CopyDBLayout
/*    */ {
/*    */   public static final void newMenu(CopyBookInterface cpyInterfact)
/*    */   {
/* 18 */     new Menu(new LayoutSelectionDBCreator(cpyInterfact), "Files.txt");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static void main(String[] args)
/*    */   {
/* 26 */     new ReMainFrame("File Copy", "", "Cpy");
/* 27 */     newMenu(CopyBookDbReader.getInstance());
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/copy/CopyDBLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */