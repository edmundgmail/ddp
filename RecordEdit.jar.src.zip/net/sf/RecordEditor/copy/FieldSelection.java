/*    */ package net.sf.RecordEditor.copy;
/*    */ 
/*    */ import javax.swing.JComponent;
/*    */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*    */ import net.sf.RecordEditor.jibx.compare.CopyDefinition;
/*    */ import net.sf.RecordEditor.jibx.compare.File;
/*    */ import net.sf.RecordEditor.jibx.compare.Layout;
/*    */ import net.sf.RecordEditor.re.file.filter.BaseFieldSelection;
/*    */ import net.sf.RecordEditor.re.file.filter.FilterDetails;
/*    */ import net.sf.RecordEditor.re.openFile.AbstractLayoutSelection;
/*    */ import net.sf.RecordEditor.re.openFile.FormatFileName;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*    */ import net.sf.RecordEditor.utils.wizards.AbstractWizardPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FieldSelection
/*    */   extends BaseFieldSelection
/*    */   implements AbstractWizardPanel<CopyDefinition>
/*    */ {
/*    */   private CopyDefinition values;
/* 25 */   private String lastLayoutName1 = "";
/*    */   
/*    */ 
/*    */   private AbstractLayoutSelection selection1;
/*    */   
/* 30 */   private static final AbstractLayoutDetails layout2 = null;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public FieldSelection(AbstractLayoutSelection layoutSelection1, FormatFileName layoutSelection2, String helpName)
/*    */   {
/* 40 */     this.selection1 = layoutSelection1;
/*    */     
/* 42 */     if (((helpName != null ? 1 : 0) & (!"".equals(helpName) ? 1 : 0)) != 0) {
/* 43 */       setHelpURLre(Common.formatHelpURL(helpName));
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public CopyDefinition getValues()
/*    */     throws Exception
/*    */   {
/* 53 */     String sold = this.values.oldFile.layoutDetails.name;
/*    */     
/* 55 */     this.values.oldFile.layoutDetails = super.getFilter().getExternalLayout();
/* 56 */     this.values.oldFile.layoutDetails.name = sold;
/*    */     
/* 58 */     return this.values;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setValues(CopyDefinition detail)
/*    */     throws Exception
/*    */   {
/* 67 */     this.values = detail;
/*    */     
/* 69 */     if (!this.lastLayoutName1.equalsIgnoreCase(this.values.oldFile.getLayoutDetails().name)) {
/* 70 */       super.setRecordLayout(this.selection1.getRecordLayout(this.values.oldFile.getLayoutDetails().name), layout2, false, SwingUtils.COMBO_TABLE_ROW_HEIGHT * 4);
/*    */       
/* 72 */       super.getFilter().updateFromExternalLayout(detail.oldFile.layoutDetails);
/*    */       
/* 74 */       this.lastLayoutName1 = this.values.oldFile.layoutDetails.name;
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public JComponent getComponent()
/*    */   {
/* 84 */     return this;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean skip()
/*    */   {
/* 93 */     return false;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/copy/FieldSelection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */