/*     */ package net.sf.RecordEditor.copy;
/*     */ 
/*     */ import net.sf.JRecord.Common.RecordRunTimeException;
/*     */ import net.sf.RecordEditor.jibx.JibxCall;
/*     */ import net.sf.RecordEditor.jibx.compare.CopyDefinition;
/*     */ import net.sf.RecordEditor.jibx.compare.EditorTask;
/*     */ import net.sf.RecordEditor.jibx.compare.File;
/*     */ import net.sf.RecordEditor.jibx.compare.Layout;
/*     */ import net.sf.RecordEditor.re.openFile.AbstractLayoutSelection;
/*     */ import net.sf.RecordEditor.re.script.CreateRecordTreePnl;
/*     */ import net.sf.RecordEditor.re.util.wizard.AbstractFilePnl;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.TreeComboFileSelect;
/*     */ import net.sf.RecordEditor.utils.wizards.AbstractWizard;
/*     */ import net.sf.RecordEditor.utils.wizards.AbstractWizardPanel;
/*     */ 
/*     */ public class Copy2Xml extends AbstractWizard<CopyDefinition>
/*     */ {
/*     */   private CopyWizardFinalPnl finalScreen;
/*  21 */   private JibxCall<CopyDefinition> jibx = null;
/*     */   
/*     */   public Copy2Xml(AbstractLayoutSelection recordSelection1) {
/*  24 */     this(recordSelection1, new CopyDefinition(), "");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Copy2Xml(AbstractLayoutSelection recordSelection1, CopyDefinition definition, String recentFiles)
/*     */   {
/*  33 */     super("Copy to Xml file", definition);
/*     */     
/*  35 */     AbstractWizardPanel<CopyDefinition>[] pnls = new AbstractWizardPanel[4];
/*     */     
/*  37 */     recordSelection1.setMessage(super.getMessage());
/*     */     
/*  39 */     definition.type = "Xml";
/*     */     
/*  41 */     this.finalScreen = new CopyWizardFinalPnl(recordSelection1, null);
/*  42 */     pnls[0] = new GetFiles(recordSelection1, recentFiles);
/*  43 */     pnls[1] = new FieldSelection(recordSelection1, null, "");
/*  44 */     pnls[2] = new CreateTree(recordSelection1);
/*  45 */     pnls[3] = this.finalScreen;
/*     */     
/*  47 */     super.setPanels(pnls);
/*     */   }
/*     */   
/*     */ 
/*     */   public void finished(CopyDefinition details)
/*     */   {
/*  53 */     if (this.finalScreen.isToRun()) {
/*  54 */       this.finalScreen.run();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void executeAction(int action)
/*     */   {
/*  65 */     if (action == 1) {
/*     */       try {
/*  67 */         CopyDefinition diff = (CopyDefinition)super.getActivePanel().getValues();
/*     */         
/*  69 */         if (!"".equals(diff.saveFile)) {
/*  70 */           if (this.jibx == null) {
/*  71 */             this.jibx = new JibxCall(CopyDefinition.class);
/*     */           }
/*     */           
/*  74 */           this.jibx.unmarshal(diff.saveFile, diff);
/*  75 */           diff.fileSaved = true;
/*     */         }
/*     */       } catch (Exception e) {
/*  78 */         e.printStackTrace();
/*  79 */         Common.logMsgRaw(FILE_SAVE_FAILED, e);
/*     */       }
/*     */     } else {
/*  82 */       super.executeAction(action);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isActionAvailable(int action)
/*     */   {
/*  91 */     if (action == 1) {
/*  92 */       return true;
/*     */     }
/*  94 */     return super.isActionAvailable(action);
/*     */   }
/*     */   
/*     */ 
/*     */   private static class CreateTree
/*     */     implements AbstractWizardPanel<CopyDefinition>
/*     */   {
/*     */     private CreateRecordTreePnl recordTree;
/*     */     
/*     */     private CopyDefinition copydef;
/*     */     private AbstractLayoutSelection recordSelection;
/*     */     
/*     */     public CreateTree(AbstractLayoutSelection recordSelection1)
/*     */     {
/* 108 */       this.recordSelection = recordSelection1;
/* 109 */       this.recordTree = new CreateRecordTreePnl();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public javax.swing.JComponent getComponent()
/*     */     {
/* 117 */       return this.recordTree.getPanel();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public CopyDefinition getValues()
/*     */       throws Exception
/*     */     {
/* 125 */       this.copydef.treeDefinition = this.recordTree.getSaveDetails().recordTree;
/* 126 */       return this.copydef;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void setValues(CopyDefinition detail)
/*     */       throws Exception
/*     */     {
/* 134 */       this.copydef = detail;
/* 135 */       this.recordTree.setLayout(this.recordSelection.getRecordLayout(detail.oldFile.name));
/*     */       
/*     */ 
/* 138 */       this.recordTree.setFromSavedDetails(this.copydef.treeDefinition);
/* 139 */       this.recordTree.getPanel().doLayout();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void showHelpRE()
/*     */     {
/* 147 */       this.recordTree.getPanel().showHelpRE();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean skip()
/*     */     {
/* 155 */       return this.recordTree.getLayout().getRecordCount() == 1;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class GetFiles
/*     */     extends AbstractFilePnl<CopyDefinition>
/*     */   {
/* 162 */     private CopyDefinition values = new CopyDefinition();
/*     */     
/*     */     private TreeComboFileSelect xmlFileName;
/*     */     
/*     */     private AbstractLayoutSelection layoutSelection;
/*     */     
/*     */     public GetFiles(AbstractLayoutSelection selection, String recentFiles)
/*     */     {
/* 170 */       super(recentFiles);
/*     */       
/* 172 */       this.xmlFileName = new TreeComboFileSelect(true, false, true, getRecentList(), getRecentDirectoryList());
/* 173 */       this.xmlFileName.setText(Common.OPTIONS.DEFAULT_FILE_DIRECTORY.getWithStar());
/* 174 */       this.layoutSelection = selection;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public CopyDefinition getValues()
/*     */       throws Exception
/*     */     {
/* 186 */       this.values.oldFile.name = getCurrentFileName();
/* 187 */       this.values.oldFile.getLayoutDetails().name = this.layoutSelection.getLayoutName();
/*     */       
/* 189 */       this.values.newFile.name = this.xmlFileName.getText();
/*     */       
/* 191 */       if (this.layoutSelection.getRecordLayout(getCurrentFileName()) == null) {
/* 192 */         throw new RecordRunTimeException("Layout Does not exist");
/*     */       }
/*     */       
/* 195 */       return this.values;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void setValues(CopyDefinition detail)
/*     */       throws Exception
/*     */     {
/* 203 */       System.out.println("Setting Values ... ");
/* 204 */       this.values = detail;
/*     */       
/* 206 */       if (!"".equals(this.values.oldFile.name)) {
/* 207 */         this.fileName.setText(this.values.oldFile.name);
/*     */       }
/*     */       
/* 210 */       if (!"".equals(this.values.newFile.name)) {
/* 211 */         this.xmlFileName.setText(this.values.newFile.name);
/*     */       }
/*     */       
/* 214 */       if (!"".equals(this.values.oldFile.getLayoutDetails().name)) {
/* 215 */         this.layoutSelection.setLayoutName(this.values.oldFile.getLayoutDetails().name);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     protected void addFileName(BaseHelpPanel pnl)
/*     */     {
/* 222 */       pnl.addLineRE("Input File", this.fileName);
/* 223 */       pnl.addLineRE("Xml output File", this.xmlFileName);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/copy/Copy2Xml.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */