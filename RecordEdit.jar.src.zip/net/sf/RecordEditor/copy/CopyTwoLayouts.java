/*    */ package net.sf.RecordEditor.copy;
/*    */ 
/*    */ import net.sf.RecordEditor.jibx.compare.CopyDefinition;
/*    */ import net.sf.RecordEditor.re.openFile.AbstractLayoutSelection;
/*    */ import net.sf.RecordEditor.re.util.wizard.TwoLayoutsWizard;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CopyTwoLayouts
/*    */   extends TwoLayoutsWizard<CopyDefinition>
/*    */ {
/*    */   private CopyWizardFinalPnl finalScreen;
/*    */   
/*    */   public CopyTwoLayouts(AbstractLayoutSelection selection1, AbstractLayoutSelection selection2, String recentFiles)
/*    */   {
/* 26 */     this(selection1, selection2, new CopyDefinition(), recentFiles);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public CopyTwoLayouts(AbstractLayoutSelection selection1, AbstractLayoutSelection selection2, CopyDefinition definition, String recentFiles)
/*    */   {
/* 40 */     super("Standard Copy", definition);
/*    */     
/* 42 */     this.finalScreen = new CopyWizardFinalPnl(selection1, selection2);
/*    */     
/* 44 */     definition.type = "StandardCopy";
/*    */     
/* 46 */     super.setUpPanels(selection1, selection2, recentFiles, this.finalScreen, "", false, true);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void finished(CopyDefinition details)
/*    */   {
/* 57 */     if (this.finalScreen.isToRun()) {
/* 58 */       this.finalScreen.run();
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/copy/CopyTwoLayouts.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */