/*    */ package net.sf.RecordEditor.copy;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import net.sf.RecordEditor.re.openFile.LayoutSelectionFile;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BatchCopyFileLayout
/*    */ {
/*    */   public static void main(String[] args)
/*    */   {
/* 21 */     if ((args == null) || (args.length == 0)) {
/* 22 */       System.out.println("You must supply a Copy definition !!! ");
/*    */     } else {
/* 24 */       new BatchCopy(new LayoutSelectionFile(), new LayoutSelectionFile(), args);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/copy/BatchCopyFileLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */