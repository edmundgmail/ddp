/*     */ package net.sf.RecordEditor.copy;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import javax.swing.JPanel;
/*     */ import net.sf.JRecord.Common.RecordRunTimeException;
/*     */ import net.sf.RecordEditor.jibx.JibxCall;
/*     */ import net.sf.RecordEditor.jibx.compare.CopyDefinition;
/*     */ import net.sf.RecordEditor.jibx.compare.File;
/*     */ import net.sf.RecordEditor.jibx.compare.Layout;
/*     */ import net.sf.RecordEditor.re.openFile.AbstractLayoutSelection;
/*     */ import net.sf.RecordEditor.re.util.wizard.AbstractFilePnl;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions.FileNameOpt;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions.FileNameOptWithDefault;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.FileSelectCombo;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.TreeComboFileSelect;
/*     */ import net.sf.RecordEditor.utils.wizards.AbstractWizard;
/*     */ import net.sf.RecordEditor.utils.wizards.AbstractWizardPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Copy2Velocity
/*     */   extends AbstractWizard<CopyDefinition>
/*     */ {
/*     */   private CopyWizardFinalPnl finalScreen;
/*  30 */   private JibxCall<CopyDefinition> jibx = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Copy2Velocity(AbstractLayoutSelection recordSelection1)
/*     */   {
/*  39 */     this(new CopyDefinition(), recordSelection1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Copy2Velocity(CopyDefinition definition, AbstractLayoutSelection recordSelection1)
/*     */   {
/*  50 */     super("Reformat via Velocity Template", definition);
/*     */     
/*  52 */     AbstractWizardPanel<CopyDefinition>[] pnls = new AbstractWizardPanel[2];
/*     */     
/*  54 */     recordSelection1.setMessage(super.getMessage());
/*  55 */     recordSelection1.setMessage(super.getMessage());
/*     */     
/*  57 */     definition.type = "Velocity";
/*     */     
/*  59 */     this.finalScreen = new CopyWizardFinalPnl(recordSelection1, null);
/*  60 */     pnls[0] = new GetFiles(recordSelection1);
/*     */     
/*  62 */     pnls[1] = this.finalScreen;
/*     */     
/*  64 */     super.setPanels(pnls);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void finished(CopyDefinition details)
/*     */   {
/*  75 */     if (this.finalScreen.isToRun()) {
/*  76 */       this.finalScreen.run();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void executeAction(int action)
/*     */   {
/*  88 */     if (action == 1) {
/*     */       try {
/*  90 */         CopyDefinition diff = (CopyDefinition)super.getActivePanel().getValues();
/*     */         
/*  92 */         if (!"".equals(diff.saveFile)) {
/*  93 */           if (this.jibx == null) {
/*  94 */             this.jibx = new JibxCall(CopyDefinition.class);
/*     */           }
/*     */           
/*  97 */           this.jibx.unmarshal(diff.saveFile, diff);
/*  98 */           diff.fileSaved = true;
/*     */         }
/*     */       } catch (Exception e) {
/* 101 */         e.printStackTrace();
/* 102 */         Common.logMsgRaw(FILE_SAVE_FAILED, e);
/*     */       }
/*     */     } else {
/* 105 */       super.executeAction(action);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isActionAvailable(int action)
/*     */   {
/* 114 */     if (action == 1) {
/* 115 */       return true;
/*     */     }
/* 117 */     return super.isActionAvailable(action);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class GetFiles
/*     */     extends AbstractFilePnl<CopyDefinition>
/*     */   {
/* 129 */     private CopyDefinition values = new CopyDefinition();
/*     */     
/*     */ 
/* 132 */     private TreeComboFileSelect newFileName = new TreeComboFileSelect(true, false, true, getRecentList(), getRecentDirectoryList());
/* 133 */     private FileSelectCombo velocityTemplateFile = new FileSelectCombo("VelocitySkels.", 25, true, false);
/*     */     
/*     */ 
/*     */     private AbstractLayoutSelection layoutSelection1;
/*     */     
/*     */ 
/*     */     public GetFiles(AbstractLayoutSelection selection1)
/*     */     {
/* 141 */       super("CobolFiles.txt");
/*     */       
/* 143 */       this.layoutSelection1 = selection1;
/* 144 */       this.newFileName.setText(Common.OPTIONS.DEFAULT_FILE_DIRECTORY.getWithStar());
/*     */       
/* 146 */       this.velocityTemplateFile.setText(Common.OPTIONS.DEFAULT_VELOCITY_DIRECTORY.get());
/*     */       
/*     */ 
/* 149 */       setHelpURLre(Common.formatHelpURL("diff2.html"));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public CopyDefinition getValues()
/*     */       throws Exception
/*     */     {
/* 159 */       this.values.oldFile.name = getCurrentFileName();
/* 160 */       this.values.newFile.name = this.newFileName.getText();
/*     */       
/* 162 */       this.values.oldFile.getLayoutDetails().name = this.layoutSelection1.getLayoutName();
/* 163 */       this.values.velocityTemplate = this.velocityTemplateFile.getText();
/* 164 */       if (this.layoutSelection1.getRecordLayout(getCurrentFileName()) == null) {
/* 165 */         throw new RecordRunTimeException("Layout Does not exist");
/*     */       }
/*     */       
/* 168 */       return this.values;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void setValues(CopyDefinition detail)
/*     */       throws Exception
/*     */     {
/* 176 */       System.out.println("Setting Values ... ");
/* 177 */       this.values = detail;
/*     */       
/* 179 */       if (!"".equals(this.values.oldFile.name)) {
/* 180 */         this.fileName.setText(this.values.oldFile.name);
/*     */       }
/*     */       
/* 183 */       if (!"".equals(this.values.newFile.name)) {
/* 184 */         this.newFileName.setText(this.values.newFile.name);
/*     */       }
/*     */       
/* 187 */       if (!"".equals(this.values.oldFile.getLayoutDetails().name)) {
/* 188 */         this.layoutSelection1.setLayoutName(this.values.oldFile.getLayoutDetails().name);
/*     */       }
/*     */       
/* 191 */       if (!"".equals(this.values.velocityTemplate)) {
/* 192 */         this.velocityTemplateFile.setText(this.values.velocityTemplate);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */     protected void addFileName(BaseHelpPanel pnl)
/*     */     {
/* 199 */       pnl.addLineRE("Old File", this.fileName);
/*     */       
/* 201 */       pnl.addLineRE("New File", this.newFileName);
/*     */     }
/*     */     
/*     */ 
/*     */     protected void addLayoutSelection()
/*     */     {
/* 207 */       this.layoutSelection1.addLayoutSelection(this, this.fileName, new JPanel(), null, null);
/* 208 */       setGapRE(GAP3);
/* 209 */       addLineRE("Velocity Template", this.velocityTemplateFile);
/* 210 */       setGapRE(GAP3);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/copy/Copy2Velocity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */