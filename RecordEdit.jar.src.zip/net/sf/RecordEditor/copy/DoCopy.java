/*     */ package net.sf.RecordEditor.copy;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import net.sf.JRecord.Common.RecordException;
/*     */ import net.sf.JRecord.Common.RecordRunTimeException;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail.FieldDetails;
/*     */ import net.sf.JRecord.Details.LayoutDetail;
/*     */ import net.sf.JRecord.Details.Line;
/*     */ import net.sf.JRecord.Details.LineProvider;
/*     */ import net.sf.JRecord.Details.RecordDetail;
/*     */ import net.sf.JRecord.Details.RecordDetail.FieldDetails;
/*     */ import net.sf.JRecord.Details.RecordSelection;
/*     */ import net.sf.JRecord.Details.XmlLine;
/*     */ import net.sf.JRecord.ExternalRecordSelection.ExternalFieldSelection;
/*     */ import net.sf.JRecord.IO.AbstractLineIOProvider;
/*     */ import net.sf.JRecord.IO.AbstractLineReader;
/*     */ import net.sf.JRecord.IO.AbstractLineWriter;
/*     */ import net.sf.JRecord.IO.LineIOProvider;
/*     */ import net.sf.RecordEditor.jibx.compare.CopyDefinition;
/*     */ import net.sf.RecordEditor.jibx.compare.Layout;
/*     */ import net.sf.RecordEditor.jibx.compare.Record;
/*     */ import net.sf.RecordEditor.re.fileWriter.FieldWriter;
/*     */ import net.sf.RecordEditor.re.fileWriter.WriterBuilder;
/*     */ import net.sf.RecordEditor.re.openFile.AbstractLayoutSelection;
/*     */ import net.sf.RecordEditor.re.openFile.LayoutSelectionFile;
/*     */ import net.sf.RecordEditor.re.script.RunVelocity;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DoCopy
/*     */ {
/*     */   private static final String CAN_NOT_LOCATE_RECORD = "Can not locate record: > {0}< in input layout";
/*     */   private LayoutDetail dtl1;
/*     */   private LayoutDetail dtl2;
/*     */   private CopyDefinition cpy;
/*     */   private int[][] fromTbl;
/*     */   private int[][] toTbl;
/*     */   private String[][] defaultValues;
/*     */   private int[] toIdx;
/*     */   private int[] fromIdx;
/*     */   private AbstractLineWriter writer;
/*     */   private boolean ok;
/*     */   private boolean first;
/*  57 */   private PrintStream fieldErrorStream = null;
/*     */   
/*  59 */   private int errorCount = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final boolean copy(AbstractLayoutSelection layoutReader1, AbstractLayoutSelection layoutReader2, CopyDefinition copy)
/*     */     throws Exception
/*     */   {
/*  73 */     boolean ret = true;
/*     */     
/*  75 */     if ("StandardCopy".equals(copy.type)) {
/*  76 */       ret = new DoCopy(copy, getLayout(layoutReader1, copy.oldFile.layoutDetails.name, copy.oldFile.name, true), getLayout(layoutReader2, copy.newFile.layoutDetails.name, copy.newFile.name, false)).copy2Layouts();
/*     */ 
/*     */ 
/*     */     }
/*  80 */     else if ("CobolCopy".equals(copy.type)) {
/*  81 */       ret = new DoCopy(copy, getLayout(new LayoutSelectionFile(true), copy.oldFile.layoutDetails.name, copy.oldFile.name, true), getLayout(new LayoutSelectionFile(true), copy.newFile.layoutDetails.name, copy.newFile.name, false)).cobolCopy();
/*     */ 
/*     */ 
/*     */     }
/*  85 */     else if ("DelimCopy".equals(copy.type)) {
/*  86 */       new DoCopy(copy, getLayout(layoutReader1, copy.oldFile.layoutDetails.name, copy.oldFile.name, true), null).copy2BinDelim();
/*     */ 
/*     */ 
/*     */     }
/*  90 */     else if ("Velocity".equals(copy.type)) {
/*  91 */       RunVelocity.getInstance().processFile(layoutReader1.getRecordLayout(""), copy.oldFile.name, copy.velocityTemplate, copy.newFile.name);
/*     */ 
/*     */     }
/*  94 */     else if ("Xml".equals(copy.type)) {
/*  95 */       DoCopy2Xml.newCopy().copyFile(layoutReader1, copy);
/*     */     } else {
/*  97 */       new RecordRunTimeException("Invalid type of Copy --> {0}", copy.type);
/*     */     }
/*     */     
/* 100 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static AbstractLayoutDetails getLayout(AbstractLayoutSelection layoutReader, String name, String fileName, boolean input)
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 120 */       AbstractLayoutDetails ret = layoutReader.getRecordLayout(name, fileName);
/* 121 */       AbstractLineReader reader; if (ret == null) {
/* 122 */         System.err.println("Retrieve of layout: " + name + " failed");
/* 123 */       } else if (((input) && (ret.isBuildLayout())) || (ret.getFileStructure() == 51)) {
/* 124 */         AbstractLineIOProvider ioProvider = LineIOProvider.getInstance();
/*     */         
/*     */ 
/* 127 */         reader = ioProvider.getLineReader(ret);
/* 128 */         reader.open(fileName, ret);
/* 129 */         reader.read();
/* 130 */         if (ret.getFileStructure() == 62) {
/* 131 */           for (int i = 0; (i < 1000) && (reader.read() != null); i++) {}
/*     */         }
/*     */       }
/* 134 */       return reader.getLayout();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 138 */       e.printStackTrace();
/* 139 */       Common.logMsg(30, "Error Loading Layout:", name, e);
/* 140 */       throw e;
/*     */     }
/*     */   }
/*     */   
/*     */   public DoCopy(CopyDefinition copy, AbstractLayoutDetails detail1, AbstractLayoutDetails detail2)
/*     */   {
/* 146 */     java.io.File file = null;
/* 147 */     this.cpy = copy;
/* 148 */     this.dtl1 = ((LayoutDetail)detail1);
/* 149 */     this.dtl2 = ((LayoutDetail)detail2);
/*     */     
/* 151 */     if (copy.fieldErrorFile != null) {
/*     */       try {
/* 153 */         this.fieldErrorStream = new PrintStream(copy.fieldErrorFile);
/*     */       } catch (Exception e) {
/* 155 */         System.out.println();
/* 156 */         System.out.println("Error Allocating Field Error File: " + e.getMessage());
/* 157 */         System.out.println();
/* 158 */         this.fieldErrorStream = null;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final boolean copy2Layouts()
/*     */     throws IOException, RecordException
/*     */   {
/* 173 */     AbstractLineIOProvider ioProvider = LineIOProvider.getInstance();
/*     */     
/*     */ 
/*     */ 
/* 177 */     this.ok = true;
/*     */     
/* 179 */     buildTranslations();
/*     */     
/* 181 */     AbstractLineReader reader = ioProvider.getLineReader(this.dtl1);
/* 182 */     this.writer = ioProvider.getLineWriter(this.dtl2.getFileStructure(), this.dtl2.getFontName());
/*     */     
/* 184 */     reader.open(this.cpy.oldFile.name, this.dtl1);
/* 185 */     this.writer.open(this.cpy.newFile.name);
/*     */     
/*     */ 
/*     */ 
/* 189 */     this.first = true;
/* 190 */     AbstractLine in = reader.read();
/* 191 */     int lineNo = 0;
/* 192 */     if (this.dtl1.getRecordCount() < 2) {
/* 193 */       while (in != null) { AbstractLine next;
/* 194 */         writeRecord(in, next = reader.read(), 0, lineNo++);
/* 195 */         in = next;
/*     */       }
/*     */     }
/* 198 */     while (in != null) {
/* 199 */       int idx = in.getPreferredLayoutIdx();
/* 200 */       if (idx >= 0) { AbstractLine next;
/* 201 */         while (((next = reader.read()) != null) && (next.getPreferredLayoutIdx() < 0)) {}
/*     */         
/*     */ 
/* 204 */         writeRecord(in, next, idx, lineNo++);
/* 205 */         in = next;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 210 */     reader.close();
/* 211 */     this.writer.close();
/* 212 */     closeFieldError();
/* 213 */     return this.ok;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeRecord(AbstractLine in, AbstractLine next, int idx, int lineNo)
/*     */     throws IOException
/*     */   {
/* 225 */     if ((idx < this.fromIdx.length) && (idx < this.toIdx.length)) {
/* 226 */       int i1 = this.fromIdx[idx];
/* 227 */       int i2 = this.toIdx[idx];
/*     */       
/* 229 */       if ((i1 >= 0) && (i2 >= 0))
/*     */       {
/*     */ 
/* 232 */         Object o = null;
/*     */         
/* 234 */         int[] fromFields = this.fromTbl[i1];
/* 235 */         int[] toFields = this.toTbl[i1];
/*     */         AbstractLine out;
/* 237 */         if (this.dtl2.isXml()) {
/* 238 */           XmlLine o1 = new XmlLine(this.dtl2, i2);
/* 239 */           AbstractLine out = o1;
/*     */           
/* 241 */           setDefaultValues(i1, i2, out);
/* 242 */           if ((this.fromTbl.length == 1) || (next == null) || (idx == next.getPreferredLayoutIdx())) {
/*     */             try {
/* 244 */               o1.setRawField(i2, 1, Boolean.valueOf(true));
/*     */             }
/*     */             catch (Exception e) {}
/*     */           }
/*     */           
/*     */           int parentIdx;
/* 250 */           if ((this.first) && ((parentIdx = ((RecordDetail)this.dtl2.getRecord(i2)).getParentRecordIndex()) >= 0))
/*     */           {
/* 252 */             printParent(parentIdx);
/* 253 */             this.first = false;
/*     */           }
/*     */         } else {
/* 256 */           out = LineIOProvider.getInstance().getLineProvider(this.dtl2).getLine(this.dtl2);
/*     */           try
/*     */           {
/* 259 */             RecordSelection sel = ((RecordDetail)this.dtl2.getRecord(i2)).getRecordSelection();
/* 260 */             for (ExternalFieldSelection fs : sel.getAllFields()) {
/* 261 */               if (fs != null) {
/* 262 */                 out.setField(fs.getFieldName(), fs.getFieldValue());
/*     */               }
/*     */             }
/*     */           }
/*     */           catch (Exception e) {}
/*     */           
/* 268 */           setDefaultValues(i1, i2, out);
/*     */         }
/*     */         
/*     */ 
/* 272 */         for (int i = 0; i < fromFields.length; i++) {
/* 273 */           if ((fromFields[i] >= 0) && (toFields[i] >= 0)) {
/*     */             try {
/* 275 */               o = in.getField(idx, fromFields[i]);
/* 276 */               if (o == null) {
/* 277 */                 o = "";
/* 278 */                 if (((RecordDetail)this.dtl2.getRecord(i2)).getFieldsNumericType(toFields[i]) == 21) {
/* 279 */                   o = "0";
/*     */                 }
/*     */               }
/*     */               
/* 283 */               out.setField(i2, toFields[i], o);
/*     */             } catch (Exception e) {
/* 285 */               String em = LangConversion.convert("Error Line {0} Field Number {1} - {2} : {3}", new Object[] { Integer.valueOf(lineNo), Integer.valueOf(i), e.getMessage(), o });
/*     */               
/*     */ 
/* 288 */               if (this.fieldErrorStream == null) {
/* 289 */                 Common.logMsgRaw(em, null);
/*     */               } else {
/* 291 */                 this.fieldErrorStream.println(em);
/*     */               }
/*     */               
/* 294 */               this.errorCount += 1;
/* 295 */               if ((this.cpy.maxErrors >= 0) && (this.errorCount > this.cpy.maxErrors)) {
/* 296 */                 this.writer.write(out);
/* 297 */                 this.writer.close();
/* 298 */                 throw new IOException("Max Conversion Errors Reached: " + this.cpy.maxErrors, e);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 305 */         this.writer.write(out);
/* 306 */         this.first = false;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void setDefaultValues(int i1, int i2, AbstractLine out)
/*     */   {
/* 313 */     if (this.defaultValues[i1] != null) {
/* 314 */       for (int i = 0; i < this.defaultValues[i1].length; i++) {
/* 315 */         if (this.defaultValues[i1][i] != null) {
/*     */           try {
/* 317 */             out.setField(i2, i, this.defaultValues[i1][i]);
/*     */           } catch (Exception e) {
/* 319 */             System.out.println("Error > " + i2 + " " + i + " " + ((RecordDetail.FieldDetails)((RecordDetail)this.dtl2.getRecord(i2)).getField(i)).getName() + " " + this.defaultValues[i2][i] + "<");
/*     */             
/* 321 */             e.printStackTrace();
/* 322 */             this.ok = false;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void printParent(int idx)
/*     */     throws IOException
/*     */   {
/*     */     int parentIdx;
/* 333 */     if ((parentIdx = ((RecordDetail)this.dtl2.getRecord(idx)).getParentRecordIndex()) >= 0) {
/* 334 */       printParent(parentIdx);
/*     */     }
/* 336 */     this.writer.write(new XmlLine(this.dtl2, idx));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void buildTranslations()
/*     */   {
/* 349 */     this.toIdx = new int[this.dtl1.getRecordCount()];
/* 350 */     this.fromIdx = new int[this.dtl1.getRecordCount()];
/*     */     
/* 352 */     this.defaultValues = new String[this.dtl2.getRecordCount()][];
/*     */     
/* 354 */     this.fromTbl = new int[this.cpy.oldFile.layoutDetails.records.size()][];
/* 355 */     this.toTbl = new int[this.fromTbl.length][];
/*     */     
/* 357 */     for (int i = 0; i < this.toIdx.length; i++) {
/* 358 */       this.toIdx[i] = -1;
/*     */     }
/*     */     
/* 361 */     for (i = 0; i < this.fromTbl.length; i++) {
/* 362 */       Record recList1 = (Record)this.cpy.oldFile.layoutDetails.records.get(i);
/* 363 */       Record recList2 = (Record)this.cpy.newFile.layoutDetails.records.get(i);
/* 364 */       int idx1 = this.dtl1.getRecordIndex(recList1.name);
/* 365 */       int idx2 = this.dtl2.getRecordIndex(recList2.name);
/*     */       
/* 367 */       if (idx1 < 0) {
/* 368 */         if (this.dtl1.getRecordCount() > 0) {
/* 369 */           System.out.println("Record 0: >" + ((RecordDetail)this.dtl1.getRecord(0)).getRecordName() + "<");
/*     */         }
/* 371 */         throw new RecordRunTimeException("Can not locate record: > {0}< in input layout", recList1.name);
/*     */       }
/* 373 */       if (idx2 < 0) {
/* 374 */         throw new RecordRunTimeException("Can not locate record: {0} in output layout", recList2.name);
/*     */       }
/*     */       
/* 377 */       this.fromIdx[idx1] = i;
/* 378 */       this.toIdx[idx1] = idx2;
/* 379 */       AbstractRecordDetail rec1 = this.dtl1.getRecord(idx1);
/* 380 */       AbstractRecordDetail rec2 = this.dtl2.getRecord(idx2);
/*     */       
/* 382 */       int size = recList1.fields.length;
/* 383 */       this.fromTbl[i] = new int[size];
/* 384 */       this.toTbl[i] = new int[size];
/*     */       
/*     */ 
/* 387 */       this.defaultValues[i] = new String[rec2.getFieldCount()];
/* 388 */       for (int j = 0; j < this.defaultValues[i].length; j++) {
/* 389 */         if (rec2.getFieldsNumericType(j) == 21) {
/* 390 */           this.defaultValues[i][j] = "0";
/*     */         } else {
/* 392 */           this.defaultValues[i][j] = "";
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 397 */       for (j = 0; j < size; j++) {
/* 398 */         this.fromTbl[i][j] = rec1.getFieldIndex(recList1.fields[j]);
/*     */         
/*     */ 
/* 401 */         int ix = rec2.getFieldIndex(recList2.fields[j]);
/* 402 */         this.toTbl[i][j] = ix;
/* 403 */         this.defaultValues[i][ix] = null;
/*     */         
/* 405 */         if ((this.fromTbl[i][j] < 0) && (this.toTbl[i][j] < 0)) {
/* 406 */           System.out.println("Can not find input & output fields: " + j + " " + recList1.fields[j] + ", " + recList2.fields[j]);
/*     */         }
/* 408 */         else if (this.fromTbl[i][j] < 0) {
/* 409 */           StringBuilder bb = new StringBuilder();
/* 410 */           for (int k = 0; k < rec1.getFieldCount(); k++) {
/* 411 */             bb.append("<\t>").append(rec1.getField(k).getName());
/*     */           }
/* 413 */           System.out.println("Can not find input field: " + j + " >" + recList1.fields[j] + "< } " + bb.toString() + " -- " + this.fromTbl[i][j]);
/*     */         }
/* 415 */         else if (this.toTbl[i][j] < 0) {
/* 416 */           System.out.println("Can not find output field: " + j + " " + recList2.fields[j]);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 425 */       boolean noDefault = true;
/* 426 */       for (j = 0; j < this.defaultValues[i].length; j++) {
/* 427 */         if (this.defaultValues[i][j] != null) {
/* 428 */           noDefault = false;
/* 429 */           break;
/*     */         }
/*     */       }
/*     */       
/* 433 */       if (noDefault) {
/* 434 */         this.defaultValues[i] = null;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void buildTranslations1layout()
/*     */   {
/* 448 */     this.toIdx = new int[this.dtl1.getRecordCount()];
/* 449 */     this.fromIdx = new int[this.dtl1.getRecordCount()];
/*     */     
/* 451 */     int size = this.dtl1.getRecordCount();
/* 452 */     if (this.cpy.oldFile.layoutDetails.records == null) {
/* 453 */       this.fromTbl = new int[this.dtl1.getRecordCount()][];
/*     */       
/* 455 */       for (int i = 0; i < this.fromTbl.length; i++) {
/* 456 */         this.fromIdx[i] = i;
/* 457 */         size = ((RecordDetail)this.dtl1.getRecord(i)).getFieldCount();
/* 458 */         this.fromTbl[i] = new int[size];
/*     */         
/* 460 */         for (int j = 0; j < size; j++) {
/* 461 */           this.fromTbl[i][j] = j;
/*     */         }
/*     */       }
/*     */     }
/* 465 */     this.fromTbl = new int[this.cpy.oldFile.layoutDetails.records.size()][];
/*     */     
/* 467 */     for (int i = 0; i < this.fromTbl.length; i++) {
/* 468 */       Record recList1 = (Record)this.cpy.oldFile.layoutDetails.records.get(i);
/*     */       
/* 470 */       int idx1 = this.dtl1.getRecordIndex(recList1.name);
/*     */       
/*     */ 
/* 473 */       this.fromIdx[idx1] = i;
/* 474 */       AbstractRecordDetail rec1 = this.dtl1.getRecord(idx1);
/*     */       
/* 476 */       size = recList1.fields.length;
/* 477 */       this.fromTbl[i] = new int[size];
/*     */       
/* 479 */       for (int j = 0; j < size; j++) {
/* 480 */         this.fromTbl[i][j] = rec1.getFieldIndex(recList1.fields[j]);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private final boolean cobolCopy()
/*     */     throws IOException, RecordException
/*     */   {
/* 490 */     AbstractLineIOProvider ioProvider = LineIOProvider.getInstance();
/*     */     
/*     */ 
/* 493 */     this.ok = true;
/*     */     
/* 495 */     AbstractLineReader reader = ioProvider.getLineReader(this.dtl1);
/* 496 */     this.writer = ioProvider.getLineWriter(this.dtl2.getFileStructure(), this.dtl2.getFontName());
/*     */     
/* 498 */     reader.open(this.cpy.oldFile.name, this.dtl1);
/* 499 */     this.writer.open(this.cpy.newFile.name);
/*     */     
/* 501 */     if (this.dtl1.getRecordCount() < 2) { AbstractLine in;
/* 502 */       while ((in = reader.read()) != null)
/* 503 */         writeCobRecord(in, 0);
/*     */     }
/*     */     AbstractLine in;
/* 506 */     while ((in = reader.read()) != null) {
/* 507 */       int idx = in.getPreferredLayoutIdx();
/* 508 */       if (idx >= 0) {
/* 509 */         writeCobRecord(in, idx);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 514 */     reader.close();
/* 515 */     this.writer.close();
/* 516 */     closeFieldError();
/* 517 */     return this.ok;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void writeCobRecord(AbstractLine in, int idx)
/*     */     throws IOException
/*     */   {
/* 528 */     AbstractLine out = new Line(this.dtl2);
/*     */     
/* 530 */     if (idx >= 0) {
/* 531 */       Object o = null;
/* 532 */       int len = in.getLayout().getRecord(idx).getFieldCount();
/*     */       
/* 534 */       for (int i = 0; i < len; i++) {
/*     */         try {
/* 536 */           o = in.getField(idx, i);
/* 537 */           out.setField(idx, i, o);
/*     */         }
/*     */         catch (Exception e) {
/* 540 */           Common.logMsgRaw(LangConversion.convert("Error in Field {0} {1} : {2}", new Object[] { in.getLayout().getRecord(idx).getField(i).getName(), e.getMessage(), o }), null);
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 549 */           this.ok = false;
/*     */         }
/*     */       }
/* 552 */       this.writer.write(out);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void copy2BinDelim()
/*     */     throws IOException, RecordException
/*     */   {
/* 567 */     AbstractLineIOProvider ioProvider = LineIOProvider.getInstance();
/*     */     
/*     */ 
/*     */ 
/* 571 */     FieldWriter writer = WriterBuilder.newCsvWriter(this.cpy.newFile.name, this.cpy.delimiter, this.cpy.font, this.cpy.quote, false, null);
/* 572 */     AbstractLineReader reader = ioProvider.getLineReader(this.dtl1);
/*     */     
/* 574 */     reader.open(this.cpy.oldFile.name, this.dtl1);
/*     */     
/* 576 */     buildTranslations1layout();
/*     */     
/* 578 */     if (this.cpy.namesOnFirstLine)
/*     */     {
/*     */ 
/* 581 */       for (int i = 0; i < this.fromTbl[this.fromIdx[0]].length; i++) {
/* 582 */         writer.writeFieldHeading(((RecordDetail.FieldDetails)((RecordDetail)this.dtl1.getRecord(this.fromIdx[0])).getField(this.fromTbl[0][i])).getName());
/*     */       }
/* 584 */       writer.newLine();
/*     */     }
/* 586 */     int lineNo = 0;
/* 587 */     if (this.dtl1.getRecordCount() < 2) { AbstractLine in;
/* 588 */       while ((in = reader.read()) != null) {
/* 589 */         lineNo++;
/* 590 */         writeBinCsvLine(writer, in, lineNo, 0);
/*     */       } }
/*     */     AbstractLine in;
/* 593 */     while ((in = reader.read()) != null) {
/* 594 */       int idx = in.getPreferredLayoutIdx();
/* 595 */       if (idx >= 0) {
/* 596 */         lineNo++;
/* 597 */         writeBinCsvLine(writer, in, lineNo, idx);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 602 */     reader.close();
/* 603 */     writer.close();
/* 604 */     closeFieldError();
/*     */   }
/*     */   
/*     */   private void writeBinCsvLine(FieldWriter writer, AbstractLine in, int lineNo, int idx) throws IOException
/*     */   {
/* 609 */     int i1 = this.fromIdx[idx];
/*     */     
/* 611 */     if (i1 >= 0) {
/* 612 */       Object o = null;
/* 613 */       int[] fromFields = this.fromTbl[i1];
/*     */       
/* 615 */       for (int i = 0; i < this.fromTbl[i1].length; i++) {
/*     */         try {
/* 617 */           o = in.getField(i1, fromFields[i]);
/*     */           
/* 619 */           if (o == null) {
/* 620 */             writer.writeField(null, true);
/*     */           } else {
/* 622 */             writer.writeField(o.toString(), ((RecordDetail)this.dtl1.getRecord(i1)).getFieldsNumericType(fromFields[i]) == 21);
/*     */           }
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 627 */           e.printStackTrace();
/* 628 */           System.out.println("Error " + e.getMessage() + " : " + o);
/*     */         }
/*     */       }
/* 631 */       writer.newLine();
/*     */     }
/*     */   }
/*     */   
/*     */   private void closeFieldError() {
/* 636 */     if (this.fieldErrorStream != null) {
/* 637 */       this.fieldErrorStream.close();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/copy/DoCopy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */