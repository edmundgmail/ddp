/*    */ package net.sf.RecordEditor.copy;
/*    */ 
/*    */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*    */ import net.sf.RecordEditor.jibx.compare.CopyDefinition;
/*    */ import net.sf.RecordEditor.jibx.compare.File;
/*    */ import net.sf.RecordEditor.jibx.compare.RecordParent;
/*    */ import net.sf.RecordEditor.re.file.FileView;
/*    */ import net.sf.RecordEditor.re.openFile.AbstractLayoutSelection;
/*    */ import net.sf.RecordEditor.re.tree.TreeParserRecord;
/*    */ 
/*    */ public class DoCopy2Xml
/*    */ {
/*    */   public void copyFile(AbstractLayoutSelection layoutReader1, CopyDefinition copy) throws Exception
/*    */   {
/* 15 */     AbstractLayoutDetails layout = layoutReader1.getRecordLayout(copy.oldFile.layoutDetails.name, copy.oldFile.name);
/*    */     
/*    */ 
/* 18 */     System.out.println(" Copy Xml:  " + layout.getRecordCount());
/* 19 */     if ((layout.getRecordCount() > 1) && (copy.oldFile.getLayoutDetails() != null)) {
/* 20 */       layout = layout.getFilteredLayout(copy.oldFile.getLayoutDetails().getFilteredRecords());
/*    */     }
/*    */     
/* 23 */     FileView view = new FileView(copy.oldFile.name, layout, true);
/*    */     
/*    */ 
/* 26 */     if (layout.hasChildren()) {
/* 27 */       new net.sf.RecordEditor.re.tree.ChildTreeToXml(copy.newFile.name, view.getLines());
/* 28 */     } else if (layout.getRecordCount() == 1) {
/* 29 */       new net.sf.RecordEditor.edit.util.WriteLinesAsXml(copy.newFile.name, view.getLines());
/*    */     }
/*    */     else {
/* 32 */       RecordParent[] parentRel = copy.treeDefinition.parentRelationship;
/* 33 */       int[] parentIdxs = new int[layout.getRecordCount()];
/*    */       
/* 35 */       for (int i = 0; i < parentIdxs.length; i++) {
/* 36 */         parentIdxs[i] = -121;
/*    */       }
/* 38 */       for (int i = 0; i < parentRel.length; i++) {
/* 39 */         int idx = layout.getRecordIndex(parentRel[i].recordName);
/* 40 */         if (idx >= 0) {
/* 41 */           parentIdxs[idx] = layout.getRecordIndex(parentRel[i].parentName);
/*    */         }
/*    */       }
/*    */       
/* 45 */       TreeParserRecord parser = new TreeParserRecord(parentIdxs);
/*    */       
/* 47 */       new net.sf.RecordEditor.re.tree.TreeToXml(copy.newFile.name, parser.parse(view));
/*    */     }
/*    */   }
/*    */   
/*    */   public static DoCopy2Xml newCopy() {
/* 52 */     return new DoCopy2Xml();
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/copy/DoCopy2Xml.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */