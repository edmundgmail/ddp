/*     */ package net.sf.RecordEditor.copy;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import net.sf.RecordEditor.jibx.compare.CopyDefinition;
/*     */ import net.sf.RecordEditor.jibx.compare.File;
/*     */ 
/*     */ public class BatchCopy
/*     */ {
/*   9 */   private static int isInput = 1;
/*  10 */   private static int isOutput = 2;
/*  11 */   private static int isInputLayout = 3;
/*  12 */   private static int isOutputLayout = 4;
/*  13 */   private static int isErrorFile = 5;
/*     */   
/*  15 */   private StringBuilder bld = new StringBuilder();
/*  16 */   private String sep = "";
/*     */   
/*     */   public BatchCopy(net.sf.RecordEditor.re.openFile.AbstractLayoutSelection reader1, net.sf.RecordEditor.re.openFile.AbstractLayoutSelection reader2, String[] args) {
/*  19 */     CopyDefinition def = null;
/*  20 */     net.sf.RecordEditor.jibx.JibxCall<CopyDefinition> jibx = new net.sf.RecordEditor.jibx.JibxCall(CopyDefinition.class);
/*     */     
/*  22 */     String outLayout = "";
/*     */     try
/*     */     {
/*  25 */       if (("-h".equalsIgnoreCase(args[0])) || ("-?".equalsIgnoreCase(args[0]))) {
/*  26 */         helpMsg();
/*  27 */         return;
/*     */       }
/*  29 */       def = (CopyDefinition)jibx.marshal(args[0]);
/*     */       
/*  31 */       int mode = 0;
/*     */       
/*  33 */       for (int i = 1; i < args.length; i++) {
/*  34 */         if ("-i".equalsIgnoreCase(args[i])) {
/*  35 */           assign(mode, def);
/*  36 */           mode = isInput;
/*  37 */         } else if ("-o".equalsIgnoreCase(args[i])) {
/*  38 */           assign(mode, def);
/*  39 */           mode = isOutput;
/*  40 */         } else if ("-il".equalsIgnoreCase(args[i])) {
/*  41 */           assign(mode, def);
/*  42 */           mode = isInputLayout;
/*  43 */         } else if ("-ol".equalsIgnoreCase(args[i])) {
/*  44 */           assign(mode, def);
/*  45 */           mode = isOutputLayout;
/*  46 */         } else if ("-ef".equalsIgnoreCase(args[i])) {
/*  47 */           assign(mode, def);
/*  48 */           mode = isErrorFile;
/*  49 */         } else if (("-h".equalsIgnoreCase(args[i])) || ("-?".equalsIgnoreCase(args[i]))) {
/*  50 */           helpMsg();
/*     */         } else {
/*  52 */           this.bld.append(this.sep).append(args[i]);
/*  53 */           this.sep = " ";
/*     */         }
/*     */       }
/*     */       
/*  57 */       assign(mode, def);
/*     */       
/*  59 */       System.out.println();
/*     */       try {
/*  61 */         if (def.newFile.layoutDetails != null) {
/*  62 */           outLayout = def.newFile.layoutDetails.name;
/*     */         }
/*  64 */         System.out.println("Copy Definition: " + args[0]);
/*  65 */         System.out.println("Copy From  File: " + def.oldFile.name + "\t\t Layout: " + def.oldFile.layoutDetails.name);
/*  66 */         System.out.println("Copy To    File: " + def.newFile.name + "\t\t Layout: " + outLayout);
/*     */       }
/*     */       catch (Exception e) {}
/*  69 */       System.out.println();
/*     */       
/*     */ 
/*  72 */       DoCopy.copy(reader1, reader2, def);
/*     */     } catch (Exception e) {
/*  74 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */   private void helpMsg()
/*     */   {
/*  80 */     System.out.println();
/*  81 */     System.out.println("Batch Copy, First parameter must be the copy-control-file after that:");
/*  82 */     System.out.println("    -i Input File                -il Input Layout");
/*  83 */     System.out.println("    -o Input File                -ol Input Layout");
/*  84 */     System.out.println("    -ef Field error file");
/*  85 */     System.out.println();
/*     */   }
/*     */   
/*     */   private void assign(int mode, CopyDefinition def) {
/*  89 */     String s = this.bld.toString();
/*     */     
/*     */ 
/*  92 */     if (mode == isInput) {
/*  93 */       def.oldFile.name = s;
/*  94 */     } else if (mode == isOutput) {
/*  95 */       def.newFile.name = s;
/*  96 */     } else if (mode == isInputLayout) {
/*  97 */       def.getLayoutDetails().name = s;
/*  98 */       def.oldFile.layoutDetails.name = s;
/*  99 */       def.getLayoutDetails().name = def.oldFile.layoutDetails.name;
/* 100 */     } else if (mode == isOutputLayout) {
/* 101 */       def.newFile.layoutDetails.name = s;
/* 102 */     } else if (mode == isErrorFile) {
/* 103 */       def.newFile.layoutDetails.name = s;
/*     */     }
/*     */     
/* 106 */     this.bld = new StringBuilder();
/* 107 */     this.sep = "";
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/copy/BatchCopy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */