/*     */ package net.sf.RecordEditor.copy;
/*     */ 
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JRadioButton;
/*     */ import javax.swing.JTextField;
/*     */ import net.sf.RecordEditor.jibx.JibxCall;
/*     */ import net.sf.RecordEditor.jibx.compare.CopyDefinition;
/*     */ import net.sf.RecordEditor.re.openFile.AbstractLayoutSelection;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.FileSelectCombo;
/*     */ import net.sf.RecordEditor.utils.wizards.AbstractWizardPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CopyWizardFinalPnl
/*     */   extends BaseHelpPanel
/*     */   implements AbstractWizardPanel<CopyDefinition>
/*     */ {
/*  37 */   private FileSelectCombo saveFileName = new FileSelectCombo("SavedCpy.", 25, true, false, true);
/*  38 */   private FileSelectCombo fieldErrorFile = new FileSelectCombo("ErrorFiles.", 8, false, false, true);
/*     */   
/*  40 */   private JTextField maxErrors = new JTextField();
/*     */   
/*     */   private AbstractLayoutSelection selection;
/*     */   
/*     */   private AbstractLayoutSelection selection2;
/*  45 */   private JButton saveBtn = SwingUtils.newButton("Save", Common.getRecordIcon(2));
/*  46 */   private JButton runBtn = SwingUtils.newButton("Copy");
/*     */   
/*     */ 
/*  49 */   private JRadioButton stripTrailingSpaces = new JRadioButton("Strip Trailing Spaces");
/*     */   
/*     */ 
/*     */ 
/*     */   private CopyDefinition copyDetail;
/*     */   
/*     */ 
/*  56 */   private JibxCall<CopyDefinition> jibx = null;
/*     */   
/*  58 */   private boolean toRun = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  63 */   private AbstractAction btnAction = new AbstractAction()
/*     */   {
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/*  67 */       if (e.getSource() == CopyWizardFinalPnl.this.runBtn) {
/*  68 */         CopyWizardFinalPnl.this.run();
/*     */       } else {
/*  70 */         CopyWizardFinalPnl.this.save();
/*     */       }
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public CopyWizardFinalPnl(AbstractLayoutSelection layoutSelection, AbstractLayoutSelection layoutSelection2)
/*     */   {
/*  84 */     JPanel pnl = new JPanel(new GridLayout(3, 2));
/*     */     
/*     */ 
/*     */ 
/*  88 */     this.selection = layoutSelection;
/*  89 */     this.selection2 = layoutSelection2;
/*     */     
/*  91 */     this.saveFileName.setText(Parameters.getFileName("CopySaveDirectory"));
/*  92 */     this.saveFileName.setDefaultDirectory(Parameters.getFileName("CopySaveDirectory"));
/*     */     
/*  94 */     this.saveBtn.addActionListener(this.btnAction);
/*  95 */     this.runBtn.addActionListener(this.btnAction);
/*     */     
/*  97 */     super.setHelpURLre(Common.formatHelpURL("diff2.html"));
/*     */     
/*  99 */     super.addLineRE("Save File", this.saveFileName);
/* 100 */     super.setGapRE(BasePanel.GAP1);
/* 101 */     super.addLineRE("Field Error File", this.fieldErrorFile);
/* 102 */     super.addLineRE("Max Error Limit", this.maxErrors);
/* 103 */     super.setGapRE(BasePanel.GAP1);
/* 104 */     super.addLineRE("", this.stripTrailingSpaces);
/* 105 */     super.addLineRE("", pnl);
/* 106 */     super.setHeightRE(BasePanel.GAP5);
/*     */     
/* 108 */     super.addLineRE("", null, this.saveBtn);
/* 109 */     super.setGapRE(BasePanel.GAP0);
/* 110 */     super.addLineRE("", null, this.runBtn);
/* 111 */     super.setGapRE(BasePanel.GAP2);
/* 112 */     super.addMessageRE();
/* 113 */     super.setHeightRE(BasePanel.HEIGHT_1P6);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final JComponent getComponent()
/*     */   {
/* 122 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final CopyDefinition getValues()
/*     */     throws Exception
/*     */   {
/* 131 */     if (!"".equals(this.saveFileName.getText())) {
/* 132 */       this.copyDetail.saveFile = this.saveFileName.getText();
/*     */     }
/*     */     
/* 135 */     this.copyDetail.fieldErrorFile = this.fieldErrorFile.getText();
/* 136 */     if ("".equals(this.copyDetail.fieldErrorFile.trim())) {
/* 137 */       this.copyDetail.fieldErrorFile = null;
/*     */     }
/*     */     
/* 140 */     if ("".equals(this.maxErrors.getText().trim())) {
/* 141 */       this.copyDetail.maxErrors = -1;
/*     */     } else {
/*     */       try {
/* 144 */         this.copyDetail.maxErrors = Integer.parseInt(this.maxErrors.getText());
/*     */       } catch (Exception e) {
/* 146 */         String em = LangConversion.convert("Invalid max errors value: ") + e.getMessage();
/*     */         
/* 148 */         super.setMessageRawTxtRE(em);
/* 149 */         this.copyDetail.maxErrors = -1;
/* 150 */         throw new RuntimeException(em, e);
/*     */       }
/*     */     }
/*     */     
/* 154 */     this.copyDetail.stripTrailingSpaces = this.stripTrailingSpaces.isSelected();
/*     */     
/*     */ 
/* 157 */     return this.copyDetail;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean skip()
/*     */   {
/* 165 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setValues(CopyDefinition detail)
/*     */     throws Exception
/*     */   {
/* 176 */     this.saveFileName.setText(detail.saveFile);
/* 177 */     this.copyDetail = detail;
/* 178 */     this.copyDetail.fileSaved = false;
/* 179 */     this.copyDetail.complete = "YES";
/*     */     
/* 181 */     if (this.copyDetail.fieldErrorFile == null) {
/* 182 */       this.fieldErrorFile.setText("");
/*     */     } else {
/* 184 */       this.fieldErrorFile.setText(this.copyDetail.fieldErrorFile);
/*     */     }
/*     */     
/* 187 */     this.maxErrors.setText("");
/* 188 */     if (this.copyDetail.maxErrors >= 0) {
/* 189 */       this.maxErrors.setText(Integer.toString(this.copyDetail.maxErrors));
/*     */     }
/*     */     
/* 192 */     this.stripTrailingSpaces.setSelected(this.copyDetail.stripTrailingSpaces);
/*     */   }
/*     */   
/*     */   public final void run()
/*     */   {
/*     */     try {
/* 198 */       this.copyDetail = getValues();
/*     */       
/* 200 */       boolean ok = DoCopy.copy(this.selection, this.selection2, this.copyDetail);
/*     */       
/* 202 */       this.toRun = false;
/* 203 */       if (ok) {
/* 204 */         setMessageTxtRE("Copy Done !!!");
/*     */       } else {
/* 206 */         setMessageTxtRE("Copy Done !!!, check log for errors");
/*     */       }
/*     */     } catch (Exception e) {
/* 209 */       e.printStackTrace();
/* 210 */       Common.logMsg("Copy Failed:", e);
/* 211 */       setMessageTxtRE("Copy Failed:", e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void save()
/*     */   {
/*     */     try
/*     */     {
/* 222 */       this.copyDetail = getValues();
/*     */       
/* 224 */       if (this.jibx == null) {
/* 225 */         this.jibx = new JibxCall(CopyDefinition.class);
/*     */       }
/* 227 */       this.jibx.unmarshal(this.copyDetail.saveFile, this.copyDetail);
/* 228 */       this.copyDetail.fileSaved = true;
/*     */     } catch (Exception e) {
/* 230 */       e.printStackTrace();
/* 231 */       Common.logMsgRaw(Common.FILE_SAVE_FAILED, e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final boolean isToRun()
/*     */   {
/* 239 */     return this.toRun;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/copy/CopyWizardFinalPnl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */