/*    */ package net.sf.RecordEditor.po.display;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.OutputStreamWriter;
/*    */ import net.sf.RecordEditor.jibx.JibxCall;
/*    */ import net.sf.RecordEditor.jibx.compare.EditorTask;
/*    */ import net.sf.RecordEditor.re.file.FileView;
/*    */ import net.sf.RecordEditor.re.file.filter.FilterDetails;
/*    */ 
/*    */ public class FuzzyFilter
/*    */ {
/* 12 */   public static String TO_WORK_FILTER_XML = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><EditorTask type=\"Filter\" layoutName=\"GetText_PO\">  <layout name=\"GetText_PO\" groupHeader=\"\">    <record name=\"GetText_PO\">      <FieldTest fieldName=\"fuzzy\"  operator=\"Contains\" value=\"Y\" booleanOperator=\"And\"/>      <FieldTest fieldName=\"msgstr\" operator=\"Is Empty\" value=\"\"  booleanOperator=\"Or\"/>      <FieldTest fieldName=\"msgidPlural\"  operator=\"Is Empty\" value=\"\"  booleanOperator=\"And\"/>      <FieldTest fieldName=\"msgstrPlural\" operator=\"Is Empty\" value=\"\"  booleanOperator=\"Or\"/>      <FieldTest fieldName=\"msgstrPlural\" operator=\" &lt;> \"  value=\"\"  booleanOperator=\"And\"/>    </record>  </layout></EditorTask>";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 26 */   private static String fName = null;
/*    */   private static FilterDetails filter;
/*    */   
/*    */   private static String getFileName() {
/* 30 */     if (fName == null) {
/*    */       try {
/* 32 */         File f = File.createTempFile("FuzzyFilter", "x,l");
/* 33 */         OutputStreamWriter s = new OutputStreamWriter(new java.io.FileOutputStream(f), "utf8");
/*    */         
/* 35 */         s.write(TO_WORK_FILTER_XML);
/* 36 */         s.close();
/* 37 */         fName = f.getAbsolutePath();
/*    */       }
/*    */       catch (Exception e) {}
/*    */     }
/*    */     
/* 42 */     return fName;
/*    */   }
/*    */   
/*    */   public static final FileView getFuzzyView(FileView fileView)
/*    */   {
/* 47 */     if (filter == null) {
/*    */       try {
/* 49 */         JibxCall<EditorTask> jibx = new JibxCall(EditorTask.class);
/*    */         
/*    */ 
/*    */ 
/* 53 */         EditorTask saveDetails = (EditorTask)jibx.marshal(getFileName());
/*    */         
/* 55 */         filter = new FilterDetails(fileView.getLayout(), FilterDetails.FT_NORMAL);
/*    */         
/* 57 */         filter.updateFromExternalLayout(saveDetails.filter);
/*    */       }
/*    */       catch (ClassNotFoundException e) {
/* 60 */         e.printStackTrace();
/* 61 */         filter = null;
/* 62 */         return null;
/*    */       } catch (Exception e) {
/* 64 */         e.printStackTrace();
/* 65 */         filter = null;
/* 66 */         return null;
/*    */       }
/*    */     }
/*    */     
/* 70 */     return fileView.getFilteredView(filter);
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/po/display/FuzzyFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */