/*    */ package net.sf.RecordEditor.po.display;
/*    */ 
/*    */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*    */ import net.sf.RecordEditor.edit.display.DisplayBuilderImp;
/*    */ import net.sf.RecordEditor.edit.display.DisplayFrame;
/*    */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*    */ import net.sf.RecordEditor.re.display.AbstractFileDisplayWithFieldHide;
/*    */ import net.sf.RecordEditor.re.display.IDisplayFrame;
/*    */ import net.sf.RecordEditor.re.file.FileView;
/*    */ import net.sf.RecordEditor.re.script.DisplayBuilderAdapter;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ import net.sf.RecordEditor.utils.params.BoolOpt;
/*    */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*    */ import net.sf.RecordEditor.utils.params.ProgramOptions.StringOpt;
/*    */ 
/*    */ public class PoDisplayBuilder extends DisplayBuilderAdapter
/*    */ {
/* 18 */   private static final TableCellColoringAgent coloringAgent = new TableCellColoringAgent();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private static final String PO_LIST = "PO List";
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public AbstractFileDisplayWithFieldHide newDisplay(int screenType, String screenName, IDisplayFrame<? extends AbstractFileDisplay> parentFrame, AbstractLayoutDetails group, FileView viewOfFile, int lineNo)
/*    */   {
/* 30 */     if (viewOfFile.getLayout().getFileStructure() == 101) {
/* 31 */       switch (screenType) {
/*    */       case 1: 
/*    */       case 2: 
/* 34 */         if ((screenName == null) || ("".equals(screenName))) {
/* 35 */           screenName = "PO List";
/*    */         }
/* 37 */         PoList polist = getListScreen(screenName, parentFrame, group, viewOfFile, true, viewOfFile.getRowCount() == 0);
/*    */         
/* 39 */         if (Common.OPTIONS.openPoFuzzyWindow.isSelected()) {
/* 40 */           FileView fuzzyView = FuzzyFilter.getFuzzyView(viewOfFile);
/*    */           
/* 42 */           if ((fuzzyView != null) && (fuzzyView.getRowCount() > 0)) {
/* 43 */             PoList screen = getListScreen("Fuzzy/Blank", polist.getParentFrame(), group, fuzzyView, false, false);
/*    */             
/* 45 */             if (screen != null) {
/* 46 */               DisplayFrame parentFrame2 = screen.getParentFrame();
/* 47 */               parentFrame2.executeAction(screen, 67);
/*    */             }
/*    */           }
/*    */         }
/*    */         
/* 52 */         return polist;
/*    */       
/*    */       case 3: 
/* 55 */         if ((screenName == null) || ("".equals(screenName))) {
/* 56 */           screenName = "PO List";
/*    */         }
/* 58 */         return getListScreen(screenName, parentFrame, group, viewOfFile, viewOfFile == viewOfFile.getBaseFile(), false);
/*    */       
/*    */       case 4: 
/* 61 */         return (AbstractFileDisplayWithFieldHide)DisplayBuilderImp.addToScreen(parentFrame, new PoRecordScreen(viewOfFile, lineNo, parentFrame.getActiveDisplay().getJTable()));
/*    */       }
/*    */       
/*    */     }
/* 65 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   private PoList getListScreen(String screenName, IDisplayFrame<? extends AbstractFileDisplay> parentFrame, AbstractLayoutDetails group, FileView viewOfFile, boolean primaryScreen, boolean addBlankLine)
/*    */   {
/* 72 */     PoList polist = new PoList(screenName, viewOfFile, primaryScreen);
/* 73 */     polist.setTableCellColoringAgent(coloringAgent);
/*    */     
/* 75 */     DisplayBuilderImp.addToScreen(parentFrame, polist);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 80 */     if (addBlankLine) {
/* 81 */       polist.insertLine(0);
/* 82 */       polist.getParentFrame().executeAction(0, getChildOption());
/* 83 */       polist.getParentFrame().setActiveIdx(1);
/*    */     } else {
/* 85 */       polist.getParentFrame().executeAction(0, getChildOption());
/*    */     }
/*    */     
/* 88 */     return polist;
/*    */   }
/*    */   
/*    */   public static int getChildOption() {
/* 92 */     int ret = 68;
/* 93 */     if ("B".equals(Common.OPTIONS.poChildScreenPosition.get())) {
/* 94 */       ret = 69;
/*    */     }
/* 96 */     return ret;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/po/display/PoDisplayBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */