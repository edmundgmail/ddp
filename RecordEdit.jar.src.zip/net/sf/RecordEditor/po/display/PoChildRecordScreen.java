/*     */ package net.sf.RecordEditor.po.display;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Rectangle;
/*     */ import javax.swing.JEditorPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextArea;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.RecordEditor.edit.display.BaseDisplay;
/*     */ import net.sf.RecordEditor.edit.display.extension.IChildScreen;
/*     */ import net.sf.RecordEditor.edit.display.extension.PaneDtls;
/*     */ import net.sf.RecordEditor.edit.display.extension.SplitPaneRecord;
/*     */ import net.sf.RecordEditor.edit.display.util.LinePosition;
/*     */ import net.sf.RecordEditor.po.def.PoField;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.swing.array.ArrayRender;
/*     */ import org.jdesktop.swingx.JXMultiSplitPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PoChildRecordScreen
/*     */   extends BaseDisplay
/*     */   implements IChildScreen
/*     */ {
/*     */   private static final String COMMENT_STR = "Comment";
/*     */   private static final String MSGCTXT_STR = "msgctxt";
/*     */   private static final String MSGID_STR = "msgid";
/*     */   private static final String MSGSTR_STR = "msgstr";
/*     */   private static final String HTML_STR = "Html";
/*     */   private static final String MSGSTR_PLURAL_STR = "msgstr plural";
/*     */   private static final String MSGID_PLURAL_STR = "msgid plural";
/*     */   private static final int CODE_MSG_CTX = 1;
/*     */   private static final int CODE_PLURAL = 2;
/*     */   private static final int CODE_COMMENT = 4;
/*     */   private static final int CODE_HTML = 8;
/*     */   private static final int CODE_MSGSTR = 16;
/*  41 */   private static final double[] STD_PNL_WEIGHT = { 0.3D, 0.3D, 0.3D };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  46 */   private String[] STR_TRANS = { "msgctxt", "Html", "Comment", "msgid plural", "msgstr plural", "msgstr" };
/*     */   
/*     */ 
/*  49 */   private int[] CODE_TRANS = { 1, 8, 4, 2, 2, 16 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  54 */   private final PaneDtls[] optionalFields = new PaneDtls[this.STR_TRANS.length];
/*     */   
/*  56 */   private int activeFields = 0;
/*     */   
/*     */ 
/*     */ 
/*     */   protected SplitPaneRecord splitRecPane;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static PoChildRecordScreen newRightHandScreen(JTable parentTbl, FileView viewOfFile, int lineNo)
/*     */   {
/*  67 */     ArrayRender msgstrPlural = new ArrayRender(true, false);
/*  68 */     msgstrPlural.setTableDetails(parentTbl, lineNo, PoField.msgstrPlural.fieldIdx, "", viewOfFile.getBaseFile().getFileNameNoDirectory(), viewOfFile.getBaseFile());
/*     */     
/*  70 */     PaneDtls[] fields = { new PaneDtls("Comment", PoField.comments, new JTextArea(), 0.15D), new PaneDtls("msgctxt", PoField.msgctxt, new JTextArea()), new PaneDtls("msgid", PoField.msgid, new JTextArea(), 0.15D), new PaneDtls("msgstr", PoField.msgstr, new JTextArea(), 0.15D), new PaneDtls("msgid plural", PoField.msgidPlural, new JTextArea(), 0.15D), new PaneDtls("msgstr plural", PoField.msgstrPlural, msgstrPlural, 0, PaneDtls.NOT_HTML, 0.15D), new PaneDtls("Html", PoField.msgstr, new JEditorPane("text/html", ""), 0, PaneDtls.IS_HTML, 0.15D) };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  80 */     return new PoChildRecordScreen(viewOfFile, lineNo, fields, null);
/*     */   }
/*     */   
/*     */ 
/*     */   public static PoChildRecordScreen newBottomScreen(JTable parentTbl, FileView viewOfFile, int lineNo)
/*     */   {
/*  86 */     ArrayRender msgstrPlural = new ArrayRender(true, false);
/*  87 */     msgstrPlural.setTableDetails(parentTbl, lineNo, PoField.msgstrPlural.fieldIdx, "", viewOfFile.getBaseFile().getFileNameNoDirectory(), viewOfFile.getBaseFile());
/*     */     
/*  89 */     PaneDtls[] fields = { new PaneDtls("Comment", PoField.comments, new JTextArea(), 0), new PaneDtls("msgctxt", PoField.msgctxt, new JTextArea(), 1), new PaneDtls("msgid", PoField.msgid, new JTextArea(), 1), new PaneDtls("msgstr", PoField.msgstr, new JTextArea(), 1), new PaneDtls("msgid plural", PoField.msgidPlural, new JTextArea(), 1), new PaneDtls("msgstr plural", PoField.msgstrPlural, msgstrPlural, 2, PaneDtls.NOT_HTML, 0.15D), new PaneDtls("Html", PoField.msgstr, new JEditorPane("text/html", ""), 3, true) };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  99 */     return new PoChildRecordScreen(viewOfFile, lineNo, fields, STD_PNL_WEIGHT);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public PoChildRecordScreen(FileView viewOfFile, int lineNo, PaneDtls[] newFields, double[] newWeight)
/*     */   {
/* 106 */     super("Single PO Record", viewOfFile, false, false, false, false, false, 4);
/*     */     
/*     */ 
/*     */ 
/* 110 */     setJTable(new JTable());
/* 111 */     this.splitRecPane = new SplitPaneRecord(NO_CLOSE_ACTION_PNL, viewOfFile, lineNo);
/* 112 */     this.splitRecPane.setFields(newFields, newWeight);
/*     */     
/* 114 */     init_100_Init(newFields);
/* 115 */     init_200_layoutScreen();
/*     */   }
/*     */   
/*     */   private void init_100_Init(PaneDtls[] newFields)
/*     */   {
/* 120 */     for (PaneDtls p : newFields) {
/* 121 */       for (int i = 0; i < this.STR_TRANS.length; i++) {
/* 122 */         if (p.name == this.STR_TRANS[i]) {
/* 123 */           this.optionalFields[i] = p;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void init_200_layoutScreen()
/*     */   {
/* 131 */     layoutFieldPane(getFieldsUsed());
/* 132 */     this.splitRecPane.layoutFieldPane();
/*     */     
/* 134 */     this.actualPnl.addComponentRE(1, 3, -1.0D, BasePanel.GAP, 2, 2, this.splitRecPane.splitPane);
/*     */     
/*     */ 
/* 137 */     this.actualPnl.done();
/* 138 */     int minWidth = Math.min(this.screenSize.width * 3 / 20, 30 * SwingUtils.CHAR_FIELD_WIDTH);
/* 139 */     this.actualPnl.setPreferredSize(new Dimension(Math.max(minWidth, this.actualPnl.getPreferredSize().width), this.actualPnl.getPreferredSize().height));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setScreenSize(boolean mainframe)
/*     */   {
/* 149 */     this.actualPnl.done();
/*     */   }
/*     */   
/*     */ 
/*     */   protected int getInsertAfterPosition()
/*     */   {
/* 155 */     return getStandardPosition();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected LinePosition getInsertAfterLine(boolean prev)
/*     */   {
/* 163 */     return super.getInsertAfterLine(this.splitRecPane.getCurrRow(), prev);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void fireLayoutIndexChanged() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCurrRow()
/*     */   {
/* 181 */     return this.splitRecPane.getCurrRow();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCurrRow(int newRow)
/*     */   {
/* 189 */     int oldRow = this.splitRecPane.getCurrRow();
/* 190 */     this.splitRecPane.setCurrRow(newRow);
/*     */     
/* 192 */     if ((newRow >= 0) && 
/* 193 */       (oldRow != newRow)) {
/* 194 */       oldRow = newRow;
/* 195 */       rowChanged();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void setCurrRow(int newRow, int layoutId, int fieldNum)
/*     */   {
/* 202 */     setCurrRow(newRow);
/*     */   }
/*     */   
/*     */   protected BaseDisplay getNewDisplay(FileView view)
/*     */   {
/* 207 */     return null;
/*     */   }
/*     */   
/*     */   private void rowChanged() {
/* 211 */     int code = getFieldsUsed();
/*     */     
/*     */ 
/* 214 */     if (this.activeFields == code)
/*     */     {
/* 216 */       this.splitRecPane.splitPane.repaint();
/*     */     } else {
/* 218 */       this.splitRecPane.splitPane.removeAll();
/* 219 */       layoutFieldPane(code);
/*     */       
/*     */ 
/* 222 */       this.splitRecPane.layoutFieldPane();
/*     */       
/* 224 */       this.actualPnl.revalidate();
/* 225 */       this.actualPnl.repaint();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void layoutFieldPane(int code)
/*     */   {
/* 232 */     this.activeFields = code;
/*     */     
/* 234 */     for (int i = 0; i < this.CODE_TRANS.length; i++) {
/* 235 */       if (this.optionalFields[i] != null) {
/* 236 */         this.optionalFields[i].setVisible((this.activeFields & this.CODE_TRANS[i]) != 0);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void flush()
/*     */   {
/* 268 */     this.splitRecPane.flush();
/*     */   }
/*     */   
/*     */   private int getFieldsUsed() {
/* 272 */     int ret = 0;
/* 273 */     AbstractLine line = this.splitRecPane.getLine();
/* 274 */     Object o = line.getField(0, PoField.msgctxt.fieldIdx);
/*     */     
/* 276 */     if (checkPresent(o)) {
/* 277 */       ret++;
/*     */     }
/*     */     
/* 280 */     o = line.getField(0, PoField.msgidPlural.fieldIdx);
/* 281 */     if (checkPresent(o)) {
/* 282 */       ret += 2;
/*     */     } else {
/* 284 */       ret += 16;
/*     */     }
/* 286 */     o = line.getField(0, PoField.comments.fieldIdx);
/* 287 */     if (checkPresent(o)) {
/* 288 */       ret += 4;
/*     */     }
/*     */     
/* 291 */     o = line.getField(0, PoField.msgstr.fieldIdx);
/* 292 */     if (checkPresent(o)) {
/* 293 */       String s = o.toString();
/* 294 */       if ((s.indexOf('<') >= 0) && (s.indexOf('>') >= 0) && ((s.indexOf("</") >= 0) || (s.indexOf("/>") >= 0))) {
/* 295 */         ret += 8;
/*     */       }
/*     */     }
/*     */     
/* 299 */     return ret;
/*     */   }
/*     */   
/*     */   private boolean checkPresent(Object o) {
/* 303 */     return (o != null) && (!"".equals(o));
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/po/display/PoChildRecordScreen.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */