/*     */ package net.sf.RecordEditor.po.display;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import net.sf.JRecord.Common.AbstractFieldValue;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.RecordEditor.edit.display.BaseDisplay;
/*     */ import net.sf.RecordEditor.po.def.PoField;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*     */ import net.sf.RecordEditor.re.display.DisplayBuilderFactory;
/*     */ import net.sf.RecordEditor.re.display.IDisplayBuilder;
/*     */ import net.sf.RecordEditor.re.display.IDisplayFrame;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.fileStorage.DataStoreStd;
/*     */ import net.sf.RecordEditor.utils.fileStorage.IDataStore;
/*     */ import net.sf.RecordEditor.utils.lang.ReAbstractAction;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ 
/*     */ public class DuplicateFilter
/*     */   implements ActionListener
/*     */ {
/*     */   private final ReFrame displayFrame;
/*  30 */   private final BaseHelpPanel panel = new BaseHelpPanel("PoDuplicateFilter");
/*     */   
/*     */   private final IDisplayFrame<? extends AbstractFileDisplay> parentFrame;
/*     */   private final FileView view;
/*  34 */   private final JCheckBox removeDuplicateChk = new JCheckBox();
/*     */   
/*  36 */   private final JCheckBox removeBlankDuplicateChk = new JCheckBox();
/*  37 */   private final JButton runBtn = new JButton("Generate Duplicate View");
/*     */   
/*     */ 
/*     */   public DuplicateFilter(IDisplayFrame<? extends AbstractFileDisplay> sourceFrame, FileView fileTbl)
/*     */   {
/*  42 */     this.displayFrame = new ReFrame(fileTbl.getFileNameNoDirectory(), "Duplicate Filter", fileTbl.getBaseFile());
/*     */     
/*  44 */     this.parentFrame = sourceFrame;
/*  45 */     this.view = fileTbl;
/*     */     
/*  47 */     init_100_initialise();
/*  48 */     init_200_LayoutScreen();
/*  49 */     init_300_Finalize();
/*     */   }
/*     */   
/*     */   private void init_100_initialise()
/*     */   {
/*  54 */     this.removeDuplicateChk.setSelected(true);
/*     */     
/*  56 */     this.removeBlankDuplicateChk.setSelected(true);
/*     */   }
/*     */   
/*     */   private void init_200_LayoutScreen()
/*     */   {
/*  61 */     this.panel.addLineRE("Remove if (msgctx, msgid*, msgstr*) the same", this.removeDuplicateChk);
/*     */     
/*  63 */     this.panel.addLineRE("Remove Blank Duplicate Transalations", this.removeBlankDuplicateChk).setGapRE(BaseHelpPanel.GAP2);
/*     */     
/*     */ 
/*  66 */     this.panel.addLineRE("", this.runBtn).setGapRE(BaseHelpPanel.GAP2);
/*     */     
/*     */ 
/*  69 */     this.panel.addMessageRE();
/*     */   }
/*     */   
/*     */   private void init_300_Finalize()
/*     */   {
/*  74 */     this.runBtn.addActionListener(this);
/*     */     
/*  76 */     this.displayFrame.setDefaultCloseOperation(2);
/*  77 */     this.displayFrame.addMainComponent(this.panel);
/*     */     
/*  79 */     this.displayFrame.setVisible(true);
/*  80 */     this.displayFrame.setToMaximum(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void actionPerformed(ActionEvent arg0)
/*     */   {
/*  88 */     IDataStore<AbstractLine> ds = getDuplicates();
/*     */     
/*  90 */     if ((ds != null) && (ds.size() > 0)) {
/*  91 */       FileView newView = new FileView(ds, this.view.getBaseFile(), null);
/*     */       
/*  93 */       AbstractFileDisplay l = DisplayBuilderFactory.getInstance().newDisplay(3, "Duplicates", this.parentFrame, this.view.getLayout(), newView, 0);
/*     */       
/*  95 */       this.displayFrame.setVisible(false);
/*     */       
/*  97 */       l.getParentFrame().setToActiveTab(l);
/*  98 */       l.executeAction(50);
/*  99 */       l.getParentFrame().executeAction(68);
/* 100 */       l.getParentFrame().moveToFront();
/*     */     } else {
/* 102 */       this.panel.setMessageTxtRE("No Duplicates found !!!");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final IDataStore<AbstractLine> getDuplicates()
/*     */   {
/* 112 */     int en = this.view.getRowCount();
/* 113 */     HashMap<String, AbstractLine> lineMap = new HashMap(en * 13 / 10);
/* 114 */     HashSet<AbstractLine> lineSet = new HashSet(en * 13 / 10);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 120 */     for (int i = en - 1; i >= 0; i--) {
/* 121 */       AbstractLine l = this.view.getLine(i);
/* 122 */       String key = getKey(l);
/*     */       
/* 124 */       if (lineMap.containsKey(key)) {
/* 125 */         AbstractLine newLine = (AbstractLine)lineMap.get(key);
/* 126 */         if (!"Y".equals(l.getField(0, PoField.obsolete.fieldIdx)))
/*     */         {
/* 128 */           if ((this.removeDuplicateChk.isSelected()) && (checkEqivalent(l, newLine))) {
/* 129 */             this.view.deleteLine(i);
/*     */ 
/*     */           }
/* 132 */           else if ((!this.removeBlankDuplicateChk.isSelected()) || (!checkForSpace(lineMap, lineSet, i, key, l, newLine)))
/*     */           {
/*     */ 
/* 135 */             lineSet.add(newLine);
/* 136 */             lineSet.add(l);
/*     */           } }
/*     */       } else {
/* 139 */         lineMap.put(key, l);
/*     */       }
/*     */     }
/*     */     
/* 143 */     if (lineSet.size() > 0) {
/* 144 */       IDataStore<AbstractLine> ds = DataStoreStd.newStore(this.view.getLayout(), lineSet);
/* 145 */       ds.sortRE(new Cmp(null));
/*     */       
/* 147 */       for (int i = ds.size() - 2; i >= 0; i--) {
/* 148 */         if (checkEqivalent((AbstractLine)ds.get(i + 1), (AbstractLine)ds.get(i))) {
/* 149 */           this.view.deleteLine((AbstractLine)ds.get(i + 1));
/* 150 */           ds.remove(i + 1);
/*     */         }
/*     */       }
/* 153 */       return ds;
/*     */     }
/* 155 */     return null;
/*     */   }
/*     */   
/*     */   private static String getKey(AbstractLine l) {
/* 159 */     return l.getFieldValue(0, PoField.msgctxt.fieldIdx).asString() + "\t~.~\t" + l.getFieldValue(0, PoField.msgid.fieldIdx).asString() + l.getFieldValue(0, PoField.msgidPlural.fieldIdx).asString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static boolean checkEqivalent(AbstractLine l1, AbstractLine l2)
/*     */   {
/* 169 */     return (l1.getFieldValue(0, PoField.msgid.fieldIdx).asString().equals(l2.getFieldValue(0, PoField.msgid.fieldIdx).asString())) && (l1.getFieldValue(0, PoField.msgidPlural.fieldIdx).asString().equals(l2.getFieldValue(0, PoField.msgidPlural.fieldIdx).asString())) && (l1.getFieldValue(0, PoField.msgstr.fieldIdx).asString().equals(l2.getFieldValue(0, PoField.msgstr.fieldIdx).asString())) && (l1.getFieldValue(0, PoField.msgstrPlural.fieldIdx).asString().equals(l2.getFieldValue(0, PoField.msgstrPlural.fieldIdx).asString()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean checkForSpace(HashMap<String, AbstractLine> lineMap, HashSet<AbstractLine> lineSet, int idx, String key, AbstractLine l1, AbstractLine l2)
/*     */   {
/* 223 */     if (l1.getFieldValue(0, PoField.msgid.fieldIdx).asString().equals("") == l2.getFieldValue(0, PoField.msgid.fieldIdx).asString().equals(""))
/*     */     {
/* 225 */       if ((l1.getFieldValue(0, PoField.msgstr.fieldIdx).asString().equals("")) && (l1.getFieldValue(0, PoField.msgstrPlural.fieldIdx).asString().equals("")))
/*     */       {
/* 227 */         this.view.deleteLine(idx);
/* 228 */         return true;
/*     */       }
/* 230 */       if ((l2.getFieldValue(0, PoField.msgstr.fieldIdx).asString().equals("")) && (l2.getFieldValue(0, PoField.msgstrPlural.fieldIdx).asString().equals("")))
/*     */       {
/* 232 */         lineMap.put(key, l1);
/* 233 */         this.view.deleteLine(l2);
/* 234 */         return true;
/*     */       }
/*     */     }
/* 237 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setOptions(boolean removeDuplicate, boolean removeBlankDuplicate)
/*     */   {
/* 247 */     this.removeDuplicateChk.setSelected(removeDuplicate);
/* 248 */     this.removeBlankDuplicateChk.setSelected(removeBlankDuplicate);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ReAbstractAction getDuplicateAction(final BaseDisplay sourceFrame)
/*     */   {
/* 257 */     new ReAbstractAction("Show Duplicate Rows") {
/*     */       public void actionPerformed(ActionEvent e) {
/* 259 */         new DuplicateFilter(sourceFrame.getParentFrame(), sourceFrame.getFileView());
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class Cmp
/*     */     implements Comparator<AbstractLine>
/*     */   {
/*     */     public int compare(AbstractLine o1, AbstractLine o2)
/*     */     {
/* 271 */       return getSortKey(o1).compareToIgnoreCase(getSortKey(o2));
/*     */     }
/*     */     
/*     */     private String getSortKey(AbstractLine o1) {
/* 275 */       return DuplicateFilter.getKey(o1) + "~\t~" + o1.getFieldValue(0, PoField.msgstr.fieldIdx).asString() + "~\t~" + o1.getFieldValue(0, PoField.MSGSTR_PLURAL_INDEX).asString() + "~\t~" + o1.getFieldValue(0, PoField.comments.fieldIdx).asString();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/po/display/DuplicateFilter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */