/*     */ package net.sf.RecordEditor.po.display;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.table.TableCellEditor;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import net.sf.JRecord.Common.IEmptyTest;
/*     */ import net.sf.JRecord.Common.RecordException;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.RecordEditor.po.def.PoLine;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.swing.TextAreaTableCellEditor;
/*     */ import net.sf.RecordEditor.utils.swing.TextAreaTableCellRendor;
/*     */ import net.sf.RecordEditor.utils.swing.array.ArrayInterface;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MsgstrArray
/*     */   implements ArrayInterface, IEmptyTest
/*     */ {
/*  29 */   private static final int DEFAULT_ROW_HEIGHT = SwingUtils.TABLE_ROW_HEIGHT * 3;
/*     */   
/*  31 */   private final TextAreaTableCellRendor rendor = new TextAreaTableCellRendor();
/*     */   
/*     */   private final PoLine line;
/*     */   
/*     */   private final int fieldIdx;
/*  36 */   private List<String> msgLines = null;
/*     */   
/*     */   public MsgstrArray(PoLine poLine, int idx) {
/*  39 */     this.line = poLine;
/*  40 */     this.fieldIdx = idx;
/*     */     
/*  42 */     retrieveArray();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void add(int index, Object value)
/*     */   {
/*  50 */     this.msgLines.add(index, toString(value));
/*  51 */     flush();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean add(Object value)
/*     */   {
/*  59 */     boolean ret = this.msgLines.add(toString(value));
/*  60 */     flush();
/*  61 */     return ret;
/*     */   }
/*     */   
/*     */   private String toString(Object o) {
/*  65 */     String ret = "";
/*  66 */     if (o != null) {
/*  67 */       ret = o.toString();
/*     */     }
/*  69 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Object get(int index, int column)
/*     */   {
/*  76 */     return this.msgLines.get(index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object remove(int index)
/*     */   {
/*  84 */     Object o = this.msgLines.remove(index);
/*  85 */     flush();
/*  86 */     return o;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object set(int index, int column, Object value)
/*     */   {
/*  94 */     Object o = this.msgLines.set(index, toString(value));
/*  95 */     flush();
/*  96 */     return o;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int size()
/*     */   {
/* 104 */     return this.msgLines.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColumnCount()
/*     */   {
/* 112 */     return 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractLine getLine()
/*     */   {
/* 120 */     return this.line;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void retrieveArray()
/*     */   {
/* 129 */     Object o = this.line.getMsgstrPlural();
/*     */     
/* 131 */     if ((o instanceof List)) {
/* 132 */       this.msgLines = ((List)o);
/* 133 */     } else if (this.msgLines == null) {
/* 134 */       this.msgLines = new ArrayList();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void flush()
/*     */   {
/*     */     try
/*     */     {
/* 145 */       Object o = this.msgLines;
/* 146 */       if (this.msgLines.size() == 0) {
/* 147 */         o = null;
/*     */       }
/* 149 */       this.line.setField(0, this.fieldIdx, o);
/*     */     } catch (RecordException e) {
/* 151 */       Common.logMsg("Error updating plurarl msgstr", e);
/* 152 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getReturn()
/*     */   {
/* 162 */     return this.msgLines;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public TableCellRenderer getTableCellRenderer()
/*     */   {
/* 170 */     return this.rendor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public TableCellEditor getTableCellEditor()
/*     */   {
/* 178 */     return new TextAreaTableCellEditor();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFieldHeight()
/*     */   {
/* 186 */     return DEFAULT_ROW_HEIGHT;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 194 */     String s = "";
/* 195 */     if ((this.msgLines != null) && (this.msgLines.size() > 0)) {
/* 196 */       s = (String)this.msgLines.get(0);
/*     */     }
/* 198 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 205 */     return (this.msgLines == null) || (this.msgLines.size() == 0);
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/po/display/MsgstrArray.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */