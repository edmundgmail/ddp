/*    */ package net.sf.RecordEditor.po.display;
/*    */ 
/*    */ import javax.swing.JPopupMenu;
/*    */ import javax.swing.event.TableModelListener;
/*    */ import net.sf.JRecord.Details.LayoutDetail;
/*    */ import net.sf.JRecord.Details.RecordDetail;
/*    */ import net.sf.RecordEditor.edit.display.common.AbstractRowChangedListner;
/*    */ import net.sf.RecordEditor.edit.display.extension.EditPaneListScreen;
/*    */ import net.sf.RecordEditor.po.def.PoLayoutMgr;
/*    */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*    */ import net.sf.RecordEditor.re.file.FileView;
/*    */ import net.sf.RecordEditor.utils.MenuPopupListener;
/*    */ import net.sf.RecordEditor.utils.lang.ReAbstractAction;
/*    */ 
/*    */ public class PoList extends EditPaneListScreen implements AbstractRowChangedListner, TableModelListener, net.sf.RecordEditor.re.display.AbstractFileDisplayWithFieldHide, net.sf.RecordEditor.edit.display.AbstractCreateChildScreen
/*    */ {
/*    */   protected static final boolean[] DEFAULT_FIELD_VISIBILITY;
/*    */   
/*    */   static
/*    */   {
/*    */     boolean[] defaultFieldVisibility;
/*    */     try
/*    */     {
/* 24 */       defaultFieldVisibility = new boolean[((RecordDetail)PoLayoutMgr.PO_LAYOUT.getRecord(0)).getFieldCount()];
/* 25 */       for (int i = 0; i < defaultFieldVisibility.length; i++) {
/* 26 */         defaultFieldVisibility[i] = ((i >= 1) && (i <= 3) ? 1 : false);
/*    */       }
/*    */     } catch (Exception e) {
/* 29 */       e.printStackTrace();
/* 30 */       defaultFieldVisibility = new boolean[0];
/*    */     }
/*    */     
/* 33 */     DEFAULT_FIELD_VISIBILITY = defaultFieldVisibility;
/*    */   }
/*    */   
/*    */ 
/*    */   public PoList(FileView viewOfFile, boolean primary)
/*    */   {
/* 39 */     this("PO List", viewOfFile, primary);
/*    */   }
/*    */   
/*    */   public PoList(String name, FileView viewOfFile, boolean primary)
/*    */   {
/* 44 */     super(name, viewOfFile, primary, false, false, false, false, 4);
/* 45 */     setFieldVisibility(0, DEFAULT_FIELD_VISIBILITY);
/*    */     
/* 47 */     ReAbstractAction duplicateAction = DuplicateFilter.getDuplicateAction(this);
/* 48 */     this.mainPopup.getPopup().addSeparator();
/* 49 */     this.mainPopup.getPopup().add(duplicateAction);
/* 50 */     this.fixedPopupMenu.getPopup().addSeparator();
/* 51 */     this.fixedPopupMenu.getPopup().add(duplicateAction);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public AbstractFileDisplay createChildScreen(int position)
/*    */   {
/* 60 */     if (this.childScreen != null) {
/* 61 */       removeChildScreen();
/*    */     }
/*    */     
/* 64 */     this.currChildScreenPosition = position;
/* 65 */     if (position == 1) {
/* 66 */       this.childScreen = PoChildRecordScreen.newRightHandScreen(getJTable(), this.fileView, Math.max(0, getCurrRow()));
/*    */     } else {
/* 68 */       this.childScreen = PoChildRecordScreen.newBottomScreen(getJTable(), this.fileView, Math.max(0, getCurrRow()));
/*    */     }
/* 70 */     setKeylistner(this.tblDetails);
/* 71 */     setKeylistner(getAlternativeTbl());
/*    */     
/* 73 */     return this.childScreen;
/*    */   }
/*    */   
/*    */ 
/*    */   protected net.sf.RecordEditor.edit.display.BaseDisplay getNewDisplay(FileView view)
/*    */   {
/* 79 */     return new PoList(view, false);
/*    */   }
/*    */   
/*    */   public int getAvailableChildScreenPostion() {
/* 83 */     return 3;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/po/display/PoList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */