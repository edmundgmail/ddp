/*    */ package net.sf.RecordEditor.po.display;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Component;
/*    */ import javax.swing.JTable;
/*    */ import net.sf.JRecord.Details.AbstractLine;
/*    */ import net.sf.RecordEditor.po.def.PoField;
/*    */ import net.sf.RecordEditor.re.file.FileView;
/*    */ import net.sf.RecordEditor.utils.swing.ITableColoringAgent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TableCellColoringAgent
/*    */   implements ITableColoringAgent
/*    */ {
/* 22 */   private static Color brown = new Color(102, 43, 0);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setTableCellColors(Component component, JTable table, int row, int col, boolean isSelected)
/*    */   {
/* 29 */     Object mdl = table.getModel();
/* 30 */     if ((mdl instanceof FileView)) {
/* 31 */       AbstractLine l = ((FileView)mdl).getLine(row);
/*    */       
/* 33 */       Object o = l.getField(0, PoField.obsolete.fieldIdx);
/* 34 */       if ((o != null) && ("Y".equals(o.toString()))) {
/* 35 */         component.setForeground(Color.gray);
/*    */       } else {
/* 37 */         o = l.getField(0, PoField.fuzzy.fieldIdx);
/* 38 */         if ((o != null) && ("Y".equals(o.toString()))) {
/* 39 */           component.setForeground(brown);
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/po/display/TableCellColoringAgent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */