/*     */ package net.sf.RecordEditor.po;
/*     */ 
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.util.List;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.LayoutDetail;
/*     */ import net.sf.JRecord.IO.AbstractLineWriter;
/*     */ import net.sf.RecordEditor.po.def.PoField;
/*     */ import net.sf.RecordEditor.po.def.PoLine;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PoMessageLineWriter
/*     */   extends AbstractLineWriter
/*     */ {
/*     */   private OutputStream outStream;
/*  27 */   private OutputStreamWriter stdWriter = null;
/*  28 */   private BufferedWriter writer = null;
/*     */   
/*     */   public void open(OutputStream outputStream)
/*     */     throws IOException
/*     */   {
/*  33 */     this.outStream = outputStream;
/*     */   }
/*     */   
/*     */   public void write(AbstractLine line)
/*     */     throws IOException
/*     */   {
/*  39 */     AbstractLayoutDetails layout = line.getLayout();
/*     */     
/*  41 */     if (this.stdWriter == null) {
/*  42 */       if ((layout == null) || ("".equals(layout.getFontName()))) {
/*  43 */         this.stdWriter = new OutputStreamWriter(this.outStream);
/*     */       } else {
/*  45 */         this.stdWriter = new OutputStreamWriter(this.outStream, layout.getFontName());
/*     */       }
/*  47 */       this.writer = new BufferedWriter(this.stdWriter);
/*     */       
/*  49 */       if ((layout instanceof LayoutDetail)) {
/*  50 */         Object o = ((LayoutDetail)layout).getExtraDetails();
/*  51 */         if ((o != null) && ((o instanceof PoLine))) {
/*  52 */           write1line((PoLine)o);
/*     */         }
/*     */       }
/*     */     }
/*  56 */     write1line(line);
/*     */   }
/*     */   
/*     */   private void write1line(AbstractLine line) throws IOException
/*     */   {
/*     */     try {
/*  62 */       String fuzzy = fix(line.getField(0, PoField.fuzzy.fieldIdx));
/*  63 */       Object flags = line.getField(0, PoField.flags.fieldIdx);
/*  64 */       if (!"".equals(fuzzy)) {
/*  65 */         if ((flags == null) || ("".equals(flags))) {
/*  66 */           flags = "fuzzy";
/*     */         } else {
/*  68 */           flags = flags + ", " + "fuzzy";
/*     */         }
/*     */       }
/*  71 */       writeComment("# ", line.getField(0, PoField.comments.fieldIdx));
/*  72 */       writeComment("#. ", line.getField(0, PoField.extractedComments.fieldIdx));
/*  73 */       writeComment("#: ", line.getField(0, PoField.reference.fieldIdx));
/*  74 */       writeComment("#, ", flags);
/*     */       
/*  76 */       String prefix = "";
/*  77 */       Object o = line.getField(0, PoField.obsolete.fieldIdx);
/*  78 */       if ((o != null) && ("Y".equals(o.toString()))) {
/*  79 */         prefix = "#~ ";
/*     */       }
/*     */       
/*  82 */       writeMsgctxt(prefix, line.getField(0, PoField.msgctxt.fieldIdx));
/*     */       
/*  84 */       writeMsgid(prefix, line.getField(0, PoField.msgid.fieldIdx));
/*  85 */       Object msgIdPlural = line.getField(0, PoField.msgidPlural.fieldIdx);
/*  86 */       if (msgIdPlural != null) {
/*  87 */         List<String> msgstrPlural = null;
/*  88 */         if ((line instanceof PoLine)) {
/*  89 */           Object oo = ((PoLine)line).getMsgstrPlural();
/*  90 */           if ((oo instanceof List)) {
/*  91 */             msgstrPlural = (List)oo;
/*     */           }
/*     */         }
/*     */         
/*  95 */         writeMsgidPlural(prefix, line.getField(0, PoField.msgidPlural.fieldIdx));
/*  96 */         writeMsgstrPlurals(prefix, msgstrPlural);
/*     */       } else {
/*  98 */         writeMsgstr(prefix, line.getField(0, PoField.msgstr.fieldIdx));
/*     */       }
/*     */     } catch (Exception e) {
/* 101 */       e.printStackTrace();
/* 102 */       Common.logMsg("Error Writing File: " + e, null);
/*     */     }
/*     */     
/* 105 */     this.writer.newLine();
/* 106 */     this.writer.flush();
/*     */   }
/*     */   
/*     */ 
/*     */   protected void writeComment(String prefix, Object comment)
/*     */     throws IOException
/*     */   {
/* 113 */     if (comment != null) {
/* 114 */       String[] lines = comment.toString().split("\n");
/* 115 */       for (String line : lines) {
/* 116 */         this.writer.write(prefix);
/* 117 */         this.writer.write(line);
/* 118 */         this.writer.newLine();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected void writeMsgctxt(String prefix, Object ctxt) throws IOException
/*     */   {
/* 125 */     if ((ctxt != null) && (!"".equals(ctxt.toString()))) {
/* 126 */       String msgSpace = "msgctxt ";
/* 127 */       this.writer.write(prefix + msgSpace);
/* 128 */       writeString(prefix, ctxt.toString(), msgSpace.length());
/*     */     }
/*     */   }
/*     */   
/*     */   protected void writeMsgid(String prefix, Object objMsgid) throws IOException {
/* 133 */     String msgid = fix(objMsgid);
/*     */     
/* 135 */     String msgSpace = "msgid ";
/* 136 */     this.writer.write(prefix + msgSpace);
/* 137 */     writeString(prefix, msgid, msgSpace.length());
/*     */   }
/*     */   
/*     */   protected void writeMsgidPlural(String prefix, Object objMsgidPlural) throws IOException
/*     */   {
/* 142 */     String msgSpace = "msgid_plural ";
/* 143 */     String msgidPlural = fix(objMsgidPlural);
/* 144 */     this.writer.write(prefix + msgSpace);
/* 145 */     writeString(prefix, msgidPlural, msgSpace.length());
/*     */   }
/*     */   
/*     */   protected void writeMsgstr(String prefix, Object objMsgstr) throws IOException {
/* 149 */     String msgstr = fix(objMsgstr);
/*     */     
/* 151 */     String msgSpace = "msgstr ";
/* 152 */     this.writer.write(prefix + msgSpace);
/* 153 */     writeString(prefix, msgstr, msgSpace.length());
/*     */   }
/*     */   
/*     */   protected void writeMsgstrPlurals(String prefix, List<String> msgstrPlurals) throws IOException {
/* 157 */     int i = 0;
/* 158 */     if (msgstrPlurals != null) {
/* 159 */       for (String msgstr : msgstrPlurals) {
/* 160 */         String msgSpace = "msgstr[" + i + "] ";
/* 161 */         this.writer.write(prefix + msgSpace);
/* 162 */         writeString(prefix, msgstr, msgSpace.length());
/* 163 */         i++;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private String fix(Object o) {
/* 169 */     String s = "";
/* 170 */     if (o != null) {
/* 171 */       s = o.toString();
/*     */     }
/* 173 */     return s;
/*     */   }
/*     */   
/* 176 */   protected void writeString(String prefix, String s, int firstLineContextWidth) throws IOException { writeString(prefix, s, firstLineContextWidth, 80, 0); }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void writeString(String prefix, String s, int firstLineContextWidth, int colWidth, int indent)
/*     */     throws IOException
/*     */   {
/* 194 */     boolean firstline = true;
/* 195 */     boolean wrap = true;
/* 196 */     this.writer.write(34);
/*     */     
/*     */ 
/* 199 */     int firstLineEnd = s.indexOf('\n');
/* 200 */     if ((wrap) && (((firstLineEnd != -1) && (firstLineEnd > colWidth - firstLineContextWidth - 4)) || (s.length() > colWidth - firstLineContextWidth - 4)))
/*     */     {
/* 202 */       firstline = false;
/* 203 */       this.writer.write(34);
/* 204 */       this.writer.newLine();
/* 205 */       if (prefix.isEmpty()) {
/* 206 */         this.writer.write(34);
/*     */       }
/*     */     }
/* 209 */     StringBuilder currentLine = new StringBuilder(100);
/*     */     
/* 211 */     int lastSpacePos = 0;
/*     */     
/* 213 */     for (int i = 0; i < s.length(); i++) {
/* 214 */       char currentChar = s.charAt(i);
/*     */       
/* 216 */       switch (currentChar) {
/*     */       case '\n': 
/* 218 */         currentLine.append('\\');
/* 219 */         currentLine.append('n');
/* 220 */         if ((wrap) && (i != s.length() - 1)) {
/* 221 */           writeCurrentLine(prefix, currentLine.toString(), firstline, true);
/*     */           
/* 223 */           firstline = false;
/* 224 */           lastSpacePos = 0;
/* 225 */           currentLine.delete(0, currentLine.length());
/*     */         }
/*     */         break;
/*     */       case '\\': 
/* 229 */         currentLine.append(currentChar);
/* 230 */         currentLine.append(currentChar);
/* 231 */         break;
/*     */       case '\r': 
/* 233 */         currentLine.append('\\');
/* 234 */         currentLine.append('r');
/* 235 */         break;
/*     */       case '\t': 
/* 237 */         currentLine.append('\\');
/* 238 */         currentLine.append('t');
/* 239 */         break;
/*     */       case '"': 
/* 241 */         currentLine.append('\\');
/* 242 */         currentLine.append(currentChar);
/* 243 */         break;
/*     */       case ' ': 
/*     */       case '-': 
/*     */       case '.': 
/*     */       case '/': 
/*     */       case ':': 
/*     */       case '=': 
/* 250 */         lastSpacePos = currentLine.length();
/* 251 */         currentLine.append(currentChar);
/* 252 */         break;
/*     */       default: 
/* 254 */         currentLine.append(currentChar);
/*     */       }
/*     */       
/* 257 */       if ((wrap) && (currentLine.length() > colWidth - 4) && (lastSpacePos != 0)) {
/* 258 */         writeCurrentLine(prefix, currentLine.substring(0, lastSpacePos + 1), firstline, true);
/*     */         
/* 260 */         firstline = false;
/* 261 */         currentLine.delete(0, lastSpacePos + 1);
/* 262 */         lastSpacePos = 0;
/*     */       }
/*     */     }
/*     */     
/* 266 */     writeCurrentLine(prefix, currentLine.toString(), firstline, false);
/*     */   }
/*     */   
/*     */   private void writeCurrentLine(String prefix, String currline, boolean firstline, boolean openNextLine)
/*     */     throws IOException
/*     */   {
/* 272 */     if (prefix.isEmpty()) {
/* 273 */       this.writer.write(currline);
/* 274 */       this.writer.write(34);
/* 275 */       this.writer.newLine();
/* 276 */       if (openNextLine) {
/* 277 */         this.writer.write(34);
/*     */       }
/* 279 */     } else if (firstline) {
/* 280 */       this.writer.write(currline);
/* 281 */       this.writer.write(34);
/* 282 */       this.writer.newLine();
/*     */     } else {
/* 284 */       this.writer.write(prefix);
/* 285 */       this.writer.write(34);
/* 286 */       this.writer.write(currline);
/* 287 */       this.writer.write(34);
/* 288 */       this.writer.newLine();
/*     */     }
/*     */   }
/*     */   
/*     */   public void close() throws IOException
/*     */   {
/* 294 */     if (this.stdWriter != null) {
/* 295 */       if (this.writer != null) {
/* 296 */         this.writer.close();
/*     */       }
/* 298 */       this.stdWriter.close();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/po/PoMessageLineWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */