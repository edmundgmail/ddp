/*     */ package net.sf.RecordEditor.po;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.Closeable;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.sf.JRecord.Common.Conversion;
/*     */ import net.sf.JRecord.Common.RecordException;
/*     */ import net.sf.JRecord.Details.LayoutDetail;
/*     */ import net.sf.JRecord.IO.AbstractLineReader;
/*     */ import net.sf.RecordEditor.edit.display.extension.FieldDef;
/*     */ import net.sf.RecordEditor.po.def.PoField;
/*     */ import net.sf.RecordEditor.po.def.PoLayoutMgr;
/*     */ import net.sf.RecordEditor.po.def.PoLine;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PoMessageLineReader
/*     */   extends AbstractLineReader<LayoutDetail>
/*     */ {
/*     */   private static final int BUFFER_SIZE = 16384;
/*  34 */   private static final FieldDef[] ALL_FIELDS = ;
/*     */   
/*     */   private BufferedReader r;
/*     */   
/*     */   private String font;
/*     */   
/*  40 */   private PoLine holdLine = null;
/*     */   
/*  42 */   private ArrayList<Closeable> itmsToClose = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void open(InputStream inputStream, LayoutDetail pLayout)
/*     */     throws IOException, RecordException
/*     */   {
/*  51 */     BufferedInputStream is = new BufferedInputStream(inputStream, 65536);
/*  52 */     is.mark(65536);
/*  53 */     this.font = "";
/*     */     
/*  55 */     InputStreamReader reader = new InputStreamReader(is);
/*  56 */     this.itmsToClose.add(inputStream);
/*  57 */     getPoDetails(pLayout, reader);
/*     */     
/*  59 */     if (!"".equals(this.font)) {
/*  60 */       is.reset();
/*     */       try {
/*  62 */         InputStreamReader in = new InputStreamReader(is, this.font);
/*  63 */         this.r = new BufferedReader(in);
/*  64 */         this.itmsToClose.add(in);
/*     */       } catch (Exception e) {
/*  66 */         this.r = new BufferedReader(reader);
/*     */       }
/*  68 */       read();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void open(InputStream inputStream, String fileName, LayoutDetail pLayout)
/*     */     throws IOException, RecordException
/*     */   {
/* 142 */     this.font = "";
/* 143 */     getPoDetails(pLayout, new FileReader(fileName));
/*     */     
/* 145 */     if (!"".equals(this.font)) {
/* 146 */       this.r.close();
/*     */       try {
/* 148 */         FileInputStream in = new FileInputStream(fileName);
/* 149 */         this.itmsToClose.add(in);
/* 150 */         InputStreamReader in2 = new InputStreamReader(in, this.font);
/* 151 */         this.itmsToClose.add(in2);
/* 152 */         this.r = new BufferedReader(in2, 16384);
/*     */       } catch (Exception e) {
/* 154 */         Reader reader = new FileReader(fileName);
/* 155 */         this.itmsToClose.add(reader);
/* 156 */         this.r = new BufferedReader(new FileReader(fileName), 16384);
/*     */       }
/* 158 */       read();
/*     */     }
/*     */   }
/*     */   
/*     */   private void getPoDetails(LayoutDetail pLayout, Reader reader) throws IOException
/*     */   {
/* 164 */     this.r = new BufferedReader(reader, 16384);
/* 165 */     pLayout = PoLayoutMgr.getPoLayout();
/* 166 */     super.setLayout(pLayout);
/*     */     
/* 168 */     this.itmsToClose.add(reader);
/*     */     
/*     */ 
/*     */ 
/* 172 */     this.font = "";
/* 173 */     PoLine l = read();
/* 174 */     if (l != null) {
/* 175 */       Object o = l.getField(0, PoField.msgstr.fieldIdx);
/* 176 */       Object o2 = l.getField(0, PoField.msgid.fieldIdx);
/*     */       
/*     */ 
/*     */ 
/* 180 */       if ((o != null) && (o2 != null) && ("".equals(o2.toString()))) {
/* 181 */         String s = o.toString().toLowerCase();
/* 182 */         int pos = s.indexOf("charset=");
/*     */         
/* 184 */         if (pos >= 0) {
/* 185 */           s = s.substring(pos + 8);
/*     */           
/* 187 */           int pos1 = s.indexOf(' ');
/* 188 */           int pos2 = s.indexOf("\\n");
/* 189 */           int pos3 = s.indexOf(';');
/* 190 */           int pos4 = s.indexOf('\n');
/* 191 */           pos = pos1;
/* 192 */           if ((pos < 0) || ((pos2 >= 0) && (pos2 < pos))) {
/* 193 */             pos = pos2;
/*     */           }
/* 195 */           if ((pos < 0) || ((pos3 >= 0) && (pos3 < pos))) {
/* 196 */             pos = pos3;
/*     */           }
/* 198 */           if ((pos < 0) || ((pos4 >= 0) && (pos4 < pos))) {
/* 199 */             pos = pos4;
/*     */           }
/*     */           
/* 202 */           if (pos > 0) {
/* 203 */             this.font = s.substring(0, pos);
/* 204 */             pLayout.setFontName(this.font);
/*     */           }
/*     */         }
/*     */         
/* 208 */         pLayout.setExtraDetails(l);
/*     */       } else {
/* 210 */         this.holdLine = l;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public final PoLine read() throws IOException
/*     */   {
/* 217 */     if (this.holdLine != null) {
/* 218 */       PoLine line = this.holdLine;
/* 219 */       this.holdLine = null;
/* 220 */       return line;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 225 */     int fldIdx = -1;
/*     */     String l;
/*     */     do {
/* 228 */       if ((l = this.r.readLine()) == null) {
/* 229 */         return null;
/*     */       }
/* 231 */     } while ("".equals(l.trim()));
/*     */     
/* 233 */     PoLine line = new PoLine((LayoutDetail)getLayout());
/*     */     do {
/* 235 */       String lc = l.toLowerCase();
/* 236 */       boolean found = false;
/*     */       
/* 238 */       if (lc.startsWith("#~ ")) {
/*     */         try {
/* 240 */           line.setField(0, PoField.obsolete.fieldIdx, "Y");
/*     */         }
/*     */         catch (Exception e) {}
/*     */         
/* 244 */         lc = lc.substring(3);
/* 245 */         l = l.substring(3);
/*     */       }
/* 247 */       for (int i = 0; i < ALL_FIELDS.length; i++) {
/* 248 */         if (ALL_FIELDS[i].isMatch(lc)) {
/* 249 */           Object o = line.getRawField(0, ALL_FIELDS[i].fieldIdx);
/* 250 */           String inputLine; String inputLine; if (l.length() >= ALL_FIELDS[i].name.length()) {
/* 251 */             inputLine = l.substring(ALL_FIELDS[i].name.length());
/*     */           } else {
/* 253 */             inputLine = "";
/*     */           }
/*     */           
/* 256 */           if (ALL_FIELDS[i].repeating) {
/* 257 */             o = processRepeatingField(i, inputLine, o);
/*     */           } else {
/* 259 */             o = updateInputLine(i, inputLine, o);
/*     */           }
/*     */           
/* 262 */           updateField(line, ALL_FIELDS[i].fieldIdx, o);
/*     */           
/* 264 */           found = true;
/* 265 */           fldIdx = i;
/* 266 */           break;
/*     */         }
/*     */       }
/*     */       
/* 270 */       if ((fldIdx >= 0) && (!found)) {
/* 271 */         Object o = updateInputLine(fldIdx, l, line.getField(0, ALL_FIELDS[fldIdx].fieldIdx));
/* 272 */         updateField(line, ALL_FIELDS[fldIdx].fieldIdx, o);
/*     */       }
/* 274 */     } while (((l = this.r.readLine()) != null) && (!"".equals(l.trim())));
/*     */     
/* 276 */     String flags = fix(line.getField(0, PoField.flags.fieldIdx));
/* 277 */     if ((flags != null) && (flags.indexOf("fuzzy") >= 0)) {
/*     */       try {
/* 279 */         line.setField(0, PoField.fuzzy.fieldIdx, "Y");
/* 280 */         if ("fuzzy".equals(flags.trim())) {
/* 281 */           flags = "";
/* 282 */         } else if (flags.indexOf(", fuzzy") >= 0) {
/* 283 */           flags = Conversion.replace(new StringBuilder(flags), ", fuzzy", "").toString();
/* 284 */         } else if (flags.indexOf("fuzzy, ") >= 0) {
/* 285 */           flags = Conversion.replace(new StringBuilder(flags), "fuzzy, ", "").toString();
/*     */         } else {
/* 287 */           flags = Conversion.replace(new StringBuilder(flags), "fuzzy", "").toString();
/*     */         }
/* 289 */         line.setField(0, PoField.flags.fieldIdx, flags);
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*     */     
/* 294 */     return line;
/*     */   }
/*     */   
/*     */   private String fix(Object o) {
/* 298 */     String s = "";
/* 299 */     if (o != null) {
/* 300 */       s = o.toString();
/*     */     }
/* 302 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */   private List<String> processRepeatingField(int fldIdx, String inputTxt, Object currValue)
/*     */   {
/* 308 */     int pos1 = inputTxt.indexOf('[');
/* 309 */     int pos2 = inputTxt.indexOf(']');
/* 310 */     List<String> a; List<String> a; if ((currValue != null) && ((currValue instanceof List))) {
/* 311 */       a = (List)currValue;
/*     */     } else {
/* 313 */       a = new ArrayList();
/*     */     }
/*     */     
/* 316 */     if ((pos1 < 0) || (pos2 < 2) || (pos1 >= pos2)) {
/* 317 */       a.add(stripQuotes(ALL_FIELDS[fldIdx], inputTxt));
/*     */     } else {
/* 319 */       String numStr = inputTxt.substring(pos1 + 1, pos2);
/* 320 */       inputTxt = stripQuotes(ALL_FIELDS[fldIdx], inputTxt.substring(pos2 + 1));
/*     */       try {
/* 322 */         int idx = Integer.parseInt(numStr);
/* 323 */         for (int j = a.size(); j <= idx; j++) {
/* 324 */           a.add(null);
/*     */         }
/* 326 */         a.set(idx, inputTxt);
/*     */       } catch (Exception e) {
/* 328 */         a.add(inputTxt);
/*     */       }
/*     */     }
/* 331 */     return a;
/*     */   }
/*     */   
/*     */   private Object updateInputLine(int fldIdx, String inputTxt, Object currValue) {
/* 335 */     inputTxt = stripQuotes(ALL_FIELDS[fldIdx], inputTxt);
/* 336 */     if (currValue == null) {
/* 337 */       currValue = inputTxt;
/* 338 */     } else if (ALL_FIELDS[fldIdx].stripQuote) {
/* 339 */       currValue = currValue.toString() + inputTxt;
/*     */     } else {
/* 341 */       currValue = currValue.toString() + "\n" + inputTxt;
/*     */     }
/* 343 */     return currValue;
/*     */   }
/*     */   
/*     */   private void updateField(PoLine line, int fldNo, Object value) {
/*     */     try {
/* 348 */       line.setField(0, fldNo, value);
/*     */     } catch (Exception e) {
/* 350 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 361 */     for (Closeable c : this.itmsToClose) {
/*     */       try {
/* 363 */         c.close();
/*     */       } catch (Exception e) {
/* 365 */         e.printStackTrace();
/*     */       }
/*     */     }
/* 368 */     this.r.close();
/*     */   }
/*     */   
/*     */   public static String stripQuotes(FieldDef field, String s) {
/* 372 */     if (field.stripQuote) {
/* 373 */       String tmp = s.trim();
/* 374 */       if (tmp.startsWith("\"")) {
/* 375 */         if (tmp.endsWith("\"")) {
/* 376 */           if (tmp.length() == 2) {
/* 377 */             tmp = "";
/*     */           } else {
/* 379 */             tmp = tmp.substring(1, tmp.length() - 1);
/*     */           }
/*     */         }
/* 382 */         s = tmp;
/*     */       }
/*     */       
/* 385 */       StringBuilder b = new StringBuilder(s);
/*     */       
/* 387 */       s = replace(b).toString();
/*     */     }
/*     */     
/* 390 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final StringBuilder replace(StringBuilder in)
/*     */   {
/* 401 */     String from = "\\";
/*     */     
/* 403 */     int fromLen = from.length() + 1;
/*     */     
/* 405 */     int start = in.indexOf(from, 0);
/* 406 */     while ((start >= 0) && (start + 1 < in.length())) { String to;
/* 407 */       switch (in.charAt(start + 1)) {
/* 408 */       case 'n':  to = "\n"; break;
/*     */       case 't': 
/* 410 */         to = "\t"; break;
/* 411 */       case '"':  to = "\""; break;
/* 412 */       case '\\':  to = "\\"; break;
/* 413 */       default:  to = null;
/*     */       }
/*     */       
/* 416 */       if (to != null) {
/* 417 */         in.replace(start, start + fromLen, to);
/*     */       }
/*     */       
/* 420 */       start = in.indexOf(from, start + 1);
/*     */     }
/*     */     
/* 423 */     return in;
/*     */   }
/*     */   
/*     */   protected static String strip(String s) {
/* 427 */     s = s.trim();
/* 428 */     if (s.startsWith("\"")) {
/* 429 */       s = s.substring(1);
/*     */     }
/* 431 */     if (s.endsWith("\"")) {
/* 432 */       s = s.substring(0, s.length() - 1);
/*     */     }
/* 434 */     if (s.indexOf("\"") > 0) {
/* 435 */       s = Conversion.replace(new StringBuilder(s), "\\\"", "\"").toString();
/*     */     }
/*     */     
/* 438 */     return s;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/po/PoMessageLineReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */