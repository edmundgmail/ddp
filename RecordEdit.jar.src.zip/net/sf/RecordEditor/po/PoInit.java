/*    */ package net.sf.RecordEditor.po;
/*    */ 
/*    */ import net.sf.JRecord.IO.LineIOProvider;
/*    */ import net.sf.RecordEditor.po.display.PoDisplayBuilder;
/*    */ import net.sf.RecordEditor.re.display.DisplayBuilderFactory;
/*    */ import net.sf.RecordEditor.tip.display.TipDisplayBuilder;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*    */ import net.sf.RecordEditor.utils.params.ProgramOptions.InternalBoolOption;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PoInit
/*    */ {
/*    */   public PoInit()
/*    */   {
/* 18 */     DisplayBuilderFactory.register(new PoDisplayBuilder());
/* 19 */     DisplayBuilderFactory.register(new TipDisplayBuilder());
/* 20 */     LineIOProvider.getInstance().register(new PoLineIOProvider());
/*    */     
/* 22 */     Common.OPTIONS.getTextPoPresent.set(true);
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/po/PoInit.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */