/*    */ package net.sf.RecordEditor.po;
/*    */ 
/*    */ import net.sf.JRecord.Common.RecordRunTimeException;
/*    */ import net.sf.JRecord.Details.AbstractLine;
/*    */ import net.sf.JRecord.Details.LayoutDetail;
/*    */ import net.sf.JRecord.Details.LineProvider;
/*    */ import net.sf.RecordEditor.po.def.PoLine;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PoLineProvider
/*    */   implements LineProvider<LayoutDetail, AbstractLine>
/*    */ {
/*    */   public AbstractLine getLine(LayoutDetail recordDescription)
/*    */   {
/* 18 */     return new PoLine();
/*    */   }
/*    */   
/*    */   public AbstractLine getLine(LayoutDetail recordDescription, String linesText)
/*    */   {
/* 23 */     throw new RecordRunTimeException("Not Supported");
/*    */   }
/*    */   
/*    */   public AbstractLine getLine(LayoutDetail recordDescription, byte[] lineBytes)
/*    */   {
/* 28 */     throw new RecordRunTimeException("Not Supported");
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/po/PoLineProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */