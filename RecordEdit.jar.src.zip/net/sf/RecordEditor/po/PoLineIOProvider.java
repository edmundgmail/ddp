/*     */ package net.sf.RecordEditor.po;
/*     */ 
/*     */ import net.sf.JRecord.Details.LineProvider;
/*     */ import net.sf.JRecord.IO.AbstractLineReader;
/*     */ import net.sf.JRecord.IO.AbstractLineWriter;
/*     */ import net.sf.JRecord.IO.BasicIoProvider;
/*     */ import net.sf.RecordEditor.tip.PropertiesLineReader;
/*     */ import net.sf.RecordEditor.tip.PropertiesLineWriter;
/*     */ import net.sf.RecordEditor.tip.TipLineProvider;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PoLineIOProvider
/*     */   extends BasicIoProvider
/*     */ {
/*     */   private static final String PO_STRUCTURE_NAME = "GetText PO/POT";
/*     */   private static final String TIP_STRUCTURE_NAME = "Tip Properties";
/*     */   private static final String EXTERNAL_PO_STRUCTURE_NAME = "GetText_PO";
/*     */   private static final String EXTERNAL_TIP_STRUCTURE_NAME = "Tip_Properties";
/*  27 */   private static final PoLineProvider provider = new PoLineProvider();
/*  28 */   private static final TipLineProvider tipProvider = new TipLineProvider();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getNumberOfEntries()
/*     */   {
/*  36 */     return 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getManagerName()
/*     */   {
/*  44 */     return "Po Line Provider";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getKey(int idx)
/*     */   {
/*  52 */     switch (idx) {
/*  53 */     case 0:  return 101;
/*  54 */     case 1:  return 102;
/*     */     }
/*     */     
/*     */     
/*     */ 
/*  59 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getName(int idx)
/*     */   {
/*  67 */     switch (idx) {
/*  68 */     case 0:  return "GetText PO/POT";
/*  69 */     case 1:  return "Tip Properties";
/*     */     }
/*  71 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractLineReader getLineReader(int fileStructure, LineProvider lineProvider)
/*     */   {
/*  80 */     switch (fileStructure) {
/*  81 */     case 101:  return new PoMessageLineReader();
/*  82 */     case 102:  return new PropertiesLineReader("tip");
/*     */     }
/*  84 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractLineReader getLineReader(int fileStructure)
/*     */   {
/*  93 */     return getLineReader(fileStructure, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractLineWriter getLineWriter(int fileStructure)
/*     */   {
/* 101 */     return getLineWriter(fileStructure, null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractLineWriter getLineWriter(int fileStructure, String charset)
/*     */   {
/* 109 */     switch (fileStructure) {
/* 110 */     case 102:  return new PropertiesLineWriter("tip");
/* 111 */     case 101:  return new PoMessageLineWriter();
/*     */     }
/* 113 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCopyBookFileRequired(int fileStructure)
/*     */   {
/* 121 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getStructureName(int fileStructure)
/*     */   {
/* 129 */     switch (fileStructure) {
/* 130 */     case 101:  return "GetText_PO";
/* 131 */     case 102:  return "Tip_Properties";
/*     */     }
/* 133 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getStructureNameForIndex(int index)
/*     */   {
/* 141 */     return "GetText_PO";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LineProvider getLineProvider(int fileStructure, String charset)
/*     */   {
/* 150 */     switch (fileStructure) {
/* 151 */     case 101:  return provider;
/* 152 */     case 102:  return tipProvider;
/*     */     }
/* 154 */     return null;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/po/PoLineIOProvider.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */