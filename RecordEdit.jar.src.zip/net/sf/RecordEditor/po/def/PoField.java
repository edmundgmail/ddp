/*    */ package net.sf.RecordEditor.po.def;
/*    */ 
/*    */ import net.sf.JRecord.Details.RecordDetail;
/*    */ import net.sf.RecordEditor.edit.display.extension.FieldDef;
/*    */ 
/*    */ public class PoField extends FieldDef
/*    */ {
/*    */   public static final String FUZZY = "fuzzy";
/*  9 */   public static final PoField msgctxt = new PoField("msgctxt");
/* 10 */   public static final PoField msgid = new PoField("msgid");
/* 11 */   public static final PoField msgidPlural = new PoField("msgid_plural ", "msgidPlural");
/* 12 */   public static final PoField msgstr = new PoField("msgstr");
/* 13 */   public static final PoField msgstrPlural = new PoField("msgstr", "msgstrPlural", true, true, false, true, true);
/* 14 */   public static final PoField comments = new PoField("# ", "comments", false, false, false, false, false);
/* 15 */   public static final PoField extractedComments = new PoField("#. ", "extractedComments", false, false, false, false, false);
/* 16 */   public static final PoField reference = new PoField("#: ", "reference", false, false, false, false, false);
/* 17 */   public static final PoField flags = new PoField("#, ", "flags", false, false, false, false, false);
/* 18 */   public static final PoField previousMsgctx = new PoField("#| msgctxt ", "previousMsgctx");
/* 19 */   public static final PoField previousMsgId = new PoField("#| msgid", "previousMsgId");
/* 20 */   public static final PoField previousMsgidPlural = new PoField("#| msgid", "previousMsgidPlural", true, false, true, true, true);
/*    */   
/* 22 */   public static final PoField fuzzy = new PoField("fuzzy");
/* 23 */   public static final PoField obsolete = new PoField("obsolete");
/*    */   
/* 25 */   public static final int MSGSTR_PLURAL_INDEX = ((RecordDetail)PoLayoutMgr.PO_LAYOUT.getRecord(0)).getFieldCount();
/*    */   
/* 27 */   static final PoField[] allFields = { msgctxt, msgid, msgidPlural, msgstrPlural, msgstr, comments, extractedComments, reference, flags, previousMsgctx, previousMsgId, previousMsgidPlural };
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public PoField(String name)
/*    */   {
/* 43 */     this(name + " ", PoLayoutMgr.getIndexOf(name), false, false, true, false, true);
/*    */   }
/*    */   
/*    */   public PoField(String name, boolean stripQuote) {
/* 47 */     this(name + " ", PoLayoutMgr.getIndexOf(name), false, false, true, false, stripQuote);
/*    */   }
/*    */   
/*    */   public PoField(String name, String fieldName) {
/* 51 */     this(name, PoLayoutMgr.getIndexOf(fieldName), false, false, true, false, true);
/*    */   }
/*    */   
/*    */   public PoField(String name, String fieldName, boolean multLine, boolean repeating, boolean single, boolean couldHaveIndex, boolean stripQuote)
/*    */   {
/* 56 */     this(name, PoLayoutMgr.getIndexOf(fieldName), multLine, repeating, single, couldHaveIndex, stripQuote);
/*    */   }
/*    */   
/*    */   public PoField(String name, int idx, boolean multLine, boolean repeating, boolean single, boolean couldHaveIndex, boolean stripQuote)
/*    */   {
/* 61 */     super(name, idx, multLine, repeating, single, couldHaveIndex, stripQuote);
/*    */   }
/*    */   
/*    */ 
/*    */   public static PoField[] getAllfields()
/*    */   {
/* 67 */     return (PoField[])allFields.clone();
/*    */   }
/*    */   
/*    */   public boolean isMatch(String s)
/*    */   {
/* 72 */     boolean ret = super.isMatch(s);
/* 73 */     if ((s.startsWith(this.name)) && (this.repeating)) {
/* 74 */       ret = s.substring(this.name.length()).trim().startsWith("[");
/*    */     }
/*    */     
/* 77 */     return ret;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/po/def/PoField.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */