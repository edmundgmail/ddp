/*    */ package net.sf.RecordEditor.po.def;
/*    */ 
/*    */ import net.sf.JRecord.Common.IFieldDetail;
/*    */ import net.sf.JRecord.Details.ArrayListLine;
/*    */ import net.sf.JRecord.Details.LayoutDetail;
/*    */ import net.sf.JRecord.Details.RecordDetail;
/*    */ import net.sf.RecordEditor.po.display.MsgstrArray;
/*    */ 
/*    */ public final class PoLine extends ArrayListLine<net.sf.JRecord.Common.FieldDetail, RecordDetail, LayoutDetail>
/*    */ {
/*    */   public PoLine()
/*    */   {
/* 13 */     super(PoLayoutMgr.PO_LAYOUT, 0, 1);
/*    */   }
/*    */   
/*    */   public PoLine(LayoutDetail l) {
/* 17 */     super(l, 0, 1);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Object getField(int recordIdx, int fieldIdx)
/*    */   {
/* 37 */     if ((recordIdx == 0) && (fieldIdx == PoField.MSGSTR_PLURAL_INDEX)) {
/* 38 */       return super.getFieldRaw(recordIdx, PoField.msgstrPlural.fieldIdx);
/*    */     }
/*    */     
/* 41 */     Object o = super.getFieldRaw(recordIdx, fieldIdx);
/*    */     
/* 43 */     if ((recordIdx == 0) && (fieldIdx == PoField.msgstrPlural.fieldIdx)) {
/* 44 */       return new MsgstrArray(this, fieldIdx);
/*    */     }
/* 46 */     return o;
/*    */   }
/*    */   
/*    */   public Object getRawField(int recordIdx, int fieldIdx) {
/* 50 */     return super.getFieldRaw(recordIdx, fieldIdx);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Object getField(IFieldDetail field)
/*    */   {
/* 58 */     if (field == null) return null;
/* 59 */     return getField(this.preferredLayout, field.getPos() - 1);
/*    */   }
/*    */   
/*    */   public final Object getMsgstrPlural()
/*    */   {
/* 64 */     return super.getFieldRaw(0, PoField.msgstrPlural.fieldIdx);
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/po/def/PoLine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */