/*    */ package net.sf.RecordEditor.po.def;
/*    */ 
/*    */ import net.sf.JRecord.Details.LayoutDetail;
/*    */ import net.sf.JRecord.Details.RecordDetail;
/*    */ import net.sf.JRecord.External.ExternalRecord;
/*    */ import net.sf.JRecord.External.RecordEditorXmlLoader;
/*    */ 
/*    */ 
/*    */ public class PoLayoutMgr
/*    */ {
/* 11 */   public static final LayoutDetail PO_LAYOUT = ;
/* 12 */   private static ExternalRecord poLayout = null;
/*    */   
/*    */   public static LayoutDetail getPoLayout()
/*    */   {
/* 16 */     LayoutDetail t = null;
/*    */     
/*    */     try
/*    */     {
/* 20 */       if (poLayout == null) {
/* 21 */         poLayout = RecordEditorXmlLoader.getExternalRecord("<?xml version=\"1.0\" ?><RECORD RECORDNAME=\"GetText_PO\" COPYBOOK=\"\" DELIMITER=\"&lt;Tab&gt;\" FILESTRUCTURE=\"101\" STYLE=\"0\" RECORDTYPE=\"Delimited\" LIST=\"Y\" QUOTE=\"\" RecSep=\"default\" LINE_NO_FIELD_NAMES=\"1\">\t<FIELDS>\t\t<FIELD NAME=\"msgctxt\" POSITION=\"1\" TYPE=\"118\"/>\t\t<FIELD NAME=\"msgid\" POSITION=\"2\" TYPE=\"118\"/>\t\t<FIELD NAME=\"msgstr\" POSITION=\"3\" TYPE=\"118\"/>\t\t<FIELD NAME=\"comments\" POSITION=\"4\" TYPE=\"118\"/>\t\t<FIELD NAME=\"msgidPlural\" POSITION=\"5\" TYPE=\"118\"/>\t\t<FIELD NAME=\"msgstrPlural\" POSITION=\"6\" TYPE=\"92\"/>\t\t<FIELD NAME=\"extractedComments\" POSITION=\"7\" TYPE=\"118\"/>\t\t<FIELD NAME=\"reference\" POSITION=\"8\" TYPE=\"118\"/>\t\t<FIELD NAME=\"flags\" POSITION=\"9\" TYPE=\"118\"/>\t\t<FIELD NAME=\"previousMsgctx\" POSITION=\"10\" TYPE=\"118\"/>\t\t<FIELD NAME=\"previousMsgId\" POSITION=\"11\" TYPE=\"118\"/>\t\t<FIELD NAME=\"previousMsgidPlural\" POSITION=\"12\" TYPE=\"118\"/>\t\t<FIELD NAME=\"fuzzy\" POSITION=\"13\" TYPE=\"109\"/>\t\t<FIELD NAME=\"obsolete\" POSITION=\"14\" TYPE=\"109\"/>\t</FIELDS></RECORD>", "PO Layout");
/*    */       }
/* 23 */       t = poLayout.asLayoutDetail();
/*    */     }
/*    */     catch (Exception e) {
/* 26 */       e.printStackTrace();
/*    */     }
/*    */     
/* 29 */     return t;
/*    */   }
/*    */   
/*    */   public static int getIndexOf(String name) {
/* 33 */     int ret = -1;
/* 34 */     if (PO_LAYOUT != null) {
/* 35 */       ret = ((RecordDetail)PO_LAYOUT.getRecord(0)).getFieldIndex(name);
/*    */     }
/*    */     
/* 38 */     return ret;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/po/def/PoLayoutMgr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */