/*    */ package net.sf.RecordEditor.layoutWizard;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ 
/*    */ 
/*    */ public class RecordDefinition
/*    */ {
/*  8 */   public boolean searchForFields = true;
/*  9 */   public boolean displayedFieldSelection = false;
/* 10 */   public boolean displayedFieldNames = false;
/*    */   public Object[] keyValue;
/*    */   public Object[] keyValueHold;
/* 13 */   public Boolean defaultRec = Boolean.FALSE; public Boolean include = Boolean.TRUE;
/*    */   
/* 15 */   public String name = "";
/* 16 */   public int numRecords = 0;
/* 17 */   public byte[][] records = new byte[60][];
/* 18 */   public ArrayList<ColumnDetails> columnDtls = new ArrayList();
/*    */   
/*    */ 
/*    */ 
/*    */   public final void addKeyField(Details detail, boolean addRest)
/*    */   {
/* 24 */     for (int i = 0; i < detail.keyFields.size(); i++) {
/* 25 */       if ((this.keyValue == null) || (this.defaultRec.booleanValue()) || ((i < this.keyValue.length) && (this.keyValue[i] != null)))
/*    */       {
/*    */ 
/* 28 */         KeyField k = (KeyField)detail.keyFields.get(i);
/* 29 */         ColumnDetails colDtls = new ColumnDetails(k.keyStart, k.keyType.intValue());
/* 30 */         colDtls.name = k.keyName;
/* 31 */         colDtls.length = k.keyLength;
/*    */         
/* 33 */         this.columnDtls.add(colDtls);
/*    */       }
/*    */     }
/*    */     
/* 37 */     if (addRest) {
/* 38 */       KeyField k = (KeyField)detail.keyFields.get(detail.keyFields.size() - 1);
/* 39 */       this.columnDtls.add(new ColumnDetails(k.keyStart + k.keyLength, detail.defaultType.intValue()));
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Object[] getKeyValue()
/*    */   {
/* 50 */     return this.keyValue;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setKeyValue(Object[] keyValue)
/*    */   {
/* 57 */     this.keyValue = keyValue;
/* 58 */     this.keyValueHold = ((Object[])keyValue.clone());
/*    */   }
/*    */   
/*    */   public String getStringKey()
/*    */   {
/* 63 */     return getStringKey(this.keyValue, "~");
/*    */   }
/*    */   
/*    */   public String getStringKey(String sep)
/*    */   {
/* 68 */     return getStringKey(this.keyValue, sep);
/*    */   }
/*    */   
/*    */   public static String getStringKey(Object[] keys)
/*    */   {
/* 73 */     return getStringKey(keys, "~");
/*    */   }
/*    */   
/*    */   public static String getStringKey(Object[] keys, String seperator)
/*    */   {
/* 78 */     StringBuilder sb = new StringBuilder();
/* 79 */     String sep = "";
/*    */     
/* 81 */     for (int i = 0; i < keys.length; i++) {
/* 82 */       if (keys[i] != null) {
/* 83 */         sb.append(sep);
/* 84 */         sb.append(keys[i]);
/* 85 */         sep = seperator;
/*    */       }
/*    */     }
/* 88 */     return sb.toString();
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/layoutWizard/RecordDefinition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */