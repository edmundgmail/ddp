/*    */ package net.sf.RecordEditor.layoutWizard;
/*    */ 
/*    */ import javax.swing.JTextArea;
/*    */ import javax.swing.JTextField;
/*    */ import net.sf.JRecord.External.CopybookWriterManager;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ import net.sf.RecordEditor.utils.edit.ManagerRowList;
/*    */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*    */ import net.sf.RecordEditor.utils.swing.BmKeyedComboBox;
/*    */ import net.sf.RecordEditor.utils.swing.treeCombo.FileSelectCombo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Pnl5SaveFileLayout
/*    */   extends WizardPanel
/*    */ {
/*    */   private Details wizardDetails;
/* 25 */   private FileSelectCombo saveDirectoryFC = new FileSelectCombo("SchemaDirs.", 15, false, true);
/*    */   
/* 27 */   private BmKeyedComboBox outputFormatCombo = new BmKeyedComboBox(new ManagerRowList(CopybookWriterManager.getInstance(), false), false);
/*    */   
/*    */ 
/* 30 */   private JTextField layoutName = new JTextField();
/* 31 */   private JTextArea layoutDescription = new JTextArea();
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Pnl5SaveFileLayout()
/*    */   {
/* 42 */     setGapRE(BasePanel.GAP2);
/*    */     
/* 44 */     addLineRE("Layout Name", this.layoutName);
/* 45 */     addLineRE("Layout Description", this.layoutDescription);
/* 46 */     setHeightRE(BasePanel.GAP3);
/* 47 */     setGapRE(BasePanel.GAP1);
/* 48 */     addLineRE("Record Layout Directory", this.saveDirectoryFC);
/* 49 */     setGapRE(BasePanel.GAP1);
/* 50 */     addLineRE("Output Format", this.outputFormatCombo);
/* 51 */     setGapRE(BasePanel.GAP3);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Details getValues()
/*    */     throws Exception
/*    */   {
/* 59 */     this.wizardDetails.layoutName = this.layoutName.getText();
/* 60 */     this.wizardDetails.layoutDescription = this.layoutDescription.getText();
/* 61 */     this.wizardDetails.layoutDirectory = this.saveDirectoryFC.getText();
/* 62 */     this.wizardDetails.layoutWriterIdx = this.outputFormatCombo.getSelectedIndex();
/*    */     
/* 64 */     if ("".equals(this.wizardDetails.layoutName)) {
/* 65 */       this.layoutName.requestFocus();
/* 66 */       throw new Exception("You must enter a layout name");
/*    */     }
/*    */     
/* 69 */     return this.wizardDetails;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setValues(Details detail)
/*    */     throws Exception
/*    */   {
/* 78 */     this.wizardDetails = detail;
/*    */     
/* 80 */     this.layoutName.setText(detail.layoutName);
/* 81 */     this.layoutDescription.setText(detail.layoutDescription);
/* 82 */     this.saveDirectoryFC.setText(detail.layoutDirectory);
/*    */     
/* 84 */     if (detail.layoutWriterIdx < 0) {
/* 85 */       detail.layoutWriterIdx = Common.getCopybookWriterIndex();
/*    */     }
/* 87 */     this.outputFormatCombo.setSelectedIndex(detail.layoutWriterIdx);
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/layoutWizard/Pnl5SaveFileLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */