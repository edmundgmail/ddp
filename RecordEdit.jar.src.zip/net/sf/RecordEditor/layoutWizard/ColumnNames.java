/*     */ package net.sf.RecordEditor.layoutWizard;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.DefaultCellEditor;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.table.AbstractTableModel;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import net.sf.JRecord.Common.Conversion;
/*     */ import net.sf.JRecord.Common.FieldDetail;
/*     */ import net.sf.JRecord.Types.Type;
/*     */ import net.sf.JRecord.Types.TypeManager;
/*     */ import net.sf.RecordEditor.re.util.BuildTypeComboList;
/*     */ import net.sf.RecordEditor.utils.MenuPopupListener;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.ReAbstractAction;
/*     */ import net.sf.RecordEditor.utils.swing.AbsRowList;
/*     */ import net.sf.RecordEditor.utils.swing.CheckBoxTableRender;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.TreeComboItem;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.TreeComboRendor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ColumnNames
/*     */ {
/*  52 */   private static final int NAME_WIDTH = SwingUtils.STANDARD_FONT_WIDTH * 19;
/*  53 */   private static final int INT_TABLE_WIDTH = SwingUtils.STANDARD_FONT_WIDTH * 13 / 2;
/*  54 */   private static final int INCLUDE_WIDTH = SwingUtils.STANDARD_FONT_WIDTH * 3 + 3;
/*  55 */   private static final int TYPE_WIDTH = SwingUtils.STANDARD_FONT_WIDTH * 18;
/*     */   
/*     */   private ColumnTblModel columnMdl;
/*     */   
/*     */   private FileTblModel fileMdl;
/*  60 */   public final JTable columnTbl = new JTable();
/*  61 */   public final JTable fileTbl = new JTable();
/*     */   
/*     */ 
/*     */   private TreeComboRendor typeRendor;
/*     */   
/*     */ 
/*     */   private TreeComboRendor typeEditor;
/*     */   
/*     */   private Details currentDetails;
/*     */   
/*     */   private RecordDefinition recordDefinition;
/*     */   
/*     */ 
/*     */   public ColumnNames(AbsRowList typeList)
/*     */   {
/*  76 */     TreeComboItem[] typeCombolist = BuildTypeComboList.getList(typeList);
/*     */     
/*  78 */     this.columnTbl.setRowHeight(SwingUtils.COMBO_TABLE_ROW_HEIGHT);
/*  79 */     this.columnTbl.setAutoResizeMode(0);
/*  80 */     this.fileTbl.setAutoResizeMode(0);
/*     */     
/*  82 */     this.typeRendor = BuildTypeComboList.getTreeComboRender(typeCombolist);
/*  83 */     this.typeEditor = BuildTypeComboList.getTreeComboRender(typeCombolist);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  91 */     this.columnTbl.addMouseListener(new MenuPopupListener(new ReAbstractAction("Generate Field Names") {
/*     */       public void actionPerformed(ActionEvent e) {
/*  93 */         ColumnNames.this.nameColumns();
/*     */       }
/*     */     }));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Details getValues()
/*     */     throws Exception
/*     */   {
/* 104 */     Common.stopCellEditing(this.columnTbl);
/*     */     
/* 106 */     return this.currentDetails;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setValues(Details detail, RecordDefinition recordDef)
/*     */     throws Exception
/*     */   {
/* 114 */     this.currentDetails = detail;
/* 115 */     this.recordDefinition = recordDef;
/*     */     
/* 117 */     if ((this.recordDefinition.columnDtls.size() == 0) || (((ColumnDetails)this.recordDefinition.columnDtls.get(0)).start != 1))
/*     */     {
/* 119 */       this.recordDefinition.columnDtls.add(0, new ColumnDetails(1, detail.defaultType.intValue()));
/*     */     }
/*     */     
/* 122 */     setValues_100_SetupColumns();
/* 123 */     setValues_200_SetupColumnTable();
/* 124 */     setValues_300_SetupFileTable();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setValues_100_SetupColumns()
/*     */   {
/* 137 */     int colEnd = 0;
/* 138 */     for (int i = 0; i < this.recordDefinition.numRecords; i++) {
/* 139 */       if (colEnd < this.recordDefinition.records[i].length) {
/* 140 */         colEnd = this.recordDefinition.records[i].length;
/*     */       }
/*     */     }
/*     */     
/* 144 */     for (i = this.recordDefinition.columnDtls.size() - 1; i >= 0; i--) {
/* 145 */       ColumnDetails colDtls = (ColumnDetails)this.recordDefinition.columnDtls.get(i);
/* 146 */       colDtls.length = (colEnd - colDtls.start + 1);
/* 147 */       colEnd = colDtls.start - 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setValues_200_SetupColumnTable()
/*     */   {
/* 159 */     this.columnMdl = new ColumnTblModel(this.recordDefinition.columnDtls);
/* 160 */     this.columnTbl.setModel(this.columnMdl);
/*     */     
/* 162 */     TableColumnModel tcm = this.columnTbl.getColumnModel();
/*     */     
/* 164 */     tcm.getColumn(0).setPreferredWidth(NAME_WIDTH);
/* 165 */     tcm.getColumn(1).setPreferredWidth(INT_TABLE_WIDTH);
/* 166 */     tcm.getColumn(2).setPreferredWidth(INT_TABLE_WIDTH);
/* 167 */     tcm.getColumn(4).setPreferredWidth(INT_TABLE_WIDTH);
/*     */     
/* 169 */     TableColumn tc = tcm.getColumn(3);
/* 170 */     tc.setPreferredWidth(TYPE_WIDTH);
/* 171 */     tc.setCellRenderer(this.typeRendor);
/* 172 */     tc.setCellEditor(this.typeEditor);
/*     */     
/* 174 */     tc = tcm.getColumn(5);
/* 175 */     tc.setPreferredWidth(INCLUDE_WIDTH);
/* 176 */     tc.setCellRenderer(new CheckBoxTableRender());
/* 177 */     tc.setCellEditor(new DefaultCellEditor(new JCheckBox()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setValues_300_SetupFileTable()
/*     */   {
/* 190 */     this.fileMdl = new FileTblModel(this.recordDefinition.records, this.currentDetails.fontName, this.recordDefinition.columnDtls);
/*     */     
/*     */ 
/* 193 */     this.fileTbl.setModel(this.fileMdl);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 201 */     this.fileMdl.fireTableDataChanged();
/*     */   }
/*     */   
/*     */   private void nameColumns()
/*     */   {
/* 206 */     String s = "n";
/* 207 */     int i = 0;
/*     */     String t;
/* 209 */     if ((this.recordDefinition.getKeyValue() != null) && (this.recordDefinition.getKeyValue().length > 0) && (!"".equals(t = this.recordDefinition.getStringKey(""))))
/*     */     {
/*     */ 
/* 212 */       s = t;
/*     */     }
/*     */     
/* 215 */     for (ColumnDetails column : this.recordDefinition.columnDtls) {
/* 216 */       if ((column.name == null) || ("".equals(column.name.trim()))) {
/* 217 */         column.name = (s + i);
/*     */       }
/* 219 */       i++;
/*     */     }
/*     */     
/* 222 */     this.columnMdl.fireTableDataChanged();
/* 223 */     this.fileMdl.fireTableStructureChanged();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private class ColumnTblModel
/*     */     extends AbstractTableModel
/*     */   {
/*     */     private ArrayList<ColumnDetails> columns;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public ColumnTblModel()
/*     */     {
/* 246 */       this.columns = tblColumns;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public int getColumnCount()
/*     */     {
/* 253 */       return 6;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public int getRowCount()
/*     */     {
/* 260 */       return this.columns.size();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Object getValueAt(int rowIndex, int columnIndex)
/*     */     {
/* 267 */       ColumnDetails colDtls = (ColumnDetails)this.columns.get(rowIndex);
/*     */       
/* 269 */       return colDtls.getValue(columnIndex);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public String getColumnName(int column)
/*     */     {
/* 276 */       return ColumnDetails.getColumnName(column);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isCellEditable(int rowIndex, int columnIndex)
/*     */     {
/* 284 */       return (columnIndex != 1) && (columnIndex != 2);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setValueAt(Object aValue, int rowIndex, int columnIndex)
/*     */     {
/* 293 */       ColumnDetails colDtls = (ColumnDetails)this.columns.get(rowIndex);
/*     */       try
/*     */       {
/* 296 */         colDtls.setValue(columnIndex, aValue);
/* 297 */         if ((columnIndex == 0) || (columnIndex == 3) || (columnIndex == 4))
/*     */         {
/*     */ 
/* 300 */           ColumnNames.this.fileMdl.fireTableStructureChanged();
/*     */         }
/*     */       } catch (Exception e) {
/* 303 */         Common.logMsgRaw(e.getMessage(), null);
/* 304 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private class FileTblModel
/*     */     extends AbstractTableModel
/*     */   {
/*     */     private byte[][] lines;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     private String font;
/*     */     
/*     */ 
/*     */ 
/*     */     private ArrayList<ColumnDetails> columns;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public FileTblModel(String lines2show, ArrayList<ColumnDetails> fontname)
/*     */     {
/* 332 */       this.lines = lines2show;
/* 333 */       this.font = fontname;
/* 334 */       this.columns = tblColumns;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public int getColumnCount()
/*     */     {
/* 341 */       return this.columns.size();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public int getRowCount()
/*     */     {
/* 348 */       return ColumnNames.this.recordDefinition.numRecords;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public Object getValueAt(int rowIndex, int columnIndex)
/*     */     {
/* 355 */       ColumnDetails colDtls = (ColumnDetails)this.columns.get(columnIndex);
/* 356 */       int colStart = colDtls.start - 1;
/* 357 */       int colEnd = colDtls.start + colDtls.length - 1;
/*     */       
/* 359 */       if (this.lines[rowIndex].length < colStart) {
/* 360 */         return "";
/*     */       }
/* 362 */       switch (colDtls.type) {
/*     */       case 0: 
/*     */       case 1: 
/*     */       case 3: 
/*     */       case 111: 
/*     */       case 112: 
/* 368 */         return getStandardField(rowIndex, colStart, colEnd);
/*     */       }
/*     */       
/* 371 */       FieldDetail fldDef = new FieldDetail("", "", colDtls.type, colDtls.decimal, ColumnNames.this.currentDetails.fontName, 0, "");
/*     */       
/* 373 */       fldDef.setPosLen(colDtls.start, colDtls.length);
/*     */       try
/*     */       {
/* 376 */         return TypeManager.getInstance().getType(colDtls.type).getField(this.lines[rowIndex], colDtls.start, fldDef);
/*     */       }
/*     */       catch (Exception e) {}
/* 379 */       return getStandardField(rowIndex, colStart, colEnd);
/*     */     }
/*     */     
/*     */     private String getStandardField(int rowIndex, int colStart, int colEnd)
/*     */     {
/* 384 */       if (this.lines[rowIndex].length < colEnd) {
/* 385 */         return Conversion.getString(this.lines[rowIndex], colStart, this.lines[rowIndex].length, this.font);
/*     */       }
/*     */       
/* 388 */       return Conversion.getString(this.lines[rowIndex], colStart, colEnd, this.font);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getColumnName(int column)
/*     */     {
/* 397 */       ColumnDetails colDtls = (ColumnDetails)this.columns.get(column);
/*     */       
/* 399 */       if ("".equals(colDtls.name)) {
/* 400 */         return super.getColumnName(column);
/*     */       }
/* 402 */       return colDtls.name;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/layoutWizard/ColumnNames.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */