/*     */ package net.sf.RecordEditor.layoutWizard;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import net.sf.JRecord.Common.RecordException;
/*     */ import net.sf.JRecord.Details.LayoutDetail;
/*     */ import net.sf.JRecord.Details.RecordDetail;
/*     */ import net.sf.JRecord.Details.RecordDetail.FieldDetails;
/*     */ import net.sf.JRecord.External.Def.ExternalField;
/*     */ import net.sf.JRecord.External.ExternalRecord;
/*     */ import net.sf.JRecord.IO.AbstractLineReader;
/*     */ import net.sf.JRecord.IO.LineIOProvider;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Details
/*     */ {
/*     */   public static final int RT_FIXED_LENGTH_FIELDS = 0;
/*     */   public static final int RT_DELIMITERED_FIELDS = 1;
/*     */   public static final int RT_MULTIPLE_RECORDS = 2;
/*  41 */   public String filename = "";
/*  42 */   public int fileStructure = 0;
/*  43 */   public int recordType = 0;
/*  44 */   public int system = 0;
/*  45 */   public int recordLength = 0;
/*  46 */   public String layoutName = "Wizard_";
/*  47 */   public String layoutDescription = "";
/*  48 */   public String fontName = "";
/*  49 */   public Integer defaultType = KeyField.CHAR_TYPE;
/*  50 */   public String fieldSeperator = "";
/*  51 */   public String actualSeperator = "";
/*  52 */   public String quote = "";
/*  53 */   public String actualQuote = "";
/*  54 */   public int parserType = 0;
/*  55 */   public boolean fieldNamesOnLine = false;
/*  56 */   public boolean unicode = false;
/*  57 */   public boolean generateFieldNames = false;
/*  58 */   public boolean editFile = true;
/*     */   
/*  60 */   public String layoutDirectory = "";
/*  61 */   public int layoutWriterIdx = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  68 */   public RecordDefinition standardRecord = new RecordDefinition();
/*     */   
/*  70 */   public ArrayList<RecordDefinition> recordDtls = new ArrayList();
/*  71 */   public ArrayList<RecordDefinition> recordDtlsFull = new ArrayList();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  76 */   public int textPct = 100;
/*     */   
/*     */ 
/*  79 */   public ArrayList<KeyField> keyFields = new ArrayList();
/*     */   
/*     */   public Details() {
/*  82 */     KeyField k = new KeyField();
/*  83 */     k.keyName = "Record_Type";
/*  84 */     this.keyFields.add(k);
/*     */   }
/*     */   
/*     */   public KeyField getMainKey() {
/*  88 */     if (this.keyFields.size() == 0) {
/*  89 */       this.keyFields.add(new KeyField("Record_Type", 0, 0, this.defaultType));
/*     */     }
/*  91 */     return (KeyField)this.keyFields.get(0);
/*     */   }
/*     */   
/*     */   public final ExternalRecord createRecordLayout()
/*     */   {
/*     */     ExternalRecord rec;
/*  97 */     switch (this.recordType) {
/*     */     case 0: 
/*  99 */       rec = new ExternalRecord(-1, this.layoutName, this.layoutDescription, 1, this.system, "Y", "", "<Tab>", "", 0, "default", Common.CRLF_BYTES, this.fontName, this.parserType, this.fileStructure, false);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 107 */       nameFields(rec, this.standardRecord);
/* 108 */       addFields(rec, this.standardRecord);
/* 109 */       break;
/*     */     
/*     */ 
/*     */     case 2: 
/* 113 */       rec = new ExternalRecord(-1, this.layoutName, this.layoutDescription, 9, this.system, "Y", "", "<Tab>", "", 0, "default", Common.CRLF_BYTES, this.fontName, this.parserType, this.fileStructure, false);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 122 */       for (RecordDefinition child : this.recordDtls) {
/* 123 */         if (child.include.booleanValue()) {
/* 124 */           ExternalRecord childRecord = new ExternalRecord(-1, child.name, "", 1, this.system, "N", "", "<Tab>", "", 0, "default", Common.CRLF_BYTES, this.fontName, this.parserType, this.fileStructure, false);
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 133 */           nameFields(childRecord, child);
/* 134 */           childRecord.setDefaultRecord(child.defaultRec.booleanValue());
/* 135 */           System.out.println("Record: " + child.name + "\t" + childRecord.isDefaultRecord());
/* 136 */           for (int i = 0; i < this.keyFields.size(); i++) {
/* 137 */             if (child.getKeyValue()[i] != null) {
/* 138 */               String value = child.getKeyValue()[i].toString();
/* 139 */               childRecord.addTstField(((KeyField)this.keyFields.get(i)).keyName, value);
/*     */             }
/*     */           }
/* 142 */           addFields(childRecord, child);
/* 143 */           childRecord.setNew(true);
/*     */           
/* 145 */           rec.addRecord(childRecord);
/*     */         }
/*     */       }
/* 148 */       break;
/*     */     default: 
/* 150 */       String delim = this.fieldSeperator;
/*     */       
/* 152 */       if ("<Default>".equalsIgnoreCase(delim)) {
/* 153 */         delim = this.actualSeperator;
/*     */       }
/*     */       
/* 156 */       rec = new ExternalRecord(-1, this.layoutName, this.layoutDescription, 2, this.system, "Y", "", delim, this.actualQuote, 0, "default", Common.CRLF_BYTES, this.fontName, this.parserType, this.fileStructure, false);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 165 */       nameFields(rec, this.standardRecord);
/* 166 */       addFields(rec, this.standardRecord);
/*     */     }
/*     */     
/* 169 */     rec.setNew(true);
/* 170 */     return rec;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void addFields(ExternalRecord rec, RecordDefinition recordDef)
/*     */   {
/* 183 */     for (int i = 0; i < recordDef.columnDtls.size(); i++) {
/* 184 */       ColumnDetails column = (ColumnDetails)recordDef.columnDtls.get(i);
/*     */       
/* 186 */       if (column.include.booleanValue()) {
/* 187 */         ExternalField field = new ExternalField(column.start, column.length, column.name, "", column.type, column.decimal, 0, "", "", "", i);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 201 */         rec.addRecordField(field);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void nameFields(ExternalRecord rec, RecordDefinition recordDef)
/*     */   {
/* 209 */     for (int i = 0; i < recordDef.columnDtls.size(); i++) {
/* 210 */       ColumnDetails column = (ColumnDetails)recordDef.columnDtls.get(i);
/*     */       
/* 212 */       if ((column.name == null) || ("".equals(column.name))) {
/* 213 */         column.name = ("Field_" + i);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractLineReader<LayoutDetail> getReader()
/*     */     throws RecordException, IOException
/*     */   {
/* 228 */     AbstractLineReader<LayoutDetail> reader = LineIOProvider.getInstance().getLineReader(this.fileStructure);
/*     */     
/*     */ 
/*     */     RecordDetail[] recs;
/*     */     
/* 233 */     if (this.fileStructure == 2) {
/* 234 */       RecordDetail.FieldDetails[] field = new RecordDetail.FieldDetails[1];
/*     */       
/* 236 */       field[0] = new RecordDetail.FieldDetails("", "", 0, 0, "", 0, "");
/* 237 */       field[0].setPosLen(1, this.recordLength);
/* 238 */       RecordDetail[] recs = new RecordDetail[1];
/* 239 */       recs[0] = new RecordDetail("", "", "", 0, "", "", "", field, this.parserType, 0);
/*     */     }
/*     */     else
/*     */     {
/* 243 */       recs = new RecordDetail[0];
/*     */     }
/* 245 */     LayoutDetail emptyLayout = new LayoutDetail("", recs, "", this.fileStructure, null, "", this.fontName, null, this.fileStructure);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 251 */     reader.open(this.filename, emptyLayout);
/* 252 */     return reader;
/*     */   }
/*     */   
/*     */   public void setFieldSearch() {
/* 256 */     this.standardRecord.searchForFields = true;
/*     */     
/* 258 */     if (this.recordDtls != null) {
/* 259 */       for (int i = 0; i < this.recordDtls.size(); i++) {
/* 260 */         ((RecordDefinition)this.recordDtls.get(i)).searchForFields = true;
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/layoutWizard/Details.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */