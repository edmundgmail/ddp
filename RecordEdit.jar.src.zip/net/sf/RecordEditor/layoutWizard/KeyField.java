/*    */ package net.sf.RecordEditor.layoutWizard;
/*    */ 
/*    */ 
/*    */ public class KeyField
/*    */ {
/*  6 */   public static final Integer CHAR_TYPE = Integer.valueOf(0);
/*    */   
/*  8 */   public String keyName = "";
/*    */   public int keyStart;
/*    */   public int keyLength;
/*    */   public Integer keyType;
/*    */   
/*    */   public KeyField() {
/* 14 */     this("", 0, 0, CHAR_TYPE);
/*    */   }
/*    */   
/*    */   public KeyField(String name, int start, int length, Integer type) {
/* 18 */     this.keyName = name;
/* 19 */     this.keyStart = start;
/* 20 */     this.keyLength = length;
/* 21 */     this.keyType = type;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/layoutWizard/KeyField.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */