/*    */ package net.sf.RecordEditor.layoutWizard;
/*    */ 
/*    */ import javax.swing.JComponent;
/*    */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*    */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*    */ import net.sf.RecordEditor.utils.wizards.AbstractWizardPanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class WizardPanel
/*    */   extends BaseHelpPanel
/*    */   implements AbstractWizardPanel<Details>
/*    */ {
/* 27 */   public static final int TIP_HEIGHT = SwingUtils.STANDARD_FONT_HEIGHT * 10 + 5;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public JComponent getComponent()
/*    */   {
/* 35 */     return this;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean skip()
/*    */   {
/* 43 */     return false;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/layoutWizard/WizardPanel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */