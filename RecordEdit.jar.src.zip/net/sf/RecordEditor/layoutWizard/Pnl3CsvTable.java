/*    */ package net.sf.RecordEditor.layoutWizard;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import javax.swing.JCheckBox;
/*    */ import net.sf.JRecord.ByteIO.ByteTextReader;
/*    */ import net.sf.RecordEditor.re.util.csv.CsvSelectionPanel;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ import net.sf.RecordEditor.utils.swing.BmKeyedComboBox;
/*    */ import net.sf.RecordEditor.utils.swing.ComboBoxs.DelimiterCombo;
/*    */ import net.sf.RecordEditor.utils.swing.ComboBoxs.QuoteCombo;
/*    */ 
/*    */ public class Pnl3CsvTable extends WizardPanel
/*    */ {
/* 14 */   private static final byte[][] oneBlankLine = { new byte[0] };
/* 15 */   private CsvSelectionPanel pnl = new CsvSelectionPanel(oneBlankLine, "", false, null);
/*    */   
/*    */   private Details wizardDetail;
/*    */   
/*    */ 
/*    */   public Pnl3CsvTable()
/*    */   {
/* 22 */     setHelpURLre(Common.formatHelpURL("HlpLe04.htm#HDRWIZ4"));
/*    */     
/* 24 */     addComponentRE(0, 4, -2.0D, 0.0D, 2, 2, this.pnl);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public final Details getValues()
/*    */     throws Exception
/*    */   {
/* 35 */     this.wizardDetail.fieldSeperator = this.pnl.fieldSeparatorCombo.getSelectedItem().toString();
/* 36 */     this.wizardDetail.actualSeperator = this.pnl.getSeperator();
/* 37 */     this.wizardDetail.quote = this.pnl.quoteCombo.getSelectedItem().toString();
/* 38 */     this.wizardDetail.actualQuote = this.pnl.getQuote();
/* 39 */     this.wizardDetail.parserType = ((Integer)this.pnl.parseType.getSelectedItem()).intValue();
/* 40 */     this.wizardDetail.fieldNamesOnLine = this.pnl.fieldNamesOnLine.isSelected();
/* 41 */     if (this.wizardDetail.fieldNamesOnLine) {
/* 42 */       this.wizardDetail.fileStructure = 51;
/*    */     }
/*    */     
/* 45 */     this.wizardDetail.standardRecord.columnDtls = new ArrayList();
/* 46 */     int numCols = this.pnl.getColumnCount();
/*    */     
/*    */ 
/* 49 */     for (int i = 0; i < numCols; i++) {
/* 50 */       ColumnDetails colDtls = new ColumnDetails(i, this.wizardDetail.defaultType.intValue());
/* 51 */       colDtls.start = (i + 1);
/* 52 */       colDtls.length = 0;
/* 53 */       colDtls.decimal = 0;
/* 54 */       colDtls.include = Boolean.TRUE;
/* 55 */       colDtls.name = this.pnl.getColumnName(i);
/* 56 */       this.wizardDetail.standardRecord.columnDtls.add(i, colDtls);
/*    */     }
/* 58 */     return this.wizardDetail;
/*    */   }
/*    */   
/*    */   public final void setValues(Details detail)
/*    */     throws Exception
/*    */   {
/* 64 */     this.wizardDetail = detail;
/*    */     
/* 66 */     if (!"".equals(detail.fieldSeperator)) {
/* 67 */       this.pnl.fieldSeparatorCombo.setSelectedItem(detail.fieldSeperator);
/*    */     }
/* 69 */     if (!"".equals(detail.quote)) {
/* 70 */       this.pnl.quoteCombo.setSelectedItem(detail.quote);
/*    */     }
/* 72 */     this.pnl.parseType.setSelectedIndex(detail.parserType);
/* 73 */     this.pnl.fieldNamesOnLine.setSelected(detail.fieldNamesOnLine);
/*    */     
/* 75 */     setValues_100_ReadFile(detail);
/*    */   }
/*    */   
/*    */   private void setValues_100_ReadFile(Details detail) throws Exception
/*    */   {
/* 80 */     ByteTextReader r = new ByteTextReader();
/*    */     
/*    */ 
/* 83 */     int i = 0;
/*    */     
/* 85 */     r.open(detail.filename);
/* 86 */     byte[] line; while ((i < detail.standardRecord.records.length) && ((line = r.read()) != null)) {
/* 87 */       detail.standardRecord.records[(i++)] = line;
/*    */     }
/* 89 */     this.pnl.setLines(detail.standardRecord.records, detail.fontName, i);
/* 90 */     detail.standardRecord.numRecords = i;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/layoutWizard/Pnl3CsvTable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */