/*     */ package net.sf.RecordEditor.layoutWizard;
/*     */ 
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.DefaultCellEditor;
/*     */ import javax.swing.JEditorPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.table.AbstractTableModel;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import javax.swing.text.JTextComponent;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.swing.AbsRowList;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.BmKeyedComboBox;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Pnl3RecordTypeMF
/*     */   extends WizardPanel
/*     */ {
/*  48 */   private static final String[] FIELD_COL_NAMES = LangConversion.convertColHeading("LayoutWizard Record Selection Fields", new String[] { "Field Name", "Start", "Length", "Type" });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  53 */   private static final int FILE_HEIGHT = SwingUtils.TABLE_ROW_HEIGHT * 15 - 3;
/*     */   
/*     */   private JEditorPane tips;
/*     */   
/*  57 */   private FieldMdl keyFieldMdl = new FieldMdl(null);
/*  58 */   private JTable keyFieldTbl = new JTable(this.keyFieldMdl);
/*     */   
/*     */ 
/*     */   private Details dtl;
/*     */   
/*     */ 
/*     */   private ArrayList<KeyField> keys;
/*     */   
/*     */ 
/*     */   private ColumnSelector columnSelector;
/*     */   
/*     */ 
/*  70 */   private RecordDefinition recordDef = new RecordDefinition();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Pnl3RecordTypeMF(AbsRowList typeList, JTextComponent message)
/*     */   {
/*  94 */     this.columnSelector = new ColumnSelector(message);
/*     */     
/*  96 */     this.keyFieldTbl.getColumnModel().getColumn(3).setCellRenderer(new BmKeyedComboBox(typeList, false).getTableCellRenderer());
/*     */     
/*     */ 
/*  99 */     this.keyFieldTbl.getColumnModel().getColumn(3).setCellEditor(new DefaultCellEditor(new BmKeyedComboBox(typeList, false)));
/*     */     
/*     */ 
/* 102 */     this.keyFieldTbl.setRowHeight(SwingUtils.COMBO_TABLE_ROW_HEIGHT);
/*     */     
/* 104 */     String formDescription = LangConversion.convertId(2, "FileWizard_3mf", "This screen will display the first 60 lines of the file. <br>Indicate the <i>start</i> of the <b>Record-Type field</b> by clicking on the starting column<br>Then click on the start of the Next Field.<br>To remove a position click on it again.");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 110 */     this.tips = new JEditorPane("text/html", formDescription);
/*     */     
/* 112 */     setHelpURLre(Common.formatHelpURL("HlpLe04.htm#HDRWIZRECORDTYPE"));
/*     */     
/* 114 */     addComponentRE(1, 5, TIP_HEIGHT, BasePanel.GAP0, 2, 2, this.tips);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 122 */     addComponentRE(1, 5, SwingUtils.COMBO_TABLE_ROW_HEIGHT * 7, BasePanel.GAP0, 2, 2, this.keyFieldTbl);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 129 */     addLineRE("Show Hex", this.columnSelector.hexChk);
/* 130 */     setGapRE(BasePanel.GAP0);
/* 131 */     addComponentRE(1, 5, FILE_HEIGHT, BasePanel.GAP1, 2, 2, this.columnSelector.fileTbl);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 138 */     this.columnSelector.addMouseListner(new MouseAdapter() {
/*     */       public void mousePressed(MouseEvent m) {
/* 140 */         int col = Pnl3RecordTypeMF.this.columnSelector.fileTbl.columnAtPoint(m.getPoint());
/* 141 */         Pnl3RecordTypeMF.this.columnSelector.columnSelected(col);
/* 142 */         Pnl3RecordTypeMF.this.checkSelectedFieldOnTable();
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   private void checkSelectedFieldOnTable() {
/* 148 */     ArrayList<ColumnDetails> cd = this.recordDef.columnDtls;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 157 */     if (cd.size() > 0) {
/* 158 */       int start = 1;
/* 159 */       int cmp = cd.size() % 2;
/* 160 */       int fieldCount = 1;
/* 161 */       String name = "Record_Type";
/*     */       
/* 163 */       this.keys.clear();
/* 164 */       for (int i = 0; i < cd.size(); i++) {
/* 165 */         if (i % 2 == cmp) {
/* 166 */           start = ((ColumnDetails)cd.get(i)).start;
/*     */         } else {
/* 168 */           this.keys.add(new KeyField(name, start, ((ColumnDetails)cd.get(i)).start - start, this.dtl.defaultType));
/* 169 */           fieldCount++;
/* 170 */           name = "Record_Type_" + fieldCount;
/*     */         }
/*     */       }
/*     */       
/* 174 */       padKeys();
/* 175 */       this.keyFieldMdl.fireTableDataChanged();
/*     */     }
/*     */   }
/*     */   
/*     */   private void setSelectedFieldOnTable() {
/* 180 */     for (KeyField k : this.keys) {
/* 181 */       if (((k.keyStart > 0) || (k.keyLength > 0)) && ((k.keyStart <= 0) || (k.keyLength <= 0)))
/*     */       {
/*     */ 
/*     */ 
/* 185 */         return;
/*     */       }
/*     */     }
/*     */     try {
/* 189 */       if (this.keys.size() > 0) {
/* 190 */         int prev = 1;
/* 191 */         this.recordDef.columnDtls.clear();
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 198 */         for (KeyField k : this.keys) {
/* 199 */           if ((k.keyStart >= 1) && (k.keyLength >= 1)) {
/* 200 */             if (k.keyStart > prev) {
/* 201 */               this.recordDef.columnDtls.add(new ColumnDetails(k.keyStart, this.columnSelector.getCurrentDetails().defaultType.intValue()));
/*     */             }
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 211 */             prev = k.keyStart + k.keyLength;
/* 212 */             this.recordDef.columnDtls.add(new ColumnDetails(prev, k.keyType.intValue()));
/*     */           }
/*     */         }
/*     */         
/* 216 */         this.columnSelector.setColorIndicator();
/*     */       }
/*     */     }
/*     */     catch (Exception e) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Details getValues()
/*     */     throws Exception
/*     */   {
/* 228 */     Details ret = this.columnSelector.getCurrentDetails();
/*     */     
/* 230 */     for (int i = this.keys.size() - 1; i >= 0; i--) {
/* 231 */       if (((KeyField)this.keys.get(i)).keyStart < 0) {
/* 232 */         this.keys.remove(i);
/*     */       }
/*     */     }
/* 235 */     ret.keyFields = this.keys;
/*     */     
/* 237 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setValues(Details detail)
/*     */     throws Exception
/*     */   {
/* 257 */     this.columnSelector.readFile(detail, this.recordDef);
/* 258 */     this.columnSelector.setValues(detail, this.recordDef, false);
/*     */     
/* 260 */     this.dtl = detail;
/* 261 */     this.keys = detail.keyFields;
/* 262 */     padKeys();
/* 263 */     this.keyFieldMdl.fireTableDataChanged();
/*     */   }
/*     */   
/*     */ 
/*     */   private void padKeys()
/*     */   {
/* 269 */     for (int i = this.keys.size(); i < 5; i++) {
/* 270 */       this.keys.add(new KeyField("", -1, -1, this.dtl.defaultType));
/*     */     }
/*     */   }
/*     */   
/*     */   private class FieldMdl
/*     */     extends AbstractTableModel
/*     */   {
/*     */     private FieldMdl() {}
/*     */     
/*     */     public String getColumnName(int column)
/*     */     {
/* 281 */       return Pnl3RecordTypeMF.FIELD_COL_NAMES[column];
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isCellEditable(int rowIndex, int columnIndex)
/*     */     {
/* 289 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setValueAt(Object value, int rowIndex, int columnIndex)
/*     */     {
/* 297 */       KeyField k = (KeyField)Pnl3RecordTypeMF.this.keys.get(rowIndex);
/*     */       
/*     */       int t;
/* 300 */       switch (columnIndex) {
/*     */       case 0: 
/* 302 */         if (value == null) {
/* 303 */           k.keyName = "";
/*     */         } else {
/* 305 */           k.keyName = value.toString();
/*     */         }
/* 307 */         break;
/*     */       case 1: 
/* 309 */         t = k.keyStart;
/* 310 */         k.keyStart = toInt(value);
/* 311 */         if (t != k.keyStart) {
/* 312 */           Pnl3RecordTypeMF.this.setSelectedFieldOnTable();
/*     */         }
/*     */         break;
/*     */       case 2: 
/* 316 */         t = k.keyLength;
/* 317 */         k.keyLength = toInt(value);
/* 318 */         if (t != k.keyLength) {
/* 319 */           Pnl3RecordTypeMF.this.setSelectedFieldOnTable();
/*     */         }
/*     */         break;
/*     */       default: 
/* 323 */         if ((value != null) && ((value instanceof Integer)))
/* 324 */           k.keyType = ((Integer)value);
/*     */         break;
/*     */       }
/*     */     }
/*     */     
/*     */     private int toInt(Object o) {
/* 330 */       int ret = -1;
/* 331 */       if (o != null)
/*     */       {
/* 333 */         if ((o instanceof Number)) {
/* 334 */           ret = ((Number)o).intValue();
/*     */         } else {
/*     */           try {
/* 337 */             ret = Integer.parseInt(o.toString());
/*     */           }
/*     */           catch (Exception e) {}
/*     */         }
/*     */       }
/* 342 */       return ret;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getColumnCount()
/*     */     {
/* 350 */       return Pnl3RecordTypeMF.FIELD_COL_NAMES.length;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getRowCount()
/*     */     {
/* 358 */       return Pnl3RecordTypeMF.this.keys.size();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Object getValueAt(int rowIndex, int columnIndex)
/*     */     {
/* 366 */       KeyField k = (KeyField)Pnl3RecordTypeMF.this.keys.get(rowIndex);
/* 367 */       switch (columnIndex) {
/* 368 */       case 0:  return k.keyName;
/* 369 */       case 1:  return fixInt(k.keyStart);
/* 370 */       case 2:  return fixInt(k.keyLength); }
/* 371 */       return k.keyType;
/*     */     }
/*     */     
/*     */ 
/*     */     public Object fixInt(int ii)
/*     */     {
/* 377 */       if (ii < 0) {
/* 378 */         return "";
/*     */       }
/* 380 */       return Integer.valueOf(ii);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/layoutWizard/Pnl3RecordTypeMF.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */