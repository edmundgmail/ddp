/*    */ package net.sf.RecordEditor.layoutWizard;
/*    */ 
/*    */ import javax.swing.JEditorPane;
/*    */ import javax.swing.JScrollPane;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*    */ import net.sf.RecordEditor.utils.swing.AbsRowList;
/*    */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*    */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Pnl4Names
/*    */   extends WizardPanel
/*    */ {
/* 38 */   private static final int COLUMN_HEIGHT = SwingUtils.TABLE_ROW_HEIGHT * 9;
/* 39 */   private static final int FILE_HEIGHT = SwingUtils.TABLE_ROW_HEIGHT * 15 / 2;
/*    */   
/*    */ 
/*    */ 
/*    */   private ColumnNames columnNames;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public Pnl4Names(AbsRowList typeList)
/*    */   {
/* 50 */     String formDescription = LangConversion.convertId(2, "FileWizard_4", "This screen will display the Column Details and allow you to change them. ");
/*    */     
/*    */ 
/* 53 */     JEditorPane tips = new JEditorPane("text/html", formDescription);
/*    */     
/* 55 */     this.columnNames = new ColumnNames(typeList);
/*    */     
/*    */ 
/* 58 */     setHelpURLre(Common.formatHelpURL("HlpLe04.htm#HDRWIZ3"));
/* 59 */     addComponentRE(1, 5, TIP_HEIGHT, BasePanel.GAP3, 2, 2, tips);
/*    */     
/*    */ 
/* 62 */     setGapRE(BasePanel.GAP1);
/* 63 */     addComponentRE(1, 5, COLUMN_HEIGHT, BasePanel.GAP1, 2, 2, new JScrollPane(this.columnNames.columnTbl));
/*    */     
/*    */ 
/* 66 */     addComponentRE(1, 5, FILE_HEIGHT, BasePanel.GAP0, 2, 2, new JScrollPane(this.columnNames.fileTbl));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Details getValues()
/*    */     throws Exception
/*    */   {
/* 79 */     return this.columnNames.getValues();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setValues(Details detail)
/*    */     throws Exception
/*    */   {
/* 87 */     this.columnNames.setValues(detail, detail.standardRecord);
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/layoutWizard/Pnl4Names.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */