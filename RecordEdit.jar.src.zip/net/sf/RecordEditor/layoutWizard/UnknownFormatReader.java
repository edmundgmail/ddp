/*     */ package net.sf.RecordEditor.layoutWizard;
/*     */ 
/*     */ import java.awt.Container;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDialog;
/*     */ import net.sf.JRecord.Common.Constants;
/*     */ import net.sf.JRecord.Common.RecordException;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.LayoutDetail;
/*     */ import net.sf.JRecord.Details.RecordDetail;
/*     */ import net.sf.JRecord.Details.RecordDetail.FieldDetails;
/*     */ import net.sf.JRecord.IO.AbstractLineReader;
/*     */ import net.sf.JRecord.IO.DelegateReader;
/*     */ import net.sf.JRecord.IO.LineIOProvider;
/*     */ import net.sf.RecordEditor.utils.charsets.FontCombo;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMainFrame;
/*     */ import net.sf.RecordEditor.utils.swing.EditingCancelled;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UnknownFormatReader
/*     */   extends DelegateReader
/*     */ {
/*     */   public void open(InputStream inputStream, AbstractLayoutDetails layout)
/*     */     throws IOException, RecordException
/*     */   {
/*  46 */     BufferedInputStream inStream = new BufferedInputStream(inputStream, 32000);
/*  47 */     int fileStructure = buildLayout(inStream, layout);
/*     */     
/*  49 */     AbstractLineReader reader = LineIOProvider.getInstance().getLineReader(fileStructure);
/*  50 */     reader.open(inStream, getLayout());
/*  51 */     setReader(reader);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void generateLayout(AbstractLayoutDetails layout)
/*     */   {
/*  62 */     super.generateLayout(layout);
/*     */     try
/*     */     {
/*  65 */       buildLayout(null, layout);
/*     */     } catch (Exception e) {
/*  67 */       Common.logMsg("Error Generating Layout", e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private int buildLayout(BufferedInputStream inStream, AbstractLayoutDetails layout)
/*     */     throws IOException, RecordException
/*     */   {
/*  76 */     int fileStructure = 0;
/*  77 */     int fieldType = 81;
/*  78 */     int format = 0;
/*     */     
/*  80 */     String param = "";
/*  81 */     byte[] recordSep = Constants.CRLF_BYTES;
/*     */     
/*     */ 
/*  84 */     GetFileDetails getDetails = new GetFileDetails(inStream);
/*     */     
/*  86 */     getDetails.setVisible(true);
/*     */     
/*     */ 
/*     */ 
/*  90 */     if (getDetails.ok) {
/*  91 */       PnlUnknownFileFormat pnl = getDetails.pnl;
/*  92 */       fileStructure = pnl.getFileStructure();
/*  93 */       String font = pnl.fontNameCombo.getText();
/*     */       
/*  95 */       RecordDetail.FieldDetails[] flds = new RecordDetail.FieldDetails[1];
/*  96 */       RecordDetail[] recs = new RecordDetail[1];
/*     */       
/*     */ 
/*  99 */       if (fileStructure == 2) {
/* 100 */         flds[0] = new RecordDetail.FieldDetails("Data", "", 0, 0, font, format, param);
/*     */         
/* 102 */         flds[0].setPosLen(1, pnl.getLength());
/*     */       } else {
/* 104 */         flds[0] = new RecordDetail.FieldDetails("Data", "", fieldType, 0, font, format, param);
/*     */         
/* 106 */         flds[0].setPosLen(1, 1);
/*     */       }
/*     */       
/* 109 */       recs[0] = new RecordDetail("UnknownFormatRecord", "", "", 1, "", "", font, flds, 0, 0);
/*     */       
/*     */ 
/* 112 */       layout = new LayoutDetail(layout.getLayoutName(), recs, "", 0, recordSep, layout.getEolString(), font, null, fileStructure);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 120 */       setLayout(layout);
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 126 */       throw new EditingCancelled();
/*     */     }
/*     */     
/* 129 */     return fileStructure;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class GetFileDetails
/*     */     extends JDialog
/*     */     implements ActionListener
/*     */   {
/*     */     public final PnlUnknownFileFormat pnl;
/*     */     
/*     */ 
/*     */ 
/* 143 */     public boolean ok = false;
/*     */     
/*     */     public GetFileDetails(BufferedInputStream in) throws IOException
/*     */     {
/* 147 */       super(true);
/*     */       
/* 149 */       this.pnl = new PnlUnknownFileFormat(in);
/*     */       
/*     */ 
/* 152 */       this.pnl.goBtn.addActionListener(this);
/*     */       
/*     */ 
/* 155 */       getContentPane().add(this.pnl);
/* 156 */       setResizable(true);
/* 157 */       pack();
/*     */       
/* 159 */       if (Common.NIMBUS_LAF) {
/* 160 */         setBounds(getY(), getX(), Math.max(getWidth(), ReFrame.getDesktopWidth() * 3 / 4), getHeight());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/* 169 */       this.ok = (e.getSource() == this.pnl.goBtn);
/* 170 */       setVisible(false);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/layoutWizard/UnknownFormatReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */