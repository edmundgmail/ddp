/*    */ package net.sf.RecordEditor.layoutWizard;
/*    */ 
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.swing.JButton;
/*    */ import javax.swing.UIManager;
/*    */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*    */ import net.sf.RecordEditor.utils.screenManager.ReMainFrame;
/*    */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*    */ 
/*    */ 
/*    */ public class WizardFileMenu
/*    */   implements ActionListener
/*    */ {
/* 15 */   private JButton wizBtn = new JButton("*");
/* 16 */   private JButton copyBtn = new JButton("*");
/*    */   
/*    */   public WizardFileMenu() {
/* 19 */     ReFrame frame = new ReFrame("Menu");
/* 20 */     BasePanel pnl = new BasePanel();
/*    */     
/* 22 */     pnl.setGapRE(BasePanel.GAP3);
/* 23 */     pnl.addMenuItemRE("Layout Wizard (For File copybooks) ", this.wizBtn);
/* 24 */     pnl.setGapRE(BasePanel.GAP1);
/* 25 */     pnl.addMenuItemRE("Convert Layout ", this.copyBtn);
/* 26 */     pnl.setGapRE(BasePanel.GAP3);
/*    */     
/* 28 */     frame.addMainComponent(pnl);
/*    */     
/* 30 */     this.wizBtn.addActionListener(this);
/* 31 */     this.copyBtn.addActionListener(this);
/* 32 */     frame.setVisible(true);
/*    */     
/* 34 */     new WizardFileLayout("");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void actionPerformed(ActionEvent e)
/*    */   {
/* 44 */     if (e.getSource() == this.wizBtn) {
/* 45 */       new WizardFileLayout(new ReFrame("", "File Wizard", "", null), "", null, true, true);
/*    */     } else {
/* 47 */       new ConvertLayout();
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static void main(String[] args)
/*    */   {
/* 56 */     new ReMainFrame("Wizard - Generate Copybooks", "", "Wiz");
/*    */     try
/*    */     {
/* 59 */       UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
/*    */     }
/*    */     catch (Exception e) {}
/* 62 */     new WizardFileMenu();
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/layoutWizard/WizardFileMenu.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */