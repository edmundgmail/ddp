/*     */ package net.sf.RecordEditor.layoutWizard;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.table.AbstractTableModel;
/*     */ import javax.swing.table.DefaultTableCellRenderer;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import javax.swing.text.JTextComponent;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.IO.AbstractLineReader;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.params.BoolOpt;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.HexTwoLineRender;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.tblModels.LineArrayHexModel;
/*     */ import net.sf.RecordEditor.utils.tblModels.LineArrayModel;
/*     */ 
/*     */ public class ColumnSelector
/*     */ {
/*  35 */   private static final int STANDARD_TABLE_CELL_WIDTH = SwingUtils.CHECK_BOX_HEIGHT;
/*     */   
/*     */   private static final int COLUMNS_TO_NUMER = 10;
/*     */   public int stdLineHeight;
/*     */   private AbstractTableModel stdModel;
/*     */   private AbstractTableModel hexModel;
/*     */   private AbstractTableModel fileModel;
/*     */   private TableCellRenderer stdRender;
/*     */   private TableCellRenderer hexRender;
/*     */   private TableCellRenderer tblRender;
/*     */   private RecordDefinition recordDef;
/*     */   private Details currentDetails;
/*  47 */   public final JTable fileTbl = new JTable();
/*  48 */   public final JCheckBox hexChk = new JCheckBox();
/*     */   
/*  50 */   private final JCheckBox lookMainframeZoned = new JCheckBox("Mainframe Zoned Numeric");
/*  51 */   private final JCheckBox lookPcZoned = new JCheckBox("PC/Unix Zoned Numeric");
/*  52 */   private final JCheckBox lookComp3 = new JCheckBox("Comp 3");
/*  53 */   private final JCheckBox lookCompBigEndian = new JCheckBox("Binary Integer (Big Endian)");
/*  54 */   private final JCheckBox lookCompLittleEndian = new JCheckBox("Binary Integer (Little Endian)");
/*     */   
/*  56 */   private final JButton clearFieldsBtn = SwingUtils.newButton("Clear Fields");
/*  57 */   private final JButton addFieldsBtn = SwingUtils.newButton("Add Fields");
/*     */   
/*     */   private JTextComponent msg;
/*     */   
/*     */   private int[] colorInd;
/*  62 */   private boolean firstTime = true;
/*     */   
/*     */ 
/*  65 */   private ActionListener listner = new ActionListener()
/*     */   {
/*     */ 
/*     */ 
/*     */     public void actionPerformed(ActionEvent event)
/*     */     {
/*     */ 
/*  72 */       if (event.getSource() == ColumnSelector.this.clearFieldsBtn) {
/*  73 */         ColumnSelector.this.recordDef.columnDtls.clear();
/*     */         
/*  75 */         if (ColumnSelector.this.currentDetails.recordType == 2) {
/*  76 */           ColumnSelector.this.recordDef.addKeyField(ColumnSelector.this.currentDetails, true);
/*     */         }
/*     */       } else {
/*  79 */         ColumnSelector.this.findFields();
/*     */       }
/*  81 */       ColumnSelector.this.setColorIndicator();
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ColumnSelector(JTextComponent message)
/*     */   {
/*  92 */     this.msg = message;
/*     */     
/*  94 */     this.fileTbl.setAutoResizeMode(0);
/*  95 */     this.hexChk.setSelected(false);
/*     */     
/*  97 */     this.lookPcZoned.setSelected(Common.OPTIONS.searchForPcZoned.isSelected());
/*  98 */     this.clearFieldsBtn.addActionListener(this.listner);
/*  99 */     this.addFieldsBtn.addActionListener(this.listner);
/*     */   }
/*     */   
/*     */ 
/*     */   public void addMouseListner()
/*     */   {
/* 105 */     addMouseListner(new java.awt.event.MouseAdapter() {
/*     */       public void mousePressed(MouseEvent m) {
/* 107 */         int col = ColumnSelector.this.fileTbl.columnAtPoint(m.getPoint());
/* 108 */         ColumnSelector.this.columnSelected(col);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public void addMouseListner(MouseListener mouseListner) {
/* 114 */     this.fileTbl.addMouseListener(mouseListner);
/* 115 */     this.fileTbl.getTableHeader().addMouseListener(mouseListner);
/*     */     
/* 117 */     this.hexChk.addActionListener(new ActionListener()
/*     */     {
/*     */ 
/*     */ 
/*     */       public void actionPerformed(ActionEvent arg0)
/*     */       {
/*     */ 
/* 124 */         ColumnSelector.this.flipHex();
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   public void addFields(BasePanel pnl, int tblHeight) {
/* 130 */     JPanel optionPnl = new JPanel(new GridLayout(3, 2));
/* 131 */     JPanel btnPnl = new JPanel(new GridLayout(1, 1));
/*     */     
/* 133 */     optionPnl.add(this.lookMainframeZoned);
/* 134 */     optionPnl.add(this.lookPcZoned);
/*     */     
/* 136 */     optionPnl.add(this.lookComp3);
/* 137 */     optionPnl.add(new JPanel());
/* 138 */     optionPnl.add(this.lookCompBigEndian);
/* 139 */     optionPnl.add(this.lookCompLittleEndian);
/*     */     
/*     */ 
/*     */ 
/* 143 */     btnPnl.add(this.clearFieldsBtn);
/* 144 */     btnPnl.add(this.addFieldsBtn);
/*     */     
/* 146 */     pnl.addLineRE("Show Hex", this.hexChk).setGapRE(BasePanel.GAP);
/*     */     
/* 148 */     pnl.addLineRE("Search For", optionPnl).setHeightRE(-2.0D).setGapRE(BasePanel.GAP1);
/*     */     
/*     */ 
/* 151 */     pnl.addLineRE("", btnPnl).setHeightRE(-2.0D);
/*     */     
/* 153 */     pnl.addComponentRE(1, 5, tblHeight, 2.0D, 2, 2, this.fileTbl);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void columnSelected(int col)
/*     */   {
/* 163 */     int searchCol = col + 1;
/*     */     
/*     */ 
/*     */ 
/* 167 */     int pos = -1;
/*     */     
/* 169 */     if (this.recordDef.columnDtls.size() == 0) {
/* 170 */       this.recordDef.columnDtls.add(0, new ColumnDetails(searchCol, this.currentDetails.defaultType.intValue()));
/*     */     } else {
/* 172 */       pos = columnSelected_100_getColumnPosition(searchCol);
/*     */       
/* 174 */       int column = ((ColumnDetails)this.recordDef.columnDtls.get(pos)).start;
/*     */       
/* 176 */       if (searchCol < column) {
/* 177 */         this.recordDef.columnDtls.add(pos, new ColumnDetails(searchCol, this.currentDetails.defaultType.intValue()));
/*     */       }
/* 179 */       else if (searchCol == column) {
/* 180 */         this.recordDef.columnDtls.remove(pos);
/*     */       } else {
/* 182 */         this.recordDef.columnDtls.add(pos + 1, new ColumnDetails(searchCol, this.currentDetails.defaultType.intValue()));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 187 */     setColorIndicator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int columnSelected_100_getColumnPosition(int col)
/*     */   {
/* 199 */     int ret = 0;
/* 200 */     int size = this.recordDef.columnDtls.size() - 1;
/*     */     
/* 202 */     int column = -1;
/*     */     
/* 204 */     ret = 0;
/*     */     
/* 206 */     if (size > 0) {
/* 207 */       column = ((ColumnDetails)this.recordDef.columnDtls.get(ret)).start;
/* 208 */       while ((ret < size) && (col > column)) {
/* 209 */         ret++;
/* 210 */         column = ((ColumnDetails)this.recordDef.columnDtls.get(ret)).start;
/*     */       }
/*     */     }
/*     */     
/* 214 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setColorIndicator()
/*     */   {
/* 226 */     int size = this.recordDef.columnDtls.size();
/*     */     
/* 228 */     int j = 0;
/* 229 */     int ind = 0;
/*     */     
/* 231 */     for (int i = 0; i < size; i++) {
/* 232 */       int col = Math.min(((ColumnDetails)this.recordDef.columnDtls.get(i)).start - 1, this.colorInd.length);
/*     */       
/* 234 */       while (j < col) {
/* 235 */         this.colorInd[(j++)] = ind;
/*     */       }
/*     */       
/* 238 */       ind = 1 - ind;
/*     */     }
/* 240 */     while (j < this.colorInd.length) {
/* 241 */       this.colorInd[(j++)] = ind;
/*     */     }
/*     */     
/* 244 */     this.fileModel.fireTableDataChanged();
/*     */   }
/*     */   
/*     */   public final void setValues(Details detail, RecordDefinition recordDefinition, boolean findFields)
/*     */     throws Exception
/*     */   {
/* 250 */     boolean cp037 = "cp037".equalsIgnoreCase(detail.fontName);
/* 251 */     this.currentDetails = detail;
/* 252 */     this.recordDef = recordDefinition;
/*     */     
/* 254 */     this.hexChk.setSelected((this.hexChk.isSelected()) || (this.currentDetails.textPct < 40));
/* 255 */     this.lookComp3.setSelected((cp037) || (Common.OPTIONS.searchForComp3.isSelected()));
/* 256 */     this.lookCompBigEndian.setSelected((cp037) || (this.currentDetails.textPct < 70) || (Common.OPTIONS.searchForCompBigEndian.isSelected()));
/* 257 */     this.lookMainframeZoned.setSelected((cp037) || (Common.OPTIONS.searchForMainframeZoned.isSelected()));
/* 258 */     this.lookCompLittleEndian.setSelected((!this.lookCompBigEndian.isSelected()) && (Common.OPTIONS.searchForCompLittleEndian.isSelected()));
/*     */     
/*     */ 
/* 261 */     setValues_100_SetupTable(findFields);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setValues_100_SetupTable(boolean findFields)
/*     */   {
/* 271 */     this.stdRender = new TblRender();
/* 272 */     this.stdModel = new LineArrayModel(this.recordDef.records, this.currentDetails.fontName, this.recordDef.numRecords);
/*     */     
/* 274 */     this.fileModel = this.stdModel;
/* 275 */     this.tblRender = this.stdRender;
/*     */     
/* 277 */     this.hexModel = new LineArrayHexModel(this.recordDef.records, this.recordDef.numRecords);
/*     */     
/* 279 */     this.hexRender = new HexRender(this.currentDetails.fontName);
/*     */     
/* 281 */     this.colorInd = new int[this.fileModel.getColumnCount()];
/*     */     
/* 283 */     if (this.firstTime) {
/* 284 */       this.firstTime = false;
/* 285 */       this.fileTbl.setModel(this.fileModel);
/* 286 */       this.stdLineHeight = this.fileTbl.getRowHeight();
/*     */       
/* 288 */       setupTableColumns();
/*     */     }
/* 290 */     flipHex();
/*     */     
/*     */ 
/* 293 */     if ((findFields) && (Common.OPTIONS.runFieldSearchAutomatically.isSelected()) && (this.recordDef.searchForFields))
/*     */     {
/*     */ 
/* 296 */       findFields();
/*     */     }
/*     */     
/* 299 */     setColorIndicator();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void findFields()
/*     */   {
/* 306 */     if ((this.lookCompBigEndian.isSelected()) && (this.lookCompLittleEndian.isSelected())) {
/* 307 */       this.msg.setText("Can only look for one type of binary field !!!");
/* 308 */       this.lookCompLittleEndian.setSelected(false);
/*     */     }
/*     */     
/* 311 */     new FieldSearch(this.currentDetails, this.recordDef).findFields(this.lookMainframeZoned.isSelected(), this.lookPcZoned.isSelected(), this.lookComp3.isSelected(), this.lookCompBigEndian.isSelected(), this.lookCompLittleEndian.isSelected());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 317 */     this.recordDef.searchForFields = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void readFile(Details detail, RecordDefinition recordDefinition)
/*     */     throws Exception
/*     */   {
/* 331 */     AbstractLineReader reader = detail.getReader();
/* 332 */     int i = 0;
/*     */     
/*     */ 
/*     */ 
/* 336 */     this.currentDetails = detail;
/* 337 */     this.recordDef = recordDefinition;
/*     */     
/* 339 */     AbstractLine l = reader.read();
/* 340 */     while ((l != null) && (i < this.recordDef.records.length)) {
/* 341 */       byte[] s = l.getData();
/*     */       
/* 343 */       this.recordDef.records[(i++)] = s;
/* 344 */       l = reader.read();
/*     */     }
/* 346 */     this.recordDef.numRecords = i;
/*     */   }
/*     */   
/*     */   private void flipHex()
/*     */   {
/* 351 */     int height = this.stdLineHeight;
/* 352 */     this.fileModel = this.stdModel;
/* 353 */     this.tblRender = this.stdRender;
/* 354 */     if (this.hexChk.isSelected()) {
/* 355 */       this.fileModel = this.hexModel;
/* 356 */       this.tblRender = this.hexRender;
/* 357 */       height = (this.stdLineHeight + 1) * 2;
/*     */     }
/*     */     
/* 360 */     this.fileTbl.setModel(this.fileModel);
/* 361 */     this.fileTbl.setRowHeight(height);
/*     */     
/* 363 */     setupTableColumns();
/* 364 */     this.fileModel.fireTableDataChanged();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setupTableColumns()
/*     */   {
/* 372 */     TableColumnModel tcm = this.fileTbl.getColumnModel();
/* 373 */     int cellWidth = STANDARD_TABLE_CELL_WIDTH;
/*     */     
/* 375 */     for (int i = 0; i < this.fileModel.getColumnCount(); i++) {
/* 376 */       TableColumn tc = tcm.getColumn(i);
/* 377 */       cellWidth = STANDARD_TABLE_CELL_WIDTH;
/* 378 */       if ((Common.NIMBUS_LAF) && (i >= 99) && (i % 10 == 9)) {
/* 379 */         cellWidth += 8;
/*     */       }
/*     */       
/* 382 */       tc.setPreferredWidth(cellWidth);
/* 383 */       tc.setCellRenderer(this.tblRender);
/*     */       
/*     */       String s;
/* 386 */       switch ((i + 1) % 10) {
/* 387 */       case 0:  s = "" + (i + 1) / 10; break;
/* 388 */       case 5:  s = "+"; break;
/* 389 */       default:  s = " ";
/*     */       }
/* 391 */       tc.setHeaderValue(s);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final Details getCurrentDetails()
/*     */   {
/* 399 */     return this.currentDetails;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public class TblRender
/*     */     implements TableCellRenderer
/*     */   {
/* 413 */     private DefaultTableCellRenderer txtFld = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public TblRender()
/*     */     {
/* 422 */       this.txtFld = new DefaultTableCellRenderer();
/* 423 */       this.txtFld.setBorder(BorderFactory.createEmptyBorder());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Component getTableCellRendererComponent(JTable tbl, Object value, boolean isSelected, boolean hasFocus, int row, int column)
/*     */     {
/* 448 */       if (ColumnSelector.this.colorInd[column] == 0) {
/* 449 */         this.txtFld.setBackground(Color.LIGHT_GRAY);
/*     */       } else {
/* 451 */         this.txtFld.setBackground(Color.WHITE);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 457 */       this.txtFld.setText(value.toString());
/*     */       
/*     */ 
/*     */ 
/* 461 */       return this.txtFld.getTableCellRendererComponent(tbl, value, isSelected, hasFocus, row, column);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public class HexRender
/*     */     extends HexTwoLineRender
/*     */   {
/*     */     public HexRender(String font)
/*     */     {
/* 472 */       super();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Component getTableCellRendererComponent(JTable tbl, Object value, boolean isSelected, boolean hasFocus, int row, int column)
/*     */     {
/* 483 */       Component ret = super.getTableCellRendererComponent(tbl, value, isSelected, hasFocus, row, column);
/* 484 */       if (ColumnSelector.this.colorInd[column] == 0) {
/* 485 */         ret.setBackground(Color.LIGHT_GRAY);
/*     */       } else {
/* 487 */         ret.setBackground(Color.WHITE);
/*     */       }
/*     */       
/* 490 */       return ret;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/layoutWizard/ColumnSelector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */