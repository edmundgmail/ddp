/*     */ package net.sf.RecordEditor.layoutWizard;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.math.BigInteger;
/*     */ import java.util.ArrayList;
/*     */ import net.sf.JRecord.ByteIO.AbstractByteReader;
/*     */ import net.sf.JRecord.ByteIO.ByteIOProvider;
/*     */ import net.sf.JRecord.External.ExternalRecord;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ 
/*     */ 
/*     */ public class FileAnalyser
/*     */ {
/*     */   private static final int LAST_7_BITS_SET = 127;
/*  17 */   private static final boolean[] ASCII_CHAR = init(new boolean[''], false);
/*  18 */   private static final boolean[] EBCDIC_CHAR = getTextChars("cp037");
/*     */   private static final String TEXT_CHARS = "+-.,abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789\n\t ;:?{}<>";
/*     */   
/*     */   static {
/*  22 */     for (int i = 0; i < "+-.,abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789\n\t ;:?{}<>".length(); i++) {
/*  23 */       ASCII_CHAR["+-.,abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789\n\t ;:?{}<>".charAt(i)] = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*  28 */   private checkFile[] fileChecks = { new VbDumpCheck(), new StandardCheckFile(4, "cp037"), new StandardCheckFile(7), new StandardCheckFile(8), new BinTextCheck() };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean ebcdicFile;
/*     */   
/*     */ 
/*     */ 
/*     */   private static int maxRun;
/*     */   
/*     */ 
/*     */ 
/*  41 */   private int textPct = 0;
/*  42 */   private int recordLength = 100;
/*  43 */   private int fileStructure = -121;
/*  44 */   private String fontName = "";
/*     */   
/*     */   private byte[] fData;
/*     */   
/*  48 */   private int linesRead = 0;
/*     */   
/*     */   public static FileAnalyser getAnaylserNoLengthCheck(byte[] fileData, String lengthStr) {
/*  51 */     return new FileAnalyser(fileData, lengthStr, true, false);
/*     */   }
/*     */   
/*     */   public static FileAnalyser getAnaylser(byte[] fileData, String lengthStr) {
/*  55 */     return new FileAnalyser(fileData, lengthStr, true, true);
/*     */   }
/*     */   
/*     */   public static FileAnalyser getFixedAnalyser(byte[] fileData, String lengthStr) {
/*  59 */     return new FileAnalyser(fileData, lengthStr, false, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private FileAnalyser(byte[] fileData, String lengthStr, boolean searchFileStructures, boolean searchFixedWidthLength)
/*     */   {
/*  68 */     this.fData = fileData;
/*     */     
/*  70 */     int textPerc = 0;
/*  71 */     int ebcdicCount = countTextChars(fileData, EBCDIC_CHAR);
/*  72 */     int ebcdicRun = maxRun;
/*  73 */     int asciiCount = countTextChars(fileData, ASCII_CHAR);
/*  74 */     int asciiRun = maxRun;
/*  75 */     if (fileData.length > 0) {
/*  76 */       textPerc = 100 * Math.max(ebcdicCount, asciiCount) / fileData.length;
/*     */     }
/*  78 */     this.textPct = textPerc;
/*     */     
/*  80 */     if (searchFileStructures) {
/*  81 */       for (int i = 0; i < this.fileChecks.length; i++) {
/*  82 */         if (this.fileChecks[i].check(fileData)) {
/*  83 */           this.fileStructure = this.fileChecks[i].getFileStructure();
/*  84 */           this.fontName = this.fileChecks[i].getFontName();
/*  85 */           this.linesRead = this.fileChecks[i].getLinesRead();
/*  86 */           return;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  91 */     this.ebcdicFile = (((ebcdicCount - asciiCount) * 20 / fileData.length > 3) || ((ebcdicCount > asciiCount) && (ebcdicRun > 2) && (ebcdicRun > asciiRun)));
/*     */     
/*     */ 
/*  94 */     if (this.ebcdicFile) {
/*  95 */       this.fontName = "cp037";
/*     */     } else {
/*  97 */       this.fontName = "";
/*     */     }
/*  99 */     System.out.println("Ebcidic Counts " + ebcdicCount + " " + asciiCount + " -- " + ebcdicRun + " " + asciiRun);
/*     */     
/* 101 */     this.fileStructure = 2;
/*     */     
/* 103 */     if (searchFixedWidthLength) {
/* 104 */       findRecordLength(fileData, lengthStr);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void findRecordLength(byte[] fileData, String lengthStr)
/*     */   {
/* 111 */     this.recordLength = -121;
/*     */     try {
/* 113 */       this.recordLength = Integer.parseInt(lengthStr);
/*     */     }
/*     */     catch (Exception e) {}
/*     */     
/*     */ 
/* 118 */     if (this.recordLength <= 0) {
/* 119 */       boolean lookMainframeZoned = this.ebcdicFile;
/* 120 */       boolean lookPcZoned = false;boolean lookComp3 = this.ebcdicFile;boolean lookCompBigEndian = true;boolean lookCompLittleEndian = false;
/*     */       
/*     */ 
/* 123 */       Details details = new Details();
/* 124 */       RecordDefinition recordDefinition = details.standardRecord;
/* 125 */       int relCount = 0;int maxCount = 0;int len = -121;
/*     */       
/* 127 */       details.fileStructure = 2;
/* 128 */       details.fontName = this.fontName;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 134 */       System.out.println("File Length: " + fileData.length);
/* 135 */       FieldSearch fieldSearch = new FieldSearch(details, recordDefinition);
/* 136 */       for (int i = 5; i < 200; i++) {
/* 137 */         details.recordLength = i;
/*     */         
/* 139 */         recordDefinition.numRecords = 0;
/* 140 */         for (int j = 0; (j < recordDefinition.records.length) && ((j + 1) * i < fileData.length); j++) {
/* 141 */           recordDefinition.records[j] = new byte[i];
/* 142 */           System.arraycopy(fileData, j * i, recordDefinition.records[j], 0, i);
/* 143 */           recordDefinition.numRecords = (j + 1);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 152 */         if ((recordDefinition.numRecords < 4) || ((i > 99) && (recordDefinition.numRecords < 5))) {
/*     */           break;
/*     */         }
/*     */         
/*     */ 
/* 157 */         recordDefinition.columnDtls.clear();
/* 158 */         fieldSearch.findFields(lookMainframeZoned, lookPcZoned, lookComp3, lookCompBigEndian, lookCompLittleEndian);
/* 159 */         int fieldCount = recordDefinition.columnDtls.size();
/* 160 */         relCount = fieldCount * 10000 / i;
/*     */         
/* 162 */         if ((fieldCount > 1) && (relCount > maxCount)) {
/* 163 */           maxCount = relCount;
/* 164 */           len = i;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 175 */         if (len < 1) {
/* 176 */           len = 100;
/*     */         }
/* 178 */         this.recordLength = len;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public ExternalRecord getLayoutDetails(boolean nameFields)
/*     */   {
/* 185 */     Details details = new Details();
/* 186 */     RecordDefinition recordDefinition = details.standardRecord;
/*     */     
/* 188 */     ByteArrayInputStream is = new ByteArrayInputStream(this.fData);
/*     */     try {
/* 190 */       details.fileStructure = this.fileStructure;
/* 191 */       details.fontName = this.fontName;
/* 192 */       details.recordLength = this.recordLength;
/*     */       
/*     */ 
/* 195 */       int i = 0;
/* 196 */       AbstractByteReader r = ByteIOProvider.getInstance().getByteReader(this.fileStructure);
/*     */       
/* 198 */       r.setLineLength(this.recordLength);
/* 199 */       r.open(is);
/* 200 */       byte[] l; while ((i < recordDefinition.records.length) && ((l = r.read()) != null)) {
/* 201 */         recordDefinition.records[(i++)] = l;
/* 202 */         recordDefinition.numRecords = i;
/*     */       }
/*     */       
/*     */ 
/*     */       try
/*     */       {
/* 208 */         is.close();
/*     */       }
/*     */       catch (Exception e) {}
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 215 */       lookMainframeZoned = this.ebcdicFile;
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 205 */       e.printStackTrace();
/*     */     } finally {
/*     */       try {
/* 208 */         is.close();
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*     */     
/*     */ 
/*     */     boolean lookMainframeZoned;
/*     */     
/* 216 */     boolean lookPcZoned = false;boolean lookComp3 = this.ebcdicFile;boolean lookCompBigEndian = true;boolean lookCompLittleEndian = false;
/*     */     
/*     */ 
/* 219 */     new FieldSearch(details, recordDefinition).findFields(lookMainframeZoned, lookPcZoned, lookComp3, lookCompBigEndian, lookCompLittleEndian);
/* 220 */     System.out.println("Column Count: " + recordDefinition.columnDtls.size() + " Number of Records: " + recordDefinition.numRecords);
/*     */     
/*     */ 
/* 223 */     if (nameFields) {
/* 224 */       for (int i = 0; i < recordDefinition.columnDtls.size(); i++) {
/* 225 */         ((ColumnDetails)recordDefinition.columnDtls.get(i)).name = ("Field_" + i);
/*     */       }
/*     */     }
/*     */     
/* 229 */     return details.createRecordLayout();
/*     */   }
/*     */   
/*     */ 
/*     */   private static boolean[] init(boolean[] b, boolean val)
/*     */   {
/* 235 */     for (int i = 0; i < b.length; i++) {
/* 236 */       b[i] = val;
/*     */     }
/*     */     
/* 239 */     return b;
/*     */   }
/*     */   
/*     */ 
/*     */   public static final int getTextPct(byte[] data, String font)
/*     */   {
/* 245 */     if ((data == null) || (data.length < 10)) {
/* 246 */       return 100;
/*     */     }
/* 248 */     return countTextChars(data, getTextChars(font)) * 100 / data.length;
/*     */   }
/*     */   
/*     */   public static final int countTextChars(byte[] data, String font)
/*     */   {
/* 253 */     return countTextChars(data, getTextChars(font));
/*     */   }
/*     */   
/*     */   private static final int countTextChars(byte[] data, boolean[] check)
/*     */   {
/* 258 */     int count = 0;
/* 259 */     int run = 1;
/*     */     
/* 261 */     boolean last = false;
/* 262 */     int cc = 0;
/*     */     
/* 264 */     maxRun = 0;
/* 265 */     for (int i = 0; i < data.length; i++) {
/* 266 */       int j = Common.toInt(data[i]);
/* 267 */       if (j >= check.length) {
/* 268 */         last = false;
/*     */       } else {
/* 270 */         if ((last) && (check[j] != 0)) {
/* 271 */           count++;
/* 272 */           run++;
/* 273 */           maxRun = Math.max(maxRun, run);
/* 274 */           if (cc == 0) {
/* 275 */             count++;
/*     */           }
/*     */           
/* 278 */           cc++;
/*     */         }
/* 280 */         last = check[j];
/*     */       }
/* 282 */       if (!last) {
/* 283 */         cc = 0;
/* 284 */         run = 1;
/*     */       }
/*     */     }
/*     */     
/* 288 */     return count;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getRecordLength()
/*     */   {
/* 294 */     return this.recordLength;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getTextPct()
/*     */   {
/* 300 */     return this.textPct;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getFileStructure()
/*     */   {
/* 306 */     return this.fileStructure;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getFontName()
/*     */   {
/* 312 */     return this.fontName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLinesRead()
/*     */   {
/* 320 */     return this.linesRead;
/*     */   }
/*     */   
/*     */   private static boolean[] getTextChars(String font) {
/* 324 */     boolean[] isText = init(new boolean['Ā'], false);
/*     */     try { byte[] bytes;
/*     */       byte[] bytes;
/* 327 */       if ((font == null) || ("".equals(font))) {
/* 328 */         bytes = "+-.,abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789\n\t ;:?{}<>".getBytes();
/*     */       } else {
/* 330 */         bytes = "+-.,abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789\n\t ;:?{}<>".getBytes(font);
/*     */       }
/*     */       
/* 333 */       for (int i = 0; i < bytes.length; i++) {
/* 334 */         int j = Common.toInt(bytes[i]);
/* 335 */         if (j > 32) {
/* 336 */           isText[j] = true;
/*     */         }
/*     */       }
/*     */     } catch (UnsupportedEncodingException e) {
/* 340 */       e.printStackTrace();
/*     */     }
/* 342 */     return isText;
/*     */   }
/*     */   
/*     */   private static abstract interface checkFile { public abstract boolean check(byte[] paramArrayOfByte);
/*     */     
/*     */     public abstract int getFileStructure();
/*     */     
/*     */     public abstract String getFontName();
/*     */     
/*     */     public abstract int getLinesRead(); }
/*     */   
/*     */   private static class StandardCheckFile implements FileAnalyser.checkFile { private int structure;
/* 354 */     private String font = "";
/* 355 */     protected int linesRead = 0;
/*     */     
/*     */ 
/*     */ 
/*     */     public StandardCheckFile(int fileStructure)
/*     */     {
/* 361 */       this.structure = fileStructure;
/*     */     }
/*     */     
/*     */     public StandardCheckFile(int fileStructure, String fontName) {
/* 365 */       this.structure = fileStructure;
/* 366 */       this.font = fontName;
/*     */     }
/*     */     
/*     */     public boolean check(byte[] data) {
/* 370 */       boolean ret = true;
/*     */       try {
/* 372 */         int len = 0;
/*     */         
/* 374 */         AbstractByteReader reader = ByteIOProvider.getInstance().getByteReader(this.structure);
/* 375 */         reader.open(new ByteArrayInputStream(data));
/*     */         byte[] bytes;
/* 377 */         for (int i = 0; 
/* 378 */             (i < 20) && (len < data.length) && ((bytes = reader.read()) != null); 
/* 379 */             i++) {
/* 380 */           len += bytes.length;
/* 381 */           this.linesRead = i;
/*     */         }
/* 383 */         reader.close();
/*     */       } catch (Exception e) {
/* 385 */         ret = false;
/*     */       }
/* 387 */       return ret;
/*     */     }
/*     */     
/*     */     public int getFileStructure() {
/* 391 */       return this.structure;
/*     */     }
/*     */     
/*     */     public String getFontName() {
/* 395 */       return this.font;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getLinesRead()
/*     */     {
/* 404 */       return this.linesRead;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class BinTextCheck extends FileAnalyser.StandardCheckFile {
/*     */     public BinTextCheck() {
/* 410 */       super();
/*     */     }
/*     */     
/*     */     public boolean check(byte[] data)
/*     */     {
/* 415 */       boolean ret = false;
/* 416 */       if (data != null) {
/* 417 */         int count = FileAnalyser.countTextChars(data, FileAnalyser.ASCII_CHAR);
/*     */         
/*     */ 
/* 420 */         if (count * 100 / data.length >= 70) {
/* 421 */           ret = super.check(data);
/*     */         }
/*     */       }
/*     */       
/* 425 */       return ret;
/*     */     }
/*     */   }
/*     */   
/*     */   private class VbDumpCheck extends FileAnalyser.StandardCheckFile
/*     */   {
/*     */     public VbDumpCheck() {
/* 432 */       super("cp037");
/*     */     }
/*     */     
/*     */     public boolean check(byte[] data)
/*     */     {
/* 437 */       boolean ret = false;
/* 438 */       if ((data != null) && (data.length >= 8) && 
/* 439 */         (data[6] == 0) && (data[7] == 0))
/*     */       {
/*     */         byte[] bdwLength;
/* 442 */         if (data[0] >= 0) {
/* 443 */           byte[] bdwLength = new byte[2];
/* 444 */           bdwLength[0] = data[0];
/* 445 */           bdwLength[1] = data[1];
/*     */         } else {
/* 447 */           bdwLength = new byte[4];
/* 448 */           bdwLength[0] = ((byte)(data[0] & 0x7F));
/* 449 */           bdwLength[1] = data[1];
/* 450 */           bdwLength[2] = data[2];
/* 451 */           bdwLength[3] = data[3];
/*     */         }
/* 453 */         int blockLength = new BigInteger(bdwLength).intValue();
/* 454 */         if (blockLength + 8 < data.length) {
/* 455 */           if ((data[(blockLength + 7)] == 0) && (data[(blockLength + 8)] == 0)) {
/* 456 */             ret = super.check(data);
/*     */           }
/*     */         } else {
/* 459 */           ret = super.check(data);
/*     */         }
/*     */       }
/* 462 */       return ret;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/layoutWizard/FileAnalyser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */