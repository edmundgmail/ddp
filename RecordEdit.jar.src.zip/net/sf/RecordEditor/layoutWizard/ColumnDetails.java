/*     */ package net.sf.RecordEditor.layoutWizard;
/*     */ 
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.TreeComboItem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ColumnDetails
/*     */ {
/*     */   public static final int NAME_IDX = 0;
/*     */   public static final int START_IDX = 1;
/*     */   public static final int LENGTH_IDX = 2;
/*     */   public static final int TYPE_IDX = 3;
/*     */   public static final int DECIMAL_IDX = 4;
/*     */   public static final int INCLUDE_IDX = 5;
/*     */   public static final int NUMBER_OF_COLUMNS = 6;
/*  33 */   private static final String[] COLUMN_NAMES = LangConversion.convertColHeading("LayoutWizard Field definition", new String[] { "Field Name", "Start", "Length", "Type", "Decimal", "Include" });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  39 */   protected String name = "";
/*  40 */   protected int start = 0;
/*  41 */   protected int length = 0;
/*     */   protected int type;
/*  43 */   protected int decimal = 0;
/*  44 */   protected Boolean include = Boolean.TRUE;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ColumnDetails(int colStart, int defaultType)
/*     */   {
/*  54 */     this.start = colStart;
/*  55 */     this.type = defaultType;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getValue(int columnIdx)
/*     */   {
/*     */     Object o;
/*     */     
/*     */ 
/*  66 */     switch (columnIdx) {
/*  67 */     case 1:  o = Integer.valueOf(this.start); break;
/*  68 */     case 2:  o = Integer.valueOf(this.length); break;
/*  69 */     case 3:  o = Integer.valueOf(this.type); break;
/*  70 */     case 4:  o = Integer.valueOf(this.decimal); break;
/*  71 */     case 5:  o = this.include; break;
/*  72 */     default:  o = this.name;
/*     */     }
/*     */     
/*  75 */     return o;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValue(int columnIdx, Object o)
/*     */   {
/*  86 */     switch (columnIdx) {
/*  87 */     case 1:  this.start = getInt(o); break;
/*  88 */     case 2:  this.length = getInt(o); break;
/*  89 */     case 3:  this.type = getInt(o); break;
/*  90 */     case 4:  this.decimal = getInt(o); break;
/*  91 */     case 5:  this.include = ((Boolean)o); break;
/*  92 */     default:  this.name = o.toString();
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private int getInt(Object o)
/*     */   {
/* 102 */     int i = 0;
/* 103 */     if (o != null) {
/* 104 */       if ((o instanceof Integer)) {
/* 105 */         i = ((Integer)o).intValue();
/* 106 */       } else if ((o instanceof TreeComboItem)) {
/* 107 */         i = ((Integer)((TreeComboItem)o).key).intValue();
/*     */       } else {
/* 109 */         i = Integer.parseInt(o.toString());
/*     */       }
/*     */     }
/* 112 */     return i;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getColumnName(int column)
/*     */   {
/* 122 */     return COLUMN_NAMES[column];
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/layoutWizard/ColumnDetails.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */