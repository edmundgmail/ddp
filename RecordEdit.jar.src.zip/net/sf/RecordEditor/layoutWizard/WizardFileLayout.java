/*     */ package net.sf.RecordEditor.layoutWizard;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.RootPaneContainer;
/*     */ import net.sf.JRecord.External.CopybookWriter;
/*     */ import net.sf.JRecord.External.CopybookWriterManager;
/*     */ import net.sf.JRecord.External.ExternalConversion;
/*     */ import net.sf.JRecord.External.ExternalRecord;
/*     */ import net.sf.JRecord.IO.LineIOProvider;
/*     */ import net.sf.RecordEditor.utils.BasicLayoutCallback;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.edit.ManagerRowList;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.swing.AbsRowList;
/*     */ import net.sf.RecordEditor.utils.wizards.AbstractWizard;
/*     */ import net.sf.RecordEditor.utils.wizards.AbstractWizardPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WizardFileLayout
/*     */   extends AbstractWizard<Details>
/*     */ {
/*  26 */   private AbstractWizardPanel<Details>[] panelsFixed = new AbstractWizardPanel[5];
/*     */   
/*  28 */   private AbstractWizardPanel<Details>[] panelsCsv = new AbstractWizardPanel[5];
/*     */   
/*  30 */   private AbstractWizardPanel<Details>[] panelsMulti = new AbstractWizardPanel[7];
/*     */   
/*     */   private BasicLayoutCallback callbackClass;
/*     */   
/*  34 */   private ExternalRecord externalRecord = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WizardFileLayout(String fileName)
/*     */   {
/*  45 */     this(new ReFrame("", "File Wizard", "", null), fileName, null, false, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T extends Component,  extends RootPaneContainer> WizardFileLayout(T frame, String fileName, BasicLayoutCallback callback, boolean alwaysShowCsv, boolean visible)
/*     */   {
/*  57 */     super(frame, new Details());
/*     */     
/*  59 */     ((Details)getWizardDetails()).filename = fileName;
/*  60 */     this.callbackClass = callback;
/*     */     
/*  62 */     AbsRowList typeList = new AbsRowList(0, 1, false, false).loadData(ExternalConversion.getTypes(0));
/*     */     
/*     */ 
/*  65 */     AbsRowList structureList = new ManagerRowList(LineIOProvider.getInstance(), true);
/*     */     
/*  67 */     ((Details)super.getWizardDetails()).layoutDirectory = Parameters.getFileName("CopybookDirectory");
/*     */     
/*     */ 
/*  70 */     this.panelsFixed[0] = new Pnl1File(structureList, typeList);
/*  71 */     this.panelsFixed[1] = new Pnl2FileFormat();
/*  72 */     this.panelsFixed[2] = new Pnl3Table(super.getMessage());
/*  73 */     this.panelsFixed[3] = new Pnl4Names(typeList);
/*  74 */     this.panelsFixed[4] = new Pnl5SaveFileLayout();
/*     */     
/*  76 */     this.panelsCsv[0] = this.panelsFixed[0];
/*  77 */     this.panelsCsv[1] = this.panelsFixed[1];
/*  78 */     this.panelsCsv[2] = new Pnl3CsvTable();
/*  79 */     this.panelsCsv[3] = new Pnl4CsvNames(typeList, false);
/*  80 */     this.panelsCsv[4] = this.panelsFixed[4];
/*     */     
/*  82 */     this.panelsMulti[0] = this.panelsFixed[0];
/*  83 */     this.panelsMulti[1] = this.panelsFixed[1];
/*  84 */     this.panelsMulti[2] = new Pnl3RecordTypeMF(typeList, getMessage());
/*  85 */     this.panelsMulti[3] = new Pnl4RecordNames();
/*  86 */     this.panelsMulti[4] = new Pnl5RecordTable(getMessage());
/*  87 */     this.panelsMulti[5] = new Pnl6RecordFieldNames(typeList);
/*  88 */     this.panelsMulti[6] = this.panelsFixed[4];
/*     */     
/*  90 */     super.setPanels(this.panelsFixed, visible);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void changePanel(int inc)
/*     */   {
/* 100 */     changePanel(inc, true);
/*     */   }
/*     */   
/*     */   public void changePanel(int inc, boolean visible)
/*     */   {
/* 105 */     if (getPanelNumber() == 0) {
/* 106 */       if (((Details)super.getWizardDetails()).recordType == 0) {
/* 107 */         super.setPanels(this.panelsFixed, visible);
/* 108 */       } else if (((Details)super.getWizardDetails()).recordType == 2) {
/* 109 */         super.setPanels(this.panelsMulti, visible);
/*     */       } else {
/* 111 */         super.setPanels(this.panelsCsv, visible);
/*     */       }
/*     */     }
/* 114 */     super.changePanel(inc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void finished(Details details)
/*     */   {
/* 125 */     if ("".equals(details.layoutName)) {
/* 126 */       super.getMessage().setText("Layout filename must be entered");
/*     */     } else {
/*     */       try
/*     */       {
/* 130 */         this.externalRecord = details.createRecordLayout();
/* 131 */         CopybookWriter w = (CopybookWriter)CopybookWriterManager.getInstance().get(details.layoutWriterIdx);
/*     */         
/*     */ 
/* 134 */         String dir = details.layoutDirectory;
/*     */         
/* 136 */         if ((dir != null) && (dir.length() > 0)) {
/* 137 */           dir = fixDirectory(dir);
/*     */           
/* 139 */           String copybookFile = w.writeCopyBook(dir, this.externalRecord, Common.getLogger());
/*     */           
/* 141 */           if (this.callbackClass != null) {
/* 142 */             this.callbackClass.setRecordLayout(this.externalRecord.getRecordId(), copybookFile, details.filename);
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (Exception ex) {
/* 147 */         super.getMessage().setText(ex.getMessage());
/* 148 */         Common.logMsgRaw(ex.getMessage(), ex);
/* 149 */         ex.printStackTrace();
/*     */       } finally {
/*     */         try {
/* 152 */           setClosed(true);
/*     */         }
/*     */         catch (Exception e) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static final String fixDirectory(String dir)
/*     */   {
/* 161 */     if ((dir != null) && (dir.length() > 0)) {
/* 162 */       while (dir.endsWith("*")) {
/* 163 */         dir = dir.substring(0, dir.length() - 1);
/*     */       }
/* 165 */       if ((!dir.endsWith("/")) && (!dir.endsWith("\\"))) {
/* 166 */         dir = dir + Common.FILE_SEPERATOR;
/*     */       }
/*     */     }
/* 169 */     return dir;
/*     */   }
/*     */   
/*     */   public ExternalRecord getExternalRecord() {
/* 173 */     return this.externalRecord;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/layoutWizard/WizardFileLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */