/*     */ package net.sf.RecordEditor.layoutWizard;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import javax.swing.DefaultCellEditor;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JEditorPane;
/*     */ import javax.swing.JPopupMenu;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import net.sf.JRecord.Common.FieldDetail;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.IO.AbstractLineReader;
/*     */ import net.sf.RecordEditor.utils.MenuPopupListener;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.lang.ReAbstractAction;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.CheckBoxTableRender;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ public class Pnl4RecordNames extends WizardPanel
/*     */ {
/*  28 */   private static final String[] COLUMN_NAMES = LangConversion.convertColHeading("LayoutWizard RecordNames", new String[] { "Record Name", "Default", "Include" });
/*     */   
/*     */ 
/*     */   private JEditorPane tips;
/*     */   
/*  33 */   private JTable recordTbl = new JTable();
/*     */   
/*     */   private Details currentDetails;
/*     */   
/*  37 */   private String lastFile = "";
/*     */   
/*     */   private MenuPopupListener popup;
/*     */   private RecordNames recordNamesMdl;
/*     */   private boolean rebuildRecords;
/*     */   
/*     */   public Pnl4RecordNames()
/*     */   {
/*  45 */     int height = Math.max(40, ReFrame.getDesktopHeight() - TIP_HEIGHT - 12 * SwingUtils.NORMAL_FIELD_HEIGHT);
/*     */     
/*     */ 
/*     */ 
/*  49 */     String formDescription = "This screen will display the first 60 lines of the file. <br>Indicate the <i>start</i> of a <b>field</b> by clicking on the starting column<br>Each succesive <b>field</b> will have alternating background color<p>To remove a <b>field</b> click on the starting column again.";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  54 */     this.tips = new JEditorPane("text/html", formDescription);
/*     */     
/*  56 */     setHelpURLre(Common.formatHelpURL("HlpLe04.htm#HDRWIZRECORDNAMES"));
/*  57 */     addComponentRE(1, 5, TIP_HEIGHT, BasePanel.GAP1, 2, 2, this.tips);
/*     */     
/*     */ 
/*     */ 
/*  61 */     addComponentRE(1, 5, height, BasePanel.GAP1, 2, 2, this.recordTbl);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  67 */     this.popup = new MenuPopupListener();
/*  68 */     this.popup.setTable(this.recordTbl);
/*  69 */     this.popup.getPopup().add(new ReAbstractAction("Clear Value") {
/*     */       public void actionPerformed(ActionEvent e) {
/*  71 */         int col = Pnl4RecordNames.this.popup.getPopupCol();
/*  72 */         int row = Pnl4RecordNames.this.popup.getPopupRow();
/*  73 */         RecordDefinition rec = (RecordDefinition)Pnl4RecordNames.this.currentDetails.recordDtlsFull.get(row);
/*     */         
/*  75 */         if (col < rec.getKeyValue().length) {
/*  76 */           rec.getKeyValue()[col] = null;
/*  77 */           Pnl4RecordNames.this.recordNamesMdl.fireTableCellUpdated(row, col);
/*  78 */           Pnl4RecordNames.this.rebuildRecords = true;
/*     */         }
/*     */       }
/*  81 */     });
/*  82 */     this.popup.getPopup().add(new ReAbstractAction("Reset Value") {
/*     */       public void actionPerformed(ActionEvent e) {
/*  84 */         int col = Pnl4RecordNames.this.popup.getPopupCol();
/*  85 */         int row = Pnl4RecordNames.this.popup.getPopupRow();
/*  86 */         RecordDefinition rec = (RecordDefinition)Pnl4RecordNames.this.currentDetails.recordDtlsFull.get(row);
/*     */         
/*  88 */         System.out.print(" == Clear: " + row + ", " + col + " " + rec.getKeyValue().length);
/*     */         
/*  90 */         if (col < rec.getKeyValue().length) {
/*  91 */           rec.getKeyValue()[col] = rec.keyValueHold[col];
/*  92 */           Pnl4RecordNames.this.recordNamesMdl.fireTableCellUpdated(row, col);
/*  93 */           Pnl4RecordNames.this.rebuildRecords = true;
/*  94 */           System.out.print(" ***");
/*     */         }
/*  96 */         System.out.println();
/*     */       }
/*  98 */     });
/*  99 */     this.popup.getPopup().add(new ReAbstractAction("Generate Record Names") {
/*     */       public void actionPerformed(ActionEvent e) {
/* 101 */         for (RecordDefinition rec : Pnl4RecordNames.this.currentDetails.recordDtlsFull) {
/* 102 */           if ("".equals(rec.name)) {
/* 103 */             rec.name = rec.getStringKey("");
/*     */           }
/*     */         }
/* 106 */         Pnl4RecordNames.this.recordNamesMdl.fireTableDataChanged();
/*     */       }
/* 108 */     });
/* 109 */     this.recordTbl.addMouseListener(this.popup);
/*     */   }
/*     */   
/*     */   public Details getValues() throws Exception
/*     */   {
/* 114 */     Common.stopCellEditing(this.recordTbl);
/*     */     
/* 116 */     if (this.rebuildRecords) {}
/*     */     
/*     */ 
/*     */ 
/* 120 */     this.currentDetails.recordDtls.clear();
/* 121 */     for (RecordDefinition rd : this.currentDetails.recordDtlsFull) {
/* 122 */       if (rd.include.booleanValue()) {
/* 123 */         this.currentDetails.recordDtls.add(rd);
/*     */       }
/*     */     }
/*     */     
/* 127 */     return this.currentDetails;
/*     */   }
/*     */   
/*     */   public void setValues(Details detail) throws Exception
/*     */   {
/* 132 */     int noKeys = detail.keyFields.size();
/*     */     
/* 134 */     FieldDetail[] keyDef = new FieldDetail[noKeys];
/*     */     
/*     */ 
/* 137 */     for (int i = 0; i < noKeys; i++) {
/* 138 */       KeyField k = (KeyField)detail.keyFields.get(i);
/* 139 */       keyDef[i] = new FieldDetail("", "", k.keyType.intValue(), 0, detail.fontName, 0, "");
/*     */       
/* 141 */       keyDef[i].setPosLen(k.keyStart, k.keyLength);
/*     */     }
/*     */     
/* 144 */     this.currentDetails = detail;
/*     */     
/* 146 */     if (!this.lastFile.equals(detail.filename))
/*     */     {
/* 148 */       HashMap<String, RecordDefinition> keyToRecordMap = new HashMap();
/* 149 */       AbstractLineReader<?> reader = detail.getReader();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 154 */       this.lastFile = detail.filename;
/* 155 */       detail.recordDtlsFull.clear();
/*     */       AbstractLine line;
/* 157 */       while ((line = reader.read()) != null) {
/* 158 */         Object[] key = new Object[noKeys];
/*     */         
/* 160 */         boolean keyPresent = false;
/* 161 */         for (int i = 0; i < noKeys; i++) {
/* 162 */           key[i] = line.getField(keyDef[i]);
/* 163 */           if (key[i] != null) {
/* 164 */             keyPresent = true;
/*     */           }
/*     */         }
/* 167 */         if (keyPresent) {
/* 168 */           String keyStr = RecordDefinition.getStringKey(key);
/* 169 */           if (keyToRecordMap.containsKey(keyStr)) {
/* 170 */             RecordDefinition recDef = (RecordDefinition)keyToRecordMap.get(keyStr);
/* 171 */             if (recDef.numRecords < recDef.records.length) {
/* 172 */               recDef.records[(recDef.numRecords++)] = line.getData();
/*     */             }
/*     */           } else {
/* 175 */             RecordDefinition recDef = new RecordDefinition();
/* 176 */             recDef.setKeyValue(key);
/* 177 */             recDef.records[(recDef.numRecords++)] = line.getData();
/*     */             
/* 179 */             recDef.addKeyField(detail, true);
/*     */             
/*     */ 
/* 182 */             keyToRecordMap.put(keyStr, recDef);
/* 183 */             detail.recordDtlsFull.add(recDef);
/*     */           }
/*     */         }
/*     */       }
/* 187 */       reader.close();
/*     */     }
/*     */     
/* 190 */     this.recordNamesMdl = new RecordNames(null);
/* 191 */     this.recordTbl.setModel(this.recordNamesMdl);
/*     */     
/*     */ 
/* 194 */     TableColumn tc = this.recordTbl.getColumnModel().getColumn(noKeys + 2);
/* 195 */     tc.setCellRenderer(new CheckBoxTableRender());
/* 196 */     tc.setCellEditor(new DefaultCellEditor(new JCheckBox()));
/*     */     
/* 198 */     tc = this.recordTbl.getColumnModel().getColumn(noKeys + 1);
/* 199 */     tc.setCellRenderer(new CheckBoxTableRender());
/* 200 */     tc.setCellEditor(new DefaultCellEditor(new JCheckBox()));
/*     */     
/* 202 */     this.rebuildRecords = false;
/*     */   }
/*     */   
/*     */ 
/*     */   private class RecordNames
/*     */     extends javax.swing.table.AbstractTableModel
/*     */   {
/*     */     private RecordNames() {}
/*     */     
/*     */ 
/*     */     public String getColumnName(int column)
/*     */     {
/* 214 */       if (column < Pnl4RecordNames.this.currentDetails.keyFields.size()) {
/* 215 */         return "key " + (column + 1);
/*     */       }
/* 217 */       return Pnl4RecordNames.COLUMN_NAMES[(column - Pnl4RecordNames.this.currentDetails.keyFields.size())];
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setValueAt(Object value, int rowIndex, int columnIndex)
/*     */     {
/* 225 */       if (columnIndex >= Pnl4RecordNames.this.currentDetails.keyFields.size())
/*     */       {
/* 227 */         RecordDefinition rec = (RecordDefinition)Pnl4RecordNames.this.currentDetails.recordDtlsFull.get(rowIndex);
/*     */         
/* 229 */         switch (columnIndex - Pnl4RecordNames.this.currentDetails.keyFields.size()) {
/*     */         case 1: 
/* 231 */           rec.defaultRec = ((Boolean)value);
/* 232 */           break;
/*     */         case 2: 
/* 234 */           rec.include = ((Boolean)value);
/* 235 */           break;
/*     */         default: 
/* 237 */           String val = "";
/* 238 */           if (value != null) {
/* 239 */             val = value.toString();
/*     */           }
/* 241 */           rec.name = val;
/*     */         }
/*     */         
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getColumnCount()
/*     */     {
/* 252 */       return Pnl4RecordNames.this.currentDetails.keyFields.size() + 3;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getRowCount()
/*     */     {
/* 260 */       return Pnl4RecordNames.this.currentDetails.recordDtlsFull.size();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isCellEditable(int rowIndex, int columnIndex)
/*     */     {
/* 268 */       return columnIndex >= Pnl4RecordNames.this.currentDetails.keyFields.size();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Object getValueAt(int row, int col)
/*     */     {
/* 276 */       RecordDefinition rec = (RecordDefinition)Pnl4RecordNames.this.currentDetails.recordDtlsFull.get(row);
/* 277 */       if (col >= Pnl4RecordNames.this.currentDetails.keyFields.size()) {
/* 278 */         switch (col - Pnl4RecordNames.this.currentDetails.keyFields.size()) {
/* 279 */         case 1:  return rec.defaultRec;
/* 280 */         case 2:  return rec.include; }
/* 281 */         return rec.name;
/*     */       }
/*     */       
/* 284 */       if (rec.getKeyValue().length <= col) {
/* 285 */         return null;
/*     */       }
/* 287 */       if (rec.getKeyValue()[col] == null) {
/* 288 */         return "[cleared]";
/*     */       }
/* 290 */       return rec.getKeyValue()[col];
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/layoutWizard/Pnl4RecordNames.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */