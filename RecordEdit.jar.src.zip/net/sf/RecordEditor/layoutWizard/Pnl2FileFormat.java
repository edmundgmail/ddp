/*     */ package net.sf.RecordEditor.layoutWizard;
/*     */ 
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JTextField;
/*     */ import net.sf.RecordEditor.utils.charsets.FontCombo;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.swing.BmKeyedComboBox;
/*     */ import net.sf.RecordEditor.utils.wizards.AbstractWizardPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Pnl2FileFormat
/*     */   extends PnlUnknownFileFormat
/*     */   implements AbstractWizardPanel<Details>
/*     */ {
/*     */   private Details wizardDetails;
/*     */   private int initRecLength;
/*     */   private int initFormat;
/*     */   
/*     */   public Pnl2FileFormat()
/*     */   {
/*  23 */     setHelpURLre(Common.formatHelpURL("HlpLe04.htm#HDRWIZFILESTRUCTURE"));
/*     */   }
/*     */   
/*     */   public JComponent getComponent()
/*     */   {
/*  28 */     return this;
/*     */   }
/*     */   
/*     */   public Details getValues()
/*     */     throws Exception
/*     */   {
/*  34 */     this.wizardDetails.fileStructure = super.getFileStructure();
/*  35 */     this.wizardDetails.fontName = this.fontNameCombo.getText();
/*  36 */     this.wizardDetails.textPct = this.textPct;
/*     */     
/*     */ 
/*  39 */     if (this.wizardDetails.fileStructure == 2) {
/*     */       int len;
/*  41 */       try { len = Integer.parseInt(this.lengthTxt.getText());
/*     */       } catch (Exception e) {
/*  43 */         this.lengthTxt.requestFocus();
/*  44 */         throw new Exception("Invalid Record Length: " + e.getMessage());
/*     */       }
/*     */       
/*  47 */       if (len <= 0) {
/*  48 */         this.lengthTxt.requestFocus();
/*  49 */         throw new Exception("Invalid Record Length: " + len);
/*     */       }
/*  51 */       this.wizardDetails.recordLength = len;
/*     */     } else {
/*     */       try {
/*  54 */         int len = Integer.parseInt(this.lengthTxt.getText());
/*  55 */         if (len >= 0) {
/*  56 */           this.wizardDetails.recordLength = len;
/*     */         }
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*     */     
/*  62 */     if ((this.initFormat != this.wizardDetails.fileStructure) || ((this.initFormat == 2) && (this.initRecLength != this.wizardDetails.recordLength)))
/*     */     {
/*     */ 
/*  65 */       this.wizardDetails.setFieldSearch();
/*     */     }
/*     */     
/*  68 */     return this.wizardDetails;
/*     */   }
/*     */   
/*     */   public void setValues(Details detail) throws Exception
/*     */   {
/*  73 */     this.wizardDetails = detail;
/*     */     
/*  75 */     this.fontNameCombo.setText(detail.fontName);
/*     */     
/*  77 */     this.initFormat = detail.fileStructure;
/*  78 */     this.initRecLength = this.wizardDetails.recordLength;
/*     */     
/*  80 */     if (this.wizardDetails.recordLength > 0) {
/*  81 */       this.lengthTxt.setText(Integer.toString(this.wizardDetails.recordLength));
/*     */     }
/*     */     
/*  84 */     super.open(detail.filename);
/*     */     
/*  86 */     if (detail.fileStructure == 2) {
/*  87 */       int structure = super.getFileStructure();
/*  88 */       switch (structure) {
/*     */       case 1: 
/*     */       case 9: 
/*     */       case 90: 
/*  92 */         this.initFormat = 2;
/*  93 */         this.structureCombo.setSelectedItem(Integer.valueOf(2));
/*     */       }
/*     */       
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean skip()
/*     */   {
/* 105 */     boolean ret = true;
/*     */     
/*     */ 
/* 108 */     switch (this.wizardDetails.fileStructure) {
/*     */     case 2: 
/*     */     case 21: 
/* 111 */       ret = false;
/* 112 */       break;
/*     */     case 0: 
/* 114 */       int fs = super.getFileStructure();
/* 115 */       switch (fs) {
/*     */       case 2: 
/*     */       case 4: 
/*     */       case 5: 
/*     */       case 7: 
/*     */       case 8: 
/*     */       case 31: 
/* 122 */         this.wizardDetails.fileStructure = fs;
/* 123 */         ret = false;
/*     */       }
/*     */       break;
/*     */     }
/* 127 */     return ret;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/layoutWizard/Pnl2FileFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */