/*     */ package net.sf.RecordEditor.layoutWizard;
/*     */ 
/*     */ import java.awt.event.FocusAdapter;
/*     */ import java.awt.event.FocusEvent;
/*     */ import java.awt.event.FocusListener;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.JEditorPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.text.JTextComponent;
/*     */ import net.sf.RecordEditor.re.util.BuildTypeComboList;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.swing.AbsRowList;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.TreeCombo;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.TreeComboItem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Pnl3RecordType
/*     */   extends WizardPanel
/*     */ {
/*  50 */   private static final int FILE_HEIGHT = SwingUtils.TABLE_ROW_HEIGHT * 15 - 3;
/*     */   
/*     */   private JEditorPane tips;
/*     */   
/*  54 */   private JTextField nameTxt = new JTextField();
/*  55 */   private JTextField startTxt = new JTextField();
/*  56 */   private JTextField lengthTxt = new JTextField();
/*     */   
/*     */ 
/*     */   private TreeCombo typeCombo;
/*     */   
/*     */   private ColumnSelector columnSelector;
/*     */   
/*  63 */   private RecordDefinition recordDef = new RecordDefinition();
/*     */   
/*     */ 
/*  66 */   FocusListener focusListner = new FocusAdapter()
/*     */   {
/*     */ 
/*     */ 
/*     */     public void focusLost(FocusEvent e)
/*     */     {
/*     */ 
/*  73 */       super.focusLost(e);
/*     */       
/*  75 */       Pnl3RecordType.this.setSelectedFieldOnTable();
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Pnl3RecordType(AbsRowList typeList, JTextComponent message)
/*     */   {
/*  87 */     this.columnSelector = new ColumnSelector(message);
/*     */     
/*  89 */     this.typeCombo = new TreeCombo(BuildTypeComboList.getList(typeList));
/*     */     
/*  91 */     String formDescription = LangConversion.convertId(2, "FileWizard_3", "This screen will display the first 60 lines of the file. <br>Indicate the <i>start</i> of the <b>Record-Type field</b> by clicking on the starting column<br>Then click on the start of the Next Field.<br>To remove a position click on it again.");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  97 */     this.tips = new JEditorPane("text/html", formDescription);
/*     */     
/*  99 */     setHelpURLre(Common.formatHelpURL("HlpLe04.htm#HDRWIZRECORDTYPE"));
/*     */     
/* 101 */     addComponentRE(1, 5, TIP_HEIGHT, BasePanel.GAP0, 2, 2, this.tips);
/*     */     
/*     */ 
/*     */ 
/* 105 */     addLineRE("Name", this.nameTxt);
/* 106 */     addLineRE("Field Start", this.startTxt);
/* 107 */     addLineRE("Field Length", this.lengthTxt);
/* 108 */     addLineRE("Type", this.typeCombo);
/* 109 */     setGapRE(BasePanel.GAP0);
/*     */     
/* 111 */     addLineRE("Show Hex", this.columnSelector.hexChk);
/* 112 */     setGapRE(BasePanel.GAP0);
/* 113 */     addComponentRE(1, 5, FILE_HEIGHT, BasePanel.GAP1, 2, 2, this.columnSelector.fileTbl);
/*     */     
/*     */ 
/*     */ 
/* 117 */     this.startTxt.addFocusListener(this.focusListner);
/* 118 */     this.lengthTxt.addFocusListener(this.focusListner);
/*     */     
/* 120 */     this.columnSelector.addMouseListner(new MouseAdapter() {
/*     */       public void mousePressed(MouseEvent m) {
/* 122 */         int col = Pnl3RecordType.this.columnSelector.fileTbl.columnAtPoint(m.getPoint());
/* 123 */         Pnl3RecordType.this.columnSelector.columnSelected(col);
/* 124 */         Pnl3RecordType.this.checkSelectedFieldOnTable();
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   private void checkSelectedFieldOnTable()
/*     */   {
/* 131 */     if (this.recordDef.columnDtls.size() == 1) {
/* 132 */       setRecordTypeDetails(1, ((ColumnDetails)this.recordDef.columnDtls.get(0)).start);
/* 133 */     } else if (this.recordDef.columnDtls.size() == 2) {
/* 134 */       setRecordTypeDetails(((ColumnDetails)this.recordDef.columnDtls.get(0)).start, ((ColumnDetails)this.recordDef.columnDtls.get(1)).start);
/* 135 */     } else if (this.recordDef.columnDtls.size() > 2) {
/* 136 */       setRecordTypeDetails(((ColumnDetails)this.recordDef.columnDtls.get(1)).start, ((ColumnDetails)this.recordDef.columnDtls.get(2)).start);
/*     */     }
/*     */   }
/*     */   
/*     */   private void setSelectedFieldOnTable()
/*     */   {
/*     */     try {
/* 143 */       int start = Integer.parseInt(this.startTxt.getText());
/* 144 */       int length = Integer.parseInt(this.lengthTxt.getText());
/*     */       
/* 146 */       if ((start >= 1) && (length >= 1)) {
/* 147 */         this.recordDef.columnDtls.clear();
/* 148 */         if (start > 1) {
/* 149 */           this.recordDef.columnDtls.add(new ColumnDetails(start, this.columnSelector.getCurrentDetails().defaultType.intValue()));
/*     */         }
/*     */         
/*     */ 
/* 153 */         this.recordDef.columnDtls.add(new ColumnDetails(start + length, this.columnSelector.getCurrentDetails().defaultType.intValue()));
/*     */         
/*     */ 
/*     */ 
/* 157 */         this.columnSelector.setColorIndicator();
/*     */       }
/*     */     }
/*     */     catch (Exception e) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void setRecordTypeDetails(int start, int pos2)
/*     */   {
/* 167 */     this.startTxt.setText(Integer.toString(start));
/* 168 */     this.lengthTxt.setText(Integer.toString(pos2 - start));
/*     */   }
/*     */   
/*     */ 
/*     */   public Details getValues()
/*     */     throws Exception
/*     */   {
/* 175 */     Details ret = this.columnSelector.getCurrentDetails();
/* 176 */     KeyField k = ret.getMainKey();
/* 177 */     k.keyName = this.nameTxt.getText();
/* 178 */     k.keyStart = getInteger(this.startTxt);
/* 179 */     k.keyLength = getInteger(this.lengthTxt);
/* 180 */     k.keyType = ((Integer)this.typeCombo.getSelectedItem().key);
/*     */     
/* 182 */     return ret;
/*     */   }
/*     */   
/*     */   private int getInteger(JTextField fld) throws Exception
/*     */   {
/*     */     try {
/* 188 */       return Integer.parseInt(fld.getText());
/*     */     } catch (Exception e) {
/* 190 */       fld.requestFocus();
/* 191 */       throw e;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void setValues(Details detail)
/*     */     throws Exception
/*     */   {
/* 200 */     KeyField k = detail.getMainKey();
/* 201 */     this.columnSelector.readFile(detail, this.recordDef);
/* 202 */     this.columnSelector.setValues(detail, this.recordDef, false);
/*     */     
/* 204 */     this.nameTxt.setText(k.keyName);
/* 205 */     this.startTxt.setText(Integer.toString(k.keyStart));
/* 206 */     this.lengthTxt.setText(Integer.toString(k.keyLength));
/* 207 */     this.typeCombo.setSelectedKey(k.keyType.intValue());
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/layoutWizard/Pnl3RecordType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */