/*     */ package net.sf.RecordEditor.layoutWizard;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JEditorPane;
/*     */ import javax.swing.JScrollPane;
/*     */ import net.sf.JRecord.Common.RecordException;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.swing.AbsRowList;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Pnl6RecordFieldNames
/*     */   extends WizardPanel
/*     */ {
/*  42 */   private static final int COLUMN_HEIGHT = SwingUtils.TABLE_ROW_HEIGHT * 9;
/*  43 */   private static final int FILE_HEIGHT = SwingUtils.TABLE_ROW_HEIGHT * 15 / 2;
/*     */   
/*     */ 
/*     */   private ColumnNames columnNames;
/*     */   
/*  48 */   private RecordComboMgr recordMgr = new RecordComboMgr(new AbstractAction()
/*     */   {
/*     */ 
/*     */ 
/*     */     public void actionPerformed(ActionEvent arg0)
/*     */     {
/*     */ 
/*  55 */       Pnl6RecordFieldNames.this.changeRecord();
/*     */     }
/*  48 */   });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Pnl6RecordFieldNames(AbsRowList typeList)
/*     */   {
/*  68 */     String formDescription = LangConversion.convertId(2, "FileWizard_6_RecordNames", "This screen will display the Column Details (for each Record) and allow you to change them. <br>The Record controls which Records columns are displayed.");
/*     */     
/*     */ 
/*     */ 
/*  72 */     JEditorPane tips = new JEditorPane("text/html", formDescription);
/*     */     
/*  74 */     this.columnNames = new ColumnNames(typeList);
/*     */     
/*     */ 
/*  77 */     setHelpURLre(Common.formatHelpURL("HlpLe04.htm#HDRWIZ3M"));
/*  78 */     addComponentRE(1, 5, TIP_HEIGHT, BasePanel.GAP0, 2, 2, tips);
/*     */     
/*     */ 
/*     */ 
/*  82 */     addLineRE("Record", this.recordMgr.recordCombo);
/*  83 */     setGapRE(BasePanel.GAP0);
/*     */     
/*  85 */     addComponentRE(1, 5, COLUMN_HEIGHT, BasePanel.GAP0, 2, 2, new JScrollPane(this.columnNames.columnTbl));
/*     */     
/*     */ 
/*  88 */     addComponentRE(1, 5, FILE_HEIGHT, BasePanel.GAP0, 2, 2, new JScrollPane(this.columnNames.fileTbl));
/*     */     
/*     */ 
/*     */ 
/*  92 */     addMessageRE();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Details getValues()
/*     */     throws Exception
/*     */   {
/* 103 */     Details detail = this.columnNames.getValues();
/*     */     
/* 105 */     for (int i = 0; i < detail.recordDtls.size(); i++) {
/* 106 */       RecordDefinition recdef = (RecordDefinition)detail.recordDtls.get(i);
/* 107 */       if (!recdef.displayedFieldNames) {
/* 108 */         this.recordMgr.recordCombo.setSelectedIndex(i);
/* 109 */         throw new RecordException("You must define the field Names in all Records, please update: {0}", recdef.name);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 115 */     return detail;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setValues(Details detail)
/*     */     throws Exception
/*     */   {
/* 123 */     RecordDefinition recDef = (RecordDefinition)detail.recordDtls.get(0);
/* 124 */     this.columnNames.setValues(detail, recDef);
/* 125 */     recDef.displayedFieldNames = true;
/*     */     
/* 127 */     this.recordMgr.load(detail.recordDtls);
/*     */   }
/*     */   
/*     */   private void changeRecord() {
/* 131 */     setMessageRawTxtRE("");
/*     */     try {
/* 133 */       Details detail = this.columnNames.getValues();
/* 134 */       RecordDefinition recDef = (RecordDefinition)detail.recordDtls.get(this.recordMgr.recordCombo.getSelectedIndex());
/* 135 */       this.columnNames.setValues(detail, recDef);
/* 136 */       recDef.displayedFieldNames = true;
/*     */     } catch (Exception e) {
/* 138 */       setMessageTxtRE("Error Changing Record:", e.getMessage());
/* 139 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/layoutWizard/Pnl6RecordFieldNames.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */