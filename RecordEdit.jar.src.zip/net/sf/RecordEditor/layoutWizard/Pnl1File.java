/*     */ package net.sf.RecordEditor.layoutWizard;
/*     */ 
/*     */ import java.awt.GridLayout;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.JEditorPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JRadioButton;
/*     */ import net.sf.RecordEditor.re.openFile.RecentFiles;
/*     */ import net.sf.RecordEditor.re.util.BuildTypeComboList;
/*     */ import net.sf.RecordEditor.utils.charsets.FontCombo;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.swing.AbsRowList;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.BmKeyedComboBox;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.TreeCombo;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.TreeComboFileSelect;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.TreeComboItem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Pnl1File
/*     */   extends WizardPanel
/*     */ {
/*     */   private JEditorPane tips;
/*  48 */   private TreeComboFileSelect filenameFld = new TreeComboFileSelect(true, false, true, RecentFiles.getMainRecentFile());
/*     */   
/*     */ 
/*  51 */   private JRadioButton fixedLengthBtn = new JRadioButton("Fixed Length Fields");
/*  52 */   private JRadioButton delimitedBtn = new JRadioButton("Delimited Fields");
/*  53 */   private JRadioButton fixedMultiBtn = new JRadioButton("Multiple Records (fixed length)");
/*     */   
/*     */   private BmKeyedComboBox fileStructure;
/*     */   
/*  57 */   private FontCombo fontname = new FontCombo();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private TreeCombo defaultType;
/*     */   
/*     */ 
/*     */ 
/*     */   private Details wizardDetail;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Pnl1File(AbsRowList structureList, AbsRowList typeList)
/*     */   {
/*  73 */     this.defaultType = new TreeCombo(BuildTypeComboList.getList(typeList));
/*     */     
/*  75 */     this.fileStructure = new BmKeyedComboBox(structureList, false);
/*     */     
/*  77 */     String formDescription = LangConversion.convertId(2, "FileWizard_1", "This wizard will build a <b>Record-Layout</b> from a sample file. <p> you need to enter a<ol><li>sample file in the new layout</li><li>the file structure (use <b>Default Reader</b> for standard windows / Unix files)  for unknown file format use <b>Unknown Format</b></li><li>the new layout name</li>");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  85 */     this.tips = new JEditorPane("text/html", formDescription);
/*     */     
/*  87 */     ButtonGroup grp = new ButtonGroup();
/*  88 */     JPanel recordTypePnl = new JPanel(new GridLayout(2, 2));
/*  89 */     addRadioGrp(recordTypePnl, grp, this.fixedLengthBtn);
/*  90 */     addRadioGrp(recordTypePnl, grp, this.delimitedBtn);
/*     */     
/*  92 */     addRadioGrp(recordTypePnl, grp, this.fixedMultiBtn);
/*     */     
/*  94 */     this.fixedLengthBtn.setSelected(true);
/*     */     
/*     */ 
/*  97 */     setHelpURLre(Common.formatHelpURL("HlpLe04.htm"));
/*  98 */     addComponentRE(1, 5, TIP_HEIGHT, BasePanel.GAP3, 2, 2, this.tips);
/*     */     
/*     */ 
/* 101 */     setGapRE(BasePanel.GAP1);
/*     */     
/* 103 */     addLineRE("File Name", this.filenameFld);
/* 104 */     addLineRE("File Structure", this.fileStructure);
/* 105 */     setGapRE(BasePanel.GAP0);
/* 106 */     addLineRE("Record Type", recordTypePnl);
/* 107 */     setHeightRE(-2.0D);
/* 108 */     setGapRE(BasePanel.GAP0);
/*     */     
/* 110 */     addLineRE("Font Name", this.fontname);
/* 111 */     addLineRE("Default Type", this.defaultType);
/* 112 */     setGapRE(BasePanel.GAP1);
/*     */   }
/*     */   
/*     */ 
/*     */   private void addRadioGrp(JPanel pnl, ButtonGroup grp, JRadioButton btn1)
/*     */   {
/* 118 */     grp.add(btn1);
/*     */     
/* 120 */     pnl.add(btn1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final Details getValues()
/*     */     throws Exception
/*     */   {
/* 128 */     this.wizardDetail.filename = this.filenameFld.getText();
/* 129 */     this.wizardDetail.fileStructure = ((Integer)this.fileStructure.getSelectedItem()).intValue();
/*     */     
/*     */     try
/*     */     {
/* 133 */       this.wizardDetail.defaultType = ((Integer)this.defaultType.getSelectedItem().key);
/*     */     }
/*     */     catch (Exception e) {}
/* 136 */     this.wizardDetail.fontName = this.fontname.getText();
/*     */     
/*     */ 
/* 139 */     if ("".equals(this.wizardDetail.filename)) {
/* 140 */       this.filenameFld.requestFocus();
/* 141 */       throw new Exception("You must enter a file name");
/*     */     }
/*     */     
/* 144 */     if (this.wizardDetail.fileStructure == 51) {
/* 145 */       this.delimitedBtn.setSelected(true);
/*     */     }
/*     */     
/* 148 */     this.wizardDetail.recordType = 0;
/* 149 */     if (this.delimitedBtn.isSelected()) {
/* 150 */       this.wizardDetail.recordType = 1;
/* 151 */     } else if (this.fixedMultiBtn.isSelected()) {
/* 152 */       this.wizardDetail.recordType = 2;
/*     */     }
/* 154 */     return this.wizardDetail;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setValues(Details detail)
/*     */   {
/* 162 */     this.wizardDetail = detail;
/*     */     
/* 164 */     this.filenameFld.setText(detail.filename);
/* 165 */     this.fileStructure.setSelectedItem(Integer.valueOf(detail.fileStructure));
/*     */     
/* 167 */     this.fontname.setText(detail.fontName);
/* 168 */     this.defaultType.setSelectedKey(detail.defaultType.intValue());
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/layoutWizard/Pnl1File.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */