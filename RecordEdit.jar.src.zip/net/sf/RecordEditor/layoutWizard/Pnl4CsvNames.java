/*     */ package net.sf.RecordEditor.layoutWizard;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.DefaultCellEditor;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JEditorPane;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.table.AbstractTableModel;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import net.sf.RecordEditor.re.util.BuildTypeComboList;
/*     */ import net.sf.RecordEditor.re.util.csv.CsvSelectionTblMdl;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.swing.AbsRowList;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.CheckBoxTableRender;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.TreeComboItem;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.TreeComboRendor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Pnl4CsvNames
/*     */   extends WizardPanel
/*     */ {
/*  50 */   private static final int COLUMN_HEIGHT = SwingUtils.STANDARD_FONT_HEIGHT * 25 / 2;
/*  51 */   private static final int FILE_HEIGHT = SwingUtils.STANDARD_FONT_HEIGHT * 8 + 4;
/*     */   
/*     */   private static final int NAME_WIDTH = 170;
/*  54 */   private static final int INCLUDE_WIDTH = SwingUtils.STANDARD_FONT_WIDTH * 3 + 3;
/*  55 */   private static final int TYPE_WIDTH = SwingUtils.STANDARD_FONT_WIDTH * 18;
/*     */   
/*     */   private static final int COL_ADJUST_AMOUNT = 2;
/*     */   
/*     */   private JEditorPane tips;
/*     */   
/*     */   private ColumnTblModel columnMdl;
/*     */   private CsvSelTblMdl fileMdl;
/*  63 */   private JTable columnTbl = new JTable();
/*  64 */   private JTable fileTbl = new JTable();
/*     */   
/*     */ 
/*     */ 
/*     */   private TreeComboRendor typeRendor;
/*     */   
/*     */ 
/*     */ 
/*     */   private TreeComboRendor typeEditor;
/*     */   
/*     */ 
/*     */   private Details currentDetails;
/*     */   
/*     */ 
/*     */   private boolean alwayShow;
/*     */   
/*     */ 
/*     */ 
/*     */   public Pnl4CsvNames(AbsRowList typeList, boolean alwayShowScreen)
/*     */   {
/*  84 */     TreeComboItem[] typeCombolist = BuildTypeComboList.getList(typeList);
/*  85 */     String formDescription = LangConversion.convertId(2, "FileWizard_4_csv", "This screen will display the Column Details and allow you to change them. ");
/*     */     
/*     */ 
/*     */ 
/*  89 */     this.alwayShow = alwayShowScreen;
/*  90 */     this.tips = new JEditorPane("text/html", formDescription);
/*     */     
/*  92 */     this.columnTbl.setRowHeight(SwingUtils.COMBO_TABLE_ROW_HEIGHT);
/*  93 */     this.columnTbl.setAutoResizeMode(0);
/*  94 */     this.fileTbl.setAutoResizeMode(0);
/*     */     
/*  96 */     this.typeRendor = BuildTypeComboList.getTreeComboRender(typeCombolist);
/*  97 */     this.typeEditor = BuildTypeComboList.getTreeComboRender(typeCombolist);
/*     */     
/*     */ 
/* 100 */     setHelpURLre(Common.formatHelpURL("HlpLe04.htm#HDRWIZ5"));
/* 101 */     addComponentRE(1, 5, TIP_HEIGHT, BasePanel.GAP3, 2, 2, this.tips);
/*     */     
/*     */ 
/* 104 */     setGapRE(BasePanel.GAP1);
/* 105 */     addComponentRE(1, 5, COLUMN_HEIGHT, BasePanel.GAP3, 2, 2, new JScrollPane(this.columnTbl));
/*     */     
/*     */ 
/* 108 */     setGapRE(BasePanel.GAP1);
/* 109 */     addComponentRE(1, 5, FILE_HEIGHT, BasePanel.GAP3, 2, 2, new JScrollPane(this.fileTbl));
/*     */     
/*     */ 
/* 112 */     setGapRE(BasePanel.GAP1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final boolean skip()
/*     */   {
/* 119 */     return (!this.alwayShow) && (this.currentDetails.fieldNamesOnLine);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final Details getValues()
/*     */     throws Exception
/*     */   {
/* 127 */     Common.stopCellEditing(this.columnTbl);
/*     */     
/* 129 */     return this.currentDetails;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void setValues(Details detail)
/*     */     throws Exception
/*     */   {
/* 137 */     this.currentDetails = detail;
/*     */     
/*     */ 
/* 140 */     setValues_200_SetupColumnTable();
/* 141 */     setValues_300_SetupFileTable();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setValues_200_SetupColumnTable()
/*     */   {
/* 160 */     this.columnMdl = new ColumnTblModel(this.currentDetails.standardRecord.columnDtls);
/* 161 */     this.columnTbl.setModel(this.columnMdl);
/*     */     
/* 163 */     TableColumnModel tcm = this.columnTbl.getColumnModel();
/*     */     
/* 165 */     tcm.getColumn(0).setPreferredWidth(170);
/*     */     
/* 167 */     TableColumn tc = tcm.getColumn(2);
/* 168 */     tc.setPreferredWidth(TYPE_WIDTH);
/* 169 */     tc.setCellRenderer(this.typeRendor);
/* 170 */     tc.setCellEditor(this.typeEditor);
/*     */     
/* 172 */     tc = tcm.getColumn(3);
/* 173 */     tc.setPreferredWidth(INCLUDE_WIDTH);
/* 174 */     tc.setCellRenderer(new CheckBoxTableRender());
/* 175 */     tc.setCellEditor(new DefaultCellEditor(new JCheckBox()));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setValues_300_SetupFileTable()
/*     */   {
/* 188 */     this.fileMdl = new CsvSelTblMdl(null);
/* 189 */     this.fileMdl.setLines(this.currentDetails.standardRecord.records, this.currentDetails.fontName);
/* 190 */     this.fileMdl.setLines2display(this.currentDetails.standardRecord.numRecords);
/* 191 */     this.fileMdl.setSeperator(this.currentDetails.actualSeperator);
/* 192 */     this.fileMdl.setQuote(this.currentDetails.actualQuote);
/* 193 */     this.fileMdl.setupColumnCount();
/* 194 */     this.fileMdl.setHideFirstLine(this.currentDetails.fieldNamesOnLine);
/*     */     
/* 196 */     this.fileTbl.setModel(this.fileMdl);
/* 197 */     this.fileMdl.fireTableDataChanged();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static int adjustColumn(int col)
/*     */   {
/* 208 */     if (col < 2)
/* 209 */       return col;
/* 210 */     if (col == 2) {
/* 211 */       return col + 1;
/*     */     }
/* 213 */     return col + 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private class ColumnTblModel
/*     */     extends AbstractTableModel
/*     */   {
/*     */     private ArrayList<ColumnDetails> columns;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public ColumnTblModel()
/*     */     {
/* 236 */       this.columns = tblColumns;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public final int getColumnCount()
/*     */     {
/* 243 */       return 4;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public final int getRowCount()
/*     */     {
/* 250 */       return this.columns.size();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public final Object getValueAt(int rowIndex, int columnIndex)
/*     */     {
/* 257 */       ColumnDetails colDtls = (ColumnDetails)this.columns.get(rowIndex);
/*     */       
/* 259 */       return colDtls.getValue(Pnl4CsvNames.adjustColumn(columnIndex));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public final String getColumnName(int column)
/*     */     {
/* 266 */       return ColumnDetails.getColumnName(Pnl4CsvNames.adjustColumn(column));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public final boolean isCellEditable(int rowIndex, int columnIndex)
/*     */     {
/* 274 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public final void setValueAt(Object aValue, int rowIndex, int columnIndex)
/*     */     {
/* 282 */       ColumnDetails colDtls = (ColumnDetails)this.columns.get(rowIndex);
/* 283 */       int col = Pnl4CsvNames.adjustColumn(columnIndex);
/*     */       try {
/* 285 */         colDtls.setValue(col, aValue);
/* 286 */         if (col == 0) {
/* 287 */           Pnl4CsvNames.this.fileMdl.fireTableStructureChanged();
/*     */         }
/*     */       } catch (Exception e) {
/* 290 */         Common.logMsgRaw(e.getMessage(), null);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private class CsvSelTblMdl
/*     */     extends CsvSelectionTblMdl
/*     */   {
/*     */     private CsvSelTblMdl() {}
/*     */     
/*     */     public final String getColumnName(int col)
/*     */     {
/* 302 */       return ((ColumnDetails)Pnl4CsvNames.this.currentDetails.standardRecord.columnDtls.get(col)).name;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/layoutWizard/Pnl4CsvNames.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */