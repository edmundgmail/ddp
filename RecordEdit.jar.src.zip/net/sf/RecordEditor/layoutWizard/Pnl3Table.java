/*    */ package net.sf.RecordEditor.layoutWizard;
/*    */ 
/*    */ import javax.swing.JEditorPane;
/*    */ import javax.swing.text.JTextComponent;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*    */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*    */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Pnl3Table
/*    */   extends WizardPanel
/*    */ {
/* 42 */   private static final int FILE_HEIGHT = SwingUtils.TABLE_ROW_HEIGHT * 15 - 3;
/*    */   
/*    */ 
/*    */ 
/*    */   public int stdLineHeight;
/*    */   
/*    */ 
/*    */   private JEditorPane tips;
/*    */   
/*    */ 
/*    */   private ColumnSelector columnSelector;
/*    */   
/*    */ 
/*    */ 
/*    */   public Pnl3Table(JTextComponent msg)
/*    */   {
/* 58 */     this.columnSelector = new ColumnSelector(msg);
/*    */     
/* 60 */     String formDescription = LangConversion.convertId(2, "FileWizard_3b", "This screen will display the first 60 lines of the file. <br>Indicate the <i>start</i> of a <b>field</b> by clicking on the starting column<br>Each succesive <b>field</b> will have alternating background color<p>To remove a <b>field</b> click on the starting column again.");
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 66 */     this.tips = new JEditorPane("text/html", formDescription);
/*    */     
/* 68 */     setHelpURLre(Common.formatHelpURL("HlpLe04.htm#HDRWIZ2"));
/* 69 */     addComponentRE(1, 5, TIP_HEIGHT, BasePanel.GAP0, 2, 2, this.tips);
/*    */     
/*    */ 
/*    */ 
/* 73 */     this.columnSelector.addFields(this, FILE_HEIGHT);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 81 */     this.columnSelector.addMouseListner();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Details getValues()
/*    */     throws Exception
/*    */   {
/* 89 */     return this.columnSelector.getCurrentDetails();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public final void setValues(Details detail)
/*    */     throws Exception
/*    */   {
/* 97 */     this.columnSelector.readFile(detail, detail.standardRecord);
/* 98 */     this.columnSelector.setValues(detail, detail.standardRecord, true);
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/layoutWizard/Pnl3Table.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */