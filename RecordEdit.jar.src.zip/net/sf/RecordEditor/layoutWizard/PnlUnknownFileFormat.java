/*     */ package net.sf.RecordEditor.layoutWizard;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.FocusAdapter;
/*     */ import java.awt.event.FocusEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JEditorPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import net.sf.JRecord.ByteIO.AbstractByteReader;
/*     */ import net.sf.JRecord.ByteIO.ByteIOProvider;
/*     */ import net.sf.JRecord.ByteIO.FixedLengthByteReader;
/*     */ import net.sf.JRecord.ByteIO.TextReader;
/*     */ import net.sf.JRecord.IO.LineIOProvider;
/*     */ import net.sf.RecordEditor.utils.charsets.FontCombo;
/*     */ import net.sf.RecordEditor.utils.edit.ManagerRowList;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.BmKeyedComboBox;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.tblModels.LineArrayModel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PnlUnknownFileFormat
/*     */   extends BaseHelpPanel
/*     */ {
/*  51 */   private static final int TIP_HEIGHT = SwingUtils.STANDARD_FONT_HEIGHT * 12;
/*  52 */   private static final int FILE_HEIGHT = SwingUtils.TABLE_ROW_HEIGHT * 14;
/*     */   
/*     */   private static final int COLUMNS_TO_NUMER = 10;
/*     */   
/*     */   private LineArrayModel fileMdl;
/*  57 */   public final BmKeyedComboBox structureCombo = new BmKeyedComboBox(new ManagerRowList(LineIOProvider.getInstance(), false), false);
/*     */   
/*     */ 
/*     */ 
/*  61 */   public final JButton goBtn = SwingUtils.newButton("Go");
/*     */   
/*  63 */   public final JTextField lengthTxt = new JTextField();
/*  64 */   public final FontCombo fontNameCombo = new FontCombo();
/*  65 */   private JTable fileTbl = new JTable();
/*     */   
/*     */ 
/*     */ 
/*     */   private byte[] fileData;
/*     */   
/*     */ 
/*     */   protected int textPct;
/*     */   
/*     */ 
/*  75 */   private ActionListener changed = new ActionListener() {
/*     */     public void actionPerformed(ActionEvent e) {
/*  77 */       if (PnlUnknownFileFormat.this.getFileStructure() == 2) {
/*  78 */         FileAnalyser fa = FileAnalyser.getFixedAnalyser(PnlUnknownFileFormat.this.fileData, PnlUnknownFileFormat.this.lengthTxt.getText());
/*     */         
/*  80 */         PnlUnknownFileFormat.this.lengthTxt.setText(Integer.toString(fa.getRecordLength()));
/*  81 */         if (!"".equals(fa.getFontName())) {
/*  82 */           PnlUnknownFileFormat.this.fontNameCombo.setText(fa.getFontName());
/*     */         }
/*     */       }
/*  85 */       PnlUnknownFileFormat.this.readFile();
/*     */     }
/*     */   };
/*     */   
/*  89 */   private FocusAdapter focusHandler = new FocusAdapter() {
/*     */     public void focusLost(FocusEvent e) {
/*  91 */       PnlUnknownFileFormat.this.readFile();
/*     */     }
/*     */   };
/*     */   
/*     */   public PnlUnknownFileFormat() {
/*  96 */     init_100_setupScreen(false);
/*     */   }
/*     */   
/*     */   public PnlUnknownFileFormat(String fileName) throws IOException {
/* 100 */     init_100_setupScreen(true);
/*     */     
/* 102 */     open(fileName);
/*     */   }
/*     */   
/*     */   public PnlUnknownFileFormat(BufferedInputStream in) throws IOException {
/* 106 */     init_100_setupScreen(true);
/* 107 */     open(in);
/*     */   }
/*     */   
/*     */   public void open(String fileName) throws IOException {
/* 111 */     open(new BufferedInputStream(new FileInputStream(fileName)));
/*     */   }
/*     */   
/*     */   public void open(BufferedInputStream in) throws IOException
/*     */   {
/* 116 */     init_200_loadFile(in);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_100_setupScreen(boolean showGoBtn)
/*     */   {
/* 124 */     JEditorPane tips = new JEditorPane("text/html", LangConversion.convertId(2, "UnknownFileFormatTip", "<h3>File Structure</h3><p>This screen lets you select the File structure. <br>For Standard Windows / Unix files use <b>Text IO</b>. <br>For Fixed width files, You can click on the Start of the second record to set the length."));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 131 */     addComponentRE(1, 5, TIP_HEIGHT, BasePanel.GAP3, 2, 2, tips);
/*     */     
/*     */ 
/* 134 */     setGapRE(BasePanel.GAP1);
/*     */     
/* 136 */     addLineRE("File Structure", this.structureCombo);
/* 137 */     addLineRE("Length", this.lengthTxt);
/* 138 */     addLineRE("Font Name", this.fontNameCombo);
/* 139 */     setGapRE(GAP1);
/* 140 */     addComponentRE(1, 5, FILE_HEIGHT, BasePanel.GAP1, 2, 2, this.fileTbl);
/*     */     
/*     */ 
/*     */ 
/* 144 */     if (showGoBtn) {
/* 145 */       setGapRE(GAP2);
/* 146 */       addLineRE("", null, this.goBtn);
/*     */     }
/* 148 */     setGapRE(GAP1);
/* 149 */     addMessage(new JTextArea());
/*     */     
/*     */ 
/* 152 */     this.lengthTxt.addFocusListener(this.focusHandler);
/* 153 */     this.fontNameCombo.addFocusListener(this.focusHandler);
/* 154 */     this.structureCombo.addActionListener(this.changed);
/*     */     
/* 156 */     this.fileTbl.setAutoResizeMode(0);
/*     */     
/* 158 */     this.fileTbl.addMouseListener(new MouseAdapter()
/*     */     {
/*     */ 
/*     */ 
/*     */       public void mouseReleased(MouseEvent e)
/*     */       {
/*     */ 
/* 165 */         int row = PnlUnknownFileFormat.this.fileTbl.rowAtPoint(e.getPoint());
/* 166 */         int length = PnlUnknownFileFormat.this.fileTbl.columnAtPoint(e.getPoint());
/*     */         
/* 168 */         for (int i = 0; i < row; i++)
/*     */         {
/* 170 */           length += PnlUnknownFileFormat.this.fileMdl.getLine(i).length;
/*     */         }
/*     */         
/*     */ 
/* 174 */         PnlUnknownFileFormat.this.lengthTxt.setText(Integer.toString(length));
/* 175 */         if (PnlUnknownFileFormat.this.getFileStructure() == 2) {
/* 176 */           PnlUnknownFileFormat.this.readFile();
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_200_loadFile(BufferedInputStream in)
/*     */     throws IOException
/*     */   {
/* 189 */     if (in == null) {
/* 190 */       this.fileData = new byte[0];
/* 191 */       return;
/*     */     }
/* 193 */     this.fileData = new byte[Math.min(34000, in.available())];
/*     */     
/* 195 */     in.mark(this.fileData.length);
/* 196 */     in.read(this.fileData);
/* 197 */     in.reset();
/*     */     
/*     */ 
/* 200 */     FileAnalyser fa = FileAnalyser.getAnaylser(this.fileData, this.lengthTxt.getText());
/*     */     
/* 202 */     if (!"".equals(fa.getFontName())) {
/* 203 */       this.fontNameCombo.setText(fa.getFontName());
/*     */     }
/* 205 */     this.structureCombo.removeActionListener(this.changed);
/* 206 */     this.structureCombo.setSelectedItem(Integer.valueOf(fa.getFileStructure()));
/* 207 */     this.structureCombo.addActionListener(this.changed);
/*     */     
/* 209 */     if (fa.getFileStructure() == 2) {
/* 210 */       this.lengthTxt.setText(Integer.toString(fa.getRecordLength()));
/*     */     }
/* 212 */     readFile();
/*     */   }
/*     */   
/*     */ 
/*     */   private void readFile()
/*     */   {
/* 218 */     int structure = getFileStructure();
/* 219 */     byte[][] lines = new byte[30][];
/*     */     
/* 221 */     int count = 0;
/*     */     
/*     */ 
/*     */     try
/*     */     {
/*     */       AbstractByteReader reader;
/*     */       
/* 228 */       switch (structure) {
/*     */       case 2: 
/* 230 */         if ("".equals(this.lengthTxt.getText())) {
/* 231 */           setMessageTxtRE("You Must enter a Length for fixed Length files");
/* 232 */           this.lengthTxt.requestFocus();
/* 233 */           return;
/*     */         }
/* 235 */         reader = new FixedLengthByteReader(Integer.parseInt(this.lengthTxt.getText()));
/* 236 */         break;
/*     */       case 1: 
/*     */       case 51: 
/*     */       case 61: 
/*     */       case 62: 
/*     */       case 90: 
/* 242 */         reader = new TextReader(this.fontNameCombo.getText());
/* 243 */         break;
/*     */       default: 
/* 245 */         reader = ByteIOProvider.getInstance().getByteReader(structure);
/*     */       }
/*     */       
/* 248 */       if (reader == null) {
/* 249 */         setMessageTxtRE("Selected File Structue is not supported here");
/*     */       } else {
/* 251 */         reader.open(new ByteArrayInputStream(this.fileData));
/* 252 */         while ((count < lines.length) && ((lines[(count++)] = reader.read()) != null)) {}
/*     */         
/* 254 */         reader.close();
/*     */         
/* 256 */         this.fileMdl = new LineArrayModel(lines, this.fontNameCombo.getText(), count - 1);
/*     */         
/* 258 */         this.fileTbl.setModel(this.fileMdl);
/*     */         
/* 260 */         TableColumnModel tcm = this.fileTbl.getColumnModel();
/*     */         
/* 262 */         for (int i = 0; i < this.fileMdl.getColumnCount(); i++)
/*     */         {
/* 264 */           TableColumn tc = tcm.getColumn(i);
/*     */           
/* 266 */           tc.setPreferredWidth(SwingUtils.ONE_CHAR_TABLE_CELL_WIDTH);
/*     */           String s;
/* 268 */           switch ((i + 1) % 10) {
/* 269 */           case 0:  s = "" + (i + 1) / 10; break;
/* 270 */           case 5:  s = "+"; break;
/* 271 */           default:  s = " ";
/*     */           }
/* 273 */           tc.setHeaderValue(s);
/*     */         }
/* 275 */         this.fileMdl.fireTableDataChanged();
/*     */       }
/*     */     } catch (Exception e) {
/* 278 */       setMessageTxtRE("Error Reading File:", e.getMessage());
/* 279 */       e.printStackTrace();
/*     */     }
/*     */     
/* 282 */     this.lengthTxt.setEnabled(structure == 2);
/*     */   }
/*     */   
/*     */   public int getFileStructure() {
/* 286 */     return ((Integer)this.structureCombo.getSelectedItem()).intValue();
/*     */   }
/*     */   
/*     */   public int getLength() {
/* 290 */     int ret = 10;
/*     */     try
/*     */     {
/* 293 */       ret = Integer.parseInt(this.lengthTxt.getText());
/*     */     }
/*     */     catch (Exception e) {}
/* 296 */     return ret;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/layoutWizard/PnlUnknownFileFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */