/*     */ package net.sf.RecordEditor.layoutWizard;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.event.ActionEvent;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.RootPaneContainer;
/*     */ import net.sf.JRecord.External.ExternalRecord;
/*     */ import net.sf.JRecord.IO.LineIOProvider;
/*     */ import net.sf.RecordEditor.re.db.Record.ExtendedRecordDB;
/*     */ import net.sf.RecordEditor.re.db.Record.RecordRec;
/*     */ import net.sf.RecordEditor.re.db.Table.TableDB;
/*     */ import net.sf.RecordEditor.re.db.Table.TypeList;
/*     */ import net.sf.RecordEditor.utils.LayoutConnection;
/*     */ import net.sf.RecordEditor.utils.LayoutConnectionAction;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.common.ReConnection;
/*     */ import net.sf.RecordEditor.utils.edit.ManagerRowList;
/*     */ import net.sf.RecordEditor.utils.jdbc.DBList;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.swing.AbsRowList;
/*     */ import net.sf.RecordEditor.utils.wizards.AbstractWizard;
/*     */ import net.sf.RecordEditor.utils.wizards.AbstractWizardPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Wizard
/*     */   extends AbstractWizard<Details>
/*     */ {
/*  30 */   private AbstractWizardPanel<Details>[] panelsFixed = new AbstractWizardPanel[5];
/*  31 */   private AbstractWizardPanel<Details>[] panelsCsv = new AbstractWizardPanel[5];
/*  32 */   private AbstractWizardPanel<Details>[] panelsUnicodeCsv = new AbstractWizardPanel[5];
/*  33 */   private AbstractWizardPanel<Details>[] panelsMulti = new AbstractWizardPanel[7];
/*     */   
/*     */ 
/*     */   private int connectionIdx;
/*     */   
/*     */ 
/*     */   private LayoutConnection callbackClass;
/*     */   
/*     */ 
/*     */ 
/*     */   public Wizard(int connectionId, String fileName, LayoutConnection callback)
/*     */   {
/*  45 */     this(new ReFrame("", "File Wizard", "", null), connectionId, fileName, callback, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public <T extends Component,  extends RootPaneContainer> Wizard(T frame, int connectionId, String fileName, LayoutConnection callback, boolean visible)
/*     */   {
/*  54 */     super(frame, new Details());
/*     */     
/*  56 */     boolean free = Common.isSetDoFree(false);
/*  57 */     this.connectionIdx = connectionId;
/*  58 */     this.callbackClass = callback;
/*  59 */     ((Details)getWizardDetails()).filename = fileName;
/*     */     
/*  61 */     ReConnection con = new ReConnection(this.connectionIdx);
/*  62 */     TableDB structureTable = new TableDB();
/*  63 */     TableDB systemTable = new TableDB();
/*  64 */     structureTable.setParams(4);
/*  65 */     systemTable.setParams(3);
/*  66 */     AbsRowList typeList = new TypeList(this.connectionIdx, true, false);
/*     */     
/*  68 */     AbsRowList structureList = new ManagerRowList(LineIOProvider.getInstance(), false);
/*  69 */     AbsRowList systemList = new DBList(systemTable, 0, 1, true, false);
/*     */     
/*     */ 
/*  72 */     structureTable.setConnection(con);
/*  73 */     systemTable.setConnection(con);
/*     */     
/*     */ 
/*  76 */     this.panelsFixed[0] = new Pnl1File(structureList, typeList);
/*  77 */     this.panelsFixed[1] = new Pnl2FileFormat();
/*  78 */     this.panelsFixed[2] = new Pnl3Table(super.getMessage());
/*  79 */     this.panelsFixed[3] = new Pnl4Names(typeList);
/*  80 */     this.panelsFixed[4] = new Pnl7SaveDbLayout(systemList);
/*     */     
/*  82 */     this.panelsCsv[0] = this.panelsFixed[0];
/*  83 */     this.panelsCsv[1] = this.panelsFixed[1];
/*  84 */     this.panelsCsv[2] = new Pnl3CsvTable();
/*  85 */     this.panelsCsv[3] = new Pnl4CsvNames(typeList, false);
/*  86 */     this.panelsCsv[4] = this.panelsFixed[4];
/*     */     
/*  88 */     System.arraycopy(this.panelsCsv, 0, this.panelsUnicodeCsv, 0, this.panelsCsv.length);
/*     */     
/*  90 */     this.panelsMulti[0] = this.panelsFixed[0];
/*  91 */     this.panelsMulti[1] = this.panelsFixed[1];
/*  92 */     this.panelsMulti[2] = new Pnl3RecordType(typeList, super.getMessage());
/*  93 */     this.panelsMulti[3] = new Pnl4RecordNames();
/*  94 */     this.panelsMulti[4] = new Pnl5RecordTable(getMessage());
/*  95 */     this.panelsMulti[5] = new Pnl6RecordFieldNames(typeList);
/*  96 */     this.panelsMulti[6] = this.panelsFixed[4];
/*     */     
/*  98 */     super.setPanels(this.panelsFixed, visible);
/*  99 */     Common.setDoFree(free, connectionId);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void changePanel(int inc)
/*     */   {
/* 110 */     if (getPanelNumber() == 0) {
/* 111 */       Details details = (Details)super.getWizardDetails();
/* 112 */       if (details.recordType == 0) {
/* 113 */         super.setPanels(this.panelsFixed);
/* 114 */       } else if (details.recordType == 2) {
/* 115 */         super.setPanels(this.panelsMulti);
/* 116 */       } else if (details.unicode) {
/* 117 */         super.setPanels(this.panelsUnicodeCsv);
/*     */       } else {
/* 119 */         super.setPanels(this.panelsCsv);
/*     */       }
/*     */     }
/* 122 */     super.changePanel(inc);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void finished(Details details)
/*     */   {
/*     */     try
/*     */     {
/* 131 */       ExternalRecord rec = details.createRecordLayout();
/* 132 */       ExtendedRecordDB db = new ExtendedRecordDB();
/* 133 */       db.setConnection(new ReConnection(this.connectionIdx));
/*     */       
/* 135 */       db.insert(new RecordRec(rec));
/*     */       
/* 137 */       Common.checkpoint(this.connectionIdx);
/*     */       
/* 139 */       if (this.callbackClass != null) {
/* 140 */         if (details.editFile) {
/* 141 */           this.callbackClass.setRecordLayout(rec.getRecordId(), rec.getRecordName(), details.filename);
/*     */         } else {
/* 143 */           this.callbackClass.setRecordLayout(rec.getRecordId(), rec.getRecordName(), null);
/*     */         }
/*     */       }
/*     */       
/* 147 */       setClosed(true);
/*     */     } catch (Exception ex) {
/* 149 */       super.getMessage().setText(ex.getMessage());
/* 150 */       Common.logMsgRaw(ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static LayoutConnectionAction getAction(LayoutConnection callback)
/*     */   {
/* 166 */     new LayoutConnectionAction("Layout Wizard", callback, 43)
/*     */     {
/*     */       public void actionPerformed(ActionEvent e)
/*     */       {
/*     */         try
/*     */         {
/* 172 */           new Wizard(getCallback().getCurrentDbIdentifier(), getCallback().getCurrentFileName(), getCallback());
/*     */         }
/*     */         catch (Exception ex) {
/* 175 */           Common.logMsg("Cant start wizard", ex);
/*     */         }
/*     */       }
/*     */     };
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/layoutWizard/Wizard.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */