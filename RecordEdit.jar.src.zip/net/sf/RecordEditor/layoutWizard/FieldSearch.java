/*     */ package net.sf.RecordEditor.layoutWizard;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import net.sf.JRecord.Common.Conversion;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FieldSearch
/*     */ {
/*     */   private static final int NOT_IN_FIELD = 0;
/*     */   private static final int IN_COMP3 = 1;
/*     */   private static final int IN_ZONED = 2;
/*     */   private static final int IN_PC_ZONED = 3;
/*     */   private static final int IN_NUMERIC = 4;
/*     */   private static final int IN_BINARY = 5;
/*     */   private static final int IN_TEXT = 6;
/*     */   private static final int TYPE_SPACE = 0;
/*     */   private static final int TYPE_LAST_SPACE = 1;
/*     */   private static final int TYPE_COMP3 = 2;
/*     */   private static final int TYPE_COMP3_FINAL_BYTE = 3;
/*     */   private static final int TYPE_HEX_ZERO = 4;
/*     */   private static final int TYPE_ZERO = 5;
/*     */   private static final int TYPE_NUMBER = 6;
/*     */   private static final int POSSIBLE_MAINFRAME_ZONED_SIGN = 7;
/*     */   private static final int POSSIBLE_PC_ZONED_SIGN = 8;
/*     */   private static final int TYPE_TEXT = 9;
/*     */   private static final int TYPE_T = 10;
/*     */   private static final int TYPE_F = 11;
/*     */   private static final int TYPE_Y = 12;
/*     */   private static final int TYPE_N = 13;
/*     */   private static final int TYPE_NORMAL = 14;
/*     */   private static final int TYPE_SIGN = 15;
/*     */   private static final int TYPE_SLASH1 = 16;
/*     */   private static final int TYPE_SLASH2 = 17;
/*     */   private static final int TYPE_DASH = 18;
/*     */   private static final int TYPE_COLON = 19;
/*     */   private static final int TYPE_DOT = 20;
/*     */   private static final int TYPE_YEAR_CHAR_1 = 21;
/*     */   private static final int TYPE_YEAR_CHAR_2 = 22;
/*     */   private static final int START_BIN_FIELD = 23;
/*     */   private static final int TYPE_OTHER = 24;
/*     */   private static final int COUNT_IDX = 25;
/*  53 */   private CheckByte[] byteChecks = new CheckByte[24];
/*     */   
/*     */ 
/*  56 */   private String fontname = "";
/*     */   private RecordDefinition recordDef;
/*     */   private Details currDetails;
/*     */   private int[] charType;
/*     */   private int[] fieldIdentifier;
/*  61 */   private int fieldId; private int sameByteOnLines = 0;
/*     */   
/*  63 */   private final boolean[] check4Byte = new boolean['Ā'];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FieldSearch(Details details, RecordDefinition recordDefinition)
/*     */   {
/*  71 */     resetDetails(details, recordDefinition);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void findFields(boolean lookMainframeZoned, boolean lookPcZoned, boolean lookComp3, boolean lookCompBigEndian, boolean lookCompLittleEndian)
/*     */   {
/*  79 */     if ((this.recordDef.records != null) && (this.recordDef.numRecords > 0))
/*     */     {
/*  81 */       int size = 0;
/*     */       
/*     */ 
/*  84 */       for (int i = 0; i < this.recordDef.numRecords; i++) {
/*  85 */         size = Math.max(size, this.recordDef.records[i].length);
/*     */       }
/*     */       
/*  88 */       int[][] counts = new int[size][];
/*  89 */       this.fieldId = 0;
/*  90 */       ff100_determineByteTypes(this.recordDef.columnDtls, size, counts);
/*     */       
/*  92 */       int limit = this.recordDef.numRecords;
/*  93 */       int limit1 = this.recordDef.numRecords;
/*     */       
/*  95 */       if (limit > 3) {
/*  96 */         limit = (limit * 9 - 1) / 10;
/*  97 */       } else if (limit > 1) {
/*  98 */         limit = limit * 7 / 10;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 105 */       ff200_checkForCobolNumericFields(limit, size, counts, lookMainframeZoned, lookPcZoned, lookComp3);
/* 106 */       ff300_checkForDateAndTime(limit, size, counts);
/* 107 */       ff400_checkForNumericFields(limit, size, counts, lookCompBigEndian, lookCompLittleEndian);
/* 108 */       ff500_checkForTextFields(limit, limit1, size, counts);
/*     */       
/* 110 */       ff600_createFields(counts);
/* 111 */       ff700_checkForSameChars(limit, limit1, size);
/*     */     }
/*     */   }
/*     */   
/*     */   public final void resetDetails(Details details, RecordDefinition recordDefinition)
/*     */   {
/* 117 */     this.fontname = details.fontName;
/* 118 */     this.currDetails = details;
/* 119 */     this.recordDef = recordDefinition;
/*     */     
/* 121 */     Comp3SignByte comp3SignChk = new Comp3SignByte(null);
/* 122 */     this.byteChecks[0] = new Check4Bytes(" ");
/* 123 */     this.byteChecks[1] = new LastSpace(this.fontname);
/* 124 */     this.byteChecks[2] = new Comp3Byte(null);
/* 125 */     this.byteChecks[3] = comp3SignChk;
/* 126 */     this.byteChecks[4] = new Check4Bytes(0);
/* 127 */     this.byteChecks[14] = new NormalByte();
/* 128 */     this.byteChecks[5] = new Check4Bytes("0");
/* 129 */     this.byteChecks[6] = new Check4Bytes("0123456789");
/* 130 */     this.byteChecks[7] = new Check4Bytes("}{ABCDEFGHIJKLMNOPQR");
/* 131 */     this.byteChecks[8] = new Check4Bytes("@ABCDEFGHIPQRSTUVWXY");
/* 132 */     this.byteChecks[15] = new Check4Bytes("+-");
/* 133 */     this.byteChecks[9] = new Check4Bytes("+-.,/?\\!'\"$%&*@()[]abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789");
/* 134 */     this.byteChecks[10] = new Check4Bytes("T");
/* 135 */     this.byteChecks[11] = new Check4Bytes("F");
/* 136 */     this.byteChecks[12] = new Check4Bytes("Yy");
/* 137 */     this.byteChecks[13] = new Check4Bytes("Nn");
/* 138 */     this.byteChecks[16] = new Check4Bytes("/");
/* 139 */     this.byteChecks[17] = new Check4Bytes("\\");
/* 140 */     this.byteChecks[18] = new Check4Bytes("-");
/* 141 */     this.byteChecks[19] = new Check4Bytes(":");
/* 142 */     this.byteChecks[20] = new Check4Bytes(".");
/* 143 */     this.byteChecks[21] = new Check4Bytes("12");
/* 144 */     this.byteChecks[22] = new Check4Bytes("901");
/* 145 */     this.byteChecks[23] = new CheckStartBinField(null);
/*     */     
/*     */ 
/* 148 */     Check4Bytes charCk = new Check4Bytes(" 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ.,-+");
/*     */     
/* 150 */     for (byte i = Byte.MIN_VALUE; i < Byte.MAX_VALUE; i = (byte)(i + 1)) {
/* 151 */       this.check4Byte[Common.toInt(i)] = ((comp3SignChk.isAmatch(i)) || (charCk.isAmatch(i)) ? 1 : false);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 158 */     this.check4Byte[0] = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void ff100_determineByteTypes(ArrayList<ColumnDetails> columnDtls, int size, int[][] counts)
/*     */   {
/* 175 */     boolean[] foundType = null;
/*     */     
/* 177 */     this.charType = new int[size];
/* 178 */     this.fieldIdentifier = new int[size];
/* 179 */     for (int i = 0; i < size; i++) {
/* 180 */       this.charType[i] = 0;
/* 181 */       this.fieldIdentifier[i] = 0;
/* 182 */       counts[i] = new int[26];
/* 183 */       for (int j = 0; j < this.byteChecks.length; j++) {
/* 184 */         counts[i][j] = 0;
/*     */       }
/*     */     }
/*     */     
/* 188 */     columnDtls.clear();
/* 189 */     if (this.currDetails.recordType == 2)
/*     */     {
/* 191 */       this.recordDef.addKeyField(this.currDetails, false);
/*     */       
/* 193 */       for (i = 0; i < columnDtls.size(); i++) {
/* 194 */         ColumnDetails dtl = (ColumnDetails)columnDtls.get(i);
/* 195 */         this.fieldId += 1;
/*     */         
/* 197 */         for (int j = 0; j < dtl.length; j++) {
/* 198 */           this.fieldIdentifier[(dtl.start + j - 1)] = this.fieldId;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 204 */     for (int k = 0; k < this.byteChecks.length; k++) {
/* 205 */       this.byteChecks[k].reset();
/*     */     }
/*     */     
/* 208 */     for (i = 0; i < this.recordDef.numRecords; i++) {
/* 209 */       if ((foundType == null) || (foundType.length < this.recordDef.records[i].length))
/*     */       {
/* 211 */         foundType = new boolean[this.recordDef.records[i].length];
/*     */       }
/* 213 */       for (int j = 0; j < this.recordDef.records[i].length; j++) {
/* 214 */         counts[j][25] += 1;
/* 215 */         foundType[j] = false;
/* 216 */         for (k = 0; k < this.byteChecks.length; k++) {
/* 217 */           if ((this.byteChecks[k].forward()) && (this.byteChecks[k].isAmatch(this.recordDef.records[i][j])))
/*     */           {
/* 219 */             counts[j][k] += 1;
/* 220 */             foundType[j] = true;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 225 */       for (j = this.recordDef.records[i].length - 1; j >= 0; j--) {
/* 226 */         for (k = this.byteChecks.length - 1; k >= 0; k--) {
/* 227 */           if ((!this.byteChecks[k].forward()) && (this.byteChecks[k].isAmatch(this.recordDef.records[i][j])))
/*     */           {
/* 229 */             counts[j][k] += 1;
/* 230 */             foundType[j] = true;
/*     */           }
/*     */         }
/*     */         
/* 234 */         if (foundType[j] != 0) {
/* 235 */           counts[j][24] += 1;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void ff200_checkForCobolNumericFields(int limit, int size, int[][] counts, boolean lookMainframeZoned, boolean lookPcZoned, boolean lookComp3)
/*     */   {
/* 254 */     boolean wasStartOfBin = false;
/* 255 */     int type = 0;
/* 256 */     for (int i = size - 1; i >= 0; i--) {
/* 257 */       if (this.fieldIdentifier[i] > 0) {
/* 258 */         type = 0;
/* 259 */       } else if ((lookComp3) && (counts[i][3] >= limit)) {
/* 260 */         type = 1;
/* 261 */         this.fieldId += 1;
/* 262 */         this.charType[i] = 31;
/* 263 */         this.fieldIdentifier[i] = this.fieldId;
/* 264 */       } else if ((type == 1) && (counts[i][2] >= limit) && (!wasStartOfBin))
/*     */       {
/*     */ 
/* 267 */         this.fieldIdentifier[i] = this.fieldId;
/* 268 */         this.charType[i] = this.charType[(i + 1)];
/* 269 */       } else if ((lookMainframeZoned) && (counts[i][7] >= limit) && (i > 0) && (counts[(i - 1)][6] >= limit))
/*     */       {
/*     */ 
/* 272 */         type = 2;
/* 273 */         this.fieldId += 1;
/* 274 */         this.charType[i] = 32;
/* 275 */         this.fieldIdentifier[i] = this.fieldId;
/* 276 */       } else if ((lookPcZoned) && (counts[i][8] >= limit) && (i > 0) && (counts[(i - 1)][6] >= limit))
/*     */       {
/*     */ 
/* 279 */         type = 3;
/* 280 */         this.fieldId += 1;
/* 281 */         this.charType[i] = 41;
/* 282 */         this.fieldIdentifier[i] = this.fieldId;
/* 283 */       } else if (((type == 2) || (type == 3) || (type == 4)) && (counts[i][6] >= limit))
/*     */       {
/* 285 */         this.fieldIdentifier[i] = this.fieldId;
/* 286 */         this.charType[i] = this.charType[(i + 1)];
/* 287 */       } else if ((type == 4) && (counts[i][15] >= limit)) {
/* 288 */         this.fieldIdentifier[i] = this.fieldId;
/* 289 */         this.charType[i] = this.charType[(i + 1)];
/* 290 */         type = 0;
/*     */ 
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 297 */         type = 0;
/*     */       }
/*     */       
/* 300 */       wasStartOfBin = counts[i][23] >= limit;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void ff300_checkForDateAndTime(int limit, int size, int[][] counts)
/*     */   {
/* 308 */     for (int i = 2; i < size - 5; i++) {
/* 309 */       if (this.fieldIdentifier[i] <= 0)
/*     */       {
/* 311 */         if (((counts[i][16] >= limit) && (counts[(i + 3)][16] >= limit)) || ((counts[i][17] >= limit) && (counts[(i + 3)][17] >= limit)) || ((counts[i][18] >= limit) && (counts[(i + 3)][18] >= limit)) || ((counts[i][19] >= limit) && (counts[(i + 3)][19] >= limit)) || ((counts[i][20] >= limit) && (counts[(i + 3)][20] >= limit)))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 316 */           if ((ff310_isPossibleDateOrTime(counts, i - 4, 4, limit)) && (ff310_isPossibleDateOrTime(counts, i + 1, 2, limit)) && (ff310_isPossibleDateOrTime(counts, i + 4, 2, limit)) && (ff320_checkDayMthLast(i, limit)))
/*     */           {
/*     */ 
/*     */ 
/* 320 */             ff340_setDateTimeField(i - 4, 10);
/* 321 */           } else if ((ff310_isPossibleDateOrTime(counts, i - 2, 2, limit)) && (ff310_isPossibleDateOrTime(counts, i + 1, 2, limit)) && (ff310_isPossibleDateOrTime(counts, i + 4, 4, limit)) && (ff330_checkDayMthFirst(i, limit)))
/*     */           {
/*     */ 
/*     */ 
/* 325 */             ff340_setDateTimeField(i - 2, 10);
/* 326 */           } else if ((ff310_isPossibleDateOrTime(counts, i - 2, 2, limit)) && (ff310_isPossibleDateOrTime(counts, i + 1, 2, limit)) && (ff310_isPossibleDateOrTime(counts, i + 4, 2, limit)))
/*     */           {
/*     */ 
/* 329 */             if ((ff320_checkDayMthLast(i, limit)) || (ff330_checkDayMthFirst(i, limit)))
/*     */             {
/* 331 */               ff340_setDateTimeField(i - 2, 8);
/*     */             }
/*     */           }
/*     */           
/* 335 */           if (this.fieldIdentifier[i] <= 0)
/*     */           {
/* 337 */             if (((counts[i][18] >= limit) && (counts[(i + 3)][18] >= limit)) || ((counts[i][19] >= limit) && (counts[(i + 3)][19] >= limit)) || ((counts[i][20] >= limit) && (counts[(i + 3)][20] >= limit)))
/*     */             {
/*     */ 
/* 340 */               if ((ff310_isPossibleDateOrTime(counts, i - 2, 2, limit)) && (ff310_isPossibleDateOrTime(counts, i + 1, 2, limit)) && (ff310_isPossibleDateOrTime(counts, i + 4, 2, limit)) && (ff340_checkTime(i, limit)))
/*     */               {
/*     */ 
/*     */ 
/* 344 */                 ff340_setDateTimeField(i - 2, 8);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean ff310_isPossibleDateOrTime(int[][] counts, int start, int len, int limit)
/*     */   {
/* 361 */     boolean ret = false;
/*     */     
/*     */ 
/*     */ 
/* 365 */     if ((start >= 0) && (start + len <= counts.length))
/*     */     {
/* 367 */       ret = (len != 4) || ((counts[start][21] >= limit) && (counts[(start + 1)][22] >= limit));
/*     */       
/* 369 */       for (int i = 0; (ret) && (i < len); i++)
/*     */       {
/* 371 */         ret = counts[(start + i)][6] >= limit;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 376 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean ff320_checkDayMthLast(int pos, int limit)
/*     */   {
/* 382 */     return ((ff350_checkRange(pos + 4, 2, 31, limit)) && (ff350_checkRange(pos + 1, 2, 12, limit))) || ((ff350_checkRange(pos + 4, 2, 12, limit)) && (ff350_checkRange(pos + 1, 2, 31, limit)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean ff330_checkDayMthFirst(int pos, int limit)
/*     */   {
/* 390 */     return ((ff350_checkRange(pos - 2, 2, 31, limit)) && (ff350_checkRange(pos + 1, 2, 12, limit))) || ((ff350_checkRange(pos - 2, 2, 12, limit)) && (ff350_checkRange(pos + 1, 2, 31, limit)));
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean ff340_checkTime(int pos, int limit)
/*     */   {
/* 396 */     return (ff350_checkRange(pos - 2, 2, 25, limit)) && (ff350_checkRange(pos + 1, 2, 61, limit)) && (ff350_checkRange(pos + 4, 2, 61, limit));
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean ff350_checkRange(int start, int len, int maxValue, int limit)
/*     */   {
/* 402 */     int count = 0;
/* 403 */     int diff = this.recordDef.numRecords - limit;
/*     */     
/* 405 */     for (int i = 0; (i - count <= diff) && (i < this.recordDef.numRecords); i++)
/*     */     {
/*     */       try
/*     */       {
/*     */ 
/* 410 */         if (maxValue > Integer.parseInt(Conversion.getString(this.recordDef.records[i], start, start + len, this.fontname)))
/*     */         {
/* 412 */           count++;
/*     */         }
/*     */       } catch (Exception e) {
/* 415 */         System.out.println("Error: " + e.getMessage());
/*     */       }
/*     */     }
/*     */     
/* 419 */     return count >= limit;
/*     */   }
/*     */   
/*     */   private void ff340_setDateTimeField(int start, int len) {
/* 423 */     this.fieldId += 1;
/* 424 */     for (int i = start; i < start + len; i++) {
/* 425 */       this.fieldIdentifier[i] = this.fieldId;
/*     */     }
/*     */   }
/*     */   
/*     */   private void ff400_checkForNumericFields(int limit, int size, int[][] counts, boolean lookCompBigEndian, boolean lookCompLittleEndian)
/*     */   {
/* 431 */     int type = 0;
/* 432 */     int len = 0;
/* 433 */     boolean lastCharNonZero = true;
/* 434 */     boolean allowDot = false;
/* 435 */     boolean wasHexZero = false;
/* 436 */     boolean holdWasHexZero = true;
/*     */     
/* 438 */     for (int i = 0; i < size; i++) {
/* 439 */       holdWasHexZero = false;
/* 440 */       if (this.fieldIdentifier[i] > 0) {
/* 441 */         type = 0;
/* 442 */         allowDot = false;
/* 443 */       } else if ((lookCompBigEndian) && (counts[i][4] >= limit)) {
/* 444 */         holdWasHexZero = true;
/*     */         
/* 446 */         if ((len == 8) || (!wasHexZero)) {
/* 447 */           type = 5;
/* 448 */           this.fieldId += 1;
/* 449 */           len = 1;
/*     */         } else {
/* 451 */           len++;
/*     */         }
/* 453 */         this.charType[i] = 35;
/* 454 */         this.fieldIdentifier[i] = this.fieldId;
/* 455 */       } else if (((lastCharNonZero) && (counts[i][5] >= limit) && (i < size - 1) && (counts[(i + 1)][6] >= limit)) || ((type != 4) && (counts[i][6] >= limit)))
/*     */       {
/*     */ 
/* 458 */         type = 4;
/* 459 */         this.fieldId += 1;
/* 460 */         this.charType[i] = 6;
/* 461 */         this.fieldIdentifier[i] = this.fieldId;
/* 462 */         allowDot = true;
/* 463 */       } else if ((type == 4) && (counts[i][6] >= limit)) {
/* 464 */         this.fieldIdentifier[i] = this.fieldId;
/* 465 */         this.charType[i] = 6;
/* 466 */       } else if ((allowDot) && (type == 4) && (counts[i][20] >= limit)) {
/* 467 */         this.fieldIdentifier[i] = this.fieldId;
/* 468 */         this.charType[i] = 6;
/* 469 */         allowDot = false;
/* 470 */       } else if ((len == 8) || (counts[i][9] + counts[i][0] >= limit)) {
/* 471 */         type = 0;
/* 472 */       } else if (type == 5) {
/* 473 */         this.charType[i] = 35;
/* 474 */         this.fieldIdentifier[i] = this.fieldId;
/* 475 */         len++;
/*     */       }
/*     */       
/*     */ 
/* 479 */       lastCharNonZero = counts[i][5] < limit;
/* 480 */       wasHexZero = holdWasHexZero;
/*     */     }
/*     */     
/* 483 */     if ((lookCompLittleEndian) && (!lookCompBigEndian)) {
/* 484 */       type = 0;
/* 485 */       for (int i = size - 1; i >= 0; i--) {
/* 486 */         if (this.fieldIdentifier[i] > 0) {
/* 487 */           type = 0;
/* 488 */         } else if (counts[i][4] >= limit) {
/* 489 */           type = 5;
/* 490 */           this.fieldId += 1;
/* 491 */           this.charType[i] = 15;
/* 492 */           this.fieldIdentifier[i] = this.fieldId;
/* 493 */           len = 1;
/* 494 */         } else if ((len == 8) || (counts[i][9] + counts[i][0] >= limit)) {
/* 495 */           type = 0;
/* 496 */         } else if (type == 5) {
/* 497 */           this.charType[i] = 15;
/* 498 */           this.fieldIdentifier[i] = this.fieldId;
/* 499 */           len++;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void ff500_checkForTextFields(int limit, int limit1, int size, int[][] counts) {
/* 506 */     boolean wasSpace = false;
/* 507 */     int type = 0;
/*     */     
/* 509 */     for (int i = 0; i < size; i++) {
/* 510 */       if (this.fieldIdentifier[i] > 0) {
/* 511 */         type = 0;
/* 512 */       } else if ((counts[i][10] + counts[i][11] >= limit) && (counts[i][10] > 0) && (counts[i][11] > 0) && (counts[i][9] + counts[i][0] >= limit))
/*     */       {
/*     */ 
/* 515 */         type = 0;
/* 516 */         this.fieldId += 1;
/* 517 */         this.charType[i] = 112;
/* 518 */         this.fieldIdentifier[i] = this.fieldId;
/* 519 */       } else if ((counts[i][12] + counts[i][12] >= limit) && (counts[i][12] > 0) && (counts[i][13] > 0) && (counts[i][12] + counts[i][13] >= counts[i][9] - 1))
/*     */       {
/*     */ 
/* 522 */         type = 0;
/* 523 */         this.fieldId += 1;
/* 524 */         this.charType[i] = 111;
/* 525 */         this.fieldIdentifier[i] = this.fieldId;
/* 526 */       } else if ((wasSpace) && (counts[i][9] >= limit)) {
/* 527 */         type = 6;
/* 528 */         this.fieldId += 1;
/* 529 */         this.charType[i] = 0;
/* 530 */         this.fieldIdentifier[i] = this.fieldId;
/* 531 */       } else if ((type == 6) && (counts[i][9] + counts[i][0] >= limit)) {
/* 532 */         this.fieldIdentifier[i] = this.fieldId;
/* 533 */         this.charType[i] = 0;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 541 */       wasSpace = counts[i][1] >= limit;
/*     */     }
/*     */   }
/*     */   
/*     */   private void ff600_createFields(int[][] counts)
/*     */   {
/* 547 */     int lastField = -1;
/*     */     
/* 549 */     ColumnDetails colDtls = null;
/*     */     
/* 551 */     this.recordDef.columnDtls.clear();
/* 552 */     for (int i = 0; i < this.fieldIdentifier.length; i++)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 559 */       if (lastField != this.fieldIdentifier[i]) {
/* 560 */         lastField = this.fieldIdentifier[i];
/*     */         
/* 562 */         if (colDtls != null) {
/* 563 */           this.recordDef.columnDtls.add(colDtls);
/*     */         }
/* 565 */         int type = 0;
/* 566 */         if (this.charType[i] > 0) {
/* 567 */           type = this.charType[i];
/*     */         }
/*     */         
/* 570 */         colDtls = new ColumnDetails(i + 1, type);
/* 571 */         colDtls.length = 1;
/*     */         
/* 573 */         if (this.currDetails.recordType == 2) {
/* 574 */           for (KeyField k : this.currDetails.keyFields) {
/* 575 */             if (i + 1 == k.keyStart) {
/* 576 */               colDtls.name = k.keyName;
/*     */             }
/*     */           }
/*     */         }
/*     */       } else {
/* 581 */         colDtls.length += 1;
/*     */       }
/*     */     }
/*     */     
/* 585 */     if (colDtls != null) {
/* 586 */       this.recordDef.columnDtls.add(colDtls);
/*     */     }
/*     */   }
/*     */   
/*     */   private void ff700_checkForSameChars(int limit, int limit1, int size)
/*     */   {
/* 592 */     int count = 0;
/* 593 */     CountBytes countBytes = new CountBytes(null);
/*     */     
/*     */ 
/* 596 */     for (int j = 0; j < size; j++)
/*     */     {
/* 598 */       countBytes.reset();
/*     */       
/* 600 */       for (int i = 0; i < this.recordDef.numRecords; i++)
/*     */       {
/* 602 */         if ((this.recordDef.records[i].length > j) && 
/* 603 */           (this.check4Byte[Common.toInt(this.recordDef.records[i][j])] != 0)) {
/* 604 */           countBytes.addByte(this.recordDef.records[i][j]);
/*     */         }
/*     */       }
/*     */       
/* 608 */       if (countBytes.getCount() >= limit) {
/* 609 */         count++;
/*     */       }
/*     */     }
/* 612 */     this.sameByteOnLines = count;
/*     */   }
/*     */   
/*     */   public int getSameByteOnLines() {
/* 616 */     return this.sameByteOnLines;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static abstract interface CheckByte
/*     */   {
/*     */     public abstract void reset();
/*     */     
/*     */ 
/*     */ 
/*     */     public abstract boolean forward();
/*     */     
/*     */ 
/*     */ 
/*     */     public abstract boolean isAmatch(byte paramByte);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class BasicCheck
/*     */   {
/*     */     public void reset() {}
/*     */     
/*     */ 
/*     */     public boolean forward()
/*     */     {
/* 643 */       return true;
/*     */     }
/*     */     
/*     */     public boolean search(byte[] tstBytes, byte b) {
/* 647 */       for (int i = 0; i < tstBytes.length; i++) {
/* 648 */         if (b == tstBytes[i]) {
/* 649 */           return true;
/*     */         }
/*     */       }
/* 652 */       return false;
/*     */     }
/*     */   }
/*     */   
/*     */   private static class LastSpace implements FieldSearch.CheckByte {
/*     */     private final byte spaceByte;
/*     */     boolean notSpace;
/*     */     
/* 660 */     public LastSpace(String fontname) { this.spaceByte = Conversion.getBytes(" ", fontname)[0]; }
/*     */     
/*     */     public void reset()
/*     */     {
/* 664 */       this.notSpace = false;
/*     */     }
/*     */     
/* 667 */     public boolean forward() { return false; }
/*     */     
/*     */     public boolean isAmatch(byte b)
/*     */     {
/* 671 */       boolean ret = (this.notSpace) && (b == this.spaceByte);
/* 672 */       this.notSpace = (b != this.spaceByte);
/* 673 */       return ret;
/*     */     }
/*     */   }
/*     */   
/* 677 */   private class CheckStartBinField extends FieldSearch.BasicCheck implements FieldSearch.CheckByte { private CheckStartBinField() { super(); }
/* 678 */     private byte[] tstBytes = Conversion.getBytes(" " + Common.STANDARD_CHARS1, FieldSearch.this.fontname);
/* 679 */     private boolean m1 = true; private boolean m2 = true;
/*     */     
/*     */     public boolean isAmatch(byte b) {
/* 682 */       boolean ret = (b == 0) && (this.m1) && (this.m2);
/* 683 */       this.m1 = this.m2;
/* 684 */       this.m2 = search(this.tstBytes, b);
/* 685 */       return ret;
/*     */     }
/*     */   }
/*     */   
/*     */   private class Check4Bytes extends FieldSearch.BasicCheck implements FieldSearch.CheckByte { private byte[] tstBytes;
/*     */     
/* 691 */     public Check4Bytes(String tst) { super();
/* 692 */       this.tstBytes = Conversion.getBytes(tst, FieldSearch.this.fontname); }
/*     */     
/* 694 */     public Check4Bytes(byte tst) { super();
/* 695 */       byte[] b = { tst };
/* 696 */       this.tstBytes = b;
/*     */     }
/*     */     
/*     */ 
/* 700 */     public boolean isAmatch(byte b) { return search(this.tstBytes, b); }
/*     */   }
/*     */   
/*     */   private class NormalByte extends FieldSearch.BasicCheck implements FieldSearch.CheckByte {
/*     */     private byte tstByte;
/*     */     
/* 706 */     public NormalByte() { super();
/* 707 */       byte[] b = Conversion.getBytes(" ", FieldSearch.this.fontname);
/* 708 */       this.tstByte = b[0];
/*     */     }
/*     */     
/*     */     public boolean isAmatch(byte b) {
/* 712 */       return this.tstByte >= b;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class Comp3Byte
/*     */     extends FieldSearch.BasicCheck
/*     */     implements FieldSearch.CheckByte
/*     */   {
/* 722 */     private Comp3Byte() { super(); }
/*     */     
/*     */     public boolean isAmatch(byte b) {
/* 725 */       int bb = b;
/* 726 */       if (bb < 0) {
/* 727 */         bb += 256;
/*     */       }
/* 729 */       int n1 = bb & 0xF;
/* 730 */       int n2 = bb >> 4;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 736 */       return (n1 < 10) && (n2 < 10);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class Comp3SignByte
/*     */     extends FieldSearch.BasicCheck
/*     */     implements FieldSearch.CheckByte
/*     */   {
/* 747 */     private Comp3SignByte() { super(); }
/*     */     
/*     */     public boolean isAmatch(byte b) {
/* 750 */       int n1 = b & 0xF;
/* 751 */       int n2 = b >> 4;
/*     */       
/* 753 */       return ((n1 == 15) || (n1 == 13) || (n1 == 12)) && (n2 < 10);
/*     */     }
/*     */   }
/*     */   
/*     */   private static class CountBytes {
/* 758 */     private byte[] bytes = new byte['Ā'];
/* 759 */     private byte[] bytesList = new byte['Ā'];
/* 760 */     private int bytesUsed = 0;
/*     */     
/*     */     public void reset() {
/* 763 */       for (int i = 0; i < 256; i++) {
/* 764 */         this.bytes[i] = 0;
/*     */       }
/* 766 */       this.bytesUsed = 0;
/*     */     }
/*     */     
/*     */     public void addByte(byte theByte)
/*     */     {
/* 771 */       int idx = Common.toInt(theByte);
/* 772 */       if (this.bytes[idx] == 0) {
/* 773 */         this.bytesList[(this.bytesUsed++)] = theByte;
/*     */       }
/* 775 */       int tmp36_35 = idx; byte[] tmp36_32 = this.bytes;tmp36_32[tmp36_35] = ((byte)(tmp36_32[tmp36_35] + 1));
/*     */     }
/*     */     
/*     */     public int getCount() {
/* 779 */       int max = 0;
/* 780 */       for (int i = 0; i < this.bytesUsed; i++) {
/* 781 */         int idx = Common.toInt(this.bytesList[i]);
/* 782 */         if (this.bytes[idx] > max) {
/* 783 */           max = this.bytes[idx];
/*     */         }
/*     */       }
/* 786 */       return max;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/layoutWizard/FieldSearch.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */