/*    */ package net.sf.RecordEditor.layoutWizard;
/*    */ 
/*    */ import javax.swing.JTextArea;
/*    */ import javax.swing.JTextField;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ import net.sf.RecordEditor.utils.swing.AbsRowList;
/*    */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*    */ import net.sf.RecordEditor.utils.swing.BmKeyedComboBox;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Pnl7SaveDbLayout
/*    */   extends WizardPanel
/*    */ {
/*    */   private Details wizardDetails;
/* 28 */   private JTextField layoutName = new JTextField();
/* 29 */   private JTextArea layoutDescription = new JTextArea();
/* 30 */   private BmKeyedComboBox system = null;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Pnl7SaveDbLayout(AbsRowList systemList)
/*    */   {
/* 38 */     setHelpURLre(Common.formatHelpURL("HlpLe04.htm#HDRWIZSAVE1"));
/*    */     
/* 40 */     setGapRE(BasePanel.GAP2);
/*    */     
/* 42 */     addLineRE("Layout Name", this.layoutName);
/* 43 */     addLineRE("Layout Description", this.layoutDescription);
/* 44 */     setHeightRE(BasePanel.GAP3);
/* 45 */     setGapRE(BasePanel.GAP1);
/*    */     
/* 47 */     this.system = new BmKeyedComboBox(systemList, false);
/* 48 */     addLineRE("System", this.system);
/*    */     
/*    */ 
/* 51 */     setGapRE(BasePanel.GAP3);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public Details getValues()
/*    */     throws Exception
/*    */   {
/* 59 */     this.wizardDetails.layoutName = this.layoutName.getText();
/* 60 */     this.wizardDetails.layoutDescription = this.layoutDescription.getText();
/* 61 */     this.wizardDetails.system = ((Integer)this.system.getSelectedItem()).intValue();
/*    */     
/* 63 */     if ("".equals(this.wizardDetails.layoutName)) {
/* 64 */       this.layoutName.requestFocus();
/* 65 */       throw new Exception("You must enter a layout name");
/*    */     }
/*    */     
/* 68 */     return this.wizardDetails;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setValues(Details detail)
/*    */     throws Exception
/*    */   {
/* 77 */     this.wizardDetails = detail;
/*    */     
/* 79 */     this.layoutName.setText(detail.layoutName);
/* 80 */     this.layoutDescription.setText(detail.layoutDescription);
/* 81 */     this.system.setSelectedItem(Integer.valueOf(detail.system));
/*    */     
/* 83 */     if (detail.layoutWriterIdx < 0) {
/* 84 */       detail.layoutWriterIdx = Common.getCopybookWriterIndex();
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/layoutWizard/Pnl7SaveDbLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */