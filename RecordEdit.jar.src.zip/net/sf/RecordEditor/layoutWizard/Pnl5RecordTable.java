/*     */ package net.sf.RecordEditor.layoutWizard;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JEditorPane;
/*     */ import javax.swing.text.JTextComponent;
/*     */ import net.sf.JRecord.Common.RecordException;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Pnl5RecordTable
/*     */   extends WizardPanel
/*     */ {
/*  45 */   private static final int FILE_HEIGHT = SwingUtils.TABLE_ROW_HEIGHT * 12 - 3;
/*     */   
/*     */ 
/*     */   public int stdLineHeight;
/*     */   
/*     */ 
/*     */   private JEditorPane tips;
/*     */   
/*  53 */   private RecordComboMgr recordMgr = new RecordComboMgr(new AbstractAction()
/*     */   {
/*     */ 
/*     */ 
/*     */     public void actionPerformed(ActionEvent arg0)
/*     */     {
/*     */ 
/*  60 */       Pnl5RecordTable.this.setRecord();
/*     */     }
/*  53 */   });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ColumnSelector columnSelector;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Pnl5RecordTable(JTextComponent msg)
/*     */   {
/*  72 */     this.columnSelector = new ColumnSelector(msg);
/*     */     
/*  74 */     String formDescription = "This screen will display the first 60 lines for each Record Type. <br>Use the Record Combo to switch between the various record layouts.<br/><br>Indicate the <i>start</i> of a <b>field</b> by clicking on the starting column<br>Each succesive <b>field</b> will have alternating background color<p>To remove a <b>field</b> click on the starting column again.";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  80 */     this.tips = new JEditorPane("text/html", formDescription);
/*     */     
/*  82 */     setHelpURLre(Common.formatHelpURL("HlpLe04.htm#HDRWIZ2M"));
/*  83 */     addComponentRE(1, 5, TIP_HEIGHT, BasePanel.GAP0, 2, 2, this.tips);
/*     */     
/*     */ 
/*     */ 
/*  87 */     addLineRE("Record", this.recordMgr.recordCombo);
/*     */     
/*  89 */     this.columnSelector.addFields(this, FILE_HEIGHT);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  96 */     addMessageRE();
/*     */     
/*  98 */     this.columnSelector.addMouseListner();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Details getValues()
/*     */     throws Exception
/*     */   {
/* 107 */     Details detail = this.columnSelector.getCurrentDetails();
/*     */     
/* 109 */     for (int i = 0; i < detail.recordDtls.size(); i++) {
/* 110 */       RecordDefinition recdef = (RecordDefinition)detail.recordDtls.get(i);
/* 111 */       if (!recdef.displayedFieldSelection) {
/* 112 */         this.recordMgr.recordCombo.setSelectedIndex(i);
/* 113 */         throw new RecordException("You must define the Fields for all Records. Please update - {0}", recdef.name);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 119 */     return detail;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void setValues(Details detail)
/*     */     throws Exception
/*     */   {
/* 127 */     if (detail.recordDtls.size() == 0) {
/* 128 */       setMessageTxtRE("No Records to display");
/*     */     } else {
/* 130 */       RecordDefinition recDef = (RecordDefinition)detail.recordDtls.get(0);
/* 131 */       this.columnSelector.setValues(detail, recDef, true);
/* 132 */       recDef.displayedFieldSelection = true;
/*     */       
/* 134 */       this.recordMgr.load(detail.recordDtls);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void setRecord()
/*     */   {
/* 142 */     Details detail = this.columnSelector.getCurrentDetails();
/*     */     try {
/* 144 */       RecordDefinition recDef = (RecordDefinition)detail.recordDtls.get(this.recordMgr.recordCombo.getSelectedIndex());
/* 145 */       setMessageRawTxtRE("");
/* 146 */       this.columnSelector.setValues(detail, recDef, true);
/* 147 */       recDef.displayedFieldSelection = true;
/*     */     } catch (Exception e) {
/* 149 */       setMessageTxtRE("Error Changing Record: " + e.getMessage());
/* 150 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/layoutWizard/Pnl5RecordTable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */