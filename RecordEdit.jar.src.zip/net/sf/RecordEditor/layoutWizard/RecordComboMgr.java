/*    */ package net.sf.RecordEditor.layoutWizard;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import javax.swing.AbstractAction;
/*    */ import javax.swing.JComboBox;
/*    */ 
/*    */ public class RecordComboMgr
/*    */ {
/*  9 */   public final JComboBox recordCombo = new JComboBox();
/*    */   
/*    */   private AbstractAction recordAction;
/*    */   
/*    */   public RecordComboMgr(AbstractAction recordAction)
/*    */   {
/* 15 */     this.recordAction = recordAction;
/*    */   }
/*    */   
/*    */   public void load(ArrayList<RecordDefinition> recordDtls) {
/* 19 */     this.recordCombo.removeActionListener(this.recordAction);
/* 20 */     this.recordCombo.removeAllItems();
/*    */     
/* 22 */     if (recordDtls.size() > 0) {
/* 23 */       for (RecordDefinition def : recordDtls) {
/* 24 */         this.recordCombo.addItem(def.name);
/*    */       }
/* 26 */       this.recordCombo.setSelectedIndex(0);
/*    */     }
/* 28 */     this.recordCombo.addActionListener(this.recordAction);
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/layoutWizard/RecordComboMgr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */