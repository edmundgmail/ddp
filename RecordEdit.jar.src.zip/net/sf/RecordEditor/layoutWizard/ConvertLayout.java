/*     */ package net.sf.RecordEditor.layoutWizard;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JTextField;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.External.CopybookLoader;
/*     */ import net.sf.JRecord.External.CopybookLoaderFactory;
/*     */ import net.sf.JRecord.External.CopybookWriter;
/*     */ import net.sf.JRecord.External.CopybookWriterManager;
/*     */ import net.sf.JRecord.External.ExternalRecord;
/*     */ import net.sf.JRecord.External.ToExternalRecord;
/*     */ import net.sf.JRecord.IO.LineIOProvider;
/*     */ import net.sf.JRecord.Log.ScreenLog;
/*     */ import net.sf.RecordEditor.re.openFile.ComputerOptionCombo;
/*     */ import net.sf.RecordEditor.re.openFile.ReadLayout;
/*     */ import net.sf.RecordEditor.re.openFile.RecentFiles;
/*     */ import net.sf.RecordEditor.re.openFile.SplitCombo;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.edit.ManagerRowList;
/*     */ import net.sf.RecordEditor.utils.msg.UtMessages;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions.FileNameOpt;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMsg;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.BmKeyedComboBox;
/*     */ import net.sf.RecordEditor.utils.swing.ComboBoxs.ManagerCombo;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.FileSelectCombo;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.TreeComboFileSelect;
/*     */ 
/*     */ public class ConvertLayout extends ReFrame
/*     */ {
/*  37 */   private ManagerCombo loaderOptions = ManagerCombo.newCopybookLoaderCombo();
/*  38 */   private FileSelectCombo copybookFile = new FileSelectCombo("SchemaFiles.", 25, true, false);
/*  39 */   private SplitCombo splitOptions = new SplitCombo();
/*  40 */   private JTextField fontName = new JTextField();
/*  41 */   private BmKeyedComboBox fileStructure = new BmKeyedComboBox(new ManagerRowList(LineIOProvider.getInstance(), false), false);
/*     */   
/*     */ 
/*  44 */   private ComputerOptionCombo binaryOptions = new ComputerOptionCombo();
/*  45 */   private TreeComboFileSelect sampleFile = new TreeComboFileSelect(true, false, true, RecentFiles.getMainRecentFile());
/*  46 */   private JTextField layoutName = new JTextField();
/*     */   
/*  48 */   private BmKeyedComboBox writerOptions = new BmKeyedComboBox(new ManagerRowList(CopybookWriterManager.getInstance(), false), false);
/*     */   
/*  50 */   private FileSelectCombo outputCopybookDir = new FileSelectCombo("OutputSchemas.", 25, false, false, true);
/*     */   
/*  52 */   private JButton goBtn = SwingUtils.newButton("Convert");
/*     */   
/*     */   private ScreenLog msgField;
/*     */   
/*  56 */   private ActionListener listner = new ActionListener()
/*     */   {
/*     */ 
/*     */ 
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/*     */ 
/*  63 */       if (e.getSource() == ConvertLayout.this.goBtn) {
/*  64 */         ConvertLayout.this.copyLayout();
/*     */       } else {
/*  66 */         int loaderId = ConvertLayout.this.loaderOptions.getSelectedIndex();
/*  67 */         if (loaderId >= 0) {
/*  68 */           boolean enabled = CopybookLoaderFactory.getInstance().isBasedOnInputFile(loaderId);
/*     */           
/*  70 */           ConvertLayout.this.sampleFile.setEnabled(enabled);
/*  71 */           ConvertLayout.this.layoutName.setEnabled(enabled);
/*     */         }
/*     */       }
/*     */     }
/*     */   };
/*     */   
/*     */   public ConvertLayout()
/*     */   {
/*  79 */     super("", "Convert Copybook", null);
/*     */     
/*  81 */     init_Fields();
/*  82 */     setup_Screen();
/*     */   }
/*     */   
/*     */   private void init_Fields() {
/*  86 */     String dir = Parameters.getFileName("CopybookDirectory");
/*     */     
/*     */ 
/*     */ 
/*  90 */     this.loaderOptions.setEnglish(Common.OPTIONS.COPYBOOK_READER.get());
/*  91 */     if (this.loaderOptions.getSelectedIndex() < 0) {
/*  92 */       this.loaderOptions.setSelectedIndex(0);
/*     */     }
/*     */     
/*  95 */     this.copybookFile.setText(dir);
/*  96 */     this.outputCopybookDir.setText(dir);
/*     */     
/*  98 */     this.writerOptions.setSelectedIndex(Common.getCopybookWriterIndex());
/*     */     
/* 100 */     this.sampleFile.setText(Common.OPTIONS.DEFAULT_FILE_DIRECTORY.getWithStar());
/*     */     
/* 102 */     this.sampleFile.setEnabled(false);
/* 103 */     this.layoutName.setEnabled(false);
/*     */   }
/*     */   
/*     */   private void setup_Screen() {
/* 107 */     BasePanel pnl = new BasePanel();
/*     */     
/* 109 */     this.msgField = new ScreenLog(pnl);
/*     */     
/* 111 */     pnl.setGapRE(BasePanel.GAP2);
/* 112 */     pnl.addLineRE("Input Copybook", this.copybookFile);
/* 113 */     pnl.addLineRE("Input Copybook Type", this.loaderOptions);
/* 114 */     pnl.addLineRE("Split Copybook", this.splitOptions);
/* 115 */     pnl.addLineRE("File Structure", this.fileStructure);
/* 116 */     pnl.addLineRE("Font Name", this.fontName);
/* 117 */     pnl.addLineRE("Binary Format", this.binaryOptions);
/* 118 */     pnl.setGapRE(BasePanel.GAP1);
/* 119 */     pnl.addLineRE("Sample File", this.sampleFile);
/* 120 */     pnl.addLineRE("Layout Name", this.layoutName);
/*     */     
/* 122 */     pnl.setGapRE(BasePanel.GAP3);
/*     */     
/* 124 */     pnl.addLineRE("Output Copybook Directory", this.outputCopybookDir);
/* 125 */     pnl.addLineRE("Output Copybook Type", this.writerOptions, this.goBtn);
/* 126 */     pnl.setGapRE(BasePanel.GAP3);
/*     */     
/* 128 */     pnl.addMessage(this.msgField);
/* 129 */     pnl.setHeightRE(BasePanel.GAP4);
/*     */     
/* 131 */     addMainComponent(pnl);
/* 132 */     setVisible(true);
/*     */     
/* 134 */     this.goBtn.addActionListener(this.listner);
/* 135 */     this.loaderOptions.addActionListener(this.listner);
/*     */   }
/*     */   
/*     */   private void copyLayout() {
/* 139 */     CopybookLoaderFactory loaders = CopybookLoaderFactory.getInstance();
/* 140 */     CopybookWriterManager writers = CopybookWriterManager.getInstance();
/* 141 */     int loaderId = this.loaderOptions.getSelectedIndex();
/* 142 */     int split = this.splitOptions.getSelectedValue();
/*     */     try {
/* 144 */       if (loaders.isBasedOnInputFile(loaderId)) {
/* 145 */         if ("".equals(this.sampleFile.getText())) {
/* 146 */           this.msgField.logMsg(30, UtMessages.SAMPLE_FILE_MSG.get());
/* 147 */           this.sampleFile.requestFocus();
/* 148 */         } else if ("".equals(this.layoutName.getText())) {
/* 149 */           this.msgField.logMsg(30, UtMessages.LAYOUT_MSG.get());
/* 150 */           this.layoutName.requestFocus();
/*     */         } else {
/* 152 */           boolean isCsv = loaders.isCsv(loaderId);
/* 153 */           int struc = 62;
/* 154 */           if (isCsv) {
/* 155 */             struc = 51;
/*     */           }
/* 157 */           AbstractLayoutDetails dtl = new ReadLayout().setLoadFromFile(true).buildLayoutFromSample(struc, isCsv, this.fontName.getText(), loaders.getFieldDelim(loaderId), this.sampleFile.getText());
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 166 */           ExternalRecord rec = ToExternalRecord.getInstance().getExternalRecord(dtl, this.layoutName.getText(), 0);
/*     */           
/* 168 */           rec.setDelimiter(loaders.getFieldDelim(loaderId));
/* 169 */           ((CopybookWriter)writers.get(this.writerOptions.getSelectedIndex())).writeCopyBook(this.outputCopybookDir.getText(), rec, this.msgField);
/*     */         }
/*     */         
/*     */ 
/*     */       }
/* 174 */       else if ("".equals(this.copybookFile.getText())) {
/* 175 */         this.msgField.logMsg(30, UtMessages.INPUT_COPYBOOK.get());
/* 176 */         this.copybookFile.requestFocus();
/*     */       }
/*     */       else {
/* 179 */         ExternalRecord rec = loaders.getLoader(loaderId).loadCopyBook(this.copybookFile.getText(), split, 0, this.fontName.getText(), this.binaryOptions.getSelectedIndex(), 0, this.msgField);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 188 */         rec.setFileStructure(((Integer)this.fileStructure.getSelectedItem()).intValue());
/*     */         
/* 190 */         ((CopybookWriter)writers.get(this.writerOptions.getSelectedIndex())).writeCopyBook(this.outputCopybookDir.getText(), rec, this.msgField);
/*     */       }
/*     */     }
/*     */     catch (NoClassDefFoundError e)
/*     */     {
/* 195 */       e.printStackTrace();
/*     */     }
/*     */     catch (Exception e) {
/* 198 */       this.msgField.logMsg(30, UtMessages.ERROR_CONVERTING_COPYBOOK.get());
/* 199 */       this.msgField.logException(30, e);
/* 200 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/layoutWizard/ConvertLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */