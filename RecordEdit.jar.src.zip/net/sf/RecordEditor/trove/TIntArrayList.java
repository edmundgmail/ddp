/*      */ package net.sf.RecordEditor.trove;
/*      */ 
/*      */ import java.io.Externalizable;
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInput;
/*      */ import java.io.ObjectOutput;
/*      */ import java.util.Arrays;
/*      */ import java.util.ConcurrentModificationException;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.Random;
/*      */ import net.sf.RecordEditor.trove.iterator.TIntIterator;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class TIntArrayList
/*      */   implements TIntList, Externalizable
/*      */ {
/*      */   static final long serialVersionUID = 1L;
/*      */   protected int[] _data;
/*      */   protected int _pos;
/*      */   protected static final int DEFAULT_CAPACITY = 512;
/*      */   protected int no_entry_value;
/*      */   
/*      */   public TIntArrayList()
/*      */   {
/*   66 */     this(512, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TIntArrayList(int capacity)
/*      */   {
/*   77 */     this(capacity, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TIntArrayList(int capacity, int no_entry_value)
/*      */   {
/*   89 */     this._data = new int[capacity];
/*   90 */     this._pos = 0;
/*   91 */     this.no_entry_value = no_entry_value;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TIntArrayList(TIntCollection collection)
/*      */   {
/*  101 */     this(collection.size());
/*  102 */     addAll(collection);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TIntArrayList(int[] values)
/*      */   {
/*  116 */     this(values.length);
/*  117 */     add(values);
/*      */   }
/*      */   
/*      */   protected TIntArrayList(int[] values, int no_entry_value, boolean wrap) {
/*  121 */     if (!wrap) {
/*  122 */       throw new IllegalStateException("Wrong call");
/*      */     }
/*  124 */     if (values == null) {
/*  125 */       throw new IllegalArgumentException("values can not be null");
/*      */     }
/*  127 */     this._data = values;
/*  128 */     this._pos = values.length;
/*  129 */     this.no_entry_value = no_entry_value;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static TIntArrayList wrap(int[] values)
/*      */   {
/*  142 */     return wrap(values, 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static TIntArrayList wrap(int[] values, int no_entry_value)
/*      */   {
/*  156 */     new TIntArrayList(values, no_entry_value, true)
/*      */     {
/*      */ 
/*      */       public void ensureCapacity(int capacity)
/*      */       {
/*      */ 
/*  162 */         if (capacity > this._data.length) {
/*  163 */           throw new IllegalStateException("Can not grow ArrayList wrapped external array");
/*      */         }
/*      */       }
/*      */     };
/*      */   }
/*      */   
/*      */   public int getNoEntryValue() {
/*  170 */     return this.no_entry_value;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void ensureCapacity(int capacity)
/*      */   {
/*  182 */     if (capacity > this._data.length) {
/*  183 */       int newCap = Math.max(this._data.length << 1, capacity);
/*  184 */       int[] tmp = new int[newCap];
/*  185 */       System.arraycopy(this._data, 0, tmp, 0, this._data.length);
/*  186 */       this._data = tmp;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public int size()
/*      */   {
/*  193 */     return this._pos;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean isEmpty()
/*      */   {
/*  199 */     return this._pos == 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void trimToSize()
/*      */   {
/*  207 */     if (this._data.length > size()) {
/*  208 */       int[] tmp = new int[size()];
/*  209 */       toArray(tmp, 0, tmp.length);
/*  210 */       this._data = tmp;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean add(int val)
/*      */   {
/*  219 */     ensureCapacity(this._pos + 1);
/*  220 */     this._data[(this._pos++)] = val;
/*  221 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */   public void add(int[] vals)
/*      */   {
/*  227 */     add(vals, 0, vals.length);
/*      */   }
/*      */   
/*      */ 
/*      */   public void add(int[] vals, int offset, int length)
/*      */   {
/*  233 */     ensureCapacity(this._pos + length);
/*  234 */     System.arraycopy(vals, offset, this._data, this._pos, length);
/*  235 */     this._pos += length;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void insert(int offset, int value)
/*      */   {
/*  253 */     if (offset == this._pos) {
/*  254 */       add(value);
/*  255 */       return;
/*      */     }
/*  257 */     ensureCapacity(this._pos + 1);
/*      */     
/*  259 */     System.arraycopy(this._data, offset, this._data, offset + 1, this._pos - offset);
/*      */     
/*  261 */     this._data[offset] = value;
/*  262 */     this._pos += 1;
/*      */   }
/*      */   
/*      */ 
/*      */   public void insert(int offset, int[] values)
/*      */   {
/*  268 */     insert(offset, values, 0, values.length);
/*      */   }
/*      */   
/*      */ 
/*      */   public void insert(int offset, int[] values, int valOffset, int len)
/*      */   {
/*  274 */     if (offset == this._pos) {
/*  275 */       add(values, valOffset, len);
/*  276 */       return;
/*      */     }
/*      */     
/*  279 */     ensureCapacity(this._pos + len);
/*      */     
/*  281 */     System.arraycopy(this._data, offset, this._data, offset + len, this._pos - offset);
/*      */     
/*  283 */     System.arraycopy(values, valOffset, this._data, offset, len);
/*  284 */     this._pos += len;
/*      */   }
/*      */   
/*      */ 
/*      */   public int get(int offset)
/*      */   {
/*  290 */     if (offset >= this._pos) {
/*  291 */       throw new ArrayIndexOutOfBoundsException(offset);
/*      */     }
/*  293 */     return this._data[offset];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getQuick(int offset)
/*      */   {
/*  301 */     return this._data[offset];
/*      */   }
/*      */   
/*      */ 
/*      */   public int set(int offset, int val)
/*      */   {
/*  307 */     if (offset >= this._pos) {
/*  308 */       throw new ArrayIndexOutOfBoundsException(offset);
/*      */     }
/*      */     
/*  311 */     int prev_val = this._data[offset];
/*  312 */     this._data[offset] = val;
/*  313 */     return prev_val;
/*      */   }
/*      */   
/*      */ 
/*      */   public int replace(int offset, int val)
/*      */   {
/*  319 */     if (offset >= this._pos) {
/*  320 */       throw new ArrayIndexOutOfBoundsException(offset);
/*      */     }
/*  322 */     int old = this._data[offset];
/*  323 */     this._data[offset] = val;
/*  324 */     return old;
/*      */   }
/*      */   
/*      */ 
/*      */   public void set(int offset, int[] values)
/*      */   {
/*  330 */     set(offset, values, 0, values.length);
/*      */   }
/*      */   
/*      */ 
/*      */   public void set(int offset, int[] values, int valOffset, int length)
/*      */   {
/*  336 */     if ((offset < 0) || (offset + length > this._pos)) {
/*  337 */       throw new ArrayIndexOutOfBoundsException(offset);
/*      */     }
/*  339 */     System.arraycopy(values, valOffset, this._data, offset, length);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setQuick(int offset, int val)
/*      */   {
/*  347 */     this._data[offset] = val;
/*      */   }
/*      */   
/*      */ 
/*      */   public void clear()
/*      */   {
/*  353 */     clear(512);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void clear(int capacity)
/*      */   {
/*  362 */     this._data = new int[capacity];
/*  363 */     this._pos = 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void reset()
/*      */   {
/*  373 */     this._pos = 0;
/*  374 */     Arrays.fill(this._data, this.no_entry_value);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void resetQuick()
/*      */   {
/*  387 */     this._pos = 0;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean remove(int value)
/*      */   {
/*  393 */     for (int index = 0; index < this._pos; index++) {
/*  394 */       if (value == this._data[index]) {
/*  395 */         remove(index, 1);
/*  396 */         return true;
/*      */       }
/*      */     }
/*  399 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */   public int removeAt(int offset)
/*      */   {
/*  405 */     int old = get(offset);
/*  406 */     remove(offset, 1);
/*  407 */     return old;
/*      */   }
/*      */   
/*      */ 
/*      */   public void remove(int offset, int length)
/*      */   {
/*  413 */     if (length == 0) return;
/*  414 */     if ((offset < 0) || (offset >= this._pos)) {
/*  415 */       throw new ArrayIndexOutOfBoundsException(offset);
/*      */     }
/*      */     
/*  418 */     if (offset == 0)
/*      */     {
/*  420 */       System.arraycopy(this._data, length, this._data, 0, this._pos - length);
/*      */     }
/*  422 */     else if (this._pos - length != offset)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  428 */       System.arraycopy(this._data, offset + length, this._data, offset, this._pos - (offset + length));
/*      */     }
/*      */     
/*  431 */     this._pos -= length;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public TIntIterator iterator()
/*      */   {
/*  440 */     return new TIntArrayIterator(0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean containsAll(TIntCollection collection)
/*      */   {
/*  463 */     if (this == collection) {
/*  464 */       return true;
/*      */     }
/*  466 */     TIntIterator iter = collection.iterator();
/*  467 */     while (iter.hasNext()) {
/*  468 */       int element = iter.next();
/*  469 */       if (!contains(element)) {
/*  470 */         return false;
/*      */       }
/*      */     }
/*  473 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean containsAll(int[] array)
/*      */   {
/*  479 */     for (int i = array.length; i-- > 0;) {
/*  480 */       if (!contains(array[i])) {
/*  481 */         return false;
/*      */       }
/*      */     }
/*  484 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean addAll(TIntCollection collection)
/*      */   {
/*  503 */     boolean changed = false;
/*  504 */     TIntIterator iter = collection.iterator();
/*  505 */     while (iter.hasNext()) {
/*  506 */       int element = iter.next();
/*  507 */       if (add(element)) {
/*  508 */         changed = true;
/*      */       }
/*      */     }
/*  511 */     return changed;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean addAll(int[] array)
/*      */   {
/*  517 */     boolean changed = false;
/*  518 */     for (int element : array) {
/*  519 */       if (add(element)) {
/*  520 */         changed = true;
/*      */       }
/*      */     }
/*  523 */     return changed;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean retainAll(TIntCollection collection)
/*      */   {
/*  544 */     if (this == collection) {
/*  545 */       return false;
/*      */     }
/*  547 */     boolean modified = false;
/*  548 */     TIntIterator iter = iterator();
/*  549 */     while (iter.hasNext()) {
/*  550 */       if (!collection.contains(iter.next())) {
/*  551 */         iter.remove();
/*  552 */         modified = true;
/*      */       }
/*      */     }
/*  555 */     return modified;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean retainAll(int[] array)
/*      */   {
/*  561 */     boolean changed = false;
/*  562 */     Arrays.sort(array);
/*  563 */     int[] data = this._data;
/*      */     
/*  565 */     for (int i = this._pos; i-- > 0;) {
/*  566 */       if (Arrays.binarySearch(array, data[i]) < 0) {
/*  567 */         remove(i, 1);
/*  568 */         changed = true;
/*      */       }
/*      */     }
/*  571 */     return changed;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean removeAll(TIntCollection collection)
/*      */   {
/*  592 */     if (collection == this) {
/*  593 */       clear();
/*  594 */       return true;
/*      */     }
/*  596 */     boolean changed = false;
/*  597 */     TIntIterator iter = collection.iterator();
/*  598 */     while (iter.hasNext()) {
/*  599 */       int element = iter.next();
/*  600 */       if (remove(element)) {
/*  601 */         changed = true;
/*      */       }
/*      */     }
/*  604 */     return changed;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean removeAll(int[] array)
/*      */   {
/*  610 */     boolean changed = false;
/*  611 */     for (int i = array.length; i-- > 0;) {
/*  612 */       if (remove(array[i])) {
/*  613 */         changed = true;
/*      */       }
/*      */     }
/*  616 */     return changed;
/*      */   }
/*      */   
/*      */ 
/*      */   public void transformValues(TIntFunction function)
/*      */   {
/*  622 */     for (int i = this._pos; i-- > 0;) {
/*  623 */       this._data[i] = function.execute(this._data[i]);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void reverse()
/*      */   {
/*  630 */     reverse(0, this._pos);
/*      */   }
/*      */   
/*      */ 
/*      */   public void reverse(int from, int to)
/*      */   {
/*  636 */     if (from == to) {
/*  637 */       return;
/*      */     }
/*  639 */     if (from > to) {
/*  640 */       throw new IllegalArgumentException("from cannot be greater than to");
/*      */     }
/*  642 */     int i = from; for (int j = to - 1; i < j; j--) {
/*  643 */       swap(i, j);i++;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   public void shuffle(Random rand)
/*      */   {
/*  650 */     for (int i = this._pos; i-- > 1;) {
/*  651 */       swap(i, rand.nextInt(i));
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void swap(int i, int j)
/*      */   {
/*  663 */     int tmp = this._data[i];
/*  664 */     this._data[i] = this._data[j];
/*  665 */     this._data[j] = tmp;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public TIntList subList(int begin, int end)
/*      */   {
/*  673 */     if (end < begin) {
/*  674 */       throw new IllegalArgumentException("end index " + end + " greater than begin index " + begin);
/*      */     }
/*      */     
/*  677 */     if (begin < 0) {
/*  678 */       throw new IndexOutOfBoundsException("begin index can not be < 0");
/*      */     }
/*  680 */     if (end > this._data.length) {
/*  681 */       throw new IndexOutOfBoundsException("end index < " + this._data.length);
/*      */     }
/*  683 */     TIntArrayList list = new TIntArrayList(end - begin);
/*  684 */     for (int i = begin; i < end; i++) {
/*  685 */       list.add(this._data[i]);
/*      */     }
/*  687 */     return list;
/*      */   }
/*      */   
/*      */ 
/*      */   public int[] toArray()
/*      */   {
/*  693 */     return toArray(0, this._pos);
/*      */   }
/*      */   
/*      */ 
/*      */   public int[] toArray(int offset, int len)
/*      */   {
/*  699 */     int[] rv = new int[len];
/*  700 */     toArray(rv, offset, len);
/*  701 */     return rv;
/*      */   }
/*      */   
/*      */ 
/*      */   public int[] toArray(int[] dest)
/*      */   {
/*  707 */     int len = dest.length;
/*  708 */     if (dest.length > this._pos) {
/*  709 */       len = this._pos;
/*  710 */       dest[len] = this.no_entry_value;
/*      */     }
/*  712 */     toArray(dest, 0, len);
/*  713 */     return dest;
/*      */   }
/*      */   
/*      */ 
/*      */   public int[] toArray(int[] dest, int offset, int len)
/*      */   {
/*  719 */     if (len == 0) {
/*  720 */       return dest;
/*      */     }
/*  722 */     if ((offset < 0) || (offset >= this._pos)) {
/*  723 */       throw new ArrayIndexOutOfBoundsException(offset);
/*      */     }
/*  725 */     System.arraycopy(this._data, offset, dest, 0, len);
/*  726 */     return dest;
/*      */   }
/*      */   
/*      */ 
/*      */   public int[] toArray(int[] dest, int source_pos, int dest_pos, int len)
/*      */   {
/*  732 */     if (len == 0) {
/*  733 */       return dest;
/*      */     }
/*  735 */     if ((source_pos < 0) || (source_pos >= this._pos)) {
/*  736 */       throw new ArrayIndexOutOfBoundsException(source_pos);
/*      */     }
/*  738 */     System.arraycopy(this._data, source_pos, dest, dest_pos, len);
/*  739 */     return dest;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean equals(Object other)
/*      */   {
/*  748 */     if (other == this) {
/*  749 */       return true;
/*      */     }
/*  751 */     if ((other instanceof TIntArrayList)) {
/*  752 */       TIntArrayList that = (TIntArrayList)other;
/*  753 */       if (that.size() != size()) { return false;
/*      */       }
/*  755 */       for (int i = this._pos; i-- > 0;) {
/*  756 */         if (this._data[i] != that._data[i]) {
/*  757 */           return false;
/*      */         }
/*      */       }
/*  760 */       return true;
/*      */     }
/*      */     
/*  763 */     return false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public int hashCode()
/*      */   {
/*  770 */     int h = 0;
/*  771 */     for (int i = this._pos; i-- > 0;) {
/*  772 */       h += this._data[i];
/*      */     }
/*      */     
/*      */ 
/*  776 */     return h;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void sort()
/*      */   {
/*  808 */     Arrays.sort(this._data, 0, this._pos);
/*      */   }
/*      */   
/*      */ 
/*      */   public void sort(int fromIndex, int toIndex)
/*      */   {
/*  814 */     Arrays.sort(this._data, fromIndex, toIndex);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void fill(int val)
/*      */   {
/*  822 */     Arrays.fill(this._data, 0, this._pos, val);
/*      */   }
/*      */   
/*      */ 
/*      */   public void fill(int fromIndex, int toIndex, int val)
/*      */   {
/*  828 */     if (toIndex > this._pos) {
/*  829 */       ensureCapacity(toIndex);
/*  830 */       this._pos = toIndex;
/*      */     }
/*  832 */     Arrays.fill(this._data, fromIndex, toIndex, val);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int binarySearch(int value)
/*      */   {
/*  840 */     return binarySearch(value, 0, this._pos);
/*      */   }
/*      */   
/*      */ 
/*      */   public int binarySearch(int value, int fromIndex, int toIndex)
/*      */   {
/*  846 */     if (fromIndex < 0) {
/*  847 */       throw new ArrayIndexOutOfBoundsException(fromIndex);
/*      */     }
/*  849 */     if (toIndex > this._pos) {
/*  850 */       throw new ArrayIndexOutOfBoundsException(toIndex);
/*      */     }
/*      */     
/*  853 */     int low = fromIndex;
/*  854 */     int high = toIndex - 1;
/*      */     
/*  856 */     while (low <= high) {
/*  857 */       int mid = low + high >>> 1;
/*  858 */       int midVal = this._data[mid];
/*      */       
/*  860 */       if (midVal < value) {
/*  861 */         low = mid + 1;
/*      */       }
/*  863 */       else if (midVal > value) {
/*  864 */         high = mid - 1;
/*      */       }
/*      */       else {
/*  867 */         return mid;
/*      */       }
/*      */     }
/*  870 */     return -(low + 1);
/*      */   }
/*      */   
/*      */ 
/*      */   public int indexOf(int value)
/*      */   {
/*  876 */     return indexOf(0, value);
/*      */   }
/*      */   
/*      */ 
/*      */   public int indexOf(int offset, int value)
/*      */   {
/*  882 */     for (int i = offset; i < this._pos; i++) {
/*  883 */       if (this._data[i] == value) {
/*  884 */         return i;
/*      */       }
/*      */     }
/*  887 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */   public int lastIndexOf(int value)
/*      */   {
/*  893 */     return lastIndexOf(this._pos, value);
/*      */   }
/*      */   
/*      */ 
/*      */   public int lastIndexOf(int offset, int value)
/*      */   {
/*  899 */     for (int i = offset; i-- > 0;) {
/*  900 */       if (this._data[i] == value) {
/*  901 */         return i;
/*      */       }
/*      */     }
/*  904 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean contains(int value)
/*      */   {
/*  910 */     return lastIndexOf(value) >= 0;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int max()
/*      */   {
/*  940 */     if (size() == 0) {
/*  941 */       throw new IllegalStateException("cannot find maximum of an empty list");
/*      */     }
/*  943 */     int max = Integer.MIN_VALUE;
/*  944 */     for (int i = 0; i < this._pos; i++) {
/*  945 */       if (this._data[i] > max) {
/*  946 */         max = this._data[i];
/*      */       }
/*      */     }
/*  949 */     return max;
/*      */   }
/*      */   
/*      */ 
/*      */   public int min()
/*      */   {
/*  955 */     if (size() == 0) {
/*  956 */       throw new IllegalStateException("cannot find minimum of an empty list");
/*      */     }
/*  958 */     int min = Integer.MAX_VALUE;
/*  959 */     for (int i = 0; i < this._pos; i++) {
/*  960 */       if (this._data[i] < min) {
/*  961 */         min = this._data[i];
/*      */       }
/*      */     }
/*  964 */     return min;
/*      */   }
/*      */   
/*      */ 
/*      */   public int sum()
/*      */   {
/*  970 */     int sum = 0;
/*  971 */     for (int i = 0; i < this._pos; i++) {
/*  972 */       sum += this._data[i];
/*      */     }
/*  974 */     return sum;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public String toString()
/*      */   {
/*  983 */     StringBuilder buf = new StringBuilder("{");
/*  984 */     int i = 0; for (int end = this._pos - 1; i < end; i++) {
/*  985 */       buf.append(this._data[i]);
/*  986 */       buf.append(", ");
/*      */     }
/*  988 */     if (size() > 0) {
/*  989 */       buf.append(this._data[(this._pos - 1)]);
/*      */     }
/*  991 */     buf.append("}");
/*  992 */     return buf.toString();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   class TIntArrayIterator
/*      */     implements TIntIterator
/*      */   {
/* 1000 */     private int cursor = 0;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1007 */     int lastRet = -1;
/*      */     
/*      */     TIntArrayIterator(int index)
/*      */     {
/* 1011 */       this.cursor = index;
/*      */     }
/*      */     
/*      */ 
/*      */     public boolean hasNext()
/*      */     {
/* 1017 */       return this.cursor < TIntArrayList.this.size();
/*      */     }
/*      */     
/*      */     public int next()
/*      */     {
/*      */       try
/*      */       {
/* 1024 */         int next = TIntArrayList.this.get(this.cursor);
/* 1025 */         this.lastRet = (this.cursor++);
/* 1026 */         return next;
/*      */       } catch (IndexOutOfBoundsException e) {
/* 1028 */         throw new NoSuchElementException();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */     public void remove()
/*      */     {
/* 1035 */       if (this.lastRet == -1) {
/* 1036 */         throw new IllegalStateException();
/*      */       }
/*      */       try {
/* 1039 */         TIntArrayList.this.remove(this.lastRet, 1);
/* 1040 */         if (this.lastRet < this.cursor)
/* 1041 */           this.cursor -= 1;
/* 1042 */         this.lastRet = -1;
/*      */       } catch (IndexOutOfBoundsException e) {
/* 1044 */         throw new ConcurrentModificationException();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public void writeExternal(ObjectOutput out)
/*      */     throws IOException
/*      */   {
/* 1052 */     out.writeByte(0);
/*      */     
/*      */ 
/* 1055 */     out.writeInt(this._pos);
/*      */     
/*      */ 
/* 1058 */     out.writeInt(this.no_entry_value);
/*      */     
/*      */ 
/* 1061 */     int len = this._data.length;
/* 1062 */     out.writeInt(len);
/* 1063 */     for (int i = 0; i < len; i++) {
/* 1064 */       out.writeInt(this._data[i]);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void readExternal(ObjectInput in)
/*      */     throws IOException, ClassNotFoundException
/*      */   {
/* 1073 */     in.readByte();
/*      */     
/*      */ 
/* 1076 */     this._pos = in.readInt();
/*      */     
/*      */ 
/* 1079 */     this.no_entry_value = in.readInt();
/*      */     
/*      */ 
/* 1082 */     int len = in.readInt();
/* 1083 */     this._data = new int[len];
/* 1084 */     for (int i = 0; i < len; i++) {
/* 1085 */       this._data[i] = in.readInt();
/*      */     }
/*      */   }
/*      */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/trove/TIntArrayList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */