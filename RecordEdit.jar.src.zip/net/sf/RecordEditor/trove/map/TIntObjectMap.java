package net.sf.RecordEditor.trove.map;

import java.util.Collection;
import net.sf.RecordEditor.trove.procedure.TIntObjectProcedure;
import net.sf.RecordEditor.trove.set.TIntSet;

public abstract interface TIntObjectMap<V>
{
  public abstract int getNoEntryKey();
  
  public abstract int size();
  
  public abstract boolean isEmpty();
  
  public abstract boolean containsKey(int paramInt);
  
  public abstract boolean containsValue(Object paramObject);
  
  public abstract V get(int paramInt);
  
  public abstract V put(int paramInt, V paramV);
  
  public abstract V putIfAbsent(int paramInt, V paramV);
  
  public abstract V remove(int paramInt);
  
  public abstract void clear();
  
  public abstract TIntSet keySet();
  
  public abstract int[] keys();
  
  public abstract int[] keys(int[] paramArrayOfInt);
  
  public abstract Collection<V> valueCollection();
  
  public abstract Object[] values();
  
  public abstract V[] values(V[] paramArrayOfV);
  
  public abstract boolean forEachEntry(TIntObjectProcedure<? super V> paramTIntObjectProcedure);
  
  public abstract boolean equals(Object paramObject);
  
  public abstract int hashCode();
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/trove/map/TIntObjectMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */