package net.sf.RecordEditor.trove.procedure;

public abstract interface TIntObjectProcedure<T>
{
  public abstract boolean execute(int paramInt, T paramT);
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/trove/procedure/TIntObjectProcedure.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */