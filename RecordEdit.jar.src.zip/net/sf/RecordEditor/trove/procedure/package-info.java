package net.sf.RecordEditor.trove.procedure;

interface package-info {}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/trove/procedure/package-info.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */