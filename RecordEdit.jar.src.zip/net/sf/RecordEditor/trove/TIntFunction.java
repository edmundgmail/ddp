package net.sf.RecordEditor.trove;

public abstract interface TIntFunction
{
  public abstract int execute(int paramInt);
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/trove/TIntFunction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */