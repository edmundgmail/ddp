package net.sf.RecordEditor.trove.iterator;

public abstract interface TIntIterator
  extends TIterator
{
  public abstract int next();
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/trove/iterator/TIntIterator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */