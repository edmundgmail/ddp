package net.sf.RecordEditor.trove.iterator;

public abstract interface TIntObjectIterator<V>
  extends TAdvancingIterator
{
  public abstract int key();
  
  public abstract V value();
  
  public abstract V setValue(V paramV);
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/trove/iterator/TIntObjectIterator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */