package net.sf.RecordEditor.trove.iterator;

public abstract interface TPrimitiveIterator
  extends TIterator
{
  public abstract boolean hasNext();
  
  public abstract void remove();
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/trove/iterator/TPrimitiveIterator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */