/*     */ package net.sf.RecordEditor.trove.impl.hash;
/*     */ 
/*     */ import java.io.Externalizable;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInput;
/*     */ import java.io.ObjectOutput;
/*     */ import net.sf.RecordEditor.trove.impl.HashFunctions;
/*     */ import net.sf.RecordEditor.trove.impl.PrimeFinder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class THash
/*     */   implements Externalizable
/*     */ {
/*     */   static final long serialVersionUID = -1792948471915530295L;
/*     */   protected static final float DEFAULT_LOAD_FACTOR = 0.5F;
/*     */   protected static final int DEFAULT_CAPACITY = 10;
/*     */   protected transient int _size;
/*     */   protected transient int _free;
/*     */   protected float _loadFactor;
/*     */   protected int _maxSize;
/*     */   protected int _autoCompactRemovesRemaining;
/*     */   protected float _autoCompactionFactor;
/*  98 */   protected transient boolean _autoCompactTemporaryDisable = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public THash()
/*     */   {
/* 106 */     this(10, 0.5F);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public THash(int initialCapacity)
/*     */   {
/* 118 */     this(initialCapacity, 0.5F);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public THash(int initialCapacity, float loadFactor)
/*     */   {
/* 133 */     this._loadFactor = loadFactor;
/*     */     
/*     */ 
/*     */ 
/* 137 */     this._autoCompactionFactor = loadFactor;
/*     */     
/* 139 */     setUp(HashFunctions.fastCeil(initialCapacity / loadFactor));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 149 */     return 0 == this._size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int size()
/*     */   {
/* 159 */     return this._size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract int capacity();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void ensureCapacity(int desiredCapacity)
/*     */   {
/* 176 */     if (desiredCapacity > this._maxSize - size()) {
/* 177 */       rehash(PrimeFinder.nextPrime(Math.max(size() + 1, HashFunctions.fastCeil((desiredCapacity + size()) / this._loadFactor) + 1)));
/*     */       
/* 179 */       computeMaxSize(capacity());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void compact()
/*     */   {
/* 203 */     rehash(PrimeFinder.nextPrime(Math.max(this._size + 1, HashFunctions.fastCeil(size() / this._loadFactor) + 1)));
/*     */     
/* 205 */     computeMaxSize(capacity());
/*     */     
/*     */ 
/* 208 */     if (this._autoCompactionFactor != 0.0F) {
/* 209 */       computeNextAutoCompactionAmount(size());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAutoCompactionFactor(float factor)
/*     */   {
/* 226 */     if (factor < 0.0F) {
/* 227 */       throw new IllegalArgumentException("Factor must be >= 0: " + factor);
/*     */     }
/*     */     
/* 230 */     this._autoCompactionFactor = factor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public float getAutoCompactionFactor()
/*     */   {
/* 240 */     return this._autoCompactionFactor;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void trimToSize()
/*     */   {
/* 254 */     compact();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void removeAt(int index)
/*     */   {
/* 265 */     this._size -= 1;
/*     */     
/*     */ 
/* 268 */     if (this._autoCompactionFactor != 0.0F) {
/* 269 */       this._autoCompactRemovesRemaining -= 1;
/*     */       
/* 271 */       if ((!this._autoCompactTemporaryDisable) && (this._autoCompactRemovesRemaining <= 0))
/*     */       {
/*     */ 
/* 274 */         compact();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void clear()
/*     */   {
/* 282 */     this._size = 0;
/* 283 */     this._free = capacity();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int setUp(int initialCapacity)
/*     */   {
/* 297 */     int capacity = PrimeFinder.nextPrime(initialCapacity);
/* 298 */     computeMaxSize(capacity);
/* 299 */     computeNextAutoCompactionAmount(initialCapacity);
/*     */     
/* 301 */     return capacity;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void rehash(int paramInt);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void tempDisableAutoCompaction()
/*     */   {
/* 318 */     this._autoCompactTemporaryDisable = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reenableAutoCompaction(boolean check_for_compaction)
/*     */   {
/* 331 */     this._autoCompactTemporaryDisable = false;
/*     */     
/* 333 */     if ((check_for_compaction) && (this._autoCompactRemovesRemaining <= 0) && (this._autoCompactionFactor != 0.0F))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 338 */       compact();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void computeMaxSize(int capacity)
/*     */   {
/* 351 */     this._maxSize = Math.min(capacity - 1, (int)(capacity * this._loadFactor));
/* 352 */     this._free = (capacity - this._size);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void computeNextAutoCompactionAmount(int size)
/*     */   {
/* 363 */     if (this._autoCompactionFactor != 0.0F)
/*     */     {
/*     */ 
/* 366 */       this._autoCompactRemovesRemaining = ((int)(size * this._autoCompactionFactor + 0.5F));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void postInsertHook(boolean usedFreeSlot)
/*     */   {
/* 379 */     if (usedFreeSlot) {
/* 380 */       this._free -= 1;
/*     */     }
/*     */     
/*     */ 
/* 384 */     if ((++this._size > this._maxSize) || (this._free == 0))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/* 389 */       int newCapacity = this._size > this._maxSize ? PrimeFinder.nextPrime(capacity() << 1) : capacity();
/* 390 */       rehash(newCapacity);
/* 391 */       computeMaxSize(capacity());
/*     */     }
/*     */   }
/*     */   
/*     */   protected int calculateGrownCapacity()
/*     */   {
/* 397 */     return capacity() << 1;
/*     */   }
/*     */   
/*     */   public void writeExternal(ObjectOutput out)
/*     */     throws IOException
/*     */   {
/* 403 */     out.writeByte(0);
/*     */     
/*     */ 
/* 406 */     out.writeFloat(this._loadFactor);
/*     */     
/*     */ 
/* 409 */     out.writeFloat(this._autoCompactionFactor);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void readExternal(ObjectInput in)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 417 */     in.readByte();
/*     */     
/*     */ 
/* 420 */     float old_factor = this._loadFactor;
/* 421 */     this._loadFactor = in.readFloat();
/*     */     
/*     */ 
/* 424 */     this._autoCompactionFactor = in.readFloat();
/*     */     
/*     */ 
/* 427 */     if (old_factor != this._loadFactor) {
/* 428 */       setUp((int)Math.ceil(10.0F / this._loadFactor));
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/trove/impl/hash/THash.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */