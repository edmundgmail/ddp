/*     */ package net.sf.RecordEditor.trove.impl.hash;
/*     */ 
/*     */ import net.sf.RecordEditor.trove.impl.HashFunctions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class TPrimitiveHash
/*     */   extends THash
/*     */ {
/*     */   static final long serialVersionUID = 1L;
/*     */   public transient byte[] _states;
/*     */   public static final byte FREE = 0;
/*     */   public static final byte FULL = 1;
/*     */   public static final byte REMOVED = 2;
/*     */   
/*     */   public TPrimitiveHash() {}
/*     */   
/*     */   public TPrimitiveHash(int initialCapacity)
/*     */   {
/*  79 */     this(initialCapacity, 0.5F);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TPrimitiveHash(int initialCapacity, float loadFactor)
/*     */   {
/*  94 */     initialCapacity = Math.max(1, initialCapacity);
/*  95 */     this._loadFactor = loadFactor;
/*  96 */     setUp(HashFunctions.fastCeil(initialCapacity / loadFactor));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int capacity()
/*     */   {
/* 107 */     return this._states.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void removeAt(int index)
/*     */   {
/* 117 */     this._states[index] = 2;
/* 118 */     super.removeAt(index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int setUp(int initialCapacity)
/*     */   {
/* 132 */     int capacity = super.setUp(initialCapacity);
/* 133 */     this._states = new byte[capacity];
/* 134 */     return capacity;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/trove/impl/hash/TPrimitiveHash.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */