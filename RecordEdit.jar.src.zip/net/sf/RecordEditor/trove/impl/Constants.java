/*     */ package net.sf.RecordEditor.trove.impl;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Constants
/*     */ {
/*     */   private static final boolean VERBOSE;
/*     */   public static final int DEFAULT_CAPACITY = 10;
/*     */   public static final float DEFAULT_LOAD_FACTOR = 0.5F;
/*     */   public static final byte DEFAULT_BYTE_NO_ENTRY_VALUE;
/*     */   public static final short DEFAULT_SHORT_NO_ENTRY_VALUE;
/*     */   public static final char DEFAULT_CHAR_NO_ENTRY_VALUE;
/*     */   public static final int DEFAULT_INT_NO_ENTRY_VALUE;
/*     */   public static final long DEFAULT_LONG_NO_ENTRY_VALUE;
/*     */   public static final float DEFAULT_FLOAT_NO_ENTRY_VALUE;
/*     */   public static final double DEFAULT_DOUBLE_NO_ENTRY_VALUE;
/*     */   
/*     */   static
/*     */   {
/*  28 */     boolean verbose = false;
/*     */     try {
/*  30 */       verbose = System.getProperty("gnu.trove.verbose", null) != null;
/*     */     }
/*     */     catch (SecurityException ex) {}
/*     */     
/*     */ 
/*  35 */     VERBOSE = verbose;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  49 */     String property = "0";
/*     */     try {
/*  51 */       property = System.getProperty("gnu.trove.no_entry.byte", property);
/*     */     }
/*     */     catch (SecurityException ex) {}
/*     */     byte value;
/*     */     byte value;
/*  56 */     if ("MAX_VALUE".equalsIgnoreCase(property)) { value = Byte.MAX_VALUE; } else { byte value;
/*  57 */       if ("MIN_VALUE".equalsIgnoreCase(property)) value = Byte.MIN_VALUE; else
/*  58 */         value = Byte.valueOf(property).byteValue();
/*     */     }
/*  60 */     if (value > Byte.MAX_VALUE) { value = Byte.MAX_VALUE;
/*  61 */     } else if (value < Byte.MIN_VALUE) value = Byte.MIN_VALUE;
/*  62 */     DEFAULT_BYTE_NO_ENTRY_VALUE = value;
/*  63 */     if (VERBOSE) {
/*  64 */       System.out.println("DEFAULT_BYTE_NO_ENTRY_VALUE: " + DEFAULT_BYTE_NO_ENTRY_VALUE);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  74 */     String property = "0";
/*     */     try {
/*  76 */       property = System.getProperty("gnu.trove.no_entry.short", property);
/*     */     }
/*     */     catch (SecurityException ex) {}
/*     */     short value;
/*     */     short value;
/*  81 */     if ("MAX_VALUE".equalsIgnoreCase(property)) { value = Short.MAX_VALUE; } else { short value;
/*  82 */       if ("MIN_VALUE".equalsIgnoreCase(property)) value = Short.MIN_VALUE; else
/*  83 */         value = Short.valueOf(property).shortValue();
/*     */     }
/*  85 */     if (value > Short.MAX_VALUE) { value = Short.MAX_VALUE;
/*  86 */     } else if (value < Short.MIN_VALUE) value = Short.MIN_VALUE;
/*  87 */     DEFAULT_SHORT_NO_ENTRY_VALUE = value;
/*  88 */     if (VERBOSE) {
/*  89 */       System.out.println("DEFAULT_SHORT_NO_ENTRY_VALUE: " + DEFAULT_SHORT_NO_ENTRY_VALUE);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  99 */     String property = "\000";
/*     */     try {
/* 101 */       property = System.getProperty("gnu.trove.no_entry.char", property);
/*     */     }
/*     */     catch (SecurityException ex) {}
/*     */     char value;
/*     */     char value;
/* 106 */     if ("MAX_VALUE".equalsIgnoreCase(property)) { value = 65535; } else { char value;
/* 107 */       if ("MIN_VALUE".equalsIgnoreCase(property)) value = '\000'; else
/* 108 */         value = property.toCharArray()[0];
/*     */     }
/* 110 */     if (value > 65535) { value = 65535;
/* 111 */     } else if (value < 0) value = '\000';
/* 112 */     DEFAULT_CHAR_NO_ENTRY_VALUE = value;
/* 113 */     if (VERBOSE) {
/* 114 */       System.out.println("DEFAULT_CHAR_NO_ENTRY_VALUE: " + Integer.valueOf(value));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 124 */     String property = "0";
/*     */     try {
/* 126 */       property = System.getProperty("gnu.trove.no_entry.int", property);
/*     */     }
/*     */     catch (SecurityException ex) {}
/*     */     int value;
/*     */     int value;
/* 131 */     if ("MAX_VALUE".equalsIgnoreCase(property)) { value = Integer.MAX_VALUE; } else { int value;
/* 132 */       if ("MIN_VALUE".equalsIgnoreCase(property)) value = Integer.MIN_VALUE; else
/* 133 */         value = Integer.valueOf(property).intValue(); }
/* 134 */     DEFAULT_INT_NO_ENTRY_VALUE = value;
/* 135 */     if (VERBOSE) {
/* 136 */       System.out.println("DEFAULT_INT_NO_ENTRY_VALUE: " + DEFAULT_INT_NO_ENTRY_VALUE);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 146 */     String property = "0";
/*     */     try {
/* 148 */       property = System.getProperty("gnu.trove.no_entry.long", property);
/*     */     }
/*     */     catch (SecurityException ex) {}
/*     */     long value;
/*     */     long value;
/* 153 */     if ("MAX_VALUE".equalsIgnoreCase(property)) { value = Long.MAX_VALUE; } else { long value;
/* 154 */       if ("MIN_VALUE".equalsIgnoreCase(property)) value = Long.MIN_VALUE; else
/* 155 */         value = Long.valueOf(property).longValue(); }
/* 156 */     DEFAULT_LONG_NO_ENTRY_VALUE = value;
/* 157 */     if (VERBOSE) {
/* 158 */       System.out.println("DEFAULT_LONG_NO_ENTRY_VALUE: " + DEFAULT_LONG_NO_ENTRY_VALUE);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 168 */     String property = "0";
/*     */     try {
/* 170 */       property = System.getProperty("gnu.trove.no_entry.float", property);
/*     */     }
/*     */     catch (SecurityException ex) {}
/*     */     float value;
/*     */     float value;
/* 175 */     if ("MAX_VALUE".equalsIgnoreCase(property)) { value = Float.MAX_VALUE; } else { float value;
/* 176 */       if ("MIN_VALUE".equalsIgnoreCase(property)) { value = Float.MIN_VALUE;
/*     */       } else { float value;
/* 178 */         if ("MIN_NORMAL".equalsIgnoreCase(property)) { value = 1.17549435E-38F; } else { float value;
/* 179 */           if ("NEGATIVE_INFINITY".equalsIgnoreCase(property)) { value = Float.NEGATIVE_INFINITY; } else { float value;
/* 180 */             if ("POSITIVE_INFINITY".equalsIgnoreCase(property)) { value = Float.POSITIVE_INFINITY;
/*     */             } else
/* 182 */               value = Float.valueOf(property).floatValue(); } } } }
/* 183 */     DEFAULT_FLOAT_NO_ENTRY_VALUE = value;
/* 184 */     if (VERBOSE) {
/* 185 */       System.out.println("DEFAULT_FLOAT_NO_ENTRY_VALUE: " + DEFAULT_FLOAT_NO_ENTRY_VALUE);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 195 */     String property = "0";
/*     */     try {
/* 197 */       property = System.getProperty("gnu.trove.no_entry.double", property);
/*     */     }
/*     */     catch (SecurityException ex) {}
/*     */     double value;
/*     */     double value;
/* 202 */     if ("MAX_VALUE".equalsIgnoreCase(property)) { value = Double.MAX_VALUE; } else { double value;
/* 203 */       if ("MIN_VALUE".equalsIgnoreCase(property)) { value = Double.MIN_VALUE;
/*     */       } else { double value;
/* 205 */         if ("MIN_NORMAL".equalsIgnoreCase(property)) { value = 2.2250738585072014E-308D; } else { double value;
/* 206 */           if ("NEGATIVE_INFINITY".equalsIgnoreCase(property)) { value = Double.NEGATIVE_INFINITY; } else { double value;
/* 207 */             if ("POSITIVE_INFINITY".equalsIgnoreCase(property)) { value = Double.POSITIVE_INFINITY;
/*     */             } else
/* 209 */               value = Double.valueOf(property).doubleValue(); } } } }
/* 210 */     DEFAULT_DOUBLE_NO_ENTRY_VALUE = value;
/* 211 */     if (VERBOSE) {
/* 212 */       System.out.println("DEFAULT_DOUBLE_NO_ENTRY_VALUE: " + DEFAULT_DOUBLE_NO_ENTRY_VALUE);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/trove/impl/Constants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */