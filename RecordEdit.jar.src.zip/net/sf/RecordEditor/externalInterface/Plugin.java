package net.sf.RecordEditor.externalInterface;

import net.sf.RecordEditor.re.file.FileView;

public abstract interface Plugin
{
  public abstract void execute(String paramString, FileView paramFileView, int[] paramArrayOfInt);
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/externalInterface/Plugin.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */