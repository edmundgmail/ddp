/*    */ package net.sf.RecordEditor.editFileLayout;
/*    */ 
/*    */ import javax.swing.SwingUtilities;
/*    */ import net.sf.RecordEditor.edit.EditFileLayout;
/*    */ import net.sf.RecordEditor.utils.edit.ParseArgs;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Edit
/*    */ {
/*    */   public static void main(String[] pgmArgs)
/*    */   {
/* 14 */     SwingUtilities.invokeLater(new Runnable()
/*    */     {
/*    */       public void run() {
/* 17 */         ParseArgs args = new ParseArgs(this.val$pgmArgs);
/*    */         
/* 19 */         new EditFileLayout(args.getDfltFile(), args.getInitialRow());
/*    */       }
/*    */     });
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/editFileLayout/Edit.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */