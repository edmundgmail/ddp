/*    */ package net.sf.RecordEditor.edit;
/*    */ 
/*    */ import net.sf.RecordEditor.utils.params.CheckUserData;
/*    */ 
/*    */ public class XCreateData
/*    */ {
/*    */   public static void main(String[] args) {
/*  8 */     int extractUserParms = 1;
/*  9 */     String dbDir = null;
/* 10 */     if ((args != null) && (args.length > 0)) {
/* 11 */       String typeVar = args[0].toLowerCase();
/* 12 */       if (typeVar.startsWith("y")) {
/* 13 */         extractUserParms = 2;
/* 14 */       } else if (typeVar.startsWith("u")) {
/* 15 */         extractUserParms = 3;
/*    */       }
/*    */       
/* 18 */       if (args.length > 1) {
/* 19 */         StringBuilder b = new StringBuilder();
/* 20 */         String sep = "";
/* 21 */         for (int i = 1; i < args.length; i++) {
/* 22 */           b.append(sep).append(args[i]);
/* 23 */           sep = " ";
/*    */         }
/* 25 */         dbDir = b.toString();
/*    */       }
/*    */     }
/* 28 */     CheckUserData.checkAndCreate(extractUserParms, false, dbDir);
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/XCreateData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */