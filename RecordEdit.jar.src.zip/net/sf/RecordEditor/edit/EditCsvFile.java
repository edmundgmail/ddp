/*     */ package net.sf.RecordEditor.edit;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ComponentAdapter;
/*     */ import java.awt.event.ComponentEvent;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.SwingUtilities;
/*     */ import net.sf.JRecord.CsvParser.ParserManager;
/*     */ import net.sf.JRecord.IO.AbstractLineIOProvider;
/*     */ import net.sf.RecordEditor.diff.CompareSingleLayout;
/*     */ import net.sf.RecordEditor.diff.CompareTwoLayouts;
/*     */ import net.sf.RecordEditor.edit.display.Action.CsvUpdateLayoutAction;
/*     */ import net.sf.RecordEditor.edit.display.Action.LoadFileLayoutFromXml;
/*     */ import net.sf.RecordEditor.edit.display.Action.NewCsvAction;
/*     */ import net.sf.RecordEditor.edit.display.Action.SaveFieldSequenceAction;
/*     */ import net.sf.RecordEditor.edit.display.Action.SaveFileLayout2Xml;
/*     */ import net.sf.RecordEditor.edit.display.Action.VisibilityAction;
/*     */ import net.sf.RecordEditor.edit.display.util.ErrorScreen;
/*     */ import net.sf.RecordEditor.edit.open.OpenCsvFilePnl;
/*     */ import net.sf.RecordEditor.edit.open.OpenFile;
/*     */ import net.sf.RecordEditor.edit.util.NewCsvFile;
/*     */ import net.sf.RecordEditor.po.def.PoLayoutMgr;
/*     */ import net.sf.RecordEditor.re.display.DisplayBuilderFactory;
/*     */ import net.sf.RecordEditor.re.openFile.LayoutSelectionCsvCreator;
/*     */ import net.sf.RecordEditor.re.openFile.LayoutSelectionPoTipCreator;
/*     */ import net.sf.RecordEditor.re.util.ReIOProvider;
/*     */ import net.sf.RecordEditor.tip.def.TipLayoutMgr;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.edit.ParseArgs;
/*     */ import net.sf.RecordEditor.utils.lang.ReAbstractAction;
/*     */ import net.sf.RecordEditor.utils.params.BoolOpt;
/*     */ import net.sf.RecordEditor.utils.params.CheckUserData;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions.InternalBoolOption;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMainFrame.ShowURI;
/*     */ import net.sf.RecordEditor.utils.swingx.TipsManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EditCsvFile
/*     */   extends EditRec
/*     */ {
/*     */   private static final String RECENT_CSV_FILES = "CsvFiles.txt";
/*     */   private final OpenFile open;
/*     */   private final String recentFileName;
/*  64 */   private static boolean showTips = true;
/*     */   
/*     */ 
/*  67 */   private ComponentAdapter resizeListner = new ComponentAdapter()
/*     */   {
/*     */ 
/*     */ 
/*     */     public void componentResized(ComponentEvent e)
/*     */     {
/*     */ 
/*     */ 
/*  75 */       EditCsvFile.this.setLogFrameSize();
/*  76 */       EditCsvFile.this.open.setSize(EditCsvFile.this.getLogWidth(), EditCsvFile.this.getOpenHeight());
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EditCsvFile(String pInFile, int pInitialRow)
/*     */   {
/*  89 */     this(pInFile, pInitialRow, ReIOProvider.getInstance());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EditCsvFile(String pInFile, int pInitialRow, AbstractLineIOProvider pIoProvider)
/*     */   {
/* 104 */     super(false, "reCsv Editor", "csv", new NewCsvAction(), true);
/*     */     
/* 106 */     JMenu compareMenu = new JMenu("Compare");
/* 107 */     JMenu newMenu = new JMenu("New Files");
/* 108 */     newMenu.add(new ReAbstractAction("New Csv file") {
/*     */       public void actionPerformed(ActionEvent e) {
/* 110 */         new NewCsvFile();
/*     */       }
/*     */       
/* 113 */     });
/* 114 */     newMenu.add(new ReAbstractAction("New GetText-PO file") {
/*     */       public void actionPerformed(ActionEvent e) {
/* 116 */         DisplayBuilderFactory.startEditorNewFile(PoLayoutMgr.getPoLayout());
/*     */       }
/* 118 */     });
/* 119 */     newMenu.add(new ReAbstractAction("New SwingX-Tip file") {
/*     */       public void actionPerformed(ActionEvent e) {
/* 121 */         DisplayBuilderFactory.startEditorNewFile(TipLayoutMgr.getTipLayout());
/*     */       }
/*     */       
/* 124 */     });
/* 125 */     this.recentFileName = (Parameters.getApplicationDirectory() + "CsvFiles.txt");
/* 126 */     compareMenu.add(new ReAbstractAction("Csv Compare") {
/*     */       public void actionPerformed(ActionEvent e) {
/* 128 */         LayoutSelectionCsvCreator csvl = new LayoutSelectionCsvCreator();
/* 129 */         new CompareTwoLayouts(csvl.create(), csvl.create(), "CsvFiles.txt", false);
/*     */       }
/* 131 */     });
/* 132 */     compareMenu.add(new ReAbstractAction("Get-Text PO Compare") {
/*     */       public void actionPerformed(ActionEvent e) {
/* 134 */         LayoutSelectionPoTipCreator newPoCreator = LayoutSelectionPoTipCreator.newPoCreator();
/* 135 */         new CompareSingleLayout("GetText-PO Compare Wizard -", newPoCreator.create(), "CsvFiles.txt");
/*     */       }
/* 137 */     });
/* 138 */     compareMenu.add(new ReAbstractAction("Swingx-Tip Compare") {
/*     */       public void actionPerformed(ActionEvent e) {
/* 140 */         LayoutSelectionPoTipCreator newTipCreator = LayoutSelectionPoTipCreator.newTipCreator();
/* 141 */         new CompareSingleLayout("SwingX-Tip Compare Wizard -", newTipCreator.create(), "CsvFiles.txt");
/*     */ 
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 147 */     });
/* 148 */     OpenCsvFilePnl csvPnl = new OpenCsvFilePnl(pInFile, this.recentFileName, pIoProvider, true);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 156 */     this.open = new OpenFile(csvPnl, super.getLogWidth(), getOpenHeight());
/*     */     
/*     */ 
/* 159 */     csvPnl.setParentFrame(this.open);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 172 */     super.setOpenFileWindow(this.open, null, compareMenu, newMenu, false);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 181 */     super.getEditMenu().addSeparator();
/* 182 */     super.getEditMenu().add(addAction(new VisibilityAction()));
/* 183 */     super.getEditMenu().add(addAction(new SaveFieldSequenceAction()));
/* 184 */     super.getEditMenu().addSeparator();
/* 185 */     super.getEditMenu().add(addAction(new CsvUpdateLayoutAction()));
/* 186 */     super.getEditMenu().add(addAction(new SaveFileLayout2Xml()));
/* 187 */     super.getEditMenu().add(addAction(new LoadFileLayoutFromXml()));
/*     */     
/* 189 */     super.addComponentListener(this.resizeListner);
/*     */     
/*     */ 
/* 192 */     if ((Common.OPTIONS.showRecordEditorTips.isSelected()) && (TipsManager.tipsModulePresent()) && (showTips))
/*     */     {
/* 194 */       TipsManager.startTips(this, Parameters.getSytemJarFileDirectory() + "/ReCsvEditor_TipOfTheDay.properties", "showRecordEditorTips");
/*     */     }
/*     */     
/*     */ 
/* 198 */     EditCommon.doStandardInit();
/*     */   }
/*     */   
/*     */   private int getOpenHeight() {
/* 202 */     int height = -1;
/* 203 */     int logHeight = getLogHeight();
/* 204 */     if (logHeight > 20) {
/* 205 */       height = getDesktopHeight() - logHeight;
/*     */     }
/* 207 */     return height;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected void addWebsitesToHelpMenu(JMenu helpMenu)
/*     */   {
/*     */     try
/*     */     {
/* 216 */       helpMenu.add(new ReMainFrame.ShowURI("ReCsvEditor Documentations", Common.formatHelpURL("reCsvEdFR.htm").toURI()));
/*     */       
/*     */ 
/*     */ 
/* 220 */       helpMenu.add(new ReMainFrame.ShowURI("HowTo Documentations", Common.formatHelpURL("howTo.htm").toURI()));
/*     */       
/*     */ 
/*     */ 
/* 224 */       helpMenu.addSeparator();
/* 225 */       helpMenu.add(new ReMainFrame.ShowURI("ReCsvEditor Web Page", new URI("http://recsveditor.sourceforge.net/")));
/* 226 */       helpMenu.add(new ReMainFrame.ShowURI("ReCsvEditor Forum", new URI("https://sourceforge.net/p/recsveditor/discussion/")));
/*     */     } catch (URISyntaxException e1) {
/* 228 */       e1.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void showAbout()
/*     */   {
/* 238 */     String currentVersion = Common.currentVersion();
/* 239 */     showAbout("The <b>reCsvEditor</b> (" + currentVersion + ")  is an editor for CSV " + "data files. It is built on top of the RecordEditor.<br><br><pre>" + "<br> <b>Version: </b> " + currentVersion + "<br>" + "<br> <b>Authors:</b><br> " + "\t<b>Bruce Martin</b>: Main author<br/><br/>" + " <b>Websites:</b><br><br> " + "\t<b>reCsvEditor:</b> http://recsveditor.sourceforge.net<br>" + "\t<b>RecordEditor:</b> http://record-editor.sourceforge.net<br>" + "</pre><br>");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void main(String[] pgmArgs)
/*     */   {
/*     */     try
/*     */     {
/* 261 */       Common.OPTIONS.addTextDisplay.set(true);
/* 262 */       Common.OPTIONS.loadPoScreens.set(true);
/* 263 */       Common.setDBstatus(false);
/* 264 */       ParserManager.setUseNewCsvParsers(true);
/*     */       
/* 266 */       CheckUserData.setUseCsvLine();
/* 267 */       CheckUserData.checkAndCreate(3, false, null);
/*     */     } catch (Throwable e) {
/* 269 */       e.printStackTrace();
/*     */     }
/*     */     
/* 272 */     SwingUtilities.invokeLater(new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/*     */         try
/*     */         {
/* 278 */           ParseArgs args = new ParseArgs(this.val$pgmArgs);
/* 279 */           Common.OPTIONS.overWriteOutputFile.set(args.isOverWiteOutputFile());
/*     */           
/*     */ 
/* 282 */           String fileName = args.getDfltFile();
/* 283 */           EditCsvFile.access$402((fileName == null) || ("".equals(fileName)));
/*     */           
/* 285 */           new EditCsvFile(fileName, args.getInitialRow(), ReIOProvider.getInstance());
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 291 */           CheckUserData.checkJavaVersion("ReCsvEditor");
/*     */ 
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/*     */ 
/* 297 */           new ErrorScreen("ReCsvEditor", e);
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/EditCsvFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */