/*     */ package net.sf.RecordEditor.edit;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.SwingUtilities;
/*     */ import net.sf.JRecord.CsvParser.ParserManager;
/*     */ import net.sf.JRecord.External.CopybookLoaderFactory;
/*     */ import net.sf.JRecord.IO.AbstractLineIOProvider;
/*     */ import net.sf.RecordEditor.copy.CopyDBLayout;
/*     */ import net.sf.RecordEditor.diff.CompareDBLayout;
/*     */ import net.sf.RecordEditor.edit.display.Action.ChangeLayoutAction;
/*     */ import net.sf.RecordEditor.edit.display.Action.CsvOpenAction;
/*     */ import net.sf.RecordEditor.edit.display.Action.CsvUpdateLayoutAction;
/*     */ import net.sf.RecordEditor.edit.display.Action.NewCsvAction;
/*     */ import net.sf.RecordEditor.edit.display.Action.NewFileAction;
/*     */ import net.sf.RecordEditor.edit.display.Action.SaveFieldSequenceAction;
/*     */ import net.sf.RecordEditor.edit.display.Action.VisibilityAction;
/*     */ import net.sf.RecordEditor.edit.display.util.ErrorScreen;
/*     */ import net.sf.RecordEditor.edit.open.OpenFile;
/*     */ import net.sf.RecordEditor.layoutEd.LayoutMenu;
/*     */ import net.sf.RecordEditor.layoutEd.schema.ImportExport.SchemaBackup;
/*     */ import net.sf.RecordEditor.layoutWizard.Wizard;
/*     */ import net.sf.RecordEditor.re.openFile.AbstractLayoutSelection;
/*     */ import net.sf.RecordEditor.re.openFile.IOpenFileExtended;
/*     */ import net.sf.RecordEditor.re.openFile.LayoutSelectionDB;
/*     */ import net.sf.RecordEditor.re.openFile.LayoutSelectionDBCreator;
/*     */ import net.sf.RecordEditor.re.openFile.OpenFileInterface;
/*     */ import net.sf.RecordEditor.re.util.CopybookLoaderFactoryDB;
/*     */ import net.sf.RecordEditor.re.util.ReIOProvider;
/*     */ import net.sf.RecordEditor.re.util.UpgradeDB;
/*     */ import net.sf.RecordEditor.utils.CopyBookDbReader;
/*     */ import net.sf.RecordEditor.utils.CopyBookInterface;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.edit.ParseArgs;
/*     */ import net.sf.RecordEditor.utils.jdbc.AbsDB;
/*     */ import net.sf.RecordEditor.utils.lang.ReAbstractAction;
/*     */ import net.sf.RecordEditor.utils.params.BoolOpt;
/*     */ import net.sf.RecordEditor.utils.params.CheckUserData;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions.FileNameOpt;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions.InternalBoolOption;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.swingx.TipsManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FullEditor
/*     */   extends EditRec
/*     */ {
/*  66 */   private LayoutMenu layoutMenu = new LayoutMenu(null);
/*     */   
/*     */ 
/*  69 */   private static FullEditor instance = null;
/*  70 */   private static boolean showTips = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FullEditor(String pInFile, int pInitialRow, CopyBookInterface pInterfaceToCopyBooks)
/*     */   {
/*  82 */     this(pInFile, pInitialRow, ReIOProvider.getInstance(), pInterfaceToCopyBooks);
/*  83 */     UpgradeDB.checkForUpdate(Common.getConnectionIndex());
/*  84 */     SchemaBackup.backupAllSchemas();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FullEditor(String pInFile, int pInitialRow, AbstractLineIOProvider pIoProvider, CopyBookInterface pInterfaceToCopyBooks)
/*     */   {
/* 101 */     super("Record Editor");
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 110 */     initMenusToolBars(true, new CsvOpenAction(Common.OPTIONS.DEFAULT_FILE_DIRECTORY.get(), pIoProvider), new NewFileAction(new LayoutSelectionDBCreator(pInterfaceToCopyBooks)), new NewCsvAction("New Basic Csv file"), this.layoutMenu.getStartSchemaAction());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 118 */     setupOpenWindow(pInFile, pInitialRow, pIoProvider, pInterfaceToCopyBooks);
/*     */     
/*     */ 
/*     */ 
/* 122 */     if ((Common.OPTIONS.showRecordEditorTips.isSelected()) && (TipsManager.tipsModulePresent()) && (showTips))
/*     */     {
/* 124 */       TipsManager.startTips(this, Parameters.getSytemJarFileDirectory() + "/RecordEditor_TipOfTheDay.properties", "showRecordEditorTips");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setupOpenWindow(String pInFile, int pInitialRow, AbstractLineIOProvider pIoProvider, final CopyBookInterface pInterfaceToCopyBooks)
/*     */   {
/* 143 */     JButton createLayoutWizard = new JButton("XX");
/*     */     
/* 145 */     CopybookLoaderFactory.setInstance(new CopybookLoaderFactoryDB());
/*     */     
/* 147 */     OpenFile open = new OpenFile(pInFile, pInitialRow, pIoProvider, createLayoutWizard, null, new LayoutSelectionDB(pInterfaceToCopyBooks, null, true));
/*     */     
/*     */ 
/* 150 */     ChangeLayoutAction changeLayout = new ChangeLayoutAction(new LayoutSelectionDBCreator(pInterfaceToCopyBooks));
/*     */     
/*     */ 
/*     */ 
/* 154 */     createLayoutWizard.setAction(Wizard.getAction(open.getOpenFilePanel()));
/*     */     
/* 156 */     this.layoutMenu.setDatabaseDetails(open.getOpenFilePanel());
/*     */     
/* 158 */     JMenu editMenu = super.getEditMenu();
/* 159 */     editMenu.addSeparator();
/* 160 */     editMenu.add(addAction(new VisibilityAction()));
/* 161 */     editMenu.add(addAction(new SaveFieldSequenceAction()));
/* 162 */     editMenu.addSeparator();
/* 163 */     editMenu.add(addAction(changeLayout));
/* 164 */     editMenu.add(addAction(new CsvUpdateLayoutAction()));
/*     */     
/* 166 */     setOpenFileWindow(open, new ReAbstractAction("File Copy Menu")
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 174 */       new ReAbstractAction
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         public void actionPerformed(ActionEvent e) {
/* 174 */           CopyDBLayout.newMenu(pInterfaceToCopyBooks); } }, new ReAbstractAction("Compare Menu")
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         public void actionPerformed(ActionEvent e) {
/* 184 */           CompareDBLayout.newMenu(pInterfaceToCopyBooks); } }, null, true);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 190 */     AbsDB.setSystemLog(super.getLog());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addProgramSpecificMenus(JMenuBar menubar)
/*     */   {
/* 201 */     menubar.add(this.layoutMenu);
/* 202 */     super.addProgramSpecificMenus(menubar);
/*     */   }
/*     */   
/*     */ 
/*     */   public static void close()
/*     */   {
/*     */     try
/*     */     {
/* 210 */       ReFrame.closeAllFrames();
/* 211 */       Common.closeConnection();
/*     */     }
/*     */     catch (Exception e) {}
/*     */   }
/*     */   
/*     */   public static void startEditor(String fileName, String schemaName, int initialRow)
/*     */   {
/* 218 */     startEditor(new ParseArgs[] { new ParseArgs(fileName, schemaName, initialRow) });
/*     */   }
/*     */   
/*     */   public static void startEditor(ParseArgs... args)
/*     */   {
/*     */     try {
/* 224 */       Common.OPTIONS.fileWizardAvailable.set(true);
/* 225 */       Common.OPTIONS.standardEditor.set(true);
/* 226 */       Common.OPTIONS.addTextDisplay.set(true);
/* 227 */       Common.OPTIONS.loadPoScreens.set(true);
/* 228 */       ParserManager.setUseNewCsvParsers(true);
/*     */       
/* 230 */       CheckUserData.checkAndCreate();
/* 231 */       CheckUserData.setUseCsvLine();
/* 232 */       if ((args != null) && (args.length > 0)) {
/* 233 */         Common.OPTIONS.overWriteOutputFile.set(args[0].isOverWiteOutputFile());
/* 234 */         Parameters.loadParamProperties(args[0].getParamFilename());
/*     */       }
/*     */     } catch (Throwable e1) {
/* 237 */       e1.printStackTrace();
/*     */     }
/*     */     
/*     */ 
/* 241 */     if ((args != null) && (args.length > 0)) {
/* 242 */       SwingUtilities.invokeLater(new Runnable() {
/*     */         public void run() {
/* 244 */           boolean free = Common.isSetDoFree(false);
/*     */           try
/*     */           {
/* 247 */             String fileName = this.val$args[0].getDfltFile();
/* 248 */             FullEditor.access$002((fileName == null) || ("".equals(fileName)));
/* 249 */             if (!"".equals(this.val$args[0].getSchemaName())) {
/* 250 */               fileName = "";
/*     */             }
/* 252 */             FullEditor.access$102(new FullEditor(fileName, this.val$args[0].getInitialRow(), CopyBookDbReader.getInstance()));
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 263 */             if (FullEditor.instance.getOpenFileWindow() != null) {
/* 264 */               OpenFileInterface openFilePanel = FullEditor.instance.getOpenFileWindow().getOpenFilePanel();
/* 265 */               IOpenFileExtended openFileExtended = null;
/* 266 */               String[] dbs = Common.getSourceId();
/*     */               
/* 268 */               if ((openFilePanel instanceof IOpenFileExtended)) {
/* 269 */                 openFileExtended = (IOpenFileExtended)openFilePanel;
/*     */               }
/* 271 */               for (int i = 0; i < this.val$args.length; i++) {
/* 272 */                 String db = this.val$args[i].getDb();
/* 273 */                 if ((openFileExtended != null) && (!"".equals(db))) {
/* 274 */                   for (int j = 0; j < dbs.length; j++) {
/* 275 */                     if (db.equalsIgnoreCase(dbs[j])) {
/* 276 */                       openFileExtended.getLayoutSelection().setDatabaseIdx(j);
/*     */                     }
/*     */                   }
/*     */                 }
/* 280 */                 if (!"".equals(this.val$args[i].getSchemaName())) {
/* 281 */                   openFilePanel.setRecordLayout(-1, this.val$args[i].getSchemaName(), this.val$args[i].getDfltFile());
/*     */                 }
/*     */               }
/*     */             }
/*     */           } catch (Exception e) {
/* 286 */             new ErrorScreen("RecordEditor", e);
/*     */           } finally {
/* 288 */             CheckUserData.checkJavaVersion("RecordEditor");
/* 289 */             Common.setDoFree(free, Common.getConnectionIndex());
/*     */           }
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void main(String[] pgmArgs)
/*     */   {
/* 301 */     startEditor(new ParseArgs[] { new ParseArgs(pgmArgs) });
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/FullEditor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */