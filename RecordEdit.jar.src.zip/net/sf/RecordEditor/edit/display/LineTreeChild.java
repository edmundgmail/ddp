/*     */ package net.sf.RecordEditor.edit.display;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTree;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.event.TableModelEvent;
/*     */ import javax.swing.tree.TreePath;
/*     */ import net.sf.JRecord.Details.AbstractChildDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.AbstractTreeDetails;
/*     */ import net.sf.RecordEditor.edit.display.util.LinePosition;
/*     */ import net.sf.RecordEditor.edit.util.ReMessages;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*     */ import net.sf.RecordEditor.re.display.DisplayBuilderFactory;
/*     */ import net.sf.RecordEditor.re.display.IDisplayBuilder;
/*     */ import net.sf.RecordEditor.re.file.AbstractLineNode;
/*     */ import net.sf.RecordEditor.re.file.FilePosition;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.re.tree.LineNode;
/*     */ import net.sf.RecordEditor.re.tree.LineNodeChild;
/*     */ import net.sf.RecordEditor.re.tree.LineTreeTabelModel;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.fileStorage.DataStoreStd.DataStoreStdBinary;
/*     */ import net.sf.RecordEditor.utils.fileStorage.IDataStore;
/*     */ import net.sf.RecordEditor.utils.lang.ReAbstractAction;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReAction;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMsg;
/*     */ import net.sf.RecordEditor.utils.swing.LayoutCombo;
/*     */ import net.sf.RecordEditor.utils.swing.treeTable.JTreeTable;
/*     */ 
/*     */ public class LineTreeChild extends BaseLineTree<AbstractLineNode>
/*     */ {
/*     */   protected LineTreeChild(FileView viewOfFile, AbstractLineNode rootNode, boolean mainView, int columnsToSkip)
/*     */   {
/*  40 */     super(viewOfFile, mainView, true, columnsToSkip, 3);
/*  41 */     super.setDisplayType(5);
/*     */     
/*  43 */     this.root = rootNode;
/*     */     
/*     */ 
/*  46 */     AbstractAction[] extraActions = { null, new ReAction(30, this), null, new ReAbstractAction("Redisplay Tree")
/*     */     {
/*     */ 
/*     */       public void actionPerformed(ActionEvent e)
/*     */       {
/*     */ 
/*  52 */         AbstractLineNode root = (AbstractLineNode)LineTreeChild.this.model.getRoot();
/*  53 */         LineTreeChild.this.model.fireTreeStructureChanged(root, root.getPath(), null, null);
/*     */       }
/*     */       
/*     */ 
/*  57 */     } };
/*  58 */     init_100_setupScreenFields(extraActions);
/*     */     
/*  60 */     init_200_LayoutScreen();
/*     */     
/*  62 */     if (!viewOfFile.isView()) {
/*  63 */       viewOfFile.setTreeTableNotify(this.model);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setScreenSize(boolean mainframe)
/*     */   {
/*  71 */     DisplayFrame parentFrame = getParentFrame();
/*  72 */     parentFrame.bldScreen();
/*     */     
/*  74 */     parentFrame.setBounds(1, 1, this.screenSize.width - 1, this.screenSize.height - 1);
/*     */     
/*     */ 
/*     */ 
/*  78 */     parentFrame.setToMaximum(true);
/*  79 */     parentFrame.setVisible(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isOkToUseSelectedRows()
/*     */   {
/*  86 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public List<AbstractLine> getSelectedLines()
/*     */   {
/*  96 */     int[] sel = this.tblDetails.getSelectedRows();
/*  97 */     ArrayList<AbstractLine> list = new ArrayList(sel.length);
/*     */     
/*     */ 
/* 100 */     for (int i = 0; i < sel.length; i++) {
/* 101 */       AbstractLineNode node = getNodeForRow(sel[i]);
/* 102 */       if ((node != null) && (node.getLine() != null)) {
/* 103 */         list.add(node.getLine());
/*     */       }
/*     */     }
/*     */     
/* 107 */     return list;
/*     */   }
/*     */   
/*     */ 
/*     */   public int getCurrRow()
/*     */   {
/* 113 */     return 0;
/*     */   }
/*     */   
/*     */   protected int getInsertAfterPosition()
/*     */   {
/* 118 */     return -1;
/*     */   }
/*     */   
/*     */   protected LinePosition getInsertAfterLine(boolean prev)
/*     */   {
/* 123 */     AbstractLine ret = null;
/* 124 */     int row = getTreeTblRow();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 129 */     if (row >= 0) {
/* 130 */       AbstractLineNode node = getNodeForRow(row);
/* 131 */       if ((prev) && (row > 0)) {
/* 132 */         AbstractLineNode prevNode = getNodeForRow(row - 1);
/* 133 */         if ((prevNode.getLine() != null) && (prevNode.getParent() == node.getParent())) {
/* 134 */           return new LinePosition(prevNode.getLine(), false);
/*     */         }
/*     */       }
/* 137 */       if (node != null) {
/* 138 */         ret = node.getLine();
/*     */         
/*     */ 
/* 141 */         while ((ret == null) && (node.getParent() != null) && ((node.getParent() instanceof AbstractLineNode))) {
/* 142 */           node = (AbstractLineNode)node.getParent();
/* 143 */           ret = node.getLine();
/* 144 */           prev = false;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 149 */     return new LinePosition(ret, prev);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractLine getTreeLine()
/*     */   {
/* 158 */     AbstractLine line = getInsertAfterLine(false).line;
/* 159 */     if ((line == null) && (this.view.getRowCount() > 0)) {
/* 160 */       line = this.view.getLine(0);
/*     */     }
/* 162 */     return line;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCurrRow(int newRow, int layoutId, int fieldNum) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCurrRow(FilePosition position)
/*     */   {
/* 178 */     if (position.currentLine != null)
/*     */     {
/* 180 */       setLayoutForPosition(position);
/*     */       
/* 182 */       AbstractLineNode node = createNodes(position.currentLine);
/*     */       
/* 184 */       int row = expandNode(node);
/* 185 */       this.fileView.fireTableDataChanged();
/*     */       
/* 187 */       this.tblDetails.changeSelection(row, 1, false, false);
/*     */       
/*     */ 
/* 190 */       getChildScreen().setLine(node.getLine());
/*     */     }
/*     */   }
/*     */   
/*     */   private AbstractLineNode createNodes(AbstractLine line)
/*     */   {
/* 196 */     AbstractLineNode node = this.view.getTreeNode(line);
/* 197 */     if (node == null) {
/* 198 */       AbstractLine p = line.getTreeDetails().getParentLine();
/* 199 */       if (p != null) {
/* 200 */         AbstractChildDetails childDtls = line.getTreeDetails().getChildDefinitionInParent();
/* 201 */         AbstractLineNode parentNode = createNodes(p);
/*     */         
/* 203 */         if ((childDtls.isRepeated()) && ((parentNode instanceof LineNodeChild)))
/*     */         {
/* 205 */           int idx = childDtls.getRecordIndex();
/* 206 */           AbstractLineNode childNode = ((LineNodeChild)parentNode).getChildbyCode(childDtls.getChildIndex());
/*     */           
/*     */ 
/* 209 */           if (childNode.getChildCount() > idx) {
/* 210 */             childNode.getChildAt(idx);
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 215 */         node = this.view.getTreeNode(line);
/*     */       }
/*     */     }
/*     */     
/* 219 */     return node;
/*     */   }
/*     */   
/*     */   private int expandNode(AbstractLineNode node) {
/* 223 */     if (node != null) {
/* 224 */       expandNode((AbstractLineNode)node.getParent());
/* 225 */       TreePath t = new TreePath(node.getPath());
/* 226 */       this.treeTable.getTree().expandPath(t);
/* 227 */       return this.treeTable.getTree().getRowForPath(t);
/*     */     }
/* 229 */     return -1;
/*     */   }
/*     */   
/*     */   public void tableChanged(TableModelEvent event)
/*     */   {
/* 234 */     checkForResize(event);
/*     */   }
/*     */   
/*     */ 
/*     */   public void deleteLines()
/*     */   {
/* 240 */     int[] selRows = this.treeTable.getSelectedRows();
/*     */     
/* 242 */     if ((selRows != null) && (selRows.length > 0))
/*     */     {
/*     */ 
/* 245 */       AbstractLineNode[] nodes = new AbstractLineNode[selRows.length];
/* 246 */       for (int i = 0; i < selRows.length; i++) {
/* 247 */         TreePath treePath = this.treeTable.getPathForRow(selRows[i]);
/* 248 */         nodes[i] = ((AbstractLineNode)treePath.getLastPathComponent());
/*     */       }
/*     */       
/* 251 */       for (i = 0; i < selRows.length; i++) {
/* 252 */         AbstractLineNode parent = (AbstractLineNode)nodes[i].getParent();
/* 253 */         if (nodes[i].getLine() != null)
/*     */         {
/*     */ 
/* 256 */           this.fileView.deleteLine(nodes[i].getLine());
/* 257 */           nodes[i].removeFromParent();
/* 258 */         } else if (nodes[i].getChildCount() > 0) {
/* 259 */           AbstractLineNode firstChild = (AbstractLineNode)nodes[i].getChildAt(0);
/*     */           
/* 261 */           AbstractChildDetails childDef = firstChild.getLine().getTreeDetails().getChildDefinitionInParent();
/* 262 */           if ((childDef != null) && (!childDef.isRequired()) && (parent.getLine() != null)) {
/* 263 */             AbstractLine parentLine = parent.getLine();
/* 264 */             if (parentLine.getTreeDetails().removeChildren(childDef)) {
/* 265 */               this.model.fireTreeNodesRemoved(nodes[i]);
/* 266 */               nodes[i].removeFromParent();
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void executeAction(int action)
/*     */   {
/* 284 */     switch (action) {
/*     */     case 31: 
/* 286 */       getFileView().repeatLine(getNodeForRow(this.popupRow).getLine());
/* 287 */       break;
/*     */     case 24: 
/* 289 */       execute_100_Copy();
/* 290 */       break;
/*     */     case 25: 
/* 292 */       execute_100_Copy();
/* 293 */       deleteLines();
/* 294 */       break;
/*     */     case 26: 
/*     */     case 27: 
/*     */     case 73: 
/*     */     case 74: 
/* 299 */       executeTreeAction(action);
/* 300 */       break;
/* 301 */     case 14:  createView(); break;
/* 302 */     case 15:  createRecordView(); break;
/* 303 */     case 16:  createColumnView(); break;
/*     */     default: 
/* 305 */       super.executeAction(action);
/*     */     }
/*     */   }
/*     */   
/*     */   private void execute_100_Copy()
/*     */   {
/* 311 */     new Thread(new Runnable() {
/*     */       public void run() {
/* 313 */         int[] selRows = LineTreeChild.this.treeTable.getSelectedRows();
/* 314 */         if ((selRows != null) && (selRows.length > 0))
/*     */         {
/*     */ 
/*     */ 
/* 318 */           IDataStore<AbstractLine> lines = LineTreeChild.this.view.newDataStore(selRows.length > 2000, selRows.length, 1L, null, null);
/*     */           
/*     */ 
/*     */ 
/* 322 */           for (int i = 0; i < selRows.length; i++) {
/* 323 */             TreePath treePath = LineTreeChild.this.treeTable.getPathForRow(selRows[i]);
/* 324 */             AbstractLine l = ((AbstractLineNode)treePath.getLastPathComponent()).getLine();
/* 325 */             if (l != null) {
/* 326 */               lines.add(l.getNewDataLine());
/*     */             }
/*     */           }
/*     */           
/* 330 */           FileView.setCopyRecords(lines);
/*     */         }
/*     */       }
/*     */     }).start();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void createView()
/*     */   {
/* 341 */     List<AbstractLine> selLines = getSelectedLines();
/*     */     
/* 343 */     if ((selLines != null) && (selLines.size() > 0)) {
/* 344 */       DisplayBuilderFactory.newLineList(getParentFrame(), this.fileView.getLayout(), this.fileView.getView(selLines), this.fileView.getBaseFile());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void createColumnView()
/*     */   {
/* 354 */     int selectedRowCount = getSelectedRowCount();
/* 355 */     if (selectedRowCount > 50000) {
/* 356 */       Common.logMsgRaw(ReMessages.TO_MANY_ROWS.get(new Object[] { Integer.valueOf(selectedRowCount), Integer.valueOf(50000) }), null);
/*     */     } else {
/* 358 */       List<AbstractLine> selLines = getSelectedLines();
/*     */       
/* 360 */       if ((selLines != null) && (selLines.size() > 0)) {
/* 361 */         FileView f = new FileView(new DataStoreStd.DataStoreStdBinary(this.layout, selLines), this.fileMaster, null);
/*     */         
/*     */ 
/*     */ 
/* 365 */         DisplayBldr.newDisplay(7, "", getParentFrame(), this.fileView.getLayout(), f, 0);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void createRecordView()
/*     */   {
/* 376 */     List<AbstractLine> selLines = getSelectedLines();
/*     */     
/* 378 */     if ((selLines != null) && (selLines.size() > 0)) {
/* 379 */       newLineDisp(this.fileView.getView(selLines), 0);
/*     */     }
/*     */   }
/*     */   
/*     */   public void expandTree(String option) {
/* 384 */     getLayoutCombo().setSelectedItem(option);
/*     */     
/* 386 */     doFullExpansion(this.root);
/*     */     
/* 388 */     SwingUtilities.invokeLater(new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/* 392 */         Common.calcColumnWidths(LineTreeChild.this.tblDetails, 1);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isActionAvailable(int action)
/*     */   {
/* 406 */     return (action == 31) || ((action != 55) && (super.isActionAvailable(action)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractFileDisplay createChildScreen(int pos)
/*     */   {
/* 418 */     AbstractLine l = getInsertAfterLine(false).line;
/* 419 */     if ((l == null) && (this.fileView.getRowCount() > 0)) {
/* 420 */       l = this.fileView.getLine(0);
/*     */     }
/* 422 */     LineFrameTree f = new LineFrameTree(this.fileView, l, false);
/*     */     
/* 424 */     setChildScreen(f);
/* 425 */     return f;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected BaseDisplay getNewDisplay(FileView view)
/*     */   {
/* 435 */     LineNode ln = new LineNode("root", view, -1);
/* 436 */     ln.setFirstLeafLine(0);
/* 437 */     ln.setLastLeafLine(view.getRowCount());
/* 438 */     LineTreeChild tc = new LineTreeChild(view, ln, false, this.cols2skip);
/*     */     
/* 440 */     return tc;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/LineTreeChild.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */