/*     */ package net.sf.RecordEditor.edit.display;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.util.List;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.ListSelectionModel;
/*     */ import javax.swing.event.TableModelEvent;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.AbstractTreeDetails;
/*     */ import net.sf.RecordEditor.edit.display.models.BaseLineModel;
/*     */ import net.sf.RecordEditor.edit.display.models.LineModel;
/*     */ import net.sf.RecordEditor.edit.display.util.LinePosition;
/*     */ import net.sf.RecordEditor.re.file.FieldMapping;
/*     */ import net.sf.RecordEditor.re.file.FilePosition;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.ExpandLineTree;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.swing.LayoutCombo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LineFrameTree
/*     */   extends BaseLineFrame
/*     */   implements ILineDisplay
/*     */ {
/*     */   private static final int IDX_START = 0;
/*     */   private static final int IDX_PREV = 1;
/*     */   private static final int IDX_PARENT = 2;
/*     */   private static final int IDX_CHILD = 3;
/*     */   private static final int IDX_NEXT = 4;
/*     */   private static final int IDX_LAST = 5;
/*  66 */   private ImageIcon[] icons = Common.getArrowTreeIcons();
/*     */   
/*  68 */   private ActionListener listner = new ActionListener()
/*     */   {
/*     */ 
/*     */     public void actionPerformed(ActionEvent event)
/*     */     {
/*  73 */       LineFrameTree.this.stopCellEditing();
/*     */       
/*  75 */       if (event.getSource() == LineFrameTree.this.btnPanel.buttons[0]) {
/*  76 */         LineFrameTree.this.setCurrentLine(0);
/*  77 */       } else if (event.getSource() == LineFrameTree.this.btnPanel.buttons[1]) {
/*  78 */         LineFrameTree.this.changeRow(-1);
/*  79 */       } else if (event.getSource() == LineFrameTree.this.btnPanel.buttons[2]) {
/*  80 */         AbstractLine l = LineFrameTree.this.record.getCurrentLine().getTreeDetails().getParentLine();
/*  81 */         if (l != null) {
/*  82 */           LineFrameTree.this.setLine(l);
/*     */         }
/*  84 */       } else if (event.getSource() == LineFrameTree.this.btnPanel.buttons[3]) {
/*  85 */         AbstractTreeDetails children = LineFrameTree.this.record.getCurrentLine().getTreeDetails();
/*  86 */         if ((children != null) && (children.getChildCount() > 0)) {
/*  87 */           List<AbstractLine> list = children.getLines(0);
/*  88 */           if (list.size() > 0) {
/*  89 */             LineFrameTree.this.setLine((AbstractLine)list.get(0));
/*     */           }
/*     */         }
/*  92 */       } else if (event.getSource() == LineFrameTree.this.btnPanel.buttons[4]) {
/*  93 */         LineFrameTree.this.changeRow(1);
/*  94 */       } else if (event.getSource() == LineFrameTree.this.btnPanel.buttons[5]) {
/*  95 */         LineFrameTree.this.setCurrentLine(LineFrameTree.this.fileView.getRowCount() - 1);
/*  96 */       } else if (event.getSource() == LineFrameTree.this.oneLineHex) {
/*  97 */         LineFrameTree.this.ap_100_setHexFormat();
/*     */       }
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected LineFrameTree(FileView viewOfFile, int cRow, boolean changeRow)
/*     */   {
/* 116 */     super("Record: ", viewOfFile, false, !viewOfFile.getLayout().isXml(), changeRow);
/*     */     
/* 118 */     super.setDisplayType(5);
/*     */     
/* 120 */     this.record = new LineModel(this.fileView);
/* 121 */     setModel(this.record);
/*     */     
/* 123 */     this.record.setCurrentLine(this.fileView.getLine(cRow), this.fileView.getCurrLayoutIdx());
/* 124 */     init_200_setupFields(this.icons, this.listner, changeRow);
/* 125 */     init_300_setupScreen(changeRow);
/*     */   }
/*     */   
/*     */ 
/*     */   protected LineFrameTree(FileView viewOfFile, AbstractLine line, boolean changeRow)
/*     */   {
/* 131 */     super("Record:", viewOfFile, false, !viewOfFile.getLayout().isXml(), changeRow);
/*     */     
/*     */ 
/* 134 */     if (line == null) {
/* 135 */       Common.logMsg("Line Can not be Viewed !!!!", null);
/* 136 */       closeWindow();
/* 137 */       return;
/*     */     }
/*     */     
/* 140 */     this.record = new LineModel(this.fileView);
/* 141 */     setModel(this.record);
/*     */     
/* 143 */     this.record.setCurrentLine(line, this.fileView.getCurrLayoutIdx());
/*     */     
/* 145 */     init_200_setupFields(this.icons, this.listner, changeRow);
/* 146 */     init_300_setupScreen(changeRow);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCurrRow()
/*     */   {
/* 158 */     int ret = -121;
/* 159 */     AbstractLine l = this.record.getCurrentLine();
/*     */     
/* 161 */     if (l != null) {
/* 162 */       l = ExpandLineTree.getRootLine(l);
/* 163 */       ret = this.fileView.indexOf(l);
/*     */     }
/* 165 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractLine getTreeLine()
/*     */   {
/* 173 */     return this.record.getCurrentLine();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCurrRow(FilePosition position)
/*     */   {
/* 181 */     setLine(position.currentLine);
/* 182 */     if ((position.col > 0) && (isCurrLayoutIdx(position.layoutIdxUsed))) {
/* 183 */       int fNo = FieldMapping.getAdjColumn(getModel().getFieldMapping(), position.layoutIdxUsed, position.col);
/* 184 */       this.tblDetails.getSelectionModel().clearSelection();
/* 185 */       this.tblDetails.getSelectionModel().setSelectionInterval(fNo, fNo);
/* 186 */       this.tblDetails.editCellAt(fNo, this.record.firstDataColumn);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCurrRow(int newRow, int layout, int fieldNum)
/*     */   {
/* 202 */     setCurrentLine(newRow);
/* 203 */     if ((fieldNum > 0) && (isCurrLayoutIdx(layout))) {
/* 204 */       int fNo = FieldMapping.getAdjColumn(getModel().getFieldMapping(), layout, fieldNum);
/* 205 */       this.tblDetails.getSelectionModel().clearSelection();
/* 206 */       this.tblDetails.getSelectionModel().setSelectionInterval(fNo, fNo);
/* 207 */       this.tblDetails.editCellAt(fNo, this.record.firstDataColumn);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void deleteLines()
/*     */   {
/* 216 */     AbstractLine line = this.record.getCurrentLine();
/* 217 */     getFileView().deleteLine(line);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 227 */     setLayoutIndex(this.record.getCurrentLayout());
/* 228 */     setupForChangeOfLayout();
/* 229 */     setDirectionButtonStatus();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int[] getSelectedRows()
/*     */   {
/* 237 */     return new int[] { getCurrRow() };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void tableChanged(TableModelEvent event)
/*     */   {
/* 250 */     switch (event.getType())
/*     */     {
/*     */     case 1: 
/*     */       break;
/*     */     case -1: 
/* 255 */       int currRow = getCurrRow();
/* 256 */       if (currRow < 0) {
/* 257 */         setCurrentLine(Math.min(this.fileView.getRowCount(), event.getFirstRow()));
/* 258 */       } else if ((currRow <= event.getLastRow()) && 
/* 259 */         (currRow > event.getFirstRow())) {
/* 260 */         setCurrentLine(Math.min(this.fileView.getRowCount(), event.getFirstRow()));
/*     */       }
/*     */       
/*     */       break;
/*     */     default: 
/* 265 */       this.record.fireTableDataChanged();
/*     */     }
/* 267 */     setFullLine();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void executeAction(int action)
/*     */   {
/* 277 */     switch (action) {
/*     */     case 31: 
/* 279 */       AbstractLine l = getFileView().repeatLine(this.record.getCurrentLine());
/* 280 */       if (l != null) {
/* 281 */         this.record.setCurrentLine(l, getLayoutIndex());
/* 282 */         setDirectionButtonStatus();
/*     */       }
/*     */       break;
/*     */     case 26: 
/*     */     case 27: 
/*     */     case 73: 
/*     */     case 74: 
/* 289 */       executeTreeAction(action);
/* 290 */       break;
/*     */     default: 
/* 292 */       super.executeAction(action);
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isActionAvailable(int action)
/*     */   {
/* 303 */     if (action == 31) {
/* 304 */       return true;
/*     */     }
/* 306 */     return super.isActionAvailable(action);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setDirectionButtonStatus()
/*     */   {
/* 315 */     AbstractLine l = this.record.getCurrentLine();
/* 316 */     this.btnPanel.buttons[0].setEnabled(true);
/* 317 */     if ((l == null) || (this.fileView == null)) {
/* 318 */       this.btnPanel.buttons[1].setEnabled(false);
/* 319 */       this.btnPanel.buttons[2].setEnabled(false);
/* 320 */       this.btnPanel.buttons[3].setEnabled(false);
/* 321 */       this.btnPanel.buttons[4].setEnabled(false);
/*     */     } else {
/* 323 */       int rowCount = this.fileView.getRowCount();
/* 324 */       AbstractLine parent = l.getTreeDetails().getParentLine();
/* 325 */       boolean changeParent = (parent == null) && (rowCount > 1);
/*     */       
/* 327 */       this.btnPanel.buttons[1].setEnabled((l != prevLine(l)) || ((changeParent) && (this.fileView.getLine(0) != l)));
/* 328 */       this.btnPanel.buttons[2].setEnabled(parent != null);
/* 329 */       this.btnPanel.buttons[3].setEnabled(l.getTreeDetails().getChildCount() > 0);
/* 330 */       this.btnPanel.buttons[4].setEnabled((l != nextLine(l)) || ((changeParent) && (this.fileView.getLine(rowCount - 1) != l)));
/*     */     }
/*     */     
/* 333 */     this.btnPanel.buttons[5].setEnabled(true);
/*     */   }
/*     */   
/*     */   private void setCurrentLine(int num) {
/* 337 */     setLine(this.fileView.getLine(num));
/*     */   }
/*     */   
/*     */   private void changeRow(int amount)
/*     */   {
/* 342 */     AbstractLine l = this.record.getCurrentLine();
/*     */     
/*     */ 
/*     */ 
/* 346 */     if (l.getTreeDetails().getParentLine() == null) {
/* 347 */       int idx = this.fileView.indexOf(l);
/* 348 */       if (idx < 0) {
/* 349 */         closeWindow();
/* 350 */         return;
/*     */       }
/* 352 */       idx = Math.min(Math.max(0, idx + amount), this.fileView.getRowCount() - 1);
/* 353 */       l = this.fileView.getLine(idx);
/*     */     }
/* 355 */     else if (amount < 0) {
/* 356 */       l = prevLine(l);
/*     */     } else {
/* 358 */       l = nextLine(l);
/*     */     }
/*     */     
/* 361 */     setLine(l);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setLine(AbstractLine l)
/*     */   {
/* 373 */     if (l != this.record.getCurrentLine()) {
/* 374 */       int[] colWidths = getColumnWidths();
/* 375 */       this.record.setCurrentLine(l, getLayoutIndex());
/*     */       
/* 377 */       setLayoutIndex(this.record.getCurrentLayout());
/*     */       
/*     */ 
/* 380 */       setDirectionButtonStatus();
/* 381 */       setColWidths();
/* 382 */       setColumnWidths(colWidths);
/* 383 */       setFullLine();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private AbstractLine prevLine(AbstractLine l)
/*     */   {
/* 393 */     AbstractLine prev = l;
/* 394 */     AbstractLine parent = l.getTreeDetails().getParentLine();
/* 395 */     if (parent != null) {
/* 396 */       AbstractTreeDetails children = parent.getTreeDetails();
/*     */       
/* 398 */       for (int i = 0; i < children.getChildCount(); i++) {
/* 399 */         List<? extends AbstractLine> list = children.getLines(i);
/* 400 */         for (AbstractLine line : list) {
/* 401 */           if (line == l) {
/* 402 */             return prev;
/*     */           }
/* 404 */           prev = line;
/*     */         }
/*     */       }
/*     */     }
/* 408 */     return prev;
/*     */   }
/*     */   
/*     */ 
/*     */   private AbstractLine nextLine(AbstractLine l)
/*     */   {
/* 414 */     AbstractLine next = l;
/* 415 */     AbstractLine parent = l.getTreeDetails().getParentLine();
/* 416 */     if (parent != null) {
/* 417 */       AbstractTreeDetails children = parent.getTreeDetails();
/* 418 */       boolean found = false;
/*     */       
/* 420 */       if ((children != null) && (children.getChildCount() > 0)) {
/* 421 */         for (int i = 0; i < children.getChildCount(); i++) {
/* 422 */           List<AbstractLine> list = children.getLines(i);
/* 423 */           for (AbstractLine line : list) {
/* 424 */             if (found) {
/* 425 */               return line;
/*     */             }
/* 427 */             found = line == l;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 432 */     return next;
/*     */   }
/*     */   
/*     */ 
/*     */   public String getScreenName()
/*     */   {
/* 438 */     return super.getScreenName() + " " + getLayoutCombo().getSelectedItem();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected LinePosition getInsertAfterLine(boolean prev)
/*     */   {
/* 448 */     if (prev) {
/* 449 */       AbstractLine l = prevLine(this.record.getCurrentLine());
/* 450 */       if (l != this.record.getCurrentLine()) {
/* 451 */         return new LinePosition(l, false);
/*     */       }
/*     */     }
/* 454 */     return new LinePosition(this.record.getCurrentLine(), prev);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected BaseDisplay getNewDisplay(FileView view)
/*     */   {
/* 463 */     return new LineFrameTree(view, 0, true);
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/LineFrameTree.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */