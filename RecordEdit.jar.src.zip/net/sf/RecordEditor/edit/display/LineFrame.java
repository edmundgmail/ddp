/*     */ package net.sf.RecordEditor.edit.display;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.ListSelectionModel;
/*     */ import javax.swing.event.TableModelEvent;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.RecordEditor.edit.display.models.BaseLineModel;
/*     */ import net.sf.RecordEditor.edit.display.models.LineModel;
/*     */ import net.sf.RecordEditor.edit.display.util.LinePosition;
/*     */ import net.sf.RecordEditor.re.file.FieldMapping;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LineFrame
/*     */   extends BaseLineFrame
/*     */   implements ILineDisplay
/*     */ {
/*     */   private int currRow;
/*  54 */   private ActionListener listner = new ActionListener()
/*     */   {
/*     */     public void actionPerformed(ActionEvent event) {
/*  57 */       LineFrame.this.stopCellEditing();
/*     */       
/*  59 */       if (event.getSource() == LineFrame.this.btnPanel.buttons[0]) {
/*  60 */         LineFrame.this.currRow = 0;
/*  61 */         LineFrame.this.rowChanged();
/*     */       }
/*  63 */       else if (event.getSource() == LineFrame.this.btnPanel.buttons[1]) {
/*  64 */         LineFrame.this.changeRow(-1);
/*  65 */       } else if (event.getSource() == LineFrame.this.btnPanel.buttons[2]) {
/*  66 */         LineFrame.this.changeRow(1);
/*  67 */       } else if (event.getSource() == LineFrame.this.btnPanel.buttons[3]) {
/*  68 */         LineFrame.this.currRow = (LineFrame.this.getFileView().getRowCount() - 1);
/*  69 */         LineFrame.this.rowChanged();
/*  70 */       } else if (event.getSource() == LineFrame.this.oneLineHex) {
/*  71 */         LineFrame.this.ap_100_setHexFormat();
/*     */       }
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected LineFrame(String screenName, FileView viewOfFile, int cRow, boolean changeRow)
/*     */   {
/*  83 */     super(screenName, viewOfFile, false, !viewOfFile.getLayout().isXml(), changeRow);
/*     */     
/*  85 */     init_101_setRecord(changeRow);
/*     */     
/*  87 */     init_100_setupRow(cRow);
/*  88 */     init_200_setupFields(Common.getArrowIcons(), this.listner, changeRow);
/*  89 */     init_300_setupScreen(changeRow);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void init_100_setupRow(int cRow)
/*     */   {
/*  99 */     this.lineNum.setText(Integer.toString(cRow + 1));
/* 100 */     this.lineNum.setEditable(false);
/*     */     
/* 102 */     this.record.setCurrentLine(cRow, this.fileView.getCurrLayoutIdx());
/* 103 */     this.currRow = cRow;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected LineFrame(String screenName, FileView viewOfFile, AbstractLine line, boolean changeRow)
/*     */   {
/* 111 */     super(screenName, viewOfFile, false, !viewOfFile.getLayout().isXml(), changeRow);
/*     */     
/* 113 */     init_101_setRecord(changeRow);
/*     */     
/* 115 */     this.record.setCurrentLine(line, this.fileView.getCurrLayoutIdx());
/* 116 */     this.currRow = -121;
/* 117 */     init_200_setupFields(Common.getArrowIcons(), this.listner, changeRow);
/* 118 */     init_300_setupScreen(changeRow);
/*     */   }
/*     */   
/*     */   private void init_101_setRecord(boolean changeRow)
/*     */   {
/* 123 */     if (changeRow) {
/* 124 */       this.record = new LineModel(this.fileView);
/*     */     } else {
/* 126 */       this.record = new LineModel(this.fileView, 2);
/*     */     }
/* 128 */     setModel(this.record);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCurrRow()
/*     */   {
/* 137 */     return this.currRow;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLine(AbstractLine line)
/*     */   {
/* 147 */     setCurrRow(this.fileView.indexOf(line));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCurrRow(int newRow)
/*     */   {
/* 156 */     if ((newRow >= 0) && (this.currRow != newRow)) {
/* 157 */       this.currRow = newRow;
/* 158 */       rowChanged();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCurrRow(int newRow, int layout, int fieldNum)
/*     */   {
/* 173 */     setCurrRow(newRow);
/*     */     
/* 175 */     if ((fieldNum > 0) && (getLayoutIndex() == layout)) {
/* 176 */       int fNo = FieldMapping.getAdjColumn(getModel().getFieldMapping(), layout, fieldNum);
/* 177 */       this.tblDetails.getSelectionModel().clearSelection();
/* 178 */       this.tblDetails.getSelectionModel().setSelectionInterval(fNo, fNo);
/* 179 */       this.tblDetails.editCellAt(fNo, this.record.firstDataColumn);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void deleteLines()
/*     */   {
/* 188 */     getFileView().deleteLine(this.currRow);
/*     */     
/* 190 */     rowChanged();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int[] getSelectedRows()
/*     */   {
/* 198 */     return new int[] { getCurrRow() };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void tableChanged(TableModelEvent event)
/*     */   {
/* 209 */     int firstRow = event.getFirstRow();
/* 210 */     switch (event.getType()) {
/*     */     case 1: 
/* 212 */       if (firstRow <= this.currRow) {
/* 213 */         changeRow(event.getLastRow() - firstRow + 1);
/*     */       }
/*     */       break;
/*     */     case -1: 
/* 217 */       if (this.currRow > event.getLastRow()) {
/* 218 */         this.currRow -= event.getLastRow() - firstRow + 1;
/* 219 */         rowChanged();
/* 220 */       } else if (this.currRow > firstRow) {
/* 221 */         this.currRow -= Math.min(this.fileView.getRowCount(), firstRow);
/* 222 */         rowChanged();
/*     */       }
/*     */       break;
/*     */     default: 
/* 226 */       this.currRow = this.record.getActualLineNumber();
/* 227 */       this.lineNum.setText(Integer.toString(this.currRow + 1));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 233 */       if ((super.hasTheFormatChanged(event)) || (firstRow < 0)) {
/* 234 */         this.record.fireTableDataChanged();
/* 235 */         this.record.layoutChanged(this.layout);
/* 236 */       } else if ((firstRow <= this.currRow) && (event.getLastRow() >= this.currRow) && (this.currRow >= 0))
/*     */       {
/*     */ 
/* 239 */         this.record.fireTableDataChanged();
/*     */       }
/*     */       break; }
/* 242 */     setFullLine();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void executeAction(int action)
/*     */   {
/* 251 */     if (action == 31) {
/* 252 */       getFileView().repeatLine(this.currRow);
/* 253 */       changeRow(1);
/*     */     } else {
/* 255 */       super.executeAction(action);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isActionAvailable(int action)
/*     */   {
/* 265 */     if (action == 31) {
/* 266 */       return true;
/*     */     }
/* 268 */     return super.isActionAvailable(action);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void rowChanged()
/*     */   {
/* 276 */     int[] colWidths = getColumnWidths();
/*     */     try {
/* 278 */       this.fileView.removeTableModelListener(this);
/*     */       
/* 280 */       stopCellEditing();
/*     */       
/* 282 */       if (this.currRow >= getFileView().getRowCount()) {
/* 283 */         if (this.currRow == 0) {
/* 284 */           closeWindow();
/*     */         } else {
/* 286 */           this.currRow -= 1;
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 291 */       this.lineNum.setText(Integer.toString(this.currRow + 1));
/*     */       
/* 293 */       this.record.setCurrentLayout(getLayoutIndex());
/*     */       
/* 295 */       this.record.setCurrentLine(this.currRow, getLayoutIndex());
/* 296 */       if (this.record.getCurrentLine() == null) {
/* 297 */         getParentFrame().close(this);
/*     */       }
/* 299 */       int newIdx = this.record.getCurrentLayout();
/*     */       
/* 301 */       if ((newIdx != -121) && (newIdx != getLayoutIndex()))
/*     */       {
/* 303 */         setLayoutIndex(newIdx);
/*     */         
/* 305 */         fireLayoutIndexChanged();
/* 306 */         setColWidths();
/* 307 */         setDirectionButtonStatus();
/* 308 */         setFullLine();
/*     */       }
/*     */       else {
/* 311 */         setColWidths();
/* 312 */         setDirectionButtonStatus();
/* 313 */         setFullLine();
/*     */       }
/*     */       
/* 316 */       setColumnWidths(colWidths);
/* 317 */       super.notifyChangeListners();
/*     */     } finally {
/* 319 */       this.fileView.addTableModelListener(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected LinePosition getInsertAfterLine(boolean prev)
/*     */   {
/* 330 */     if (prev) {
/* 331 */       return getInsertAfterLine(this.currRow, prev);
/*     */     }
/* 333 */     return new LinePosition(this.record.getCurrentLine(), prev);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setDirectionButtonStatus()
/*     */   {
/* 341 */     boolean allowBack = this.currRow > 0;
/* 342 */     boolean allowForward = (this.fileView != null) && (this.currRow < this.fileView.getRowCount() - 1);
/*     */     
/* 344 */     this.btnPanel.buttons[0].setEnabled(allowBack);
/* 345 */     this.btnPanel.buttons[1].setEnabled(allowBack);
/* 346 */     this.btnPanel.buttons[2].setEnabled(allowForward);
/* 347 */     this.btnPanel.buttons[3].setEnabled(allowForward);
/*     */   }
/*     */   
/*     */   private void changeRow(int amount) {
/* 351 */     this.currRow += amount;
/* 352 */     rowChanged();
/*     */   }
/*     */   
/*     */ 
/*     */   public String getScreenName()
/*     */   {
/* 358 */     return super.getScreenName() + " " + (this.currRow + 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected BaseDisplay getNewDisplay(FileView view)
/*     */   {
/* 366 */     return new LineFrame("Record:", view, 0, true);
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/LineFrame.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */