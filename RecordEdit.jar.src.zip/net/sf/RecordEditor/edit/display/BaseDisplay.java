/*      */ package net.sf.RecordEditor.edit.display;
/*      */ 
/*      */ import java.awt.Component;
/*      */ import java.awt.GridLayout;
/*      */ import java.awt.Point;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.Toolkit;
/*      */ import java.awt.datatransfer.Clipboard;
/*      */ import java.awt.datatransfer.DataFlavor;
/*      */ import java.awt.datatransfer.Transferable;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.ActionListener;
/*      */ import java.awt.event.KeyAdapter;
/*      */ import java.awt.event.KeyEvent;
/*      */ import java.awt.event.MouseAdapter;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.awt.event.MouseListener;
/*      */ import java.io.File;
/*      */ import java.util.List;
/*      */ import javax.swing.BorderFactory;
/*      */ import javax.swing.JDesktopPane;
/*      */ import javax.swing.JFileChooser;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JOptionPane;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.JTable;
/*      */ import javax.swing.JTable.PrintMode;
/*      */ import javax.swing.event.TableModelEvent;
/*      */ import javax.swing.event.TableModelListener;
/*      */ import javax.swing.table.JTableHeader;
/*      */ import javax.swing.table.TableCellEditor;
/*      */ import javax.swing.table.TableCellRenderer;
/*      */ import javax.swing.table.TableColumn;
/*      */ import javax.swing.table.TableColumnModel;
/*      */ import net.sf.JRecord.Common.CommonBits;
/*      */ import net.sf.JRecord.Details.AbstractChildDetails;
/*      */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*      */ import net.sf.JRecord.Details.AbstractLine;
/*      */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*      */ import net.sf.JRecord.Details.AbstractRecordDetail.FieldDetails;
/*      */ import net.sf.JRecord.Details.AbstractTreeDetails;
/*      */ import net.sf.JRecord.Details.BasicChildDefinition;
/*      */ import net.sf.JRecord.Details.LineCompare;
/*      */ import net.sf.RecordEditor.diff.DoCompare;
/*      */ import net.sf.RecordEditor.diff.LineBufferedReader;
/*      */ import net.sf.RecordEditor.edit.display.SaveAs.SaveAs3;
/*      */ import net.sf.RecordEditor.edit.display.SaveAs.SaveAs4;
/*      */ import net.sf.RecordEditor.edit.display.common.ILayoutChanged;
/*      */ import net.sf.RecordEditor.edit.display.util.AddAttributes;
/*      */ import net.sf.RecordEditor.edit.display.util.GotoLine;
/*      */ import net.sf.RecordEditor.edit.display.util.LinePosition;
/*      */ import net.sf.RecordEditor.edit.display.util.OptionPnl;
/*      */ import net.sf.RecordEditor.edit.display.util.Search;
/*      */ import net.sf.RecordEditor.edit.display.util.SortFrame;
/*      */ import net.sf.RecordEditor.edit.util.ReMessages;
/*      */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*      */ import net.sf.RecordEditor.re.display.AbstractFileDisplayWithFieldHide;
/*      */ import net.sf.RecordEditor.re.display.DisplayBuilderFactory;
/*      */ import net.sf.RecordEditor.re.display.IClosablePanel;
/*      */ import net.sf.RecordEditor.re.display.IDisplayBuilder;
/*      */ import net.sf.RecordEditor.re.display.IDisplayFrame;
/*      */ import net.sf.RecordEditor.re.display.IExecuteSaveAction;
/*      */ import net.sf.RecordEditor.re.file.AbstractLineNode;
/*      */ import net.sf.RecordEditor.re.file.FilePosition;
/*      */ import net.sf.RecordEditor.re.file.FileView;
/*      */ import net.sf.RecordEditor.re.jrecord.types.RecordFormats;
/*      */ import net.sf.RecordEditor.re.tree.ChildTreeToXml;
/*      */ import net.sf.RecordEditor.re.tree.TreeParserRecord;
/*      */ import net.sf.RecordEditor.re.tree.TreeParserXml;
/*      */ import net.sf.RecordEditor.re.tree.TreeToXml;
/*      */ import net.sf.RecordEditor.utils.common.Common;
/*      */ import net.sf.RecordEditor.utils.common.ReActionHandler;
/*      */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*      */ import net.sf.RecordEditor.utils.lang.ReOptionDialog;
/*      */ import net.sf.RecordEditor.utils.params.BoolOpt;
/*      */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*      */ import net.sf.RecordEditor.utils.params.ProgramOptions.InternalBoolOption;
/*      */ import net.sf.RecordEditor.utils.screenManager.ReMainFrame;
/*      */ import net.sf.RecordEditor.utils.screenManager.ReMsg;
/*      */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*      */ import net.sf.RecordEditor.utils.swing.IExternalTableCellColoring;
/*      */ import net.sf.RecordEditor.utils.swing.ITableColoringAgent;
/*      */ import net.sf.RecordEditor.utils.swing.LayoutCombo;
/*      */ import net.sf.RecordEditor.utils.swing.StandardRendor;
/*      */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*      */ import net.sf.RecordEditor.utils.swing.treeTable.TreeTableNotify;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class BaseDisplay
/*      */   implements AbstractFileDisplay, ILayoutChanged, ReActionHandler
/*      */ {
/*      */   private static final String PRINTING_REQUIRES_JAVA_5 = "Printing failed (Printing requires Java 1.5)";
/*      */   protected static final int NORMAL_DISPLAY = 3;
/*      */   protected static final int TREE_DISPLAY = 5;
/*  122 */   protected static IClosablePanel NO_CLOSE_ACTION_PNL = new IClosablePanel()
/*      */   {
/*      */     public void closePanel() {}
/*      */   };
/*      */   
/*      */   private static final int RECORDS_TO_CHECK = 30;
/*      */   
/*      */   public static final int MAXIMUM_NO_COLUMNS = 50000;
/*      */   
/*      */   protected static final int NO_OPTION_PANEL = 1;
/*      */   
/*      */   protected static final int STD_OPTION_PANEL = 2;
/*      */   
/*      */   protected static final int TREE_OPTION_PANEL = 3;
/*      */   protected static final int NO_LAYOUT_LINE = 4;
/*  137 */   protected static final IDisplayBuilder DisplayBldr = DisplayBuilderFactory.getInstance();
/*      */   
/*      */   public static final int NO_CHILD_FRAME = 1;
/*      */   
/*      */   public static final int CHILD_FRAME_RIGHT = 2;
/*      */   
/*      */   public static final int CHILD_FRAME_BOTTOM = 2;
/*      */   
/*      */   public final String formType;
/*      */   
/*      */   public final boolean primary;
/*      */   private Search searchScreen;
/*  149 */   protected Rectangle screenSize = ReMainFrame.getMasterFrame().getDesktop().getBounds();
/*      */   
/*      */   protected AbstractLayoutDetails layout;
/*      */   
/*      */   protected FileView fileView;
/*      */   
/*      */   protected FileView fileMaster;
/*      */   protected JTable tblDetails;
/*  157 */   private JTable alternativeTbl = null;
/*      */   
/*      */ 
/*      */ 
/*      */   private LayoutCombo layoutCombo;
/*      */   
/*      */ 
/*  164 */   protected BaseHelpPanel actualPnl = new BaseHelpPanel(getClass().getSimpleName());
/*      */   
/*      */ 
/*      */   protected TableCellRenderer[] cellRenders;
/*      */   
/*  169 */   private int maxHeight = -1;
/*      */   protected int[] widths;
/*  171 */   private IDisplayChangeListner changeListner = null;
/*      */   
/*  173 */   private RecordFormats[] displayDetails = null;
/*      */   
/*      */   protected TableCellEditor[] cellEditors;
/*      */   
/*      */   private HeaderToolTips toolTips;
/*      */   
/*  179 */   private ITableColoringAgent tableCellColoringAgent = null;
/*      */   
/*  181 */   private int displayType = 3;
/*      */   
/*  183 */   private boolean copyHiddenFields = false;
/*      */   
/*      */   private DisplayFrame parentFrame;
/*      */   
/*  187 */   private MouseListener dockingPopup = null;
/*  188 */   private boolean allowPaste = true;
/*      */   
/*      */   private final ExecuteSavedTasks executeTasks;
/*      */   
/*  192 */   private KeyAdapter listner = new KeyAdapter() {
/*  193 */     private long lastWhen = -121L;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public final void keyReleased(KeyEvent event)
/*      */     {
/*  203 */       if (this.lastWhen != event.getWhen())
/*      */       {
/*  205 */         if (event.getModifiers() == 2)
/*      */         {
/*      */ 
/*  208 */           if ((event.getKeyCode() == 65) && (BaseDisplay.this.allowPaste)) {
/*  209 */             BaseDisplay.this.tblDetails.selectAll();
/*      */ 
/*      */           }
/*  212 */           else if (event.getKeyCode() == 155) {
/*  213 */             BaseDisplay.this.insertLine(0);
/*      */ 
/*      */ 
/*      */ 
/*      */           }
/*  218 */           else if (event.getKeyCode() == 76) {
/*  219 */             new GotoLine(BaseDisplay.this, BaseDisplay.this.fileView);
/*      */           }
/*  221 */           this.lastWhen = event.getWhen();
/*      */         }
/*      */       }
/*      */     }
/*      */   };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private KeyAdapter ctrlVlistner;
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  238 */   private TableModelListener layoutChangeListner = new TableModelListener() {
/*      */     public void tableChanged(TableModelEvent arg0) {
/*  240 */       BaseDisplay.this.layoutChangedInternal(BaseDisplay.this.fileMaster.getLayout());
/*      */     }
/*      */   };
/*      */   
/*  244 */   private ActionListener layoutListner = new ActionListener()
/*      */   {
/*      */ 
/*      */ 
/*      */     public final void actionPerformed(ActionEvent e)
/*      */     {
/*      */ 
/*  251 */       if (e.getSource() == BaseDisplay.this.layoutCombo) {
/*  252 */         BaseDisplay.this.setupForChangeOfLayout();
/*      */       }
/*      */     }
/*      */   };
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected BaseDisplay(String formType, FileView viewOfFile, boolean primary, boolean addFullLine, boolean fullList, boolean prefered, boolean hex, int option)
/*      */   {
/*  276 */     this.fileView = viewOfFile;
/*  277 */     this.formType = formType;
/*  278 */     this.primary = primary;
/*  279 */     this.executeTasks = new ExecuteSavedTasks(this, viewOfFile);
/*      */     
/*      */ 
/*  282 */     init(addFullLine, fullList, prefered, hex);
/*      */     
/*      */ 
/*  285 */     switch (option) {
/*      */     case 4: 
/*      */       break;
/*      */     case 1: 
/*  289 */       this.actualPnl.addLineRE("Layouts", getLayoutCombo());
/*  290 */       break;
/*      */     default: 
/*  292 */       int opt = this.fileView.isBrowse() ? 1 : 2;
/*      */       
/*      */ 
/*  295 */       this.actualPnl.addComponent3Lines("Layouts", getLayoutCombo(), new OptionPnl(opt, this));
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void init(boolean addFullLine, boolean fullList, boolean prefered, boolean hex)
/*      */   {
/*  307 */     this.fileMaster = this.fileView.getBaseFile();
/*  308 */     this.layout = this.fileMaster.getLayout();
/*      */     
/*  310 */     this.actualPnl.addReKeyListener(this.listner);
/*      */     
/*  312 */     setupDisplayDetails(this.layout);
/*      */     
/*  314 */     this.layoutCombo = new LayoutCombo(this.layout, addFullLine, fullList, prefered, hex);
/*      */     
/*  316 */     setTableFormatDetails(0);
/*      */     
/*  318 */     this.searchScreen = new Search(this, this.fileMaster);
/*      */     
/*  320 */     this.layoutCombo.addActionListener(this.layoutListner);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  338 */     this.fileView.addTableModelListener(this.layoutChangeListner);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   protected final void initToolTips(int colsToSkip)
/*      */   {
/*  345 */     this.toolTips = new HeaderToolTips(this.tblDetails.getColumnModel(), colsToSkip);
/*  346 */     this.tblDetails.setTableHeader(this.toolTips);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public final void closePanel()
/*      */   {
/*  353 */     this.parentFrame.close(this);
/*      */   }
/*      */   
/*      */   public void doClose()
/*      */   {
/*  358 */     AbstractFileDisplay child = getChildScreen();
/*  359 */     if (child != null) {
/*  360 */       child.doClose();
/*      */     }
/*  362 */     if (this.fileView != null) {
/*  363 */       this.fileView.removeTableModelListener(this.layoutChangeListner);
/*      */     }
/*  365 */     closeWindow();
/*  366 */     this.layoutCombo.removeActionListener(this.layoutListner);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void closeWindow()
/*      */   {
/*      */     try
/*      */     {
/*  376 */       if (this.searchScreen != null) {
/*  377 */         ReMainFrame.getMasterFrame().deleteWindow(this.searchScreen);
/*  378 */         this.searchScreen.setVisible(false);
/*  379 */         this.searchScreen.setClosed(true);
/*  380 */         this.searchScreen = null;
/*      */       }
/*  382 */       this.fileView.removeTableModelListener(this.layoutChangeListner);
/*  383 */       stopCellEditing();
/*  384 */       this.fileMaster = null;
/*  385 */       this.fileView = null;
/*      */     }
/*      */     catch (Exception ex) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void layoutChanged(AbstractLayoutDetails newLayout) {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void layoutChangedInternal(AbstractLayoutDetails newLayout)
/*      */   {
/*  401 */     if (newLayout != this.layout) {
/*  402 */       this.layout = newLayout;
/*      */       
/*  404 */       this.layoutCombo.setRecordLayout(newLayout);
/*      */       
/*      */ 
/*  407 */       setupDisplayDetails(newLayout);
/*      */       
/*  409 */       setTableFormatDetails(getLayoutIndex());
/*  410 */       setNewLayout(newLayout);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void executeAction(int action, Object o)
/*      */   {
/*  423 */     if (o != null) {
/*  424 */       switch (action) {
/*      */       case 5: 
/*  426 */         executeSaveAs(9, o.toString());
/*  427 */         break;
/*      */       case 56: 
/*  429 */         executeSaveAs(8, o.toString());
/*  430 */         break;
/*      */       case 58: 
/*  432 */         executeSaveAs(7, o.toString());
/*  433 */         break;
/*      */       default: 
/*  435 */         executeAction(action);break;
/*      */       }
/*      */     } else {
/*  438 */       executeAction(action);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void executeAction(int action)
/*      */   {
/*  450 */     stopCellEditing();
/*      */     try
/*      */     {
/*  453 */       switch (action) {
/*  454 */       case 7:  this.searchScreen.startSearch(this.fileView); break;
/*  455 */       case 8:  new FilterFrame(this, this.fileView); break;
/*  456 */       case 43:  compareWithDisk(); break;
/*  457 */       case 40:  this.executeTasks.executeSavedFilterDialog(); break;
/*  458 */       case 41:  this.executeTasks.executeSavedSortTreeDialog(); break;
/*  459 */       case 42:  this.executeTasks.executeSavedRecordTreeDialog(); break;
/*  460 */       case 49:  createErrorView(); break;
/*  461 */       case 14:  createView(); break;
/*  462 */       case 15:  createRecordView(); break;
/*  463 */       case 16:  createColumnView(); break;
/*      */       case 55: 
/*  465 */         int[] selRows = getSelectedRows();
/*      */         
/*  467 */         if ((selRows != null) && (selRows.length > 0)) {
/*  468 */           BaseDisplay bd = getNewDisplay(this.fileView.getView(selRows));
/*  469 */           addToScreen(this.parentFrame, bd);
/*      */           
/*  471 */           copyVisibility(bd);
/*  472 */           bd.layoutCombo.setSelectedIndex(this.layoutCombo.getSelectedIndex()); }
/*  473 */         break;
/*      */       case 18: 
/*  475 */         new CreateSortedTree(this, this.fileView); break;
/*  476 */       case 17:  new CreateFieldTree(this, this.fileView); break;
/*  477 */       case 19:  new CreateRecordTree(this, this.fileView); break;
/*      */       case 20: 
/*  479 */         TreeParserRecord parser = new TreeParserRecord(executeAction_100_getParent());
/*      */         
/*  481 */         DisplayBuilderFactory.newLineTree(this.parentFrame, this.fileView, parser, false, 0);
/*  482 */         break;
/*      */       case 22: 
/*  484 */         if (getSelectedRowCount() > 0) {
/*  485 */           TreeParserRecord parser = new TreeParserRecord(executeAction_100_getParent());
/*      */           
/*  487 */           DisplayBuilderFactory.newLineTree(this.parentFrame, this.fileView.getView(getSelectedRows()), parser, false, 0); }
/*  488 */         break;
/*      */       case 21: 
/*  490 */         createXmlTreeView(); break;
/*  491 */       case 2:  new SaveAs4(this, this.fileView); break;
/*  492 */       case 57:  new SaveAs3(this, this.fileView); break;
/*      */       case 51: 
/*  494 */         executeSaveAs(4, "");
/*  495 */         break;
/*      */       case 52: 
/*  497 */         executeSaveAs(5, "");
/*  498 */         break;
/*      */       case 3: 
/*  500 */         executeSaveAs(1, "");
/*  501 */         break;
/*      */       case 4: 
/*  503 */         executeSaveAs(2, "");
/*  504 */         break;
/*      */       case 46: 
/*  506 */         executeSaveAs(3, "");
/*  507 */         break;
/*      */       case 5: 
/*  509 */         executeSaveAs(9, "");
/*  510 */         break;
/*      */       case 56: 
/*  512 */         executeSaveAs(8, "");
/*  513 */         break;
/*      */       case 58: 
/*  515 */         executeSaveAs(7, "");
/*  516 */         break;
/*      */       case 44: 
/*  518 */         if ((this.layout.hasTreeStructure()) || (this.layout.hasChildren())) {
/*  519 */           JFileChooser chooseFile = new JFileChooser();
/*  520 */           chooseFile.setDialogType(1);
/*  521 */           chooseFile.setSelectedFile(new File(this.fileView.getFileName() + ".xml"));
/*      */           
/*  523 */           int ret = chooseFile.showOpenDialog(null);
/*      */           
/*  525 */           if (ret == 0) {
/*  526 */             if (this.layout.hasChildren()) {
/*  527 */               new ChildTreeToXml(chooseFile.getSelectedFile().getPath(), this.fileView.getLines());
/*      */             } else {
/*  529 */               TreeParserRecord parser = new TreeParserRecord(executeAction_100_getParent());
/*      */               
/*  531 */               new TreeToXml(chooseFile.getSelectedFile().getPath(), parser.parse(this.fileView));
/*      */             }
/*      */           }
/*      */         }
/*      */         
/*  536 */         break;
/*      */       case 1: 
/*  538 */         saveFile(); break;
/*      */       case 29: case 77: 
/*      */       case 78: 
/*  541 */         deleteLines(); break;
/*  542 */       case 24:  copyRecords(); break;
/*      */       case 25: 
/*  544 */         copyRecords();
/*  545 */         deleteLines();
/*  546 */         break;
/*  547 */       case 82:  clearSelectedCells(); break;
/*  548 */       case 76:  copySelectedCells(); break;
/*  549 */       case 47:  pasteOverTbl(); break;
/*  550 */       case 75:  pasteStandard(); break;
/*      */       case 26: 
/*      */       case 73: 
/*  553 */         this.fileView.pasteLines(getInsertAfterPosition()); break;
/*      */       case 27: case 74: 
/*  555 */         this.fileView.pasteLines(getInsertBeforePosition()); break;
/*  556 */       case 13:  setRecordLayout(); break;
/*      */       case 28: case 71: 
/*  558 */         insertLine(0); break;
/*      */       case 53: case 72: 
/*  560 */         insertLine(-1); break;
/*  561 */       case 10:  closeWindow(); break;
/*  562 */       case 30:  new SortFrame(this, this.fileView); break;
/*  563 */       case 23:  this.actualPnl.showHelpRE(); break;
/*  564 */       case 38:  new AddAttributes(this.fileView, this.layoutCombo.getLayoutIndex()); break;
/*      */       case 36: 
/*      */         try {
/*  567 */           this.tblDetails.print(JTable.PrintMode.NORMAL);
/*      */         } catch (Exception e) {
/*  569 */           Common.logMsg("Printing failed (Printing requires Java 1.5)", e);
/*      */         }
/*      */       
/*      */       case 54: 
/*  573 */         int[] selRowsP = getSelectedRows();
/*      */         
/*  575 */         if ((selRowsP != null) && (selRowsP.length > 0)) {
/*      */           try {
/*  577 */             BaseDisplay bdisp = getNewDisplay(this.fileView.getView(selRowsP));
/*  578 */             DisplayFrame bd = new DisplayFrame(bdisp);
/*      */             
/*  580 */             bdisp.layoutCombo.setSelectedIndex(this.layoutCombo.getSelectedIndex());
/*  581 */             copyVisibility(bdisp);
/*  582 */             bd.setVisible(true);
/*  583 */             bd.setVisible(false);
/*  584 */             bd.executeAction(36);
/*  585 */             bd.dispose();
/*      */           } catch (Exception e) {
/*  587 */             Common.logMsg("Printing failed (Printing requires Java 1.5)", e);
/*      */           }
/*      */         }
/*      */         
/*      */         break;
/*      */       case 50: 
/*  593 */         Common.calcColumnWidths(getJTable(), 1);
/*      */       }
/*      */     } catch (Exception e) {
/*  596 */       Common.logMsg("Error Executing action:", null);
/*  597 */       Common.logMsg(e.getMessage(), e);
/*  598 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */   
/*      */   protected final void checkForResize(TableModelEvent event)
/*      */   {
/*  604 */     if (((event.getType() == 1) || (event.getType() == 0)) && (this.fileView != null) && (this.fileView.getRowCount() == 1) && (event.getFirstRow() == 0) && ((event.getLastRow() == 0) || (event.getLastRow() == Integer.MAX_VALUE)))
/*      */     {
/*      */ 
/*  607 */       Common.calcColumnWidths(getJTable(), 1);
/*      */     }
/*      */   }
/*      */   
/*      */   private final void executeSaveAs(int format, String s)
/*      */   {
/*  613 */     new SaveAs3(this, this.fileView, format, s);
/*      */   }
/*      */   
/*      */ 
/*      */   protected final void executeTreeAction(int action)
/*      */   {
/*  619 */     switch (action) {
/*      */     case 26: 
/*      */     case 73: 
/*  622 */       getFileView().pasteTreeLines(getInsertAfterLine(false));
/*  623 */       break;
/*      */     case 27: 
/*      */     case 74: 
/*  626 */       getFileView().pasteTreeLines(getInsertAfterLine(true));
/*  627 */       break;
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void insertLine(int adj)
/*      */   {
/*  643 */     insertLine(adj, false);
/*      */   }
/*      */   
/*      */   public void insertLine(int adj, boolean popup)
/*      */   {
/*  648 */     if (this.fileMaster.getTreeTableNotify() == null) {
/*  649 */       insertLine_100_FlatFile(adj, popup);
/*      */     } else {
/*  651 */       insertLine_200_TreeFile(adj);
/*      */     }
/*      */   }
/*      */   
/*      */   private void insertLine_100_FlatFile(int adj, boolean popup)
/*      */   {
/*  657 */     if ((this.layout.getOption(6) == 1) && (this.fileView.getBaseFile().getRowCount() > 0))
/*      */     {
/*  659 */       Common.logMsg("Only one record allowed in the file", null);
/*  660 */       return;
/*      */     }
/*      */     
/*  663 */     int pos = insertLine_101_FlatFile(adj, popup);
/*      */     
/*  665 */     checkLayout();
/*  666 */     newLineFrame(this.fileView, pos);
/*      */   }
/*      */   
/*      */   protected int insertLine_101_FlatFile(int adj, boolean popup) {
/*  670 */     int pos = this.fileView.newLine(getInsertPos(popup), adj);
/*      */     
/*  672 */     if (this.layout.isXml())
/*      */     {
/*  674 */       this.fileView.getLine(pos).setWriteLayout(this.layoutCombo.getLayoutIndex());
/*      */     }
/*  676 */     if (this.layout.getRecordCount() == 1) {
/*  677 */       AbstractRecordDetail rec = this.layout.getRecord(0);
/*  678 */       AbstractLine l = this.fileView.getLine(pos);
/*  679 */       for (int i = 0; i < rec.getFieldCount(); i++) {
/*  680 */         if (rec.getField(i).getDefaultValue() != null) {
/*      */           try {
/*  682 */             l.setField(0, i, rec.getField(i).getDefaultValue());
/*      */           }
/*      */           catch (Exception e) {}
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*  689 */     return pos;
/*      */   }
/*      */   
/*      */   private void insertLine_200_TreeFile(int adj)
/*      */   {
/*  694 */     LinePosition lp = getInsertAfterLine(adj < 0);
/*  695 */     AbstractLine l = lp.line;
/*  696 */     AbstractLine newLine = null;
/*  697 */     int adjust = 0;
/*      */     
/*  699 */     if (lp.before) {
/*  700 */       adjust = -1;
/*      */     }
/*      */     
/*  703 */     if (l == null) {
/*  704 */       if (this.fileView.getRowCount() == 0) {
/*  705 */         newLine = newMainLine(0);
/*  706 */         checkLayout();
/*  707 */         if (newLine != null) {
/*  708 */           newLineFrame(this.fileView, 0);
/*  709 */           AbstractLineNode root = (AbstractLineNode)this.fileView.getTreeTableNotify().getRoot();
/*  710 */           this.fileView.getTreeTableNotify().fireTreeStructureChanged(root, root.getPath(), null, null);
/*      */         }
/*      */       }
/*      */     } else {
/*  714 */       List<AbstractChildDetails> children = l.getTreeDetails().getInsertRecordOptions();
/*  715 */       AbstractChildDetails ldef = l.getTreeDetails().getChildDefinitionInParent();
/*  716 */       AbstractLine parent = l.getTreeDetails().getParentLine();
/*  717 */       AbstractChildDetails<AbstractRecordDetail> rootDef = null;
/*      */       
/*  719 */       if ((children == null) || (children.size() == 0)) {
/*  720 */         if (parent == null) {
/*  721 */           if ((this.layout.getOption(6) == 1) && (this.fileView.getBaseFile().getRowCount() > 0))
/*      */           {
/*  723 */             Common.logMsg("Only one record allowed in the file", null);
/*  724 */             return;
/*      */           }
/*  726 */           newLine = insertLine_210_CreateMainRecord(l, adjust);
/*      */         } else {
/*  728 */           if ((ldef == null) || (!ldef.isRepeated())) {
/*  729 */             Common.logMsg("Nothing can be inserted at this point", null);
/*  730 */             return;
/*      */           }
/*      */           
/*  733 */           newLine = insertLine_220_CreateRepeated(parent, l, ldef, adjust);
/*      */         }
/*      */       } else {
/*  736 */         if ((ldef != null) && (ldef.isRepeated())) {
/*  737 */           children.add(ldef);
/*  738 */         } else if ((parent == null) && ((this.layout.getOption(6) != 1) || (this.fileView.getBaseFile().getRowCount() == 0)))
/*      */         {
/*      */ 
/*  741 */           int idx = l.getPreferredLayoutIdx();
/*  742 */           rootDef = new BasicChildDefinition(l.getLayout().getRecord(idx), idx, 0);
/*      */           
/*  744 */           children.add(rootDef);
/*      */         }
/*      */         
/*  747 */         if (children.size() == 1)
/*      */         {
/*      */ 
/*  750 */           newLine = insertLine_230_CreateChild(l, (AbstractChildDetails)children.get(0), -1);
/*      */         }
/*      */         else {
/*  753 */           AbstractChildDetails resp = (AbstractChildDetails)ReOptionDialog.showInputDialog(this.parentFrame, "Select the Record to Insert", "Record Selection", 3, null, children.toArray(), children.get(0));
/*      */           
/*      */ 
/*      */ 
/*  757 */           if (resp != null) {
/*  758 */             if (resp == rootDef) {
/*  759 */               if ((this.layout.getOption(6) == 1) && (this.fileView.getBaseFile().getRowCount() > 0))
/*      */               {
/*  761 */                 Common.logMsg("Only one record allowed in the file", null);
/*  762 */                 return;
/*      */               }
/*  764 */               newLine = insertLine_210_CreateMainRecord(l, adjust);
/*  765 */             } else if (resp == ldef) {
/*  766 */               newLine = insertLine_220_CreateRepeated(parent, l, ldef, adjust);
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/*  771 */               newLine = insertLine_230_CreateChild(l, resp, -1);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*  776 */       if ((newLine != null) && (this.fileView != null))
/*      */       {
/*      */ 
/*  779 */         DisplayBldr.newDisplay(5, "", this.parentFrame, this.fileView.getLayout(), this.fileView, newLine);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private AbstractLine insertLine_210_CreateMainRecord(AbstractLine line, int adj)
/*      */   {
/*  786 */     return newMainLine(this.fileView.indexOf(line) + adj);
/*      */   }
/*      */   
/*      */ 
/*      */   private AbstractLine insertLine_220_CreateRepeated(AbstractLine parent, AbstractLine child, AbstractChildDetails childDef, int adj)
/*      */   {
/*  792 */     int location = parent.getTreeDetails().getLines(childDef.getChildIndex()).indexOf(child);
/*      */     
/*  794 */     if (location >= 0) {
/*  795 */       location += 1 + adj;
/*      */     }
/*      */     
/*  798 */     return insertLine_230_CreateChild(parent, childDef, location);
/*      */   }
/*      */   
/*      */   private AbstractLine insertLine_230_CreateChild(AbstractLine parent, AbstractChildDetails childDef, int location)
/*      */   {
/*  803 */     AbstractLine ret = parent.getTreeDetails().addChild(childDef, location);
/*      */     
/*  805 */     AbstractLineNode pn = this.fileView.getTreeNode(parent);
/*  806 */     if ((ret != null) && (pn != null))
/*      */     {
/*  808 */       pn.insert(ret, -1, location);
/*      */       
/*      */ 
/*  811 */       AbstractLine line = pn.getLine();
/*  812 */       if ((line != null) && (line.getOption(15) == 5))
/*      */       {
/*  814 */         this.fileView.fireRowUpdated(-1, null, line);
/*      */       }
/*      */     }
/*      */     
/*  818 */     return ret;
/*      */   }
/*      */   
/*      */   protected final int getInsertPos(boolean popup)
/*      */   {
/*  823 */     int insPos = -1;
/*  824 */     if (popup) {
/*  825 */       insPos = getPopupPosition();
/*      */     }
/*  827 */     if (insPos < 0) {
/*  828 */       insPos = getInsertAfterPosition();
/*      */     }
/*  830 */     return insPos;
/*      */   }
/*      */   
/*      */   private void checkLayout() {
/*  834 */     if ((!this.fileView.isView()) && (this.fileView.getRowCount() == 1)) {
/*  835 */       int idx = this.fileView.getLine(0).getPreferredLayoutIdx();
/*  836 */       if (idx >= 0) {
/*  837 */         setLayoutIndex(idx);
/*  838 */         setupForChangeOfLayout();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected AbstractLine newMainLine(int pos) {
/*  844 */     int location = this.fileView.newLine(pos, 0);
/*  845 */     AbstractLine ret = this.fileView.getLine(location);
/*  846 */     AbstractLineNode pn = (AbstractLineNode)this.fileView.getTreeTableNotify().getRoot();
/*  847 */     if ((ret != null) && (pn != null)) {
/*  848 */       pn.insert(ret, -1, location);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  853 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private int[] executeAction_100_getParent()
/*      */   {
/*  864 */     int[] parentIdxs = new int[this.layout.getRecordCount()];
/*      */     
/*  866 */     for (int i = 0; i < parentIdxs.length; i++) {
/*  867 */       parentIdxs[i] = this.layout.getRecord(i).getParentRecordIndex();
/*      */     }
/*      */     
/*  870 */     return parentIdxs;
/*      */   }
/*      */   
/*      */   private void compareWithDisk() {
/*      */     try {
/*  875 */       new DoCompare().compare1Layout(new LineBufferedReader(this.fileView.getFileName(), this.layout, null, null, true), new LineBufferedReader(this.fileView.getFileName(), this.layout, this.fileView.getBaseFile().getLines(), true));
/*      */ 
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  880 */       Common.logMsg("Error Compare", e);
/*  881 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isActionAvailable(int action)
/*      */   {
/*  965 */     boolean ret = false;
/*  966 */     switch (action) {
/*      */     case 2: 
/*      */     case 3: 
/*      */     case 4: 
/*      */     case 5: 
/*      */     case 7: 
/*      */     case 8: 
/*      */     case 10: 
/*      */     case 14: 
/*      */     case 15: 
/*      */     case 16: 
/*      */     case 23: 
/*      */     case 24: 
/*      */     case 36: 
/*      */     case 40: 
/*      */     case 43: 
/*      */     case 51: 
/*      */     case 52: 
/*      */     case 54: 
/*      */     case 55: 
/*      */     case 56: 
/*      */     case 57: 
/*      */     case 58: 
/*      */     case 76: 
/*  990 */       return true;
/*  991 */     case 46:  ret = this.layout.hasChildren(); break;
/*      */     case 20: case 22: 
/*  993 */       ret = this.layout.hasTreeStructure(); break;
/*  994 */     case 44:  ret = (this.layout.hasTreeStructure()) || (this.layout.hasChildren()); break;
/*  995 */     case 21:  ret = this.layout.isXml(); break;
/*  996 */     case 38:  ret = this.layout.isOkToAddAttributes(); break;
/*      */     
/*      */     case 17: 
/*      */     case 18: 
/*      */     case 19: 
/*      */     case 41: 
/*      */     case 42: 
/* 1003 */       ret = (!this.layout.hasChildren()) && (this.fileView.isTreeViewAvailable());
/*      */       
/* 1005 */       break;
/*      */     
/*      */     case 1: 
/*      */     case 13: 
/*      */     case 25: 
/*      */     case 26: 
/*      */     case 27: 
/*      */     case 28: 
/*      */     case 29: 
/*      */     case 30: 
/*      */     case 47: 
/*      */     case 49: 
/*      */     case 53: 
/*      */     case 71: 
/*      */     case 72: 
/*      */     case 73: 
/*      */     case 74: 
/*      */     case 75: 
/*      */     case 77: 
/*      */     case 78: 
/* 1025 */       ret = !this.fileView.isBrowse();
/*      */     }
/*      */     
/* 1028 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected abstract int getInsertAfterPosition();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int getPopupPosition()
/*      */   {
/* 1106 */     return getInsertAfterPosition();
/*      */   }
/*      */   
/*      */   protected int getInsertBeforePosition() {
/* 1110 */     return getStandardPosition() - 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected LinePosition getInsertAfterLine(boolean prev)
/*      */   {
/* 1118 */     return getInsertAfterLine(getInsertAfterPosition(), prev);
/*      */   }
/*      */   
/*      */   protected final LinePosition getInsertAfterLine(int idx, boolean prev) {
/* 1122 */     if (idx >= 0) {
/* 1123 */       if ((idx == 0) && (prev)) {
/* 1124 */         return new LinePosition(this.fileView.getLine(0), true);
/*      */       }
/* 1126 */       if (prev) {
/* 1127 */         idx--;
/*      */       }
/* 1129 */       return new LinePosition(this.fileView.getLine(idx), false);
/*      */     }
/*      */     
/* 1132 */     return new LinePosition(null, prev);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int getStandardPosition()
/*      */   {
/* 1141 */     int pos = getCurrRow();
/* 1142 */     if (pos < 0) {
/* 1143 */       pos = this.fileView.getRowCount() - 1;
/*      */     }
/*      */     
/* 1146 */     return pos;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final JTable getJTable()
/*      */   {
/* 1155 */     return this.tblDetails;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void setJTable(JTable tableDetails)
/*      */   {
/* 1163 */     this.tblDetails = tableDetails;
/*      */     
/* 1165 */     this.actualPnl.setComponentName(tableDetails, "FileDisplay");
/* 1166 */     this.tblDetails.putClientProperty("terminateEditOnFocusLost", Boolean.TRUE);
/*      */     
/* 1168 */     if (Common.OPTIONS.highlightEmptyActive.isSelected()) {
/* 1169 */       this.tblDetails.setDefaultRenderer(Object.class, new StandardRendor());
/*      */     }
/*      */     
/* 1172 */     if ((isActionAvailable(47)) && (Common.OPTIONS.useRowColSelection.isSelected()))
/*      */     {
/* 1174 */       tableDetails.setColumnSelectionAllowed(true);
/* 1175 */       tableDetails.setRowSelectionAllowed(true);
/*      */       
/* 1177 */       this.ctrlVlistner = new KeyAdapter() {
/* 1178 */         private long lastWhen = -121L;
/*      */         
/*      */         public final void keyReleased(KeyEvent event) {
/* 1181 */           if (this.lastWhen != event.getWhen())
/*      */           {
/* 1183 */             if ((event.getModifiers() == 2) && 
/* 1184 */               (event.getKeyCode() == 86) && (BaseDisplay.this.tblDetails.getSelectedRow() >= 0) && (BaseDisplay.this.tblDetails.hasFocus()))
/*      */             {
/*      */ 
/* 1187 */               BaseDisplay.this.pasteStandard();
/*      */             }
/*      */           }
/*      */         }
/* 1191 */       };
/* 1192 */       tableDetails.addKeyListener(this.ctrlVlistner);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void createView()
/*      */   {
/* 1201 */     int[] selRows = getSelectedRows();
/*      */     
/* 1203 */     if ((selRows != null) && (selRows.length > 0)) {
/* 1204 */       DisplayBuilderFactory.newLineList(this.parentFrame, this.fileView.getLayout(), this.fileView.getView(selRows), this.fileView.getBaseFile());
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void createColumnView()
/*      */   {
/* 1214 */     int rowCount = getSelectedRowCount();
/* 1215 */     if (rowCount > 50000) {
/* 1216 */       Common.logMsgRaw(ReMessages.TO_MANY_ROWS.get(new Object[] { Integer.valueOf(rowCount), Integer.valueOf(50000) }), null);
/*      */     } else {
/* 1218 */       int[] selRows = getSelectedRows();
/*      */       
/* 1220 */       if ((selRows != null) && (selRows.length > 0)) {
/* 1221 */         DisplayBldr.newDisplay(7, "", this.parentFrame, this.fileView.getLayout(), this.fileView.getView(selRows), 0);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void createRecordView()
/*      */   {
/* 1232 */     int[] selRows = getSelectedRows();
/*      */     
/* 1234 */     if ((selRows != null) && (selRows.length > 0)) {
/* 1235 */       newLineFrame(this.fileView.getView(selRows), 0);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private void createErrorView()
/*      */   {
/* 1244 */     FileView errorView = this.fileView.getViewOfErrorRecords();
/*      */     
/* 1246 */     if (errorView == null) {
/* 1247 */       Common.logMsg("No Error Records, nothing to display", null);
/*      */     } else {
/* 1249 */       newLineDisp("Error Records", errorView, 0);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void createXmlTreeView()
/*      */   {
/* 1257 */     int[] selRows = getSelectedRows();
/*      */     
/* 1259 */     if ((selRows != null) && (selRows.length > 0)) {
/* 1260 */       DisplayBuilderFactory.newLineTree(this.parentFrame, this.fileView.getView(selRows), TreeParserXml.getInstance(), false, 1);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public final boolean saveFile()
/*      */   {
/* 1269 */     boolean ret = true;
/*      */     
/*      */ 
/* 1272 */     if ("".equals(this.fileMaster.getFileName()))
/*      */     {
/* 1274 */       new SaveAs4(this, this.fileView);
/*      */     } else {
/*      */       try {
/* 1277 */         this.fileMaster.writeFile();
/*      */         
/* 1279 */         FileView errorView = this.fileView.getViewOfErrorRecords();
/*      */         
/* 1281 */         if (errorView != null) {
/* 1282 */           saveFileError(LangConversion.convert("File saved, but there where records in error that may not make it on to the file"), null);
/* 1283 */           newLineDisp("Error Records", errorView, 0);
/* 1284 */           ret = false;
/*      */         }
/*      */       }
/*      */       catch (Exception ex) {
/* 1288 */         saveFileError(LangConversion.convert("Save Failed:") + " " + ex.getMessage(), ex);
/* 1289 */         ex.printStackTrace();
/* 1290 */         ret = false;
/*      */       }
/*      */     }
/* 1293 */     return ret;
/*      */   }
/*      */   
/*      */   private void saveFileError(String s, Exception ex)
/*      */   {
/* 1298 */     JOptionPane.showInternalMessageDialog(this.parentFrame, s);
/* 1299 */     Common.logMsgRaw(s, ex);
/*      */   }
/*      */   
/*      */   private void check4Delete()
/*      */   {
/* 1304 */     int[] selected = getSelectedRows();
/* 1305 */     if ((selected != null) && (selected.length > 0))
/*      */     {
/*      */ 
/*      */ 
/* 1309 */       int res = 0;
/* 1310 */       if (Common.OPTIONS.warnWhenUsingDelKey.isSelected()) {
/* 1311 */         res = JOptionPane.showConfirmDialog(this.actualPnl, ReMessages.LINE_DELETE_MSG.get(Integer.toString(selected.length)), ReMessages.LINE_DELETE_CHECK.get(), 0);
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1322 */       if (res == 0) {
/* 1323 */         stopCellEditing();
/* 1324 */         deleteLines();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void deleteLines()
/*      */   {
/* 1334 */     int[] selRows = getSelectedRows();
/*      */     
/* 1336 */     if ((selRows != null) && (selRows.length > 0)) {
/* 1337 */       this.fileView.deleteLines(selRows);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void copyRecords()
/*      */   {
/* 1347 */     Common.runOptionalyInBackground(new Runnable() {
/*      */       public void run() {
/* 1349 */         int[] selRows = BaseDisplay.this.getSelectedRows();
/*      */         
/* 1351 */         if ((selRows != null) && (selRows.length > 0)) {
/* 1352 */           BaseDisplay.this.fileView.copyLines(selRows);
/*      */         }
/*      */       }
/*      */     });
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void fireLayoutIndexChanged();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNewLayout(AbstractLayoutDetails newLayout)
/*      */   {
/* 1369 */     setupDisplayDetails(newLayout);
/*      */   }
/*      */   
/*      */   private void setupDisplayDetails(AbstractLayoutDetails newLayout)
/*      */   {
/* 1374 */     this.displayDetails = new RecordFormats[newLayout.getRecordCount()];
/* 1375 */     for (int i = 0; i < this.displayDetails.length; i++) {
/* 1376 */       this.displayDetails[i] = null;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract int getCurrRow();
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public AbstractLine getTreeLine()
/*      */   {
/* 1390 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCurrRow(FilePosition position)
/*      */   {
/* 1399 */     int idx = setLayoutForPosition(position);
/*      */     
/* 1401 */     this.parentFrame.setToActiveTab(this);
/* 1402 */     setCurrRow(position.row, idx, position.currentFieldNumber);
/*      */   }
/*      */   
/*      */   protected final int setLayoutForPosition(FilePosition position) {
/* 1406 */     int idx = position.recordId;
/* 1407 */     if ((position.layoutIdxUsed >= 0) && (position.layoutIdxUsed < this.layout.getRecordCount()))
/*      */     {
/*      */ 
/* 1410 */       idx = position.layoutIdxUsed;
/* 1411 */       int currIdx; if ((position.layoutIdxUsed != (currIdx = getLayoutIndex())) && (currIdx < this.layout.getRecordCount()))
/*      */       {
/* 1413 */         setLayoutIndex(position.layoutIdxUsed);
/* 1414 */         setupForChangeOfLayout();
/*      */       }
/*      */     }
/* 1417 */     return idx;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public abstract void setCurrRow(int paramInt1, int paramInt2, int paramInt3);
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void setRecordLayout()
/*      */   {
/* 1433 */     int[] selRows = getSelectedRows();
/*      */     
/* 1435 */     if ((selRows != null) && (selRows.length > 0)) {
/* 1436 */       int layoutIdx = getLayoutIndex();
/*      */       
/* 1438 */       for (int i = 0; i < selRows.length; i++) {
/* 1439 */         this.fileView.getLine(i).setWriteLayout(layoutIdx);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void setLayoutIdx()
/*      */   {
/* 1450 */     if (this.layout.getRecordCount() > 0)
/*      */     {
/* 1452 */       int record2Use = 0;
/* 1453 */       int currMax = 0;
/* 1454 */       int recordsToCheck = Math.min(30, this.fileView.getRowCount());
/*      */       
/* 1456 */       int[] layoutCounts = new int[this.layout.getRecordCount()];
/*      */       
/*      */ 
/*      */ 
/* 1460 */       for (int i = 0; i < layoutCounts.length; i++) {
/* 1461 */         layoutCounts[i] = 0;
/*      */       }
/*      */       
/* 1464 */       for (i = 0; i < recordsToCheck; i++) {
/* 1465 */         int l = getLayoutIdx_100_getLayout4Row(i);
/* 1466 */         if (l > 0) {
/* 1467 */           layoutCounts[l] += 1;
/*      */         }
/*      */       }
/*      */       
/* 1471 */       for (i = 0; i < layoutCounts.length; i++) {
/* 1472 */         if (layoutCounts[i] > currMax) {
/* 1473 */           currMax = layoutCounts[i];
/* 1474 */           record2Use = i;
/*      */         }
/*      */       }
/*      */       
/* 1478 */       setLayoutIndex(record2Use);
/* 1479 */       setupForChangeOfLayout();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int getLayoutIdx_100_getLayout4Row(int row)
/*      */   {
/* 1490 */     return this.fileView.getTempLine(row).getPreferredLayoutIdx();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getSelectedRowCount()
/*      */   {
/* 1498 */     return this.tblDetails.getSelectedRowCount();
/*      */   }
/*      */   
/*      */ 
/*      */   public boolean isOkToUseSelectedRows()
/*      */   {
/* 1504 */     return true;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public int[] getSelectedRows()
/*      */   {
/* 1512 */     return this.tblDetails.getSelectedRows();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public List<AbstractLine> getSelectedLines()
/*      */   {
/* 1523 */     return this.fileView.getLines(getSelectedRows());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void stopCellEditing()
/*      */   {
/* 1532 */     Common.stopCellEditing(this.tblDetails);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void setTableFormatDetails(int recordIndex)
/*      */   {
/* 1543 */     if (recordIndex >= this.displayDetails.length) {
/* 1544 */       this.cellRenders = null;
/* 1545 */       this.cellEditors = null;
/*      */     } else {
/* 1547 */       RecordFormats recordDesc = getDisplayDetails(recordIndex);
/* 1548 */       this.cellRenders = recordDesc.getCellRenders();
/* 1549 */       this.cellEditors = recordDesc.getCellEditors();
/* 1550 */       this.widths = recordDesc.getWidths();
/*      */       
/* 1552 */       this.maxHeight = recordDesc.getMaxHeight();
/* 1553 */       if ((this.tblDetails != null) && (this.tblDetails.getRowHeight() > this.maxHeight)) {
/* 1554 */         this.maxHeight = Math.max(this.maxHeight, this.tblDetails.getRowHeight());
/*      */       }
/*      */       
/* 1557 */       setCellColoring();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final RecordFormats getDisplayDetails(int idx)
/*      */   {
/* 1571 */     if (this.displayDetails[idx] == null) {
/* 1572 */       this.layout = this.fileView.getLayout();
/* 1573 */       this.displayDetails[idx] = new RecordFormats(this.fileView, this.layout, idx);
/*      */     }
/* 1575 */     return this.displayDetails[idx];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final boolean hasTheFormatChanged(TableModelEvent event)
/*      */   {
/* 1585 */     boolean changed = false;
/*      */     
/* 1587 */     if (hasTheTableStructureChanged(event)) {
/* 1588 */       for (int i = 0; (i < this.displayDetails.length) && (!changed); i++) {
/* 1589 */         if (this.displayDetails[i] != null) {
/* 1590 */           changed = (changed) || (this.displayDetails[i].hasTheFormatChanged());
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 1595 */     if (changed)
/*      */     {
/* 1597 */       setTableFormatDetails(getLayoutIndex());
/*      */     }
/*      */     
/* 1600 */     return changed;
/*      */   }
/*      */   
/*      */   protected boolean hasTheTableStructureChanged(TableModelEvent event) {
/* 1604 */     return (event.getType() == 0) && (event.getFirstRow() < 0) && (event.getLastRow() < 0);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setRowHeight()
/*      */   {
/* 1629 */     setRowHeight(this.maxHeight);
/*      */   }
/*      */   
/*      */   protected void setRowHeight(int height) {
/* 1633 */     if (height > 0) {
/* 1634 */       this.tblDetails.setRowHeight(height);
/* 1635 */       if (this.alternativeTbl != null) {
/* 1636 */         this.alternativeTbl.setRowHeight(height);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void defineColumns(int numCols, int blankColumns, int columnsToSkip)
/*      */   {
/* 1646 */     defineColumns(this.tblDetails, numCols, blankColumns, columnsToSkip);
/*      */   }
/*      */   
/*      */   protected final void defineColumns(JTable tblDtls, int numCols, int blankColumns, int columnsToSkip)
/*      */   {
/* 1651 */     tblDtls.setAutoResizeMode(0);
/*      */     
/* 1653 */     TableColumnModel tcm = tblDtls.getColumnModel();
/*      */     
/* 1655 */     numCols = Math.min(numCols, tcm.getColumnCount());
/* 1656 */     for (int i = blankColumns; i < numCols; i++) {
/* 1657 */       if ((this.widths != null) && (i - blankColumns < this.widths.length) && (this.widths[(i - blankColumns)] > 0)) {
/* 1658 */         tcm.getColumn(i).setPreferredWidth(this.widths[(i - blankColumns)]);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1663 */     int idx = getLayoutIndex();
/* 1664 */     if (idx < this.layoutCombo.getFullLineIndex()) {
/* 1665 */       this.toolTips.setTips(this.layout.getFieldDescriptions(idx, 0));
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1697 */     Common.calcColumnWidths(tblDtls, blankColumns + 1);
/* 1698 */     setRowHeight();
/*      */   }
/*      */   
/*      */   protected void defineCellRenders(TableColumnModel tcm, int blankColumns, int columnsToSkip) {
/* 1702 */     int idx = getLayoutIndex();
/*      */     
/* 1704 */     if (idx < this.layoutCombo.getFullLineIndex())
/*      */     {
/*      */       try
/*      */       {
/* 1708 */         int count = Math.min(this.fileView.getLayoutColumnCount(idx), tcm.getColumnCount() - blankColumns + columnsToSkip);
/*      */         
/* 1710 */         if (this.cellRenders != null) {
/* 1711 */           int c = Math.min(count, this.cellRenders.length);
/* 1712 */           for (int i = columnsToSkip; i < c; i++) {
/* 1713 */             if (this.cellRenders[i] != null)
/*      */             {
/*      */ 
/*      */ 
/*      */ 
/* 1718 */               tcm.getColumn(i + blankColumns - columnsToSkip).setCellRenderer(this.cellRenders[i]);
/*      */             }
/*      */           }
/*      */         }
/*      */         
/* 1723 */         if (this.cellEditors != null) {
/* 1724 */           int c = Math.min(count, this.cellEditors.length);
/* 1725 */           for (int i = columnsToSkip; i < c; i++) {
/* 1726 */             if (this.cellEditors[i] != null) {
/* 1727 */               tcm.getColumn(i + blankColumns - columnsToSkip).setCellEditor(this.cellEditors[i]);
/*      */             }
/*      */           }
/*      */         }
/*      */       } catch (Exception e) {
/* 1732 */         e.printStackTrace();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   protected final boolean isCurrLayoutIdx(int layoutId)
/*      */   {
/* 1739 */     int idx = this.layoutCombo.getLayoutIndex();
/* 1740 */     return (idx == layoutId) || (idx == this.layoutCombo.getPreferedIndex());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public final int getLayoutIndex()
/*      */   {
/* 1748 */     return this.layoutCombo.getLayoutIndex();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setLayoutIndex(int recordIndex)
/*      */   {
/* 1759 */     this.layoutCombo.removeActionListener(this.layoutListner);
/* 1760 */     this.layoutCombo.setLayoutIndex(recordIndex);
/* 1761 */     if (recordIndex >= 0) {
/* 1762 */       setTableFormatDetails(recordIndex);
/* 1763 */       setRowHeight();
/*      */     }
/* 1765 */     this.layoutCombo.addActionListener(this.layoutListner);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final LayoutCombo getLayoutCombo()
/*      */   {
/* 1773 */     return this.layoutCombo;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final int[] getFieldCounts()
/*      */   {
/* 1781 */     int[] rows = new int[this.layout.getRecordCount()];
/*      */     
/* 1783 */     for (int i = 0; i < this.layout.getRecordCount(); i++) {
/* 1784 */       rows[i] = this.fileView.getLayoutColumnCount(i);
/*      */     }
/*      */     
/* 1787 */     return rows;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public FileView getFileView()
/*      */   {
/* 1811 */     return this.fileView;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public JTable getAlternativeTbl()
/*      */   {
/* 1820 */     return this.alternativeTbl;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setAlternativeTbl(JTable alternativeTbl)
/*      */   {
/* 1828 */     this.alternativeTbl = alternativeTbl;
/*      */   }
/*      */   
/*      */   protected void newLineFrame(FileView viewOfFile, int cRow)
/*      */   {
/*      */     AbstractFileDisplayWithFieldHide newScreen;
/*      */     AbstractFileDisplayWithFieldHide newScreen;
/* 1835 */     if ((this.displayType != 3) && (viewOfFile.getLayout().hasChildren()))
/*      */     {
/* 1837 */       newScreen = DisplayBldr.newDisplay(5, "", this.parentFrame, viewOfFile.getLayout(), viewOfFile, cRow);
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 1842 */       newScreen = newLineDisp(viewOfFile, cRow);
/*      */     }
/*      */     
/* 1845 */     if ((this.copyHiddenFields) && ((this instanceof AbstractFileDisplayWithFieldHide))) {
/* 1846 */       int idx = getLayoutIndex();
/* 1847 */       newScreen.setFieldVisibility(idx, ((AbstractFileDisplayWithFieldHide)this).getFieldVisibility(idx));
/*      */     }
/*      */   }
/*      */   
/*      */   protected AbstractFileDisplayWithFieldHide newLineDisp(FileView viewOfFile, int cRow)
/*      */   {
/* 1853 */     return newLineDisp("Record:", viewOfFile, cRow);
/*      */   }
/*      */   
/*      */ 
/*      */   protected AbstractFileDisplayWithFieldHide newLineDisp(String name, FileView viewOfFile, int cRow)
/*      */   {
/* 1859 */     return DisplayBldr.newDisplay(4, name, this.parentFrame, viewOfFile.getLayout(), viewOfFile, cRow);
/*      */   }
/*      */   
/*      */   protected static final void addToScreen(IDisplayFrame df, BaseDisplay d)
/*      */   {
/* 1864 */     if (Common.OPTIONS.useSeperateScreens.isSelected()) {
/* 1865 */       new DisplayFrame(d);
/*      */     } else {
/* 1867 */       df.addScreen(d);
/*      */     }
/*      */   }
/*      */   
/*      */   protected final int[] getColumnWidths() {
/* 1872 */     TableColumnModel tcm = this.tblDetails.getColumnModel();
/* 1873 */     int[] ret = new int[tcm.getColumnCount()];
/* 1874 */     for (int i = 0; i < tcm.getColumnCount(); i++) {
/* 1875 */       ret[i] = tcm.getColumn(i).getPreferredWidth();
/*      */     }
/*      */     
/* 1878 */     return ret;
/*      */   }
/*      */   
/*      */   protected final void setColumnWidths(int[] colWidths)
/*      */   {
/* 1883 */     TableColumnModel tcm = this.tblDetails.getColumnModel();
/* 1884 */     int size = Math.min(colWidths.length, tcm.getColumnCount());
/*      */     
/* 1886 */     for (int i = 0; i < size; i++) {
/* 1887 */       tcm.getColumn(i).setPreferredWidth(colWidths[i]);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void setDisplayType(int displayType)
/*      */   {
/* 1896 */     this.displayType = displayType;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void setCopyHiddenFields(boolean copyHiddenFields)
/*      */   {
/* 1904 */     this.copyHiddenFields = copyHiddenFields;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public BaseHelpPanel getActualPnl()
/*      */   {
/* 1912 */     return this.actualPnl;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public MouseListener getDockingPopup()
/*      */   {
/* 1920 */     return this.dockingPopup;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setDockingPopup(MouseListener dockingPopup)
/*      */   {
/* 1929 */     if (this.dockingPopup == null) {
/* 1930 */       this.dockingPopup = dockingPopup;
/* 1931 */       this.actualPnl.addMouseListener(dockingPopup);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public DisplayFrame getParentFrame()
/*      */   {
/* 1941 */     return this.parentFrame;
/*      */   }
/*      */   
/*      */   public AbstractFileDisplay getChildScreen()
/*      */   {
/* 1946 */     return null;
/*      */   }
/*      */   
/*      */   public int getAvailableChildScreenPostion()
/*      */   {
/* 1951 */     return 1;
/*      */   }
/*      */   
/*      */   public int getCurrentChildScreenPostion() {
/* 1955 */     return 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public void setTableCellColoringAgent(ITableColoringAgent tableCellColoringObj)
/*      */   {
/* 1962 */     this.tableCellColoringAgent = tableCellColoringObj;
/* 1963 */     setCellColoring();
/*      */   }
/*      */   
/*      */   private void setCellColoring()
/*      */   {
/* 1968 */     if ((this.cellRenders != null) && (this.tableCellColoringAgent != null)) {
/* 1969 */       for (Object r : this.cellRenders) {
/* 1970 */         setColoring(r);
/*      */       }
/*      */       
/* 1973 */       for (Object e : this.cellEditors) {
/* 1974 */         setColoring(e);
/*      */       }
/*      */       
/* 1977 */       TableColumnModel mdl = getJTable().getColumnModel();
/*      */       
/* 1979 */       for (int i = 0; i < mdl.getColumnCount(); i++) {
/* 1980 */         setColoring(mdl.getColumn(i).getCellRenderer());
/*      */       }
/*      */       
/*      */ 
/* 1984 */       this.fileView.fireTableDataChanged();
/* 1985 */       this.tblDetails.repaint();
/*      */     }
/*      */   }
/*      */   
/*      */   private void setColoring(Object o)
/*      */   {
/* 1991 */     if ((o instanceof IExternalTableCellColoring)) {
/* 1992 */       ((IExternalTableCellColoring)o).setTableCellColoring(this.tableCellColoringAgent);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setAllowPaste(boolean allowPaste)
/*      */   {
/* 2001 */     this.allowPaste = allowPaste;
/*      */   }
/*      */   
/*      */ 
/*      */   public void removeChildScreen() {}
/*      */   
/*      */   public int getChildFrameType()
/*      */   {
/* 2009 */     if (getChildScreen() != null) {
/* 2010 */       return 2;
/*      */     }
/*      */     
/* 2013 */     return 1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public IExecuteSaveAction getExecuteTasks()
/*      */   {
/* 2021 */     return this.executeTasks;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void setParentFrame(DisplayFrame parentFrame, boolean mainframe)
/*      */   {
/* 2029 */     this.parentFrame = parentFrame;
/*      */     
/* 2031 */     if (mainframe) {
/* 2032 */       setScreenSize(mainframe);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setScreenSize(boolean mainframe) {}
/*      */   
/*      */ 
/*      */ 
/*      */   public void setChangeListner(IDisplayChangeListner changeListner)
/*      */   {
/* 2045 */     this.changeListner = changeListner;
/*      */   }
/*      */   
/*      */   protected void notifyChangeListners() {
/* 2049 */     if (this.changeListner != null) {
/* 2050 */       this.changeListner.displayChanged();
/*      */     }
/*      */   }
/*      */   
/*      */   public String getScreenName() {
/* 2055 */     return LangConversion.convert(5, this.formType);
/*      */   }
/*      */   
/*      */   private void copyVisibility(AbstractFileDisplay bd) {
/* 2059 */     if ((this instanceof AbstractFileDisplayWithFieldHide)) {
/* 2060 */       int count = this.layoutCombo.getItemCount();
/* 2061 */       AbstractFileDisplayWithFieldHide from = (AbstractFileDisplayWithFieldHide)this;
/* 2062 */       AbstractFileDisplayWithFieldHide to = (AbstractFileDisplayWithFieldHide)bd;
/*      */       
/* 2064 */       for (int i = 0; i < count; i++) {
/* 2065 */         to.setFieldVisibility(i, from.getFieldVisibility(i));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */   protected abstract BaseDisplay getNewDisplay(FileView paramFileView);
/*      */   
/*      */   protected final void setupForChangeOfLayout()
/*      */   {
/* 2075 */     int idx = this.layoutCombo.getSelectedIndex();
/*      */     
/* 2077 */     if (idx >= 0) {
/* 2078 */       setTableFormatDetails(idx);
/* 2079 */       setRowHeight();
/* 2080 */       fireLayoutIndexChanged();
/*      */     }
/*      */   }
/*      */   
/*      */   private void pasteStandard() {
/* 2085 */     if ((this.tblDetails.getSelectedRowCount() > 1) || (this.tblDetails.getSelectedColumnCount() > 1)) {
/* 2086 */       pasteOverSelected();
/*      */     } else {
/* 2088 */       pasteOverTbl();
/*      */     }
/*      */   }
/*      */   
/*      */   private void clearSelectedCells() {
/* 2093 */     JTable tbl = getJTable();
/* 2094 */     int[] selectedRows = tbl.getSelectedRows();
/* 2095 */     int[] selectedColumns = tbl.getSelectedColumns();
/* 2096 */     if ((selectedRows != null) && (selectedColumns != null)) {
/* 2097 */       for (int row : selectedRows) {
/* 2098 */         for (int col : selectedColumns) {
/* 2099 */           tbl.setValueAt(Common.MISSING_VALUE, row, col);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void copySelectedCells() {
/* 2106 */     SwingUtils.copySelectedCells(getJTable());
/*      */   }
/*      */   
/*      */   protected final void pasteOverTbl()
/*      */   {
/* 2111 */     JTable tblDtls = getJTable();
/*      */     
/* 2113 */     pasteOver(this, tblDtls.getSelectedRow(), tblDtls.getSelectedColumn(), Integer.MAX_VALUE, Integer.MAX_VALUE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private final void pasteOverSelected()
/*      */   {
/* 2127 */     JTable dtlTbl = getJTable();
/*      */     
/* 2129 */     pasteOver(this, dtlTbl.getSelectedRow(), dtlTbl.getSelectedColumn(), dtlTbl.getSelectedRowCount(), dtlTbl.getSelectedColumnCount());
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void pasteOver(Object requestor, int startRow, int startCol, int numRows, int numCols)
/*      */   {
/* 2147 */     if (startRow >= 0) {
/* 2148 */       Clipboard system = Toolkit.getDefaultToolkit().getSystemClipboard();
/*      */       try {
/* 2150 */         pasteTable(startRow, startCol, numRows, numCols, (String)system.getContents(this).getTransferData(DataFlavor.stringFlavor));
/*      */       }
/*      */       catch (Exception e) {}
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected final void pasteTable(int startRow, int startCol, String trstring)
/*      */   {
/* 2161 */     pasteTable(startRow, startCol, Integer.MAX_VALUE, Integer.MAX_VALUE, trstring);
/*      */   }
/*      */   
/*      */   private final void pasteTable(int startRow, int startCol, int rowCount, int colCount, String trstring)
/*      */   {
/*      */     try {
/* 2167 */       this.fileMaster.setDisplayErrorDialog(false);
/* 2168 */       SwingUtils.pasteTable(getJTable(), startRow, startCol, rowCount, colCount, trstring);
/*      */     } catch (Exception ex) {
/* 2170 */       ex.printStackTrace();
/*      */     } finally {
/* 2172 */       this.fileMaster.setDisplayErrorDialog(true);
/*      */     }
/*      */   }
/*      */   
/*      */   private final void deleteSelectedCells()
/*      */   {
/*      */     try {
/* 2179 */       JTable tblDetails = getJTable();
/* 2180 */       int startRow = tblDetails.getSelectedRow();
/* 2181 */       int startCol = tblDetails.getSelectedColumn();
/* 2182 */       int rowCount = tblDetails.getSelectedRowCount();
/* 2183 */       int colCount = tblDetails.getSelectedColumnCount();
/* 2184 */       this.fileMaster.setDisplayErrorDialog(false);
/* 2185 */       stopCellEditing();
/*      */       
/* 2187 */       for (int i = 0; i < rowCount; i++) {
/* 2188 */         for (int j = 0; j < colCount; j++) {
/* 2189 */           if (tblDetails.isCellEditable(startRow + i, startCol + j)) {
/* 2190 */             tblDetails.setValueAt(CommonBits.NULL_VALUE, startRow + i, startCol + j);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/* 2197 */       ex.printStackTrace();
/*      */     } finally {
/* 2199 */       this.fileMaster.setDisplayErrorDialog(true);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   private static class HeaderToolTips
/*      */     extends JTableHeader
/*      */   {
/*      */     private String[] tips;
/*      */     
/*      */ 
/*      */ 
/*      */     private final int colsToSkip;
/*      */     
/*      */ 
/*      */ 
/*      */     public HeaderToolTips(TableColumnModel columnModel, int colsToSkip)
/*      */     {
/* 2219 */       super();
/* 2220 */       this.colsToSkip = colsToSkip;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void setTips(String[] strings)
/*      */     {
/* 2229 */       this.tips = strings;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public String getToolTipText(MouseEvent m)
/*      */     {
/* 2236 */       String tip = super.getToolTipText(m);
/*      */       try
/*      */       {
/* 2239 */         int col = super.getColumnModel().getColumnIndexAtX(m.getPoint().x);
/* 2240 */         if (col >= 0) {
/* 2241 */           col = super.getColumnModel().getColumn(col).getModelIndex() - this.colsToSkip;
/* 2242 */           if ((this.tips != null) && (col < this.tips.length) && (col >= 0)) {
/* 2243 */             tip = this.tips[col];
/*      */           }
/*      */         }
/*      */       } catch (Exception e) {
/* 2247 */         e.printStackTrace();
/*      */       }
/*      */       
/* 2250 */       return tip;
/*      */     }
/*      */   }
/*      */   
/*      */   public class DelKeyWatcher extends KeyAdapter {
/* 2255 */     private long lastWhen = Long.MIN_VALUE;
/*      */     
/*      */     public DelKeyWatcher() {}
/*      */     
/*      */     public final void keyReleased(KeyEvent event)
/*      */     {
/* 2261 */       long when = event.getWhen();
/*      */       
/* 2263 */       if ((when != this.lastWhen) && ((event.getModifiers() & 0x2) == 0) && ((event.getModifiers() & 0x1) == 0) && (BaseDisplay.this.tblDetails.getSelectedRow() >= 0))
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/* 2268 */         switch (event.getKeyCode()) {
/*      */         case 127: 
/* 2270 */           if (Common.OPTIONS.deleteSelectedWithDelKey.isSelected()) {
/* 2271 */             BaseDisplay.this.check4Delete();
/*      */           } else {
/* 2273 */             BaseDisplay.this.deleteSelectedCells();
/*      */           }
/*      */           break;
/*      */         }
/*      */         
/*      */       }
/* 2279 */       this.lastWhen = when;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final class HeaderSort
/*      */     extends MouseAdapter
/*      */   {
/* 2290 */     private int lastCol = -1;
/*      */     
/*      */     public HeaderSort() {}
/*      */     
/*      */     public void mousePressed(MouseEvent e)
/*      */     {
/* 2296 */       if (e.getClickCount() == 2) {
/* 2297 */         JTableHeader header = (JTableHeader)e.getSource();
/* 2298 */         int col = header.columnAtPoint(e.getPoint());
/* 2299 */         int layoutIndex = BaseDisplay.this.getLayoutIndex();
/*      */         
/* 2301 */         col = BaseDisplay.this.fileView.getRealColumn(layoutIndex, header.getColumnModel().getColumn(col).getModelIndex() - 2);
/*      */         
/*      */ 
/* 2304 */         if (col >= 0) {
/* 2305 */           int[] cols = { col };
/* 2306 */           boolean[] descending = { this.lastCol == col ? 1 : 0 };
/*      */           
/* 2308 */           BaseDisplay.this.fileView.sort(new LineCompare(BaseDisplay.this.fileView.getLayout(), layoutIndex, cols, descending));
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2315 */           if (this.lastCol == col) {
/* 2316 */             this.lastCol = -1;
/*      */           } else {
/* 2318 */             this.lastCol = col;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public class HeaderRender
/*      */     extends JPanel
/*      */     implements TableCellRenderer
/*      */   {
/*      */     public HeaderRender() {}
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public Component getTableCellRendererComponent(JTable tbl, Object value, boolean isFldSelected, boolean hasFocus, int row, int column)
/*      */     {
/* 2345 */       removeAll();
/* 2346 */       setLayout(new GridLayout(2, 1));
/*      */       
/* 2348 */       if ((column >= 0) && (value != null))
/*      */       {
/* 2350 */         String s = (String)value;
/* 2351 */         String first = s;
/* 2352 */         String second = "";
/* 2353 */         int pos = s.indexOf("|");
/* 2354 */         if (pos > 0) {
/* 2355 */           first = s.substring(pos + 1);
/* 2356 */           second = s.substring(0, pos);
/*      */         }
/* 2358 */         JLabel label = new JLabel(first);
/* 2359 */         add(label);
/* 2360 */         if (!second.equals("")) {
/* 2361 */           label = new JLabel(second);
/*      */           
/*      */ 
/* 2364 */           if (BaseDisplay.this.getLayoutIndex() >= BaseDisplay.this.getLayoutCombo().getFullLineIndex()) {
/* 2365 */             label.setFont(SwingUtils.getMonoSpacedFont());
/*      */           }
/*      */           
/* 2368 */           add(label);
/*      */         }
/*      */       }
/* 2371 */       setBorder(BorderFactory.createEtchedBorder());
/*      */       
/* 2373 */       return this;
/*      */     }
/*      */   }
/*      */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/BaseDisplay.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */