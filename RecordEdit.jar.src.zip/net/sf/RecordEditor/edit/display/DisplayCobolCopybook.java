/*     */ package net.sf.RecordEditor.edit.display;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.File;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JTextField;
/*     */ import net.sf.JRecord.Common.AbstractFieldValue;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.LayoutDetail;
/*     */ import net.sf.JRecord.Details.RecordDetail;
/*     */ import net.sf.JRecord.Details.RecordDetail.FieldDetails;
/*     */ import net.sf.JRecord.IO.AbstractLineReader;
/*     */ import net.sf.JRecord.IO.LineIOProvider;
/*     */ import net.sf.JRecord.Numeric.ConversionManager;
/*     */ import net.sf.JRecord.Numeric.Convert;
/*     */ import net.sf.RecordEditor.re.display.DisplayBuilderFactory;
/*     */ import net.sf.RecordEditor.re.display.IDisplayBuilder;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.re.openFile.ComputerOptionCombo;
/*     */ import net.sf.RecordEditor.re.tree.TreeParserXml;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.fileStorage.DataStoreStd;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions.FileNameOpt;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMainFrame;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.FileSelectCombo;
/*     */ import net.sf.cb2xml.Cb2Xml2;
/*     */ import net.sf.cb2xml.CopyBookAnalyzer;
/*     */ import net.sf.cb2xml.def.NumericDefinition;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DisplayCobolCopybook
/*     */   implements ActionListener
/*     */ {
/*  43 */   private static final String ERROR_COBOL_COPYBOOK_FILE_IS_A_DIRECTORY = LangConversion.convert("Error: cobol copybook file is a directory");
/*  44 */   private static final String NOTHING_TO_DISPLAY = LangConversion.convert("Nothing to Display");
/*  45 */   private static final String COBOL_COPYBOOK_DOES_NOT_EXIST = LangConversion.convert("Cobol Copybook does not exist");
/*  46 */   private static final String COBOL_COPYBOOK_NAME_MSG = LangConversion.convert("You must enter a Cobol Copybook name");
/*     */   
/*  48 */   private FileSelectCombo copybook = new FileSelectCombo("CobolCpy.", 25, true, false, true);
/*  49 */   private ComputerOptionCombo cobolDialect = new ComputerOptionCombo();
/*  50 */   private JButton displayBtn = SwingUtils.newButton("Display");
/*  51 */   private JCheckBox showComments = new JCheckBox();
/*  52 */   private JTextField msgTxt = new JTextField();
/*     */   
/*     */   public DisplayCobolCopybook()
/*     */   {
/*  56 */     BasePanel p = new BasePanel();
/*  57 */     ReFrame frame = new ReFrame("", "Copybook Analysis", "Copybook Analysis", null);
/*     */     
/*  59 */     this.copybook.setText(Common.OPTIONS.DEFAULT_COBOL_DIRECTORY.get());
/*  60 */     this.showComments.setSelected(false);
/*     */     
/*  62 */     p.setGapRE(BasePanel.GAP3);
/*  63 */     p.addLineRE("Copybook", this.copybook);
/*  64 */     p.setGapRE(BasePanel.GAP1);
/*  65 */     p.addLineRE("Cobol Dialect", this.cobolDialect);
/*  66 */     p.setGapRE(BasePanel.GAP1);
/*  67 */     p.addLineRE("Include Comments", this.showComments, this.displayBtn);
/*  68 */     p.setGapRE(BasePanel.GAP3);
/*  69 */     p.addMessage(this.msgTxt);
/*     */     
/*  71 */     frame.addMainComponent(p);
/*  72 */     frame.setVisible(true);
/*     */     
/*  74 */     this.displayBtn.addActionListener(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void actionPerformed(ActionEvent event)
/*     */   {
/*  83 */     if (event.getSource() == this.displayBtn) {
/*  84 */       String name = this.copybook.getText();
/*  85 */       if ("".equals(name)) {
/*  86 */         this.msgTxt.setText(COBOL_COPYBOOK_NAME_MSG);
/*  87 */         this.copybook.requestFocus();
/*  88 */       } else if (new File(name).isDirectory()) {
/*  89 */         this.msgTxt.setText(ERROR_COBOL_COPYBOOK_FILE_IS_A_DIRECTORY);
/*  90 */       } else if (new File(name).exists()) {
/*  91 */         display(name, this.cobolDialect.getSelectedIndex(), this.showComments.isSelected());
/*     */       } else {
/*  93 */         this.msgTxt.setText(COBOL_COPYBOOK_DOES_NOT_EXIST);
/*  94 */         this.copybook.requestFocus();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void display(String fileName, int dialect, boolean incComments)
/*     */   {
/* 102 */     Convert conv = ConversionManager.getInstance().getConverter(dialect);
/*     */     try
/*     */     {
/* 105 */       AbstractLineReader reader = LineIOProvider.getInstance().getLineReader(61);
/* 106 */       File file = new File(fileName);
/* 107 */       DataStoreStd<AbstractLine> lines = DataStoreStd.newStore(null);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 112 */       CopyBookAnalyzer.setNumericDetails((NumericDefinition)conv.getNumericDefinition());
/* 113 */       String xml = Cb2Xml2.convertToXMLString(Cb2Xml2.convertToXMLDOM(file));
/*     */       
/* 115 */       reader.open(new ByteArrayInputStream(xml.getBytes()), getXmlLayout(incComments));
/*     */       AbstractLine aLine;
/* 117 */       while ((aLine = reader.read()) != null) {
/* 118 */         if ((incComments) || (!"XML Comment".equals(aLine.getFieldValue("Xml~Name").asString()))) {
/* 119 */           lines.add(aLine);
/*     */         }
/*     */       }
/* 122 */       lines.setLayoutRE(reader.getLayout());
/*     */       
/* 124 */       if (lines.size() > 1) {
/* 125 */         DisplayBuilderFactory.getInstance().newDisplay(6, null, lines.getLayoutRE(), new FileView(lines, null, null), TreeParserXml.getInstance(), true, 1);
/*     */ 
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/* 132 */         this.msgTxt.setText(NOTHING_TO_DISPLAY);
/*     */       }
/* 134 */       reader.close();
/*     */     }
/*     */     catch (Exception e) {
/* 137 */       Common.logMsgRaw(e.getMessage(), null);
/* 138 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private LayoutDetail getXmlLayout(boolean incComment)
/*     */   {
/* 145 */     String recordName = "item";
/* 146 */     int idx = 0;
/* 147 */     RecordDetail.FieldDetails[] fields = { new RecordDetail.FieldDetails("Xml~Name", "", 116, 0, "", 0, "").setPosOnly(idx++), new RecordDetail.FieldDetails("Xml~End", "", 110, 0, "", 0, "").setPosOnly(idx++), new RecordDetail.FieldDetails("Following~Text", "", 117, 0, "", 0, "").setPosOnly(idx++), new RecordDetail.FieldDetails("level", "", 0, 0, "", 0, "").setPosOnly(idx++), new RecordDetail.FieldDetails("name", "", 0, 0, "", 0, "").setPosOnly(idx++), new RecordDetail.FieldDetails("position", "", 0, 0, "", 0, "").setPosOnly(idx++), new RecordDetail.FieldDetails("storage-length", "", 0, 0, "", 0, "").setPosOnly(idx++), new RecordDetail.FieldDetails("display-length", "", 0, 0, "", 0, "").setPosOnly(idx++), new RecordDetail.FieldDetails("picture", "", 0, 0, "", 0, "").setPosOnly(idx++), new RecordDetail.FieldDetails("usage", "", 0, 0, "", 0, "").setPosOnly(idx++) };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 159 */     RecordDetail item = new RecordDetail(recordName, "Xml~Name", recordName, 6, "", "", "", fields, 0, 0);
/*     */     
/*     */ 
/*     */ 
/* 163 */     RecordDetail[] recs = { item, null, null, null, null, null };
/*     */     
/* 165 */     if (incComment) {
/* 166 */       idx = 0;
/* 167 */       recordName = "XML Comment";
/* 168 */       RecordDetail.FieldDetails[] fields1 = { new RecordDetail.FieldDetails("Xml~Name", "", 116, 0, "", 0, "").setPosOnly(idx++), new RecordDetail.FieldDetails("Xml~End", "", 110, 0, "", 0, "").setPosOnly(idx++), new RecordDetail.FieldDetails("Following~Text", "", 117, 0, "", 0, "").setPosOnly(idx++), new RecordDetail.FieldDetails("zz:Dummy", "", 0, 0, "", 0, "").setPosOnly(idx++) };
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 174 */       RecordDetail comment = new RecordDetail(recordName, "Xml~Name", recordName, 6, "", "", "", fields1, 0, 0);
/*     */       
/*     */ 
/*     */ 
/* 178 */       RecordDetail[] r1 = { item, comment, null, null, null, null };
/* 179 */       recs = r1;
/*     */     }
/*     */     
/* 182 */     return new LayoutDetail("XML Document", recs, "", 6, null, null, "", null, 62);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 196 */     new ReMainFrame("Cobol CopyBook Analysis", "", "An");
/* 197 */     new DisplayCobolCopybook();
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/DisplayCobolCopybook.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */