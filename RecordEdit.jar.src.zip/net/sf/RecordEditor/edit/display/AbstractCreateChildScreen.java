package net.sf.RecordEditor.edit.display;

import net.sf.RecordEditor.edit.display.common.AbstractRowChangedListner;
import net.sf.RecordEditor.re.display.AbstractFileDisplay;

public abstract interface AbstractCreateChildScreen
  extends AbstractRowChangedListner
{
  public static final int CS_RIGHT = 1;
  public static final int CS_BOTTOM = 2;
  public static final int CS_BOTH = 3;
  public static final int CS_DEFAULT = 4;
  
  public abstract AbstractFileDisplay createChildScreen(int paramInt);
  
  public abstract void removeChildScreen();
  
  public abstract int getAvailableChildScreenPostion();
  
  public abstract int getCurrentChildScreenPostion();
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/AbstractCreateChildScreen.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */