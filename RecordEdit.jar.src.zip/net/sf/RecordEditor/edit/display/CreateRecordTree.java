/*     */ package net.sf.RecordEditor.edit.display;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.JButton;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.RecordEditor.jibx.compare.EditorTask;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*     */ import net.sf.RecordEditor.re.display.DisplayBuilderFactory;
/*     */ import net.sf.RecordEditor.re.display.IChildDisplay;
/*     */ import net.sf.RecordEditor.re.display.IUpdateExecute;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.re.script.CreateRecordTreePnl;
/*     */ import net.sf.RecordEditor.re.tree.TreeParserRecord;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CreateRecordTree
/*     */   extends ReFrame
/*     */   implements ActionListener, IChildDisplay, IUpdateExecute<EditorTask>
/*     */ {
/*     */   public final CreateRecordTreePnl treeDisplay;
/*     */   private AbstractLayoutDetails layout;
/*     */   private AbstractFileDisplay source;
/*     */   private FileView view;
/*     */   
/*     */   public CreateRecordTree(AbstractFileDisplay src, FileView fileView)
/*     */   {
/*  33 */     super(fileView.getFileNameNoDirectory(), "Create Record Tree", fileView.getBaseFile());
/*     */     
/*     */ 
/*  36 */     this.view = fileView;
/*  37 */     this.source = src;
/*  38 */     this.layout = this.view.getLayout();
/*     */     
/*  40 */     this.treeDisplay = new CreateRecordTreePnl(this.layout, true);
/*  41 */     addMainComponent(this.treeDisplay.getPanel());
/*     */     
/*  43 */     this.treeDisplay.execute.addActionListener(this);
/*     */     
/*  45 */     super.addMainComponent(this.treeDisplay.getPanel());
/*  46 */     setVisible(true);
/*  47 */     setToMaximum(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void actionPerformed(ActionEvent event)
/*     */   {
/* 110 */     Common.stopCellEditing(this.treeDisplay.recordTbl);
/*     */     
/* 112 */     doAction();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final AbstractFileDisplay doAction()
/*     */   {
/* 119 */     AbstractFileDisplay ret = null;
/* 120 */     this.treeDisplay.panel.setMessageRawTxtRE("");
/*     */     try
/*     */     {
/* 123 */       FileView newView = getNewView();
/*     */       
/* 125 */       if (newView == null) {
/* 126 */         this.treeDisplay.panel.setMessageTxtRE("No Records Selected");
/*     */       } else {
/* 128 */         Integer[] parent = this.treeDisplay.getParent();
/* 129 */         int[] parentIdxs = new int[parent.length];
/*     */         
/*     */ 
/* 132 */         for (int i = 0; i < parent.length; i++) {
/* 133 */           parentIdxs[i] = parent[i].intValue();
/*     */         }
/*     */         
/*     */ 
/* 137 */         TreeParserRecord parser = new TreeParserRecord(parentIdxs);
/*     */         
/* 139 */         ret = DisplayBuilderFactory.newLineTree(this.source.getParentFrame(), newView, parser, false, 0);
/*     */       }
/*     */       
/* 142 */       setClosed(true);
/*     */     } catch (Exception e) {
/* 144 */       this.treeDisplay.panel.setMessageRawTxtRE(e.getMessage());
/* 145 */       e.printStackTrace();
/*     */     }
/*     */     
/* 148 */     return ret;
/*     */   }
/*     */   
/*     */   protected final FileView getNewView()
/*     */   {
/* 153 */     return this.source.getFileView().getView();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void executeAction(int action)
/*     */   {
/* 163 */     if (action == 23) {
/* 164 */       this.treeDisplay.getPanel().showHelpRE();
/*     */     } else {
/* 166 */       super.executeAction(action);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isActionAvailable(int action)
/*     */   {
/* 178 */     return (action == 23) || (super.isActionAvailable(action));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractFileDisplay getSourceDisplay()
/*     */   {
/* 189 */     return this.source;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void update(EditorTask serialisedData)
/*     */   {
/* 200 */     this.treeDisplay.update(serialisedData);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setFromSavedDetails(EditorTask saveDetails)
/*     */   {
/* 211 */     this.treeDisplay.setFromSavedDetails(saveDetails);
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/CreateRecordTree.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */