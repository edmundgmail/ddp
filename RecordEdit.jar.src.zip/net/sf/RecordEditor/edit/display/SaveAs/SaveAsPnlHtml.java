/*     */ package net.sf.RecordEditor.edit.display.SaveAs;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JRadioButton;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.re.fileWriter.HtmlColors;
/*     */ import net.sf.RecordEditor.re.fileWriter.HtmlMultiTableWriter;
/*     */ import net.sf.RecordEditor.re.fileWriter.HtmlWriter;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SaveAsPnlHtml
/*     */   extends SaveAsPnlBase
/*     */ {
/*  31 */   private BasePanel htmlColorPnl = new BasePanel();
/*  32 */   private final ButtonGroup htmlColorGrp = new ButtonGroup();
/*  33 */   protected final JRadioButton whiteHtmlBtn = genHtmlColorBtn("White Background");
/*  34 */   protected final JRadioButton standardBtn = genHtmlColorBtn("Standard Colors");
/*  35 */   protected final JRadioButton dullBtn = genHtmlColorBtn("Dull colors");
/*  36 */   protected final JRadioButton colorfulHtmlBtn = genHtmlColorBtn("Colorfull Table");
/*     */   
/*  38 */   ChangeListener actL = new ChangeListener()
/*     */   {
/*     */     public void stateChanged(ChangeEvent e)
/*     */     {
/*  42 */       SaveAsPnlHtml.this.commonSaveAsFields.setVisibility(SaveAsPnlHtml.this.panelFormat, SaveAsPnlHtml.this.singleTable.isSelected());
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SaveAsPnlHtml(CommonSaveAsFields commonSaveAsFields)
/*     */   {
/*  53 */     super(commonSaveAsFields, ".html", 4, -1, null);
/*     */     
/*  55 */     BasePanel pnl1 = new BasePanel();
/*     */     
/*     */ 
/*  58 */     pnl1.addLineRE("Table Type:", this.singleTable);
/*  59 */     pnl1.addLineRE("", this.tablePerRow);
/*  60 */     pnl1.addLineRE("", this.treeTable);
/*  61 */     pnl1.setGapRE(BasePanel.GAP0);
/*  62 */     addHtmlFields(pnl1);
/*     */     
/*  64 */     this.htmlColorPnl.addLineRE("", this.whiteHtmlBtn);
/*  65 */     this.htmlColorPnl.addLineRE("", this.standardBtn);
/*  66 */     this.htmlColorPnl.addLineRE("", this.dullBtn);
/*  67 */     this.htmlColorPnl.addLineRE("", this.colorfulHtmlBtn);
/*  68 */     this.colorfulHtmlBtn.setSelected(true);
/*     */     
/*  70 */     pnl1.setBorder(BorderFactory.createLoweredBevelBorder());
/*  71 */     this.htmlColorPnl.setBorder(BorderFactory.createLoweredBevelBorder());
/*     */     
/*  73 */     this.panel.addComponentRE(1, 1, -1.0D, 0.0D, 2, 2, pnl1);
/*  74 */     this.panel.addComponentRE(3, 3, -1.0D, 0.0D, 2, 2, false, this.htmlColorPnl);
/*     */     
/*     */ 
/*  77 */     this.namesFirstLine.setSelected(true);
/*     */     
/*  79 */     this.singleTable.addChangeListener(this.actL);
/*  80 */     this.tablePerRow.addChangeListener(this.actL);
/*     */   }
/*     */   
/*     */ 
/*     */   public void save(String selection, String outFile)
/*     */     throws Exception
/*     */   {
/*  87 */     HtmlColors colors = HtmlColors.STANDARD_COLORS;
/*     */     
/*  89 */     if (this.whiteHtmlBtn.isSelected()) {
/*  90 */       colors = HtmlColors.BOORING_COLORS;
/*  91 */     } else if (this.colorfulHtmlBtn.isSelected()) {
/*  92 */       colors = HtmlColors.BRIGHT_COLORS;
/*  93 */     } else if (this.dullBtn.isSelected()) {
/*  94 */       colors = HtmlColors.MONEY_COLORS;
/*     */     }
/*     */     
/*     */     try
/*     */     {
/*  99 */       switch (getTableOption()) {
/*     */       case 1: 
/* 101 */         HtmlWriter w = new HtmlWriter(outFile, this.showBorder.isSelected(), colors, "File: " + this.commonSaveAsFields.file.getFileNameNoDirectory());
/*     */         
/*     */ 
/* 104 */         save_writeFile(w, selection);
/* 105 */         break;
/*     */       case 2: 
/* 107 */         multiTable(1, outFile, selection, colors);
/*     */         
/* 109 */         break;
/*     */       case 3: 
/* 111 */         multiTable(64205, outFile, selection, colors);
/*     */       }
/*     */     }
/*     */     catch (IOException e) {
/* 115 */       e.printStackTrace();
/* 116 */       Common.logMsg(30, "Writing HTML File failed:", e.getMessage(), null);
/*     */     }
/*     */   }
/*     */   
/*     */   private void multiTable(int writerId, String outFile, String selection, HtmlColors colors)
/*     */     throws IOException
/*     */   {
/* 123 */     boolean showText = !this.onlyData.isSelected();
/* 124 */     HtmlMultiTableWriter w1 = new HtmlMultiTableWriter(outFile, this.showBorder.isSelected(), showText, (showText) && (this.commonSaveAsFields.file.getLayout().isBinary()), colors, "File: " + this.commonSaveAsFields.file.getFileNameNoDirectory());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 129 */     SaveAsWrite.getWriter(writerId, this.commonSaveAsFields.file, this.commonSaveAsFields.getRecordFrame()).writeFile(w1, this.namesFirstLine.isSelected(), this.commonSaveAsFields.getWhatToSave(selection));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private JRadioButton genHtmlColorBtn(String s)
/*     */   {
/* 137 */     return generateRadioButton(this.htmlColorGrp, s);
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/SaveAs/SaveAsPnlHtml.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */