/*     */ package net.sf.RecordEditor.edit.display.SaveAs;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.net.URL;
/*     */ import java.net.URLClassLoader;
/*     */ import javax.swing.JTextField;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.Transformer;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions.FileNameOpt;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions.FileNameOptWithDefault;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions.StringOpt;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.FileSelectCombo;
/*     */ 
/*     */ public class SaveAsPnlXslt extends SaveAsPnlBase
/*     */ {
/*  23 */   private FileSelectCombo xsltJar1 = new FileSelectCombo("XsltJars.", 15, true, false);
/*     */   
/*  25 */   private FileSelectCombo xsltJar2 = new FileSelectCombo("XsltJars.", 15, true, false);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SaveAsPnlXslt(CommonSaveAsFields commonSaveAsFields)
/*     */   {
/*  34 */     super(commonSaveAsFields, ".xml", 6, 5, new FileSelectCombo("XsltFiles.", 25, true, false));
/*     */     
/*     */ 
/*     */ 
/*  38 */     this.panel.addLineRE("Xslt Engine (leave blank for default)", this.xsltTxt);
/*  39 */     this.panel.addLineRE("Xslt File", this.template);
/*  40 */     this.panel.setGapRE(net.sf.RecordEditor.utils.swing.BasePanel.GAP1);
/*     */     
/*  42 */     this.panel.addLineRE("Jars", this.xsltJar1);
/*  43 */     this.panel.addLineRE("", this.xsltJar2);
/*     */     
/*  45 */     this.xsltTxt.setText(Common.OPTIONS.XSLT_ENGINE.get());
/*     */     
/*  47 */     this.template.setText(Common.OPTIONS.DEFAULT_XSLT_DIRECTORY.get());
/*  48 */     this.xsltJar1.setText(Common.OPTIONS.XSLT_JAR1.get());
/*  49 */     this.xsltJar2.setText(Common.OPTIONS.XSLT_JAR2.get());
/*     */     
/*  51 */     this.template.addFcFocusListener(commonSaveAsFields.templateListner);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void save(String selection, String outFile)
/*     */     throws Exception
/*     */   {
/*  63 */     FileView view = this.commonSaveAsFields.getViewToSave(selection);
/*     */     
/*     */ 
/*  66 */     File tempFile = File.createTempFile("reXsltInput", ".xml");
/*  67 */     String xsltFileName = this.template.getText();
/*  68 */     String xsltClass = this.xsltTxt.getText();
/*     */     
/*     */ 
/*  71 */     view.writeFile(tempFile.getCanonicalPath());
/*     */     
/*  73 */     Source xmlSource = new StreamSource(tempFile);
/*  74 */     Source xsltSource = new StreamSource(xsltFileName);
/*  75 */     javax.xml.transform.Result result = new javax.xml.transform.stream.StreamResult(new File(outFile));
/*     */     
/*  77 */     Parameters.setSavePropertyChanges(false);
/*  78 */     Common.OPTIONS.XSLT_ENGINE.set(xsltClass);
/*  79 */     Common.OPTIONS.XSLT_JAR1.set(this.xsltJar1.getText());
/*  80 */     Parameters.setSavePropertyChanges(true);
/*  81 */     Common.OPTIONS.XSLT_JAR2.set(this.xsltJar2.getText());
/*     */     TransformerFactory transFact;
/*  83 */     TransformerFactory transFact; if ("".equals(xsltClass)) {
/*  84 */       transFact = TransformerFactory.newInstance();
/*     */     } else {
/*  86 */       ClassLoader classLoader = getClass().getClassLoader();
/*  87 */       String jar1 = this.xsltJar1.getText();
/*  88 */       String jar2 = this.xsltJar2.getText();
/*  89 */       if ("saxon".equalsIgnoreCase(xsltClass)) {
/*  90 */         xsltClass = "net.sf.saxon.TransformerFactoryImpl";
/*  91 */       } else if ("xalan".equalsIgnoreCase(xsltClass)) {
/*  92 */         xsltClass = "org.apache.xalan.processor.TransformerFactoryImpl";
/*     */       }
/*     */       
/*  95 */       if ((!"".equals(jar1)) || (!"".equals(jar2))) {
/*  96 */         int count = 2;
/*  97 */         String[] urlStr = { jar1, jar2 };
/*  98 */         int idx = 0;
/*  99 */         if (("".equals(jar1)) || ("".equals(jar2))) {
/* 100 */           count = 1;
/*     */         }
/* 102 */         URL[] urls = new URL[count];
/* 103 */         for (int i = 0; i < urlStr.length; i++) {
/* 104 */           if (!"".equals(urlStr[i])) {
/* 105 */             urls[(idx++)] = new File(urlStr[i]).toURI().toURL();
/*     */           }
/*     */         }
/*     */         
/* 109 */         classLoader = new URLClassLoader(urls);
/*     */       }
/* 111 */       transFact = TransformerFactory.newInstance(xsltClass, classLoader);
/*     */     }
/*     */     
/*     */ 
/* 115 */     Transformer trans = transFact.newTransformer(xsltSource);
/*     */     
/* 117 */     trans.transform(xmlSource, result);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isActive()
/*     */   {
/* 126 */     return Common.OPTIONS.xsltAvailable.isSelected();
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/SaveAs/SaveAsPnlXslt.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */