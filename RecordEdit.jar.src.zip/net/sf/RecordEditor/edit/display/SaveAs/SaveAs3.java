/*     */ package net.sf.RecordEditor.edit.display.SaveAs;
/*     */ 
/*     */ import java.awt.Desktop;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.FocusAdapter;
/*     */ import java.awt.event.FocusEvent;
/*     */ import java.awt.event.FocusListener;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.io.File;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JRadioButton;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTabbedPane;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*     */ import net.sf.RecordEditor.re.display.IChildDisplay;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.re.openFile.RecentFiles;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.params.BoolOpt;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions.FileNameOpt;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.FileSelectCombo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SaveAs3
/*     */   extends ReFrame
/*     */   implements ActionListener, IChildDisplay
/*     */ {
/*     */   public static final int FORMAT_DATA = 0;
/*     */   public static final int FORMAT_1_TABLE = 1;
/*     */   public static final int FORMAT_MULTI_TABLE = 2;
/*     */   public static final int FORMAT_TREE_HTML = 3;
/*     */   public static final int FORMAT_DELIMITED = 4;
/*     */   public static final int FORMAT_FIXED = 5;
/*     */   public static final int FORMAT_XML = 6;
/*     */   public static final int FORMAT_SCRIPT = 7;
/*     */   public static final int FORMAT_XSLT = 8;
/*     */   public static final int FORMAT_VELOCITY = 9;
/* 101 */   private static final int[] FORMAT_TRANSLATION = { 0, 4, 4, 4, 1, 2, 3, 5, 6, 7 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 106 */   private static int[] FORMAT_HTML_TRANSLATION = { -1, 1, 2, 3 };
/*     */   
/*     */ 
/*     */ 
/*     */   private CommonSaveAsFields commonSaveFields;
/*     */   
/*     */ 
/*     */ 
/*     */   private SaveAsPnlBase[] pnls;
/*     */   
/*     */ 
/*     */ 
/* 118 */   private BaseHelpPanel pnl = new BaseHelpPanel();
/* 119 */   private FileSelectCombo fileNameTxt = new FileSelectCombo("SaveAs.", 16, false, false, true);
/*     */   
/*     */ 
/*     */ 
/* 123 */   private JButton saveFile = SwingUtils.newButton("Save File", Common.getRecordIcon(2));
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 133 */   private JCheckBox openChk = new JCheckBox();
/*     */   
/* 135 */   private JTabbedPane formatTab = new JTabbedPane();
/*     */   
/*     */   private FileView file;
/*     */   
/*     */   private int currentIndex;
/*     */   
/*     */   private int currentType;
/*     */   
/* 143 */   private String currentExtension = null;
/*     */   
/* 145 */   private boolean usingTab = true; private boolean normalOpen = false; private boolean htmlOpen = true;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 150 */   private ChangeListener tabListner = new ChangeListener()
/*     */   {
/*     */ 
/*     */     public void stateChanged(ChangeEvent e)
/*     */     {
/* 155 */       int idx = SaveAs3.this.getTabIndex();
/*     */       
/* 157 */       if (SaveAs3.this.currentIndex != idx) {
/* 158 */         SaveAs3.this.changeExtension();
/*     */         
/* 160 */         SaveAs3.this.setVisibility();
/*     */       }
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 169 */   private KeyAdapter listner = new KeyAdapter()
/*     */   {
/*     */ 
/*     */     public final void keyReleased(KeyEvent event)
/*     */     {
/*     */ 
/* 175 */       switch (event.getKeyCode()) {
/* 176 */       case 10:  SaveAs3.this.saveFile(); break;
/* 177 */       case 27:  SaveAs3.this.doDefaultCloseAction();
/*     */       }
/*     */       
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SaveAs3(AbstractFileDisplay recordFrame, FileView fileView)
/*     */   {
/* 190 */     this(recordFrame, fileView, 0, "");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public SaveAs3(AbstractFileDisplay recordFrame, FileView fileView, int formatIdx, String script)
/*     */   {
/* 198 */     super(fileView.getFileNameNoDirectory(), (formatIdx <= 0) || (Common.OPTIONS.showAllExportPnls.isSelected()) ? "Export" : "Export1", fileView.getBaseFile());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 203 */     setDefaultCloseOperation(2);
/*     */     
/*     */ 
/* 206 */     FocusListener templateChg = new FocusAdapter()
/*     */     {
/*     */       public void focusLost(FocusEvent e)
/*     */       {
/* 210 */         SaveAs3.this.changeExtension();
/*     */       }
/*     */       
/*     */ 
/* 214 */     };
/* 215 */     this.commonSaveFields = new CommonSaveAsFields(recordFrame, fileView, templateChg);
/* 216 */     this.file = fileView;
/*     */     
/* 218 */     SaveAsPnlBase[] p = { new SaveAsPnlBasic.Data(this.commonSaveFields), new SaveAsPnlCsv(this.commonSaveFields), new SaveAsPnlFixed(this.commonSaveFields), new SaveAsPnlBasic.Xml(this.commonSaveFields), new SaveAsPnlHtml(this.commonSaveFields), new SaveAsPnlScript(this.commonSaveFields), new SaveAsPnlXslt(this.commonSaveFields), new SaveAsPnlVelocity(this.commonSaveFields), new SaveAsPnlFileStructure(this.commonSaveFields) };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 229 */     this.pnls = p;
/*     */     
/* 231 */     init_100_setupFields_GetPnlLength(formatIdx);
/*     */     
/* 233 */     init_200_SetupTabPnls(formatIdx, script);
/* 234 */     init_300_layoutScreen();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 239 */     super.addMainComponent(this.pnl);
/*     */     
/* 241 */     setVisible(true);
/*     */     
/*     */ 
/* 244 */     this.formatTab.addChangeListener(this.tabListner);
/* 245 */     this.pnl.addReKeyListener(this.listner);
/*     */     
/* 247 */     setToMaximum(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void init_100_setupFields_GetPnlLength(int formatType)
/*     */   {
/* 254 */     int saveAsId = FORMAT_TRANSLATION[formatType];
/* 255 */     int idx = 0;
/* 256 */     String fname = this.file.getFileName();
/* 257 */     if ("".equals(fname)) {
/* 258 */       fname = Common.OPTIONS.DEFAULT_FILE_DIRECTORY.get();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 270 */     this.currentIndex = saveAsId;
/* 271 */     this.currentType = this.pnls[saveAsId].panelFormat;
/*     */     
/* 273 */     for (int i = 0; i < this.pnls.length; i++) {
/* 274 */       this.pnls[i].onlyData.setSelected(!this.file.isBinaryFile());
/* 275 */       this.pnls[i].showBorder.setSelected(true);
/* 276 */       if (this.pnls[i].isActive()) {
/* 277 */         this.formatTab.add(this.pnls[i].getTitle(), this.pnls[i].panel);
/* 278 */         if (this.pnls[i].panelFormat == saveAsId) {
/* 279 */           this.currentIndex = idx;
/* 280 */           this.currentType = this.pnls[i].panelFormat;
/*     */         }
/* 282 */         this.pnls[idx] = this.pnls[i];
/* 283 */         idx++;
/*     */       }
/*     */     }
/* 286 */     setOpenChk();
/*     */     
/* 288 */     this.commonSaveFields.keepOpenChk.setSelected(false);
/* 289 */     this.commonSaveFields.editChk.setSelected(false);
/* 290 */     this.commonSaveFields.treeExportChk.setSelected(false);
/* 291 */     this.commonSaveFields.treeExportChk.setVisible(this.pnls[this.currentIndex].panelFormat == 1);
/* 292 */     this.commonSaveFields.nodesWithDataChk.setVisible(this.pnls[this.currentIndex].panelFormat == 1);
/* 293 */     this.commonSaveFields.nodesWithDataChk.setSelected(false);
/*     */     
/* 295 */     this.currentExtension = getExtension(this.currentIndex);
/* 296 */     this.fileNameTxt.setText(fname + this.currentExtension);
/*     */     
/*     */ 
/*     */ 
/* 300 */     this.saveFile.addActionListener(this);
/*     */   }
/*     */   
/*     */ 
/*     */   private void init_200_SetupTabPnls(int formatIdx, String script)
/*     */   {
/* 306 */     this.formatTab.setSelectedIndex(this.currentIndex);
/* 307 */     switch (formatIdx) {
/*     */     case 1: 
/*     */     case 2: 
/*     */     case 3: 
/* 311 */       getSelectedPnl().setTableOption(FORMAT_HTML_TRANSLATION[formatIdx]);
/*     */     }
/*     */     
/*     */     
/* 315 */     if ((script != null) && (!"".equals(script)) && (getSelectedPnl().template != null)) {
/* 316 */       getSelectedPnl().setTemplateText(script);
/* 317 */       changeExtension();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void init_300_layoutScreen()
/*     */   {
/* 324 */     this.pnl.addHelpBtnRE(SwingUtils.getHelpButton());
/*     */     
/* 326 */     this.pnl.setHelpURLre(Common.formatHelpURL("HlpRe07.htm"));
/* 327 */     this.pnl.addLineRE("File Name", this.fileNameTxt);
/* 328 */     this.pnl.addLineRE("What to Save", this.commonSaveFields.saveWhat);
/*     */     
/* 330 */     if (this.commonSaveFields.getTreeFrame() != null) {
/* 331 */       this.commonSaveFields.treeExportChk.setSelected(true);
/* 332 */       this.commonSaveFields.nodesWithDataChk.setSelected(false);
/*     */       
/*     */ 
/* 335 */       this.pnl.addLineRE("Export Tree", this.commonSaveFields.treeExportChk);
/* 336 */       this.pnl.addLineRE("Only export Nodes with Data", this.commonSaveFields.nodesWithDataChk);
/*     */       
/* 338 */       if (this.commonSaveFields.saveWhat.getItemCount() > 1) {
/* 339 */         this.commonSaveFields.saveWhat.addActionListener(new ActionListener()
/*     */         {
/*     */           public void actionPerformed(ActionEvent arg0)
/*     */           {
/* 343 */             SaveAs3.this.setVisibility();
/*     */           }
/*     */         });
/*     */       }
/*     */     }
/*     */     
/* 349 */     this.pnl.setGapRE(BasePanel.GAP1);
/*     */     
/* 351 */     if ((this.currentIndex < 1) || (this.currentIndex >= this.pnls.length) || (Common.OPTIONS.showAllExportPnls.isSelected())) {
/* 352 */       this.pnl.addLineRE("Output Format:", null);
/* 353 */       this.pnl.addComponentRE(1, 5, -1.0D, BasePanel.GAP, 2, 2, this.formatTab);
/*     */     }
/*     */     else
/*     */     {
/* 357 */       this.pnl.addComponentRE(0, 6, -1.0D, BasePanel.GAP, 2, 2, this.pnls[this.currentIndex].panel);
/*     */       
/*     */ 
/* 360 */       this.pnls[this.currentIndex].panel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createRaisedBevelBorder(), this.pnls[this.currentIndex].getTitle() + " Options : "));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 365 */       this.usingTab = false;
/*     */     }
/*     */     
/* 368 */     this.pnl.setGapRE(BasePanel.GAP1);
/* 369 */     this.pnl.addLineRE("Edit Output File", this.commonSaveFields.editChk);
/* 370 */     if (isDesktopAvailable()) {
/* 371 */       this.pnl.addLineRE("Open Output File", this.openChk);
/*     */     }
/* 373 */     this.pnl.addLineRE("Keep screen open", this.commonSaveFields.keepOpenChk, this.saveFile);
/* 374 */     this.pnl.setGapRE(BasePanel.GAP1);
/* 375 */     this.pnl.addMessage(new JScrollPane(this.commonSaveFields.message));
/* 376 */     this.pnl.setHeightRE(BasePanel.GAP5);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void actionPerformed(ActionEvent event)
/*     */   {
/* 417 */     saveFile();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void saveFile()
/*     */   {
/* 425 */     String outFile = this.fileNameTxt.getText();
/*     */     
/*     */ 
/* 428 */     if (outFile.equals("")) {
/* 429 */       this.commonSaveFields.message.setText(LangConversion.convert("Please Enter a file name"));
/* 430 */       return;
/*     */     }
/* 432 */     SaveAsPnlBase activePnl = getSelectedPnl();
/* 433 */     String selection = this.commonSaveFields.saveWhat.getSelectedItem().toString();
/* 434 */     String ext = "";
/*     */     try
/*     */     {
/* 437 */       int lastDot = outFile.lastIndexOf('.');
/* 438 */       ext = outFile.substring(lastDot);
/* 439 */       if ((activePnl.extensionType >= 0) && (lastDot > 0)) {
/* 440 */         RecentFiles.getLast().putFileExtension(activePnl.extensionType, activePnl.template.getText(), ext, activePnl.extension);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 446 */       activePnl.save(selection, outFile);
/*     */       
/* 448 */       if (this.commonSaveFields.editChk.isSelected()) {
/* 449 */         activePnl.edit(outFile, ext);
/*     */       }
/*     */       
/* 452 */       if ((this.openChk.isSelected()) && 
/* 453 */         (isDesktopAvailable())) {
/* 454 */         Desktop desktop = Desktop.getDesktop();
/*     */         
/* 456 */         desktop.open(new File(outFile));
/*     */       }
/*     */       
/*     */ 
/* 460 */       if (!this.commonSaveFields.keepOpenChk.isSelected()) {
/* 461 */         this.formatTab.removeChangeListener(this.tabListner);
/* 462 */         setVisible(false);
/* 463 */         doDefaultCloseAction();
/*     */       }
/*     */     } catch (Exception e) {
/* 466 */       e.printStackTrace();
/* 467 */       this.commonSaveFields.message.setText(LangConversion.convert("Error:") + " " + e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isDesktopAvailable()
/*     */   {
/* 473 */     boolean ret = false;
/*     */     try
/*     */     {
/* 476 */       ret = Desktop.isDesktopSupported();
/*     */     }
/*     */     catch (Exception e) {}
/*     */     
/*     */ 
/* 481 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */   private SaveAsPnlBase getSelectedPnl()
/*     */   {
/* 487 */     return this.pnls[getTabIndex()];
/*     */   }
/*     */   
/*     */ 
/*     */   private void setVisibility()
/*     */   {
/* 493 */     SaveAsPnlBase pnl = getSelectedPnl();
/*     */     
/* 495 */     this.commonSaveFields.setVisibility(pnl.panelFormat, pnl.singleTable.isSelected());
/*     */   }
/*     */   
/*     */   private void changeExtension() {
/* 499 */     String s = this.fileNameTxt.getText();
/* 500 */     int idx = getTabIndex();
/* 501 */     String newExtension = getExtension(idx);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 507 */     if ((this.currentExtension != null) && (s.endsWith(this.currentExtension)) && (!this.currentExtension.equals(newExtension)))
/*     */     {
/*     */ 
/* 510 */       this.fileNameTxt.setText(s.substring(0, s.length() - this.currentExtension.length()) + newExtension);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 516 */     if (this.currentType == 4) {
/* 517 */       this.htmlOpen = this.openChk.isSelected();
/*     */     } else {
/* 519 */       this.normalOpen = this.openChk.isSelected();
/*     */     }
/* 521 */     this.currentIndex = idx;
/* 522 */     this.currentType = this.pnls[idx].panelFormat;
/* 523 */     this.currentExtension = newExtension;
/* 524 */     setOpenChk();
/*     */   }
/*     */   
/*     */   private void setOpenChk()
/*     */   {
/* 529 */     if (this.pnls[this.currentIndex].panelFormat == 4) {
/* 530 */       this.openChk.setSelected(this.htmlOpen);
/*     */     } else {
/* 532 */       this.openChk.setSelected(this.normalOpen);
/*     */     }
/*     */   }
/*     */   
/*     */   private int getTabIndex() {
/* 537 */     int idx = this.currentIndex;
/* 538 */     if (this.usingTab) {
/* 539 */       idx = this.formatTab.getSelectedIndex();
/*     */     }
/* 541 */     return idx;
/*     */   }
/*     */   
/*     */   private String getExtension(int idx) {
/* 545 */     if (this.pnls[idx].template == null) {
/* 546 */       return this.pnls[idx].extension;
/*     */     }
/* 548 */     return RecentFiles.getLast().getFileExtension(this.pnls[idx].extensionType, this.pnls[idx].template.getText(), this.pnls[idx].extension);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractFileDisplay getSourceDisplay()
/*     */   {
/* 560 */     return this.commonSaveFields.getRecordFrame();
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/SaveAs/SaveAs3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */