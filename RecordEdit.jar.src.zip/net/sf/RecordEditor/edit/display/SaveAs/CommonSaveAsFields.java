/*     */ package net.sf.RecordEditor.edit.display.SaveAs;
/*     */ 
/*     */ import java.awt.event.FocusListener;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JTextArea;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*     */ import net.sf.RecordEditor.re.file.AbstractTreeFrame;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ 
/*     */ 
/*     */ public final class CommonSaveAsFields
/*     */ {
/*  16 */   public static final String OPT_FILE = LangConversion.convertComboItms("File SelectionOptions", "File");
/*  17 */   public static final String OPT_VIEW = LangConversion.convertComboItms("File SelectionOptions", "Current View");
/*  18 */   public static final String OPT_SELECTED = LangConversion.convertComboItms("File SelectionOptions", "Selected Records");
/*     */   
/*     */   public static final int FMT_DATA = 0;
/*     */   
/*     */   public static final int FMT_CSV = 1;
/*     */   
/*     */   public static final int FMT_FIXED = 2;
/*     */   public static final int FMT_XML = 3;
/*     */   public static final int FMT_HTML = 4;
/*     */   public static final int FMT_SCRIPT = 5;
/*     */   public static final int FMT_XSLT = 6;
/*     */   public static final int FMT_VELOCITY = 7;
/*     */   public static final int FMT_FILE_STRUCTURE = 8;
/*  31 */   public final JComboBox saveWhat = new JComboBox();
/*     */   
/*  33 */   public final JCheckBox treeExportChk = new JCheckBox(); public final JCheckBox nodesWithDataChk = new JCheckBox(); public final JCheckBox keepOpenChk = new JCheckBox(); public final JCheckBox editChk = new JCheckBox();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  38 */   public final JTextArea message = new JTextArea();
/*     */   
/*     */   public final FileView file;
/*     */   
/*     */   public final SaveAsWrite flatFileWriter;
/*     */   public final FocusListener templateListner;
/*     */   private final AbstractFileDisplay recordFrame;
/*  45 */   private AbstractTreeFrame treeFrame = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AbstractRecordDetail printRecordDetails;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AbstractFileDisplay getRecordFrame()
/*     */   {
/*  58 */     return this.recordFrame;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected CommonSaveAsFields(AbstractFileDisplay recordFrame, FileView file, FocusListener templateListner)
/*     */   {
/*  67 */     this.recordFrame = recordFrame;
/*  68 */     this.file = file;
/*  69 */     this.templateListner = templateListner;
/*     */     
/*  71 */     int[] selected = recordFrame.getSelectedRows();
/*     */     
/*  73 */     this.treeFrame = null;
/*  74 */     if ((recordFrame instanceof AbstractTreeFrame)) {
/*  75 */       this.treeFrame = ((AbstractTreeFrame)recordFrame);
/*     */     }
/*  77 */     this.flatFileWriter = SaveAsWrite.getWriter(file, getRecordFrame());
/*     */     
/*  79 */     if (file.isView()) {
/*  80 */       this.saveWhat.addItem(OPT_VIEW);
/*     */     }
/*  82 */     this.saveWhat.addItem(OPT_FILE);
/*     */     
/*  84 */     if ((selected != null) && (selected.length > 0)) {
/*  85 */       this.saveWhat.addItem(OPT_SELECTED);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AbstractTreeFrame getTreeFrame()
/*     */   {
/*  95 */     return this.treeFrame;
/*     */   }
/*     */   
/*     */   public final int getWhatToSave(String selection)
/*     */   {
/* 100 */     int whatToSave = 3;
/* 101 */     if (OPT_FILE.equals(selection)) {
/* 102 */       whatToSave = 1;
/* 103 */     } else if (OPT_VIEW.equals(selection)) {
/* 104 */       whatToSave = 2;
/*     */     }
/* 106 */     return whatToSave;
/*     */   }
/*     */   
/*     */   public final FileView getViewToSave(String selection)
/*     */   {
/* 111 */     return getViewToSave(getWhatToSave(selection));
/*     */   }
/*     */   
/*     */   public final FileView getViewToSave(int whatToSave)
/*     */   {
/* 116 */     FileView ret = null;
/* 117 */     switch (whatToSave) {
/* 118 */     case 3:  ret = this.file.getView(this.recordFrame.getSelectedRows()); break;
/* 119 */     case 1:  ret = this.file.getBaseFile(); break;
/* 120 */     case 2:  ret = this.file;
/*     */     }
/*     */     
/* 123 */     return ret;
/*     */   }
/*     */   
/*     */   public final void setVisibility(int pnlFormat, boolean singleTable)
/*     */   {
/* 128 */     boolean visible = ((pnlFormat == 1) || (pnlFormat == 2) || ((pnlFormat == 4) && (singleTable)) || ((pnlFormat == 3) && (getTreeFrame() != null))) && ((this.saveWhat.getItemCount() == 1) || (OPT_VIEW.equals(this.saveWhat.getSelectedItem())) || ((OPT_FILE.equals(this.saveWhat.getSelectedItem())) && (!this.file.isView())));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 141 */     this.treeExportChk.setVisible(visible);
/* 142 */     this.nodesWithDataChk.setVisible((visible) && (pnlFormat != 3));
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/SaveAs/CommonSaveAsFields.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */