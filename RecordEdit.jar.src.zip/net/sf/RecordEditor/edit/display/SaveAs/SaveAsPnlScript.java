/*    */ package net.sf.RecordEditor.edit.display.SaveAs;
/*    */ 
/*    */ import java.awt.event.FocusListener;
/*    */ import java.util.List;
/*    */ import javax.swing.JComboBox;
/*    */ import javax.swing.event.ChangeEvent;
/*    */ import javax.swing.event.ChangeListener;
/*    */ import net.sf.RecordEditor.re.script.ScriptMgr;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ import net.sf.RecordEditor.utils.params.Parameters;
/*    */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*    */ import net.sf.RecordEditor.utils.params.ProgramOptions.FileNameOptWithDefault;
/*    */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*    */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*    */ import net.sf.RecordEditor.utils.swing.treeCombo.FileSelectCombo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SaveAsPnlScript
/*    */   extends SaveAsPnlBase
/*    */ {
/* 23 */   private JComboBox languageCombo = new JComboBox(ScriptMgr.getLanguages().toArray(new String[ScriptMgr.getLanguages().size()]));
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 28 */   private ScriptMgr scriptMgr = new ScriptMgr();
/*    */   
/*    */ 
/*    */ 
/*    */   public SaveAsPnlScript(CommonSaveAsFields commonSaveAsFields)
/*    */   {
/* 34 */     super(commonSaveAsFields, ".txt", 5, 6, new FileSelectCombo("SaveScripts.", 25, true, false));
/*    */     
/*    */ 
/*    */ 
/* 38 */     this.template.setText(Common.OPTIONS.DEFAULT_SCRIPT_EXPORT_DIRECTORY.get());
/*    */     
/* 40 */     this.panel.addLineRE("Script Language", this.languageCombo).setGapRE(BasePanel.GAP2);
/*    */     
/* 42 */     this.panel.addLineRE("Script", this.template).setGapRE(BasePanel.GAP2);
/*    */     
/*    */ 
/* 45 */     addHtmlFields(this.panel);
/*    */     
/* 47 */     this.template.addTextChangeListner(new ChangeListener() {
/*    */       public void stateChanged(ChangeEvent e) {
/* 49 */         SaveAsPnlScript.this.checkLanguage();
/*    */         
/* 51 */         SaveAsPnlScript.this.commonSaveAsFields.templateListner.focusLost(null);
/*    */       }
/*    */     });
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setTemplateText(String text)
/*    */   {
/* 62 */     super.setTemplateText(text);
/* 63 */     checkLanguage();
/*    */   }
/*    */   
/*    */   private void checkLanguage()
/*    */   {
/*    */     try {
/* 69 */       String ext = Parameters.getExtensionOnly(this.template.getText());
/*    */       
/* 71 */       String lang = this.scriptMgr.getEngineNameByExtension(ext);
/*    */       
/* 73 */       if (!"".equals(lang)) {
/* 74 */         this.languageCombo.setSelectedItem(lang);
/*    */       }
/*    */     }
/*    */     catch (Exception e2) {}
/*    */   }
/*    */   
/*    */ 
/*    */   public void save(String selection, String outFile)
/*    */     throws Exception
/*    */   {
/* 84 */     new ScriptMgr().runScript(this.languageCombo.getSelectedItem().toString(), this.template.getText(), getScriptData(selection, outFile));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isActive()
/*    */   {
/* 97 */     return this.languageCombo.getItemCount() > 0;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/SaveAs/SaveAsPnlScript.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */