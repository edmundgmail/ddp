/*     */ package net.sf.RecordEditor.edit.display.SaveAs;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.sf.JRecord.Details.AbstractChildDetails;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.JRecord.Details.AbstractTreeDetails;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*     */ import net.sf.RecordEditor.re.file.AbstractLineNode;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.re.fileWriter.FieldWriter;
/*     */ 
/*     */ public abstract class SaveAsWrite
/*     */ {
/*     */   public static final int HTML_TREE_PRINT = -1331;
/*     */   public static final int SAVE_FILE = 1;
/*     */   public static final int SAVE_VIEW = 2;
/*     */   public static final int SAVE_SELECTED = 3;
/*     */   protected AbstractLayoutDetails layout;
/*     */   protected FileView file;
/*     */   protected AbstractFileDisplay recFrame;
/*     */   protected int layoutIdx;
/*     */   private int levelCount;
/*     */   private int firstLevel;
/*     */   private int maximumFieldCount;
/*     */   private FieldWriter writer;
/*     */   private boolean printAllNodes;
/*     */   private ArrayList<String> levels;
/*     */   protected final ArrayList<String> columnNames;
/*     */   private int maxFields;
/*     */   
/*     */   public static SaveAsWrite getWriter(FileView file, AbstractFileDisplay recFrame)
/*     */   {
/*  37 */     return getWriter(net.sf.RecordEditor.re.file.DisplayType.displayTypePrint(file.getLayout(), recFrame.getLayoutIndex()), file, recFrame);
/*     */   }
/*     */   
/*     */   public static SaveAsWrite getWriter(int type, FileView file, AbstractFileDisplay recFrame)
/*     */   {
/*  42 */     AbstractLayoutDetails layout = file.getLayout();
/*  43 */     SaveAsWrite ret; switch (type) {
/*     */     case 1: 
/*  45 */       ret = new WritePreferedLayout(null);
/*  46 */       break;
/*     */     case 2: 
/*  48 */       ret = new WriteFullLine(null);
/*  49 */       break;
/*     */     case 3: 
/*  51 */       ret = new WriteHexLine(null);
/*  52 */       break;
/*     */     case -1331: 
/*  54 */       ret = new WriteTree(null);
/*  55 */       break;
/*     */     default: 
/*  57 */       ret = new WriteFromLayout(null);
/*     */     }
/*     */     
/*  60 */     ret.layout = layout;
/*  61 */     ret.layoutIdx = recFrame.getLayoutIndex();
/*  62 */     ret.file = file;
/*  63 */     ret.recFrame = recFrame;
/*     */     
/*  65 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SaveAsWrite()
/*     */   {
/*  74 */     this.firstLevel = 0;this.maximumFieldCount = 0;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  79 */     this.levels = new ArrayList();
/*  80 */     this.columnNames = new ArrayList();
/*     */   }
/*     */   
/*     */ 
/*     */   public final void writeFile(FieldWriter writer, boolean namesOnFirstLine, int saveWhat)
/*     */     throws IOException
/*     */   {
/*  87 */     this.writer = writer;
/*  88 */     writeAFile(writer, getViewToSave(saveWhat), this.layoutIdx, namesOnFirstLine);
/*     */     
/*  90 */     writer.close();
/*     */   }
/*     */   
/*     */   public final FileView getViewToSave(int whatToSave)
/*     */   {
/*  95 */     FileView ret = null;
/*  96 */     switch (whatToSave) {
/*  97 */     case 3:  ret = this.file.getView(this.recFrame.getSelectedRows()); break;
/*  98 */     case 1:  ret = this.file.getBaseFile(); break;
/*  99 */     case 2:  ret = this.file;
/*     */     }
/*     */     
/* 102 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public List<String> getColumnNames()
/*     */   {
/* 109 */     return this.columnNames;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void writeAFile(FieldWriter writer, FileView view, int layoutIdx, boolean namesFirstLine)
/*     */     throws IOException
/*     */   {
/* 118 */     this.writer = writer;
/*     */     
/* 120 */     this.columnNames.clear();
/* 121 */     allocateColumnNames(this.file, layoutIdx);
/*     */     
/* 123 */     if (namesFirstLine) {
/* 124 */       writeColumnHeadings();
/*     */     }
/*     */     
/* 127 */     for (int i = 0; i < view.getRowCount(); i++) {
/* 128 */       writeLine(writer, view.getLine(i));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void writeLine(FieldWriter writer, AbstractLine line, int count)
/*     */     throws IOException
/*     */   {
/* 138 */     writeLine(writer, line);
/*     */   }
/*     */   
/*     */   protected final void writeLine(FieldWriter writer, AbstractLine line, int idx, int fieldCount) throws IOException
/*     */   {
/* 143 */     if (line != null) {
/* 144 */       for (int j = 0; j < fieldCount; j++) {
/*     */         try {
/* 146 */           writer.writeFieldDetails(this.layout.getRecord(idx).getField(j), getValue(line.getField(idx, j)), getValue(line.getFieldText(idx, j)), getValue(line.getFieldHex(idx, j)));
/*     */         }
/*     */         catch (Exception e) {}
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 156 */       if (writer.printAllFields()) {
/* 157 */         for (int i = fieldCount; i < this.maxFields; i++) {
/* 158 */           writer.writeField("");
/*     */         }
/*     */       }
/* 161 */     } else if (writer.printAllFields()) {
/* 162 */       for (int i = 0; i < this.maxFields; i++) {
/* 163 */         writer.writeField("");
/*     */       }
/*     */     }
/* 166 */     writer.newLine();
/*     */   }
/*     */   
/*     */   private String getValue(Object o) {
/* 170 */     String s = null;
/* 171 */     if (o != null) {
/* 172 */       s = o.toString();
/*     */     }
/*     */     
/* 175 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean[] getFieldsToInclude()
/*     */   {
/* 188 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeTree(FieldWriter writer, AbstractLineNode root, boolean namesOnFirstLine, boolean printAllNodes, int layoutIdx)
/*     */   {
/* 196 */     this.writer = writer;
/* 197 */     this.printAllNodes = printAllNodes;
/* 198 */     this.layout = root.getLayout();
/*     */     
/*     */ 
/* 201 */     ArrayList<Integer> levelSizes = new ArrayList(this.layout.getRecordCount() + 1);
/*     */     
/*     */ 
/* 204 */     this.levelCount = countLevels(levelSizes, root, 0);
/*     */     
/* 206 */     if ((root.getLine() == null) && ("File".equals(root.toString()))) {
/* 207 */       this.firstLevel = 1;
/*     */     }
/*     */     
/*     */ 
/* 211 */     int[] prefixLen = new int[this.levelCount - this.firstLevel];
/* 212 */     this.columnNames.clear();
/*     */     
/* 214 */     for (int i = this.firstLevel; i < this.levelCount; i++) {
/* 215 */       String s = "Level_" + (i - this.firstLevel + 1);
/* 216 */       this.columnNames.add(s);
/* 217 */       prefixLen[(i - this.firstLevel)] = ((Integer)levelSizes.get(i)).intValue();
/* 218 */       if ((namesOnFirstLine) && (s.length() > prefixLen[(i - this.firstLevel)])) {
/* 219 */         prefixLen[(i - this.firstLevel)] = s.length();
/*     */       }
/*     */     }
/*     */     
/* 223 */     if (this.layout.isXml()) {
/* 224 */       writer.setPrintField(this.layout.getRecord(0).getFieldIndex("Xml~Name"), false);
/* 225 */       writer.setPrintField(this.layout.getRecord(0).getFieldIndex("Xml~End"), false);
/*     */     }
/*     */     
/*     */ 
/* 229 */     writer.setupInitialFields(this.levelCount - this.firstLevel, prefixLen);
/* 230 */     allocateColumnNames(this.file, layoutIdx);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 236 */     if (namesOnFirstLine) {
/*     */       try {
/* 238 */         writeColumnHeadings();
/*     */       } catch (Exception e) {
/* 240 */         e.printStackTrace();
/* 241 */         net.sf.RecordEditor.utils.common.Common.logMsg(30, "Error Writing Column Headings:", e.getMessage(), e);
/*     */       }
/*     */     }
/*     */     
/* 245 */     printTree(root);
/*     */     try
/*     */     {
/* 248 */       writer.close();
/*     */     } catch (Exception e) {
/* 250 */       net.sf.RecordEditor.utils.common.Common.logMsg(30, "Error Closing File:", e.getClass().getName() + " " + e.getMessage(), null);
/* 251 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */   private int countLevels(List<Integer> levelSizes, AbstractLineNode node, int lvl) {
/* 256 */     int ret = lvl + 1;
/*     */     
/* 258 */     AbstractLine line = node.getLine();
/*     */     int len;
/* 260 */     int len; if ((node == null) || (node.toString() == null)) {
/* 261 */       len = 4;
/*     */     } else {
/* 263 */       len = node.toString().length();
/*     */     }
/* 265 */     if (levelSizes.size() <= lvl) {
/* 266 */       levelSizes.add(Integer.valueOf(len));
/* 267 */     } else if (len > ((Integer)levelSizes.get(lvl)).intValue()) {
/* 268 */       levelSizes.set(lvl, Integer.valueOf(len));
/*     */     }
/*     */     
/* 271 */     if (line != null) {
/* 272 */       this.maximumFieldCount = Math.max(this.maximumFieldCount, this.layout.getRecord(line.getPreferredLayoutIdx()).getFieldCount());
/*     */     }
/* 274 */     for (int i = 0; i < node.getChildCount(); i++) {
/* 275 */       ret = Math.max(ret, countLevels(levelSizes, (AbstractLineNode)node.getChildAt(i), lvl + 1));
/*     */     }
/*     */     
/* 278 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getMaximumFieldCount()
/*     */   {
/* 287 */     return this.maximumFieldCount;
/*     */   }
/*     */   
/*     */ 
/*     */   private void printTree(AbstractLineNode node)
/*     */   {
/* 293 */     boolean hasData = false;
/* 294 */     AbstractLine line = node.getLine();
/*     */     
/* 296 */     int fieldCount = 0;
/* 297 */     int prefIdx = 0;
/*     */     
/* 299 */     this.levels.add(node.toString());
/*     */     
/* 301 */     if (line != null) {
/* 302 */       prefIdx = line.getPreferredLayoutIdx();
/* 303 */       fieldCount = this.layout.getRecord(prefIdx).getFieldCount();
/*     */       
/* 305 */       for (int i = 0; i < fieldCount; i++) {
/* 306 */         Object o = line.getField(prefIdx, i);
/* 307 */         if ((o != null) && (!"".equals(o.toString().trim())) && (includeField(prefIdx, i))) {
/* 308 */           hasData = true;
/* 309 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 314 */     if ((this.printAllNodes) || (hasData)) {
/*     */       try {
/* 316 */         for (int i = this.firstLevel; i < this.levels.size(); i++) {
/* 317 */           this.writer.writeField((String)this.levels.get(i));
/*     */         }
/* 319 */         for (int i = this.levels.size(); i < this.levelCount; i++) {
/* 320 */           this.writer.writeField("");
/*     */         }
/*     */         
/* 323 */         writeLine(this.writer, line, fieldCount);
/*     */ 
/*     */ 
/*     */ 
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 333 */         net.sf.RecordEditor.utils.common.Common.logMsg(30, "Write Failed", e.getClass().getName() + " " + e.getMessage(), null);
/* 334 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */     
/* 338 */     for (int i = 0; i < node.getChildCount(); i++) {
/* 339 */       printTree((AbstractLineNode)node.getChildAt(i));
/*     */     }
/*     */     
/* 342 */     this.levels.remove(this.levels.size() - 1);
/*     */   }
/*     */   
/*     */   private boolean includeField(int prefIdx, int fieldIdx) {
/* 346 */     String field = this.layout.getRecord(prefIdx).getField(fieldIdx).getName();
/* 347 */     return (!this.layout.isXml()) || ((!"Xml~Name".equalsIgnoreCase(field)) && (!"Xml~End".equalsIgnoreCase(field)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLevelCount()
/*     */   {
/* 356 */     return this.levelCount - this.firstLevel;
/*     */   }
/*     */   
/*     */   protected void allocateColumnNames(FileView fieldMapping, int idx) {
/* 360 */     AbstractRecordDetail rec = this.layout.getRecord(idx);
/* 361 */     int colCount = rec.getFieldCount();
/*     */     
/* 363 */     this.maxFields = 0;
/*     */     
/* 365 */     for (int i = 0; i < this.layout.getRecordCount(); i++) {
/* 366 */       this.maxFields = Math.max(this.maxFields, this.layout.getRecord(i).getFieldCount());
/*     */     }
/* 368 */     for (int i = this.maxFields; i >= 0; i--) {
/* 369 */       if (!this.writer.isFieldToBePrinted(i)) {
/* 370 */         this.maxFields -= 1;
/*     */       }
/*     */     }
/*     */     
/* 374 */     for (int i = 0; i < colCount; i++) {
/* 375 */       int layoutFieldNo = i;
/* 376 */       if (this.writer.isFieldToBePrinted(layoutFieldNo + this.levelCount - this.firstLevel)) {
/* 377 */         this.columnNames.add(rec.getField(layoutFieldNo).getName());
/*     */       }
/*     */     }
/* 380 */     for (int i = colCount; i < this.maxFields; i++) {
/* 381 */       this.columnNames.add("Field_" + i);
/*     */     }
/*     */   }
/*     */   
/*     */   protected final void writeColumnHeadings() throws IOException {
/* 386 */     int st = 0;
/* 387 */     for (String s : this.columnNames) {
/* 388 */       while (!this.writer.isFieldToBePrinted(st++)) {
/* 389 */         this.writer.writeFieldHeading("");
/*     */       }
/* 391 */       this.writer.writeFieldHeading(s);
/*     */     }
/* 393 */     this.writer.newLine();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void writeLine(FieldWriter paramFieldWriter, AbstractLine paramAbstractLine)
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class WriteFromLayout
/*     */     extends SaveAsWrite
/*     */   {
/*     */     int colCount;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     protected void writeAFile(FieldWriter writer, FileView view, int layoutIdx, boolean namesFirstLine)
/*     */       throws IOException
/*     */     {
/* 428 */       this.colCount = this.layout.getRecord(layoutIdx).getFieldCount();
/* 429 */       boolean[] numeric = new boolean[this.colCount];
/*     */       
/* 431 */       for (int i = 0; i < this.colCount; i++) {
/* 432 */         numeric[i] = false;
/*     */       }
/*     */       
/* 435 */       if (layoutIdx < this.layout.getRecordCount())
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 440 */         int toCheck = Math.min(view.getRowCount(), 90);
/* 441 */         int rt = -121;
/* 442 */         if (this.layout.getRecord(layoutIdx) != null) {
/* 443 */           rt = this.layout.getRecord(layoutIdx).getRecordType();
/*     */         }
/* 445 */         boolean isCsv = (this.layout.isBinCSV()) || (this.layout.getFileStructure() == 51) || (rt == 2) || (rt == 3);
/*     */         
/*     */ 
/*     */ 
/* 449 */         for (int i = 0; i < this.colCount; i++) {
/* 450 */           numeric[i] = (this.layout.getRecord(layoutIdx).getFieldsNumericType(i) == 21 ? 1 : false);
/* 451 */           if ((numeric[i] == 0) && (isCsv) && (toCheck > 3)) {
/* 452 */             boolean onlyNumeric = true;
/* 453 */             boolean aNumeric = false;
/* 454 */             for (int j = 1; j < toCheck; j++) {
/* 455 */               Object o = view.getValueAt(j, i);
/* 456 */               if ((o != null) && (!"".equals(o.toString().trim())))
/*     */               {
/*     */                 try
/*     */                 {
/* 460 */                   new java.math.BigDecimal(o.toString().trim());
/* 461 */                   aNumeric = true;
/*     */                 } catch (Exception e) {
/* 463 */                   onlyNumeric = false;
/* 464 */                   break;
/*     */                 }
/*     */               }
/*     */             }
/*     */             
/* 469 */             numeric[i] = ((aNumeric) && (onlyNumeric) ? 1 : false);
/*     */           }
/*     */         }
/* 472 */         writer.setNumericFields(numeric);
/*     */       }
/*     */       
/* 475 */       super.writeAFile(writer, view, layoutIdx, namesFirstLine);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     protected void writeLine(FieldWriter writer, AbstractLine line)
/*     */       throws IOException
/*     */     {
/* 483 */       writeLine(writer, line, this.layoutIdx, this.colCount);
/*     */     }
/*     */     
/*     */     protected void writeLine(FieldWriter writer, AbstractLine line, int fieldCount) throws IOException
/*     */     {
/* 488 */       writeLine(writer, line, this.layoutIdx, fieldCount);
/*     */     }
/*     */     
/*     */     public boolean[] getFieldsToInclude() {
/* 492 */       boolean[] t = this.file.getFieldVisibility(this.layoutIdx);
/* 493 */       boolean[] ret = t;
/* 494 */       int maxFlds = net.sf.RecordEditor.re.file.DisplayType.getMaxFields(this.layout);
/* 495 */       if (((this.layout.isXml()) || (this.layout.hasChildren())) && (t != null) && (maxFlds > t.length))
/*     */       {
/* 497 */         ret = new boolean[maxFlds];
/*     */         
/* 499 */         System.arraycopy(t, 0, ret, 0, t.length);
/* 500 */         for (int i = t.length; i < ret.length; i++) {
/* 501 */           ret[i] = false;
/*     */         }
/*     */       }
/* 504 */       return ret;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class WritePreferedLayout
/*     */     extends SaveAsWrite
/*     */   {
/*     */     protected void allocateColumnNames(FileView fieldMapping, int index)
/*     */     {
/* 517 */       int idx = 0;
/*     */       
/* 519 */       if (this.layout.getRecordCount() > 1) {
/* 520 */         int[] counts = new int[this.layout.getRecordCount()];
/* 521 */         for (int i = 0; i < counts.length; i++) {
/* 522 */           counts[i] = 0;
/*     */         }
/* 524 */         for (int i = 0; i < fieldMapping.getRowCount(); i++) {
/* 525 */           counts[fieldMapping.getLine(i).getPreferredLayoutIdx()] += 1;
/*     */         }
/*     */         
/* 528 */         for (int i = 1; i < counts.length; i++) {
/* 529 */           if (counts[i] > counts[idx]) {
/* 530 */             idx = i;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 536 */       super.allocateColumnNames(fieldMapping, idx);
/*     */     }
/*     */     
/*     */     protected void writeLine(FieldWriter writer, AbstractLine line)
/*     */       throws IOException
/*     */     {
/* 542 */       if (line == null) {
/* 543 */         writeNullLine(writer);
/*     */       } else {
/* 545 */         int idx = line.getPreferredLayoutIdx();
/* 546 */         writeLine(writer, line, idx, this.layout.getRecord(idx).getFieldCount());
/*     */       }
/*     */     }
/*     */     
/*     */     protected void writeLine(FieldWriter writer, AbstractLine line, int fieldCount)
/*     */       throws IOException
/*     */     {
/* 553 */       if (line == null) {
/* 554 */         writeNullLine(writer);
/*     */       } else {
/* 556 */         int idx = line.getPreferredLayoutIdx();
/* 557 */         writeLine(writer, line, idx, fieldCount);
/*     */       }
/*     */     }
/*     */     
/*     */     private void writeNullLine(FieldWriter writer) throws IOException
/*     */     {
/* 563 */       if (writer.printAllFields()) {
/* 564 */         writeLine(writer, null, 0, 0);
/*     */       } else {
/* 566 */         writer.newLine();
/*     */       }
/*     */     }
/*     */     
/*     */     public boolean[] getFieldsToInclude()
/*     */     {
/* 572 */       return this.file.getFieldVisibility(net.sf.RecordEditor.re.file.DisplayType.getRecordMaxFields(this.layout));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class WriteFullLine
/*     */     extends SaveAsWrite
/*     */   {
/*     */     protected void allocateColumnNames(FileView fieldMapping, int idx)
/*     */     {
/* 584 */       this.columnNames.add(net.sf.RecordEditor.utils.lang.LangConversion.convert("Full Line"));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     protected void writeLine(FieldWriter writer, AbstractLine line)
/*     */       throws IOException
/*     */     {
/* 592 */       if (line != null) {
/* 593 */         writer.writeField(line.getFullLine());
/*     */       }
/* 595 */       writer.newLine();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static class WriteHexLine
/*     */     extends SaveAsWrite
/*     */   {
/*     */     protected void allocateColumnNames(FileView fieldMapping, int idx)
/*     */     {
/* 609 */       this.columnNames.add("Hex");
/*     */     }
/*     */     
/*     */     protected void writeLine(FieldWriter writer, AbstractLine line) throws IOException {
/* 613 */       byte[] bytes = line.getData();
/* 614 */       writer.writeField(net.sf.JRecord.Common.Conversion.getDecimal(bytes, 0, bytes.length));
/* 615 */       writer.newLine();
/*     */     }
/*     */   }
/*     */   
/*     */   private static class WriteTree extends SaveAsWrite
/*     */   {
/* 621 */     private int lineNo = 1;
/*     */     
/* 623 */     protected void writeLine(FieldWriter writer, AbstractLine line) throws IOException { writeTreeLineAsHtml(writer, line, false, this.lineNo++ + ""); }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     private void writeTreeLineAsHtml(FieldWriter writer, AbstractLine line, boolean indent, String id)
/*     */       throws IOException
/*     */     {
/* 632 */       int idx = line.getPreferredLayoutIdx();
/*     */       
/* 634 */       writer.startLevel(indent, id);
/* 635 */       writeLine(writer, line, idx, this.layout.getRecord(idx).getFieldCount());
/*     */       
/* 637 */       AbstractTreeDetails tree = line.getTreeDetails();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 642 */       for (int i = 0; i < tree.getChildCount(); i++) {
/* 643 */         AbstractChildDetails childDef = tree.getChildDetails(i);
/* 644 */         List<? extends AbstractLine> list = tree.getLines(i);
/*     */         
/* 646 */         if (list.size() == 1) {
/* 647 */           writeTreeLineAsHtml(writer, (AbstractLine)list.get(0), false, childDef.getName());
/*     */         } else {
/* 649 */           for (int j = 0; j < list.size(); j++) {
/* 650 */             writeTreeLineAsHtml(writer, (AbstractLine)list.get(j), true, childDef.getName() + "." + (j + 1));
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 655 */       writer.endLevel();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/SaveAs/SaveAsWrite.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */