/*     */ package net.sf.RecordEditor.edit.display.SaveAs;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JSplitPane;
/*     */ import javax.swing.JTable;
/*     */ import net.sf.JRecord.Common.Conversion;
/*     */ import net.sf.JRecord.Common.RecordException;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.JRecord.Details.RecordDetail;
/*     */ import net.sf.JRecord.External.Def.ExternalField;
/*     */ import net.sf.RecordEditor.edit.util.StandardLayouts;
/*     */ import net.sf.RecordEditor.re.fileWriter.FieldWriter;
/*     */ import net.sf.RecordEditor.re.fileWriter.WriterBuilder;
/*     */ import net.sf.RecordEditor.utils.charsets.FontCombo;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.ComboBoxs.DelimiterCombo;
/*     */ 
/*     */ 
/*     */ public class SaveAsPnlCsv
/*     */   extends SaveAsPnlBase
/*     */ {
/*     */   public SaveAsPnlCsv(CommonSaveAsFields commonSaveAsFields)
/*     */   {
/*  29 */     super(commonSaveAsFields, ".csv", 1, -1, null);
/*     */     
/*  31 */     BasePanel pnl1 = new BasePanel();
/*  32 */     BasePanel pnl2 = new BasePanel();
/*     */     
/*  34 */     pnl1.setFieldNamePrefix("Csv");
/*  35 */     pnl1.addLineRE("Delimiter", this.delimiterCombo);
/*  36 */     pnl1.addLineRE("Quote", this.quoteCombo);
/*  37 */     pnl1.addLineRE("Charset", this.charsetCombo);
/*  38 */     pnl1.addLineRE("names on first line", this.namesFirstLine);
/*  39 */     pnl1.addLineRE("Add Quote to all Text Fields", this.quoteAllTextFields);
/*     */     
/*  41 */     this.fieldTbl = new JTable();
/*  42 */     pnl2.addComponentRE(1, 5, 130.0D, BasePanel.GAP, 2, 2, this.fieldTbl);
/*     */     
/*  44 */     pnl2.setComponentName(this.fieldTbl, "CsvColNames");
/*     */     
/*     */ 
/*  47 */     this.panel.addComponentRE(1, 5, -1.0D, BasePanel.GAP, 2, 2, new JSplitPane(1, pnl1, pnl2));
/*     */     
/*     */ 
/*     */ 
/*  51 */     setupPrintDetails(false);
/*     */   }
/*     */   
/*     */   public void save(String selection, String outFile) throws IOException, RecordException
/*     */   {
/*  56 */     String fieldSeperator = this.delimiterCombo.getSelectedEnglish();
/*  57 */     String fontname = getCharset();
/*     */     
/*  59 */     if ((fieldSeperator != null) && (fieldSeperator.toLowerCase().startsWith("x'")) && (Conversion.isMultiByte(fontname))) {
/*  60 */       throw new RecordException("Hex seperators can not be used with a multibyte charset");
/*     */     }
/*     */     
/*     */ 
/*  64 */     FieldWriter writer = WriterBuilder.newCsvWriter(outFile, fieldSeperator, fontname, getQuote(), this.quoteAllTextFields.isSelected(), getIncludeFields());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  69 */     save_writeFile(writer, selection);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractLayoutDetails getEditLayout(String ext, AbstractLayoutDetails l)
/*     */   {
/*  78 */     AbstractLayoutDetails ret = null;
/*  79 */     StandardLayouts genLayout = StandardLayouts.getInstance();
/*  80 */     boolean EmbeddedCr = false;
/*  81 */     if ((l != null) && (l.getRecordCount() > 0) && ((l.getRecord(0) instanceof RecordDetail)))
/*     */     {
/*  83 */       EmbeddedCr = ((RecordDetail)l.getRecord(0)).isEmbeddedNewLine();
/*     */     }
/*     */     
/*  86 */     if (this.namesFirstLine.isSelected()) {
/*  87 */       ret = genLayout.getCsvLayoutNamesFirstLine(this.delimiterCombo.getSelectedEnglish(), this.charsetCombo.getText(), getQuote(), EmbeddedCr);
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*  92 */     else if (this.commonSaveAsFields.printRecordDetails != null) {
/*  93 */       List<ExternalField> ef = new ArrayList(this.commonSaveAsFields.printRecordDetails.getFieldCount());
/*  94 */       int pos = 1;
/*  95 */       List<String> colNames = this.commonSaveAsFields.flatFileWriter.getColumnNames();
/*     */       
/*  97 */       for (int i = 0; i < colNames.size(); i++) {
/*  98 */         ef.add(new ExternalField(pos++, -121, (String)colNames.get(i), "", 0, 0, 0, "", "", "", 0));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 105 */       ret = genLayout.getCsvLayout(ef, "Default", this.delimiterCombo.getSelectedEnglish(), this.charsetCombo.getText(), getQuote(), EmbeddedCr);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 113 */     return ret;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/SaveAs/SaveAsPnlCsv.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */