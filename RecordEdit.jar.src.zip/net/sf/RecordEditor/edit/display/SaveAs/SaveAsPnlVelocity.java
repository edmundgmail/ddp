/*    */ package net.sf.RecordEditor.edit.display.SaveAs;
/*    */ 
/*    */ import java.io.BufferedWriter;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.OutputStreamWriter;
/*    */ import net.sf.RecordEditor.re.script.RunVelocity;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*    */ import net.sf.RecordEditor.utils.params.ProgramOptions.FileNameOptWithDefault;
/*    */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*    */ import net.sf.RecordEditor.utils.swing.treeCombo.FileSelectCombo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SaveAsPnlVelocity
/*    */   extends SaveAsPnlBase
/*    */ {
/*    */   public SaveAsPnlVelocity(CommonSaveAsFields commonSaveAsFields)
/*    */   {
/* 27 */     super(commonSaveAsFields, ".html", 7, 4, new FileSelectCombo("VelocitySkels.", 25, true, false));
/*    */     
/*    */ 
/*    */ 
/* 31 */     addHtmlFields(this.panel);
/*    */     
/*    */ 
/* 34 */     this.template.setText(Common.OPTIONS.DEFAULT_VELOCITY_DIRECTORY.get());
/* 35 */     this.panel.addLineRE("Velocity Template", this.template);
/*    */     
/* 37 */     this.template.addFcFocusListener(commonSaveAsFields.templateListner);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void save(String selection, String outFile)
/*    */     throws Exception
/*    */   {
/* 48 */     RunVelocity velocity = RunVelocity.getInstance();
/*    */     
/* 50 */     BufferedWriter w = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(outFile), "utf8"));
/*    */     try {
/* 52 */       velocity.genSkel(this.template.getText(), getScriptData(selection, outFile), w);
/*    */     }
/*    */     finally
/*    */     {
/* 56 */       w.close();
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isActive()
/*    */   {
/* 66 */     return Common.isVelocityAvailable();
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/SaveAs/SaveAsPnlVelocity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */