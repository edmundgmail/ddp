/*     */ package net.sf.RecordEditor.edit.display.SaveAs;
/*     */ 
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JTextArea;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.LayoutDetail;
/*     */ import net.sf.JRecord.Details.RecordDetail;
/*     */ import net.sf.JRecord.IO.AbstractLineWriter;
/*     */ import net.sf.JRecord.IO.LineIOProvider;
/*     */ import net.sf.RecordEditor.edit.util.ReMessages;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.re.util.FileStructureDtls;
/*     */ import net.sf.RecordEditor.re.util.ReIOProvider;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions.InternalBoolOption;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMsgId;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.Combo.ComboOption;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SaveAsPnlFileStructure
/*     */   extends SaveAsPnlBase
/*     */ {
/*  37 */   private JComboBox fileStructures = FileStructureDtls.getFileStructureCombo();
/*     */   
/*     */ 
/*     */ 
/*     */   public SaveAsPnlFileStructure(CommonSaveAsFields commonSaveAsFields)
/*     */   {
/*  43 */     super(commonSaveAsFields, ".bin", 8, -1, null);
/*     */     
/*  45 */     JTextArea area = new JTextArea(ReMessages.EXPORT_FILE_STRUCTURE.get());
/*     */     
/*  47 */     this.panel.addComponentRE(1, 3, -1.0D, BasePanel.GAP, 2, 2, area);
/*     */     
/*     */ 
/*     */ 
/*  51 */     this.panel.addLineRE("new File Structure", this.fileStructures);
/*  52 */     this.panel.setGapRE(BasePanel.GAP2);
/*     */   }
/*     */   
/*     */   public void save(String selection, String outFile)
/*     */     throws Exception
/*     */   {
/*  58 */     ComboOption opt = (ComboOption)this.fileStructures.getSelectedItem();
/*     */     
/*  60 */     if (opt != null)
/*     */     {
/*  62 */       FileView view = this.commonSaveAsFields.getViewToSave(selection);
/*  63 */       if (view != null) {
/*  64 */         if (opt.index == 2) {
/*  65 */           saveFixed(outFile, view);
/*     */         } else {
/*  67 */           LineIOProvider p = ReIOProvider.getInstance();
/*  68 */           AbstractLineWriter w = p.getLineWriter(opt.index, this.commonSaveAsFields.file.getLayout().getFontName());
/*     */           
/*  70 */           w.open(outFile);
/*     */           
/*  72 */           for (int i = 0; i < view.getRowCount(); i++) {
/*  73 */             w.write(view.getLine(i));
/*     */           }
/*  75 */           w.close();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void saveFixed(String outFile, FileView view) throws IOException {
/*  82 */     BufferedOutputStream outStream = new BufferedOutputStream(new FileOutputStream(outFile), 8192);
/*  83 */     AbstractLayoutDetails layout = view.getLayout();
/*  84 */     int len = layout.getMaximumRecordLength();
/*     */     
/*  86 */     byte[] data = new byte[len];
/*     */     
/*  88 */     byte fill = 0;
/*  89 */     if (!layout.isBinary()) {
/*  90 */       fill = net.sf.JRecord.Common.Conversion.getBytes(" ", layout.getFontName())[0];
/*     */     }
/*     */     
/*     */     try
/*     */     {
/*  95 */       for (int i = 0; i < view.getRowCount(); i++) {
/*  96 */         byte[] l = view.getLine(i).getData();
/*  97 */         if (l.length == len) {
/*  98 */           outStream.write(l);
/*  99 */         } else if (l.length == len) {
/* 100 */           outStream.write(l, 0, len);
/*     */         } else {
/* 102 */           for (int j = l.length; j < len; j++) {
/* 103 */             data[j] = fill;
/*     */           }
/* 105 */           System.arraycopy(l, 0, data, 0, l.length - 1);
/* 106 */           outStream.write(data);
/*     */         }
/*     */       }
/*     */     } finally {
/* 110 */       outStream.close();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractLayoutDetails getEditLayout(String ext)
/*     */   {
/* 123 */     AbstractLayoutDetails l = this.commonSaveAsFields.file.getLayout();
/* 124 */     ComboOption opt = (ComboOption)this.fileStructures.getSelectedItem();
/*     */     
/*     */ 
/* 127 */     if ((opt != null) && ((l instanceof LayoutDetail))) {
/* 128 */       LayoutDetail layout = (LayoutDetail)l;
/* 129 */       RecordDetail[] recs = new RecordDetail[layout.getRecordCount()];
/*     */       
/* 131 */       for (int i = 0; i < recs.length; i++) {
/* 132 */         recs[i] = ((RecordDetail)layout.getRecord(i));
/*     */       }
/*     */       
/* 135 */       return new LayoutDetail(l.getLayoutName(), recs, l.getDescription(), l.getLayoutType(), l.getRecordSep(), l.getEolString(), l.getFontName(), l.getDecider(), opt.index);
/*     */     }
/*     */     
/*     */ 
/* 139 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isActive()
/*     */   {
/*     */     try
/*     */     {
/* 149 */       int fileStructure = this.commonSaveAsFields.file.getLayout().getFileStructure();
/*     */       
/* 151 */       return (Common.OPTIONS.standardEditor.isSelected()) && (fileStructure != 55) && (fileStructure != 90);
/*     */     }
/*     */     catch (Exception e) {}
/*     */     
/* 155 */     return false;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/SaveAs/SaveAsPnlFileStructure.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */