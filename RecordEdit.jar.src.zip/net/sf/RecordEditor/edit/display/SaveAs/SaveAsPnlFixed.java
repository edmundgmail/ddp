/*     */ package net.sf.RecordEditor.edit.display.SaveAs;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JSplitPane;
/*     */ import javax.swing.JTable;
/*     */ import net.sf.JRecord.Common.RecordException;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.JRecord.External.Def.ExternalField;
/*     */ import net.sf.RecordEditor.edit.util.StandardLayouts;
/*     */ import net.sf.RecordEditor.re.fileWriter.FixedWriter;
/*     */ import net.sf.RecordEditor.utils.charsets.FontCombo;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SaveAsPnlFixed
/*     */   extends SaveAsPnlBase
/*     */ {
/*     */   private FixedWriter writer;
/*     */   
/*     */   public SaveAsPnlFixed(CommonSaveAsFields commonSaveAsFields)
/*     */   {
/*  35 */     super(commonSaveAsFields, ".txt", 2, -1, null);
/*     */     
/*  37 */     BasePanel pnl1 = new BasePanel();
/*  38 */     BasePanel pnl2 = new BasePanel();
/*     */     
/*     */ 
/*     */ 
/*  42 */     pnl1.addLineRE("names on first line", this.namesFirstLine);
/*  43 */     pnl1.addLineRE("space between fields", this.spaceBetweenFields);
/*  44 */     pnl1.addLineRE("Charset", this.charsetCombo);
/*     */     
/*  46 */     this.fieldTbl = new JTable();
/*  47 */     pnl2.addComponentRE(1, 5, 130.0D, BasePanel.GAP, 2, 2, this.fieldTbl);
/*     */     
/*  49 */     pnl2.setComponentName(this.fieldTbl, "FixedColNames");
/*     */     
/*     */ 
/*  52 */     this.panel.addComponentRE(1, 5, -1.0D, BasePanel.GAP, 2, 2, new JSplitPane(1, pnl1, pnl2));
/*     */     
/*     */ 
/*     */ 
/*  56 */     setupPrintDetails(true);
/*     */   }
/*     */   
/*     */   public void save(String selection, String outFile) throws IOException, RecordException {
/*  60 */     String fieldSeperator = "";
/*  61 */     String fontname = getCharset();
/*     */     
/*  63 */     if (this.spaceBetweenFields.isSelected()) {
/*  64 */       fieldSeperator = " ";
/*     */     }
/*     */     
/*     */ 
/*  68 */     this.writer = new FixedWriter(outFile, fieldSeperator, fontname, getFieldLengths(), getIncludeFields());
/*     */     
/*     */ 
/*     */ 
/*  72 */     save_writeFile(this.writer, selection);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractLayoutDetails getEditLayout(String ext)
/*     */   {
/*  80 */     AbstractLayoutDetails ret = null;
/*     */     
/*  82 */     if (this.commonSaveAsFields.printRecordDetails != null) {
/*  83 */       List<ExternalField> ef = new ArrayList(this.commonSaveAsFields.printRecordDetails.getFieldCount());
/*  84 */       int pos = 1;
/*  85 */       int sepLength = 0;
/*  86 */       List<String> colNames = this.commonSaveAsFields.flatFileWriter.getColumnNames();
/*  87 */       int levels = this.commonSaveAsFields.flatFileWriter.getLevelCount();
/*  88 */       int[] lengths = this.writer.getColumnWidths();
/*  89 */       if (this.spaceBetweenFields.isSelected()) {
/*  90 */         sepLength = 1;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  97 */       for (int i = 0; i < levels; i++) {
/*  98 */         ef.add(new ExternalField(pos, lengths[i], (String)colNames.get(i), "", 0, 0, 0, "", "", "", 0));
/*     */         
/*     */ 
/*     */ 
/* 102 */         pos += sepLength + lengths[i];
/*     */       }
/* 104 */       for (int i = levels; i < colNames.size(); i++)
/*     */       {
/*     */ 
/* 107 */         ef.add(new ExternalField(pos, lengths[i], (String)colNames.get(i), "", 0, 0, 0, "", "", "", 0));
/*     */         
/*     */ 
/*     */ 
/* 111 */         pos += sepLength + lengths[i];
/*     */       }
/*     */       
/*     */ 
/* 115 */       ret = StandardLayouts.getInstance().getFixedLayout(ef, this.charsetCombo.getText());
/*     */     }
/* 117 */     return ret;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/SaveAs/SaveAsPnlFixed.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */