/*     */ package net.sf.RecordEditor.edit.display.SaveAs;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JTextArea;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.RecordFilter;
/*     */ import net.sf.RecordEditor.edit.util.ReMessages;
/*     */ import net.sf.RecordEditor.edit.util.StandardLayouts;
/*     */ import net.sf.RecordEditor.edit.util.WriteLinesAsXml;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.re.tree.ChildTreeToXml;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMsgId;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ 
/*     */ public class SaveAsPnlBasic extends SaveAsPnlBase
/*     */ {
/*     */   public SaveAsPnlBasic(CommonSaveAsFields commonSaveAsFields, int panelFormat, String extension, String description)
/*     */   {
/*  21 */     super(commonSaveAsFields, extension, panelFormat, -1, null);
/*  22 */     JTextArea area = new JTextArea(description);
/*     */     
/*  24 */     this.panel.addComponentRE(1, 5, -1.0D, BasePanel.GAP, 2, 2, area);
/*     */   }
/*     */   
/*     */ 
/*     */   public void save(String selection, String outFile)
/*     */     throws Exception
/*     */   {
/*  31 */     if (CommonSaveAsFields.OPT_VIEW.equals(selection)) {
/*  32 */       this.commonSaveAsFields.file.writeFile(outFile);
/*  33 */     } else if (CommonSaveAsFields.OPT_SELECTED.equals(selection)) {
/*  34 */       this.commonSaveAsFields.file.writeLinesToFile(outFile, this.commonSaveAsFields.getRecordFrame().getSelectedLines());
/*     */     } else {
/*  36 */       this.commonSaveAsFields.file.getBaseFile().writeFile(outFile);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static class Data
/*     */     extends SaveAsPnlBasic
/*     */   {
/*     */     public Data(CommonSaveAsFields commonSaveAsFields)
/*     */     {
/*  47 */       super(0, "$", ReMessages.EXPORT_DATA_DESC.get());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public AbstractLayoutDetails getEditLayout(String ext)
/*     */     {
/*  60 */       AbstractLayoutDetails tl = this.commonSaveAsFields.file.getLayout();
/*  61 */       if (tl.isXml()) {
/*  62 */         return StandardLayouts.getInstance().getXmlLayout();
/*     */       }
/*  64 */       ArrayList<RecordFilter> filter = new ArrayList(tl.getRecordCount());
/*  65 */       for (int i = 0; i < tl.getRecordCount(); i++) {
/*  66 */         filter.add(new SaveAsPnlBasic.RecFilter(tl.getRecord(i).getRecordName()));
/*     */       }
/*     */       
/*  69 */       return tl.getFilteredLayout(filter);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public static class Xml
/*     */     extends SaveAsPnlBasic
/*     */   {
/*     */     public Xml(CommonSaveAsFields commonSaveAsFields)
/*     */     {
/*  79 */       super(3, ".xml", ReMessages.EXPORT_XML_DESC.get());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void save(String selection, String outFile)
/*     */       throws Exception
/*     */     {
/*  88 */       if (this.commonSaveAsFields.file.getLayout().isXml()) {
/*  89 */         super.save(selection, outFile);
/*  90 */       } else if (this.commonSaveAsFields.file.getLayout().hasChildren()) {
/*  91 */         new ChildTreeToXml(outFile, saveFile_getLines(selection));
/*  92 */       } else if ((this.commonSaveAsFields.getTreeFrame() != null) && (this.commonSaveAsFields.treeExportChk.isSelected()) && (this.commonSaveAsFields.treeExportChk.isVisible()))
/*     */       {
/*     */ 
/*  95 */         new net.sf.RecordEditor.re.tree.TreeToXml(outFile, this.commonSaveAsFields.getTreeFrame().getRoot());
/*     */       } else {
/*  97 */         new WriteLinesAsXml(outFile, saveFile_getLines(selection));
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public AbstractLayoutDetails getEditLayout(String ext)
/*     */     {
/* 108 */       return StandardLayouts.getInstance().getXmlLayout();
/*     */     }
/*     */   }
/*     */   
/*     */   private static class RecFilter
/*     */     implements RecordFilter
/*     */   {
/*     */     private String name;
/*     */     
/*     */     public RecFilter(String name)
/*     */     {
/* 119 */       this.name = name;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getRecordName()
/*     */     {
/* 127 */       return this.name;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public String[] getFields()
/*     */     {
/* 135 */       return null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/SaveAs/SaveAsPnlBasic.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */