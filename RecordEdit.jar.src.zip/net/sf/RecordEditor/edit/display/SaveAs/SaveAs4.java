/*     */ package net.sf.RecordEditor.edit.display.SaveAs;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.io.File;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextArea;
/*     */ import net.sf.RecordEditor.edit.util.ReMessages;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*     */ import net.sf.RecordEditor.re.display.IChildDisplay;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions.FileNameOpt;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMsg;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SaveAs4
/*     */   extends ReFrame
/*     */   implements IChildDisplay
/*     */ {
/*  36 */   public JFileChooser fileChooser = new JFileChooser();
/*     */   
/*     */ 
/*     */   private CommonSaveAsFields commonSaveFields;
/*     */   
/*     */   private SaveAsPnlBase saveAsPnl;
/*     */   
/*  43 */   public final KeyAdapter keyListner = new KeyAdapter()
/*     */   {
/*     */ 
/*     */     public final void keyReleased(KeyEvent event)
/*     */     {
/*     */ 
/*  49 */       if (event.getKeyCode() == 10) {
/*  50 */         SaveAs4.this.saveFile();
/*  51 */       } else if (event.getKeyCode() == 27) {
/*  52 */         SaveAs4.this.doDefaultCloseAction();
/*     */       }
/*     */     }
/*     */   };
/*     */   
/*     */   public SaveAs4(AbstractFileDisplay recordFrame, FileView fileView)
/*     */   {
/*  59 */     super(fileView.getFileNameNoDirectory(), "Save As", fileView.getBaseFile());
/*     */     
/*     */ 
/*  62 */     BaseHelpPanel pnl = new BaseHelpPanel();
/*  63 */     String fname = fileView.getFileName();
/*  64 */     if ("".equals(fname)) {
/*  65 */       fname = Common.OPTIONS.DEFAULT_FILE_DIRECTORY.get();
/*     */     }
/*  67 */     this.commonSaveFields = new CommonSaveAsFields(recordFrame, fileView, null);
/*  68 */     this.saveAsPnl = new SaveAsPnlBasic.Data(this.commonSaveFields);
/*     */     
/*     */ 
/*  71 */     this.fileChooser.setApproveButtonText(ReMessages.SAVE.get());
/*  72 */     this.fileChooser.setApproveButtonToolTipText(ReMessages.SAVE_MESSAGE.get());
/*     */     
/*  74 */     if (fname != null) {
/*  75 */       this.fileChooser.setSelectedFile(new File(fname + "$"));
/*     */     }
/*     */     
/*  78 */     SwingUtils.addKeyListnerToContainer(pnl, this.keyListner);
/*  79 */     pnl.addReKeyListener(this.keyListner);
/*     */     
/*  81 */     addKeyListener(this.keyListner);
/*     */     
/*  83 */     pnl.addLineRE("What to Save", this.commonSaveFields.saveWhat);
/*     */     
/*  85 */     pnl.addComponentRE(1, 5, -1.0D, BasePanel.GAP2, 2, 2, this.fileChooser);
/*     */     
/*     */ 
/*     */ 
/*  89 */     pnl.setGapRE(BasePanel.GAP2);
/*  90 */     pnl.addMessage(this.commonSaveFields.message);
/*     */     
/*  92 */     pnl.done();
/*     */     
/*  94 */     addMainComponent(new JScrollPane(pnl));
/*     */     
/*     */ 
/*  97 */     setDefaultCloseOperation(2);
/*     */     
/*  99 */     this.fileChooser.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 102 */         if ("ApproveSelection".equals(evt.getActionCommand())) {
/* 103 */           SaveAs4.this.saveFile();
/* 104 */         } else if ("CancelSelection".equals(evt.getActionCommand())) {
/* 105 */           SaveAs4.this.setVisible(false);
/*     */         }
/*     */         
/*     */       }
/*     */       
/* 110 */     });
/* 111 */     setVisible(true);
/* 112 */     setToMaximum(false);
/*     */   }
/*     */   
/*     */   public final void saveFile()
/*     */   {
/*     */     try
/*     */     {
/* 119 */       String outFile = this.fileChooser.getSelectedFile().getCanonicalPath();
/* 120 */       String selection = this.commonSaveFields.saveWhat.getSelectedItem().toString();
/*     */       
/* 122 */       this.saveAsPnl.save(selection, outFile);
/*     */       
/* 124 */       doDefaultCloseAction();
/*     */     } catch (Exception e) {
/* 126 */       String s = LangConversion.convert("Save Failed:") + " " + e;
/* 127 */       this.commonSaveFields.message.setText(s);
/* 128 */       Common.logMsgRaw(s, e);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractFileDisplay getSourceDisplay()
/*     */   {
/* 139 */     return this.commonSaveFields.getRecordFrame();
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/SaveAs/SaveAs4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */