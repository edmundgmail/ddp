/*     */ package net.sf.RecordEditor.edit.display.SaveAs;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.management.RuntimeErrorException;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JRadioButton;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import javax.swing.table.AbstractTableModel;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import net.sf.JRecord.Common.RecordException;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail.FieldDetails;
/*     */ import net.sf.RecordEditor.edit.open.StartEditor;
/*     */ import net.sf.RecordEditor.edit.util.StandardLayouts;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*     */ import net.sf.RecordEditor.re.file.AbstractLineNode;
/*     */ import net.sf.RecordEditor.re.file.AbstractTreeFrame;
/*     */ import net.sf.RecordEditor.re.file.DisplayType;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.re.fileWriter.FieldWriter;
/*     */ import net.sf.RecordEditor.re.script.ScriptData;
/*     */ import net.sf.RecordEditor.re.util.ReIOProvider;
/*     */ import net.sf.RecordEditor.utils.charsets.FontCombo;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.CheckBoxTableRender;
/*     */ import net.sf.RecordEditor.utils.swing.ComboBoxs.DelimiterCombo;
/*     */ import net.sf.RecordEditor.utils.swing.ComboBoxs.QuoteCombo;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.FileSelectCombo;
/*     */ 
/*     */ public abstract class SaveAsPnlBase
/*     */ {
/*     */   public static final int SINGLE_TABLE = 1;
/*     */   public static final int TABLE_PER_ROW = 2;
/*     */   public static final int TREE_TABLE = 3;
/*  50 */   public static final String[] FIXED_COL_NAMES = LangConversion.convertColHeading("Export_Field_Selection", new String[] { "Field Name", "Include", "Length" });
/*     */   
/*     */ 
/*     */ 
/*  54 */   public static final String[] TITLES = LangConversion.convertArray(9, "ExportTab", new String[] { "Data", "CSV", "Fixed", "Xml", "Html", "Script", "XSLT Transform", "Velocity", "File Structure" });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int NULL_INT = -121;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int COL_NAME = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int COL_INCLUDE = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private static final int COL_LENGTH = 2;
/*     */   
/*     */ 
/*     */ 
/*  78 */   private static final int[] FMT_TO_NUMBER_OF_COLS = { 1, 2, 3 };
/*     */   
/*     */   public final String extension;
/*     */   
/*     */   public final int panelFormat;
/*     */   
/*     */   public final int extensionType;
/*     */   
/*     */   protected final CommonSaveAsFields commonSaveAsFields;
/*  87 */   public final BaseHelpPanel panel = new BaseHelpPanel(getClass().getSimpleName());
/*     */   
/*  89 */   public final DelimiterCombo delimiterCombo = DelimiterCombo.NewDelimCombo();
/*  90 */   public final QuoteCombo quoteCombo = QuoteCombo.newCombo();
/*  91 */   public final JCheckBox quoteAllTextFields = new JCheckBox();
/*     */   
/*  93 */   public final JTextField xsltTxt = new JTextField();
/*     */   
/*     */ 
/*  96 */   public final FontCombo charsetCombo = new FontCombo();
/*     */   
/*  98 */   private final ButtonGroup tableTypeGrp = new ButtonGroup();
/*  99 */   protected final JRadioButton singleTable = genTableTypeBtn("Single Table");
/* 100 */   protected final JRadioButton tablePerRow = genTableTypeBtn("Table per Row");
/* 101 */   protected final JRadioButton treeTable = genTableTypeBtn("Tree Table");
/*     */   
/* 103 */   public final JCheckBox onlyData = new JCheckBox();
/* 104 */   public final JCheckBox showBorder = new JCheckBox();
/* 105 */   public final JCheckBox namesFirstLine = new JCheckBox();
/* 106 */   public final JCheckBox spaceBetweenFields = new JCheckBox();
/*     */   
/*     */   public final FileSelectCombo template;
/*     */   
/*     */   protected JTable fieldTbl;
/*     */   
/*     */   protected FldTblMdl fixedModel;
/*     */   
/*     */   private AbstractRecordDetail record;
/*     */   
/*     */   private int[] fieldLengths;
/*     */   
/*     */   private int[] suppliedFieldLengths;
/*     */   
/*     */   private boolean[] includeFields;
/*     */   
/*     */   public int rowCount;
/*     */   
/*     */   private FileView file;
/*     */   
/*     */   public SaveAsPnlBase(CommonSaveAsFields commonSaveAsFields, String extension, int panelFormat, int extensionType, FileSelectCombo template)
/*     */   {
/* 128 */     this.commonSaveAsFields = commonSaveAsFields;
/* 129 */     this.extension = extension;
/* 130 */     this.panelFormat = panelFormat;
/* 131 */     this.extensionType = extensionType;
/* 132 */     this.template = template;
/* 133 */     this.file = commonSaveAsFields.getRecordFrame().getFileView();
/*     */     
/* 135 */     String f = this.file.getLayout().getFontName();
/* 136 */     if ((f != null) && (f.toLowerCase().startsWith("utf"))) {
/* 137 */       this.charsetCombo.setText(f);
/*     */     }
/*     */   }
/*     */   
/*     */   protected final void addDescription(String s)
/*     */   {
/* 143 */     JTextArea area = new JTextArea(s);
/*     */     
/* 145 */     this.panel.addComponentRE(1, 5, -1.0D, BasePanel.GAP, 2, 2, area);
/*     */   }
/*     */   
/*     */ 
/*     */   protected final void addHtmlFields(BasePanel pnl)
/*     */   {
/* 151 */     pnl.addLineRE("Only Data Column", this.onlyData);
/* 152 */     pnl.addLineRE("Show Table Border", this.showBorder);
/*     */   }
/*     */   
/*     */   private JRadioButton genTableTypeBtn(String s)
/*     */   {
/* 157 */     return generateRadioButton(this.tableTypeGrp, s);
/*     */   }
/*     */   
/*     */   protected final JRadioButton generateRadioButton(ButtonGroup grp, String s)
/*     */   {
/* 162 */     JRadioButton btn = new JRadioButton(LangConversion.convert(7, s));
/*     */     
/* 164 */     grp.add(btn);
/* 165 */     return btn;
/*     */   }
/*     */   
/*     */   public int getTableOption() {
/* 169 */     int ret = 1;
/*     */     
/* 171 */     if (this.tablePerRow.isSelected()) {
/* 172 */       ret = 2;
/* 173 */     } else if (this.treeTable.isSelected()) {
/* 174 */       ret = 3;
/*     */     }
/*     */     
/* 177 */     return ret;
/*     */   }
/*     */   
/*     */   public void setTableOption(int opt) {
/* 181 */     switch (opt) {
/* 182 */     case 1:  this.singleTable.setSelected(true); break;
/* 183 */     case 2:  this.tablePerRow.setSelected(true); break;
/* 184 */     case 3:  this.treeTable.setSelected(true);
/*     */     }
/*     */   }
/*     */   
/*     */   public String getTitle() {
/* 189 */     return TITLES[this.panelFormat];
/*     */   }
/*     */   
/*     */   public String getQuote() {
/* 193 */     String ret = "";
/* 194 */     int idx = this.quoteCombo.getSelectedIndex();
/*     */     
/* 196 */     if (idx >= 0) {
/* 197 */       ret = net.sf.RecordEditor.utils.common.Common.QUOTE_VALUES[idx];
/*     */     }
/*     */     
/* 200 */     return ret;
/*     */   }
/*     */   
/*     */   public String getCharset() throws RecordException {
/* 204 */     String charset = this.charsetCombo.getText();
/*     */     
/* 206 */     if ((!"".equals(charset)) && (!Charset.isSupported(charset))) {
/* 207 */       throw new RecordException("Charset is not supported by this Java implementation");
/*     */     }
/*     */     
/* 210 */     return charset;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int[] getFieldLengths()
/*     */   {
/* 218 */     if ((this.namesFirstLine.isSelected()) && (this.record != null)) {
/* 219 */       for (int i = 0; i < this.fieldLengths.length; i++) {
/* 220 */         if (this.fieldLengths[i] < 0) {
/* 221 */           this.fieldLengths[i] = Math.max(this.suppliedFieldLengths[i], this.record.getField(i).getName().length());
/*     */         }
/*     */         
/*     */       }
/*     */       
/*     */     } else {
/* 227 */       for (int i = 0; i < this.fieldLengths.length; i++) {
/* 228 */         if (this.fieldLengths[i] < 0) {
/* 229 */           this.fieldLengths[i] = this.suppliedFieldLengths[i];
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 234 */     return this.fieldLengths;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean[] getIncludeFields()
/*     */   {
/* 241 */     return this.includeFields;
/*     */   }
/*     */   
/*     */ 
/*     */   public abstract void save(String paramString1, String paramString2)
/*     */     throws Exception;
/*     */   
/*     */ 
/*     */   protected final void save_writeFile(FieldWriter writer, String selection)
/*     */     throws IOException
/*     */   {
/* 252 */     if (this.commonSaveAsFields.treeExportChk.isSelected()) {
/* 253 */       this.commonSaveAsFields.flatFileWriter.writeTree(writer, this.commonSaveAsFields.getTreeFrame().getRoot(), this.namesFirstLine.isSelected(), !this.commonSaveAsFields.nodesWithDataChk.isSelected(), this.commonSaveAsFields.getRecordFrame().getLayoutIndex());
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 259 */       this.commonSaveAsFields.flatFileWriter.writeFile(writer, this.namesFirstLine.isSelected(), this.commonSaveAsFields.getWhatToSave(selection));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void edit(String outFile, String ext)
/*     */   {
/* 266 */     AbstractLayoutDetails layout = getEditLayout(ext, this.file.getLayout());
/*     */     
/* 268 */     if (layout == null) {
/* 269 */       String lcExt = ext.toLowerCase();
/* 270 */       StandardLayouts genLayout = StandardLayouts.getInstance();
/* 271 */       System.out.println(" --> getExtensionFor: >" + ext + "< " + lcExt + " " + ".csv".equals(lcExt));
/* 272 */       if ((".xml".equals(lcExt)) || (".xsl".equals(lcExt))) {
/* 273 */         layout = genLayout.getXmlLayout();
/* 274 */       } else if (".csv".equals(lcExt)) {
/* 275 */         layout = genLayout.getGenericCsvLayout();
/*     */       }
/*     */     }
/*     */     
/* 279 */     if (layout == null) {
/* 280 */       throw new RuntimeErrorException(null, "Can not edit the File: Can not determine the format");
/*     */     }
/*     */     
/* 283 */     FileView newFile = new FileView(layout, ReIOProvider.getInstance(), false);
/*     */     
/*     */ 
/* 286 */     StartEditor startEditor = new StartEditor(newFile, outFile, false, this.commonSaveAsFields.message, 0);
/*     */     
/* 288 */     startEditor.doEdit();
/*     */   }
/*     */   
/*     */ 
/*     */   public AbstractLayoutDetails getEditLayout(String ext, AbstractLayoutDetails l)
/*     */   {
/* 294 */     return getEditLayout(ext);
/*     */   }
/*     */   
/*     */   public AbstractLayoutDetails getEditLayout(String ext) {
/* 298 */     return null;
/*     */   }
/*     */   
/*     */   protected final List<AbstractLine> saveFile_getLines(String selection) {
/* 302 */     return this.commonSaveAsFields.getViewToSave(selection).getLines();
/*     */   }
/*     */   
/*     */   protected final ScriptData getScriptData(String selection, String outFile)
/*     */   {
/* 307 */     AbstractLineNode root = null;
/* 308 */     String templateName = "";
/*     */     
/* 310 */     if (this.commonSaveAsFields.getTreeFrame() != null) {
/* 311 */       root = this.commonSaveAsFields.getTreeFrame().getRoot();
/*     */     }
/*     */     
/* 314 */     if (this.template != null) {
/* 315 */       templateName = this.template.getText();
/*     */     }
/*     */     
/* 318 */     return new ScriptData(saveFile_getLines(selection), this.commonSaveAsFields.file, root, this.onlyData.isSelected(), this.showBorder.isSelected(), this.commonSaveAsFields.getRecordFrame().getLayoutIndex(), outFile, ReFrame.getActiveFrame(), templateName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRecordDetails(int[] fldLengths)
/*     */   {
/* 334 */     this.record = this.commonSaveAsFields.printRecordDetails;
/* 335 */     this.suppliedFieldLengths = fldLengths;
/*     */     
/* 337 */     this.includeFields = this.commonSaveAsFields.flatFileWriter.getFieldsToInclude();
/*     */     
/* 339 */     if (fldLengths != null) {
/* 340 */       this.rowCount = this.suppliedFieldLengths.length;
/* 341 */       this.fieldLengths = new int[this.rowCount];
/*     */       
/* 343 */       for (int i = 0; i < this.fieldLengths.length; i++) {
/* 344 */         this.fieldLengths[i] = -121;
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 349 */     if (this.record != null) {
/* 350 */       AbstractLayoutDetails l = this.file.getLayout();
/* 351 */       this.rowCount = this.record.getFieldCount();
/* 352 */       this.fixedModel = new FldTblMdl();
/* 353 */       this.fieldTbl.setModel(this.fixedModel);
/*     */       
/* 355 */       if (DisplayType.isTreeStructure(l)) {
/* 356 */         this.rowCount = DisplayType.getMaxFields(l);
/*     */       }
/*     */       
/* 359 */       TableColumnModel tcm = this.fieldTbl.getColumnModel();
/* 360 */       tcm.getColumn(1).setCellRenderer(new CheckBoxTableRender());
/* 361 */       tcm.getColumn(1).setCellEditor(new javax.swing.DefaultCellEditor(new JCheckBox()));
/*     */       
/* 363 */       if (this.includeFields == null) {
/* 364 */         this.includeFields = new boolean[this.rowCount];
/* 365 */         for (int i = 0; i < this.rowCount; i++) {
/* 366 */           this.includeFields[i] = true;
/*     */         }
/*     */       }
/* 369 */       this.namesFirstLine.addChangeListener(new ChangeListener()
/*     */       {
/*     */ 
/*     */ 
/*     */         public void stateChanged(ChangeEvent arg0)
/*     */         {
/*     */ 
/* 376 */           SaveAsPnlBase.this.fixedModel.fireTableDataChanged();
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected final void setupPrintDetails(boolean isFixed)
/*     */   {
/* 386 */     AbstractLayoutDetails l = this.file.getLayout();
/* 387 */     int layoutIdx = this.file.getCurrLayoutIdx();
/* 388 */     int[] colLengths = null;
/* 389 */     this.commonSaveAsFields.printRecordDetails = null;
/*     */     
/* 391 */     switch (DisplayType.displayTypePrint(l, this.commonSaveAsFields.getRecordFrame().getLayoutIndex())) {
/*     */     case 0: 
/* 393 */       this.commonSaveAsFields.printRecordDetails = l.getRecord(layoutIdx);
/* 394 */       if (isFixed) {
/* 395 */         colLengths = getFieldWidths();
/*     */       }
/*     */       break;
/*     */     case 1: 
/* 399 */       this.commonSaveAsFields.printRecordDetails = l.getRecord(DisplayType.getRecordMaxFields(l));
/* 400 */       if (isFixed) {
/* 401 */         colLengths = getFieldWidthsPrefered();
/*     */       }
/*     */       break;
/*     */     case 3: 
/* 405 */       colLengths = new int[1];
/* 406 */       colLengths[0] = (l.getMaximumRecordLength() * 2);
/*     */     }
/*     */     
/*     */     
/* 410 */     setRecordDetails(colLengths);
/*     */   }
/*     */   
/*     */   public boolean isActive() {
/* 414 */     return true;
/*     */   }
/*     */   
/*     */   private int[] getFieldWidths() {
/* 418 */     AbstractLayoutDetails l = this.file.getLayout();
/* 419 */     int layoutIdx = this.file.getCurrLayoutIdx();
/* 420 */     int[] ret = new int[DisplayType.getFieldCount(l, layoutIdx)];
/* 421 */     int count = 0;
/* 422 */     Iterator<AbstractLine> it = this.file.iterator();
/*     */     
/* 424 */     while (it.hasNext()) {
/* 425 */       calcColLengthsForLine(ret, (AbstractLine)it.next(), l, layoutIdx);
/* 426 */       if (count++ > 30000) {
/*     */         break;
/*     */       }
/*     */     }
/*     */     
/* 431 */     return ret;
/*     */   }
/*     */   
/*     */   private int[] getFieldWidthsPrefered()
/*     */   {
/* 436 */     AbstractLayoutDetails l = this.file.getLayout();
/* 437 */     int layoutIdx = DisplayType.getRecordMaxFields(l);
/* 438 */     int[] ret = new int[l.getRecord(layoutIdx).getFieldCount()];
/* 439 */     int count = 0;
/* 440 */     Iterator<AbstractLine> it = this.file.iterator();
/*     */     
/*     */ 
/* 443 */     while (it.hasNext()) {
/* 444 */       AbstractLine line = (AbstractLine)it.next();
/* 445 */       calcColLengthsForLine(ret, line, l, line.getPreferredLayoutIdx());
/* 446 */       if (count++ > 30000) {
/*     */         break;
/*     */       }
/*     */     }
/*     */     
/* 451 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTemplateText(String text)
/*     */   {
/* 460 */     if (this.template != null) {
/* 461 */       this.template.setText(text);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void calcColLengthsForLine(int[] ret, AbstractLine line, AbstractLayoutDetails layout, int layoutIdx)
/*     */   {
/* 470 */     int colCount = layout.getRecord(layoutIdx).getFieldCount();
/* 471 */     calcLengths(ret, line, layoutIdx, 0, colCount);
/*     */     
/* 473 */     if (DisplayType.isTreeStructure(layout)) {
/* 474 */       int idx = DisplayType.getRecordMaxFields(layout);
/* 475 */       calcLengths(ret, line, idx, colCount, ret.length);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void calcLengths(int[] ret, AbstractLine line, int layoutIdx, int colStart, int colEnd)
/*     */   {
/* 483 */     for (int j = colStart; j < colEnd; j++) {
/* 484 */       Object o = line.getField(layoutIdx, j);
/*     */       
/* 486 */       if (o != null) {
/* 487 */         ret[j] = Math.max(ret[j], o.toString().length());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected final class FldTblMdl
/*     */     extends AbstractTableModel
/*     */   {
/*     */     protected FldTblMdl() {}
/*     */     
/*     */ 
/*     */     public String getColumnName(int row)
/*     */     {
/* 502 */       return SaveAsPnlBase.FIXED_COL_NAMES[row];
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isCellEditable(int row, int col)
/*     */     {
/* 511 */       return col != 0;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setValueAt(Object val, int row, int col)
/*     */     {
/* 519 */       if (val != null) {
/* 520 */         switch (col) {
/*     */         case 1: 
/* 522 */           if ((val instanceof Boolean)) {
/* 523 */             SaveAsPnlBase.this.includeFields[row] = ((Boolean)val).booleanValue();
/*     */           }
/*     */           break;
/*     */         case 2: 
/*     */           try {
/* 528 */             int v = new Integer(val.toString().trim()).intValue();
/* 529 */             if (v > 0) {
/* 530 */               SaveAsPnlBase.this.fieldLengths[row] = v;
/*     */             }
/*     */           }
/*     */           catch (Exception e) {}
/*     */         }
/*     */         
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getColumnCount()
/*     */     {
/* 547 */       return SaveAsPnlBase.FMT_TO_NUMBER_OF_COLS[SaveAsPnlBase.this.panelFormat];
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getRowCount()
/*     */     {
/* 555 */       return SaveAsPnlBase.this.includeFields.length;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Object getValueAt(int row, int col)
/*     */     {
/* 563 */       Object ret = null;
/*     */       try
/*     */       {
/* 566 */         switch (col) {
/*     */         case 0: 
/* 568 */           if ((SaveAsPnlBase.this.record == null) || (row >= SaveAsPnlBase.this.record.getFieldCount())) {
/* 569 */             ret = "Column " + row;
/*     */           } else {
/* 571 */             ret = SaveAsPnlBase.this.record.getField(row).getName();
/*     */           }
/* 573 */           break;
/*     */         case 1: 
/* 575 */           if (SaveAsPnlBase.this.includeFields != null) {
/* 576 */             ret = Boolean.valueOf(SaveAsPnlBase.this.includeFields[row]);
/*     */           }
/*     */           break;
/*     */         case 2: 
/* 580 */           if (SaveAsPnlBase.this.suppliedFieldLengths != null) {
/* 581 */             int v = SaveAsPnlBase.this.suppliedFieldLengths[row];
/*     */             
/* 583 */             if (SaveAsPnlBase.this.fieldLengths[row] > 0) {
/* 584 */               v = SaveAsPnlBase.this.fieldLengths[row];
/* 585 */             } else if ((SaveAsPnlBase.this.namesFirstLine.isSelected()) && (SaveAsPnlBase.this.record != null)) {
/* 586 */               v = Math.max(SaveAsPnlBase.this.suppliedFieldLengths[row], SaveAsPnlBase.this.record.getField(row).getName().length());
/*     */             }
/*     */             
/*     */ 
/* 590 */             ret = Integer.valueOf(v);
/*     */           }
/*     */           break;
/*     */         }
/*     */       } catch (Exception e) {
/* 595 */         e.printStackTrace();
/*     */       }
/*     */       
/* 598 */       return ret;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/SaveAs/SaveAsPnlBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */