/*     */ package net.sf.RecordEditor.edit.display;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseEvent;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.Action;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.event.TableModelEvent;
/*     */ import javax.swing.event.TableModelListener;
/*     */ import javax.swing.event.TreeModelEvent;
/*     */ import javax.swing.event.TreeModelListener;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.RecordEditor.edit.display.Action.GotoLineAction;
/*     */ import net.sf.RecordEditor.edit.display.models.LineModel;
/*     */ import net.sf.RecordEditor.edit.display.util.MovementBtnPnl;
/*     */ import net.sf.RecordEditor.re.file.AbstractLineNode;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.MenuPopupListener;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.lang.ReAbstractAction;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.HexThreeLineField;
/*     */ import net.sf.RecordEditor.utils.swing.HexThreeLineRender;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ public abstract class BaseLineFrame
/*     */   extends BaseLineAsColumn
/*     */   implements TableModelListener, TreeModelListener
/*     */ {
/*     */   protected int stdCellHeight;
/*     */   protected int threeLineHeight;
/*     */   protected JCheckBox oneLineHex;
/*  47 */   protected JTextField lineNum = new JTextField();
/*     */   
/*     */   protected MovementBtnPnl btnPanel;
/*  50 */   private String[] moveHints = LangConversion.convertArray(11, "RecordBtns", new String[] { "Start of File", "Previous Record", "Next Record", "Last Record" });
/*     */   
/*     */ 
/*  53 */   private String[] moveHints6 = { this.moveHints[0], this.moveHints[1], LangConversion.convert(11, "Parent Record"), LangConversion.convert(11, "Child Record"), this.moveHints[2], this.moveHints[3] };
/*     */   
/*     */   protected JTextArea fullLine;
/*     */   
/*     */   private HexThreeLineField hexLine;
/*     */   
/*     */   private double fullLineHeight;
/*     */   
/*     */   private ActionListener listner;
/*     */   protected LineModel record;
/*     */   private TableCellRenderer defaultHexRendor;
/*  64 */   private TableCellRenderer hexRendor = null;
/*     */   
/*  66 */   private int popupRow = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BaseLineFrame(String formType, FileView viewOfFile, boolean primary, boolean fullLine, boolean changeRow)
/*     */   {
/*  75 */     super(formType, viewOfFile, primary, fullLine, changeRow);
/*     */     
/*  77 */     AbstractAction[] actions = { new ReAbstractAction("Hide Column")
/*     */     
/*     */ 
/*  80 */       new GotoLineAction
/*     */       {
/*     */ 
/*  80 */         public void actionPerformed(ActionEvent e) { BaseLineFrame.this.hideRow(BaseLineFrame.this.popupRow); } }, new GotoLineAction(this, this.fileView) };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  86 */     this.popupListner = new MenuPopupListener(actions, true, getJTable())
/*     */     {
/*     */ 
/*     */       public void mousePressed(MouseEvent e)
/*     */       {
/*  91 */         super.mousePressed(e);
/*  92 */         JTable table = BaseLineFrame.this.getJTable();
/*     */         
/*  94 */         int col = table.columnAtPoint(e.getPoint());
/*  95 */         BaseLineFrame.this.popupRow = table.rowAtPoint(e.getPoint());
/*     */         
/*  97 */         if ((BaseLineFrame.this.popupRow >= 0) && (BaseLineFrame.this.popupRow != table.getEditingRow()) && (col >= 0) && (col != table.getEditingColumn()) && (BaseLineFrame.this.cellEditors != null) && (col < BaseLineFrame.this.cellEditors.length) && (BaseLineFrame.this.cellEditors[col] != null))
/*     */         {
/*     */ 
/*     */ 
/* 101 */           table.editCellAt(BaseLineFrame.this.popupRow, col);
/*     */         }
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void init_200_setupFields(ImageIcon[] icon, ActionListener btnActions, boolean changeRow)
/*     */   {
/* 112 */     this.listner = btnActions;
/*     */     
/* 114 */     this.btnPanel = new MovementBtnPnl(icon, changeRow, btnActions);
/*     */     
/* 116 */     if (icon.length > 4) {
/* 117 */       this.moveHints = this.moveHints6;
/*     */     }
/*     */     
/* 120 */     init_210_setupTable();
/*     */     
/* 122 */     setFullLine();
/*     */     
/* 124 */     int currLayout = this.record.getCurrentLayout();
/*     */     
/* 126 */     if (currLayout == -121) {
/* 127 */       currLayout = this.fileView.getCurrLayoutIdx();
/*     */     }
/*     */     
/* 130 */     if (currLayout != this.record.getCurrentLayout()) {
/* 131 */       this.record.setCurrentLayout(currLayout);
/* 132 */       this.record.fireTableDataChanged();
/*     */     }
/* 134 */     setLayoutIndex(currLayout);
/*     */     
/* 136 */     this.fileView.addTableModelListener(this);
/* 137 */     this.fileView.addTreeModelListener(this);
/* 138 */     setColWidths();
/*     */     
/* 140 */     this.actualPnl.setHelpURLre(Common.formatHelpURL("HlpRe04.htm"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void init_210_setupTable()
/*     */   {
/* 164 */     setJTable(new BaseLineAsColumn.LineAsColTbl(this, this.record, this.record.firstDataColumn, true));
/*     */     
/*     */ 
/* 167 */     this.tblDetails.addMouseListener(this.popupListner);
/* 168 */     this.popupListner.setTable(this.tblDetails);
/* 169 */     setRowHeight();
/*     */     
/* 171 */     if (this.fileMaster.isBinaryFile()) {
/* 172 */       TableColumn tc = this.tblDetails.getColumnModel().getColumn(this.record.hexColumn);
/*     */       
/* 174 */       this.stdCellHeight = this.tblDetails.getRowHeight();
/* 175 */       this.threeLineHeight = ((this.stdCellHeight + 3) * 3);
/*     */       
/* 177 */       this.oneLineHex = new JCheckBox();
/* 178 */       this.oneLineHex.setSelected(true);
/* 179 */       this.oneLineHex.addActionListener(this.listner);
/*     */       
/* 181 */       this.defaultHexRendor = tc.getCellRenderer();
/*     */       
/* 183 */       this.hexLine = new HexThreeLineField(this.layout.getFontName());
/* 184 */       this.fullLineHeight = BasePanel.GAP5;
/* 185 */       this.fullLine = this.hexLine;
/* 186 */     } else if (this.layout.isBinCSV()) {
/* 187 */       this.hexLine = new HexThreeLineField(this.layout.getFontName());
/* 188 */       this.fullLineHeight = BasePanel.GAP5;
/* 189 */       this.fullLine = this.hexLine;
/*     */     } else {
/* 191 */       this.fullLine = new JTextArea();
/* 192 */       this.fullLineHeight = BasePanel.GAP3;
/*     */     }
/* 194 */     this.fullLine.setEditable(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void init_300_setupScreen(boolean changeRow)
/*     */   {
/* 203 */     if (!isTree()) {
/* 204 */       this.actualPnl.addLineRE("Record", this.lineNum);
/*     */     }
/*     */     
/* 207 */     if (this.fileMaster.isBinaryFile()) {
/* 208 */       this.actualPnl.addLineRE("1 line Hex", this.oneLineHex);
/*     */     }
/*     */     
/*     */ 
/* 212 */     this.actualPnl.addComponentRE(1, 5, -1.0D, BasePanel.GAP, 2, 2, this.tblDetails);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 218 */     if (changeRow) {
/* 219 */       if (!this.layout.isXml()) {
/* 220 */         this.actualPnl.addComponentRE(1, 5, this.fullLineHeight, BasePanel.GAP, 2, 2, new JScrollPane(this.fullLine));
/*     */       }
/*     */       
/*     */ 
/* 224 */       setDirectionButtonStatus();
/* 225 */       this.actualPnl.addComponentRE(1, 5, -2.0D, BasePanel.GAP, 2, 2, this.btnPanel);
/*     */     }
/*     */     else {
/* 228 */       Common.calcColumnWidths(this.tblDetails, 0);
/*     */       
/* 230 */       int w1 = 84 * SwingUtils.CHAR_FIELD_WIDTH;
/* 231 */       int w2 = this.tblDetails.getPreferredSize().width;
/* 232 */       if ((w2 > 0) && (w1 > w2)) {
/* 233 */         w1 = w2;
/*     */       }
/* 235 */       Dimension d = new Dimension(w1 + 6 * SwingUtils.CHAR_FIELD_WIDTH, this.actualPnl.getPreferredSize().height);
/* 236 */       this.actualPnl.setPreferredSize(d);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setScreenSize(boolean mainframe)
/*     */   {
/* 246 */     if (mainframe) {
/* 247 */       DisplayFrame parentFrame = getParentFrame();
/* 248 */       int preferedWidth = Math.min(this.screenSize.width - 2, (this.fileMaster.isBinaryFile() ? 111 : 88) * SwingUtils.CHAR_FIELD_WIDTH);
/*     */       
/*     */ 
/* 251 */       parentFrame.bldScreen();
/* 252 */       parentFrame.setBounds(parentFrame.getY(), parentFrame.getX(), preferedWidth, Math.min(parentFrame.getHeight(), this.screenSize.height - 5));
/*     */       
/* 254 */       parentFrame.show();
/* 255 */       parentFrame.setToMaximum(false);
/* 256 */       parentFrame.addCloseOnEsc(this.actualPnl);
/*     */     } else {
/* 258 */       this.actualPnl.done();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void closeWindow()
/*     */   {
/*     */     FileView fv;
/*     */     
/*     */ 
/* 269 */     if ((fv = getFileView()) != null) {
/* 270 */       fv.removeTableModelListener(this);
/* 271 */       fv.removeTreeModelListener(this);
/*     */     }
/*     */     
/* 274 */     super.closeWindow();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void setColWidths()
/*     */   {
/* 283 */     JTable table = getJTable();
/* 284 */     if (table != null) {
/* 285 */       int col = this.record.firstDataColumn;
/* 286 */       setStandardColumnWidths(col);
/* 287 */       TableColumn tc = table.getColumnModel().getColumn(col++);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 297 */       tc = table.getColumnModel().getColumn(col++);
/* 298 */       tc.setPreferredWidth(180);
/*     */       
/* 300 */       if ((this.fileView != null) && (this.fileView.isBinaryFile())) {
/* 301 */         tc = table.getColumnModel().getColumn(col++);
/* 302 */         tc.setPreferredWidth(180);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void ap_100_setHexFormat()
/*     */   {
/* 312 */     JTable table = getJTable();
/* 313 */     TableColumn tc = table.getColumnModel().getColumn(this.record.hexColumn);
/*     */     
/* 315 */     this.record.setOneLineHex(this.oneLineHex.isSelected());
/* 316 */     if (this.oneLineHex.isSelected()) {
/* 317 */       tc.setCellRenderer(this.defaultHexRendor);
/*     */       
/* 319 */       table.setRowHeight(this.stdCellHeight);
/*     */     } else {
/* 321 */       if (this.hexRendor == null) {
/* 322 */         this.hexRendor = new HexThreeLineRender(getFileView().getLayout().getFontName());
/*     */       }
/* 324 */       table.setRowHeight(this.threeLineHeight);
/* 325 */       tc.setCellRenderer(this.hexRendor);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setFullLine()
/*     */   {
/* 335 */     AbstractLine l = this.record.getCurrentLine();
/* 336 */     if (l != null) {
/* 337 */       if ((this.fileMaster.isBinaryFile()) || (this.layout.isBinCSV())) {
/* 338 */         this.hexLine.setHex(l.getData());
/*     */       } else
/* 340 */         this.fullLine.setText(l.getFullLine());
/*     */     }
/*     */   }
/*     */   
/*     */   protected abstract void setDirectionButtonStatus();
/*     */   
/*     */   protected boolean isTree() {
/* 347 */     return this.layout.hasChildren();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCurrRow(int newRow, int layoutId, int fieldNum) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void treeNodesChanged(TreeModelEvent arg0)
/*     */   {
/* 368 */     this.record.fireTableDataChanged();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void treeNodesInserted(TreeModelEvent arg0)
/*     */   {
/* 377 */     this.record.fireTableDataChanged();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void treeNodesRemoved(TreeModelEvent event)
/*     */   {
/* 390 */     Object[] c = event.getChildren();
/* 391 */     for (int i = 0; i < c.length; i++) {
/* 392 */       if (isThisLineDeleted(c[i])) {
/* 393 */         return;
/*     */       }
/*     */     }
/*     */     
/* 397 */     this.record.fireTableDataChanged();
/*     */   }
/*     */   
/*     */   private boolean isThisLineDeleted(Object o)
/*     */   {
/* 402 */     if ((o instanceof AbstractLineNode)) {
/* 403 */       AbstractLineNode n = (AbstractLineNode)o;
/* 404 */       if (n.getLine() == this.record.getCurrentLine()) {
/* 405 */         getParentFrame().close(this);
/*     */         
/* 407 */         return true;
/*     */       }
/*     */     }
/* 410 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void treeStructureChanged(TreeModelEvent arg0)
/*     */   {
/* 419 */     this.record.fireTableDataChanged();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void tableChanged(TableModelEvent arg0)
/*     */   {
/* 428 */     this.record.fireTableDataChanged();
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/BaseLineFrame.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */