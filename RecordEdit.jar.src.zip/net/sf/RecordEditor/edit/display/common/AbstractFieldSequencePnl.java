package net.sf.RecordEditor.edit.display.common;

import net.sf.RecordEditor.jibx.compare.FieldSequence;
import net.sf.RecordEditor.re.display.AbstractFileDisplay;

public abstract interface AbstractFieldSequencePnl
  extends AbstractFileDisplay
{
  public abstract FieldSequence getFieldSequence();
  
  public abstract void setFieldSequence(FieldSequence paramFieldSequence);
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/common/AbstractFieldSequencePnl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */