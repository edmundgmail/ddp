package net.sf.RecordEditor.edit.display.common;

public abstract interface AbstractRowChangedListner
{
  public abstract void checkForTblRowChange(int paramInt);
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/common/AbstractRowChangedListner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */