package net.sf.RecordEditor.edit.display.common;

import net.sf.JRecord.Details.AbstractLayoutDetails;

public abstract interface ILayoutChanged
{
  public abstract void layoutChanged(AbstractLayoutDetails paramAbstractLayoutDetails);
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/common/ILayoutChanged.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */