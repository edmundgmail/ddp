/*     */ package net.sf.RecordEditor.edit.display.extension;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JTable;
/*     */ import net.sf.RecordEditor.edit.display.BaseDisplay;
/*     */ import net.sf.RecordEditor.edit.display.DisplayFrame;
/*     */ import net.sf.RecordEditor.edit.display.util.LinePosition;
/*     */ import net.sf.RecordEditor.edit.display.util.MovementBtnPnl;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplayWithFieldHide;
/*     */ import net.sf.RecordEditor.re.display.IClosablePanel;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RecordSelection
/*     */   extends BaseDisplay
/*     */   implements AbstractFileDisplayWithFieldHide, IClosablePanel
/*     */ {
/*     */   private MovementBtnPnl movementPnl;
/*     */   protected SplitPaneRecord splitPane;
/*     */   
/*     */   public RecordSelection(String formType, FileView viewOfFile, int lineNo)
/*     */   {
/*  31 */     super(formType, viewOfFile, false, false, false, false, false, 4);
/*     */     
/*  33 */     this.splitPane = new SplitPaneRecord(this, viewOfFile, lineNo);
/*     */     
/*  35 */     setJTable(new JTable());
/*     */   }
/*     */   
/*     */ 
/*     */   protected final void init_200_layoutScreen()
/*     */   {
/*  41 */     this.movementPnl = new MovementBtnPnl(Common.getArrowIcons(), true, new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent event) {
/*  44 */         RecordSelection.this.btnPressed(event);
/*     */       }
/*     */       
/*  47 */     });
/*  48 */     this.splitPane.layoutFieldPane();
/*     */     
/*  50 */     this.actualPnl.addComponentRE(1, 3, -1.0D, BasePanel.GAP, 2, 2, this.splitPane.splitPane);
/*     */     
/*     */ 
/*  53 */     this.actualPnl.addComponentRE(1, 5, -2.0D, BasePanel.GAP, 2, 2, this.movementPnl);
/*     */     
/*  55 */     this.actualPnl.done();
/*  56 */     setDirectionButtonStatus();
/*     */   }
/*     */   
/*     */ 
/*     */   public void setScreenSize(boolean mainframe, int width, int height)
/*     */   {
/*  62 */     if (mainframe) {
/*  63 */       DisplayFrame parentFrame = getParentFrame();
/*     */       
/*  65 */       parentFrame.bldScreen();
/*  66 */       parentFrame.setBounds(parentFrame.getY(), parentFrame.getX(), width, height);
/*  67 */       parentFrame.show();
/*  68 */       parentFrame.setToMaximum(false);
/*  69 */       parentFrame.addCloseOnEsc(this.actualPnl);
/*     */     } else {
/*  71 */       this.actualPnl.done();
/*     */     }
/*     */   }
/*     */   
/*     */   private void btnPressed(ActionEvent event)
/*     */   {
/*  77 */     if (event.getSource() == this.movementPnl.buttons[0]) {
/*  78 */       this.splitPane.setCurrRow(0);
/*  79 */     } else if ((event.getSource() == this.movementPnl.buttons[1]) && (this.splitPane.getCurrRow() > 0)) {
/*  80 */       this.splitPane.setCurrRow(this.splitPane.getCurrRow() - 1);
/*  81 */     } else if (event.getSource() == this.movementPnl.buttons[2]) {
/*  82 */       this.splitPane.setCurrRow(this.splitPane.getCurrRow() + 1);
/*  83 */     } else if (event.getSource() == this.movementPnl.buttons[3]) {
/*  84 */       this.splitPane.setCurrRow(getFileView().getRowCount() - 1);
/*     */     }
/*     */     
/*  87 */     setDirectionButtonStatus();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setDirectionButtonStatus()
/*     */   {
/*  96 */     boolean allowBack = this.splitPane.getCurrRow() > 0;
/*  97 */     boolean allowForward = (this.fileView != null) && (this.splitPane.getCurrRow() < this.fileView.getRowCount() - 1);
/*     */     
/*  99 */     this.movementPnl.buttons[0].setEnabled(allowBack);
/* 100 */     this.movementPnl.buttons[1].setEnabled(allowBack);
/* 101 */     this.movementPnl.buttons[2].setEnabled(allowForward);
/* 102 */     this.movementPnl.buttons[3].setEnabled(allowForward);
/*     */   }
/*     */   
/*     */   protected int getInsertAfterPosition()
/*     */   {
/* 107 */     return getStandardPosition();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected LinePosition getInsertAfterLine(boolean prev)
/*     */   {
/* 115 */     return super.getInsertAfterLine(this.splitPane.getCurrRow(), prev);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void fireLayoutIndexChanged() {}
/*     */   
/*     */ 
/*     */ 
/*     */   public final int[] getSelectedRows()
/*     */   {
/* 127 */     return new int[] { getCurrRow() };
/*     */   }
/*     */   
/*     */   public int getCurrRow()
/*     */   {
/* 132 */     return this.splitPane.getCurrRow();
/*     */   }
/*     */   
/*     */   public void checkForTblRowChange(int row) {
/* 136 */     if (this.splitPane.getCurrRow() != row) {
/* 137 */       setCurrRow(row);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setCurrRow(int newRow)
/*     */   {
/* 143 */     this.splitPane.setCurrRow(newRow);
/*     */   }
/*     */   
/*     */   public void setCurrRow(int newRow, int layoutId, int fieldNum)
/*     */   {
/* 148 */     setCurrRow(newRow);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean[] getFieldVisibility(int recordIndex)
/*     */   {
/* 155 */     return this.splitPane.getFieldVisibility(recordIndex);
/*     */   }
/*     */   
/*     */   public void setFieldVisibility(int recordIndex, boolean[] fieldVisibility)
/*     */   {
/* 160 */     this.splitPane.setFieldVisibility(recordIndex, fieldVisibility);
/*     */   }
/*     */   
/*     */ 
/*     */   public void stopCellEditing()
/*     */   {
/* 166 */     this.splitPane.flush();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void executeAction(int action)
/*     */   {
/* 174 */     if (action == 31) {
/* 175 */       getFileView().repeatLine(this.splitPane.getCurrRow());
/* 176 */       this.splitPane.setCurrRow(this.splitPane.getCurrRow() + 1);
/*     */     } else {
/* 178 */       super.executeAction(action);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isActionAvailable(int action)
/*     */   {
/* 187 */     return (action == 31) || (super.isActionAvailable(action));
/*     */   }
/*     */   
/*     */   public void insertLine(int adj) {
/* 191 */     this.splitPane.setCurrRow(this.fileView.newLine(getInsertAfterPosition(), adj));
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/extension/RecordSelection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */