/*     */ package net.sf.RecordEditor.edit.display.extension;
/*     */ 
/*     */ import java.awt.event.FocusAdapter;
/*     */ import java.awt.event.FocusEvent;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.event.TableModelEvent;
/*     */ import javax.swing.event.TableModelListener;
/*     */ import javax.swing.text.JTextComponent;
/*     */ import net.sf.JRecord.Common.Conversion;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.RecordEditor.re.display.IClosablePanel;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.swing.common.UpdatableItem;
/*     */ import org.jdesktop.swingx.JXMultiSplitPane;
/*     */ import org.jdesktop.swingx.MultiSplitLayout;
/*     */ import org.jdesktop.swingx.MultiSplitLayout.Divider;
/*     */ import org.jdesktop.swingx.MultiSplitLayout.Leaf;
/*     */ import org.jdesktop.swingx.MultiSplitLayout.Node;
/*     */ import org.jdesktop.swingx.MultiSplitLayout.Split;
/*     */ 
/*     */ public class SplitPaneRecord implements TableModelListener
/*     */ {
/*     */   private FileView fileView;
/*  27 */   private int currRow = 0;
/*     */   
/*     */   private final IClosablePanel parent;
/*     */   private AbstractLine line;
/*  31 */   public final JXMultiSplitPane splitPane = new JXMultiSplitPane();
/*     */   
/*     */   private PaneDtls[] fields;
/*     */   
/*     */   private double[] weight;
/*     */   
/*  37 */   private FocusAdapter focusListner = new FocusAdapter()
/*     */   {
/*     */ 
/*     */ 
/*     */     public void focusLost(FocusEvent e)
/*     */     {
/*     */ 
/*  44 */       if ((SplitPaneRecord.this.line != null) && (SplitPaneRecord.this.fields != null) && (e != null) && (e.getComponent() != null)) {
/*  45 */         for (PaneDtls p : SplitPaneRecord.this.fields) {
/*  46 */           if (e.getComponent() == p.fld) {
/*  47 */             SplitPaneRecord.this.updateRow(p, e.getComponent());
/*  48 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   };
/*     */   
/*     */   public SplitPaneRecord(IClosablePanel parentPnl, FileView viewOfFile, int lineNo)
/*     */   {
/*  57 */     this.parent = parentPnl;
/*  58 */     this.fileView = viewOfFile;
/*  59 */     this.currRow = lineNo;
/*     */     
/*  61 */     this.line = this.fileView.getLine(this.currRow);
/*     */     
/*  63 */     this.splitPane.setModel(new org.jdesktop.swingx.multisplitpane.DefaultSplitPaneModel());
/*     */     
/*  65 */     this.fileView.addTableModelListener(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void layoutFieldPane()
/*     */   {
/*  75 */     MultiSplitLayout.Split layoutDef = new MultiSplitLayout.Split();
/*     */     
/*  77 */     ArrayList<ArrayList<MultiSplitLayout.Node>> rows = new ArrayList();
/*  78 */     rows.add(new ArrayList(this.fields.length * 2));
/*  79 */     ArrayList<MultiSplitLayout.Node> nodes = new ArrayList(this.fields.length);
/*     */     
/*     */ 
/*  82 */     setTxtFields();
/*     */     
/*  84 */     for (int i = 0; i < this.fields.length; i++) {
/*  85 */       if (this.fields[i].isVisible()) {
/*  86 */         int idx = this.fields[i].col;
/*  87 */         while (rows.size() <= idx) {
/*  88 */           rows.add(new ArrayList(this.fields.length));
/*     */         }
/*  90 */         if (((ArrayList)rows.get(idx)).size() > 0) {
/*  91 */           ((ArrayList)rows.get(idx)).add(new MultiSplitLayout.Divider());
/*     */         }
/*     */         
/*  94 */         MultiSplitLayout.Leaf l = new MultiSplitLayout.Leaf(this.fields[i].name);
/*  95 */         ((ArrayList)rows.get(idx)).add(l);
/*  96 */         nodes.add(l);
/*  97 */         if (this.fields[i].weight > 0.0D) {
/*  98 */           l.setWeight(this.fields[i].weight);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 103 */     switch (nodes.size()) {
/*     */     case 0: 
/* 105 */       this.splitPane.setLayout(new MultiSplitLayout(new MultiSplitLayout.Leaf("0")));
/* 106 */       this.splitPane.add(new JPanel(), "0");
/* 107 */       break;
/*     */     case 1: 
/* 109 */       this.splitPane.setLayout(new MultiSplitLayout((MultiSplitLayout.Node)nodes.get(0)));
/* 110 */       break;
/*     */     default: 
/* 112 */       for (int i = rows.size() - 1; i >= 0; i--) {
/* 113 */         if (((ArrayList)rows.get(i)).size() == 0) {
/* 114 */           rows.remove(i);
/*     */         }
/*     */       }
/*     */       
/* 118 */       if (rows.size() == 1) {
/* 119 */         layoutDef.setRowLayout(false);
/* 120 */         layoutDef.setChildren((List)rows.get(0));
/*     */       } else {
/* 122 */         ArrayList<MultiSplitLayout.Node> rowDefs = new ArrayList(rows.size() * 2);
/* 123 */         MultiSplitLayout.Split rowDef = new MultiSplitLayout.Split();
/*     */         
/* 125 */         for (int i = 0; i < rows.size(); i++) {
/* 126 */           if (rowDefs.size() > 0) {
/* 127 */             rowDefs.add(new MultiSplitLayout.Divider());
/*     */           }
/* 129 */           switch (((ArrayList)rows.get(i)).size()) {
/*     */           case 0: 
/*     */             break;
/* 132 */           case 1:  rowDefs.add(((ArrayList)rows.get(i)).get(0));
/* 133 */             if ((this.weight != null) && (i < this.weight.length) && (this.weight[i] > 0.0D)) {
/* 134 */               ((MultiSplitLayout.Node)((ArrayList)rows.get(i)).get(0)).setWeight(this.weight[i]);
/*     */             }
/*     */             break;
/*     */           default: 
/* 138 */             rowDef = new MultiSplitLayout.Split();
/*     */             
/* 140 */             rowDef.setRowLayout(false);
/* 141 */             rowDef.setChildren((List)rows.get(i));
/*     */             
/* 143 */             if ((this.weight != null) && (i < this.weight.length) && (this.weight[i] > 0.0D)) {
/* 144 */               rowDef.setWeight(this.weight[i]);
/*     */             }
/* 146 */             rowDefs.add(rowDef);
/*     */           }
/*     */           
/*     */         }
/* 150 */         layoutDef.setRowLayout(true);
/* 151 */         layoutDef.setChildren(rowDefs);
/*     */       }
/*     */       
/* 154 */       this.splitPane.setLayout(new MultiSplitLayout(layoutDef));
/*     */     }
/* 156 */     for (int i = 0; i < this.fields.length; i++) {
/* 157 */       if (this.fields[i].isVisible()) {
/* 158 */         this.splitPane.add(this.fields[i].getDisplayPane(), this.fields[i].name);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractLine getLine()
/*     */   {
/* 168 */     return this.line;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCurrRow()
/*     */   {
/* 177 */     return this.currRow;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setCurrRow(int newRow)
/*     */   {
/* 183 */     if (newRow >= 0) {
/* 184 */       if ((this.line != null) && (this.fields != null)) {
/* 185 */         for (PaneDtls p : this.fields) {
/* 186 */           if ((p.txtFld != null) && (p.txtFld.hasFocus()) && (p.fieldDef != null) && (!p.isHtml())) {
/*     */             try {
/* 188 */               this.line.setField(0, p.fieldDef.fieldIdx, p.txtFld.getText());
/* 189 */               this.fileView.fireRowUpdated(this.currRow, 0, p.fieldDef.fieldIdx, this.line);
/*     */             } catch (Exception ex) {
/* 191 */               ex.printStackTrace();
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 197 */       this.line = this.fileView.getLine(newRow);
/* 198 */       if (this.currRow != newRow) {
/* 199 */         this.currRow = newRow;
/* 200 */         rowChanged();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setCurrRow(int newRow, int layoutId, int fieldNum)
/*     */   {
/* 209 */     setCurrRow(newRow);
/*     */   }
/*     */   
/*     */ 
/*     */   private void rowChanged()
/*     */   {
/* 215 */     if (this.fileView.getRowCount() <= 0) {
/* 216 */       this.parent.closePanel();
/* 217 */       return;
/*     */     }
/*     */     
/* 220 */     if (this.currRow < 0) {
/* 221 */       this.currRow = 0;
/* 222 */     } else if (this.currRow >= this.fileView.getRowCount()) {
/* 223 */       this.currRow = (this.fileView.getRowCount() - 1);
/*     */     }
/*     */     
/* 226 */     this.line = this.fileView.getLine(this.currRow);
/*     */     
/*     */ 
/* 229 */     setTxtFields();
/*     */     
/* 231 */     this.splitPane.revalidate();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setTxtFields()
/*     */   {
/* 240 */     for (int i = 0; i < this.fields.length; i++) {
/* 241 */       if ((this.fields[i].txtFld != null) && (this.fields[i].fieldDef != null)) {
/* 242 */         String s = getFieldVal(this.fields[i].fieldDef);
/* 243 */         if (((this.fields[i].htmlType == PaneDtls.HTML_IF_HTML_TAG) && (s != null) && (!s.toLowerCase().startsWith("<html>"))) || ((this.fields[i].htmlType == PaneDtls.IS_HTML) && (!Conversion.isHtml(s))))
/*     */         {
/* 245 */           s = "";
/*     */         }
/* 247 */         this.fields[i].txtFld.setText(s);
/* 248 */       } else if ((this.fields[i].fld instanceof UpdatableItem)) {
/* 249 */         ((UpdatableItem)this.fields[i].fld).setValue(this.line.getField(0, this.fields[i].fieldDef.fieldIdx));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFields(PaneDtls[] newFields, double[] newWeight)
/*     */   {
/* 260 */     if (this.fields != null) {
/* 261 */       for (PaneDtls p : this.fields) {
/* 262 */         if ((p.fld != null) && (p.fieldDef != null) && (!p.isHtml())) {
/* 263 */           p.fld.removeFocusListener(this.focusListner);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 268 */     this.fields = newFields;
/* 269 */     this.weight = newWeight;
/*     */     
/* 271 */     for (PaneDtls p : newFields) {
/* 272 */       if ((p.fld != null) && (p.fieldDef != null) && (!p.isHtml())) {
/* 273 */         p.fld.addFocusListener(this.focusListner);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public final String getFieldVal(FieldDef fld) {
/* 279 */     String s = "";
/* 280 */     Object o = this.line.getField(0, fld.fieldIdx);
/*     */     
/* 282 */     if (o != null) {
/* 283 */       s = o.toString();
/*     */     }
/*     */     
/* 286 */     return s;
/*     */   }
/*     */   
/*     */   public final boolean[] getFieldVisibility(int recordIndex)
/*     */   {
/* 291 */     if ((recordIndex == 0) && (this.line != null)) {
/* 292 */       boolean[] b = new boolean[this.line.getLayout().getRecord(0).getFieldCount()];
/* 293 */       for (int i = 0; i < b.length; i++) {
/* 294 */         b[i] = false;
/*     */       }
/*     */       
/* 297 */       for (PaneDtls p : this.fields) {
/* 298 */         if ((p.fieldDef != null) && (!p.isHtml()) && (p.fieldDef.fieldIdx >= 0) && 
/* 299 */           (p.isVisible())) {
/* 300 */           b[p.fieldDef.fieldIdx] = true;
/*     */         }
/*     */       }
/*     */       
/* 304 */       return b;
/*     */     }
/* 306 */     return null;
/*     */   }
/*     */   
/*     */   public final void setFieldVisibility(int recordIndex, boolean[] fieldVisibility)
/*     */   {
/* 311 */     if ((recordIndex == 0) && (this.line != null)) {
/* 312 */       for (PaneDtls p : this.fields) {
/* 313 */         if (p.fieldDef.fieldIdx >= 0) {
/* 314 */           p.setVisible(fieldVisibility[p.fieldDef.fieldIdx]);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 323 */       this.splitPane.removeAll();
/*     */       
/* 325 */       layoutFieldPane();
/* 326 */       this.splitPane.revalidate();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void flush()
/*     */   {
/* 342 */     for (PaneDtls p : this.fields) {
/* 343 */       if ((p.fld != null) && (p.fld.hasFocus())) {
/* 344 */         updateRow(p, p.fld);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void updateRow(PaneDtls p, Object component)
/*     */   {
/*     */     try {
/* 352 */       Object oldVal = this.line.getField(0, p.fieldDef.fieldIdx);
/* 353 */       Object val; if ((component == p.txtFld) && (p.fieldDef != null) && (!p.isHtml())) {
/* 354 */         val = p.txtFld.getText(); } else { Object val;
/* 355 */         if ((p.fld instanceof UpdatableItem))
/* 356 */           val = ((UpdatableItem)p.fld).getValue(); else
/*     */           return;
/*     */       }
/*     */       Object val;
/* 360 */       if ((val != oldVal) && ((val == null) || (!val.equals(oldVal))))
/*     */       {
/*     */ 
/*     */ 
/* 364 */         this.line.setField(0, p.fieldDef.fieldIdx, val);
/* 365 */         this.fileView.setChanged(true);
/* 366 */         this.fileView.fireRowUpdated(this.currRow, 0, p.fieldDef.fieldIdx, this.line);
/*     */       }
/*     */     } catch (Exception ex) {
/* 369 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void tableChanged(TableModelEvent event)
/*     */   {
/* 381 */     switch (event.getType()) {
/*     */     case 1: 
/* 383 */       if (event.getFirstRow() <= this.currRow) {
/* 384 */         this.currRow += event.getLastRow() - event.getFirstRow() + 1;
/* 385 */         rowChanged();
/*     */       }
/*     */       
/*     */       break;
/*     */     case -1: 
/* 390 */       if (this.currRow > event.getLastRow()) {
/* 391 */         this.currRow -= event.getLastRow() - event.getFirstRow() + 1;
/*     */       }
/* 393 */       else if (this.currRow > event.getFirstRow()) {
/* 394 */         this.currRow -= Math.min(this.fileView.getRowCount(), event.getFirstRow());
/*     */       }
/*     */       
/* 397 */       javax.swing.SwingUtilities.invokeLater(new Runnable()
/*     */       {
/*     */         public void run() {
/* 400 */           SplitPaneRecord.this.rowChanged();
/*     */         }
/* 402 */       });
/* 403 */       break;
/*     */     case 0: 
/* 405 */       if ((event.getFirstRow() <= this.currRow) && (event.getLastRow() >= this.currRow)) {
/* 406 */         setTxtFields();
/*     */       }
/*     */       break;
/*     */     default: 
/* 410 */       this.currRow = this.fileView.indexOf(this.line);
/* 411 */       rowChanged();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/extension/SplitPaneRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */