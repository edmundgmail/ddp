package net.sf.RecordEditor.edit.display.extension;

import net.sf.RecordEditor.re.display.AbstractFileDisplay;

public abstract interface IChildScreen
  extends AbstractFileDisplay
{
  public abstract void setCurrRow(int paramInt);
  
  public abstract void flush();
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/extension/IChildScreen.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */