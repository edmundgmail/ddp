/*     */ package net.sf.RecordEditor.edit.display.extension;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.FocusAdapter;
/*     */ import java.awt.event.FocusEvent;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.event.TableModelEvent;
/*     */ import javax.swing.event.TableModelListener;
/*     */ import javax.swing.text.JTextComponent;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.RecordEditor.edit.display.BaseDisplay;
/*     */ import net.sf.RecordEditor.edit.display.DisplayFrame;
/*     */ import net.sf.RecordEditor.edit.display.util.LinePosition;
/*     */ import net.sf.RecordEditor.edit.display.util.MovementBtnPnl;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplayWithFieldHide;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import org.jdesktop.swingx.JXMultiSplitPane;
/*     */ import org.jdesktop.swingx.MultiSplitLayout.Divider;
/*     */ import org.jdesktop.swingx.MultiSplitLayout.Node;
/*     */ import org.jdesktop.swingx.MultiSplitLayout.Split;
/*     */ import org.jdesktop.swingx.multisplitpane.DefaultSplitPaneModel;
/*     */ 
/*     */ public abstract class ZCopyOfRecordSelection extends BaseDisplay implements IChildScreen, AbstractFileDisplayWithFieldHide, TableModelListener
/*     */ {
/*  33 */   protected int currRow = 0;
/*     */   
/*     */   protected AbstractLine line;
/*  36 */   protected JXMultiSplitPane splitPane = new JXMultiSplitPane();
/*     */   
/*     */   private MovementBtnPnl movementPnl;
/*     */   
/*     */   private PaneDtls[] fields;
/*     */   
/*  42 */   private FocusAdapter focusListner = new FocusAdapter()
/*     */   {
/*     */ 
/*     */ 
/*     */     public void focusLost(FocusEvent e)
/*     */     {
/*     */ 
/*  49 */       if ((ZCopyOfRecordSelection.this.line != null) && (ZCopyOfRecordSelection.this.fields != null) && (e != null) && (e.getComponent() != null)) {
/*  50 */         for (PaneDtls p : ZCopyOfRecordSelection.this.fields) {
/*  51 */           if ((e.getComponent() == p.txtFld) && (p.fieldDef != null)) {
/*     */             try {
/*  53 */               ZCopyOfRecordSelection.this.line.setField(0, p.fieldDef.fieldIdx, p.txtFld.getText());
/*  54 */               ZCopyOfRecordSelection.this.fileView.fireRowUpdated(ZCopyOfRecordSelection.this.currRow, null, ZCopyOfRecordSelection.this.line);
/*     */             } catch (Exception ex) {
/*  56 */               ex.printStackTrace();
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */   public ZCopyOfRecordSelection(String formType, FileView viewOfFile, int lineNo)
/*     */   {
/*  68 */     super(formType, viewOfFile, false, false, false, false, false, 4);
/*     */     
/*  70 */     this.currRow = lineNo;
/*  71 */     this.line = this.fileView.getLine(this.currRow);
/*     */     
/*  73 */     setJTable(new JTable());
/*  74 */     this.splitPane.setModel(new DefaultSplitPaneModel());
/*     */     
/*  76 */     this.fileView.addTableModelListener(this);
/*     */   }
/*     */   
/*     */ 
/*     */   protected final void init_200_layoutScreen()
/*     */   {
/*  82 */     this.movementPnl = new MovementBtnPnl(Common.getArrowIcons(), true, new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent event)
/*     */       {
/*  86 */         ZCopyOfRecordSelection.this.btnPressed(event);
/*     */       }
/*  88 */     });
/*  89 */     layoutFieldPane();
/*     */     
/*  91 */     this.actualPnl.addComponentRE(1, 3, -1.0D, BasePanel.GAP, 2, 2, new javax.swing.JScrollPane(this.splitPane));
/*     */     
/*     */ 
/*  94 */     this.actualPnl.addComponentRE(1, 5, -2.0D, BasePanel.GAP, 2, 2, this.movementPnl);
/*     */     
/*  96 */     this.actualPnl.done();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void layoutFieldPane()
/*     */   {
/* 104 */     MultiSplitLayout.Split layoutDef = new MultiSplitLayout.Split();
/*     */     
/* 106 */     ArrayList<ArrayList<MultiSplitLayout.Node>> rows = new ArrayList();
/* 107 */     rows.add(new ArrayList(this.fields.length * 2));
/*     */     
/*     */ 
/* 110 */     setTxtFields();
/*     */     
/* 112 */     for (int i = 0; i < this.fields.length; i++) {
/* 113 */       int idx = this.fields[i].col;
/* 114 */       while (rows.size() <= idx) {
/* 115 */         rows.add(new ArrayList(this.fields.length));
/*     */       }
/* 117 */       if (((ArrayList)rows.get(idx)).size() > 0) {
/* 118 */         ((ArrayList)rows.get(idx)).add(new MultiSplitLayout.Divider());
/*     */       }
/* 120 */       ((ArrayList)rows.get(idx)).add(new org.jdesktop.swingx.MultiSplitLayout.Leaf(this.fields[i].name));
/*     */     }
/*     */     
/* 123 */     if (rows.size() == 1) {
/* 124 */       layoutDef.setRowLayout(false);
/* 125 */       layoutDef.setChildren((List)rows.get(0));
/*     */     } else {
/* 127 */       ArrayList<MultiSplitLayout.Node> rowDefs = new ArrayList();
/* 128 */       MultiSplitLayout.Split rowDef = new MultiSplitLayout.Split();
/*     */       
/* 130 */       rowDef.setRowLayout(false);
/* 131 */       rowDef.setChildren((List)rows.get(0));
/* 132 */       rowDefs.add(rowDef);
/* 133 */       for (int i = 0; i < rows.size(); i++) {
/* 134 */         rowDefs.add(new MultiSplitLayout.Divider());
/* 135 */         rowDef = new MultiSplitLayout.Split();
/*     */         
/* 137 */         rowDef.setRowLayout(false);
/* 138 */         rowDef.setChildren((List)rows.get(0));
/* 139 */         rowDefs.add(rowDef);
/*     */       }
/*     */       
/* 142 */       layoutDef.setRowLayout(true);
/* 143 */       layoutDef.setChildren(rowDefs);
/*     */     }
/*     */     
/* 146 */     this.splitPane.setLayout(new org.jdesktop.swingx.MultiSplitLayout(layoutDef));
/* 147 */     for (int i = 0; i < this.fields.length; i++) {
/* 148 */       this.splitPane.add(this.fields[i].getDisplayPane(), this.fields[i].name);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void setScreenSize(boolean mainframe)
/*     */   {
/* 155 */     if (mainframe) {
/* 156 */       DisplayFrame parentFrame = getParentFrame();
/* 157 */       int preferedWidth = Math.min(this.screenSize.width - 2, 80 * SwingUtils.CHAR_FIELD_WIDTH);
/*     */       
/*     */ 
/* 160 */       parentFrame.bldScreen();
/* 161 */       parentFrame.setBounds(parentFrame.getY(), parentFrame.getX(), preferedWidth, Math.min(parentFrame.getHeight(), this.screenSize.height - 5));
/*     */       
/* 163 */       parentFrame.show();
/* 164 */       parentFrame.setToMaximum(false);
/* 165 */       parentFrame.addCloseOnEsc(this.actualPnl);
/*     */     } else {
/* 167 */       this.actualPnl.done();
/*     */     }
/*     */   }
/*     */   
/*     */   private void btnPressed(ActionEvent event) {
/* 172 */     if (event.getSource() == this.movementPnl.buttons[0]) {
/* 173 */       this.currRow = 0;
/* 174 */       rowChanged();
/* 175 */     } else if ((event.getSource() == this.movementPnl.buttons[1]) && (this.currRow > 0)) {
/* 176 */       this.currRow -= 1;
/* 177 */       rowChanged();
/* 178 */     } else if (event.getSource() == this.movementPnl.buttons[2]) {
/* 179 */       this.currRow += 1;
/* 180 */       rowChanged();
/* 181 */     } else if (event.getSource() == this.movementPnl.buttons[3]) {
/* 182 */       this.currRow = (getFileView().getRowCount() - 1);
/* 183 */       rowChanged();
/*     */     }
/*     */   }
/*     */   
/*     */   protected int getInsertAfterPosition()
/*     */   {
/* 189 */     return getStandardPosition();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected LinePosition getInsertAfterLine(boolean prev)
/*     */   {
/* 197 */     return super.getInsertAfterLine(this.currRow, prev);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void fireLayoutIndexChanged() {}
/*     */   
/*     */ 
/*     */   public int getCurrRow()
/*     */   {
/* 207 */     return this.currRow;
/*     */   }
/*     */   
/*     */ 
/*     */   public void setCurrRow(int newRow)
/*     */   {
/* 213 */     if (newRow >= 0) {
/* 214 */       this.line = this.fileView.getLine(newRow);
/* 215 */       if (this.currRow != newRow) {
/* 216 */         this.currRow = newRow;
/* 217 */         rowChanged();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void setCurrRow(int newRow, int layoutId, int fieldNum)
/*     */   {
/* 224 */     setCurrRow(newRow);
/*     */   }
/*     */   
/*     */   private void rowChanged()
/*     */   {
/* 229 */     this.line = this.fileView.getLine(this.currRow);
/*     */     
/* 231 */     setTxtFields();
/*     */     
/* 233 */     this.splitPane.revalidate();
/*     */   }
/*     */   
/*     */   protected void setTxtFields()
/*     */   {
/* 238 */     for (int i = 1; i < this.fields.length; i++) {
/* 239 */       if ((this.fields[i].txtFld != null) && (this.fields[i].fieldDef != null)) {
/* 240 */         this.fields[i].txtFld.setText(getFieldVal(this.fields[i].fieldDef));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFields(PaneDtls[] fields)
/*     */   {
/* 250 */     this.fields = fields;
/*     */     
/* 252 */     for (PaneDtls p : fields) {
/* 253 */       if ((p.txtFld != null) && (p.fieldDef != null)) {
/* 254 */         p.txtFld.addFocusListener(this.focusListner);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected final String getFieldVal(FieldDef fld) {
/* 260 */     String s = "";
/* 261 */     Object o = this.line.getField(0, fld.fieldIdx);
/*     */     
/* 263 */     if (o != null) {
/* 264 */       s = o.toString();
/*     */     }
/*     */     
/* 267 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean[] getFieldVisibility(int recordIndex)
/*     */   {
/* 273 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFieldVisibility(int recordIndex, boolean[] fieldVisibility) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void tableChanged(TableModelEvent event)
/*     */   {
/* 288 */     switch (event.getType()) {
/*     */     case 1: 
/* 290 */       if (event.getFirstRow() <= this.currRow) {
/* 291 */         this.currRow += event.getLastRow() - event.getFirstRow() + 1;
/* 292 */         rowChanged();
/*     */       }
/*     */       break;
/*     */     case -1: 
/* 296 */       if (this.currRow > event.getLastRow()) {
/* 297 */         this.currRow -= event.getLastRow() - event.getFirstRow() + 1;
/* 298 */         rowChanged();
/* 299 */       } else if (this.currRow > event.getFirstRow()) {
/* 300 */         this.currRow -= Math.min(this.fileView.getRowCount(), event.getFirstRow());
/* 301 */         rowChanged();
/*     */       }
/*     */       break;
/*     */     case 0: 
/* 305 */       if (event.getFirstRow() == this.currRow) {
/* 306 */         setTxtFields();
/*     */       }
/*     */       break;
/*     */     default: 
/* 310 */       this.currRow = this.fileView.indexOf(this.line);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/extension/ZCopyOfRecordSelection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */