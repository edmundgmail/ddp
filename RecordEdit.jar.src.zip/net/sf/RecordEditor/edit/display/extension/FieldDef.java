/*    */ package net.sf.RecordEditor.edit.display.extension;
/*    */ 
/*    */ import net.sf.RecordEditor.utils.StringMatch;
/*    */ 
/*    */ 
/*    */ public class FieldDef
/*    */   implements StringMatch
/*    */ {
/*    */   public final String name;
/*    */   public final int fieldIdx;
/*    */   public final boolean repeating;
/*    */   public final boolean multLine;
/*    */   public final boolean single;
/*    */   public final boolean couldHaveIndex;
/*    */   public final boolean stripQuote;
/*    */   
/*    */   public FieldDef(String name, int idx, boolean multLine, boolean repeating, boolean single, boolean couldHaveIndex, boolean stripQuote)
/*    */   {
/* 19 */     this.name = name;
/* 20 */     this.fieldIdx = idx;
/* 21 */     this.repeating = repeating;
/* 22 */     this.multLine = multLine;
/* 23 */     this.single = single;
/* 24 */     this.couldHaveIndex = couldHaveIndex;
/* 25 */     this.stripQuote = stripQuote;
/*    */   }
/*    */   
/*    */   public boolean isMatch(String s)
/*    */   {
/* 30 */     boolean ret = false;
/* 31 */     if (s.startsWith(this.name)) {
/* 32 */       ret = true;
/* 33 */     } else if (this.name.endsWith(" ")) {
/* 34 */       ret = s.equals(this.name.trim());
/*    */     }
/*    */     
/* 37 */     return ret;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/extension/FieldDef.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */