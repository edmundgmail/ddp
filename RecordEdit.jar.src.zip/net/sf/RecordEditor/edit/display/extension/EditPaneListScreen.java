/*     */ package net.sf.RecordEditor.edit.display.extension;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.MouseEvent;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.Action;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.event.TableModelEvent;
/*     */ import javax.swing.event.TableModelListener;
/*     */ import javax.swing.table.JTableHeader;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import net.sf.RecordEditor.edit.display.AbstractCreateChildScreen;
/*     */ import net.sf.RecordEditor.edit.display.Action.AutofitAction;
/*     */ import net.sf.RecordEditor.edit.display.BaseDisplay;
/*     */ import net.sf.RecordEditor.edit.display.BaseDisplay.DelKeyWatcher;
/*     */ import net.sf.RecordEditor.edit.display.BaseDisplay.HeaderRender;
/*     */ import net.sf.RecordEditor.edit.display.BaseDisplay.HeaderSort;
/*     */ import net.sf.RecordEditor.edit.display.DisplayFrame;
/*     */ import net.sf.RecordEditor.edit.display.common.AbstractRowChangedListner;
/*     */ import net.sf.RecordEditor.edit.display.util.RowChangeListner;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplayWithFieldHide;
/*     */ import net.sf.RecordEditor.re.file.FieldMapping;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.MenuPopupListener;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.ReAbstractAction;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReAction;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMainFrame;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.ButtonTableRendor;
/*     */ import net.sf.RecordEditor.utils.swing.FixedColumnScrollPane;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ public abstract class EditPaneListScreen extends BaseDisplay implements AbstractRowChangedListner, TableModelListener, AbstractFileDisplayWithFieldHide, AbstractCreateChildScreen
/*     */ {
/*     */   private static final int NUMBER_OF_CONTROL_COLUMNS = 2;
/*  40 */   private static final int DEFAULT_ROW_HEIGHT = SwingUtils.TABLE_ROW_HEIGHT * 7 / 2;
/*     */   
/*  42 */   protected int fixedPopupCol = 1;
/*  43 */   protected int mainPopupCol = 1;
/*  44 */   protected int popupRow = 1;
/*     */   private int lastRow;
/*     */   protected int currChildScreenPosition;
/*  47 */   private BaseDisplay.HeaderRender headerRender = new BaseDisplay.HeaderRender(this);
/*  48 */   private FixedColumnScrollPane tblScrollPane = null;
/*  49 */   private ButtonTableRendor tableBtn = new ButtonTableRendor();
/*     */   private RowChangeListner keyListner;
/*  51 */   private RowChangeListner keyListnerFixed; protected FieldMapping fieldMapping = null;
/*     */   
/*     */ 
/*     */   protected MenuPopupListener mainPopup;
/*     */   
/*     */   protected MenuPopupListener fixedPopupMenu;
/*     */   
/*     */   protected IChildScreen childScreen;
/*     */   
/*     */ 
/*     */   public EditPaneListScreen(String formType, FileView viewOfFile, boolean primary, boolean addFullLine, boolean fullList, boolean prefered, boolean hex, int option)
/*     */   {
/*  63 */     super(formType, viewOfFile, primary, addFullLine, fullList, prefered, hex, option);
/*     */     
/*  65 */     this.fieldMapping = new FieldMapping(getFieldCounts());
/*     */     
/*  67 */     init_100_SetupJtables(viewOfFile);
/*     */     
/*  69 */     init_200_LayoutScreen();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void init_100_SetupJtables(FileView viewOfFile)
/*     */   {
/*  79 */     ReAction sort = new ReAction(30, this);
/*  80 */     AbstractAction editRecord = new ReAbstractAction("Edit Record", 26)
/*     */     {
/*     */       public void actionPerformed(ActionEvent e) {
/*  83 */         EditPaneListScreen.this.newLineFrame(EditPaneListScreen.this.fileView, EditPaneListScreen.this.popupRow);
/*     */       }
/*     */       
/*  86 */     };
/*  87 */     AbstractAction gotoLine = new net.sf.RecordEditor.edit.display.Action.GotoLineAction(this, this.fileView);
/*     */     
/*     */ 
/*     */ 
/*  91 */     AbstractAction[] mainActions = { sort, null, editRecord, gotoLine, null, new AutofitAction(this), null, new ReAbstractAction("Fix Column")
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 103 */       new ReAbstractAction
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         public void actionPerformed(ActionEvent e) {
/* 103 */           EditPaneListScreen.this.tblScrollPane.doFixColumn(EditPaneListScreen.this.mainPopupCol); } }, new ReAbstractAction("Hide Column")
/*     */       {
/*     */ 
/*     */         public void actionPerformed(ActionEvent e)
/*     */         {
/* 108 */           EditPaneListScreen.this.hideColumn(EditPaneListScreen.this.mainPopupCol);
/*     */         }
/*     */         
/*     */ 
/* 112 */       } };
/* 113 */     AbstractAction[] fixedActions = { sort, null, editRecord, gotoLine, null, new ReAbstractAction("Unfix Column")
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       public void actionPerformed(ActionEvent e)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 123 */         if (EditPaneListScreen.this.fixedPopupCol > 0)
/*     */         {
/* 125 */           EditPaneListScreen.this.tblScrollPane.doUnFixColumn(EditPaneListScreen.this.fixedPopupCol);
/*     */         }
/*     */         
/*     */       }
/*     */       
/* 130 */     } };
/* 131 */     JTable tableDetails = new JTable(viewOfFile);
/*     */     
/* 133 */     setJTable(tableDetails);
/* 134 */     this.tblScrollPane = new FixedColumnScrollPane(tableDetails);
/*     */     
/* 136 */     this.keyListner = new RowChangeListner(tableDetails, this);
/* 137 */     this.keyListnerFixed = new RowChangeListner(this.tblScrollPane.getFixedTable(), this);
/*     */     
/* 139 */     this.mainPopup = new MenuPopupListener(mainActions, true, tableDetails)
/*     */     {
/*     */ 
/*     */       public void mousePressed(MouseEvent e)
/*     */       {
/*     */ 
/* 145 */         super.mousePressed(e);
/* 146 */         JTable table = EditPaneListScreen.this.getJTable();
/*     */         
/* 148 */         int col = table.columnAtPoint(e.getPoint());
/* 149 */         int row = table.rowAtPoint(e.getPoint());
/*     */         
/* 151 */         EditPaneListScreen.this.checkForTblRowChange(row);
/* 152 */         if ((row >= 0) && (row != table.getEditingRow()) && (col >= 0) && (col != table.getEditingColumn()) && (EditPaneListScreen.this.cellEditors != null) && (col < EditPaneListScreen.this.cellEditors.length) && (EditPaneListScreen.this.cellEditors[col] != null))
/*     */         {
/*     */ 
/*     */ 
/* 156 */           table.editCellAt(row, col);
/*     */         }
/*     */       }
/*     */       
/*     */       protected final boolean isOkToShowPopup(MouseEvent e) {
/* 161 */         JTable tblDetails = EditPaneListScreen.this.getJTable();
/*     */         
/* 163 */         EditPaneListScreen.this.mainPopupCol = tblDetails.columnAtPoint(e.getPoint());
/* 164 */         EditPaneListScreen.this.popupRow = tblDetails.rowAtPoint(e.getPoint());
/*     */         
/* 166 */         return true;
/*     */       }
/* 168 */     };
/* 169 */     this.mainPopup.getPopup().add(this.tblScrollPane.getShowFieldsMenu());
/*     */     
/* 171 */     this.fixedPopupMenu = new MenuPopupListener(fixedActions, true, this.tblScrollPane.getFixedTable()) {
/*     */       public void mousePressed(MouseEvent m) {
/* 173 */         JTable tbl = EditPaneListScreen.this.tblScrollPane.getFixedTable();
/* 174 */         int col = tbl.columnAtPoint(m.getPoint());
/*     */         
/* 176 */         EditPaneListScreen.this.popupRow = tbl.rowAtPoint(m.getPoint());
/*     */         
/* 178 */         EditPaneListScreen.this.checkForTblRowChange(EditPaneListScreen.this.popupRow);
/* 179 */         if (col == 0) {
/* 180 */           EditPaneListScreen.this.newLineFrame(EditPaneListScreen.this.fileView, EditPaneListScreen.this.popupRow);
/*     */         } else {
/* 182 */           super.mousePressed(m);
/*     */         }
/*     */       }
/*     */       
/*     */       protected boolean isOkToShowPopup(MouseEvent e) {
/* 187 */         JTable tbl = EditPaneListScreen.this.tblScrollPane.getFixedTable();
/* 188 */         EditPaneListScreen.this.fixedPopupCol = tbl.columnAtPoint(e.getPoint());
/* 189 */         EditPaneListScreen.this.popupRow = tbl.rowAtPoint(e.getPoint());
/*     */         
/* 191 */         return EditPaneListScreen.this.fixedPopupCol > 0;
/*     */ 
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 197 */     };
/* 198 */     viewOfFile.setFrame(ReMainFrame.getMasterFrame());
/*     */     
/*     */ 
/* 201 */     tableDetails.addMouseListener(this.mainPopup);
/*     */     
/* 203 */     initToolTips(2);
/*     */     
/* 205 */     tableDetails.getTableHeader().addMouseListener(new BaseDisplay.HeaderSort(this));
/*     */     
/* 207 */     setAlternativeTbl(this.tblScrollPane.getFixedTable());
/*     */     
/* 209 */     this.actualPnl.registerComponentRE(tableDetails);
/* 210 */     this.actualPnl.registerComponentRE(this.tblScrollPane.getFixedTable());
/* 211 */     defColumns();
/*     */     
/* 213 */     this.tblScrollPane.getFixedTable().getTableHeader().addMouseListener(new BaseDisplay.HeaderSort(this));
/* 214 */     this.tblScrollPane.getFixedTable().addMouseListener(this.fixedPopupMenu);
/*     */     
/*     */ 
/* 217 */     viewOfFile.getBaseFile().addTableModelListener(this);
/*     */     
/*     */ 
/* 220 */     setRowHeight(DEFAULT_ROW_HEIGHT);
/* 221 */     setCellEditorRendor(this.tblScrollPane.getFixedTable());
/*     */   }
/*     */   
/*     */   protected void init_200_LayoutScreen()
/*     */   {
/* 226 */     this.actualPnl.addReKeyListener(new BaseDisplay.DelKeyWatcher(this));
/*     */     
/*     */ 
/* 229 */     this.actualPnl.addComponentRE(1, 5, -1.0D, net.sf.RecordEditor.utils.swing.BasePanel.GAP, 2, 2, this.tblScrollPane);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 234 */     setLayoutIdx();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setScreenSize(boolean mainframe)
/*     */   {
/* 241 */     DisplayFrame parentFrame = getParentFrame();
/* 242 */     parentFrame.bldScreen();
/*     */     
/* 244 */     parentFrame.setBounds(1, 1, this.screenSize.width - 1, this.screenSize.height - 1);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 249 */     parentFrame.setToMaximum(true);
/* 250 */     parentFrame.setVisible(true);
/*     */     
/* 252 */     Common.calcColumnWidths(this.tblDetails, 2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void fireLayoutIndexChanged() {}
/*     */   
/*     */ 
/*     */   protected int getInsertAfterPosition()
/*     */   {
/* 262 */     return getStandardPosition();
/*     */   }
/*     */   
/*     */   public int getCurrRow()
/*     */   {
/* 267 */     if (this.tblDetails.getSelectedRowCount() > 0) {
/* 268 */       return this.tblDetails.getSelectedRow();
/*     */     }
/* 270 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int getPopupPosition()
/*     */   {
/* 279 */     return this.popupRow;
/*     */   }
/*     */   
/*     */   private void hideColumn(int col) {
/* 283 */     this.tblScrollPane.doHideColumn(col);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void defColumns()
/*     */   {
/* 290 */     defColumns(getJTable(), this.fileView, this.tblScrollPane);
/*     */   }
/*     */   
/*     */   private JTable defColumns(JTable tbl, FileView view, FixedColumnScrollPane scrollPane) {
/* 294 */     TableColumnModel tcm = tbl.getColumnModel();
/*     */     
/* 296 */     defineColumns(tbl, view.getColumnCount(), 2, 0);
/* 297 */     defineCellRenders(tcm, 2, 0);
/*     */     
/* 299 */     for (int i = 2; i < tcm.getColumnCount(); i++) {
/* 300 */       tcm.getColumn(i).setHeaderRenderer(this.headerRender);
/*     */     }
/*     */     
/*     */ 
/* 304 */     setKeylistner(tbl);
/*     */     
/* 306 */     if (scrollPane != null) {
/* 307 */       int rowCount = view.getRowCount();
/* 308 */       int width = 5;
/*     */       
/* 310 */       scrollPane.setFixedColumns(2);
/* 311 */       TableColumn tc = scrollPane.getFixedTable().getColumnModel().getColumn(0);
/* 312 */       tc.setCellRenderer(this.tableBtn);
/* 313 */       tc.setPreferredWidth(5);
/* 314 */       if (scrollPane.getFixedTable().getColumnModel().getColumnCount() <= 1) {
/* 315 */         Common.logMsg("Error No Fields defined in the layout !!!", null);
/*     */       } else {
/* 317 */         tc = scrollPane.getFixedTable().getColumnModel().getColumn(1);
/* 318 */         if (rowCount > 10000000) {
/* 319 */           width = 8;
/* 320 */         } else if (rowCount > 1000000) {
/* 321 */           width = 7;
/* 322 */         } else if (rowCount > 100000) {
/* 323 */           width = 6;
/*     */         }
/* 325 */         tc.setPreferredWidth(SwingUtils.STANDARD_FONT_WIDTH * width);
/* 326 */         tc.setResizable(false);
/*     */         
/* 328 */         scrollPane.correctFixedSize();
/*     */       }
/* 330 */       setKeylistner(scrollPane.getFixedTable());
/*     */     }
/*     */     
/* 333 */     setRowHeight(DEFAULT_ROW_HEIGHT);
/* 334 */     setCellEditorRendor(tbl);
/*     */     
/* 336 */     return tbl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setCellEditorRendor(JTable tbl) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setKeylistner(JTable tbl)
/*     */   {
/* 355 */     if (tbl != null)
/*     */     {
/* 357 */       if (this.childScreen != null) {
/* 358 */         if (tbl == this.tblDetails) {
/* 359 */           tbl.addKeyListener(this.keyListner);
/*     */         } else {
/* 361 */           tbl.addKeyListener(this.keyListnerFixed);
/*     */         }
/* 363 */         this.lastRow = -1;
/* 364 */         checkForTblRowChange(tbl.getSelectedRow());
/* 365 */       } else if (tbl == this.tblDetails) {
/* 366 */         tbl.removeKeyListener(this.keyListner);
/*     */       } else {
/* 368 */         tbl.removeKeyListener(this.keyListnerFixed);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void setCurrRow(int newRow, int layoutId, int fieldNum) {
/* 374 */     if ((newRow >= 0) && (newRow <= this.fileView.getRowCount())) {
/* 375 */       checkForTblRowChange(newRow);
/* 376 */       if (getCurrRow() != newRow) {
/* 377 */         this.fileView.fireTableDataChanged();
/* 378 */         this.tblDetails.changeSelection(newRow, 1, false, false);
/*     */       }
/*     */       
/* 381 */       if ((fieldNum >= 0) && (isCurrLayoutIdx(layoutId))) {
/* 382 */         stopCellEditing();
/* 383 */         this.tblDetails.editCellAt(newRow, FieldMapping.getAdjColumn(this.fieldMapping, layoutId, fieldNum));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void tableChanged(TableModelEvent e) {}
/*     */   
/*     */ 
/*     */ 
/*     */   public void checkForTblRowChange(int row)
/*     */   {
/* 396 */     if ((this.lastRow != row) && 
/* 397 */       (this.childScreen != null)) {
/* 398 */       this.childScreen.setCurrRow(row);
/*     */     }
/*     */     
/* 401 */     this.lastRow = row;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean[] getFieldVisibility(int recordIndex)
/*     */   {
/* 409 */     return this.tblScrollPane.getFieldVisibility(2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFieldVisibility(int recordIndex, boolean[] fieldVisibility)
/*     */   {
/* 417 */     this.fieldMapping.setFieldVisibilty(recordIndex, fieldVisibility);
/*     */     
/* 419 */     this.tblScrollPane.setFieldVisibility(2, fieldVisibility);
/*     */     
/* 421 */     DisplayFrame parentFrame = getParentFrame();
/* 422 */     if (parentFrame != null) {
/* 423 */       parentFrame.setToActiveFrame();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public int getCurrentChildScreenPostion()
/*     */   {
/* 430 */     return this.currChildScreenPosition;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeChildScreen()
/*     */   {
/* 439 */     if (this.childScreen != null) {
/* 440 */       this.childScreen.doClose();
/*     */     }
/* 442 */     this.childScreen = null;
/* 443 */     setKeylistner(this.tblDetails);
/* 444 */     setKeylistner(this.tblScrollPane.getFixedTable());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractFileDisplay getChildScreen()
/*     */   {
/* 454 */     return this.childScreen;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void executeAction(int action)
/*     */   {
/* 462 */     if (action == 31) {
/* 463 */       this.fileView.repeatLine(this.popupRow);
/* 464 */       setCurrRow(this.popupRow + 1, 0, 0);
/*     */     } else {
/* 466 */       super.executeAction(action);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isActionAvailable(int action)
/*     */   {
/* 476 */     return (action == 31) || (super.isActionAvailable(action));
/*     */   }
/*     */   
/*     */   public void insertLine(int adj)
/*     */   {
/* 481 */     if (this.childScreen == null) {
/* 482 */       super.insertLine(adj);
/*     */     } else {
/* 484 */       int pos = this.fileView.newLine(getInsertAfterPosition(), adj);
/* 485 */       setCurrRow(pos, 0, 0);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/extension/EditPaneListScreen.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */