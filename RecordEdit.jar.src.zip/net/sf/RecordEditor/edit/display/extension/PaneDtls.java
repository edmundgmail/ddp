/*    */ package net.sf.RecordEditor.edit.display.extension;
/*    */ 
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.JScrollPane;
/*    */ import javax.swing.text.JTextComponent;
/*    */ 
/*    */ public class PaneDtls
/*    */ {
/*  9 */   public static int NOT_HTML = 1;
/* 10 */   public static int HTML_IF_HTML_TAG = 2;
/* 11 */   public static int IS_HTML = 3;
/*    */   
/*    */   public final String name;
/*    */   
/*    */   public final JComponent fld;
/*    */   
/*    */   public final JTextComponent txtFld;
/*    */   
/*    */   public final FieldDef fieldDef;
/*    */   public final int col;
/*    */   public final int htmlType;
/*    */   public final double weight;
/* 23 */   private boolean visible = true;
/*    */   
/*    */   public PaneDtls(String name, FieldDef fieldDef, JComponent fld) {
/* 26 */     this(name, fieldDef, fld, 0, NOT_HTML, -1.0D);
/*    */   }
/*    */   
/*    */   public PaneDtls(String name, FieldDef fieldDef, JComponent fld, int col, int html, double weight)
/*    */   {
/* 31 */     this.name = name;
/* 32 */     this.fld = fld;
/* 33 */     this.txtFld = null;
/* 34 */     this.fieldDef = fieldDef;
/* 35 */     this.col = col;
/* 36 */     this.weight = weight;
/* 37 */     this.htmlType = html;
/*    */   }
/*    */   
/*    */   public PaneDtls(String name, FieldDef fieldDef, JTextComponent fld)
/*    */   {
/* 42 */     this(name, fieldDef, fld, 0, NOT_HTML, -1.0D);
/*    */   }
/*    */   
/*    */   public PaneDtls(String name, FieldDef fieldDef, JTextComponent fld, double weight) {
/* 46 */     this(name, fieldDef, fld, 0, NOT_HTML, weight);
/*    */   }
/*    */   
/*    */   public PaneDtls(String name, FieldDef fieldDef, JTextComponent fld, int col) {
/* 50 */     this(name, fieldDef, fld, col, NOT_HTML, -1.0D);
/*    */   }
/*    */   
/*    */   public PaneDtls(String name, FieldDef fieldDef, JTextComponent fld, int col, boolean html) {
/* 54 */     this(name, fieldDef, fld, col, html ? IS_HTML : NOT_HTML, -1.0D);
/*    */   }
/*    */   
/*    */   public PaneDtls(String name, FieldDef fieldDef, JTextComponent fld, int col, int html, double weight)
/*    */   {
/* 59 */     this.name = name;
/* 60 */     this.fld = fld;
/* 61 */     this.txtFld = fld;
/* 62 */     this.fieldDef = fieldDef;
/* 63 */     this.col = col;
/*    */     
/* 65 */     this.weight = weight;
/* 66 */     this.htmlType = html;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean isVisible()
/*    */   {
/* 73 */     return this.visible;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public PaneDtls setVisible(boolean visible)
/*    */   {
/* 80 */     this.visible = visible;
/* 81 */     return this;
/*    */   }
/*    */   
/*    */   public boolean isHtml() {
/* 85 */     return this.htmlType != NOT_HTML;
/*    */   }
/*    */   
/*    */   public final JComponent getDisplayPane() {
/* 89 */     JScrollPane ret = new JScrollPane(this.fld);
/*    */     
/* 91 */     ret.setBorder(javax.swing.BorderFactory.createTitledBorder(this.name));
/*    */     
/* 93 */     return ret;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/extension/PaneDtls.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */