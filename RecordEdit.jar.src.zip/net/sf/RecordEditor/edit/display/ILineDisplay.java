package net.sf.RecordEditor.edit.display;

import net.sf.JRecord.Details.AbstractLine;
import net.sf.RecordEditor.re.display.AbstractFileDisplay;

public abstract interface ILineDisplay
  extends AbstractFileDisplay
{
  public abstract void setLine(AbstractLine paramAbstractLine);
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/ILineDisplay.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */