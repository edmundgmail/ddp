/*    */ package net.sf.RecordEditor.edit.display;
/*    */ 
/*    */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*    */ import net.sf.RecordEditor.edit.display.util.BaseFieldSelection;
/*    */ import net.sf.RecordEditor.edit.display.util.SortFieldSummaryMdl;
/*    */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*    */ import net.sf.RecordEditor.re.display.DisplayBuilderFactory;
/*    */ import net.sf.RecordEditor.re.file.FileView;
/*    */ import net.sf.RecordEditor.re.tree.TreeParserField;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CreateFieldTree
/*    */   extends BaseFieldSelection
/*    */ {
/*    */   public CreateFieldTree(AbstractFileDisplay src, FileView fileTbl)
/*    */   {
/* 43 */     super(src, fileTbl, "Create Field Tree View", 35, "Build Tree", 1, true, true, "FieldTree");
/*    */     
/* 45 */     super.setHelpURL(Common.formatHelpURL("HlpRe11.htm"));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected AbstractFileDisplay doAction(FileView view, int recordIndex, AbstractFileDisplay src, int[] fieldList, boolean[] descending, AbstractLayoutDetails layout)
/*    */   {
/* 59 */     FileView newView = getNewView();
/*    */     
/* 61 */     if (newView != null) {
/* 62 */       TreeParserField parser = new TreeParserField(recordIndex, fieldList, this.summaryMdl.getFieldSummary());
/*    */       
/* 64 */       return DisplayBuilderFactory.newLineTree(getSourceDisplay().getParentFrame(), newView, parser, false, 0);
/*    */     }
/* 66 */     return null;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/CreateFieldTree.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */