/*    */ package net.sf.RecordEditor.edit.display.Action;
/*    */ 
/*    */ import java.awt.event.ActionEvent;
/*    */ import net.sf.RecordEditor.edit.display.util.ChangeLayout;
/*    */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*    */ import net.sf.RecordEditor.re.openFile.AbstractLayoutSelectCreator;
/*    */ import net.sf.RecordEditor.utils.screenManager.AbstractActiveScreenAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChangeLayoutAction
/*    */   extends ReSpecificScreenAction
/*    */   implements AbstractActiveScreenAction
/*    */ {
/*    */   private AbstractLayoutSelectCreator<?> creator;
/*    */   
/*    */   public ChangeLayoutAction(AbstractLayoutSelectCreator<?> layoutSelectionCreator)
/*    */   {
/* 20 */     super("Change Layout");
/* 21 */     this.creator = layoutSelectionCreator;
/* 22 */     checkActionEnabled();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void checkActionEnabled()
/*    */   {
/* 30 */     super.setEnabled(getDisplay(AbstractFileDisplay.class) != null);
/*    */   }
/*    */   
/*    */   public void actionPerformed(ActionEvent arg0)
/*    */   {
/* 35 */     AbstractFileDisplay sourcePnl = (AbstractFileDisplay)getDisplay(AbstractFileDisplay.class);
/* 36 */     if (sourcePnl != null) {
/* 37 */       new ChangeLayout(this.creator.create(), sourcePnl.getFileView());
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/Action/ChangeLayoutAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */