/*    */ package net.sf.RecordEditor.edit.display.Action;
/*    */ 
/*    */ import java.awt.event.ActionEvent;
/*    */ import javax.swing.JDesktopPane;
/*    */ import net.sf.JRecord.IO.AbstractLineIOProvider;
/*    */ import net.sf.RecordEditor.edit.open.OpenCsvFilePnl;
/*    */ import net.sf.RecordEditor.edit.open.OpenFile;
/*    */ import net.sf.RecordEditor.utils.lang.ReAbstractAction;
/*    */ import net.sf.RecordEditor.utils.params.Parameters;
/*    */ import net.sf.RecordEditor.utils.screenManager.ReMainFrame;
/*    */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*    */ 
/*    */ 
/*    */ public class CsvOpenAction
/*    */   extends ReAbstractAction
/*    */ {
/* 17 */   private OpenFile open = null;
/*    */   private OpenCsvFilePnl csvPnl;
/*    */   private final String fileName;
/*    */   private final AbstractLineIOProvider ioProvider;
/*    */   
/*    */   public CsvOpenAction(String fileName, AbstractLineIOProvider pIoProvider) {
/* 23 */     super("Open Basic CSV file", 12);
/*    */     
/*    */ 
/* 26 */     this.fileName = fileName;
/* 27 */     this.ioProvider = pIoProvider;
/*    */   }
/*    */   
/*    */   public void actionPerformed(ActionEvent e)
/*    */   {
/* 32 */     if (this.open == null) {
/* 33 */       this.csvPnl = new OpenCsvFilePnl(this.fileName, Parameters.getApplicationDirectory() + "CsvFiles.txt", this.ioProvider, false);
/*    */       
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 40 */       this.open = new OpenFile(this.csvPnl, getLogWidth(), getOpenHeight());
/* 41 */       this.csvPnl.setParentFrame(this.open);
/* 42 */       this.csvPnl.selectCsvExt();
/*    */     }
/* 44 */     this.open.setVisible(true);
/*    */   }
/*    */   
/*    */   private int getOpenHeight()
/*    */   {
/* 49 */     return ReMainFrame.getMasterFrame().getDesktopHeight() * 4 / 5;
/*    */   }
/*    */   
/*    */   private int getLogWidth()
/*    */   {
/* 54 */     return ReMainFrame.getMasterFrame().getDesktop().getWidth() - SwingUtils.STANDARD_FONT_WIDTH;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/Action/CsvOpenAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */