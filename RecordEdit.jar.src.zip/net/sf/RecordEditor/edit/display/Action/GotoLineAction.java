/*    */ package net.sf.RecordEditor.edit.display.Action;
/*    */ 
/*    */ import java.awt.event.ActionEvent;
/*    */ import net.sf.RecordEditor.edit.display.util.GotoLine;
/*    */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*    */ import net.sf.RecordEditor.re.file.FileView;
/*    */ import net.sf.RecordEditor.utils.lang.ReAbstractAction;
/*    */ 
/*    */ public class GotoLineAction
/*    */   extends ReAbstractAction
/*    */ {
/*    */   private final AbstractFileDisplay src;
/*    */   private FileView master;
/*    */   
/*    */   public GotoLineAction(AbstractFileDisplay src, FileView master)
/*    */   {
/* 17 */     super("Goto Line", 41);
/* 18 */     this.src = src;
/* 19 */     this.master = master;
/*    */   }
/*    */   
/*    */   public void actionPerformed(ActionEvent e) {
/* 23 */     new GotoLine(this.src, this.master);
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/Action/GotoLineAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */