/*    */ package net.sf.RecordEditor.edit.display.Action;
/*    */ 
/*    */ import java.awt.event.ActionEvent;
/*    */ import net.sf.RecordEditor.edit.display.util.SaveRestoreHiddenFields;
/*    */ import net.sf.RecordEditor.re.display.AbstractFileDisplayWithFieldHide;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ import net.sf.RecordEditor.utils.screenManager.AbstractActiveScreenAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoadSavedVisibilityAction
/*    */   extends ReSpecificScreenAction
/*    */   implements AbstractActiveScreenAction
/*    */ {
/*    */   public LoadSavedVisibilityAction()
/*    */   {
/* 17 */     super("Load Saved Hidden Fields");
/*    */     
/* 19 */     checkActionEnabled();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void checkActionEnabled()
/*    */   {
/* 26 */     super.setEnabled(getDisplay(AbstractFileDisplayWithFieldHide.class) != null);
/*    */   }
/*    */   
/*    */   public void actionPerformed(ActionEvent arg0)
/*    */   {
/* 31 */     AbstractFileDisplayWithFieldHide sourcePnl = (AbstractFileDisplayWithFieldHide)getDisplay(AbstractFileDisplayWithFieldHide.class);
/* 32 */     if (sourcePnl != null) {
/*    */       try {
/* 34 */         SaveRestoreHiddenFields.restoreHiddenFields(sourcePnl);
/*    */       } catch (NoClassDefFoundError e) {
/* 36 */         Common.logMsg("Unable to loaved saved definition: jibx not present ???", null);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/Action/LoadSavedVisibilityAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */