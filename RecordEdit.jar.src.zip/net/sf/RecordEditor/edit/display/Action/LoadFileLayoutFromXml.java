/*     */ package net.sf.RecordEditor.edit.display.Action;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import net.sf.JRecord.Details.LayoutDetail;
/*     */ import net.sf.JRecord.Details.RecordDetail;
/*     */ import net.sf.JRecord.External.ExternalRecord;
/*     */ import net.sf.JRecord.External.RecordEditorXmlLoader;
/*     */ import net.sf.RecordEditor.edit.display.util.Code;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*     */ import net.sf.RecordEditor.re.display.IDisplayFrame;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ import net.sf.RecordEditor.utils.screenManager.AbstractActiveScreenAction;
/*     */ import net.sf.RecordEditor.utils.swing.DirectoryFrame;
/*     */ 
/*     */ public class LoadFileLayoutFromXml
/*     */   extends ReSpecificScreenAction
/*     */   implements AbstractActiveScreenAction
/*     */ {
/*     */   private static final String MSG = "Load File Description from Xml";
/*     */   
/*     */   public LoadFileLayoutFromXml()
/*     */   {
/*  26 */     super("Load File Description from Xml");
/*     */     
/*  28 */     checkActionEnabled();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void checkActionEnabled()
/*     */   {
/*  36 */     super.setEnabled(isActive((AbstractFileDisplay)getDisplay(AbstractFileDisplay.class)));
/*     */   }
/*     */   
/*     */   public void actionPerformed(ActionEvent arg0)
/*     */   {
/*  41 */     AbstractFileDisplay fileDisplay = (AbstractFileDisplay)getDisplay(AbstractFileDisplay.class);
/*  42 */     if (isActive(fileDisplay)) {
/*  43 */       String dir = Parameters.getFileName("CopybookDirectory");
/*  44 */       String s = "";
/*  45 */       String fn = fileDisplay.getFileView().getBaseFile().getFileNameNoDirectory();
/*     */       
/*  47 */       if ((fn != null) && (!"".equals(fn))) {
/*  48 */         s = removeExtension(fn) + ".Xml";
/*     */       }
/*  50 */       new LoadLayout(fileDisplay, dir + s);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean isActive(AbstractFileDisplay activeScreen)
/*     */   {
/*  57 */     return (activeScreen != null) && (activeScreen.getFileView().isSimpleCsvFile());
/*     */   }
/*     */   
/*     */   private static String removeExtension(String s) {
/*  61 */     if (s.indexOf('.') >= 0) {
/*  62 */       int l = s.lastIndexOf('.');
/*  63 */       s = s.substring(0, l);
/*     */     }
/*  65 */     return s;
/*     */   }
/*     */   
/*     */   public static class LoadLayout extends DirectoryFrame implements ActionListener
/*     */   {
/*     */     private AbstractFileDisplay panel;
/*     */     
/*     */     public LoadLayout(AbstractFileDisplay pnl, String dir) {
/*  73 */       super(dir, false, false, false);
/*     */       
/*  75 */       this.panel = pnl;
/*  76 */       setActionListner(this);
/*  77 */       setVisible(true);
/*     */     }
/*     */     
/*     */ 
/*     */     public void actionPerformed(ActionEvent arg0)
/*     */     {
/*  83 */       FileView masterView = this.panel.getFileView().getBaseFile();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       try
/*     */       {
/*  96 */         ExternalRecord rec = new RecordEditorXmlLoader().loadCopyBook(super.getFileName(), 0, 0, "", 0, 0, Common.getLogger());
/*     */         
/*     */ 
/*  99 */         LayoutDetail l = rec.asLayoutDetail();
/*     */         
/*     */ 
/* 102 */         if ((l == null) || (l.getRecordCount() < 1) || (((RecordDetail)l.getRecord(0)).getFieldCount() < 1)) {
/* 103 */           Common.logMsg("Error in the layout that was loaded", null);
/*     */         } else {
/* 105 */           Code.notifyFramesOfNewLayout(masterView, l);
/*     */         }
/*     */         
/* 108 */         this.panel.getParentFrame().setToActiveFrame();
/* 109 */         this.panel.getParentFrame().setToActiveTab(this.panel);
/* 110 */         setVisible(false);
/*     */       } catch (Exception ex) {
/* 112 */         ex.printStackTrace();
/* 113 */         Common.logMsg(30, "Can not Load Xml Layout:", ex.getMessage(), ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/Action/LoadFileLayoutFromXml.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */