/*    */ package net.sf.RecordEditor.edit.display.Action;
/*    */ 
/*    */ import java.awt.event.ActionEvent;
/*    */ import javax.swing.JCheckBoxMenuItem;
/*    */ import javax.swing.JTable;
/*    */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ import net.sf.RecordEditor.utils.lang.ReAbstractAction;
/*    */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*    */ import net.sf.RecordEditor.utils.params.ProgramOptions.InternalBoolOption;
/*    */ import net.sf.RecordEditor.utils.params.ProgramOptions.UpdateableBoolOpt;
/*    */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*    */ 
/*    */ 
/*    */ public class HighlightMissingFields
/*    */   extends JCheckBoxMenuItem
/*    */ {
/* 18 */   private ReAbstractAction action = new ReAbstractAction("Highlight Missing Fields")
/*    */   {
/*    */     public void actionPerformed(ActionEvent arg0)
/*    */     {
/* 22 */       Common.OPTIONS.highlightEmpty.set(HighlightMissingFields.this.getState());
/*    */       
/*    */ 
/* 25 */       ReFrame[] frames = ReFrame.getAllFrames();
/* 26 */       for (int i = 0; i < frames.length; i++) {
/* 27 */         if ((frames[i] instanceof AbstractFileDisplay)) {
/* 28 */           JTable tbl = ((AbstractFileDisplay)frames[i]).getJTable();
/*    */           
/* 30 */           if (tbl != null) {
/* 31 */             tbl.repaint();
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/*    */   };
/*    */   
/*    */ 
/*    */   public HighlightMissingFields()
/*    */   {
/* 41 */     super.setAction(this.action);
/* 42 */     setState(Common.OPTIONS.highlightEmpty.isSelected());
/*    */     
/* 44 */     Common.OPTIONS.highlightEmptyActive.set(true);
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/Action/HighlightMissingFields.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */