/*    */ package net.sf.RecordEditor.edit.display.Action;
/*    */ 
/*    */ import java.awt.event.ActionEvent;
/*    */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*    */ import net.sf.RecordEditor.edit.display.util.HideFields;
/*    */ import net.sf.RecordEditor.re.display.AbstractFileDisplayWithFieldHide;
/*    */ import net.sf.RecordEditor.re.file.FileView;
/*    */ import net.sf.RecordEditor.utils.screenManager.AbstractActiveScreenAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class VisibilityAction
/*    */   extends ReSpecificScreenAction
/*    */   implements AbstractActiveScreenAction
/*    */ {
/*    */   public VisibilityAction()
/*    */   {
/* 18 */     super("Show / Hide Fields");
/*    */     
/* 20 */     checkActionEnabled();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void checkActionEnabled()
/*    */   {
/* 28 */     boolean enable = false;
/* 29 */     AbstractFileDisplayWithFieldHide sourcePnl = (AbstractFileDisplayWithFieldHide)getDisplay(AbstractFileDisplayWithFieldHide.class);
/*    */     
/* 31 */     if (sourcePnl != null) {
/* 32 */       AbstractLayoutDetails layout = sourcePnl.getFileView().getLayout();
/* 33 */       int recordIndex = sourcePnl.getLayoutIndex();
/* 34 */       enable = (recordIndex <= layout.getRecordCount()) && (recordIndex >= 0);
/*    */     }
/*    */     
/* 37 */     super.setEnabled(enable);
/*    */   }
/*    */   
/*    */   public void actionPerformed(ActionEvent arg0)
/*    */   {
/* 42 */     AbstractFileDisplayWithFieldHide sourcePnl = (AbstractFileDisplayWithFieldHide)getDisplay(AbstractFileDisplayWithFieldHide.class);
/*    */     
/* 44 */     if (sourcePnl != null) {
/* 45 */       new HideFields(sourcePnl);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/Action/VisibilityAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */