/*    */ package net.sf.RecordEditor.edit.display.Action;
/*    */ 
/*    */ import java.awt.event.ActionEvent;
/*    */ import net.sf.RecordEditor.edit.display.common.AbstractFieldSequencePnl;
/*    */ import net.sf.RecordEditor.jibx.compare.EditorTask;
/*    */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*    */ import net.sf.RecordEditor.re.file.FileView;
/*    */ import net.sf.RecordEditor.re.file.filter.AbstractExecute;
/*    */ import net.sf.RecordEditor.re.file.filter.ExecuteSavedFile;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ import net.sf.RecordEditor.utils.params.Parameters;
/*    */ import net.sf.RecordEditor.utils.screenManager.AbstractActiveScreenAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LoadSavedFieldSeqAction
/*    */   extends ReSpecificScreenAction
/*    */   implements AbstractActiveScreenAction
/*    */ {
/*    */   public LoadSavedFieldSeqAction()
/*    */   {
/* 24 */     super("Load Saved Field Sequences");
/*    */     
/* 26 */     checkActionEnabled();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void checkActionEnabled()
/*    */   {
/* 34 */     super.setEnabled(getDisplay(AbstractFieldSequencePnl.class) != null);
/*    */   }
/*    */   
/*    */ 
/*    */   public void actionPerformed(ActionEvent arg0)
/*    */   {
/* 40 */     AbstractFieldSequencePnl sourcePnl = (AbstractFieldSequencePnl)getDisplay(AbstractFieldSequencePnl.class);
/* 41 */     if (sourcePnl != null) {
/*    */       try {
/* 43 */         FileView fileView = sourcePnl.getFileView();
/*    */         
/* 45 */         SetFields setFields = new SetFields(sourcePnl);
/* 46 */         new ExecuteSavedFile(fileView.getBaseFile().getFileNameNoDirectory(), "Execute Saved Filter", fileView, Parameters.getFileName("FieldSaveDirectory"), setFields, EditorTask.class);
/*    */ 
/*    */       }
/*    */       catch (NoClassDefFoundError e)
/*    */       {
/* 51 */         Common.logMsg("Unable to load saved definition: jibx not present ???", null);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public static class SetFields
/*    */     implements AbstractExecute<EditorTask>
/*    */   {
/*    */     private AbstractFieldSequencePnl lineList;
/*    */     
/*    */ 
/*    */     public SetFields(AbstractFieldSequencePnl lineList)
/*    */     {
/* 65 */       this.lineList = lineList;
/*    */     }
/*    */     
/*    */ 
/*    */     public AbstractFileDisplay execute(EditorTask saveDetails)
/*    */     {
/* 71 */       if (saveDetails.fieldSequence != null) {
/* 72 */         this.lineList.setFieldSequence(saveDetails.fieldSequence);
/*    */       }
/* 74 */       return this.lineList;
/*    */     }
/*    */     
/*    */     public void executeDialog(EditorTask saveDetails)
/*    */     {
/* 79 */       execute(saveDetails);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/Action/LoadSavedFieldSeqAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */