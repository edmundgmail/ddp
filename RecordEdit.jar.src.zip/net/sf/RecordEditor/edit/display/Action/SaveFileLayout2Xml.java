/*     */ package net.sf.RecordEditor.edit.display.Action;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.File;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.External.CopybookWriter;
/*     */ import net.sf.JRecord.External.CopybookWriterManager;
/*     */ import net.sf.JRecord.External.ExternalRecord;
/*     */ import net.sf.JRecord.External.ToExternalRecord;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ import net.sf.RecordEditor.utils.screenManager.AbstractActiveScreenAction;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.swing.DirectoryFrame;
/*     */ 
/*     */ public class SaveFileLayout2Xml extends ReSpecificScreenAction implements AbstractActiveScreenAction
/*     */ {
/*     */   private static final String MSG = "Save File Description as Xml";
/*     */   
/*     */   public SaveFileLayout2Xml()
/*     */   {
/*  25 */     super("Save File Description as Xml");
/*     */     
/*  27 */     checkActionEnabled();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void checkActionEnabled()
/*     */   {
/*  35 */     super.setEnabled(isActive((AbstractFileDisplay)getDisplay(AbstractFileDisplay.class)));
/*     */   }
/*     */   
/*     */   public void actionPerformed(ActionEvent arg0)
/*     */   {
/*  40 */     AbstractFileDisplay fileDisplay = (AbstractFileDisplay)getDisplay(AbstractFileDisplay.class);
/*  41 */     if (isActive(fileDisplay)) {
/*  42 */       String dir = Parameters.getFileName("CopybookDirectory");
/*  43 */       String s = "";
/*  44 */       String fn = fileDisplay.getFileView().getBaseFile().getFileNameNoDirectory();
/*     */       
/*  46 */       if ((fn != null) && (!"".equals(fn))) {
/*  47 */         s = removeExtension(fn) + ".Xml";
/*     */       }
/*  49 */       new SaveLayout(fileDisplay, dir + s);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private boolean isActive(AbstractFileDisplay activeScreen)
/*     */   {
/*  56 */     boolean active = false;
/*     */     
/*  58 */     if (activeScreen != null) {
/*  59 */       AbstractFileDisplay source = activeScreen;
/*  60 */       active = source.getFileView().isSimpleCsvFile();
/*     */     }
/*     */     
/*  63 */     return active;
/*     */   }
/*     */   
/*     */   private static String removeExtension(String s) {
/*  67 */     if (s.indexOf('.') >= 0) {
/*  68 */       int l = s.lastIndexOf('.');
/*  69 */       s = s.substring(0, l);
/*     */     }
/*  71 */     return s;
/*     */   }
/*     */   
/*     */   public static class SaveLayout extends DirectoryFrame implements ActionListener
/*     */   {
/*     */     private AbstractFileDisplay panel;
/*     */     
/*     */     public SaveLayout(AbstractFileDisplay pnl, String dir) {
/*  79 */       super(dir, false, false, true);
/*     */       
/*  81 */       this.panel = pnl;
/*  82 */       setActionListner(this);
/*  83 */       setVisible(true);
/*     */     }
/*     */     
/*     */ 
/*     */     public void actionPerformed(ActionEvent arg0)
/*     */     {
/*  89 */       FileView view = this.panel.getFileView().getBaseFile();
/*  90 */       CopybookWriterManager writers = CopybookWriterManager.getInstance();
/*  91 */       String fname = super.getFileName();
/*  92 */       String lname = Common.stripDirectory(fname);
/*     */       
/*  94 */       if ((lname == null) || ("".equals(lname))) {
/*  95 */         lname = view.getLayout().getLayoutName();
/*     */       } else {
/*  97 */         lname = SaveFileLayout2Xml.removeExtension(lname);
/*     */       }
/*     */       try
/*     */       {
/* 101 */         ExternalRecord rec = ToExternalRecord.getInstance().getExternalRecord(view.getLayout(), lname, 0);
/*     */         
/*     */ 
/* 104 */         ((CopybookWriter)writers.get(1)).writeCopyBook(super.getFile().getParent(), rec, Common.getLogger());
/*     */         
/*     */ 
/*     */ 
/*     */ 
/* 109 */         setVisible(false);
/* 110 */         ReFrame.setActiveFrame((ReFrame)this.panel.getParentFrame());
/*     */       } catch (Exception ex) {
/* 112 */         Common.logMsg("Can not save Field Sequences", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/Action/SaveFileLayout2Xml.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */