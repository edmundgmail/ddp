/*    */ package net.sf.RecordEditor.edit.display.Action;
/*    */ 
/*    */ import java.awt.event.ActionEvent;
/*    */ import net.sf.RecordEditor.edit.util.NewCsvFile;
/*    */ import net.sf.RecordEditor.utils.lang.ReAbstractAction;
/*    */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NewCsvAction
/*    */   extends ReAbstractAction
/*    */ {
/*    */   public NewCsvAction()
/*    */   {
/* 15 */     this("New File");
/*    */   }
/*    */   
/*    */   public NewCsvAction(String text) {
/* 19 */     super(text, 8);
/*    */   }
/*    */   
/*    */   public void actionPerformed(ActionEvent e) {
/* 23 */     ReFrame activeFrame = ReFrame.getActiveFrame();
/* 24 */     if ((activeFrame != null) && (activeFrame.isActionAvailable(12))) {
/* 25 */       activeFrame.executeAction(12);
/*    */     } else {
/* 27 */       new NewCsvFile();
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/Action/NewCsvAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */