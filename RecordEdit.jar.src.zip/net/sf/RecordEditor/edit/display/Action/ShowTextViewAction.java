/*    */ package net.sf.RecordEditor.edit.display.Action;
/*    */ 
/*    */ import java.awt.event.ActionEvent;
/*    */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*    */ import net.sf.RecordEditor.re.display.DisplayBuilderFactory;
/*    */ import net.sf.RecordEditor.re.display.IDisplayBuilder;
/*    */ import net.sf.RecordEditor.re.file.FileView;
/*    */ import net.sf.RecordEditor.utils.params.BoolOpt;
/*    */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*    */ import net.sf.RecordEditor.utils.screenManager.AbstractActiveScreenAction;
/*    */ 
/*    */ public class ShowTextViewAction extends ReSpecificScreenAction implements AbstractActiveScreenAction
/*    */ {
/*    */   private final boolean selectedRecords;
/*    */   private final boolean coloredFields;
/*    */   private final int screenType;
/*    */   
/*    */   public static ShowTextViewAction get(boolean selectedRecords, boolean coloredFields)
/*    */   {
/* 20 */     String s = "Text View";
/* 21 */     if (selectedRecords) {
/* 22 */       s = "Text View (Selected Records)";
/*    */     }
/* 24 */     int stype = 10;
/* 25 */     if (coloredFields) {
/* 26 */       stype = 11;
/* 27 */       s = "Text View (highlight fields)";
/* 28 */       if (selectedRecords) {
/* 29 */         s = "Text View (Selected Records / highlight fields)";
/*    */       }
/*    */     }
/*    */     
/* 33 */     return new ShowTextViewAction(selectedRecords, s, stype, coloredFields);
/*    */   }
/*    */   
/*    */ 
/*    */   private ShowTextViewAction(boolean selectedRecords, String msg, int sType, boolean coloredFields)
/*    */   {
/* 39 */     super(msg);
/* 40 */     this.selectedRecords = selectedRecords;
/* 41 */     this.coloredFields = coloredFields;
/* 42 */     this.screenType = sType;
/*    */     
/* 44 */     checkActionEnabled();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void checkActionEnabled()
/*    */   {
/* 52 */     super.setEnabled((net.sf.RecordEditor.utils.common.Common.OPTIONS.allowTextEditting.isSelected()) && (isActive((AbstractFileDisplay)getDisplay(AbstractFileDisplay.class))));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void actionPerformed(ActionEvent arg0)
/*    */   {
/* 59 */     AbstractFileDisplay fileDisplay = (AbstractFileDisplay)getDisplay(AbstractFileDisplay.class);
/* 60 */     if (isActive(fileDisplay)) {
/* 61 */       FileView f = fileDisplay.getFileView();
/*    */       
/* 63 */       if (this.selectedRecords) {
/* 64 */         if (fileDisplay.isOkToUseSelectedRows()) {
/* 65 */           f = f.getView(fileDisplay.getSelectedRows());
/*    */         } else {
/* 67 */           f = f.getView(fileDisplay.getSelectedLines());
/*    */         }
/*    */       }
/*    */       
/* 71 */       if (f != null) {
/* 72 */         DisplayBuilderFactory.getInstance().newDisplay(this.screenType, "", fileDisplay.getParentFrame(), f.getLayout(), f, 0);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */   private boolean isActive(AbstractFileDisplay activeScreen)
/*    */   {
/* 79 */     boolean active = false;
/*    */     
/* 81 */     if (activeScreen != null) {
/* 82 */       AbstractFileDisplay source = activeScreen;
/* 83 */       active = source.getFileView().isDocumentViewAvailable(this.coloredFields);
/*    */     }
/*    */     
/* 86 */     return active;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/Action/ShowTextViewAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */