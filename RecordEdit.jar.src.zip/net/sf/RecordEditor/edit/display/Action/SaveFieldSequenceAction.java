/*    */ package net.sf.RecordEditor.edit.display.Action;
/*    */ 
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import net.sf.RecordEditor.edit.display.common.AbstractFieldSequencePnl;
/*    */ import net.sf.RecordEditor.jibx.JibxCall;
/*    */ import net.sf.RecordEditor.jibx.compare.EditorTask;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ import net.sf.RecordEditor.utils.params.Parameters;
/*    */ import net.sf.RecordEditor.utils.screenManager.AbstractActiveScreenAction;
/*    */ import net.sf.RecordEditor.utils.swing.DirectoryFrame;
/*    */ 
/*    */ 
/*    */ public class SaveFieldSequenceAction
/*    */   extends ReSpecificScreenAction
/*    */   implements AbstractActiveScreenAction
/*    */ {
/*    */   public SaveFieldSequenceAction()
/*    */   {
/* 20 */     super("Save Field Sequence");
/*    */     
/* 22 */     checkActionEnabled();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void checkActionEnabled()
/*    */   {
/* 30 */     super.setEnabled(getDisplay(AbstractFieldSequencePnl.class) != null);
/*    */   }
/*    */   
/*    */   public void actionPerformed(ActionEvent arg0)
/*    */   {
/* 35 */     AbstractFieldSequencePnl sourcePnl = (AbstractFieldSequencePnl)getDisplay(AbstractFieldSequencePnl.class);
/* 36 */     if (sourcePnl != null) {
/* 37 */       String dir = Parameters.getFileName("FieldSaveDirectory");
/* 38 */       new SaveSequence(sourcePnl, dir);
/*    */     }
/*    */   }
/*    */   
/*    */   public static class SaveSequence extends DirectoryFrame implements ActionListener
/*    */   {
/*    */     private AbstractFieldSequencePnl panel;
/*    */     
/*    */     public SaveSequence(AbstractFieldSequencePnl pnl, String dir) {
/* 47 */       super(dir, false, false, true);
/*    */       
/* 49 */       this.panel = pnl;
/* 50 */       setActionListner(this);
/*    */       
/* 52 */       setToMaximum(false);
/* 53 */       setVisible(true);
/*    */     }
/*    */     
/*    */     public void actionPerformed(ActionEvent arg0)
/*    */     {
/* 58 */       EditorTask task = new EditorTask();
/* 59 */       task.type = "FieldSequence";
/* 60 */       task.fieldSequence = this.panel.getFieldSequence();
/*    */       try {
/* 62 */         new JibxCall(task.getClass()).unmarshal(getFileName(), task);
/*    */         
/* 64 */         setVisible(false);
/*    */       } catch (Exception ex) {
/* 66 */         Common.logMsg("Can not save Field Sequences", ex);
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/Action/SaveFieldSequenceAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */