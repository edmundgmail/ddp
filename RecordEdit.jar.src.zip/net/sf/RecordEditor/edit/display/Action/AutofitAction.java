/*    */ package net.sf.RecordEditor.edit.display.Action;
/*    */ 
/*    */ import java.awt.event.ActionEvent;
/*    */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ import net.sf.RecordEditor.utils.lang.ReAbstractAction;
/*    */ 
/*    */ public class AutofitAction extends ReAbstractAction
/*    */ {
/*    */   private AbstractFileDisplay display;
/*    */   
/*    */   public AutofitAction(AbstractFileDisplay displ)
/*    */   {
/* 14 */     super("Autofit Columns", 19);
/*    */     
/* 16 */     this.display = displ;
/*    */   }
/*    */   
/*    */   public void actionPerformed(ActionEvent e) {
/* 20 */     Common.calcColumnWidths(this.display.getJTable(), 1);
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/Action/AutofitAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */