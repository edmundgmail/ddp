/*     */ package net.sf.RecordEditor.edit.display.Action;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JEditorPane;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.Attribute;
/*     */ import net.sf.RecordEditor.edit.util.ReMessages;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.re.util.FileStructureDtls;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.msg.UtMessages;
/*     */ import net.sf.RecordEditor.utils.screenManager.AbstractActiveScreenAction;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMsg;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMsgId;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.Combo.ComboOption;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ public class ChangeFileStructureAction
/*     */   extends ReSpecificScreenAction
/*     */   implements AbstractActiveScreenAction
/*     */ {
/*  28 */   private static final int TIP_HEIGHT = SwingUtils.STANDARD_FONT_HEIGHT * 10 + 5;
/*     */   
/*     */ 
/*     */ 
/*     */   public ChangeFileStructureAction()
/*     */   {
/*  34 */     super("Change File Structure");
/*     */     
/*  36 */     checkActionEnabled();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void checkActionEnabled()
/*     */   {
/*  44 */     super.setEnabled(isActive((AbstractFileDisplay)getDisplay(AbstractFileDisplay.class)));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void actionPerformed(ActionEvent arg0)
/*     */   {
/*  51 */     AbstractFileDisplay fileDisplay = (AbstractFileDisplay)getDisplay(AbstractFileDisplay.class);
/*  52 */     if (isActive(fileDisplay)) {
/*  53 */       FileView f = fileDisplay.getFileView();
/*     */       
/*  55 */       if (f != null) {
/*  56 */         new ChangeLayout(f);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isActive(AbstractFileDisplay activeScreen)
/*     */   {
/*  63 */     return (activeScreen != null) && (activeScreen.getFileView() != null);
/*     */   }
/*     */   
/*     */   private static class ChangeLayout extends ReFrame implements ActionListener
/*     */   {
/*     */     final FileView view;
/*     */     private JEditorPane tips;
/*  70 */     private BasePanel pnl = new BasePanel();
/*  71 */     private JComboBox fileStructures = FileStructureDtls.getFileStructureCombo();
/*  72 */     private JButton updateBtn = new JButton("Apply Update");
/*     */     
/*     */     public ChangeLayout(FileView view)
/*     */     {
/*  76 */       super("Change File Structure", view.getBaseFile());
/*  77 */       this.view = view;
/*     */       
/*  79 */       this.tips = new JEditorPane("text/html", ReMessages.CHANGE_FILE_STRUCTURE.get());
/*     */       
/*  81 */       this.pnl.addComponentRE(1, 5, ChangeFileStructureAction.TIP_HEIGHT, BasePanel.GAP3, 2, 2, this.tips);
/*     */       
/*     */ 
/*  84 */       this.pnl.setGapRE(BasePanel.GAP2);
/*  85 */       this.pnl.addLineRE("new File Structure", this.fileStructures, this.updateBtn);
/*     */       
/*  87 */       this.fileStructures.setSelectedIndex(FileStructureDtls.getComboIndex(view.getLayout().getFileStructure()));
/*     */       
/*  89 */       super.addMainComponent(this.pnl);
/*     */       
/*  91 */       super.setVisible(true);
/*  92 */       super.setToMaximum(false);
/*     */       
/*  94 */       this.updateBtn.addActionListener(this);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/* 103 */       ComboOption opt = (ComboOption)this.fileStructures.getSelectedItem();
/*     */       
/* 105 */       if (opt != null) {
/* 106 */         this.view.getLayout().setAttribute(Attribute.FILE_STRUCTURE, Integer.valueOf(opt.index));
/* 107 */         this.view.setChanged(true);
/* 108 */         Common.logMsgRaw(29, UtMessages.FILE_FORMAT_CHANGED.get(new Object[] { this.view.getFileNameNoDirectory(), FileStructureDtls.getStructureName(opt.index) }), null);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/Action/ChangeFileStructureAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */