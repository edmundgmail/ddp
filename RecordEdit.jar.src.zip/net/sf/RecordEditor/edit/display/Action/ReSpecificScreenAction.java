/*    */ package net.sf.RecordEditor.edit.display.Action;
/*    */ 
/*    */ import javax.swing.Icon;
/*    */ import net.sf.RecordEditor.re.display.IDisplayFrame;
/*    */ import net.sf.RecordEditor.utils.lang.ReAbstractAction;
/*    */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*    */ 
/*    */ public abstract class ReSpecificScreenAction
/*    */   extends ReAbstractAction
/*    */ {
/*    */   public ReSpecificScreenAction(String name, Icon icon)
/*    */   {
/* 13 */     super(name, icon);
/*    */   }
/*    */   
/*    */   public ReSpecificScreenAction(String name) {
/* 17 */     super(name);
/*    */   }
/*    */   
/*    */ 
/*    */   protected <CLASS> CLASS getDisplay(Class<CLASS> c)
/*    */   {
/* 23 */     CLASS ret = null;
/* 24 */     ReFrame actionHandler = ReFrame.getActiveFrame();
/*    */     
/* 26 */     if ((actionHandler != null) && (c != null))
/*    */     {
/* 28 */       if (c.isAssignableFrom(actionHandler.getClass())) {
/* 29 */         ret = actionHandler;
/* 30 */       } else if ((actionHandler instanceof IDisplayFrame))
/*    */       {
/* 32 */         Object displ = ((IDisplayFrame)actionHandler).getActiveDisplay();
/* 33 */         if ((displ != null) && (c.isAssignableFrom(displ.getClass())))
/* 34 */           ret = (CLASS)displ;
/*    */       }
/*    */     }
/* 37 */     return ret;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/Action/ReSpecificScreenAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */