/*    */ package net.sf.RecordEditor.edit.display.Action;
/*    */ 
/*    */ import java.awt.event.ActionEvent;
/*    */ import net.sf.RecordEditor.edit.display.util.UpdateCsvLayout;
/*    */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ import net.sf.RecordEditor.utils.screenManager.AbstractActiveScreenAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CsvUpdateLayoutAction
/*    */   extends ReSpecificScreenAction
/*    */   implements AbstractActiveScreenAction
/*    */ {
/*    */   public CsvUpdateLayoutAction()
/*    */   {
/* 18 */     super("Update Csv Columns", Common.getRecordIcon(20));
/*    */     
/*    */ 
/* 21 */     checkActionEnabled();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public CsvUpdateLayoutAction(boolean evaluate)
/*    */   {
/* 29 */     super("Update Csv Columns", Common.getRecordIcon(20));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void checkActionEnabled()
/*    */   {
/* 37 */     super.setEnabled(getDisplay(AbstractFileDisplay.class) != null);
/*    */   }
/*    */   
/*    */   public void actionPerformed(ActionEvent arg0)
/*    */   {
/* 42 */     AbstractFileDisplay sourcePnl = (AbstractFileDisplay)getDisplay(AbstractFileDisplay.class);
/* 43 */     if (sourcePnl != null) {
/* 44 */       new UpdateCsvLayout(sourcePnl);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/Action/CsvUpdateLayoutAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */