/*    */ package net.sf.RecordEditor.edit.display.Action;
/*    */ 
/*    */ import java.awt.event.ActionEvent;
/*    */ import net.sf.RecordEditor.edit.display.util.NewFile;
/*    */ import net.sf.RecordEditor.re.openFile.AbstractLayoutSelectCreator;
/*    */ import net.sf.RecordEditor.utils.lang.ReAbstractAction;
/*    */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*    */ 
/*    */ public class NewFileAction
/*    */   extends ReAbstractAction
/*    */ {
/*    */   private AbstractLayoutSelectCreator<?> create;
/*    */   
/*    */   public NewFileAction(AbstractLayoutSelectCreator<?> layoutSelectCreate)
/*    */   {
/* 16 */     super("New File", 8);
/* 17 */     this.create = layoutSelectCreate;
/*    */   }
/*    */   
/*    */   public void actionPerformed(ActionEvent e) {
/* 21 */     ReFrame activeFrame = ReFrame.getActiveFrame();
/* 22 */     if ((activeFrame != null) && (activeFrame.isActionAvailable(12))) {
/* 23 */       activeFrame.executeAction(12);
/*    */     } else {
/* 25 */       new NewFile(this.create.create());
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/Action/NewFileAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */