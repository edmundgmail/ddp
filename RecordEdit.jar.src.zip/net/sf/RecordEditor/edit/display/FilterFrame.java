/*     */ package net.sf.RecordEditor.edit.display;
/*     */ 
/*     */ import java.awt.Container;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDesktopPane;
/*     */ import javax.swing.JTabbedPane;
/*     */ import javax.swing.JTextField;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.RecordEditor.jibx.compare.EditorTask;
/*     */ import net.sf.RecordEditor.jibx.compare.Layout;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*     */ import net.sf.RecordEditor.re.display.DisplayBuilderFactory;
/*     */ import net.sf.RecordEditor.re.display.IChildDisplay;
/*     */ import net.sf.RecordEditor.re.display.IDisplayFrame;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.re.file.filter.FilterDetails;
/*     */ import net.sf.RecordEditor.re.file.filter.FilterPnl2;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.msg.UtMessages;
/*     */ import net.sf.RecordEditor.utils.params.BoolOpt;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMainFrame;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMsg;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.swing.saveRestore.IUpdateDetails;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FilterFrame
/*     */   extends ReFrame
/*     */   implements IUpdateDetails<EditorTask>, IChildDisplay
/*     */ {
/*     */   private FileView fileTable;
/*  74 */   private JTabbedPane filterTab = null;
/*     */   
/*     */   private FilterPnl2 filter1;
/*     */   
/*     */   private FilterPnl2 filter2;
/*     */   
/*     */   private final IDisplayFrame<? extends AbstractFileDisplay> frame;
/*     */   private final AbstractFileDisplay sourceDisplay;
/*  82 */   private KeyAdapter listner = new KeyAdapter()
/*     */   {
/*     */ 
/*     */     public final void keyReleased(KeyEvent event)
/*     */     {
/*     */ 
/*  88 */       switch (event.getKeyCode()) {
/*     */       case 10: 
/*  90 */         if (!Common.TEST_MODE) {
/*  91 */           if ((FilterFrame.this.filterTab == null) || (FilterFrame.this.filterTab.getSelectedIndex() == 0)) {
/*  92 */             FilterFrame.this.filter();
/*     */           } else
/*  94 */             FilterFrame.this.groupFilter();
/*     */         }
/*     */         break;
/*     */       case 27: 
/*  98 */         FilterFrame.this.doDefaultCloseAction();
/*     */       }
/*     */       
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FilterFrame(AbstractFileDisplay tab, FileView fileTbl)
/*     */   {
/* 110 */     super(fileTbl.getFileNameNoDirectory(), "Filter Options", fileTbl.getBaseFile());
/*     */     
/*     */ 
/* 113 */     this.fileTable = fileTbl;
/* 114 */     this.sourceDisplay = tab;
/* 115 */     this.frame = tab.getParentFrame();
/*     */     
/* 117 */     Rectangle screenSize = ReMainFrame.getMasterFrame().getDesktop().getBounds();
/*     */     
/*     */ 
/* 120 */     this.filter1 = new FilterPnl2(this.fileTable.getLayout(), FilterDetails.FT_NORMAL, this);
/* 121 */     this.filter1.getExecute().addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent e) {
/* 124 */         FilterFrame.this.filter();
/*     */       }
/*     */       
/*     */ 
/* 128 */     });
/* 129 */     this.filter1.addReKeyListener(this.listner);
/*     */     
/* 131 */     if (this.fileTable.getLayout().getRecordCount() < 2) {
/* 132 */       getContentPane().add(this.filter1);
/*     */     } else {
/* 134 */       this.filterTab = new JTabbedPane();
/* 135 */       this.filter2 = new FilterPnl2(this.fileTable.getLayout(), FilterDetails.FT_GROUP, this);
/* 136 */       this.filter2.getExecute().addActionListener(new ActionListener()
/*     */       {
/*     */         public void actionPerformed(ActionEvent e) {
/* 139 */           FilterFrame.this.groupFilter();
/*     */         }
/*     */         
/* 142 */       });
/* 143 */       this.filter2.addReKeyListener(this.listner);
/*     */       
/* 145 */       this.filterTab.addKeyListener(this.listner);
/*     */       
/* 147 */       SwingUtils.addTab(this.filterTab, "Filter", "Normal Filter", this.filter1);
/* 148 */       SwingUtils.addTab(this.filterTab, "Filter", "Group Filter", this.filter2);
/*     */       
/* 150 */       getContentPane().add(this.filterTab);
/*     */     }
/*     */     
/* 153 */     pack();
/* 154 */     setSize(Math.min(getWidth(), screenSize.width - 2), Math.min(getHeight(), screenSize.height - 5));
/* 155 */     setVisible(true);
/* 156 */     setToMaximum(false);
/*     */   }
/*     */   
/*     */ 
/*     */   private void filter()
/*     */   {
/* 162 */     Common.runOptionalyInBackground(new Runnable() {
/*     */       public void run() {
/* 164 */         FilterFrame.this.filterRecs(FilterFrame.this.fileTable.getFilteredView(FilterFrame.this.filter1.getFilter()), FilterFrame.this.filter1);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void groupFilter()
/*     */   {
/* 173 */     Common.runOptionalyInBackground(new Runnable() {
/*     */       public void run() {
/* 175 */         FilterFrame.this.filterRecs(FilterFrame.this.fileTable.getFilteredView(FilterFrame.this.filter2.getFilter(), FilterFrame.this.filter2.getGroupRecordId()), FilterFrame.this.filter2);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */   private void filterRecs(FileView fileView, FilterPnl2 filterPnl)
/*     */   {
/* 183 */     if (fileView == null) {
/* 184 */       filterPnl.getMessageFld().setText("No records matched the filter");
/*     */     } else {
/* 186 */       AbstractFileDisplay l = DisplayBuilderFactory.newLineList(this.frame, this.fileTable.getLayout(), fileView, this.fileTable.getBaseFile());
/* 187 */       if (!Common.OPTIONS.useSeperateScreens.isSelected()) {
/* 188 */         moveToBack();
/* 189 */         l.getParentFrame().moveToFront();
/* 190 */         l.getParentFrame().setToActiveFrame();
/*     */       }
/* 192 */       l.getParentFrame().setToActiveTab(l);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void executeAction(int action)
/*     */   {
/* 202 */     if (action == 23) {
/* 203 */       this.filter1.showHelpRE();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isActionAvailable(int action)
/*     */   {
/* 210 */     return action == 23;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final FilterDetails getFilter()
/*     */   {
/* 219 */     if ((this.filterTab != null) && (this.filterTab.getSelectedIndex() == 1)) {
/* 220 */       return this.filter2.getFilter();
/*     */     }
/* 222 */     return this.filter1.getFilter();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFromSavedDetails(EditorTask task)
/*     */   {
/* 230 */     if ((task == null) || (task.filter == null)) {
/* 231 */       Common.logMsg(UtMessages.NOT_A_FILTER.get(), null);
/*     */     } else {
/* 233 */       updateFromExternalLayout(task.filter);
/*     */     }
/*     */   }
/*     */   
/*     */   public final void update(EditorTask task)
/*     */   {
/* 239 */     setFromSavedDetails(task);
/*     */   }
/*     */   
/*     */   public final void updateFromExternalLayout(Layout values) {
/* 243 */     if (this.filterTab == null) {
/* 244 */       this.filter1.update(values);
/* 245 */     } else if ((values.groupHeader == null) || ("".equals(values.groupHeader))) {
/* 246 */       this.filter1.update(values);
/* 247 */       this.filterTab.setSelectedIndex(0);
/*     */     } else {
/* 249 */       this.filter2.update(values);
/*     */       
/* 251 */       this.filterTab.setSelectedIndex(1);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractFileDisplay getSourceDisplay()
/*     */   {
/* 262 */     return this.sourceDisplay;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/FilterFrame.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */