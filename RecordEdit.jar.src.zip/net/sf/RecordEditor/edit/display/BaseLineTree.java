/*     */ package net.sf.RecordEditor.edit.display;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.io.PrintStream;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.Action;
/*     */ import javax.swing.JPopupMenu;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTree;
/*     */ import javax.swing.event.TableModelEvent;
/*     */ import javax.swing.event.TableModelListener;
/*     */ import javax.swing.event.TreeExpansionEvent;
/*     */ import javax.swing.event.TreeExpansionListener;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import javax.swing.tree.TreePath;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.RecordEditor.edit.display.util.RowChangeListner;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplayWithFieldHide;
/*     */ import net.sf.RecordEditor.re.display.IDisplayBuilder;
/*     */ import net.sf.RecordEditor.re.file.AbstractLineNode;
/*     */ import net.sf.RecordEditor.re.file.AbstractTreeFrame;
/*     */ import net.sf.RecordEditor.re.file.FieldMapping;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.re.tree.LineTreeTabelModel;
/*     */ import net.sf.RecordEditor.utils.MenuPopupListener;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.ReAbstractAction;
/*     */ import net.sf.RecordEditor.utils.params.BoolOpt;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.ButtonTableRendor;
/*     */ import net.sf.RecordEditor.utils.swing.LayoutCombo;
/*     */ import net.sf.RecordEditor.utils.swing.ShowFieldsMenu;
/*     */ import net.sf.RecordEditor.utils.swing.treeTable.JTreeTable;
/*     */ import net.sf.RecordEditor.utils.swing.treeTable.TreeTableModelAdapter;
/*     */ 
/*     */ public abstract class BaseLineTree<LNode extends AbstractLineNode> extends BaseDisplay implements AbstractFileDisplayWithFieldHide, TableModelListener, AbstractCreateChildScreen, AbstractTreeFrame<LNode>
/*     */ {
/*  45 */   private static final int MINIMUM_TREE_COLUMN_WIDTH = net.sf.RecordEditor.utils.swing.SwingUtils.STANDARD_FONT_WIDTH * 22;
/*     */   
/*     */   private static final int STANDARD_COLUMNS = 2;
/*     */   
/*     */   protected JTreeTable treeTable;
/*     */   private JScrollPane treeTablePane;
/*     */   protected LineTreeTabelModel model;
/*     */   protected TreeTableModelAdapter tableModel;
/*     */   protected FileView view;
/*     */   protected LNode root;
/*  55 */   protected ButtonTableRendor buttonRendor = new ButtonTableRendor();
/*     */   
/*  57 */   private ILineDisplay childScreen = null;
/*     */   protected int cols2skip;
/*     */   protected int lastTblRow;
/*     */   protected int lastLineNum;
/*  61 */   protected int popupRow; protected int popupCol = 0;
/*     */   
/*  63 */   private boolean isPrefered = false;
/*     */   
/*     */ 
/*     */   private FieldMapping fieldMapping;
/*     */   
/*     */ 
/*     */   private RowChangeListner keyListner;
/*     */   
/*     */ 
/*  72 */   private ShowFieldsMenu showFields = new ShowFieldsMenu() {
/*     */     public boolean showColumn(TableColumn colDef, int originalColumn) {
/*  74 */       TableColumnModel mdl = BaseLineTree.this.tblDetails.getColumnModel();
/*  75 */       if (BaseLineTree.this.getLayoutIndex() < BaseLineTree.this.layout.getRecordCount()) {
/*  76 */         BaseLineTree.this.fieldMapping.showColumn(BaseLineTree.this.getLayoutIndex(), colDef.getModelIndex() - BaseLineTree.this.getColAdjust());
/*     */       }
/*  78 */       mdl.addColumn(colDef);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  84 */       mdl.moveColumn(mdl.getColumnCount() - 1, originalColumn);
/*  85 */       return true;
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BaseLineTree(FileView viewOfFile, boolean mainView, boolean prefered, int columnsToSkip, int option)
/*     */   {
/*  95 */     super("Tree View", viewOfFile, mainView, false, false, prefered, false, option);
/*     */     
/*  97 */     this.view = viewOfFile;
/*  98 */     this.cols2skip = columnsToSkip;
/*     */     
/* 100 */     this.fieldMapping = new FieldMapping(getFieldCounts());
/*     */     
/* 102 */     this.actualPnl.addReKeyListener(new BaseDisplay.DelKeyWatcher(this));
/*     */   }
/*     */   
/*     */   protected final void init_100_setupScreenFields(AbstractAction[] extraActions)
/*     */   {
/* 107 */     this.view.addTableModelListener(this);
/*     */     
/* 109 */     this.model = new LineTreeTabelModel(this.view, this.root, this.cols2skip, this.view.getLayout().isMapPresent());
/* 110 */     this.treeTable = new JTreeTable(this.model);
/* 111 */     this.treeTablePane = new JScrollPane(this.treeTable);
/* 112 */     this.tableModel = this.treeTable.getTableModel();
/* 113 */     this.treeTable.setAutoResizeMode(0);
/* 114 */     setJTable(this.treeTable);
/* 115 */     this.treeTable.putClientProperty("terminateEditOnFocusLost", Boolean.TRUE);
/* 116 */     this.treeTable.getTree().setRootVisible(false);
/* 117 */     this.treeTable.getTree().setShowsRootHandles(true);
/* 118 */     this.keyListner = new RowChangeListner(this.treeTable, this);
/* 119 */     this.tableModel.addTableModelListener(new TableModelListener()
/*     */     {
/*     */       public void tableChanged(TableModelEvent e) {
/* 122 */         BaseLineTree.this.checkForResize(e);
/*     */       }
/*     */       
/*     */ 
/* 126 */     });
/* 127 */     this.actualPnl.setHelpURLre(Common.formatHelpURL("HlpRe14.htm"));
/*     */     
/*     */ 
/* 130 */     initToolTips(2);
/*     */     
/* 132 */     defColumns(0);
/*     */     
/*     */ 
/* 135 */     AbstractAction[] mainActions = { new ReAbstractAction("Edit Record")
/*     */     {
/*     */ 
/* 138 */       public void actionPerformed(ActionEvent e) { BaseLineTree.this.newLineFrame(BaseLineTree.this.getNodeForRow(BaseLineTree.this.popupRow)); } }, null, new net.sf.RecordEditor.edit.display.Action.AutofitAction(this), null, new ReAbstractAction("Expand Tree")
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 146 */       new ReAbstractAction
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         public void actionPerformed(ActionEvent e) {
/* 146 */           BaseLineTree.this.treeTable.getTree().expandRow(BaseLineTree.this.popupRow); } }, new ReAbstractAction("Fully Expand Tree")
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 151 */       new ReAbstractAction
/*     */       {
/*     */ 
/*     */ 
/*     */         public void actionPerformed(ActionEvent e) {
/* 151 */           BaseLineTree.this.doFullExpansion(BaseLineTree.this.getNodeForRow(BaseLineTree.this.popupRow)); } }, new ReAbstractAction("Collapse Tree")
/*     */       {
/*     */ 
/*     */         public void actionPerformed(ActionEvent e)
/*     */         {
/*     */ 
/* 157 */           BaseLineTree.this.treeTable.getTree().collapseRow(BaseLineTree.this.popupRow);
/*     */         }
/*     */       } };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 164 */     if ((extraActions != null) && (mainActions.length > 0)) {
/* 165 */       AbstractAction[] tmpActions = mainActions;
/* 166 */       mainActions = new AbstractAction[tmpActions.length + extraActions.length];
/*     */       
/* 168 */       System.arraycopy(tmpActions, 0, mainActions, 0, tmpActions.length);
/* 169 */       System.arraycopy(extraActions, 0, mainActions, tmpActions.length, extraActions.length);
/*     */     }
/* 171 */     MenuPopupListener mainPopup = new MenuPopupListener(mainActions, true, this.treeTable) {
/*     */       public void mousePressed(MouseEvent m) {
/* 173 */         int col = BaseLineTree.this.treeTable.columnAtPoint(m.getPoint());
/*     */         
/* 175 */         BaseLineTree.this.popupRow = BaseLineTree.this.treeTable.rowAtPoint(m.getPoint());
/*     */         
/* 177 */         BaseLineTree.this.checkForTblRowChange(BaseLineTree.this.popupRow);
/* 178 */         if (BaseLineTree.this.treeTable.getColumnModel().getColumn(col).getModelIndex() == 0) {
/* 179 */           BaseLineTree.this.newLineFrame(BaseLineTree.this.getNodeForRow(BaseLineTree.this.popupRow));
/*     */         } else {
/* 181 */           super.mousePressed(m);
/*     */         }
/*     */       }
/*     */       
/*     */       protected boolean isOkToShowPopup(MouseEvent e) {
/* 186 */         BaseLineTree.this.popupCol = BaseLineTree.this.treeTable.columnAtPoint(e.getPoint());
/* 187 */         BaseLineTree.this.popupRow = BaseLineTree.this.treeTable.rowAtPoint(e.getPoint());
/*     */         
/* 189 */         return BaseLineTree.this.popupCol > 0;
/*     */       }
/* 191 */     };
/* 192 */     mainPopup.getPopup().addSeparator();
/* 193 */     mainPopup.getPopup().add(new ReAbstractAction("Hide Column") {
/*     */       public void actionPerformed(ActionEvent e) {
/* 195 */         BaseLineTree.this.hideColumn(BaseLineTree.this.popupCol);
/*     */       }
/*     */       
/* 198 */     });
/* 199 */     mainPopup.getPopup().add(this.showFields.getMenu());
/*     */     
/* 201 */     this.treeTable.addMouseListener(mainPopup);
/*     */     
/* 203 */     this.treeTable.getTree().addTreeExpansionListener(new TreeExpansionListener()
/*     */     {
/*     */       public void treeCollapsed(TreeExpansionEvent event) {}
/*     */       
/*     */       public void treeExpanded(TreeExpansionEvent event) {
/* 208 */         BaseLineTree.this.defColumns(BaseLineTree.this.getLayoutIndex());
/*     */       }
/*     */     });
/*     */     
/*     */ 
/* 213 */     if (Common.OPTIONS.useNewTreeExpansion.isSelected())
/*     */     {
/*     */ 
/* 216 */       for (int i = 0; (i < this.treeTable.getTree().getRowCount()) && (this.treeTable.getTree().getRowCount() < 50); i++) {
/* 217 */         this.treeTable.getTree().expandRow(i);
/*     */       }
/* 219 */     } else if (this.tableModel.getRowCount() == 1) {
/* 220 */       this.treeTable.getTree().expandRow(0);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void init_200_LayoutScreen()
/*     */   {
/* 229 */     this.actualPnl.setGapRE(BasePanel.GAP1);
/*     */     
/* 231 */     this.actualPnl.addComponentRE(1, 5, -1.0D, BasePanel.GAP, 2, 2, this.treeTablePane);
/*     */     
/*     */ 
/*     */ 
/* 235 */     Common.calcColumnWidths(this.treeTable, 3);
/*     */     
/* 237 */     LayoutCombo combo = getLayoutCombo();
/* 238 */     if ((this.layout.getRecordCount() > 1) && (combo.getPreferedIndex() > 0) && (Common.usePrefered())) {
/* 239 */       combo.setSelectedIndex(combo.getPreferedIndex());
/* 240 */       setTableFormatDetails(combo.getPreferedIndex());
/* 241 */       fireLayoutIndexChanged();
/*     */     } else {
/* 243 */       setLayoutIdx();
/*     */     }
/* 245 */     this.fileView.setCurrLayoutIdx(super.getLayoutIndex());
/*     */   }
/*     */   
/*     */ 
/*     */   public void setScreenSize(boolean mainframe)
/*     */   {
/* 251 */     DisplayFrame parentFrame = getParentFrame();
/*     */     
/* 253 */     parentFrame.bldScreen();
/*     */     
/* 255 */     parentFrame.setBounds(1, 1, this.screenSize.width - 1, this.screenSize.height - 1);
/*     */     
/*     */ 
/*     */ 
/* 259 */     parentFrame.bldScreen();
/* 260 */     parentFrame.setToMaximum(true);
/*     */     
/* 262 */     parentFrame.setVisible(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNewLayout(AbstractLayoutDetails newLayout)
/*     */   {
/* 272 */     super.setNewLayout(newLayout);
/* 273 */     LayoutCombo combo = getLayoutCombo();
/* 274 */     if ((this.layout.getRecordCount() > 1) && (combo.getPreferedIndex() > 0) && (Common.usePrefered())) {
/* 275 */       combo.setSelectedIndex(combo.getPreferedIndex());
/* 276 */       setTableFormatDetails(combo.getPreferedIndex());
/* 277 */       fireLayoutIndexChanged();
/*     */     } else {
/* 279 */       setLayoutIdx();
/* 280 */       defColumns(combo.getSelectedIndex());
/*     */     }
/* 282 */     this.fieldMapping.resetMapping(getFieldCounts());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void tableChanged(TableModelEvent event) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private void newLineFrame(LNode n)
/*     */   {
/* 295 */     int lineNumber = n.getLineNumber();
/*     */     
/* 297 */     if (lineNumber < 0) {
/* 298 */       lineNumber = n.getDefaultLineNumber();
/*     */     }
/*     */     
/* 301 */     if (lineNumber < 0)
/*     */     {
/* 303 */       DisplayBldr.newDisplay(5, "", getParentFrame(), this.fileView.getLayout(), this.fileView, n.getLine());
/*     */     }
/*     */     else {
/* 306 */       newLineFrame(getFileView(), lineNumber);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void fireLayoutIndexChanged()
/*     */   {
/* 318 */     int idx = getLayoutIndex();
/* 319 */     this.fileView.setCurrLayoutIdx(idx);
/*     */     
/* 321 */     if (this.model.getRecordIndex() != idx) {
/* 322 */       this.model.setRecordIndex(idx);
/* 323 */       this.tableModel.fireTableStructureChanged();
/* 324 */       defColumns(idx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final LNode getNodeForRow(int row)
/*     */   {
/* 336 */     if (row >= 0) {
/* 337 */       TreePath treePath = this.treeTable.getPathForRow(row);
/* 338 */       if (treePath != null) {
/* 339 */         return (AbstractLineNode)treePath.getLastPathComponent();
/*     */       }
/*     */     }
/* 342 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void defColumns(int idx)
/*     */   {
/* 350 */     int columns = this.model.getColumnCount();
/*     */     
/* 352 */     defineColumns(columns, this.model.getSkipColumns(), this.cols2skip);
/*     */     
/* 354 */     TableColumn tc = this.treeTable.getColumnModel().getColumn(0);
/* 355 */     tc.setCellRenderer(this.buttonRendor);
/*     */     
/* 357 */     tc.setMaxWidth(5);
/* 358 */     tc.setResizable(false);
/*     */     
/* 360 */     if (this.treeTable.getColumnModel().getColumnCount() > 1) {
/* 361 */       tc = this.treeTable.getColumnModel().getColumn(1);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 366 */       tc.setPreferredWidth(Math.max(tc.getPreferredWidth(), MINIMUM_TREE_COLUMN_WIDTH));
/*     */       
/*     */ 
/* 369 */       int layoutIdx = getLayoutIndex();
/* 370 */       this.isPrefered = (layoutIdx == getLayoutCombo().getPreferedIndex());
/*     */       
/* 372 */       setKeylistner();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void setKeylistner()
/*     */   {
/* 380 */     this.treeTable.removeKeyListener(this.keyListner);
/* 381 */     if ((this.isPrefered) || (this.childScreen != null)) {
/* 382 */       this.treeTable.addKeyListener(this.keyListner);
/*     */       
/* 384 */       this.lastTblRow = -1;
/* 385 */       this.lastLineNum = -1;
/* 386 */       checkForTblRowChange(this.treeTable.getSelectedRow());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void doFullExpansion(AbstractLineNode node)
/*     */   {
/* 396 */     if ((node != null) && (!node.isLeaf())) {
/* 397 */       for (int j = 0; j < node.getChildCount(); j++) {
/* 398 */         doFullExpansion((AbstractLineNode)node.getChildAt(j));
/*     */       }
/* 400 */       this.treeTable.getTree().expandPath(new TreePath(node.getPath()));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final int getTreeTblRow()
/*     */   {
/* 410 */     int row = this.treeTable.getEditingRow();
/*     */     
/*     */ 
/* 413 */     if ((row < 0) && (this.treeTable.getSelectedRowCount() > 0)) {
/* 414 */       row = this.treeTable.getSelectedRow();
/*     */     }
/* 416 */     return row;
/*     */   }
/*     */   
/*     */ 
/*     */   public final void checkForRowChange(int row)
/*     */   {
/* 422 */     if ((this.lastLineNum != row) && (row >= 0) && (row < this.fileView.getRowCount())) {
/* 423 */       setNewLineDtls(this.fileView.getLine(row));
/* 424 */       this.lastLineNum = row;
/* 425 */       this.lastTblRow = -1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public final void checkForTblRowChange(int row)
/*     */   {
/* 432 */     if (this.lastTblRow != row) {
/* 433 */       LNode node = getNodeForRow(row);
/* 434 */       AbstractLine line = null;
/* 435 */       this.lastLineNum = -1;
/* 436 */       if ((node != null) && ((line = node.getLine()) != null)) {
/* 437 */         setNewLineDtls(line);
/*     */         
/* 439 */         this.lastLineNum = node.getLineNumber();
/*     */       }
/*     */       
/*     */ 
/* 443 */       this.lastTblRow = row;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void setNewLineDtls(AbstractLine line)
/*     */   {
/* 450 */     if (this.isPrefered) {
/* 451 */       int recordIdx = line.getPreferredLayoutIdx();
/* 452 */       if (recordIdx != this.model.getDefaultPreferredIndex()) {
/* 453 */         this.model.setDefaultPreferredIndex(recordIdx);
/*     */         
/* 455 */         TableColumnModel columns = this.tblDetails.getColumnModel();
/* 456 */         int last = Math.min(this.model.getColumnCount(), columns.getColumnCount());
/* 457 */         for (int i = 0; i < last; i++)
/*     */         {
/* 459 */           columns.getColumn(i).setHeaderValue(this.model.getColumnName(columns.getColumn(i).getModelIndex()));
/*     */         }
/*     */         
/* 462 */         System.out.println("!!! " + (this.treeTablePane.getColumnHeader() == null) + " " + (this.treeTablePane.getRowHeader() == null));
/*     */         
/* 464 */         this.treeTablePane.getColumnHeader().repaint();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 469 */     if (this.childScreen != null) {
/* 470 */       this.childScreen.setLine(line);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeChildScreen()
/*     */   {
/* 480 */     this.childScreen = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setChildScreen(ILineDisplay childScreen)
/*     */   {
/* 487 */     this.childScreen = childScreen;
/* 488 */     setKeylistner();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ILineDisplay getChildScreen()
/*     */   {
/* 496 */     return this.childScreen;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int getInsertAfterPosition()
/*     */   {
/* 505 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected BaseDisplay getNewDisplay(FileView view)
/*     */   {
/* 523 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean[] getFieldVisibility(int recordIndex)
/*     */   {
/* 531 */     return this.fieldMapping.getFieldVisibility(recordIndex);
/*     */   }
/*     */   
/*     */   protected final int getColAdjust() {
/* 535 */     return 2 - this.cols2skip;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFieldVisibility(int recordIndex, boolean[] fieldVisibile)
/*     */   {
/* 544 */     this.fieldMapping.setFieldVisibilty(recordIndex, fieldVisibile);
/*     */     
/* 546 */     if (recordIndex == getLayoutIndex()) {
/* 547 */       int adj = getColAdjust();
/* 548 */       this.showFields.setFieldVisibility(this.tblDetails.getColumnModel(), adj, adj, fieldVisibile);
/*     */     }
/*     */     
/* 551 */     getParentFrame().setToActiveFrame();
/*     */   }
/*     */   
/*     */   private void hideColumn(int col)
/*     */   {
/* 556 */     JTable tblDetails = getJTable();
/* 557 */     TableColumn colDef = tblDetails.getColumnModel().getColumn(col);
/*     */     
/* 559 */     if (getLayoutIndex() < this.layout.getRecordCount()) {
/* 560 */       this.fieldMapping.hideColumn(getLayoutIndex(), colDef.getModelIndex() - getColAdjust());
/*     */     }
/*     */     
/* 563 */     tblDetails.getColumnModel().removeColumn(colDef);
/*     */     
/* 565 */     this.showFields.hideColumn(colDef, col);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isActionAvailable(int action)
/*     */   {
/* 571 */     return (action == 50) || (super.isActionAvailable(action));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LNode getRoot()
/*     */   {
/* 580 */     return this.root;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getAdjColumn(int recordIdx, int inRow)
/*     */   {
/* 590 */     return FieldMapping.getAdjColumn(this.fieldMapping, recordIdx, inRow) + getColAdjust();
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/BaseLineTree.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */