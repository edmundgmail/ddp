/*     */ package net.sf.RecordEditor.edit.display.models;
/*     */ 
/*     */ import net.sf.JRecord.Details.AbstractChildDetails;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.AbstractTreeDetails;
/*     */ import net.sf.RecordEditor.re.file.DisplayType;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.params.BoolOpt;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMainFrame;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LineModel
/*     */   extends BaseLineModel
/*     */ {
/*     */   private int currentRow;
/*     */   private AbstractLine currentLine;
/*  52 */   boolean oneLineHex = true;
/*     */   
/*     */ 
/*     */ 
/*     */   private int columnCount;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public LineModel(FileView file)
/*     */   {
/*  63 */     super(file);
/*     */     
/*  65 */     calcColumnCounts();
/*     */   }
/*     */   
/*     */   public LineModel(FileView file, int cols) {
/*  69 */     super(file, cols);
/*     */     
/*  71 */     calcColumnCounts();
/*     */   }
/*     */   
/*     */   private void calcColumnCounts() {
/*  75 */     this.columnCount = (this.columnName.length - 1 + this.firstDataColumn - 4);
/*  76 */     if (getFileView().isBinaryFile()) {
/*  77 */       this.columnCount += 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getColumnCount()
/*     */   {
/*  86 */     return this.columnCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getValueAt(int row, int col)
/*     */   {
/* 101 */     if (col < this.firstDataColumn)
/* 102 */       return super.getValueAt(row, col);
/* 103 */     if (this.currentLine == null) {
/* 104 */       return null;
/*     */     }
/*     */     
/* 107 */     int idx = getFixedCurrentLayout();
/* 108 */     if (idx >= this.layout.getRecordCount()) {
/* 109 */       if (col == this.firstDataColumn)
/* 110 */         return this.currentLine.getFullLine();
/* 111 */       if (col == this.firstDataColumn + 1)
/* 112 */         return this.currentLine.getFullLine();
/* 113 */       if (this.oneLineHex) {
/* 114 */         return null;
/*     */       }
/* 116 */       return this.currentLine.getData();
/*     */     }
/* 118 */     if (col == this.firstDataColumn)
/*     */       try {
/* 120 */         return this.currentLine.getField(getFixedCurrentLayout(), getRealRowWithKey(row));
/*     */       } catch (Exception e) {
/* 122 */         e.printStackTrace();
/* 123 */         return null;
/*     */       }
/* 125 */     if (isKeyRow(row))
/* 126 */       return null;
/* 127 */     if (col == this.firstDataColumn + 1)
/* 128 */       return this.currentLine.getFieldText(getFixedCurrentLayout(), getRealRow(row));
/* 129 */     if (this.oneLineHex) {
/* 130 */       return this.currentLine.getFieldHex(getFixedCurrentLayout(), getRealRow(row));
/*     */     }
/* 132 */     return this.currentLine.getFieldBytes(getFixedCurrentLayout(), getRealRow(row));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValueAt(Object val, int row, int col)
/*     */   {
/* 152 */     if (col == this.firstDataColumn) {
/* 153 */       getFileView().setValueAt(ReMainFrame.getMasterFrame(), getFixedCurrentLayout(), this.currentLine, this.currentRow, getRowLocal(row), val);
/*     */ 
/*     */     }
/* 156 */     else if (!isKeyRow(row))
/*     */     {
/* 158 */       if ((getCurrentLayout() < this.layout.getRecordCount()) && ((col == this.hexColumn) || (col == this.firstDataColumn + 1)))
/*     */       {
/* 160 */         int inputType = 3;
/* 161 */         String value = "";
/* 162 */         if (val != null) {
/* 163 */           value = val.toString();
/*     */         }
/*     */         
/* 166 */         if (col == this.firstDataColumn + 1) {
/* 167 */           inputType = 2;
/*     */         }
/* 169 */         getFileView().setHexTextValueAt(ReMainFrame.getMasterFrame(), inputType, getFixedCurrentLayout(), this.currentRow, getRowLocal(row), value);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getActualLineNumber()
/*     */   {
/* 183 */     this.currentRow = getFileView().indexOf(this.currentLine);
/* 184 */     return this.currentRow;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isCellEditable(int row, int col)
/*     */   {
/* 192 */     return (col >= this.firstDataColumn) && ((this.oneLineHex) || (col < this.hexColumn)) && ((getFixedCurrentLayout() < this.layout.getRecordCount()) || ((!getFileView().isBinaryFile()) && (Common.OPTIONS.allowTextEditting.isSelected())));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setOneLineHex(boolean newOneLineHex)
/*     */   {
/* 206 */     this.oneLineHex = newOneLineHex;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractLine getCurrentLine()
/*     */   {
/* 214 */     return this.currentLine;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCurrentLine(int newCurrentRow, int defaultLayout)
/*     */   {
/* 225 */     this.currentRow = newCurrentRow;
/* 226 */     this.currentLine = null;
/* 227 */     int newIdx = defaultLayout;
/*     */     
/* 229 */     if (newCurrentRow < getFileView().getRowCount()) {
/* 230 */       this.currentLine = getFileView().getLine(newCurrentRow);
/* 231 */       newIdx = this.currentLine.getPreferredLayoutIdx();
/*     */     }
/*     */     
/* 234 */     setIndex(newIdx, defaultLayout);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCurrentLine(AbstractLine line, int defaultLayout)
/*     */   {
/* 243 */     this.currentLine = line;
/* 244 */     if ((this.currentLine == null) && (getFileView().getRowCount() > 0)) {
/* 245 */       this.currentLine = getFileView().getLine(0);
/*     */     }
/* 247 */     setIndex(this.currentLine.getPreferredLayoutIdx(), defaultLayout);
/*     */   }
/*     */   
/*     */   private void setIndex(int newIdx, int defaultLayout)
/*     */   {
/* 252 */     if (newIdx == -121) {
/* 253 */       fireTableDataChanged();
/* 254 */       if (DisplayType.displayType(this.layout, defaultLayout) == 1) {
/* 255 */         defaultLayout = 0;
/*     */       }
/* 257 */       newIdx = defaultLayout;
/* 258 */     } else if (newIdx == getFixedCurrentLayout()) {
/* 259 */       fireTableDataChanged();
/*     */     } else {
/* 261 */       fireTableStructureChanged();
/*     */     }
/*     */     
/* 264 */     if (newIdx != -121) {
/* 265 */       setCurrentLayout(newIdx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean showKey()
/*     */   {
/* 275 */     boolean ret = false;
/*     */     
/* 277 */     if (this.currentLine != null) {
/* 278 */       if ((this.currentLine.getTreeDetails() != null) && (this.currentLine.getTreeDetails().getChildDefinitionInParent() != null))
/*     */       {
/* 280 */         ret = this.currentLine.getTreeDetails().getChildDefinitionInParent().isMap();
/*     */       } else {
/*     */         try {
/* 283 */           ret = this.currentLine.getField(0, 64771) != null;
/*     */         }
/*     */         catch (Exception e) {}
/*     */       }
/*     */     }
/* 288 */     return ret;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/models/LineModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */