/*     */ package net.sf.RecordEditor.edit.display.models;
/*     */ 
/*     */ import javax.swing.table.AbstractTableModel;
/*     */ import net.sf.RecordEditor.jibx.compare.SortFields;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SortFieldMdl
/*     */   extends AbstractTableModel
/*     */ {
/*  25 */   private static final String[] COLUMN_NAMES = LangConversion.convertColHeading("Sort", new String[] { "Field", "Ascending" });
/*     */   
/*     */   private String[] fieldName;
/*     */   
/*     */   private boolean[] ascending;
/*     */   
/*  31 */   private int columnCount = 2;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SortFieldMdl(int tableSize)
/*     */   {
/*  40 */     this.fieldName = new String[tableSize];
/*  41 */     this.ascending = new boolean[tableSize];
/*     */     
/*  43 */     resetFields();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void resetFields()
/*     */   {
/*  52 */     for (int i = 0; i < this.fieldName.length; i++) {
/*  53 */       this.ascending[i] = true;
/*  54 */       this.fieldName[i] = " ";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getColumnName(int column)
/*     */   {
/*  63 */     return COLUMN_NAMES[column];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isCellEditable(int rowIndex, int columnIndex)
/*     */   {
/*  70 */     return true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setValueAt(Object aValue, int rowIndex, int columnIndex)
/*     */   {
/*  78 */     if (aValue != null) {
/*  79 */       if (columnIndex == 0) {
/*  80 */         this.fieldName[rowIndex] = aValue.toString();
/*     */       } else {
/*  82 */         this.ascending[rowIndex] = ((Boolean)aValue).booleanValue();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getColumnCount()
/*     */   {
/*  91 */     return this.columnCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setColumnCount(int newColumnCount)
/*     */   {
/* 100 */     this.columnCount = newColumnCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getRowCount()
/*     */   {
/* 107 */     return this.ascending.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getValueAt(int rowIndex, int columnIndex)
/*     */   {
/* 115 */     if (columnIndex == 0) {
/* 116 */       return this.fieldName[rowIndex];
/*     */     }
/* 118 */     return Boolean.valueOf(this.ascending[rowIndex]);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getAscending(int index)
/*     */   {
/* 127 */     return this.ascending[index];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFieldName(int index)
/*     */   {
/* 136 */     return this.fieldName[index];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SortFields[] getSortFields()
/*     */   {
/* 147 */     int size = 0;
/* 148 */     for (int i = 0; i < this.fieldName.length; i++) {
/* 149 */       if ((this.fieldName[i] != null) && (!"".equals(this.fieldName[i]))) {
/* 150 */         size++;
/*     */       }
/*     */     }
/*     */     
/* 154 */     int j = 0;
/* 155 */     SortFields[] ret = new SortFields[size];
/* 156 */     for (i = 0; i < ret.length; i++) {
/* 157 */       if ((this.fieldName[i] != null) && (!"".equals(this.fieldName[i]))) {
/* 158 */         ret[j] = new SortFields();
/* 159 */         ret[j].fieldName = this.fieldName[i];
/* 160 */         ret[j].ascending = this.ascending[i];
/* 161 */         j++;
/*     */       }
/*     */     }
/*     */     
/* 165 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSortTree(SortFields[] fieldDetails)
/*     */   {
/* 175 */     for (int i = 0; i < fieldDetails.length; i++) {
/* 176 */       this.fieldName[i] = fieldDetails[i].fieldName;
/* 177 */       this.ascending[i] = fieldDetails[i].ascending;
/*     */     }
/*     */     
/* 180 */     for (i = fieldDetails.length; i < this.fieldName.length; i++) {
/* 181 */       this.fieldName[i] = " ";
/* 182 */       this.ascending[i] = false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/models/SortFieldMdl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */