/*    */ package net.sf.RecordEditor.edit.display.models;
/*    */ 
/*    */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*    */ import net.sf.RecordEditor.re.file.FileView;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ import net.sf.RecordEditor.utils.params.BoolOpt;
/*    */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Line2ColModel
/*    */   extends BaseLineModel
/*    */ {
/*    */   public Line2ColModel(FileView file)
/*    */   {
/* 21 */     super(file);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getColumnCount()
/*    */   {
/* 30 */     return getFileView().getRowCount() + this.firstDataColumn;
/*    */   }
/*    */   
/*    */ 
/*    */   public String getColumnName(int col)
/*    */   {
/* 36 */     if (col >= this.firstDataColumn) {
/* 37 */       return "Row " + (col - this.firstDataColumn + 1);
/*    */     }
/* 39 */     return super.getColumnName(col);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public Object getValueAt(int row, int col)
/*    */   {
/* 48 */     if (col >= this.firstDataColumn) {
/* 49 */       return getFileView().getValueAt1(super.getCurrentLayout(), col - this.firstDataColumn, getRowLocal(row) + 2);
/*    */     }
/*    */     
/*    */ 
/*    */ 
/* 54 */     return super.getValueAt(row, col);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isCellEditable(int rowIndex, int columnIndex)
/*    */   {
/* 62 */     return (columnIndex >= this.firstDataColumn) && ((getFixedCurrentLayout() < this.layout.getRecordCount()) || ((!getFileView().isBinaryFile()) && (Common.OPTIONS.allowTextEditting.isSelected())));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setValueAt(Object val, int row, int col)
/*    */   {
/* 80 */     if (col >= this.firstDataColumn) {
/* 81 */       getFileView().setValueAt(super.getCurrentLayout(), val, col - this.firstDataColumn, getRowLocal(row) + 2);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/models/Line2ColModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */