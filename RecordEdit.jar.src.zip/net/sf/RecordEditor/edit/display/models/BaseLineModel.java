/*     */ package net.sf.RecordEditor.edit.display.models;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import javax.swing.table.AbstractTableModel;
/*     */ import net.sf.JRecord.Common.BasicKeyedField;
/*     */ import net.sf.JRecord.Common.IFieldDetail;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.JRecord.Details.LayoutDetail;
/*     */ import net.sf.JRecord.External.ExternalConversion;
/*     */ import net.sf.RecordEditor.re.file.FieldMapping;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.re.file.IGetView;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.params.BoolOpt;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseLineModel
/*     */   extends AbstractTableModel
/*     */   implements IGetView
/*     */ {
/*     */   protected static final int FIRST_DATA_COLUMN = 4;
/*     */   public final int firstDataColumn;
/*     */   public final int hexColumn;
/*     */   private FileView fileView;
/*     */   protected AbstractLayoutDetails layout;
/*     */   private int currentLayout;
/*  38 */   protected String[] columnName = LangConversion.convertColHeading("Single_Record", new String[] { "Field", "Start", "Len", "Type", "Data", "Text", "Hex" });
/*     */   
/*     */ 
/*     */ 
/*  42 */   private FieldMapping fieldMapping = null;
/*     */   
/*     */   private int[] lastFieldCounts;
/*  45 */   private HashMap<Integer, String> typeNames = new HashMap(400);
/*     */   
/*     */   public BaseLineModel(FileView file)
/*     */   {
/*  49 */     this(file, Common.OPTIONS.typeOnRecordScreen.isSelected() ? 4 : 3);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public BaseLineModel(FileView file, int dataColumn)
/*     */   {
/*  56 */     this.fileView = file;
/*  57 */     this.firstDataColumn = dataColumn;
/*  58 */     this.hexColumn = (dataColumn + 2);
/*     */     
/*  60 */     this.layout = file.getLayout();
/*     */     
/*  62 */     this.lastFieldCounts = getFieldCounts();
/*  63 */     this.fieldMapping = new FieldMapping((int[])this.lastFieldCounts.clone());
/*     */     
/*     */     try
/*     */     {
/*  67 */       ArrayList<BasicKeyedField> types = ExternalConversion.getTypes(Common.getConnectionIndex());
/*  68 */       tblId = Common.getTblLookupKey(1);
/*     */       
/*  70 */       for (BasicKeyedField type : types) {
/*  71 */         if ((type.name != null) && (!type.name.equals(Integer.toString(type.key))))
/*     */         {
/*  73 */           this.typeNames.put(Integer.valueOf(type.key), LangConversion.convertId(7, tblId + type.key, type.name)); }
/*     */       }
/*     */     } catch (Exception e) {
/*     */       String tblId;
/*  77 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getRowCount()
/*     */   {
/*  85 */     int layoutIndex = getFixedCurrentLayout();
/*     */     int ret;
/*     */     int ret;
/*  88 */     if (layoutIndex >= this.layout.getRecordCount()) {
/*  89 */       ret = 1;
/*     */     } else {
/*  91 */       ret = this.fileView.getLayoutColumnCount(layoutIndex);
/*     */       
/*  93 */       ret = this.fieldMapping.getColumnCount(layoutIndex, ret);
/*     */     }
/*     */     
/*  96 */     if (showKey()) {
/*  97 */       ret++;
/*     */     }
/*     */     
/* 100 */     return ret;
/*     */   }
/*     */   
/*     */   protected boolean showKey() {
/* 104 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getValueAt(int row, int col)
/*     */   {
/* 112 */     int idx = getFixedCurrentLayout();
/* 113 */     if (idx >= this.layout.getRecordCount()) {
/* 114 */       if (col == 0) {
/* 115 */         return LangConversion.convert("Full Line");
/*     */       }
/* 117 */     } else if (row == this.layout.getRecord(idx).getFieldCount()) {
/* 118 */       if (col == 0) {
/* 119 */         return LangConversion.convert("Key Value");
/*     */       }
/* 121 */     } else if (col < this.firstDataColumn) {
/* 122 */       int column = getRealRow(row);
/* 123 */       AbstractRecordDetail record = this.fileView.getLayout().getRecord(idx);
/* 124 */       IFieldDetail df = record.getField(column);
/*     */       
/* 126 */       if (df == null) {
/* 127 */         return null;
/*     */       }
/* 129 */       switch (col) {
/* 130 */       case 0:  return df.getName();
/* 131 */       case 1:  return Integer.valueOf(df.getPos());
/*     */       case 2: 
/* 133 */         int len = df.getLen();
/*     */         
/* 135 */         if (len < 0) {
/* 136 */           return "";
/*     */         }
/*     */         
/* 139 */         return Integer.valueOf(df.getLen());
/*     */       }
/* 141 */       if ((this.fileView.getLayout() instanceof LayoutDetail)) {
/* 142 */         return this.typeNames.get(Integer.valueOf(df.getType()));
/*     */       }
/* 144 */       return record.getFieldTypeName(column);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 153 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCurrentLayout(int newCurrentLayout)
/*     */   {
/* 165 */     this.currentLayout = newCurrentLayout;
/*     */   }
/*     */   
/*     */   public final int getRealRowWithKey(int row)
/*     */   {
/* 170 */     if (isKeyRow(row)) {
/* 171 */       return 64771;
/*     */     }
/* 173 */     return getRealRow(row);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getRealRow(int row)
/*     */   {
/* 182 */     int idx = getFixedCurrentLayout();
/* 183 */     return this.fileView.getRealColumn(idx, getRowLocal(idx, row));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int getRowLocal(int inRow)
/*     */   {
/* 193 */     if (isKeyRow(inRow)) {
/* 194 */       return 64771;
/*     */     }
/* 196 */     return getRowLocal(getFixedCurrentLayout(), inRow);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int getRowLocal(int layoutIndex, int inRow)
/*     */   {
/* 205 */     int ret = inRow;
/*     */     
/* 207 */     if (inRow >= 0) {
/* 208 */       ret = this.fieldMapping.getRealColumn(layoutIndex, inRow);
/*     */     }
/*     */     
/* 211 */     return ret;
/*     */   }
/*     */   
/*     */   public final void hideRow(int row) {
/* 215 */     int idx = getFixedCurrentLayout();
/* 216 */     this.fieldMapping.hideColumn(idx, this.fieldMapping.getRealColumn(idx, row));
/* 217 */     fireTableDataChanged();
/*     */   }
/*     */   
/*     */   public final void showRow(int row)
/*     */   {
/* 222 */     this.fieldMapping.showColumn(getFixedCurrentLayout(), row);
/* 223 */     fireTableDataChanged();
/*     */   }
/*     */   
/*     */   protected final boolean isKeyRow(int row)
/*     */   {
/* 228 */     boolean ret = false;
/* 229 */     int idx = getFixedCurrentLayout();
/* 230 */     if ((idx >= 0) && (idx < this.layout.getRecordCount()) && (row == this.layout.getRecord(idx).getFieldCount()))
/*     */     {
/* 232 */       ret = true;
/*     */     }
/* 234 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFixedCurrentLayout()
/*     */   {
/* 243 */     if (this.currentLayout < 0) {
/* 244 */       return 0;
/*     */     }
/* 246 */     return this.currentLayout;
/*     */   }
/*     */   
/*     */ 
/*     */   public final void layoutChanged(AbstractLayoutDetails newLayout)
/*     */   {
/* 252 */     if (this.layout != newLayout) {
/* 253 */       this.layout = newLayout;
/*     */       
/* 255 */       this.fieldMapping.resetMapping(getFieldCounts());
/*     */       
/* 257 */       super.fireTableStructureChanged();
/*     */     } else {
/* 259 */       int[] tfc = getFieldCounts();
/* 260 */       for (int i = 0; i < tfc.length; i++) {
/* 261 */         if (tfc[i] != this.lastFieldCounts[i]) {
/* 262 */           this.lastFieldCounts = tfc;
/* 263 */           this.fieldMapping.resetMapping((int[])this.lastFieldCounts.clone());
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int[] getFieldCounts()
/*     */   {
/* 275 */     int[] rows = new int[this.layout.getRecordCount()];
/*     */     
/* 277 */     for (int i = 0; i < this.layout.getRecordCount(); i++) {
/* 278 */       rows[i] = this.fileView.getLayoutColumnCount(i);
/*     */     }
/*     */     
/* 281 */     return rows;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCurrentLayout()
/*     */   {
/* 291 */     return this.currentLayout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getColumnName(int col)
/*     */   {
/* 299 */     if (col >= this.firstDataColumn) {
/* 300 */       return this.columnName[(col - this.firstDataColumn + 4)];
/*     */     }
/* 302 */     return this.columnName[col];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final FileView getFileView()
/*     */   {
/* 310 */     return this.fileView;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final FieldMapping getFieldMapping()
/*     */   {
/* 317 */     return this.fieldMapping;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/models/BaseLineModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */