/*     */ package net.sf.RecordEditor.edit.display;
/*     */ 
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JSplitPane;
/*     */ import javax.swing.JTabbedPane;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import javax.swing.event.InternalFrameAdapter;
/*     */ import javax.swing.event.InternalFrameEvent;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.RecordEditor.edit.display.common.ILayoutChanged;
/*     */ import net.sf.RecordEditor.edit.display.util.DockingPopupListner;
/*     */ import net.sf.RecordEditor.edit.util.ReMessages;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*     */ import net.sf.RecordEditor.re.display.DisplayDetails;
/*     */ import net.sf.RecordEditor.re.display.IDisplayFrame;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMainFrame;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMsg;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.swing.TabWithClosePnl;
/*     */ 
/*     */ 
/*     */ public class DisplayFrame
/*     */   extends ReFrame
/*     */   implements IDisplayFrame<BaseDisplay>, ILayoutChanged
/*     */ {
/*  38 */   private ArrayList<BaseDisplay> mainScreens = new ArrayList();
/*  39 */   private ArrayList<JSplitPane> splitPanes = new ArrayList();
/*  40 */   private JTabbedPane pane = null;
/*     */   
/*     */ 
/*  43 */   private ChangeListener tabListner = new ChangeListener()
/*     */   {
/*     */ 
/*     */     public void stateChanged(ChangeEvent e)
/*     */     {
/*  48 */       ReMainFrame.getMasterFrame().focusChanged(DisplayFrame.this);
/*     */     }
/*     */   };
/*     */   
/*  52 */   InternalFrameAdapter closingAction = new InternalFrameAdapter()
/*     */   {
/*     */     public void internalFrameClosing(InternalFrameEvent e) {
/*  55 */       DisplayFrame.this.windowClosingCheck();
/*     */     }
/*     */   };
/*     */   
/*     */   public DisplayFrame(BaseDisplay d)
/*     */   {
/*  61 */     super(d.getFileView().getBaseFile().getFileNameNoDirectory(), d.formType, d.getFileView().getBaseFile());
/*     */     
/*  63 */     setPrimaryView(d.primary);
/*  64 */     add(d);
/*     */     
/*  66 */     d.setParentFrame(this, true);
/*     */     
/*  68 */     setDefaultCloseOperation(0);
/*     */     
/*  70 */     addInternalFrameListener(this.closingAction);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReFrame getReFrame()
/*     */   {
/*  81 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void addScreen(BaseDisplay d)
/*     */   {
/*  91 */     addScreen(d, true);
/*     */   }
/*     */   
/*     */   public final void addScreen(BaseDisplay d, boolean rebuild) {
/*  95 */     add(d);
/*     */     
/*  97 */     d.setParentFrame(this, false);
/*  98 */     d.getActualPnl().done();
/*     */     
/* 100 */     if (rebuild) {
/* 101 */       bldScreen();
/*     */     }
/* 103 */     if (this.pane != null) {
/* 104 */       this.pane.setSelectedIndex(this.pane.getTabCount() - 1);
/*     */     }
/*     */   }
/*     */   
/*     */   private void add(BaseDisplay d)
/*     */   {
/* 110 */     if (d.getDockingPopup() == null) {
/* 111 */       d.setDockingPopup(new DockingPopupListner(d));
/*     */     }
/* 113 */     this.mainScreens.add(d);
/*     */     
/* 115 */     this.splitPanes.add(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void windowClosingCheck()
/*     */   {
/* 123 */     boolean doClose = true;
/*     */     
/* 125 */     removeInternalFrameListener(this.closingAction);
/*     */     
/* 127 */     if (this.mainScreens.size() > 0) {
/* 128 */       BaseDisplay main = (BaseDisplay)this.mainScreens.get(0);
/* 129 */       FileView fileView = main.getFileView();
/* 130 */       if (super.isPrimaryView()) {
/* 131 */         ReFrame[] allFrames = ReFrame.getAllFrames();
/* 132 */         FileView fileMaster = fileView.getBaseFile();
/*     */         
/*     */ 
/* 135 */         for (int i = allFrames.length - 1; i >= 0; i--) {
/* 136 */           if ((allFrames[i].getDocument() == fileMaster) && (allFrames[i] != this))
/*     */           {
/* 138 */             allFrames[i].reClose();
/*     */           }
/*     */         }
/*     */         
/* 142 */         if ((fileMaster != null) && (fileMaster.isChanged()) && (fileMaster.isSaveAvailable()) && (!ReFrame.isForcedClose()))
/*     */         {
/* 144 */           int result = JOptionPane.showConfirmDialog(null, ReMessages.SAVE_CHANGES.get(), ReMessages.SAVE_CHANGES_FILE.get(fileMaster.getFileName()), 0);
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 152 */           if (result == 0) {
/* 153 */             doClose = main.saveFile();
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 158 */         if ((doClose) && 
/* 159 */           (fileView != null) && (fileMaster.isSaveAvailable())) {
/* 160 */           fileView.clear();
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 165 */       if (doClose) {
/* 166 */         ArrayList<FileView> views = new ArrayList();
/* 167 */         for (int i = this.mainScreens.size() - 1; i > 0; i--) {
/* 168 */           views.add(((BaseDisplay)this.mainScreens.get(i)).getFileView());
/* 169 */           ((BaseDisplay)this.mainScreens.get(i)).closeWindow();
/*     */         }
/*     */         
/* 172 */         main.doClose();
/*     */         
/* 174 */         this.mainScreens.clear();
/* 175 */         for (FileView f : views) {
/* 176 */           checkTheViewIsUsed(f);
/*     */         }
/* 178 */         super.dispose();
/*     */       }
/*     */     } else {
/* 181 */       super.dispose();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void close(AbstractFileDisplay d)
/*     */   {
/* 193 */     for (int i = 0; i < this.mainScreens.size(); i++) {
/* 194 */       if (this.mainScreens.get(i) == d) {
/* 195 */         close(i);
/* 196 */         break;
/*     */       }
/*     */     }
/*     */     
/* 200 */     if (this.mainScreens.size() == 0) {
/* 201 */       super.dispose();
/*     */     }
/*     */   }
/*     */   
/*     */   public final void close(int idx)
/*     */   {
/* 207 */     FileView fileView = ((BaseDisplay)this.mainScreens.get(idx)).getFileView();
/*     */     
/* 209 */     ((BaseDisplay)this.mainScreens.get(idx)).doClose();
/* 210 */     removeIdx(idx);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 216 */     checkTheViewIsUsed(fileView);
/*     */   }
/*     */   
/*     */   private void checkTheViewIsUsed(FileView fileView)
/*     */   {
/* 221 */     if (fileView == null) return;
/* 222 */     ReFrame[] frames = ReFrame.getAllFrames();
/* 223 */     boolean notUsed = true;
/*     */     
/* 225 */     for (int i = 0; (i < frames.length) && (notUsed); i++) {
/* 226 */       if (((frames[i] instanceof DisplayFrame)) && (frames[i].getDocument() != null) && (((DisplayFrame)frames[i]).getDocument() == fileView.getBaseFile()))
/*     */       {
/*     */ 
/* 229 */         ArrayList<BaseDisplay> ms = ((DisplayFrame)frames[i]).mainScreens;
/* 230 */         for (BaseDisplay baseDisplay : ms) {
/* 231 */           if (baseDisplay.getFileView() == fileView) {
/* 232 */             notUsed = false;
/* 233 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */       else {
/* 238 */         AbstractFileDisplay displayDetails = DisplayDetails.getDisplayDetails(frames[i]);
/* 239 */         notUsed = (displayDetails == null) || (displayDetails.getFileView() != fileView);
/*     */       }
/*     */     }
/*     */     
/* 243 */     if (notUsed) {
/* 244 */       fileView.clear();
/*     */     }
/*     */   }
/*     */   
/*     */   private void moveToSeperateScreen() {
/* 249 */     if (this.pane != null) {
/* 250 */       DisplayFrame disp = this;
/*     */       
/* 252 */       int displIdx = getActiveIdx();
/*     */       
/* 254 */       for (int i = this.mainScreens.size() - 1; i > 0; i--) {
/* 255 */         DisplayFrame p = moveToSeperateScreenI(i);
/* 256 */         if ((i == displIdx) && (p != null)) {
/* 257 */           disp = p;
/*     */         }
/*     */       }
/*     */       
/* 261 */       disp.moveToFront();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void moveToSeperateScreen(AbstractFileDisplay pnl)
/*     */   {
/* 271 */     int idx = this.mainScreens.indexOf(pnl);
/*     */     
/* 273 */     if (idx > 0) {
/* 274 */       moveToSeperateScreen(idx);
/*     */     }
/*     */   }
/*     */   
/*     */   private void moveToSeperateScreen(int idx)
/*     */   {
/* 280 */     DisplayFrame newScreen = moveToSeperateScreenI(idx);
/*     */     
/* 282 */     if (newScreen != null) {
/* 283 */       revalidate();
/*     */       try
/*     */       {
/* 286 */         ((BaseDisplay)newScreen.mainScreens.get(0)).setScreenSize(true);
/* 287 */         ReFrame.setActiveFrame(newScreen);
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*     */   }
/*     */   
/*     */   private DisplayFrame moveToSeperateScreenI(int idx)
/*     */   {
/* 295 */     if ((this.pane != null) && (idx > 0)) {
/* 296 */       BaseDisplay d = (BaseDisplay)this.mainScreens.get(idx);
/* 297 */       removeIdx(idx);
/*     */       
/* 299 */       DisplayFrame ret = new DisplayFrame(d);
/*     */       
/* 301 */       d.setScreenSize(true);
/*     */       
/* 303 */       return ret;
/*     */     }
/* 305 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */   private void removeIdx(int idx)
/*     */   {
/* 311 */     this.mainScreens.remove(idx);
/*     */     
/* 313 */     this.splitPanes.remove(idx);
/* 314 */     if (this.pane != null) {
/* 315 */       this.pane.remove(idx);
/* 316 */       if (this.pane.getTabCount() == 1) {
/* 317 */         bldScreen();
/*     */         
/* 319 */         ((BaseDisplay)this.mainScreens.get(0)).setParentFrame(this, true);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void reClose()
/*     */   {
/* 330 */     BaseDisplay main = null;
/* 331 */     if (this.mainScreens.size() > 0) {
/* 332 */       main = (BaseDisplay)this.mainScreens.get(0);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 340 */     for (AbstractFileDisplay d : this.mainScreens) {
/* 341 */       d.doClose();
/*     */     }
/*     */     
/* 344 */     if (main != null) {
/* 345 */       FileView fileView = main.getFileView();
/* 346 */       if ((super.isPrimaryView()) && 
/* 347 */         (fileView != null)) {
/* 348 */         main.closeWindow();
/*     */         
/* 350 */         if ((fileView == fileView.getBaseFile()) && (super.isPrimaryView())) {
/* 351 */           fileView.clear();
/*     */         }
/*     */       }
/*     */       
/*     */ 
/* 356 */       checkTheViewIsUsed(fileView);
/*     */     }
/* 358 */     super.reClose();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setToActiveTab(AbstractFileDisplay pnl)
/*     */   {
/* 367 */     int idx = this.mainScreens.indexOf(pnl);
/* 368 */     if ((idx >= 0) && (this.pane != null) && (this.pane.getSelectedIndex() != idx)) {
/* 369 */       this.pane.setSelectedIndex(idx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setToActiveFrame()
/*     */   {
/* 378 */     ReFrame.setActiveFrame(this);
/*     */   }
/*     */   
/*     */ 
/*     */   public void setToMaximum(boolean max)
/*     */   {
/* 384 */     boolean recalc = super.isMaximum() != max;
/*     */     
/* 386 */     super.setToMaximum(max);
/*     */     
/* 388 */     if (recalc) {
/* 389 */       recalcSplits();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void recalcSplits()
/*     */   {
/* 396 */     for (int i = 0; i < this.mainScreens.size(); i++) {
/* 397 */       if ((this.splitPanes.get(i) != null) && (((BaseDisplay)this.mainScreens.get(i)).getChildScreen() != null)) {
/* 398 */         ((JSplitPane)this.splitPanes.get(i)).setDividerLocation(calcSplit(i));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void bldScreen()
/*     */   {
/* 410 */     if (this.mainScreens.size() == 1) {
/* 411 */       getContentPane().removeAll();
/*     */       
/* 413 */       addMainComponent(getScreen(0));
/*     */       
/* 415 */       if (this.pane != null) {
/* 416 */         this.pane.removeChangeListener(this.tabListner);
/* 417 */         this.pane = null;
/*     */       }
/*     */     }
/* 420 */     else if ((this.pane == null) || (Common.TEST_MODE)) {
/* 421 */       getContentPane().removeAll();
/* 422 */       this.pane = new JTabbedPane();
/*     */       
/*     */ 
/*     */ 
/* 426 */       addTabs();
/*     */       
/* 428 */       this.pane.addChangeListener(this.tabListner);
/*     */       
/* 430 */       getContentPane().add(this.pane);
/*     */     } else {
/* 432 */       this.pane.removeAll();
/*     */       
/* 434 */       addTabs();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 440 */     revalidate();
/*     */   }
/*     */   
/*     */   private void addTabs() {
/* 444 */     for (int i = 0; i < this.mainScreens.size(); i++) {
/* 445 */       this.pane.addTab(((BaseDisplay)this.mainScreens.get(i)).formType, getScreen(i));
/*     */     }
/* 447 */     for (int i = 0; i < this.mainScreens.size(); i++) {
/* 448 */       this.pane.setTabComponentAt(i, new TabButton((BaseDisplay)this.mainScreens.get(i), i > 0));
/*     */     }
/*     */   }
/*     */   
/*     */   private JComponent getScreen(int idx) {
/* 453 */     if (((BaseDisplay)this.mainScreens.get(idx)).getChildScreen() == null) {
/* 454 */       return ((BaseDisplay)this.mainScreens.get(idx)).actualPnl;
/*     */     }
/*     */     
/* 457 */     int splitType = 1;
/* 458 */     if (((BaseDisplay)this.mainScreens.get(idx)).getCurrentChildScreenPostion() == 2) {
/* 459 */       splitType = 0;
/*     */     }
/*     */     
/* 462 */     JSplitPane sp = new JSplitPane(splitType, ((BaseDisplay)this.mainScreens.get(idx)).actualPnl, ((BaseDisplay)this.mainScreens.get(idx)).getChildScreen().getActualPnl());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 468 */     this.splitPanes.set(idx, sp);
/*     */     
/* 470 */     sp.setDividerLocation(calcSplit(idx));
/* 471 */     return sp;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int calcSplit(int idx)
/*     */   {
/* 495 */     if (((BaseDisplay)this.mainScreens.get(idx)).getCurrentChildScreenPostion() == 2) {
/* 496 */       return Math.max(getHeight() - ((BaseDisplay)this.mainScreens.get(idx)).getChildScreen().getActualPnl().getPreferredSize().height - SwingUtils.CHAR_FIELD_HEIGHT * 3, ((BaseDisplay)this.mainScreens.get(idx)).actualPnl.getPreferredSize().height);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 504 */     return Math.max(getWidth() - ((BaseDisplay)this.mainScreens.get(idx)).getChildScreen().getActualPnl().getPreferredSize().width - SwingUtils.CHAR_FIELD_WIDTH * 3, ((BaseDisplay)this.mainScreens.get(idx)).actualPnl.getPreferredSize().width - SwingUtils.CHAR_FIELD_WIDTH * 30);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BaseDisplay getActiveDisplay()
/*     */   {
/* 515 */     if (this.mainScreens.size() == 0) return null;
/* 516 */     return (BaseDisplay)this.mainScreens.get(getActiveIdx());
/*     */   }
/*     */   
/*     */   private int getActiveIdx() {
/* 520 */     if (this.pane == null) {
/* 521 */       return 0;
/*     */     }
/*     */     
/* 524 */     return Math.max(0, this.pane.getSelectedIndex());
/*     */   }
/*     */   
/*     */   public final void setActiveIdx(int newIdx) {
/* 528 */     if ((this.pane == null) || (newIdx < 0) || (newIdx >= this.pane.getTabCount())) {
/* 529 */       return;
/*     */     }
/*     */     
/* 532 */     this.pane.setSelectedIndex(newIdx);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getScreenCount()
/*     */   {
/* 541 */     return this.mainScreens.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int indexOf(AbstractFileDisplay pnl)
/*     */   {
/* 551 */     return this.mainScreens.indexOf(pnl);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void executeAction(int action, Object o)
/*     */   {
/* 559 */     BaseDisplay bd = getActiveDisplay();
/*     */     
/* 561 */     if ((bd != null) && (bd.isActionAvailable(action))) {
/* 562 */       bd.executeAction(action, o);
/*     */     } else {
/* 564 */       super.executeAction(action, o);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void executeAction(int action)
/*     */   {
/* 573 */     executeAction(getActiveIdx(), action);
/*     */   }
/*     */   
/*     */   public void executeAction(AbstractFileDisplay screen, int action)
/*     */   {
/* 578 */     int idx = this.mainScreens.indexOf(screen);
/* 579 */     if (idx >= 0) {
/* 580 */       executeAction(idx, action);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public void executeAction(int idx, int action)
/*     */   {
/* 587 */     if (idx >= 0)
/*     */     {
/* 589 */       switch (action) {
/* 590 */       case 61:  close(idx); break;
/* 591 */       case 62:  moveToSeperateScreen(idx); break;
/* 592 */       case 63:  moveToSeperateScreen(); break;
/* 593 */       case 64:  addToMainTab(idx, true); break;
/* 594 */       case 65:  dockAll(); break;
/*     */       case 67: 
/* 596 */         addChildScreen(idx, 1);
/* 597 */         break;
/*     */       case 68: 
/* 599 */         addChildScreen(idx, 1);
/* 600 */         break;
/*     */       case 69: 
/* 602 */         addChildScreen(idx, 2);
/* 603 */         break;
/*     */       case 70: 
/* 605 */         if ((idx >= 0) && (idx < this.mainScreens.size())) {
/* 606 */           int position = 1;
/* 607 */           if (((BaseDisplay)this.mainScreens.get(idx)).getCurrentChildScreenPostion() == 1) {
/* 608 */             position = 2;
/*     */           }
/* 610 */           addChildScreen(idx, position); }
/* 611 */         break;
/*     */       case 66: 
/* 613 */         removeChildScreen(idx); break;
/*     */       default: 
/* 615 */         AbstractFileDisplay bd = getActiveDisplay();
/*     */         
/* 617 */         if ((bd != null) && 
/* 618 */           (bd.isActionAvailable(action))) {
/* 619 */           bd.executeAction(action);
/*     */         }
/*     */         break;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void addChildScreen(int idx, int position)
/*     */   {
/* 628 */     if ((idx >= 0) && (idx < this.mainScreens.size())) {
/* 629 */       BaseDisplay bd = (BaseDisplay)this.mainScreens.get(idx);
/* 630 */       if (bd.getFileView().getRowCount() == 0) {
/* 631 */         Common.logMsgRaw(ReMessages.EMPTY_VIEW.get(), null);
/* 632 */       } else if ((bd instanceof AbstractCreateChildScreen)) {
/* 633 */         AbstractFileDisplay childDispl = ((AbstractCreateChildScreen)bd).createChildScreen(position);
/*     */         
/* 635 */         childDispl.setDockingPopup(bd.getDockingPopup());
/* 636 */         updateScreenStuff(idx);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void removeChildScreen(int idx)
/*     */   {
/* 643 */     if ((idx >= 0) && (idx < this.mainScreens.size())) {
/* 644 */       ((BaseDisplay)this.mainScreens.get(idx)).removeChildScreen();
/*     */       
/* 646 */       updateScreenStuff(idx);
/*     */     }
/*     */   }
/*     */   
/*     */   private void updateScreenStuff(int idx) {
/* 651 */     bldScreen();
/* 652 */     ReMainFrame.getMasterFrame().focusChanged(this);
/* 653 */     if (this.mainScreens.size() > 0) {
/* 654 */       ((BaseDisplay)this.mainScreens.get(0)).setScreenSize(true);
/*     */     }
/* 656 */     if (this.pane != null) {
/* 657 */       this.pane.setSelectedIndex(idx);
/*     */     }
/*     */   }
/*     */   
/*     */   private void dockAll() {
/* 662 */     ReFrame prim = ReFrame.getPrimaryFrame(getDocument());
/* 663 */     ReFrame[] frames = ReFrame.getAllFrames();
/*     */     
/* 665 */     if ((prim != null) && ((prim instanceof DisplayFrame))) {
/* 666 */       for (ReFrame f : frames) {
/* 667 */         if ((f != this) && (f.getDocument() == getDocument()) && ((f instanceof DisplayFrame))) {
/* 668 */           ((DisplayFrame)f).addToMainTab(prim);
/*     */         }
/*     */       }
/* 671 */       addToMainTab(prim);
/*     */       
/* 673 */       ((DisplayFrame)prim).bldScreen();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void addToMainTab(ReFrame prim)
/*     */   {
/* 680 */     if ((prim != null) && (prim != this) && ((prim instanceof DisplayFrame))) {
/* 681 */       for (int i = 0; i < this.mainScreens.size(); i++) {
/* 682 */         addToMainTab(i, false);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void addToMainTab(int idx, boolean rebuild) {
/* 688 */     ReFrame prim = ReFrame.getPrimaryFrame(getDocument());
/*     */     
/* 690 */     if ((prim != null) && (prim != this) && ((prim instanceof DisplayFrame))) {
/* 691 */       BaseDisplay d = (BaseDisplay)this.mainScreens.get(idx);
/*     */       
/* 693 */       removeIdx(idx);
/* 694 */       ((DisplayFrame)prim).addScreen(d, rebuild);
/*     */       
/* 696 */       if (this.mainScreens.size() == 0) {
/* 697 */         super.reClose();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isActionAvailable(int action)
/*     */   {
/* 707 */     return isActionAvailable(getActiveIdx(), action);
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isActionAvailable(int idx, int action)
/*     */   {
/* 713 */     switch (action) {
/*     */     case 61: 
/*     */     case 62: 
/* 716 */       return (this.mainScreens.size() > 1) && (idx > 0);
/*     */     case 63: 
/* 718 */       return this.mainScreens.size() > 1;
/*     */     case 67: 
/* 720 */       return (idx >= 0) && (this.mainScreens.size() > idx) && (((BaseDisplay)this.mainScreens.get(idx)).getChildScreen() == null) && ((this.mainScreens.get(idx) instanceof AbstractCreateChildScreen)) && (((BaseDisplay)this.mainScreens.get(idx)).getAvailableChildScreenPostion() != 3);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     case 68: 
/*     */     case 69: 
/* 727 */       return (idx >= 0) && (this.mainScreens.size() > idx) && (((BaseDisplay)this.mainScreens.get(idx)).getChildScreen() == null) && ((this.mainScreens.get(idx) instanceof AbstractCreateChildScreen)) && (((BaseDisplay)this.mainScreens.get(idx)).getAvailableChildScreenPostion() == 3);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     case 70: 
/* 733 */       return (idx >= 0) && (this.mainScreens.size() > idx) && (((BaseDisplay)this.mainScreens.get(idx)).getChildScreen() != null) && ((this.mainScreens.get(idx) instanceof AbstractCreateChildScreen)) && (((BaseDisplay)this.mainScreens.get(idx)).getAvailableChildScreenPostion() == 3);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     case 66: 
/* 739 */       return (idx >= 0) && (this.mainScreens.size() > idx) && (((BaseDisplay)this.mainScreens.get(idx)).getChildScreen() != null) && ((this.mainScreens.get(idx) instanceof AbstractCreateChildScreen));
/*     */     
/*     */ 
/*     */ 
/*     */     case 64: 
/* 744 */       return this != ReFrame.getPrimaryFrame(getDocument());
/*     */     
/*     */     case 65: 
/* 747 */       return true;
/*     */     }
/* 749 */     if ((idx >= 0) && (idx < this.mainScreens.size())) {
/* 750 */       return ((BaseDisplay)this.mainScreens.get(idx)).isActionAvailable(action);
/*     */     }
/*     */     
/* 753 */     return false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void layoutChanged(AbstractLayoutDetails layout)
/*     */   {
/* 762 */     for (BaseDisplay bd : this.mainScreens) {
/* 763 */       bd.layoutChanged(layout);
/*     */     }
/*     */   }
/*     */   
/*     */   private class TabButton
/*     */     extends TabWithClosePnl implements ActionListener, IDisplayChangeListner
/*     */   {
/*     */     private final BaseDisplay disp;
/*     */     
/*     */     public TabButton(BaseDisplay display, boolean addCloseBtn)
/*     */     {
/* 774 */       super(addCloseBtn);
/* 775 */       super.setCloseAction(this);
/*     */       
/* 777 */       this.disp = display;
/*     */       
/* 779 */       this.disp.setChangeListner(this);
/*     */       
/* 781 */       addMouseListener(this.disp.getDockingPopup());
/*     */       
/* 783 */       this.label.addMouseListener(this.disp.getDockingPopup());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void actionPerformed(ActionEvent ae)
/*     */     {
/* 790 */       int idx = DisplayFrame.this.pane.indexOfTabComponent(this);
/*     */       
/* 792 */       if (idx >= 0) {
/* 793 */         DisplayFrame.this.close(idx);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void displayChanged()
/*     */     {
/* 802 */       super.setTabname(this.disp.getScreenName());
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/DisplayFrame.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */