package net.sf.RecordEditor.edit.display;

public abstract interface IDisplayChangeListner
{
  public abstract void displayChanged();
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/IDisplayChangeListner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */