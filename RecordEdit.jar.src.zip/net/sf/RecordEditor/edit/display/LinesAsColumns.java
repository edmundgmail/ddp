/*     */ package net.sf.RecordEditor.edit.display;
/*     */ 
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.MouseEvent;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.Action;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.event.TableModelEvent;
/*     */ import javax.swing.event.TableModelListener;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.RecordEditor.edit.display.Action.AutofitAction;
/*     */ import net.sf.RecordEditor.edit.display.models.BaseLineModel;
/*     */ import net.sf.RecordEditor.edit.display.models.Line2ColModel;
/*     */ import net.sf.RecordEditor.re.file.FieldMapping;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.MenuPopupListener;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.ReAbstractAction;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMainFrame;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.FixedColumnScrollPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LinesAsColumns
/*     */   extends BaseLineAsColumn
/*     */   implements TableModelListener
/*     */ {
/*  38 */   private FixedColumnScrollPane tblScrollPane = null;
/*  39 */   private int popupCol = 1;
/*     */   
/*     */ 
/*     */   private int popupRow;
/*     */   
/*     */   private Line2ColModel tblMdl;
/*     */   
/*     */ 
/*     */   protected LinesAsColumns(FileView viewOfFile)
/*     */   {
/*  49 */     this("Column Table", viewOfFile);
/*     */   }
/*     */   
/*     */   protected LinesAsColumns(String screenName, FileView viewOfFile) {
/*  53 */     super(screenName, viewOfFile, viewOfFile == viewOfFile.getBaseFile(), true, true);
/*     */     
/*  55 */     init_100_SetupJtables(viewOfFile);
/*     */     
/*  57 */     this.actualPnl.setHelpURLre(Common.formatHelpURL("HlpRe15.htm"));
/*     */     
/*  59 */     this.actualPnl.addComponentRE(1, 5, -1.0D, BasePanel.GAP, 2, 2, this.tblScrollPane);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setScreenSize(boolean mainframe)
/*     */   {
/*  68 */     DisplayFrame parentFrame = getParentFrame();
/*     */     
/*  70 */     parentFrame.bldScreen();
/*     */     
/*  72 */     if (mainframe) {
/*  73 */       parentFrame.setBounds(1, 1, this.screenSize.width - 1, parentFrame.getHeight());
/*     */     }
/*     */     
/*     */ 
/*  77 */     setLayoutIdx();
/*     */     
/*  79 */     parentFrame.setVisible(true);
/*  80 */     this.actualPnl.addReKeyListener(new BaseDisplay.DelKeyWatcher(this));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_100_SetupJtables(FileView viewOfFile)
/*     */   {
/*  92 */     this.tblMdl = new Line2ColModel(viewOfFile);
/*     */     
/*     */ 
/*  95 */     setModel(this.tblMdl);
/*     */     
/*     */ 
/*     */ 
/*  99 */     AbstractAction editRecord = new ReAbstractAction("Edit Record") {
/*     */       public void actionPerformed(ActionEvent e) {
/* 101 */         if (LinesAsColumns.this.popupCol >= 0) {
/* 102 */           LinesAsColumns.this.newLineDisp(LinesAsColumns.this.fileView, LinesAsColumns.this.popupCol);
/*     */         }
/*     */         
/*     */       }
/* 106 */     };
/* 107 */     AbstractAction[] mainActions = { editRecord, null, new AutofitAction(this), null, new ReAbstractAction("Hide Column")
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       public void actionPerformed(ActionEvent e)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 123 */         LinesAsColumns.this.hideRow(LinesAsColumns.this.popupRow);
/*     */ 
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 129 */     } };
/* 130 */     JTable tableDetails = new BaseLineAsColumn.LineAsColTbl(this, this.tblMdl, 0, false);
/* 131 */     setJTable(tableDetails);
/*     */     
/* 133 */     this.popupListner = new MenuPopupListener(mainActions, true, tableDetails)
/*     */     {
/*     */       public void mousePressed(MouseEvent e)
/*     */       {
/* 137 */         super.mousePressed(e);
/* 138 */         JTable tbl = LinesAsColumns.this.getJTable();
/*     */         
/* 140 */         int col = tbl.columnAtPoint(e.getPoint());
/* 141 */         LinesAsColumns.this.popupRow = tbl.rowAtPoint(e.getPoint());
/*     */         
/* 143 */         if ((LinesAsColumns.this.popupRow >= 0) && (LinesAsColumns.this.popupRow != tbl.getEditingRow()) && (col >= 0) && (col != tbl.getEditingRow()) && (LinesAsColumns.this.cellEditors != null) && (LinesAsColumns.this.cellEditors[col] != null))
/*     */         {
/*     */ 
/*     */ 
/* 147 */           LinesAsColumns.this.getJTable().editCellAt(LinesAsColumns.this.popupRow, col);
/*     */         }
/*     */       }
/*     */       
/*     */       protected boolean isOkToShowPopup(MouseEvent e)
/*     */       {
/*     */         try
/*     */         {
/* 155 */           LinesAsColumns.this.popupCol = LinesAsColumns.this.getJTable().getColumnModel().getColumnIndexAtX(e.getPoint().x);
/*     */         }
/*     */         catch (Exception ex)
/*     */         {
/* 159 */           ex.printStackTrace();
/*     */         }
/* 161 */         return true;
/*     */       }
/*     */       
/* 164 */     };
/* 165 */     viewOfFile.setFrame(ReMainFrame.getMasterFrame());
/*     */     
/*     */ 
/*     */ 
/* 169 */     tableDetails.addMouseListener(this.popupListner);
/* 170 */     tableDetails.setColumnSelectionAllowed(true);
/* 171 */     tableDetails.setRowSelectionAllowed(true);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 176 */     setStandardColumnWidths(this.tblMdl.firstDataColumn);
/* 177 */     this.tblScrollPane = new FixedColumnScrollPane(tableDetails, this.tblMdl.firstDataColumn);
/* 178 */     JTable fixedTbl = this.tblScrollPane.getFixedTable();
/*     */     
/*     */ 
/* 181 */     this.actualPnl.registerComponentRE(tableDetails);
/* 182 */     this.actualPnl.registerComponentRE(fixedTbl);
/* 183 */     super.setAlternativeTbl(fixedTbl);
/* 184 */     setColWidths();
/*     */     
/*     */ 
/* 187 */     fixedTbl.addMouseListener(new MenuPopupListener(null, true, null) {
/*     */       public void mousePressed(MouseEvent m) {
/* 189 */         JTable tbl = LinesAsColumns.this.tblScrollPane.getFixedTable();
/* 190 */         LinesAsColumns.this.popupCol = tbl.columnAtPoint(m.getPoint());
/*     */         
/* 192 */         super.mousePressed(m);
/*     */       }
/*     */       
/*     */       protected boolean isOkToShowPopup(MouseEvent e) {
/* 196 */         JTable tbl = LinesAsColumns.this.tblScrollPane.getFixedTable();
/* 197 */         int fixedPopupCol = tbl.columnAtPoint(e.getPoint());
/* 198 */         LinesAsColumns.this.popupCol = fixedPopupCol;
/*     */         
/*     */ 
/* 201 */         return fixedPopupCol > 0;
/*     */       }
/*     */     });
/*     */     
/* 205 */     if (viewOfFile.getLayout().isOkToAddAttributes()) {
/* 206 */       viewOfFile.getBaseFile().addTableModelListener(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNewLayout(AbstractLayoutDetails newLayout)
/*     */   {
/* 217 */     super.setNewLayout(newLayout);
/* 218 */     setLayoutIdx();
/*     */     
/* 220 */     getModel().fireTableStructureChanged();
/* 221 */     this.tblScrollPane.setFixedColumns(this.tblMdl.firstDataColumn);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void setColWidths()
/*     */   {
/* 233 */     JTable tbl = getJTable();
/*     */     
/* 235 */     for (int i = Math.min(this.tblMdl.firstDataColumn, tbl.getColumnCount()) - 1; i >= 0; i--) {
/* 236 */       TableColumn tc = tbl.getColumnModel().getColumn(i);
/* 237 */       if (tc.getModelIndex() < this.tblMdl.firstDataColumn) {
/* 238 */         tbl.getColumnModel().removeColumn(tc);
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 255 */     if (this.tblScrollPane != null) {
/* 256 */       Common.calcColumnWidths(tbl, 1);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCurrRow()
/*     */   {
/* 267 */     int pos = 0;
/* 268 */     JTable tableDetails = getJTable();
/*     */     
/* 270 */     if (tableDetails.getSelectedColumnCount() > 0) {
/* 271 */       pos = tableDetails.getSelectedColumn();
/*     */     }
/*     */     
/* 274 */     return pos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int getPopupPosition()
/*     */   {
/* 282 */     return this.popupRow;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final int getStandardPosition()
/*     */   {
/* 291 */     JTable tbl = getJTable();
/* 292 */     int pos = this.fileView.getRowCount() - 1;
/* 293 */     if (tbl.getSelectedColumnCount() > 0) {
/* 294 */       pos = tbl.getSelectedColumn();
/*     */     }
/*     */     
/* 297 */     return pos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSelectedRowCount()
/*     */   {
/* 305 */     return this.tblDetails.getSelectedColumnCount();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int[] getSelectedRows()
/*     */   {
/* 312 */     return getJTable().getSelectedColumns();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCurrRow(int newRow, int layoutId, int fieldNum)
/*     */   {
/* 321 */     if ((newRow >= 0) && (newRow <= this.fileView.getRowCount())) {
/* 322 */       int fNo = FieldMapping.getAdjColumn(getModel().getFieldMapping(), layoutId, fieldNum);
/* 323 */       JTable tbl = getJTable();
/*     */       
/* 325 */       getModel().fireTableDataChanged();
/* 326 */       tbl.changeSelection(fNo, newRow, false, false);
/*     */       
/* 328 */       if ((fieldNum > 0) && (getLayoutIndex() == layoutId)) {
/* 329 */         stopCellEditing();
/* 330 */         tbl.editCellAt(fNo, newRow);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void tableChanged(TableModelEvent event)
/*     */   {
/* 343 */     if (super.hasTheFormatChanged(event)) {
/* 344 */       getModel().fireTableDataChanged();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isActionAvailable(int action)
/*     */   {
/* 351 */     return (action == 50) || (super.isActionAvailable(action));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected BaseDisplay getNewDisplay(FileView view)
/*     */   {
/* 360 */     return new LinesAsColumns(view);
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/LinesAsColumns.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */