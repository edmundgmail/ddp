/*    */ package net.sf.RecordEditor.edit.display;
/*    */ 
/*    */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*    */ import net.sf.JRecord.Details.LineCompare;
/*    */ import net.sf.RecordEditor.edit.display.util.BaseFieldSelection;
/*    */ import net.sf.RecordEditor.edit.display.util.SortFieldSummaryMdl;
/*    */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*    */ import net.sf.RecordEditor.re.display.DisplayBuilderFactory;
/*    */ import net.sf.RecordEditor.re.file.FileView;
/*    */ import net.sf.RecordEditor.re.tree.TreeParserField;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CreateSortedTree
/*    */   extends BaseFieldSelection
/*    */ {
/*    */   public CreateSortedTree(AbstractFileDisplay src, FileView view)
/*    */   {
/* 29 */     super(src, view, "Create Sorted Tree", 36, "Build Tree", 2, true, true, "SortTree");
/*    */     
/* 31 */     super.setHelpURL(Common.formatHelpURL("HlpRe12.htm"));
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected AbstractFileDisplay doAction(FileView view, int recordIndex, AbstractFileDisplay src, int[] fieldList, boolean[] descending, AbstractLayoutDetails layout)
/*    */   {
/* 43 */     FileView newView = getNewView();
/*    */     
/* 45 */     if (newView != null) {
/* 46 */       TreeParserField parser = new TreeParserField(recordIndex, fieldList, this.summaryMdl.getFieldSummary());
/*    */       
/* 48 */       newView.sort(new LineCompare(layout, recordIndex, fieldList, descending));
/*    */       
/*    */ 
/* 51 */       return DisplayBuilderFactory.newLineTree(getSourceDisplay().getParentFrame(), newView, parser, false, 0);
/*    */     }
/*    */     
/* 54 */     return null;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/CreateSortedTree.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */