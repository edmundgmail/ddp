/*     */ package net.sf.RecordEditor.edit.display;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JPopupMenu;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.table.TableCellEditor;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import javax.swing.table.TableModel;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail.FieldDetails;
/*     */ import net.sf.RecordEditor.edit.display.models.BaseLineModel;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplayWithFieldHide;
/*     */ import net.sf.RecordEditor.re.file.FieldMapping;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.MenuPopupListener;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ 
/*     */ 
/*     */ public abstract class BaseLineAsColumn
/*     */   extends BaseLineDisplay
/*     */   implements AbstractFileDisplayWithFieldHide
/*     */ {
/*     */   protected MenuPopupListener popupListner;
/*     */   private BaseLineModel model;
/*     */   private JMenu[] showFieldMenus;
/*  33 */   private JMenu currentShowFields = null;
/*     */   
/*     */ 
/*     */ 
/*     */   public BaseLineAsColumn(String formType, FileView viewOfFile, boolean primary, boolean fullLine, boolean changeRow)
/*     */   {
/*  39 */     super(formType, viewOfFile, primary, fullLine, false, false, changeRow);
/*     */     
/*  41 */     this.showFieldMenus = new JMenu[viewOfFile.getLayout().getRecordCount()];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void fireLayoutIndexChanged()
/*     */   {
/*  54 */     if (this.model.getCurrentLayout() != getLayoutIndex()) {
/*  55 */       this.model.setCurrentLayout(getLayoutIndex());
/*  56 */       this.model.fireTableStructureChanged();
/*  57 */       setColWidths();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNewLayout(AbstractLayoutDetails newLayout)
/*     */   {
/*  66 */     super.setNewLayout(newLayout);
/*  67 */     this.showFieldMenus = new JMenu[newLayout.getRecordCount()];
/*  68 */     this.model.layoutChanged(newLayout);
/*  69 */     setTableFormatDetails(getLayoutIndex());
/*  70 */     setColWidths();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected BaseLineModel getModel()
/*     */   {
/*  79 */     return this.model;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setModel(BaseLineModel newModel)
/*     */   {
/*  87 */     this.model = newModel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void setStandardColumnWidths(int dataCol)
/*     */   {
/*  95 */     JTable tbl = getJTable();
/*  96 */     tbl.setAutoResizeMode(0);
/*     */     
/*  98 */     TableColumn tc = tbl.getColumnModel().getColumn(0);
/*  99 */     tc.setPreferredWidth(125);
/* 100 */     tc = tbl.getColumnModel().getColumn(1);
/* 101 */     tc.setPreferredWidth(40);
/* 102 */     if (dataCol > 2) {
/* 103 */       tc = tbl.getColumnModel().getColumn(2);
/* 104 */       tc.setPreferredWidth(40);
/* 105 */       if (dataCol > 3) {
/* 106 */         tc = tbl.getColumnModel().getColumn(3);
/* 107 */         tc.setPreferredWidth(Common.getColumnWidth(tbl, 3, 0, tbl.getRowCount(), 40) + 15);
/*     */       }
/*     */     }
/* 110 */     tc = tbl.getColumnModel().getColumn(dataCol);
/* 111 */     tc.setPreferredWidth(180);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean[] getFieldVisibility(int recordIndex)
/*     */   {
/* 122 */     return this.model.getFieldMapping().getFieldVisibility(recordIndex);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFieldVisibility(int recordIndex, boolean[] fieldVisible)
/*     */   {
/* 133 */     boolean allFieldsDisplayed = true;
/* 134 */     this.model.getFieldMapping().setFieldVisibilty(recordIndex, fieldVisible);
/* 135 */     this.model.fireTableDataChanged();
/*     */     
/* 137 */     for (int i = 0; (allFieldsDisplayed) && (i < fieldVisible.length); i++) {
/* 138 */       allFieldsDisplayed = fieldVisible[i];
/*     */     }
/*     */     
/* 141 */     if (allFieldsDisplayed) {
/* 142 */       if (this.showFieldMenus[recordIndex] != null) {
/* 143 */         this.showFieldMenus[recordIndex].removeAll();
/*     */       }
/* 145 */       this.showFieldMenus[recordIndex] = null;
/*     */     } else {
/* 147 */       setupShowFields(recordIndex);
/* 148 */       this.showFieldMenus[recordIndex].removeAll();
/* 149 */       for (i = 0; i < fieldVisible.length; i++) {
/* 150 */         if (fieldVisible[i] == 0) {
/* 151 */           addHiddenFieldToMenu(recordIndex, i, this.layout.getAdjFieldNumber(recordIndex, i));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 156 */     if (recordIndex == getLayoutIndex()) {
/* 157 */       setShowFieldsMenu(recordIndex);
/*     */     }
/*     */     
/* 160 */     getParentFrame().setToActiveFrame();
/*     */   }
/*     */   
/*     */   public void setLayoutIndex(int recordIndex)
/*     */   {
/* 165 */     int idx = getLayoutIndex();
/* 166 */     if (idx != recordIndex) {
/* 167 */       setShowFieldsMenu(recordIndex);
/*     */     }
/* 169 */     super.setLayoutIndex(recordIndex);
/*     */   }
/*     */   
/*     */ 
/*     */   private void setShowFieldsMenu(int recordIndex)
/*     */   {
/* 175 */     if (this.currentShowFields != null) {
/* 176 */       this.popupListner.getPopup().remove(this.currentShowFields);
/*     */     }
/* 178 */     if (recordIndex < this.showFieldMenus.length) {
/* 179 */       this.currentShowFields = this.showFieldMenus[recordIndex];
/* 180 */       if (this.currentShowFields != null) {
/* 181 */         this.popupListner.getPopup().add(this.currentShowFields);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected final void hideRow(int row)
/*     */   {
/* 188 */     int index = this.model.getFixedCurrentLayout();
/*     */     
/* 190 */     if (this.showFieldMenus[index] == null) {
/* 191 */       setupShowFields(index);
/* 192 */       this.currentShowFields = this.showFieldMenus[index];
/* 193 */       this.popupListner.getPopup().add(this.currentShowFields);
/*     */     }
/*     */     
/* 196 */     addHiddenFieldToMenu(index, this.model.getFieldMapping().getRealColumn(index, row), this.model.getRealRow(row));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 201 */     this.model.hideRow(row);
/*     */   }
/*     */   
/*     */   private void setupShowFields(int index) {
/* 205 */     if (this.showFieldMenus[index] == null) {
/* 206 */       this.showFieldMenus[index] = new JMenu(LangConversion.convert("Show {0} Fields", this.layout.getRecord(index).getRecordName()));
/*     */     }
/*     */   }
/*     */   
/*     */   private void addHiddenFieldToMenu(int index, int row, int realRow)
/*     */   {
/* 212 */     String s = this.layout.getRecord(index).getField(realRow).getName();
/*     */     
/*     */     int idx;
/* 215 */     if ((idx = s.indexOf('|')) >= 0) {
/* 216 */       s = s.substring(idx + 1);
/*     */     }
/* 218 */     this.showFieldMenus[index].add(new ShowFieldAction(s, index, row));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void setColWidths();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private class ShowFieldAction
/*     */     extends JMenuItem
/*     */     implements ActionListener
/*     */   {
/*     */     final int theRow;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     final int idx;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public ShowFieldAction(String s, int index, int row)
/*     */     {
/* 280 */       super();
/* 281 */       this.theRow = row;
/* 282 */       this.idx = index;
/* 283 */       super.addActionListener(this);
/*     */     }
/*     */     
/*     */ 
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/* 289 */       BaseLineAsColumn.this.model.showRow(this.theRow);
/*     */       
/* 291 */       BaseLineAsColumn.this.showFieldMenus[this.idx].remove(this);
/*     */       
/* 293 */       if (BaseLineAsColumn.this.showFieldMenus[this.idx].getMenuComponentCount() == 0) {
/* 294 */         BaseLineAsColumn.this.showFieldMenus[this.idx] = null;
/* 295 */         BaseLineAsColumn.this.setShowFieldsMenu(BaseLineAsColumn.this.getLayoutIndex());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   protected class LineAsColTbl
/*     */     extends JTable
/*     */   {
/*     */     private final int firstDataCol;
/*     */     
/*     */     private final boolean singleDataCol;
/*     */     
/*     */     public LineAsColTbl(TableModel dm, int firstDataColumn, boolean singleDataColumn)
/*     */     {
/* 310 */       super();
/* 311 */       this.firstDataCol = firstDataColumn;
/* 312 */       this.singleDataCol = singleDataColumn;
/*     */     }
/*     */     
/*     */ 
/*     */     public TableCellRenderer getCellRenderer(int row, int column)
/*     */     {
/* 318 */       int calcRow = BaseLineAsColumn.this.model.getFieldMapping().getRealColumn(BaseLineAsColumn.this.getLayoutIndex(), row);
/*     */       
/*     */ 
/* 321 */       if (noCellEditor(column, calcRow, BaseLineAsColumn.this.cellRenders)) {
/* 322 */         return super.getCellRenderer(row, column);
/*     */       }
/* 324 */       return BaseLineAsColumn.this.cellRenders[calcRow];
/*     */     }
/*     */     
/*     */     public TableCellEditor getCellEditor(int row, int column)
/*     */     {
/* 329 */       int calcRow = BaseLineAsColumn.this.model.getFieldMapping().getRealColumn(BaseLineAsColumn.this.getLayoutIndex(), row);
/*     */       
/*     */ 
/* 332 */       if (noCellEditor(column, calcRow, BaseLineAsColumn.this.cellEditors)) {
/* 333 */         return super.getCellEditor(row, column);
/*     */       }
/* 335 */       return BaseLineAsColumn.this.cellEditors[calcRow];
/*     */     }
/*     */     
/*     */     private boolean noCellEditor(int column, int calcRow, Object[] cellEditors) {
/* 339 */       return (column < this.firstDataCol) || ((this.singleDataCol) && (column > this.firstDataCol)) || (cellEditors == null) || (calcRow >= cellEditors.length) || (cellEditors[calcRow] == null);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/BaseLineAsColumn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */