/*    */ package net.sf.RecordEditor.edit.display;
/*    */ 
/*    */ import net.sf.RecordEditor.re.file.FileView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class BaseLineDisplay
/*    */   extends BaseDisplay
/*    */ {
/*    */   public BaseLineDisplay(String formType, FileView viewOfFile, boolean primary, boolean fullLine, boolean prefered, boolean hex, boolean changeRow)
/*    */   {
/* 59 */     super(formType, viewOfFile, primary, fullLine, true, prefered, hex, changeRow ? 2 : 1);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected int getInsertAfterPosition()
/*    */   {
/* 69 */     return getStandardPosition();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void executeAction(int action)
/*    */   {
/* 79 */     if (action == 47) {
/* 80 */       pasteOverTbl();
/*    */     } else {
/* 82 */       super.executeAction(action);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean isActionAvailable(int action)
/*    */   {
/* 93 */     return (action == 47) || (super.isActionAvailable(action));
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/BaseLineDisplay.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */