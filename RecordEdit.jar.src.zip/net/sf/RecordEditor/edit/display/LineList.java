/*      */ package net.sf.RecordEditor.edit.display;
/*      */ 
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.Toolkit;
/*      */ import java.awt.datatransfer.Clipboard;
/*      */ import java.awt.datatransfer.DataFlavor;
/*      */ import java.awt.datatransfer.Transferable;
/*      */ import java.awt.datatransfer.UnsupportedFlavorException;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import java.util.HashMap;
/*      */ import java.util.StringTokenizer;
/*      */ import javax.swing.AbstractAction;
/*      */ import javax.swing.Action;
/*      */ import javax.swing.DefaultCellEditor;
/*      */ import javax.swing.JMenu;
/*      */ import javax.swing.JMenuItem;
/*      */ import javax.swing.JPopupMenu;
/*      */ import javax.swing.JTable;
/*      */ import javax.swing.event.TableModelEvent;
/*      */ import javax.swing.event.TableModelListener;
/*      */ import javax.swing.table.JTableHeader;
/*      */ import javax.swing.table.TableCellEditor;
/*      */ import javax.swing.table.TableCellRenderer;
/*      */ import javax.swing.table.TableColumn;
/*      */ import javax.swing.table.TableColumnModel;
/*      */ import javax.swing.table.TableModel;
/*      */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*      */ import net.sf.JRecord.Details.AbstractLine;
/*      */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*      */ import net.sf.JRecord.Details.AbstractRecordDetail.FieldDetails;
/*      */ import net.sf.JRecord.Details.LayoutDetail;
/*      */ import net.sf.RecordEditor.edit.display.Action.AutofitAction;
/*      */ import net.sf.RecordEditor.edit.display.Action.CsvUpdateLayoutAction;
/*      */ import net.sf.RecordEditor.edit.display.Action.GotoLineAction;
/*      */ import net.sf.RecordEditor.edit.display.common.AbstractFieldSequencePnl;
/*      */ import net.sf.RecordEditor.edit.display.util.Code;
/*      */ import net.sf.RecordEditor.edit.display.util.RowChangeListner;
/*      */ import net.sf.RecordEditor.edit.util.ReMessages;
/*      */ import net.sf.RecordEditor.jibx.compare.FieldSequence;
/*      */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*      */ import net.sf.RecordEditor.re.display.AbstractFileDisplayWithFieldHide;
/*      */ import net.sf.RecordEditor.re.file.FieldMapping;
/*      */ import net.sf.RecordEditor.re.file.FileView;
/*      */ import net.sf.RecordEditor.re.jrecord.types.RecordFormats;
/*      */ import net.sf.RecordEditor.utils.MenuPopupListener;
/*      */ import net.sf.RecordEditor.utils.basicStuff.BasicTable;
/*      */ import net.sf.RecordEditor.utils.common.Common;
/*      */ import net.sf.RecordEditor.utils.lang.ReAbstractAction;
/*      */ import net.sf.RecordEditor.utils.screenManager.ReAction;
/*      */ import net.sf.RecordEditor.utils.screenManager.ReMainFrame;
/*      */ import net.sf.RecordEditor.utils.screenManager.ReMsg;
/*      */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*      */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*      */ import net.sf.RecordEditor.utils.swing.ButtonTableRendor;
/*      */ import net.sf.RecordEditor.utils.swing.FixedColumnScrollPane;
/*      */ import net.sf.RecordEditor.utils.swing.HexGenericRender;
/*      */ import net.sf.RecordEditor.utils.swing.HexOneLineRender;
/*      */ import net.sf.RecordEditor.utils.swing.HexTableCellEditor;
/*      */ import net.sf.RecordEditor.utils.swing.HexThreeLineField;
/*      */ import net.sf.RecordEditor.utils.swing.HexThreeLineRender;
/*      */ import net.sf.RecordEditor.utils.swing.HexTwoLineField;
/*      */ import net.sf.RecordEditor.utils.swing.HexTwoLineFieldAlt;
/*      */ import net.sf.RecordEditor.utils.swing.HexTwoLineRender;
/*      */ import net.sf.RecordEditor.utils.swing.LayoutCombo;
/*      */ import net.sf.RecordEditor.utils.swing.MonoSpacedRender;
/*      */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class LineList
/*      */   extends BaseLineDisplay
/*      */   implements AbstractFileDisplayWithFieldHide, TableModelListener, AbstractCreateChildScreen, AbstractFieldSequencePnl
/*      */ {
/*      */   private static final int NUMBER_OF_CONTROL_COLUMNS = 2;
/*  111 */   private BaseDisplay.HeaderRender headerRender = new BaseDisplay.HeaderRender(this);
/*      */   
/*  113 */   private ButtonTableRendor tableBtn = new ButtonTableRendor();
/*  114 */   private FixedColumnScrollPane tblScrollPane = null;
/*      */   
/*  116 */   private JMenu copyMenu = SwingUtils.newMenu("Copy Column");
/*  117 */   private JMenu moveMenu = SwingUtils.newMenu("Move Column");
/*      */   
/*  119 */   private int fixedPopupCol = 1;
/*  120 */   private int mainPopupCol = 1;
/*  121 */   private int popupRow = 1;
/*      */   
/*      */   private int lastRow;
/*  124 */   boolean isPrefered = false;
/*      */   
/*  126 */   private MonoSpacedRender charRendor = null;
/*      */   
/*      */   private DefaultCellEditor charEditor;
/*      */   
/*  130 */   private HexOneLineRender hex1Rendor = null;
/*  131 */   private HexGenericRender hex2RendorA = null;
/*  132 */   private HexTwoLineRender hex2Rendor = null;
/*  133 */   private HexThreeLineRender hex3Rendor = null;
/*      */   
/*      */   private TableCellEditor hex1Editor;
/*      */   private TableCellEditor hex2Editor;
/*      */   private TableCellEditor hex2EditorA;
/*      */   private TableCellEditor hex3Editor;
/*      */   private RowChangeListner keyListner;
/*  140 */   private FieldMapping fieldMapping = null;
/*      */   
/*      */   private LineFrame childFrame;
/*      */   
/*      */ 
/*      */   protected static LineList newLineList(AbstractLayoutDetails group, FileView viewOfFile, FileView masterFile)
/*      */   {
/*  147 */     return new LineList("Table:", group, viewOfFile, masterFile);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected static LineList newLineList(String screenName, AbstractLayoutDetails group, FileView viewOfFile, FileView masterFile)
/*      */   {
/*  157 */     if ((screenName == null) || ("".equals(screenName))) {
/*  158 */       return newLineList(group, viewOfFile, masterFile);
/*      */     }
/*  160 */     return new LineList(screenName, group, viewOfFile, masterFile);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private LineList(String screenName, AbstractLayoutDetails group, FileView viewOfFile, FileView masterFile)
/*      */   {
/*  174 */     super(screenName, viewOfFile, viewOfFile == masterFile, !viewOfFile.getLayout().isXml(), true, group.isBinary(), true);
/*      */     
/*      */ 
/*  177 */     this.fieldMapping = new FieldMapping(getFieldCounts());
/*      */     
/*  179 */     init_100_SetupJtables(viewOfFile);
/*      */     
/*  181 */     init_200_LayoutScreen();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private void init_100_SetupJtables(FileView viewOfFile)
/*      */   {
/*  192 */     ReAction sort = new ReAction(30, this);
/*  193 */     AbstractAction editRecord = new ReAbstractAction("Edit Record", 26)
/*      */     {
/*      */ 
/*      */       public void actionPerformed(ActionEvent e)
/*      */       {
/*  198 */         LineList.this.newLineFrame(LineList.this.fileView, LineList.this.popupRow);
/*      */       }
/*  200 */     };
/*  201 */     AbstractAction gotoLine = new GotoLineAction(this, this.fileView);
/*      */     
/*      */ 
/*      */ 
/*  205 */     AbstractAction[] mainActions = { sort, null, editRecord, gotoLine, null, new AutofitAction(this), null, new ReAbstractAction("Fix Column")
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  217 */       new ReAbstractAction
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         public void actionPerformed(ActionEvent e) {
/*  217 */           LineList.this.tblScrollPane.doFixColumn(LineList.this.mainPopupCol); } }, new ReAbstractAction("Hide Column")
/*      */       {
/*      */ 
/*      */         public void actionPerformed(ActionEvent e)
/*      */         {
/*  222 */           LineList.this.hideColumn(LineList.this.mainPopupCol);
/*      */         }
/*      */         
/*      */ 
/*  226 */       } };
/*  227 */     AbstractAction[] fixedActions = { sort, null, editRecord, gotoLine, null, new ReAbstractAction("Unfix Column")
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       public void actionPerformed(ActionEvent e)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*  237 */         if (LineList.this.fixedPopupCol > 0)
/*      */         {
/*  239 */           LineList.this.tblScrollPane.doUnFixColumn(LineList.this.fixedPopupCol);
/*      */         }
/*      */         
/*      */       }
/*      */       
/*  244 */     } };
/*  245 */     JTable tableDetails = new LinesTbl(viewOfFile, 0);
/*  246 */     JMenu csvMenu = null;
/*      */     
/*  248 */     super.setJTable(tableDetails);
/*  249 */     this.tblScrollPane = new FixedColumnScrollPane(tableDetails);
/*      */     
/*  251 */     this.keyListner = new RowChangeListner(tableDetails, this);
/*      */     
/*  253 */     if (this.fileMaster.isSimpleCsvFile()) {
/*  254 */       csvMenu = init_110_GetCsvMenu();
/*      */     }
/*      */     
/*  257 */     MenuPopupListener mainPopup = new MenuPopupListener(mainActions, true, tableDetails, csvMenu, true)
/*      */     {
/*      */ 
/*      */       public void mousePressed(MouseEvent e)
/*      */       {
/*      */ 
/*  263 */         super.mousePressed(e);
/*  264 */         JTable table = LineList.this.getJTable();
/*      */         
/*  266 */         int col = table.columnAtPoint(e.getPoint());
/*  267 */         int row = table.rowAtPoint(e.getPoint());
/*      */         
/*  269 */         LineList.this.checkForTblRowChange(row);
/*  270 */         if ((row >= 0) && (row != table.getEditingRow()) && (col >= 0) && (col != table.getEditingColumn()) && (LineList.this.cellEditors != null) && (col < LineList.this.cellEditors.length) && (LineList.this.cellEditors[col] != null))
/*      */         {
/*      */ 
/*      */ 
/*  274 */           table.editCellAt(row, col);
/*      */         }
/*      */       }
/*      */       
/*      */       protected final boolean isOkToShowPopup(MouseEvent e) {
/*  279 */         JTable tblDetails = LineList.this.getJTable();
/*      */         
/*  281 */         LineList.this.mainPopupCol = tblDetails.columnAtPoint(e.getPoint());
/*  282 */         LineList.this.popupRow = tblDetails.rowAtPoint(e.getPoint());
/*      */         
/*  284 */         return true;
/*      */       }
/*  286 */     };
/*  287 */     mainPopup.getPopup().add(this.tblScrollPane.getShowFieldsMenu());
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  292 */     viewOfFile.setFrame(ReMainFrame.getMasterFrame());
/*      */     
/*      */ 
/*  295 */     tableDetails.addMouseListener(mainPopup);
/*      */     
/*  297 */     initToolTips(2);
/*      */     
/*  299 */     tableDetails.getTableHeader().addMouseListener(new BaseDisplay.HeaderSort(this));
/*      */     
/*  301 */     super.setAlternativeTbl(this.tblScrollPane.getFixedTable());
/*      */     
/*  303 */     this.actualPnl.registerComponentRE(tableDetails);
/*  304 */     this.actualPnl.registerComponentRE(this.tblScrollPane.getFixedTable());
/*  305 */     defColumns();
/*      */     
/*  307 */     this.tblScrollPane.getFixedTable().getTableHeader().addMouseListener(new BaseDisplay.HeaderSort(this));
/*  308 */     this.tblScrollPane.getFixedTable().addMouseListener(new MenuPopupListener(fixedActions, true, null) {
/*      */       public void mousePressed(MouseEvent m) {
/*  310 */         JTable tbl = LineList.this.tblScrollPane.getFixedTable();
/*  311 */         int col = tbl.columnAtPoint(m.getPoint());
/*      */         
/*  313 */         LineList.this.popupRow = LineList.this.getJTable().rowAtPoint(m.getPoint());
/*      */         
/*  315 */         if (col == 0) {
/*  316 */           LineList.this.newLineFrame(LineList.this.fileView, LineList.this.popupRow);
/*      */         } else {
/*  318 */           super.mousePressed(m);
/*      */         }
/*      */       }
/*      */       
/*      */       protected boolean isOkToShowPopup(MouseEvent e) {
/*  323 */         JTable tbl = LineList.this.tblScrollPane.getFixedTable();
/*  324 */         LineList.this.fixedPopupCol = tbl.columnAtPoint(e.getPoint());
/*  325 */         LineList.this.popupRow = tbl.rowAtPoint(e.getPoint());
/*      */         
/*  327 */         return LineList.this.fixedPopupCol > 0;
/*      */ 
/*      */       }
/*      */       
/*      */ 
/*  332 */     });
/*  333 */     viewOfFile.getBaseFile().addTableModelListener(this);
/*      */   }
/*      */   
/*      */ 
/*      */   private JMenu init_110_GetCsvMenu()
/*      */   {
/*  339 */     JMenu m = SwingUtils.newMenu("CSV Options");
/*      */     
/*  341 */     this.copyMenu.setIcon(Common.getRecordIcon(22));
/*  342 */     this.moveMenu.setIcon(Common.getRecordIcon(24));
/*      */     
/*  344 */     m.add(new AddColumn("Add Column before", false));
/*  345 */     m.add(new AddColumn("Add Column after", true));
/*  346 */     m.add(new DeleteColumn());
/*  347 */     m.addSeparator();
/*  348 */     m.add(this.copyMenu);
/*  349 */     m.add(this.moveMenu);
/*      */     
/*  351 */     m.add(new CsvUpdateLayoutAction(true));
/*  352 */     buildDestinationMenus();
/*      */     
/*  354 */     return m;
/*      */   }
/*      */   
/*      */   private void init_200_LayoutScreen()
/*      */   {
/*  359 */     this.actualPnl.addReKeyListener(new BaseDisplay.DelKeyWatcher(this));
/*  360 */     this.actualPnl.setHelpURLre(Common.formatHelpURL("HlpRe03.htm"));
/*      */     
/*  362 */     this.actualPnl.addComponentRE(1, 5, -1.0D, BasePanel.GAP, 2, 2, this.tblScrollPane);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  368 */     if ((this.layout.getRecordCount() > 1) && (Common.usePrefered())) {
/*  369 */       LayoutCombo combo = getLayoutCombo();
/*  370 */       combo.setSelectedIndex(combo.getPreferedIndex());
/*  371 */       setTableFormatDetails(combo.getPreferedIndex());
/*  372 */       fireLayoutIndexChanged();
/*      */     } else {
/*  374 */       setLayoutIdx();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setScreenSize(boolean mainframe)
/*      */   {
/*  392 */     DisplayFrame parentFrame = getParentFrame();
/*  393 */     parentFrame.bldScreen();
/*      */     
/*  395 */     parentFrame.setBounds(1, 1, this.screenSize.width - 1, this.screenSize.height - 1);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  400 */     parentFrame.setToMaximum(true);
/*  401 */     parentFrame.setVisible(true);
/*      */     
/*  403 */     Common.calcColumnWidths(this.tblDetails, 2);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setNewLayout(AbstractLayoutDetails newLayout)
/*      */   {
/*  416 */     super.setNewLayout(newLayout);
/*      */     
/*  418 */     this.tblScrollPane.clearHiddenCols();
/*  419 */     this.fieldMapping.resetMapping(getFieldCounts());
/*  420 */     if ((this.layout.getRecordCount() > 1) && (Common.usePrefered())) {
/*  421 */       LayoutCombo combo = getLayoutCombo();
/*  422 */       combo.setSelectedIndex(combo.getPreferedIndex());
/*      */     }
/*      */     else {
/*  425 */       setLayoutIdx();
/*      */     }
/*  427 */     int idx = getLayoutIndex();
/*  428 */     this.fileView.setCurrLayoutIdx(idx);
/*  429 */     setTableFormatDetails(idx);
/*      */     
/*  431 */     this.fileView.fireTableStructureChanged();
/*  432 */     defColumns();
/*      */   }
/*      */   
/*      */   private void buildDestinationMenus()
/*      */   {
/*  437 */     if ((this.layout.getRecordCount() == 1) && (this.layout.getRecord(0).getFieldCount() > 0)) {
/*  438 */       AbstractRecordDetail rec = this.layout.getRecord(0);
/*      */       
/*  440 */       this.copyMenu.removeAll();
/*  441 */       this.moveMenu.removeAll();
/*      */       
/*  443 */       String s = ReMessages.BEFORE_FIELD.get(rec.getField(0).getName());
/*      */       
/*  445 */       this.copyMenu.add(new MoveCopyColumn(s, true, 0));
/*  446 */       this.moveMenu.add(new MoveCopyColumn(s, false, 0));
/*      */       
/*  448 */       for (int i = 0; i < rec.getFieldCount(); i++) {
/*  449 */         s = ReMessages.AFTER_FIELD.get(rec.getField(i).getName());
/*      */         
/*  451 */         this.copyMenu.add(new MoveCopyColumn(s, true, i + 1));
/*  452 */         this.moveMenu.add(new MoveCopyColumn(s, false, i + 1));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public final void checkForTblRowChange(int row)
/*      */   {
/*  463 */     if (this.lastRow != row) {
/*  464 */       if ((this.isPrefered) && (this.lastRow != row)) {
/*  465 */         int recordIdx = this.fileView.getLine(row).getPreferredLayoutIdx();
/*  466 */         if (recordIdx != this.fileView.getDefaultPreferredIndex()) {
/*  467 */           this.fileView.setDefaultPreferredIndex(recordIdx);
/*      */           
/*  469 */           TableColumnModel columns = this.tblDetails.getColumnModel();
/*  470 */           int last = Math.min(this.fileView.getColumnCount(), columns.getColumnCount());
/*  471 */           for (int i = 0; i < last; i++)
/*      */           {
/*  473 */             columns.getColumn(i).setHeaderValue(this.fileView.getColumnName(columns.getColumn(i).getModelIndex()));
/*      */           }
/*  475 */           this.tblScrollPane.correctFixedSize();
/*      */         }
/*      */       }
/*      */       
/*  479 */       if (this.childFrame != null) {
/*  480 */         this.childFrame.setCurrRow(row);
/*      */       }
/*      */     }
/*  483 */     this.lastRow = row;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public AbstractFileDisplay createChildScreen(int pos)
/*      */   {
/*  493 */     this.childFrame = new LineFrame("ChildRecord:", this.fileView, Math.max(0, getCurrRow()), false);
/*  494 */     setKeylistner(this.tblDetails);
/*  495 */     return this.childFrame;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public AbstractFileDisplay getChildScreen()
/*      */   {
/*  505 */     return this.childFrame;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void removeChildScreen()
/*      */   {
/*  515 */     if (this.childFrame != null) {
/*  516 */       this.childFrame.doClose();
/*      */     }
/*  518 */     this.childFrame = null;
/*  519 */     setKeylistner(this.tblDetails);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void fireLayoutIndexChanged()
/*      */   {
/*  527 */     int idx = getLayoutIndex();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  532 */     if (this.fileView.getCurrLayoutIdx() != idx) {
/*  533 */       this.fileView.setCurrLayoutIdx(idx);
/*      */       
/*  535 */       this.fileView.fireTableStructureChanged();
/*  536 */       this.tblScrollPane.clearHiddenCols();
/*      */       
/*  538 */       defColumns();
/*      */       
/*  540 */       if (idx < this.layout.getRecordCount()) {
/*  541 */         setFieldVisibility(idx, this.fieldMapping.getFieldVisibility(idx));
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private void hideColumn(int col)
/*      */   {
/*  548 */     this.tblScrollPane.doHideColumn(col);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private void defColumns()
/*      */   {
/*  555 */     defColumns(getJTable(), this.fileView, this.tblScrollPane);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   private JTable defColumns(JTable tbl, FileView view, FixedColumnScrollPane scrollPane)
/*      */   {
/*  562 */     TableColumnModel tcm = tbl.getColumnModel();
/*      */     
/*  564 */     defineColumns(tbl, view.getColumnCount(), 2, 0);
/*      */     
/*  566 */     for (int i = 2; i < tcm.getColumnCount(); i++) {
/*  567 */       tcm.getColumn(i).setHeaderRenderer(this.headerRender);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*  572 */     int layoutIdx = getLayoutIndex();
/*  573 */     int lineHeight = tbl.getRowHeight();
/*  574 */     String font = this.layout.getFontName();
/*      */     
/*  576 */     if ((scrollPane != null) && (scrollPane.STD_LINE_HEIGHT > lineHeight)) {
/*  577 */       lineHeight = scrollPane.STD_LINE_HEIGHT;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  583 */     int fullLineIndex = getLayoutCombo().getFullLineIndex();
/*  584 */     this.isPrefered = (layoutIdx == getLayoutCombo().getPreferedIndex());
/*      */     
/*  586 */     setKeylistner(tbl);
/*  587 */     if ((!this.isPrefered) && (tcm.getColumnCount() >= 3))
/*      */     {
/*  589 */       if (layoutIdx == fullLineIndex) {
/*  590 */         if (this.charRendor == null) {
/*  591 */           this.charRendor = new MonoSpacedRender();
/*  592 */           this.charEditor = new DefaultCellEditor(new MonoSpacedRender());
/*      */         }
/*      */         
/*  595 */         tcm.getColumn(2).setCellRenderer(this.charRendor);
/*  596 */         tcm.getColumn(2).setCellEditor(this.charEditor);
/*  597 */       } else if (layoutIdx == fullLineIndex + 1) {
/*  598 */         if (this.hex1Rendor == null) {
/*  599 */           this.hex1Rendor = new HexOneLineRender();
/*  600 */           this.hex1Editor = new HexTableCellEditor(new HexOneLineRender());
/*      */         }
/*      */         
/*  603 */         tcm.getColumn(2).setCellRenderer(this.hex1Rendor);
/*  604 */         tcm.getColumn(2).setCellEditor(this.hex1Editor);
/*  605 */       } else if (layoutIdx == fullLineIndex + 2) {
/*  606 */         if (this.hex2Rendor == null) {
/*  607 */           this.hex2Rendor = new HexTwoLineRender(font);
/*  608 */           this.hex2Editor = new HexTableCellEditor(new HexTwoLineField(font));
/*      */         }
/*      */         
/*  611 */         tcm.getColumn(2).setCellRenderer(this.hex2Rendor);
/*  612 */         tcm.getColumn(2).setCellEditor(this.hex2Editor);
/*  613 */         lineHeight = scrollPane.TWO_LINE_HEIGHT;
/*  614 */       } else if (layoutIdx == fullLineIndex + 3) {
/*  615 */         if (this.hex3Rendor == null) {
/*  616 */           this.hex3Rendor = new HexThreeLineRender(font);
/*  617 */           this.hex3Editor = new HexTableCellEditor(new HexThreeLineField(font));
/*      */         }
/*      */         
/*  620 */         tcm.getColumn(2).setCellRenderer(this.hex3Rendor);
/*  621 */         tcm.getColumn(2).setCellEditor(this.hex3Editor);
/*  622 */         lineHeight = scrollPane.THREE_LINE_HEIGHT;
/*  623 */       } else if (layoutIdx == fullLineIndex + 4) {
/*  624 */         if (this.hex2RendorA == null) {
/*  625 */           this.hex2RendorA = new HexGenericRender(font, new HexTwoLineFieldAlt(font));
/*  626 */           this.hex2EditorA = new HexTableCellEditor(new HexTwoLineFieldAlt(font));
/*      */         }
/*      */         
/*  629 */         tcm.getColumn(2).setCellRenderer(this.hex2RendorA);
/*  630 */         tcm.getColumn(2).setCellEditor(this.hex2EditorA);
/*  631 */         lineHeight = scrollPane.TWO_LINE_HEIGHT;
/*      */       }
/*      */     }
/*  634 */     setRowHeight(lineHeight);
/*      */     
/*  636 */     if (scrollPane != null) {
/*  637 */       int rowCount = view.getRowCount();
/*  638 */       int width = SwingUtils.CHAR_FIELD_WIDTH;
/*  639 */       System.out.println("Setup fixed columns ... " + width);
/*  640 */       scrollPane.setFixedColumns(2);
/*  641 */       TableColumn tc = scrollPane.getFixedTable().getColumnModel().getColumn(0);
/*  642 */       tc.setCellRenderer(this.tableBtn);
/*  643 */       tc.setPreferredWidth(5);
/*  644 */       if (scrollPane.getFixedTable().getColumnModel().getColumnCount() <= 1) {
/*  645 */         Common.logMsg("Error No Fields defined in the layout !!!", null);
/*      */       } else {
/*  647 */         tc = scrollPane.getFixedTable().getColumnModel().getColumn(1);
/*  648 */         if (rowCount > 10000000) {
/*  649 */           width = 8;
/*  650 */         } else if (rowCount > 1000000) {
/*  651 */           width = 7;
/*  652 */         } else if (rowCount > 100000) {
/*  653 */           width = 6;
/*      */         }
/*  655 */         tc.setPreferredWidth(SwingUtils.STANDARD_FONT_WIDTH * width);
/*  656 */         tc.setResizable(false);
/*      */         
/*  658 */         scrollPane.correctFixedSize();
/*      */       }
/*      */     }
/*      */     
/*  662 */     if (layoutIdx >= fullLineIndex) {
/*  663 */       Common.calcColumnWidths(tbl, 1);
/*  664 */       this.copyMenu.removeAll();
/*  665 */       this.moveMenu.removeAll();
/*      */     } else {
/*  667 */       buildDestinationMenus();
/*      */     }
/*  669 */     return tbl;
/*      */   }
/*      */   
/*      */ 
/*      */   private void setKeylistner(JTable tbl)
/*      */   {
/*  675 */     if ((this.isPrefered) || (this.childFrame != null)) {
/*  676 */       if (tbl == this.tblDetails) {
/*  677 */         tbl.removeKeyListener(this.keyListner);
/*  678 */         tbl.addKeyListener(this.keyListner);
/*      */       }
/*  680 */       this.lastRow = -1;
/*  681 */       checkForTblRowChange(tbl.getSelectedRow());
/*      */     } else {
/*  683 */       tbl.removeKeyListener(this.keyListner);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public int getCurrRow()
/*      */   {
/*  695 */     if (this.tblDetails.getSelectedRowCount() > 0) {
/*  696 */       return this.tblDetails.getSelectedRow();
/*      */     }
/*  698 */     return -1;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   protected int getPopupPosition()
/*      */   {
/*  706 */     return this.popupRow;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setCurrRow(int newRow, int layoutId, int fieldNum)
/*      */   {
/*  719 */     if ((newRow >= 0) && (newRow <= this.fileView.getRowCount())) {
/*  720 */       if (getCurrRow() != newRow) {
/*  721 */         this.fileView.fireTableDataChanged();
/*  722 */         this.tblDetails.changeSelection(newRow, 1, false, false);
/*      */       }
/*      */       
/*  725 */       if ((fieldNum >= 0) && (isCurrLayoutIdx(layoutId))) {
/*  726 */         stopCellEditing();
/*  727 */         this.tblDetails.editCellAt(newRow, FieldMapping.getAdjColumn(this.fieldMapping, layoutId, fieldNum));
/*      */       }
/*      */       
/*      */ 
/*  731 */       checkForTblRowChange(newRow);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void executeAction(int action)
/*      */   {
/*  740 */     JTable table = getJTable();
/*      */     
/*      */ 
/*  743 */     int selectedRow = table.getSelectedRow();
/*  744 */     TableColumnModel columnModel; switch (action) {
/*      */     case 31: 
/*  746 */       this.fileView.repeatLine(this.popupRow);
/*  747 */       break;
/*      */     case 29: 
/*      */     case 77: 
/*      */     case 78: 
/*  751 */       super.executeAction(action);
/*  752 */       checkForTblRowChange(selectedRow);
/*  753 */       break;
/*      */     case 79: 
/*  755 */       if (selectedRow >= 0) {
/*  756 */         Clipboard system = Toolkit.getDefaultToolkit().getSystemClipboard();
/*      */         try {
/*  758 */           String ss = (String)system.getContents(this).getTransferData(DataFlavor.stringFlavor);
/*      */           
/*  760 */           columnModel = table.getColumnModel();
/*  761 */           boolean changed = this.fileView.insertCells(getLayoutIndex(), selectedRow, columnModel.getColumn(table.getSelectedColumn()).getModelIndex(), new BasicTable(ss));
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  766 */           if (changed) {
/*  767 */             Code.notifyFramesOfUpdatedLayout(this.fileMaster, this.layout);
/*      */           }
/*      */         }
/*      */         catch (UnsupportedFlavorException e)
/*      */         {
/*  772 */           e.printStackTrace();
/*      */         } catch (IOException e) {
/*  774 */           e.printStackTrace();
/*      */         } }
/*  776 */       break;
/*      */     
/*      */     case 81: 
/*  779 */       SwingUtils.copySelectedCells(getJTable());
/*      */     
/*      */     case 80: 
/*  782 */       int[] selectedColumns = table.getSelectedColumns();
/*  783 */       columnModel = table.getColumnModel();
/*  784 */       for (int i = 0; i < selectedColumns.length; i++) {
/*  785 */         selectedColumns[i] = columnModel.getColumn(selectedColumns[i]).getModelIndex();
/*      */       }
/*  787 */       this.fileView.deleteCells(getLayoutIndex(), table.getSelectedRows(), selectedColumns);
/*  788 */       break;
/*      */     case 48: 
/*  790 */       int startRow = selectedRow;
/*  791 */       int startCol = table.getSelectedColumn();
/*  792 */       if (startRow >= 0) {
/*  793 */         Clipboard system = Toolkit.getDefaultToolkit().getSystemClipboard();
/*      */         try {
/*  795 */           String pasteStr = (String)system.getContents(this).getTransferData(DataFlavor.stringFlavor);
/*      */           
/*  797 */           int numRows = new StringTokenizer(pasteStr, "\n").countTokens();
/*  798 */           for (int i = 0; i < numRows; i++) {
/*  799 */             this.fileView.newLine(startRow, 0);
/*      */           }
/*      */           
/*  802 */           pasteTable(startRow + 1, startCol, pasteStr);
/*      */         } catch (Exception e) {}
/*      */       }
/*  805 */       break;
/*      */     
/*      */ 
/*      */     default: 
/*  809 */       super.executeAction(action);
/*      */     }
/*      */     
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean isActionAvailable(int action)
/*      */   {
/*  822 */     switch (action) {
/*      */     case 31: 
/*      */     case 48: 
/*      */     case 50: 
/*  826 */       return true;
/*      */     case 79: 
/*      */     case 80: 
/*      */     case 81: 
/*  830 */       return this.layout.getOption(12) == 1;
/*      */     }
/*  832 */     return super.isActionAvailable(action);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void tableChanged(TableModelEvent event)
/*      */   {
/*  847 */     if (hasTheTableStructureChanged(event)) {
/*  848 */       super.hasTheFormatChanged(event);
/*  849 */       defColumns();
/*      */     } else {
/*  851 */       checkForResize(event);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected void setColWidths() {}
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public FieldSequence getFieldSequence()
/*      */   {
/*  866 */     FieldSequence rec = null;
/*  867 */     int layoutIdx = getLayoutIndex();
/*      */     
/*  869 */     if (layoutIdx < this.layout.getRecordCount()) {
/*  870 */       int[][] fieldIdx = this.tblScrollPane.getColumnSequence();
/*  871 */       int st = 2;
/*      */       
/*  873 */       rec = new FieldSequence();
/*  874 */       rec.name = this.layout.getRecord(layoutIdx).getRecordName();
/*  875 */       rec.fields = getNames(layoutIdx, st, fieldIdx[1]);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  880 */       rec.fixedFields = getNames(layoutIdx, st, fieldIdx[0]);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  886 */     return rec;
/*      */   }
/*      */   
/*      */   private String[] getNames(int layoutIdx, int st, int[] fields)
/*      */   {
/*  891 */     int j = 0;
/*  892 */     String[] ret = new String[getSize(fields)];
/*      */     
/*  894 */     for (int i = 0; i < fields.length; i++) {
/*  895 */       int idx = fields[i];
/*      */       
/*  897 */       if (idx >= st) {
/*  898 */         ret[(j++)] = this.fileView.getRealColumnName(layoutIdx, this.fileView.getRealColumn(layoutIdx, idx - st));
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  907 */     return ret;
/*      */   }
/*      */   
/*      */   private int getSize(int[] array)
/*      */   {
/*  912 */     int size = array.length;
/*      */     
/*  914 */     for (int a : array) {
/*  915 */       if (a <= 1) {
/*  916 */         size--;
/*      */       }
/*      */     }
/*  919 */     return size;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFieldSequence(FieldSequence seq)
/*      */   {
/*  927 */     int[][] fields = new int[2][];
/*  928 */     HashMap<String, Integer> map = new HashMap();
/*  929 */     int st = 2;
/*  930 */     int layoutIdx = this.layout.getRecordIndex(seq.name);
/*      */     
/*  932 */     if (layoutIdx >= 0) {
/*  933 */       setLayoutIndex(layoutIdx);
/*  934 */       for (int i = st; i < this.fileView.getColumnCount(); i++)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  941 */         map.put(this.fileView.getRealColumnName(layoutIdx, this.fileView.getRealColumn(layoutIdx, i - st)).toLowerCase(), Integer.valueOf(i));
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*  947 */       fields[1] = getFieldIndex(seq.fields, map);
/*      */       
/*  949 */       fields[0] = getFieldIndex(seq.fixedFields, map);
/*      */       
/*      */ 
/*  952 */       this.tblScrollPane.setColumnSequence(fields, st);
/*      */     }
/*      */   }
/*      */   
/*      */   private int[] getFieldIndex(String[] names, HashMap<String, Integer> map)
/*      */   {
/*  958 */     if (names == null) {
/*  959 */       return new int[0];
/*      */     }
/*  961 */     int[] ret = new int[names.length];
/*  962 */     int i = 0;
/*      */     
/*  964 */     for (String name : names) {
/*  965 */       name = name.toLowerCase();
/*  966 */       ret[i] = -1;
/*  967 */       if (map.containsKey(name)) {
/*  968 */         ret[i] = ((Integer)map.get(name)).intValue();
/*      */       }
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  975 */       i++;
/*      */     }
/*      */     
/*  978 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean[] getFieldVisibility(int recordIndex)
/*      */   {
/*  987 */     boolean[] ret = null;
/*  988 */     if (recordIndex == getLayoutIndex()) {
/*  989 */       ret = this.tblScrollPane.getFieldVisibility(2);
/*      */     } else {
/*  991 */       ret = this.fieldMapping.getFieldVisibility(recordIndex);
/*      */     }
/*      */     
/*  994 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public void setFieldVisibility(int recordIndex, boolean[] fieldVisibility)
/*      */   {
/* 1002 */     this.fieldMapping.setFieldVisibilty(recordIndex, fieldVisibility);
/*      */     
/* 1004 */     if (recordIndex == getLayoutIndex()) {
/* 1005 */       this.tblScrollPane.setFieldVisibility(2, fieldVisibility);
/*      */     }
/*      */     
/* 1008 */     DisplayFrame parentFrame = getParentFrame();
/* 1009 */     if (parentFrame != null) {
/* 1010 */       parentFrame.setToActiveFrame();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public void layoutChanged(AbstractLayoutDetails newLayout)
/*      */   {
/* 1022 */     defColumns();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private class AddColumn
/*      */     extends ReAbstractAction
/*      */   {
/*      */     private boolean afterDest;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public AddColumn(String name, boolean after)
/*      */     {
/* 1076 */       super(25);
/* 1077 */       this.afterDest = after;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void actionPerformed(ActionEvent arg0)
/*      */     {
/*      */       try
/*      */       {
/* 1088 */         int col = LineList.this.tblDetails.getColumnModel().getColumn(LineList.this.mainPopupCol).getModelIndex() - 2;
/*      */         
/*      */ 
/*      */ 
/* 1092 */         if (this.afterDest) {
/* 1093 */           col++;
/*      */         }
/*      */         
/* 1096 */         LineList.this.stopCellEditing();
/* 1097 */         Code.addColumn(LineList.this.fileMaster, (LayoutDetail)LineList.this.layout, col, -121);
/*      */       }
/*      */       catch (Exception e) {
/* 1100 */         e.printStackTrace();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private class MoveCopyColumn extends AbstractAction
/*      */   {
/*      */     private boolean copyFunc;
/*      */     private int dest;
/*      */     
/*      */     public MoveCopyColumn(String name, boolean copy, int destination) {
/* 1111 */       super();
/* 1112 */       this.copyFunc = copy;
/* 1113 */       this.dest = destination;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */     public void actionPerformed(ActionEvent arg0)
/*      */     {
/*      */       try
/*      */       {
/* 1123 */         int col = LineList.this.tblDetails.getColumnModel().getColumn(LineList.this.mainPopupCol).getModelIndex() - 2;
/*      */         
/* 1125 */         LayoutDetail l = (LayoutDetail)LineList.this.layout;
/*      */         
/* 1127 */         LineList.this.stopCellEditing();
/* 1128 */         if (this.copyFunc) {
/* 1129 */           Code.addColumn(LineList.this.fileMaster, l, this.dest, col);
/*      */         } else {
/* 1131 */           Code.moveColumn(LineList.this.fileMaster, l, this.dest, col);
/*      */         }
/*      */       } catch (Exception e) {
/* 1134 */         e.printStackTrace();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   private class DeleteColumn extends ReAbstractAction
/*      */   {
/*      */     public DeleteColumn() {
/* 1142 */       super(23);
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     public void actionPerformed(ActionEvent arg0)
/*      */     {
/*      */       try
/*      */       {
/* 1153 */         int col = LineList.this.tblDetails.getColumnModel().getColumn(LineList.this.mainPopupCol).getModelIndex() - 2;
/*      */         
/*      */ 
/* 1156 */         LineList.this.stopCellEditing();
/* 1157 */         Code.deleteColumn(LineList.this.fileMaster, (LayoutDetail)LineList.this.layout, col);
/*      */       }
/*      */       catch (Exception e) {
/* 1160 */         e.printStackTrace();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   protected BaseDisplay getNewDisplay(FileView view)
/*      */   {
/* 1171 */     return new LineList("Table:", view.getLayout(), view, this.fileMaster);
/*      */   }
/*      */   
/*      */   protected class LinesTbl extends JTable
/*      */   {
/*      */     private final int firstDataCol;
/*      */     
/*      */     public LinesTbl(TableModel dm, int firstDataColumn)
/*      */     {
/* 1180 */       super();
/* 1181 */       this.firstDataCol = firstDataColumn;
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */     public TableCellRenderer getCellRenderer(int row, int column)
/*      */     {
/* 1188 */       TableCellRenderer[] iCellRenders = LineList.this.cellRenders;
/*      */       
/* 1190 */       if (LineList.this.isPrefered) {
/* 1191 */         int recordIndex = LineList.this.fileView.getLine(row).getPreferredLayoutIdx();
/* 1192 */         iCellRenders = LineList.this.getDisplayDetails(recordIndex).getCellRenders();
/*      */       }
/*      */       
/* 1195 */       int adjCol = column - this.firstDataCol;
/* 1196 */       if (noCellEditor(adjCol, row, iCellRenders)) {
/* 1197 */         return super.getCellRenderer(row, column);
/*      */       }
/*      */       
/* 1200 */       return iCellRenders[adjCol];
/*      */     }
/*      */     
/*      */     public TableCellEditor getCellEditor(int row, int column)
/*      */     {
/* 1205 */       TableCellEditor[] iCellEditors = LineList.this.cellEditors;
/* 1206 */       if (LineList.this.isPrefered) {
/* 1207 */         int recordIndex = LineList.this.fileView.getLine(row).getPreferredLayoutIdx();
/* 1208 */         iCellEditors = LineList.this.getDisplayDetails(recordIndex).getCellEditors();
/*      */       }
/*      */       
/* 1211 */       int adjCol = column - this.firstDataCol;
/* 1212 */       if (noCellEditor(adjCol, column, iCellEditors)) {
/* 1213 */         return super.getCellEditor(row, column);
/*      */       }
/* 1215 */       return iCellEditors[adjCol];
/*      */     }
/*      */     
/*      */     private boolean noCellEditor(int column, int row, Object[] cellPainters) {
/* 1219 */       return (column < 0) || (cellPainters == null) || (column >= cellPainters.length) || (cellPainters[column] == null);
/*      */     }
/*      */   }
/*      */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/LineList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */