/*     */ package net.sf.RecordEditor.edit.display;
/*     */ 
/*     */ import java.awt.Point;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.KeyListener;
/*     */ import java.awt.event.MouseEvent;
/*     */ import javax.swing.Action;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.JTextPane;
/*     */ import javax.swing.event.DocumentEvent;
/*     */ import javax.swing.text.BadLocationException;
/*     */ import javax.swing.text.Caret;
/*     */ import javax.swing.text.DefaultHighlighter;
/*     */ import javax.swing.text.Document;
/*     */ import javax.swing.text.Highlighter;
/*     */ import javax.swing.text.JTextComponent;
/*     */ import net.sf.JRecord.Common.AbstractFieldValue;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail.FieldDetails;
/*     */ import net.sf.RecordEditor.edit.display.Action.GotoLineAction;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*     */ import net.sf.RecordEditor.re.file.DataStoreContent;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.re.file.textDocument.CsvEditorKit;
/*     */ import net.sf.RecordEditor.re.file.textDocument.FileDocument3;
/*     */ import net.sf.RecordEditor.re.file.textDocument.FileDocument5;
/*     */ import net.sf.RecordEditor.re.file.textDocument.FixedEditorKit;
/*     */ import net.sf.RecordEditor.utils.MenuPopupListener;
/*     */ import net.sf.RecordEditor.utils.fileStorage.IDataStorePosition;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.TextLineNumber;
/*     */ 
/*     */ public class DocumentScreen extends BaseDisplay implements javax.swing.event.DocumentListener, AbstractCreateChildScreen
/*     */ {
/*     */   private final JTextComponent textDisplay;
/*     */   private final DataStoreContent content;
/*     */   private int popupRow;
/*     */   private final boolean colorFields;
/*  42 */   private int lastRow = -1;
/*     */   
/*     */   private LineFrame childFrame;
/*  45 */   private KeyListener rowChangeListner = new KeyListener()
/*     */   {
/*     */     public void keyTyped(KeyEvent e) {}
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void keyReleased(KeyEvent e)
/*     */     {
/*  54 */       DocumentScreen.this.checkForTblRowChange(DocumentScreen.this.getCurrRow());
/*     */     }
/*     */     
/*     */ 
/*     */     public void keyPressed(KeyEvent e) {}
/*     */   };
/*     */   
/*     */   public DocumentScreen(FileView view, boolean colorFields)
/*     */   {
/*  63 */     super("Document View", view, false, false, false, false, false, 4);
/*     */     
/*  65 */     setAllowPaste(false);
/*  66 */     setJTable(new JTable());
/*     */     
/*  68 */     this.content = view.asDocumentContent();
/*  69 */     this.colorFields = colorFields;
/*     */     
/*  71 */     if (this.content == null) {
/*  72 */       throw new RuntimeException("File does not support Text Editting");
/*     */     }
/*     */     
/*  75 */     if (colorFields)
/*     */     {
/*  77 */       JTextPane jEditorPane = new JTextPane();
/*     */       
/*     */ 
/*  80 */       this.textDisplay = jEditorPane;
/*  81 */       if (view.getLayout().getOption(9) == 1) {
/*  82 */         jEditorPane.setEditorKit(new CsvEditorKit());
/*     */       } else {
/*  84 */         jEditorPane.setEditorKit(new FixedEditorKit());
/*     */       }
/*  86 */       jEditorPane.setDocument(new FileDocument5(this.content, colorFields));
/*     */     } else {
/*  88 */       this.textDisplay = new JTextArea();
/*  89 */       this.textDisplay.setDocument(new FileDocument3(this.content, colorFields));
/*     */     }
/*     */     
/*  92 */     this.textDisplay.setFont(net.sf.RecordEditor.utils.swing.SwingUtils.getMonoSpacedFont());
/*  93 */     this.textDisplay.getDocument().addDocumentListener(this);
/*     */     
/*  95 */     this.actualPnl.addComponentRE(1, 3, -1.0D, BasePanel.GAP, 2, 2, TextLineNumber.getTextLineNumber(this.textDisplay, Math.min(3, (int)Math.log(view.getRowCount() + 1))));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 100 */     defPopup();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void defPopup()
/*     */   {
/* 107 */     MenuPopupListener popup = new MenuPopupListener(null, true, null)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */       public void mouseReleased(MouseEvent e)
/*     */       {
/*     */ 
/*     */ 
/* 116 */         IDataStorePosition p = DocumentScreen.this.getPosition(e.getPoint());
/* 117 */         if (p != null) {
/* 118 */           DocumentScreen.this.checkForTblRowChange(p.getLineNumberRE());
/*     */         }
/* 120 */         super.mouseReleased(e);
/*     */       }
/*     */       
/*     */       protected final boolean isOkToShowPopup(MouseEvent e)
/*     */       {
/* 125 */         IDataStorePosition p = DocumentScreen.this.getPosition(e.getPoint());
/* 126 */         DocumentScreen.this.popupRow = -1;
/* 127 */         if (p != null)
/*     */         {
/* 129 */           DocumentScreen.this.popupRow = p.getLineNumberRE();
/*     */         }
/*     */         
/* 132 */         DocumentScreen.this.textDisplay.getHighlighter().removeAllHighlights();
/* 133 */         return true;
/*     */       }
/*     */       
/* 136 */     };
/* 137 */     popup.getPopup().add(new GotoLineAction(this, this.fileView));
/*     */     
/* 139 */     this.textDisplay.addMouseListener(popup);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setScreenSize(boolean mainframe)
/*     */   {
/* 146 */     DisplayFrame parentFrame = getParentFrame();
/* 147 */     parentFrame.bldScreen();
/*     */     
/* 149 */     parentFrame.setToMaximum(false);
/* 150 */     parentFrame.setVisible(true);
/*     */   }
/*     */   
/*     */ 
/*     */   private IDataStorePosition getPosition(Point p)
/*     */   {
/* 156 */     int where = this.textDisplay.viewToModel(p);
/*     */     
/* 158 */     if (where >= 0) {
/*     */       try {
/* 160 */         return this.content.createTempPosition(where);
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*     */     
/* 165 */     return null;
/*     */   }
/*     */   
/*     */   protected int getInsertAfterPosition()
/*     */   {
/* 170 */     return getCurrRow();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void fireLayoutIndexChanged() {}
/*     */   
/*     */ 
/*     */   public int getCurrRow()
/*     */   {
/* 180 */     return getLineFromPos(this.textDisplay.getCaretPosition());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int getPopupPosition()
/*     */   {
/* 188 */     return this.popupRow;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setCurrRow(int newRow, int layoutId, int fieldNum)
/*     */   {
/* 195 */     if ((newRow >= 0) && (newRow < this.fileView.getRowCount())) {
/* 196 */       IDataStorePosition p = this.content.getPositionByLineNumber(newRow, false);
/* 197 */       int fpos = 0;
/* 198 */       int len = 1;
/*     */       
/*     */ 
/* 201 */       if ((layoutId >= 0) && (layoutId < this.layout.getRecordCount()) && (fieldNum >= 0) && (fieldNum < this.layout.getRecord(layoutId).getFieldCount()))
/*     */       {
/* 203 */         AbstractRecordDetail.FieldDetails field = this.layout.getRecord(layoutId).getField(fieldNum);
/* 204 */         if (field.isFixedFormat()) {
/* 205 */           fpos = field.getPos() - 1;
/* 206 */           len = field.getLen();
/* 207 */         } else if (p.getLineRE() != null) {
/* 208 */           int next = 0;
/* 209 */           for (int i = 0; i <= fieldNum; i++) {
/* 210 */             fpos = next;
/* 211 */             len = p.getLineRE().getFieldValue(0, i).asString().length();
/* 212 */             next += len;
/*     */           }
/* 214 */           fpos += fieldNum;
/*     */         }
/*     */       }
/* 217 */       int start = p.getOffset() + fpos;
/* 218 */       Highlighter h = this.textDisplay.getHighlighter();
/*     */       
/* 220 */       this.textDisplay.getCaret().setDot(start);
/* 221 */       checkForTblRowChange(newRow);
/*     */       
/* 223 */       h.removeAllHighlights();
/*     */       try
/*     */       {
/* 226 */         h.addHighlight(start, start + len, DefaultHighlighter.DefaultPainter);
/*     */       }
/*     */       catch (BadLocationException e)
/*     */       {
/* 230 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected BaseDisplay getNewDisplay(FileView view)
/*     */   {
/* 237 */     return new DocumentScreen(view, this.colorFields);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSelectedRowCount()
/*     */   {
/* 245 */     int en = getLineFromPos(this.textDisplay.getSelectionEnd());
/* 246 */     if (en < 0) return 0;
/* 247 */     return en - getLineFromPos(this.textDisplay.getSelectionStart()) + 1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int[] getSelectedRows()
/*     */   {
/* 255 */     int en = getLineFromPos(this.textDisplay.getSelectionEnd());
/* 256 */     int st = getLineFromPos(this.textDisplay.getSelectionStart());
/*     */     
/* 258 */     if (en < 0) {
/* 259 */       return new int[0];
/*     */     }
/* 261 */     int[] ret = new int[en - st + 1];
/*     */     
/* 263 */     for (int i = st; i <= en; i++) {
/* 264 */       ret[(i - st)] = i;
/*     */     }
/*     */     
/* 267 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */   private int getLineFromPos(int pos)
/*     */   {
/*     */     try
/*     */     {
/* 275 */       IDataStorePosition p = this.content.createPosition(pos);
/* 276 */       return p.getLineNumberRE();
/*     */     }
/*     */     catch (Exception e) {}
/* 279 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void executeAction(int action)
/*     */   {
/* 289 */     this.textDisplay.getHighlighter().removeAllHighlights();
/* 290 */     switch (action) {
/*     */     case 73: 
/* 292 */       this.fileView.pasteLines(getInsertPos(true)); break;
/* 293 */     case 74:  this.fileView.pasteLines(getInsertPos(true) - 1); break;
/* 294 */     case 78:  deleteBtn(); break;
/* 295 */     case 77:  this.fileView.deleteLine(this.popupRow); break;
/*     */     case 31: 
/* 297 */       if (this.popupRow >= 0)
/* 298 */         this.fileView.repeatLine(this.popupRow);
/*     */       break;
/*     */     case 71: 
/* 301 */       insertLine(0, true); break;
/* 302 */     case 72:  insertLine(-1, true); break;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     default: 
/* 317 */       super.executeAction(action);
/*     */     }
/*     */   }
/*     */   
/*     */   private void deleteBtn() {
/* 322 */     int st = this.textDisplay.getSelectionStart();
/* 323 */     int en = this.textDisplay.getSelectionEnd();
/*     */     try
/*     */     {
/* 326 */       this.content.remove(st, Math.max(1, en - st));
/*     */     }
/*     */     catch (BadLocationException e) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void insertLine(int adj, boolean popup)
/*     */   {
/* 336 */     if (this.fileMaster.getTreeTableNotify() == null) {
/* 337 */       insertLine_101_FlatFile(adj, popup);
/*     */     } else {
/* 339 */       super.insertLine(adj);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isActionAvailable(int action)
/*     */   {
/* 348 */     switch (action) {
/*     */     case 31: 
/* 350 */       return true;
/*     */     }
/* 352 */     return super.isActionAvailable(action);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void insertUpdate(DocumentEvent e)
/*     */   {
/* 360 */     this.textDisplay.repaint();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeUpdate(DocumentEvent e)
/*     */   {
/* 368 */     this.textDisplay.repaint();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void changedUpdate(DocumentEvent e) {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractFileDisplay createChildScreen(int pos)
/*     */   {
/* 393 */     this.childFrame = new LineFrame("ChildRecord:", this.fileView, Math.max(0, getCurrRow()), false);
/* 394 */     this.textDisplay.removeKeyListener(this.rowChangeListner);
/* 395 */     this.textDisplay.addKeyListener(this.rowChangeListner);
/* 396 */     return this.childFrame;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractFileDisplay getChildScreen()
/*     */   {
/* 406 */     return this.childFrame;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeChildScreen()
/*     */   {
/* 416 */     if (this.childFrame != null) {
/* 417 */       this.childFrame.doClose();
/*     */     }
/* 419 */     this.childFrame = null;
/* 420 */     this.textDisplay.removeKeyListener(this.rowChangeListner);
/* 421 */     this.lastRow = -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void checkForTblRowChange(int row)
/*     */   {
/* 430 */     if (this.lastRow != row) {
/* 431 */       if (this.childFrame != null) {
/* 432 */         this.childFrame.setCurrRow(row);
/*     */       }
/*     */       
/* 435 */       this.lastRow = row;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/DocumentScreen.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */