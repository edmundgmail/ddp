/*     */ package net.sf.RecordEditor.edit.display;
/*     */ 
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplayWithFieldHide;
/*     */ import net.sf.RecordEditor.re.display.DisplayBuilderFactory;
/*     */ import net.sf.RecordEditor.re.display.IDisplayBuilder;
/*     */ import net.sf.RecordEditor.re.display.IDisplayFrame;
/*     */ import net.sf.RecordEditor.re.file.AbstractLineNode;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.re.tree.AbstractLineNodeTreeParser;
/*     */ import net.sf.RecordEditor.re.tree.LineNodeChild;
/*     */ import net.sf.RecordEditor.re.tree.TreeParserXml;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.params.BoolOpt;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DisplayBuilderImp
/*     */   implements IDisplayBuilder
/*     */ {
/*     */   public static AbstractFileDisplayWithFieldHide doOpen(FileView file, int initialRow, boolean pBrowse)
/*     */   {
/*  29 */     AbstractFileDisplayWithFieldHide display = null;
/*  30 */     AbstractLayoutDetails layoutDtls = file.getLayout();
/*     */     
/*     */ 
/*  33 */     if (layoutDtls.hasChildren()) {
/*  34 */       LineTreeChild displ = new LineTreeChild(file, new LineNodeChild("File", file), true, 0);
/*  35 */       new DisplayFrame(displ);
/*  36 */       display = displ;
/*     */       
/*  38 */       if ((file.getRowCount() == 0) && (!pBrowse)) {
/*  39 */         display.insertLine(0);
/*     */       }
/*  41 */     } else if (layoutDtls.isXml()) {
/*  42 */       LineTree displ1 = new LineTree(file, TreeParserXml.getInstance(), true, 1);
/*  43 */       display = displ1;
/*  44 */       new DisplayFrame(displ1);
/*     */     } else {
/*  46 */       LineList displ2 = LineList.newLineList(layoutDtls, file, file);
/*  47 */       display = displ2;
/*  48 */       display.setCurrRow(initialRow, -1, -1);
/*  49 */       new DisplayFrame(displ2);
/*     */       
/*  51 */       if ((file.getRowCount() == 0) && (!pBrowse)) {
/*  52 */         display.insertLine(0);
/*     */       }
/*     */     }
/*     */     
/*  56 */     return display;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractFileDisplayWithFieldHide newDisplay(int screenType, String screenName, IDisplayFrame<? extends AbstractFileDisplay> parentFrame, AbstractLayoutDetails group, FileView viewOfFile, int lineNo)
/*     */   {
/*  68 */     switch (screenType) {
/*     */     case 1: 
/*     */     case 2: 
/*  71 */       return doOpen(viewOfFile, lineNo, screenType == 2);
/*     */     case 3: 
/*  73 */       return (AbstractFileDisplayWithFieldHide)addToScreen(parentFrame, LineList.newLineList(group, viewOfFile, viewOfFile.getBaseFile()));
/*     */     
/*     */ 
/*     */ 
/*     */     case 4: 
/*  78 */       return (AbstractFileDisplayWithFieldHide)addToScreen(parentFrame, new LineFrame(screenName, viewOfFile, lineNo, true));
/*     */     
/*     */ 
/*     */ 
/*     */     case 5: 
/*  83 */       return (AbstractFileDisplayWithFieldHide)addToScreen(parentFrame, new LineFrameTree(viewOfFile, lineNo, true));
/*     */     
/*     */ 
/*     */ 
/*     */     case 7: 
/*  88 */       return (AbstractFileDisplayWithFieldHide)addToScreen(parentFrame, new LinesAsColumns(viewOfFile));
/*     */     
/*     */ 
/*     */ 
/*     */     case 10: 
/*     */     case 11: 
/*  94 */       addToScreen(parentFrame, new DocumentScreen(viewOfFile, screenType == 11));
/*     */     }
/*     */     
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 101 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractFileDisplayWithFieldHide newDisplay(int screenType, String screenName, IDisplayFrame<? extends AbstractFileDisplay> parentFrame, AbstractLayoutDetails group, FileView viewOfFile, AbstractLine line)
/*     */   {
/* 114 */     switch (screenType) {
/*     */     case 3: 
/* 116 */       return (AbstractFileDisplayWithFieldHide)addToScreen(parentFrame, LineList.newLineList(screenName, group, viewOfFile, viewOfFile.getBaseFile()));
/*     */     
/*     */ 
/*     */ 
/*     */     case 4: 
/* 121 */       String s = screenName;
/* 122 */       if ((screenName == null) || ("".equals(screenName))) {
/* 123 */         s = "Record:";
/*     */       }
/* 125 */       return (AbstractFileDisplayWithFieldHide)addToScreen(parentFrame, new LineFrame(s, viewOfFile, line, true));
/*     */     
/*     */ 
/*     */ 
/*     */     case 5: 
/* 130 */       return (AbstractFileDisplayWithFieldHide)addToScreen(parentFrame, new LineFrameTree(viewOfFile, line, true));
/*     */     case 7: 
/*     */       LinesAsColumns displ;
/*     */       
/*     */       LinesAsColumns displ;
/*     */       
/* 136 */       if ((screenName == null) || ("".equals(screenName))) {
/* 137 */         displ = new LinesAsColumns(viewOfFile);
/*     */       } else {
/* 139 */         displ = new LinesAsColumns(screenName, viewOfFile);
/*     */       }
/* 141 */       return (AbstractFileDisplayWithFieldHide)addToScreen(parentFrame, displ);
/*     */     
/*     */ 
/*     */ 
/*     */     case 10: 
/*     */     case 11: 
/* 147 */       addToScreen(parentFrame, new DocumentScreen(viewOfFile, screenType == 11));
/*     */     }
/*     */     
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 154 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractFileDisplayWithFieldHide newDisplay(int screenType, IDisplayFrame<? extends AbstractFileDisplay> parentFrame, AbstractLayoutDetails group, FileView viewOfFile, AbstractLineNodeTreeParser treeParser, boolean mainView, int columnsToSkip)
/*     */   {
/* 166 */     switch (screenType) {
/*     */     case 3: 
/* 168 */       return (AbstractFileDisplayWithFieldHide)addToScreen(parentFrame, new LineTree(viewOfFile, treeParser, mainView, columnsToSkip));
/*     */     
/*     */ 
/*     */ 
/*     */     case 6: 
/* 173 */       LineTree t = new LineTree(viewOfFile, treeParser, mainView, columnsToSkip);
/* 174 */       addToScreen(parentFrame, t);
/* 175 */       t.cb2xmlStuff();
/*     */       
/* 177 */       return t;
/*     */     }
/*     */     
/*     */     
/* 181 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public LineTreeChild newLineTreeChildScreen(int screenType, IDisplayFrame df, FileView viewOfFile, AbstractLineNode rootNode, boolean mainView, int columnsToSkip)
/*     */   {
/* 190 */     LineTreeChild ret = (LineTreeChild)addToScreen(df, new LineTreeChild(viewOfFile, rootNode, mainView, columnsToSkip));
/*     */     
/* 192 */     if (screenType == 9) {
/* 193 */       ret.expandTree("FieldDescriptorProto");
/*     */     }
/* 195 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */   public static final <X extends BaseDisplay> X addToScreen(IDisplayFrame df, X d)
/*     */   {
/* 201 */     if ((Common.OPTIONS.useSeperateScreens.isSelected()) || (df == null)) {
/* 202 */       new DisplayFrame(d);
/*     */     } else {
/* 204 */       df.addScreen(d);
/*     */     }
/* 206 */     return d;
/*     */   }
/*     */   
/*     */   public static void register() {
/* 210 */     DisplayBuilderFactory.register(new DisplayBuilderImp());
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/DisplayBuilderImp.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */