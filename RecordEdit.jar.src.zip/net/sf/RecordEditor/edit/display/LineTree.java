/*     */ package net.sf.RecordEditor.edit.display;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTree;
/*     */ import javax.swing.event.TableModelEvent;
/*     */ import javax.swing.tree.TreePath;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.RecordEditor.re.file.AbstractLineNode;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.re.tree.AbstractLineNodeTreeParser;
/*     */ import net.sf.RecordEditor.re.tree.LineNode;
/*     */ import net.sf.RecordEditor.utils.lang.ReAbstractAction;
/*     */ import net.sf.RecordEditor.utils.swing.LayoutCombo;
/*     */ import net.sf.RecordEditor.utils.swing.treeTable.JTreeTable;
/*     */ import net.sf.RecordEditor.utils.swing.treeTable.TreeTableModelAdapter;
/*     */ 
/*     */ public class LineTree extends BaseLineTree<LineNode>
/*     */ {
/*     */   private static final String NO_DESTINATION_LINE = "No Destination line";
/*     */   private AbstractLineNodeTreeParser parser;
/*     */   
/*     */   protected LineTree(FileView viewOfFile, AbstractLineNodeTreeParser treeParser, boolean mainView, int columnsToSkip)
/*     */   {
/*  33 */     super(viewOfFile, mainView, false, columnsToSkip, 1);
/*     */     
/*  35 */     this.parser = treeParser;
/*  36 */     this.root = this.parser.parse(this.view);
/*     */     
/*     */ 
/*  39 */     AbstractAction[] extraActions = { new ReAbstractAction("Rebuild Tree")
/*     */     
/*     */ 
/*  42 */       new ReAbstractAction
/*     */       {
/*     */ 
/*  42 */         public void actionPerformed(ActionEvent e) { LineTree.this.rebuildNode((LineNode)LineTree.this.getNodeForRow(LineTree.this.popupRow)); } }, new ReAbstractAction("Print Line Details")
/*     */       {
/*     */ 
/*     */         public void actionPerformed(ActionEvent e)
/*     */         {
/*  47 */           int[] selected = LineTree.this.treeTable.getSelectedRows();
/*     */           
/*     */ 
/*  50 */           for (int i = 0; i < selected.length; i++) {
/*  51 */             LineTree.this.getNodeForRow(selected[i]);
/*     */ 
/*     */ 
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*  62 */       } };
/*  63 */     init_100_setupScreenFields(extraActions);
/*     */     
/*  65 */     init_200_LayoutScreen();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setScreenSize(boolean mainframe)
/*     */   {
/*  72 */     DisplayFrame parentFrame = getParentFrame();
/*  73 */     parentFrame.bldScreen();
/*     */     
/*  75 */     parentFrame.setBounds(1, 1, this.screenSize.width - 1, this.screenSize.height - 1);
/*     */     
/*     */ 
/*     */ 
/*  79 */     parentFrame.setToMaximum(true);
/*  80 */     parentFrame.setVisible(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void executeAction(int action)
/*     */   {
/*  89 */     if (action == 37) {
/*  90 */       ((LineNode)this.root).removeAllChildren();
/*  91 */       this.parser.parseAppend(this.view, (LineNode)this.root);
/*  92 */       this.tableModel.fireTableStructureChanged();
/*  93 */       defColumns(getLayoutIndex());
/*  94 */     } else if (action == 31) {
/*  95 */       getFileView().repeatLine(((LineNode)getNodeForRow(this.popupRow)).getLineNumber());
/*  96 */     } else if (action == 39) {
/*  97 */       ((LineNode)this.root).removeAllChildren();
/*  98 */       rebuildNode((LineNode)this.root);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/* 104 */     else if (action == 44) {
/* 105 */       JFileChooser chooseFile = new JFileChooser();
/* 106 */       chooseFile.setSelectedFile(new File(this.view.getFileName() + ".xml"));
/*     */       
/* 108 */       int ret = chooseFile.showOpenDialog(null);
/*     */       
/* 110 */       if (ret == 0) {
/* 111 */         if (this.view.getLayout().isXml()) {
/*     */           try {
/* 113 */             this.view.getBaseFile().writeFile(chooseFile.getSelectedFile().getPath());
/*     */           } catch (Exception e) {
/* 115 */             e.printStackTrace();
/*     */           }
/*     */         } else {
/* 118 */           new net.sf.RecordEditor.re.tree.TreeToXml(chooseFile.getSelectedFile().getPath(), this.root);
/*     */         }
/*     */       }
/*     */     } else {
/* 122 */       super.executeAction(action);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isActionAvailable(int action)
/*     */   {
/* 132 */     return (action == 37) || (action == 31) || (action == 39) || (action == 44) || (super.isActionAvailable(action));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int getLayoutIdx_100_getLayout4Row(int row)
/*     */   {
/* 147 */     int ret = -1;
/* 148 */     AbstractLineNode node = getNodeForRow(row);
/*     */     
/* 150 */     if ((node != null) && (node.getLine() != null)) {
/* 151 */       ret = node.getLine().getPreferredLayoutIdx();
/*     */     }
/*     */     
/* 154 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCurrRow(int newRow, int layoutId, int fieldNum)
/*     */   {
/* 166 */     LineNode node = findNode4LineNumber((LineNode)this.root, newRow);
/*     */     
/*     */ 
/* 169 */     if ((node != null) && (fieldNum >= 0))
/*     */     {
/* 171 */       int fNo = super.getAdjColumn(layoutId, fieldNum);
/* 172 */       TreePath path = new TreePath(node.getPath());
/*     */       
/* 174 */       this.treeTable.getTree().makeVisible(path);
/* 175 */       int row = this.treeTable.getTree().getRowForPath(path);
/*     */       try
/*     */       {
/* 178 */         if (getCurrRow() != newRow) {
/* 179 */           this.tblDetails.changeSelection(row, fNo, false, false);
/*     */         }
/*     */         
/* 182 */         this.treeTable.editCellAt(row, fNo);
/*     */       }
/*     */       catch (Exception e) {}
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 189 */     if (newRow >= 0) {
/* 190 */       checkForRowChange(newRow);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCurrRow()
/*     */   {
/* 200 */     return convertRow(getTreeTblRow());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int getPopupPosition()
/*     */   {
/* 208 */     return convertRow(this.popupRow);
/*     */   }
/*     */   
/*     */   private int convertRow(int row) {
/* 212 */     if (row >= 0) {
/* 213 */       LineNode node = (LineNode)getNodeForRow(row);
/*     */       
/*     */ 
/*     */ 
/* 217 */       return node.getLineNumber();
/*     */     }
/*     */     
/*     */ 
/* 221 */     return -1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int[] getSelectedRows()
/*     */   {
/* 230 */     int[] selected = this.treeTable.getSelectedRows();
/*     */     
/*     */ 
/* 233 */     if ((selected == null) || (selected.length == 0)) {
/* 234 */       return selected;
/*     */     }
/*     */     
/* 237 */     ArrayList<Integer> list = new ArrayList();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 243 */     for (int i = 0; i < selected.length; i++) {
/* 244 */       TreePath treePath = this.treeTable.getPathForRow(selected[i]);
/* 245 */       LineNode node = (LineNode)treePath.getLastPathComponent();
/*     */       
/* 247 */       if (node.getLineNumber() >= 0) {
/* 248 */         list.add(Integer.valueOf(node.getLineNumber()));
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 253 */       if ((!node.isLeaf()) && (!this.treeTable.getTree().isExpanded(treePath))) {
/* 254 */         int end = node.getLastLeafLine();
/*     */         
/* 256 */         for (int j = node.getFirstLeafLine(); j <= end; j++) {
/* 257 */           list.add(Integer.valueOf(j));
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 263 */     int[] ret = new int[list.size()];
/* 264 */     for (i = 0; i < ret.length; i++) {
/* 265 */       ret[i] = ((Integer)list.get(i)).intValue();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 270 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int getInsertAfterPosition()
/*     */   {
/* 282 */     int row = getTreeTblRow();
/*     */     
/*     */ 
/* 285 */     if (row < 0) {
/* 286 */       throw new RuntimeException("No Destination line");
/*     */     }
/*     */     
/* 289 */     TreePath treePath = this.treeTable.getPathForRow(row);
/* 290 */     LineNode node = (LineNode)treePath.getLastPathComponent();
/*     */     int lineNum;
/*     */     int lineNum;
/* 293 */     if ((node.isLeaf()) || (this.treeTable.getTree().isExpanded(treePath))) {
/* 294 */       lineNum = node.getFirstLeafLine() - 1;
/*     */     } else {
/* 296 */       lineNum = node.getLastLeafLine();
/*     */     }
/*     */     
/* 299 */     return lineNum;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int getInsertBeforePosition()
/*     */   {
/* 308 */     int row = getTreeTblRow();
/*     */     
/*     */ 
/* 311 */     if (row < 0) {
/* 312 */       throw new RuntimeException("No Destination line");
/*     */     }
/*     */     
/* 315 */     TreePath treePath = this.treeTable.getPathForRow(row);
/* 316 */     LineNode node = (LineNode)treePath.getLastPathComponent();
/*     */     
/*     */ 
/* 319 */     int ret = node.getLineNumber();
/*     */     
/* 321 */     if (ret < 0) {
/* 322 */       ret = node.getFirstLeafLine();
/*     */     }
/*     */     
/* 325 */     return Math.max(-1, ret - 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void tableChanged(TableModelEvent event)
/*     */   {
/* 332 */     int lastRowChanged = event.getLastRow();
/* 333 */     int firstRowChanged = event.getFirstRow();
/*     */     
/*     */ 
/* 336 */     switch (event.getType()) {
/*     */     case 1: 
/* 338 */       tableChanged_100_insertLines(firstRowChanged, lastRowChanged);
/* 339 */       checkForResize(event);
/* 340 */       break;
/*     */     case -1: 
/* 342 */       tableChanged_200_deletedLines(firstRowChanged, lastRowChanged);
/* 343 */       break;
/*     */     case 0: 
/* 345 */       LineNode n = findNode4LineNumber((LineNode)this.root, firstRowChanged);
/*     */       
/*     */       AbstractLine l;
/* 348 */       if ((n == null) || (((l = n.getLine()) != null) && (l.isError())) || ((n.getLineNumber() != firstRowChanged) && (tableChanged_300_isNotEnd(n.getLine()))))
/*     */       {
/*     */ 
/* 351 */         tableChanged_400_Update(firstRowChanged);
/*     */       }
/* 353 */       checkForResize(event);
/* 354 */       break;
/*     */     }
/*     */     
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 365 */     if (super.hasTheFormatChanged(event)) {
/* 366 */       this.tableModel.fireTableStructureChanged();
/* 367 */       defColumns(getLayoutIndex());
/*     */     } else {
/* 369 */       this.tableModel.fireTableDataChanged();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void tableChanged_100_insertLines(int start, int end)
/*     */   {
/* 380 */     LineNode node = findNode4LineNumber((LineNode)this.root, start - 1);
/*     */     
/* 382 */     int diff = end - start + 1;
/*     */     
/* 384 */     if (node == null) {
/* 385 */       node = (LineNode)this.root;
/*     */     }
/*     */     
/* 388 */     while ((node != null) && (node.getLineNumber() < start - 2)) {
/* 389 */       node = (LineNode)node.getNextNode();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 396 */     LineNode parent = getParent(node, end + 1);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 403 */     updateLineNumber(start, diff);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 410 */     parseLater(parent);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void tableChanged_200_deletedLines(int start, int end)
/*     */   {
/* 421 */     LineNode node = findNode4LineNumber((LineNode)this.root, start);
/* 422 */     int diff = end - start + 1;
/*     */     
/*     */ 
/*     */ 
/* 426 */     if (node == null) {
/* 427 */       node = (LineNode)this.root;
/*     */     }
/*     */     
/*     */ 
/* 431 */     while ((node != null) && (node.getLineNumber() < start)) {
/* 432 */       node = (LineNode)node.getNextNode();
/*     */     }
/* 434 */     LineNode parent = getParent(node, end + 1);
/* 435 */     while ((node != null) && (node.getLineNumber() <= end)) {
/* 436 */       LineNode temp = node;
/* 437 */       LineNode p = (LineNode)node.getParent();
/* 438 */       node = (LineNode)node.getNextNode();
/* 439 */       if (p != null) {
/* 440 */         System.out.println("Deleting node - " + temp.getLineNumber() + " " + temp.getFirstLeafLine() + " " + temp.getLastLeafLine());
/*     */         
/* 442 */         p.remove(temp);
/*     */       }
/*     */     }
/*     */     
/* 446 */     updateLineNumber(end, -diff);
/*     */     
/* 448 */     parseLater(parent);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private boolean tableChanged_300_isNotEnd(AbstractLine l)
/*     */   {
/* 457 */     Object o = l.getField(l.getPreferredLayoutIdx(), 0);
/* 458 */     String s = "";
/* 459 */     if (o != null) {
/* 460 */       s = o.toString();
/*     */     }
/* 462 */     return (!l.getLayout().isXml()) || (!s.startsWith("/"));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void tableChanged_400_Update(int start)
/*     */   {
/* 471 */     LineNode node = findNode4LineNumber((LineNode)this.root, start);
/*     */     
/* 473 */     if (node == null) {
/* 474 */       node = (LineNode)this.root;
/*     */     }
/*     */     
/* 477 */     while ((node != null) && (node.getLineNumber() < start)) {
/* 478 */       node = (LineNode)node.getNextNode();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 483 */     rebuildNode(getParent(node, start + 1));
/*     */   }
/*     */   
/*     */   private void parseLater(LineNode parent)
/*     */   {
/* 488 */     javax.swing.SwingUtilities.invokeLater(new RebuildLater(parent));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void updateLineNumber(int start, int difference)
/*     */   {
/* 498 */     LineNode node = (LineNode)this.root;
/*     */     
/* 500 */     while (node != null) {
/* 501 */       node.adjustLineNumbers(start, difference);
/* 502 */       node = (LineNode)node.getNextNode();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void rebuildNode(LineNode node)
/*     */   {
/* 513 */     if (node != null) {
/* 514 */       int start = node.getFirstLeafLine();
/* 515 */       int end = node.getLastLeafLine();
/*     */       
/* 517 */       if (node.getLevel() == 0) {
/* 518 */         start = 0;
/* 519 */         end = this.view.getRowCount();
/*     */       }
/*     */       
/* 522 */       this.parser.parseAppend(this.view, node, start, end);
/*     */       
/*     */ 
/* 525 */       int[] childIdx = new int[node.getChildCount()];
/* 526 */       Object[] children = new Object[node.getChildCount()];
/* 527 */       for (int j = 0; j < node.getChildCount(); j++) {
/* 528 */         childIdx[j] = j;
/* 529 */         children[j] = node.getChildAt(j);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 534 */       this.treeTable.getTree().expandPath(new TreePath(node.getPath()));
/* 535 */       this.model.fireTreeStructureChanged(node, node.getPath(), childIdx, children);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private LineNode findNode4LineNumber(LineNode node, int lineNumber)
/*     */   {
/* 552 */     LineNode child = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 557 */     if (!node.isLeaf())
/*     */     {
/* 559 */       int i = 0;
/* 560 */       while ((i < node.getChildCount()) && ((child = (LineNode)node.getChildAt(i)).getLastLeafLine() < lineNumber)) { i++;
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 567 */       if ((child != null) && (child.getLineNumber() < lineNumber) && (!child.isLeaf())) {
/* 568 */         child = findNode4LineNumber(child, lineNumber);
/*     */       }
/*     */     }
/* 571 */     return child;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private LineNode getParent(LineNode node, int lastLineNum)
/*     */   {
/*     */     LineNode parent;
/*     */     
/*     */ 
/*     */     LineNode parent;
/*     */     
/* 583 */     if ((node == null) || (node == this.root)) {
/* 584 */       parent = (LineNode)this.root;
/*     */     } else {
/* 586 */       parent = (LineNode)node.getParent();
/* 587 */       if (parent != null) {
/* 588 */         int end = Math.min(lastLineNum, this.fileView.getRowCount());
/*     */         
/*     */ 
/* 591 */         while ((parent.getLastLeafLine() < end) && (parent.getParent() != null))
/*     */         {
/* 593 */           parent = (LineNode)parent.getParent();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 599 */     return parent;
/*     */   }
/*     */   
/*     */ 
/*     */   public void cb2xmlStuff()
/*     */   {
/* 605 */     doFullExpansion(this.root);
/* 606 */     getLayoutCombo().setSelectedItem("item");
/*     */     
/* 608 */     int idx = getLayoutCombo().getSelectedIndex();
/* 609 */     boolean[] fields = super.getFieldVisibility(idx);
/* 610 */     AbstractRecordDetail rec = this.layout.getRecord(idx);
/*     */     
/* 612 */     for (int i = 1; i < fields.length; i++) {
/* 613 */       String s = rec.getField(this.layout.getAdjFieldNumber(idx, i)).getName();
/* 614 */       if ((s.indexOf('~') > 0) || (s.equals("numeric"))) {
/* 615 */         fields[i] = false;
/*     */       }
/*     */     }
/*     */     
/* 619 */     super.setFieldVisibility(idx, fields);
/* 620 */     super.setCopyHiddenFields(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected BaseDisplay getNewDisplay(FileView view)
/*     */   {
/* 631 */     return new LineTree(view, this.parser, false, this.cols2skip);
/*     */   }
/*     */   
/*     */ 
/*     */   private class RebuildLater
/*     */     implements Runnable
/*     */   {
/*     */     private final LineNode parent;
/*     */     
/*     */     public RebuildLater(LineNode rebuildFrom)
/*     */     {
/* 642 */       this.parent = rebuildFrom;
/*     */     }
/*     */     
/*     */     public void run()
/*     */     {
/* 647 */       LineTree.this.rebuildNode(this.parent);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public net.sf.RecordEditor.re.display.AbstractFileDisplay createChildScreen(int pos)
/*     */   {
/* 657 */     LineFrame f = new LineFrame("ChildRecord:", this.fileView, Math.max(0, getCurrRow()), false);
/*     */     
/* 659 */     setChildScreen(f);
/*     */     
/* 661 */     return f;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/LineTree.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */