/*    */ package net.sf.RecordEditor.edit.display.util;
/*    */ 
/*    */ import java.awt.Dimension;
/*    */ import javax.swing.Icon;
/*    */ import javax.swing.JButton;
/*    */ import javax.swing.JPanel;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ import net.sf.RecordEditor.utils.common.ReActionHandler;
/*    */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*    */ import net.sf.RecordEditor.utils.screenManager.ReAction;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class OptionPnl
/*    */   extends JPanel
/*    */ {
/*    */   public static final int BROWSE_PANEL = 1;
/*    */   public static final int EDIT_PANEL = 2;
/*    */   public static final int TREE_PANEL = 3;
/* 20 */   private static String[] hints = LangConversion.convertArray(11, "FileDisplayBtns", new String[] { "Find", "Filter", "Save", "Save As", "Copy", "Cut", "Paste", "Paste Prior", "New Record", "Set the length based on Current Layout", "Delete", "Help" });
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 25 */   private static int[] actionIds = { 7, 8, 1, 2, 24, 25, 26, 27, 28, 13, 29, 23 };
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   private JButton[] btn;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public OptionPnl(int option, ReActionHandler action)
/*    */   {
/* 37 */     int num = option == 1 ? 5 : hints.length - 1;
/*    */     
/*    */ 
/* 40 */     this.btn = new JButton[num];
/*    */     
/* 42 */     Icon searchIcon = Common.getRecordIcon(0);
/* 43 */     int iconHeight = searchIcon.getIconHeight() + 5;
/* 44 */     Dimension stdSize = new Dimension(iconHeight, searchIcon.getIconWidth() + 5);
/*    */     
/*    */ 
/* 47 */     for (int i = 0; i < num; i++) {
/* 48 */       if ((option != 1) || (i != 2)) {
/* 49 */         this.btn[i] = defineBtn(stdSize, i, action);
/*    */       }
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private JButton defineBtn(Dimension stdSize, int iconIdx, ReActionHandler action)
/*    */   {
/* 67 */     JButton button = new JButton(new ReAction("", "", Common.getRecordIcon(iconIdx), actionIds[iconIdx], action));
/*    */     
/* 69 */     button.setPreferredSize(stdSize);
/* 70 */     add(button);
/* 71 */     button.setToolTipText(hints[iconIdx]);
/*    */     
/* 73 */     return button;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/util/OptionPnl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */