/*    */ package net.sf.RecordEditor.edit.display.util;
/*    */ 
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.swing.JButton;
/*    */ import javax.swing.JTabbedPane;
/*    */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*    */ import net.sf.RecordEditor.edit.util.NewCsvFile;
/*    */ import net.sf.RecordEditor.re.display.DisplayBuilderFactory;
/*    */ import net.sf.RecordEditor.re.openFile.AbstractLayoutSelection;
/*    */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*    */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*    */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*    */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NewFile
/*    */ {
/* 21 */   private final ReFrame frame = new ReFrame("", "New Csv File", null);
/* 22 */   private JTabbedPane tab = new JTabbedPane();
/* 23 */   private JButton goBtn = SwingUtils.newButton("Create");
/*    */   
/*    */   private AbstractLayoutSelection layoutSelect;
/*    */   
/* 27 */   BaseHelpPanel panel = new BaseHelpPanel();
/*    */   
/*    */ 
/*    */   public NewFile(AbstractLayoutSelection layoutSelection)
/*    */   {
/* 32 */     this.layoutSelect = layoutSelection;
/*    */     
/* 34 */     init_100_Setup();
/* 35 */     init_200_LayoutScreen();
/* 36 */     init_300_Listners();
/*    */     
/* 38 */     this.frame.setVisible(true);
/* 39 */     this.frame.setToMaximum(false);
/*    */   }
/*    */   
/*    */ 
/*    */   private void init_100_Setup() {}
/*    */   
/*    */ 
/*    */   private void init_200_LayoutScreen()
/*    */   {
/* 48 */     BasePanel pnl = new BasePanel();
/*    */     
/* 50 */     NewCsvFile csvFile = new NewCsvFile(this.frame);
/*    */     
/* 52 */     this.panel.setGapRE(BasePanel.GAP2);
/*    */     
/* 54 */     this.layoutSelect.addLayoutSelection(this.panel, null, null, null, null);
/*    */     
/* 56 */     this.panel.setGapRE(BasePanel.GAP1);
/* 57 */     this.panel.addLineRE(null, null, this.goBtn);
/* 58 */     this.panel.setGapRE(BasePanel.GAP4);
/* 59 */     this.panel.addMessageRE();
/* 60 */     this.panel.setHeightRE(BasePanel.HEIGHT_1P6);
/*    */     
/* 62 */     SwingUtils.addTab(this.tab, "NewFileTab", "Normal File", this.panel);
/* 63 */     SwingUtils.addTab(this.tab, "NewFileTab", "Csv File", csvFile.panel);
/*    */     
/* 65 */     pnl.setGapRE(2.0D);
/* 66 */     pnl.addComponentRE(0, 6, -1.0D, 2.0D, 2, 2, this.tab);
/*    */     
/*    */ 
/*    */ 
/*    */ 
/* 71 */     this.frame.addMainComponent(pnl);
/* 72 */     this.frame.setSize(Math.min(this.frame.getWidth() + 80, ReFrame.getDesktopWidth() - 2), Math.min(this.frame.getHeight(), ReFrame.getDesktopHeight() - 2));
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 78 */     this.frame.setDefaultCloseOperation(2);
/*    */   }
/*    */   
/*    */ 
/*    */   private void init_300_Listners()
/*    */   {
/* 84 */     this.goBtn.addActionListener(new ActionListener()
/*    */     {
/*    */ 
/*    */       public void actionPerformed(ActionEvent e)
/*    */       {
/*    */ 
/*    */         try
/*    */         {
/* 92 */           AbstractLayoutDetails layout = NewFile.this.layoutSelect.getRecordLayout("");
/*    */           
/* 94 */           if (layout == null) {
/* 95 */             NewFile.this.panel.setMessageTxtRE("Error Retrieving Layout");
/*    */           } else {
/* 97 */             DisplayBuilderFactory.startEditorNewFile(layout);
/*    */             
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* :6 */             NewFile.this.frame.setVisible(false);
/* :7 */             NewFile.this.frame.doDefaultCloseAction();
/*    */           }
/*    */         } catch (Exception ex) {
/* ;0 */           NewFile.this.panel.setMessageTxtRE("Error Creating File: ", ex.getMessage());
/*    */         }
/*    */       }
/*    */     });
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/util/NewFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */