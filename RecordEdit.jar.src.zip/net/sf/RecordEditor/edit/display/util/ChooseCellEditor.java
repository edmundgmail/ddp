/*     */ package net.sf.RecordEditor.edit.display.util;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import javax.swing.AbstractCellEditor;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.event.CellEditorListener;
/*     */ import javax.swing.table.TableCellEditor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChooseCellEditor
/*     */   extends AbstractCellEditor
/*     */   implements TableCellEditor
/*     */ {
/*  22 */   private JTextField stdField = new JTextField();
/*  23 */   private int lastRow = -1;
/*     */   
/*     */ 
/*     */   private TableCellEditor[] cellEditors;
/*     */   
/*     */ 
/*     */   private JTable tblDetails;
/*     */   
/*     */ 
/*     */   public ChooseCellEditor(JTable tbl, TableCellEditor[] tableCellEditors)
/*     */   {
/*  34 */     this.stdField.setBorder(BorderFactory.createEmptyBorder());
/*     */     
/*  36 */     this.cellEditors = tableCellEditors;
/*  37 */     this.tblDetails = tbl;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getCellEditorValue()
/*     */   {
/*  45 */     int row = this.lastRow;
/*  46 */     if (row < 0) {
/*  47 */       row = this.tblDetails.getSelectedRow();
/*     */     }
/*     */     
/*  50 */     if ((row >= 0) && (this.cellEditors[row] != null))
/*     */     {
/*  52 */       return this.cellEditors[row].getCellEditorValue();
/*     */     }
/*     */     
/*  55 */     return this.stdField.getText();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addCellEditorListener(CellEditorListener l)
/*     */   {
/*  65 */     for (int row = 0; row < this.cellEditors.length; row++) {
/*  66 */       if (this.cellEditors[row] != null) {
/*  67 */         this.cellEditors[row].addCellEditorListener(l);
/*     */       }
/*     */     }
/*     */     
/*  71 */     super.addCellEditorListener(l);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeCellEditorListener(CellEditorListener l)
/*     */   {
/*  81 */     for (int row = 0; row < this.cellEditors.length; row++) {
/*  82 */       if (this.cellEditors[row] != null) {
/*  83 */         this.cellEditors[row].removeCellEditorListener(l);
/*     */       }
/*     */     }
/*     */     
/*  87 */     super.removeCellEditorListener(l);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void cancelCellEditing()
/*     */   {
/*  97 */     int row = this.tblDetails.getEditingRow();
/*  98 */     if ((row > 0) && (this.cellEditors[row] != null)) {
/*  99 */       this.cellEditors[row].cancelCellEditing();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 107 */     super.cancelCellEditing();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean stopCellEditing()
/*     */   {
/* 137 */     for (int row = 0; row < this.cellEditors.length; row++) {
/* 138 */       if (this.cellEditors[row] != null) {
/* 139 */         this.cellEditors[row].stopCellEditing();
/*     */       }
/*     */     }
/*     */     
/* 143 */     return super.stopCellEditing();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column)
/*     */   {
/* 154 */     this.lastRow = row;
/* 155 */     if (this.cellEditors[row] == null) {
/* 156 */       if (value == null) {
/* 157 */         this.stdField.setText("");
/*     */       } else {
/* 159 */         this.stdField.setText(value.toString());
/*     */       }
/*     */       
/* 162 */       return this.stdField;
/*     */     }
/*     */     
/* 165 */     return this.cellEditors[row].getTableCellEditorComponent(table, value, isSelected, row, column);
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/util/ChooseCellEditor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */