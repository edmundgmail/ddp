/*     */ package net.sf.RecordEditor.edit.display.util;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.DefaultCellEditor;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.event.TableModelEvent;
/*     */ import javax.swing.event.TableModelListener;
/*     */ import javax.swing.table.AbstractTableModel;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail.FieldDetails;
/*     */ import net.sf.RecordEditor.edit.display.common.AbstractFieldSequencePnl;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplayWithFieldHide;
/*     */ import net.sf.RecordEditor.re.display.ReChildFrame;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.CheckBoxTableRender;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ public class HideFields
/*     */   implements ActionListener
/*     */ {
/*  33 */   private static final String[] FIELD_COLUMN_HEADINGS = LangConversion.convertColHeading("Show/Hide Fields", new String[] { "Field", "Show" });
/*     */   
/*     */ 
/*     */   private static final int SHOW_INDEX = 1;
/*     */   
/*  38 */   private JTable fieldTbl = new JTable();
/*     */   
/*  40 */   private JButton checkAllFields = SwingUtils.newButton("Check Fields");
/*  41 */   private JButton uncheckAllFields = SwingUtils.newButton("Uncheck Fields");
/*     */   
/*  43 */   private JCheckBox saveColSeq = new JCheckBox("Save Column Sequence");
/*  44 */   private JButton goBtn = SwingUtils.newButton("Go");
/*     */   
/*     */   private AbstractFileDisplayWithFieldHide sourcePnl;
/*     */   
/*     */   private AbstractLayoutDetails layout;
/*     */   private int recordIndex;
/*     */   private FieldList fieldMdl;
/*     */   public final ReChildFrame frame;
/*  52 */   private TableModelListener listner = new TableModelListener()
/*     */   {
/*     */ 
/*     */ 
/*     */     public void tableChanged(TableModelEvent arg0)
/*     */     {
/*     */ 
/*  59 */       if (HideFields.this.layout != HideFields.this.sourcePnl.getFileView().getBaseFile().getLayout()) {
/*  60 */         HideFields.this.frame.setVisible(false);
/*  61 */         HideFields.this.sourcePnl.getFileView().removeTableModelListener(this);
/*     */       }
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public HideFields(AbstractFileDisplayWithFieldHide sourcePanel)
/*     */   {
/*  72 */     this.sourcePnl = sourcePanel;
/*  73 */     FileView view = this.sourcePnl.getFileView();
/*  74 */     this.layout = view.getLayout();
/*  75 */     this.recordIndex = this.sourcePnl.getLayoutIndex();
/*  76 */     this.frame = new ReChildFrame(this.sourcePnl, "Field Visibility");
/*     */     
/*  78 */     if ((this.recordIndex > this.layout.getRecordCount()) || (this.recordIndex < 0))
/*  79 */       return;
/*  80 */     if (this.recordIndex == this.layout.getRecordCount()) {
/*  81 */       this.recordIndex = view.getDefaultPreferredIndex();
/*     */     }
/*     */     
/*     */ 
/*  85 */     BaseHelpPanel pnl = new BaseHelpPanel();
/*  86 */     JPanel fieldOptionPanel = new JPanel();
/*  87 */     this.frame.addCloseOnEsc(pnl);
/*     */     
/*  89 */     this.saveColSeq.setSelected(false);
/*  90 */     this.fieldMdl = new FieldList(this.layout, this.recordIndex, this.sourcePnl.getFieldVisibility(this.recordIndex));
/*  91 */     this.fieldTbl.setModel(this.fieldMdl);
/*  92 */     fieldOptionPanel.add(this.uncheckAllFields);
/*  93 */     fieldOptionPanel.add(this.checkAllFields);
/*     */     
/*  95 */     pnl.addLineRE("", fieldOptionPanel);
/*  96 */     pnl.setHeightRE(BasePanel.NORMAL_HEIGHT * 2.0D);
/*     */     
/*  98 */     pnl.addComponentRE(1, 5, -1.0D, BasePanel.GAP1, 2, 2, this.fieldTbl);
/*     */     
/*     */ 
/*     */ 
/* 102 */     if ((sourcePanel instanceof AbstractFieldSequencePnl)) {
/* 103 */       pnl.setGapRE(BasePanel.GAP0);
/* 104 */       this.saveColSeq.setSelected(true);
/* 105 */       pnl.addLineRE("", this.saveColSeq);
/*     */     }
/*     */     
/* 108 */     pnl.setGapRE(BasePanel.GAP1);
/*     */     
/*     */ 
/* 111 */     JPanel p = new JPanel();
/*     */     try {
/* 113 */       p = SaveRestoreHiddenFields.getSaveLoadPnl(sourcePanel, this);
/*     */     }
/*     */     catch (NoClassDefFoundError nce) {}catch (Exception e) {}
/*     */     
/* 117 */     pnl.addLineRE("", p, this.goBtn);
/* 118 */     pnl.setHeightRE(BasePanel.GAP1 * 2.0D);
/*     */     
/* 120 */     this.frame.addMainComponent(pnl);
/* 121 */     this.frame.setDefaultCloseOperation(2);
/*     */     
/* 123 */     TableColumnModel tcm = this.fieldTbl.getColumnModel();
/* 124 */     TableColumn tc = tcm.getColumn(1);
/* 125 */     tc.setCellRenderer(new CheckBoxTableRender());
/* 126 */     tc.setCellEditor(new DefaultCellEditor(new JCheckBox()));
/*     */     
/* 128 */     this.uncheckAllFields.addActionListener(this);
/* 129 */     this.checkAllFields.addActionListener(this);
/* 130 */     this.goBtn.addActionListener(this);
/*     */     
/* 132 */     view.addTableModelListener(this.listner);
/*     */     
/* 134 */     this.frame.setVisible(true);
/* 135 */     this.frame.setToMaximum(false);
/*     */   }
/*     */   
/*     */   public boolean isSaveSeqSelected() {
/* 139 */     return this.saveColSeq.isSelected();
/*     */   }
/*     */   
/*     */   public boolean[] getVisibleFields() {
/* 143 */     return (boolean[])this.fieldMdl.include.clone();
/*     */   }
/*     */   
/*     */   public int getRecordIndex() {
/* 147 */     return this.recordIndex;
/*     */   }
/*     */   
/*     */   public void updateIncludes(boolean[] fields)
/*     */   {
/* 152 */     int len = Math.min(fields.length, this.fieldMdl.include.length);
/* 153 */     for (int i = 0; i < len; i++) {
/* 154 */       this.fieldMdl.include[i] = fields[i];
/*     */     }
/*     */     
/* 157 */     this.fieldMdl.fireTableDataChanged();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void actionPerformed(ActionEvent event)
/*     */   {
/* 166 */     Common.stopCellEditing(this.fieldTbl);
/*     */     
/* 168 */     if (event.getSource() == this.uncheckAllFields) {
/* 169 */       this.fieldMdl.updateIncludeFlag(false);
/* 170 */     } else if (event.getSource() == this.checkAllFields) {
/* 171 */       this.fieldMdl.updateIncludeFlag(true);
/* 172 */     } else if (event.getSource() == this.goBtn) {
/* 173 */       updateSourcePanel();
/*     */     }
/*     */   }
/*     */   
/*     */   public void updateSourcePanel()
/*     */   {
/* 179 */     applyFieldVisibilty();
/* 180 */     this.frame.setVisible(false);
/* 181 */     this.sourcePnl.getFileView().removeTableModelListener(this.listner);
/*     */   }
/*     */   
/*     */   public void applyFieldVisibilty()
/*     */   {
/* 186 */     this.sourcePnl.setFieldVisibility(this.recordIndex, this.fieldMdl.include);
/*     */   }
/*     */   
/*     */ 
/*     */   private static class FieldList
/*     */     extends AbstractTableModel
/*     */   {
/*     */     private AbstractLayoutDetails layout;
/*     */     
/*     */     private AbstractRecordDetail rec;
/*     */     
/*     */     public final boolean[] include;
/*     */     int recordIdx;
/*     */     
/*     */     public FieldList(AbstractLayoutDetails layoutDetails, int recordIndex, boolean[] showField)
/*     */     {
/* 202 */       this.layout = layoutDetails;
/* 203 */       this.recordIdx = recordIndex;
/* 204 */       this.rec = this.layout.getRecord(recordIndex);
/* 205 */       this.include = showField;
/*     */     }
/*     */     
/*     */     public void updateIncludeFlag(boolean newValue) {
/* 209 */       for (int i = 0; i < this.include.length; i++) {
/* 210 */         this.include[i] = newValue;
/*     */       }
/*     */       
/* 213 */       super.fireTableDataChanged();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public int getColumnCount()
/*     */     {
/* 220 */       return HideFields.FIELD_COLUMN_HEADINGS.length;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getColumnName(int columnIndex)
/*     */     {
/* 228 */       return HideFields.FIELD_COLUMN_HEADINGS[columnIndex];
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getRowCount()
/*     */     {
/* 237 */       if (this.rec == null) {
/* 238 */         return 0;
/*     */       }
/* 240 */       return this.rec.getFieldCount();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public Object getValueAt(int rowIndex, int columnIndex)
/*     */     {
/* 249 */       if (columnIndex == 1) {
/* 250 */         return Boolean.valueOf(this.include[rowIndex]);
/*     */       }
/* 252 */       return this.rec.getField(this.layout.getAdjFieldNumber(this.recordIdx, rowIndex)).getName();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isCellEditable(int rowIndex, int columnIndex)
/*     */     {
/* 260 */       return columnIndex == 1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setValueAt(Object aValue, int rowIndex, int columnIndex)
/*     */     {
/* 269 */       this.include[rowIndex] = ((aValue == null) || (aValue.getClass() != Boolean.class) || (((Boolean)aValue).booleanValue()) ? 1 : false);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/util/HideFields.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */