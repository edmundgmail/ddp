/*     */ package net.sf.RecordEditor.edit.display.util;
/*     */ 
/*     */ import javax.swing.table.AbstractTableModel;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.RecordEditor.re.tree.FieldSummaryDetails;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SortFieldSummaryMdl
/*     */   extends AbstractTableModel
/*     */ {
/*  41 */   private static final String[] COLUMN_NAMES = LangConversion.convertColHeading("SortSum Field Function", new String[] { "Field", "Function" });
/*     */   
/*     */ 
/*     */   private FieldSummaryDetails fieldSummary;
/*     */   
/*     */ 
/*  47 */   private int columnCount = 2;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SortFieldSummaryMdl(AbstractLayoutDetails recordLayout)
/*     */   {
/*  57 */     this.fieldSummary = new FieldSummaryDetails(recordLayout);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getColumnName(int column)
/*     */   {
/*  66 */     return COLUMN_NAMES[column];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isCellEditable(int rowIndex, int columnIndex)
/*     */   {
/*  73 */     return columnIndex > 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setValueAt(Object aValue, int rowIndex, int columnIndex)
/*     */   {
/*  80 */     if (rowIndex >= 0) {
/*  81 */       int val = 0;
/*     */       
/*  83 */       if ((aValue != null) && (!"".equals(aValue))) {
/*  84 */         String s = aValue.toString();
/*  85 */         for (int i = 0; i < FieldSummaryDetails.FOREIGN_OPERATOR_NAMES.length; i++) {
/*  86 */           if (FieldSummaryDetails.FOREIGN_OPERATOR_NAMES[i].equals(s)) {
/*  87 */             val = i;
/*  88 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*  93 */       this.fieldSummary.setOperator(rowIndex, val);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getColumnCount()
/*     */   {
/* 101 */     return this.columnCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRowCount()
/*     */   {
/* 117 */     return this.fieldSummary.getFieldCount();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public Object getValueAt(int rowIndex, int columnIndex)
/*     */   {
/* 125 */     if (columnIndex == 0) {
/* 126 */       return this.fieldSummary.getFieldName(rowIndex);
/*     */     }
/*     */     
/* 129 */     return FieldSummaryDetails.FOREIGN_OPERATOR_NAMES[this.fieldSummary.getOperator(rowIndex)];
/*     */   }
/*     */   
/*     */   public FieldSummaryDetails getFieldSummary()
/*     */   {
/* 134 */     return this.fieldSummary;
/*     */   }
/*     */   
/*     */   public int getRecordIndex()
/*     */   {
/* 139 */     return this.fieldSummary.getRecordIndex();
/*     */   }
/*     */   
/*     */   public void setRecordIndex(int layoutIndex)
/*     */   {
/* 144 */     this.fieldSummary.setRecordIndex(layoutIndex);
/*     */     
/* 146 */     fireTableDataChanged();
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/util/SortFieldSummaryMdl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */