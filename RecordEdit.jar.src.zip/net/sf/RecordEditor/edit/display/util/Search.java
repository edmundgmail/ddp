/*     */ package net.sf.RecordEditor.edit.display.util;
/*     */ 
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.beans.PropertyVetoException;
/*     */ import java.io.PrintStream;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextField;
/*     */ import net.sf.JRecord.Common.RecordException;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.RecordEditor.edit.display.common.ILayoutChanged;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*     */ import net.sf.RecordEditor.re.display.IChildDisplay;
/*     */ import net.sf.RecordEditor.re.file.FilePosition;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.re.file.filter.Compare;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.params.BoolOpt;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.LayoutCombo;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Search
/*     */   extends ReFrame
/*     */   implements ActionListener, ILayoutChanged, IChildDisplay
/*     */ {
/*  69 */   public static final boolean USE_SPECIAL_NAME_FIND_BTN = "Y".equalsIgnoreCase(Parameters.getString("useAltFindName"));
/*     */   
/*     */ 
/*  72 */   private static final String ALL_FIELDS = LangConversion.convertComboItms("Field List", "All Fields");
/*  73 */   private static final String FIND_ERROR = LangConversion.convert("Find error:");
/*  74 */   private static final String LINE_MSG = LangConversion.convert("Found (line, field Num, field position)=");
/*  75 */   private static final String YOU_MUST_SPECIFY_A_FIELD = LangConversion.convert("You must specify a specific field when using replace");
/*  76 */   private static final String CAN_NOT_USE_REPLACE_IN_BROWSE_MODE = LangConversion.convert("Can not use replace in browse mode");
/*  77 */   private static final String YOU_MUST_ENTER_TEXT_TO_SEARCH_FOR = LangConversion.convert("You must enter text to search for");
/*     */   
/*     */   private static final int SILLY_INT = -101;
/*  80 */   private static final String[] SEARCH_DIRECTIONS = LangConversion.convertComboItms("File Search Direction", new String[] { "Forward", "Backward" });
/*     */   
/*     */ 
/*     */ 
/*  84 */   private BaseHelpPanel pnl = new BaseHelpPanel("Find");
/*     */   
/*  86 */   private JTextField search = new JTextField();
/*  87 */   private JTextField replace = new JTextField();
/*     */   private LayoutCombo layoutList;
/*  89 */   private JComboBox fieldList = new JComboBox();
/*  90 */   private JComboBox fieldPart = new JComboBox(Compare.getSearchOptionsForeign());
/*  91 */   private JComboBox direction = new JComboBox(SEARCH_DIRECTIONS);
/*  92 */   private JCheckBox ignoreCase = new JCheckBox();
/*     */   private JButton searchBtn;
/*  94 */   private JButton replaceBtn = SwingUtils.newButton("Replace");
/*  95 */   private JButton replaceFindBtn = SwingUtils.newButton("Replace Find");
/*  96 */   private JButton replaceAllBtn = SwingUtils.newButton("Replace All");
/*     */   
/*  98 */   private JTextField msgTxt = new JTextField();
/*     */   
/*     */   private FilePosition pos;
/*     */   
/*     */   private AbstractFileDisplay source;
/*     */   
/*     */   private FileView file;
/*     */   
/* 106 */   private boolean firstTimeDisplayed = true;
/*     */   
/*     */ 
/*     */ 
/* 110 */   private KeyAdapter listner = new KeyAdapter()
/*     */   {
/*     */ 
/*     */     public final void keyPressed(KeyEvent event)
/*     */     {
/*     */ 
/* 116 */       switch (event.getKeyCode()) {
/* 117 */       case 10:  Search.this.ap_100_find(); break;
/* 118 */       case 27:  Search.this.doDefaultCloseAction();
/*     */       }
/*     */       
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Search(AbstractFileDisplay src, FileView master)
/*     */   {
/* 130 */     super(master.getFileNameNoDirectory(), "Find", master);
/*     */     
/*     */ 
/* 133 */     this.pos = new FilePosition(-101, 101, -101, -101, true, master.getRowCount());
/*     */     
/* 135 */     setTitle("Search Screen");
/*     */     
/*     */ 
/*     */ 
/* 139 */     this.pnl.addReKeyListener(this.listner);
/*     */     
/* 141 */     this.layoutList = new LayoutCombo(master.getLayout(), false, true);
/* 142 */     this.pnl.setHelpURLre(Common.formatHelpURL("HlpRe05.htm"));
/* 143 */     this.ignoreCase.setSelected(true);
/*     */     
/* 145 */     this.pnl.addLineRE("Search For", this.search);
/* 146 */     this.pnl.addLineRE("Replace With", this.replace);
/* 147 */     this.pnl.addLineRE("Record Layout", this.layoutList);
/* 148 */     this.pnl.addLineRE("Field", this.fieldList);
/* 149 */     this.pnl.addLineRE("Operator", this.fieldPart);
/* 150 */     this.pnl.addLineRE("Direction", this.direction);
/* 151 */     this.pnl.addLineRE("Ignore Case", this.ignoreCase);
/* 152 */     this.pnl.setGapRE(BasePanel.GAP1);
/*     */     
/*     */ 
/*     */ 
/* 156 */     String s = LangConversion.convert(8, "Find");
/*     */     
/* 158 */     if (USE_SPECIAL_NAME_FIND_BTN) {
/* 159 */       s = s + " >>";
/*     */     }
/* 161 */     this.searchBtn = new JButton(s, Common.getRecordIcon(0));
/*     */     
/*     */ 
/* 164 */     if (master.isBrowse()) {
/* 165 */       this.pnl.addLineRE("", this.searchBtn);
/*     */     } else {
/* 167 */       JPanel p = new JPanel();
/* 168 */       p.setLayout(new GridLayout(2, 2));
/* 169 */       p.add(this.searchBtn);
/* 170 */       p.add(this.replaceBtn);
/* 171 */       p.add(this.replaceFindBtn);
/* 172 */       p.add(this.replaceAllBtn);
/*     */       
/* 174 */       this.pnl.addLineRE("", p);
/* 175 */       this.pnl.setHeightRE(BasePanel.NORMAL_HEIGHT * 2.0D);
/* 176 */       this.replaceBtn.addActionListener(this);
/* 177 */       this.replaceFindBtn.addActionListener(this);
/* 178 */       this.replaceAllBtn.addActionListener(this);
/*     */     }
/* 180 */     this.pnl.setGapRE(BasePanel.GAP1);
/* 181 */     this.pnl.addMessage(this.msgTxt);
/*     */     
/*     */ 
/* 184 */     this.searchBtn.addActionListener(this);
/* 185 */     this.searchBtn.setToolTipText(LangConversion.convert(11, "Start Searching the file"));
/*     */     
/* 187 */     this.layoutList.addActionListener(this);
/*     */     
/* 189 */     this.source = src;
/*     */     
/* 191 */     addMainComponent(this.pnl);
/* 192 */     setDefaultCloseOperation(1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void startSearch(FileView iFile)
/*     */   {
/* 208 */     this.file = iFile;
/* 209 */     this.pos.setLineCount(iFile.getRowCount());
/*     */     
/* 211 */     loadFieldList();
/* 212 */     this.layoutList.setSelectedIndex(Math.min(this.source.getLayoutIndex(), this.layoutList.getItemCount() - 1));
/*     */     
/* 214 */     setVisible(true);
/* 215 */     toFront();
/* 216 */     if (this.firstTimeDisplayed) {
/* 217 */       setToMaximum(false);
/* 218 */       this.firstTimeDisplayed = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void actionPerformed(ActionEvent event)
/*     */   {
/* 229 */     String searchFor = this.search.getText();
/* 230 */     this.msgTxt.setText("");
/*     */     try {
/* 232 */       if (event.getSource() == this.layoutList) {
/* 233 */         loadFieldList();
/* 234 */       } else if ((searchFor == null) || ("".equals(searchFor))) {
/* 235 */         ap_920_setMessage(YOU_MUST_ENTER_TEXT_TO_SEARCH_FOR);
/* 236 */       } else if (event.getSource() == this.searchBtn) {
/* 237 */         ap_100_find();
/* 238 */       } else if (this.file.isBrowse()) {
/* 239 */         ap_920_setMessage(CAN_NOT_USE_REPLACE_IN_BROWSE_MODE);
/* 240 */       } else if (this.fieldList.getSelectedIndex() == 0) {
/* 241 */         ap_920_setMessage(YOU_MUST_SPECIFY_A_FIELD);
/* 242 */       } else if (event.getSource() == this.replaceBtn) {
/* 243 */         ap_300_replace();
/* 244 */       } else if (event.getSource() == this.replaceFindBtn) {
/* 245 */         ap_200_ReplaceFind();
/* 246 */       } else if (event.getSource() == this.replaceAllBtn) {
/* 247 */         int func = this.fieldPart.getSelectedIndex();
/* 248 */         ap_910_setPosition();
/* 249 */         this.file.replaceAll(searchFor, this.replace.getText(), this.pos, this.ignoreCase.isSelected(), func);
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 256 */         this.file.fireTableDataChanged();
/*     */       }
/*     */     } catch (Exception e) {
/* 259 */       e.printStackTrace();
/* 260 */       ap_920_setMessage(e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */   public void setClosed(boolean b)
/*     */     throws PropertyVetoException
/*     */   {
/* 267 */     this.source = null;
/* 268 */     super.setClosed(b);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final void ap_100_find()
/*     */   {
/* 277 */     String searchFor = this.search.getText();
/* 278 */     int func = this.fieldPart.getSelectedIndex();
/*     */     
/*     */ 
/*     */ 
/* 282 */     ap_910_setPosition();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 289 */     ap_930_runFind(searchFor, func);
/*     */     
/*     */ 
/* 292 */     if (ReFrame.getActiveFrame() != this) {
/* 293 */       setActiveFrame(this);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final void ap_200_ReplaceFind()
/*     */     throws RecordException
/*     */   {
/* 306 */     int func = this.fieldPart.getSelectedIndex();
/* 307 */     String searchFor = this.search.getText();
/* 308 */     ap_300_replace();
/* 309 */     this.pos.adjustPosition(searchFor.length(), func);
/*     */     
/*     */ 
/*     */ 
/* 313 */     ap_930_runFind(searchFor, func);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final void ap_300_replace()
/*     */     throws RecordException
/*     */   {
/* 334 */     ap_910_setPosition();
/* 335 */     int func = this.fieldPart.getSelectedIndex();
/*     */     
/* 337 */     this.file.replace(this.search.getText(), this.replace.getText(), this.pos, this.ignoreCase.isSelected(), func, true);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 345 */     if (this.pos.row >= 0) {
/* 346 */       this.source.setCurrRow(this.pos);
/* 347 */       this.file.fireTableRowsUpdated(this.pos.row, this.pos.row);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final void ap_910_setPosition()
/*     */   {
/* 357 */     boolean forward = this.direction.getSelectedIndex() == 0;
/*     */     
/* 359 */     int fieldId = this.fieldList.getSelectedIndex() - 2;
/* 360 */     if ((fieldId == -2) && (this.file.getLayout().isXml())) {
/* 361 */       fieldId = -1;
/*     */     }
/*     */     
/* 364 */     int row = this.source.getCurrRow();
/*     */     
/* 366 */     this.source.stopCellEditing();
/*     */     
/* 368 */     this.pos.currentLine = this.source.getTreeLine();
/*     */     
/* 370 */     if ((this.pos.row >= 0) && ((row < 0) || (this.pos.row == row))) {
/* 371 */       this.pos.setForward(forward);
/* 372 */       this.pos.setFieldId(fieldId);
/* 373 */       this.pos.recordId = this.layoutList.getSelectedIndex();
/* 374 */       this.pos.setLineCount(this.file.getRowCount());
/*     */     }
/* 376 */     else if (this.pos.row == row) {
/* 377 */       this.pos.setAll(Math.max(0, row), Math.max(0, this.pos.col), this.layoutList.getSelectedIndex(), fieldId, forward, this.file.getRowCount());
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/*     */ 
/* 383 */       System.out.println();
/* 384 */       System.out.println("==== " + "    00".indexOf("00", 1));
/* 385 */       this.pos.setAll(Math.max(0, row), 0, this.layoutList.getSelectedIndex(), fieldId, forward, this.file.getRowCount());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final void ap_920_setMessage(String message)
/*     */   {
/* 401 */     this.msgTxt.setText(message);
/* 402 */     Common.logMsgRaw(FIND_ERROR + " " + message, null);
/*     */   }
/*     */   
/*     */ 
/*     */   private final void ap_930_runFind(String searchFor, int func)
/*     */   {
/* 408 */     this.pos.adjustPosition(searchFor.length(), func);
/* 409 */     ap_935_runFind(searchFor, func);
/*     */     
/* 411 */     if (this.pos.row >= 0) {
/* 412 */       this.source.setCurrRow(this.pos);
/* 413 */       if (this.pos.currentLine == null) {
/* 414 */         this.msgTxt.setText(LINE_MSG + (this.pos.row + 1) + ", " + this.pos.currentFieldNumber + ", " + this.pos.col);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final void ap_935_runFind(String searchFor, int func)
/*     */   {
/*     */     try
/*     */     {
/* 428 */       this.pnl.removeReKeyListener(this.listner);
/* 429 */       this.file.find(searchFor, this.pos, this.ignoreCase.isSelected(), func, true);
/*     */ 
/*     */ 
/*     */     }
/*     */     finally
/*     */     {
/*     */ 
/*     */ 
/* 437 */       this.pnl.addReKeyListener(this.listner);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void loadFieldList()
/*     */   {
/* 450 */     if (this.file != null) {
/* 451 */       int fieldListIdx = 0;
/* 452 */       int idx = this.layoutList.getSelectedIndex();
/* 453 */       int numCols = this.file.getLayoutColumnCount(idx);
/*     */       
/*     */ 
/*     */ 
/* 457 */       this.fieldList.removeAllItems();
/* 458 */       this.fieldList.addItem("");
/* 459 */       this.fieldList.addItem(ALL_FIELDS);
/* 460 */       if (idx >= 0) {
/* 461 */         for (int i = 0; i < numCols; i++) {
/* 462 */           this.fieldList.addItem(this.file.getColumnName(idx, i));
/*     */         }
/*     */       }
/* 465 */       if (Common.OPTIONS.searchAllFields.isSelected()) {
/* 466 */         fieldListIdx = 1;
/*     */       }
/* 468 */       this.fieldList.setSelectedIndex(fieldListIdx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void layoutChanged(AbstractLayoutDetails layout)
/*     */   {
/* 477 */     this.layoutList.removeActionListener(this);
/* 478 */     this.layoutList.setRecordLayout(layout);
/* 479 */     loadFieldList();
/* 480 */     this.layoutList.addActionListener(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractFileDisplay getSourceDisplay()
/*     */   {
/* 488 */     return this.source;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/util/Search.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */