/*     */ package net.sf.RecordEditor.edit.display.util;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.JRecord.Details.RecordDetail;
/*     */ import net.sf.JRecord.Details.RecordDetail.FieldDetails;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.LayoutCombo;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AddAttributes
/*     */   extends ReFrame
/*     */   implements ActionListener
/*     */ {
/*  28 */   private static final int FIELD_TABLE_HEIGHT = SwingUtils.TABLE_ROW_HEIGHT * 15 / 2;
/*     */   
/*  30 */   private String[] heading = { "Atrribute Name" };
/*  31 */   private String[][] lines = { { "" }, { "" }, { "" }, { "" }, { "" }, { "" }, { "" }, { "" }, { "" }, { "" } };
/*     */   
/*  33 */   private BaseHelpPanel pnl = new BaseHelpPanel();
/*     */   
/*     */   private LayoutCombo layoutSelection;
/*     */   
/*  37 */   private DefaultTableModel model = new DefaultTableModel(this.lines, this.heading);
/*  38 */   private JTable attributeTbl = new JTable(this.model);
/*     */   
/*  40 */   private JButton addBtn = SwingUtils.newButton("Add");
/*     */   
/*     */ 
/*     */   private FileView view;
/*     */   
/*  45 */   private KeyAdapter listner = new KeyAdapter()
/*     */   {
/*     */ 
/*     */     public final void keyReleased(KeyEvent event)
/*     */     {
/*     */ 
/*  51 */       if (event.getKeyCode() == 10) {
/*  52 */         AddAttributes.this.action_100_add();
/*     */       }
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AddAttributes(FileView fileTbl, int layoutIdx)
/*     */   {
/*  65 */     super(fileTbl.getFileNameNoDirectory(), "Add Attributes", fileTbl.getBaseFile());
/*     */     
/*     */ 
/*  68 */     this.view = fileTbl;
/*     */     
/*  70 */     init_100_setupScreenFields(layoutIdx);
/*     */     
/*  72 */     init_200_LayoutScreen();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void init_100_setupScreenFields(int layoutIdx)
/*     */   {
/*  82 */     this.layoutSelection = new LayoutCombo(this.view.getLayout(), false, false);
/*  83 */     this.layoutSelection.setLayoutIndex(layoutIdx);
/*     */     
/*  85 */     if (!Common.TEST_MODE) {
/*  86 */       this.pnl.addReKeyListener(this.listner);
/*     */     }
/*     */     
/*  89 */     this.addBtn.addActionListener(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void init_200_LayoutScreen()
/*     */   {
/*  98 */     this.pnl.addLineRE("Layout", this.layoutSelection);
/*  99 */     this.pnl.addComponentRE(1, 5, FIELD_TABLE_HEIGHT, BasePanel.GAP2, 2, 2, this.attributeTbl);
/*     */     
/*     */ 
/*     */ 
/* 103 */     this.pnl.addLineRE("", null, this.addBtn);
/*     */     
/* 105 */     addMainComponent(this.pnl);
/* 106 */     setVisible(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void actionPerformed(ActionEvent arg0)
/*     */   {
/* 114 */     action_100_add();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void action_100_add()
/*     */   {
/* 123 */     AbstractRecordDetail rec = this.view.getLayout().getRecord(this.layoutSelection.getLayoutIndex());
/*     */     
/*     */ 
/*     */ 
/* 127 */     Common.stopCellEditing(this.attributeTbl);
/*     */     
/* 129 */     if ((rec instanceof RecordDetail)) {
/* 130 */       RecordDetail record = (RecordDetail)rec;
/* 131 */       for (int i = 0; i < this.model.getRowCount(); i++) {
/* 132 */         String s = this.model.getValueAt(i, 0).toString();
/*     */         
/* 134 */         if ((s != null) && (!"".equals(s))) {
/* 135 */           if (!s.startsWith("")) {
/* 136 */             s = "" + s;
/*     */           }
/* 138 */           RecordDetail.FieldDetails field = new RecordDetail.FieldDetails(s, "", 0, 0, "", 0, "");
/* 139 */           field.setPosOnly(record.getFieldCount());
/*     */           
/*     */ 
/* 142 */           record.addField(field);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 147 */     this.view.getBaseFile().fireTableStructureChanged();
/* 148 */     doDefaultCloseAction();
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/util/AddAttributes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */