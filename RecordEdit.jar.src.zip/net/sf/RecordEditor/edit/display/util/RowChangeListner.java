/*    */ package net.sf.RecordEditor.edit.display.util;
/*    */ 
/*    */ import java.awt.event.KeyEvent;
/*    */ import java.awt.event.KeyListener;
/*    */ import javax.swing.JTable;
/*    */ import net.sf.RecordEditor.edit.display.common.AbstractRowChangedListner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RowChangeListner
/*    */   implements KeyListener
/*    */ {
/*    */   private JTable tbl;
/*    */   private AbstractRowChangedListner notify;
/*    */   
/*    */   public RowChangeListner(JTable table, AbstractRowChangedListner rowChangeNotify)
/*    */   {
/* 21 */     this.tbl = table;
/* 22 */     this.notify = rowChangeNotify;
/*    */   }
/*    */   
/*    */ 
/*    */   public void keyPressed(KeyEvent arg0) {}
/*    */   
/*    */ 
/*    */   public void keyReleased(KeyEvent arg0)
/*    */   {
/* 31 */     this.notify.checkForTblRowChange(this.tbl.getSelectedRow());
/*    */   }
/*    */   
/*    */   public void keyTyped(KeyEvent arg0) {}
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/util/RowChangeListner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */