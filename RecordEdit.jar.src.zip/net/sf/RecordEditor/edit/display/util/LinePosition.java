/*    */ package net.sf.RecordEditor.edit.display.util;
/*    */ 
/*    */ import net.sf.JRecord.Details.AbstractLine;
/*    */ 
/*    */ 
/*    */ public class LinePosition
/*    */ {
/*    */   public final AbstractLine line;
/*    */   public final boolean before;
/*    */   
/*    */   public LinePosition(AbstractLine line, boolean prev)
/*    */   {
/* 13 */     this.line = line;
/* 14 */     this.before = prev;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/util/LinePosition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */