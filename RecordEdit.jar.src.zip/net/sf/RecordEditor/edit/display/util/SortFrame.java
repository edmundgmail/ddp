/*    */ package net.sf.RecordEditor.edit.display.util;
/*    */ 
/*    */ import javax.swing.JList;
/*    */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*    */ import net.sf.JRecord.Details.AbstractLine;
/*    */ import net.sf.JRecord.Details.LineCompare;
/*    */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*    */ import net.sf.RecordEditor.re.file.FileView;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SortFrame
/*    */   extends BaseFieldSelection
/*    */ {
/*    */   public SortFrame(AbstractFileDisplay src, FileView fileTbl)
/*    */   {
/* 41 */     this(src, fileTbl, "Sort Options", 13, "Sort");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected SortFrame(AbstractFileDisplay src, FileView fileTbl, String id, int icondId, String btnText)
/*    */   {
/* 54 */     super(src, fileTbl, id, icondId, btnText, 2, false, !fileTbl.getLayout().hasChildren(), "Sort");
/* 55 */     super.setHelpURL(Common.formatHelpURL("HlpRe10.htm"));
/*    */     
/* 57 */     if (fileTbl.getRowCount() == 0) {
/* 58 */       super.doDefaultCloseAction();
/* 59 */       Common.logMsg("Nothing to sort", null);
/* 60 */       return;
/*    */     }
/*    */     
/* 63 */     if (fileTbl.getLayout().hasChildren()) {
/* 64 */       int idx = fileTbl.getLine(0).getPreferredLayoutIdx();
/*    */       
/* 66 */       for (int i = 1; i < fileTbl.getRowCount(); i++) {
/* 67 */         if (idx != fileTbl.getLine(0).getPreferredLayoutIdx()) {
/* 68 */           Common.logMsg("You can only sort when all records are of the same type", null);
/* 69 */           super.doDefaultCloseAction();
/* 70 */           return;
/*    */         }
/*    */       }
/* 73 */       this.records.setSelectedIndex(idx);
/* 74 */       setFieldCombos(idx);
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected AbstractFileDisplay doAction(FileView view, int selection, AbstractFileDisplay src, int[] fieldList, boolean[] descending, AbstractLayoutDetails layout)
/*    */   {
/* 89 */     if (selectWholeFile()) {
/* 90 */       view.sort(new LineCompare(layout, selection, fieldList, descending));
/*    */     }
/*    */     else {
/* 93 */       int[] selected = src.getSelectedRows();
/* 94 */       if ((selected != null) && (selected.length > 0)) {
/* 95 */         view.sort(selected, new LineCompare(layout, selection, fieldList, descending));
/*    */       }
/*    */     }
/*    */     
/* 99 */     return this.source;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/util/SortFrame.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */