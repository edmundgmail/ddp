/*    */ package net.sf.RecordEditor.edit.display.util;
/*    */ 
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.swing.ImageIcon;
/*    */ import javax.swing.JButton;
/*    */ import javax.swing.JPanel;
/*    */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MovementBtnPnl
/*    */   extends JPanel
/*    */ {
/* 14 */   private static String[] moveHints4 = LangConversion.convertArray(11, "RecordBtns", new String[] { "Start of File", "Previous Record", "Next Record", "Last Record" });
/*    */   
/*    */ 
/* 17 */   private static String[] moveHints6 = { moveHints4[0], moveHints4[1], LangConversion.convert(11, "Parent Record"), LangConversion.convert(11, "Child Record"), moveHints4[2], moveHints4[3] };
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 23 */   private String[] moveHints = moveHints4;
/*    */   
/*    */   public final JButton[] buttons;
/*    */   
/*    */   public MovementBtnPnl(ImageIcon[] icon, boolean changeRow, ActionListener listner)
/*    */   {
/* 29 */     this.buttons = new JButton[icon.length];
/*    */     
/* 31 */     if (icon.length > 4) {
/* 32 */       this.moveHints = moveHints6;
/*    */     }
/*    */     
/* 35 */     if (changeRow) {
/* 36 */       for (int i = 0; i < this.buttons.length; i++) {
/* 37 */         this.buttons[i] = new JButton("", icon[i]);
/* 38 */         add(this.buttons[i]);
/* 39 */         this.buttons[i].addActionListener(listner);
/* 40 */         this.buttons[i].setToolTipText(this.moveHints[i]);
/*    */       }
/*    */     }
/*    */     
/* 44 */     for (int i = 0; i < this.buttons.length; i++) {
/* 45 */       this.buttons[i] = new JButton("", icon[i]);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/util/MovementBtnPnl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */