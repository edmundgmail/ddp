/*    */ package net.sf.RecordEditor.edit.display.util;
/*    */ 
/*    */ import java.awt.Container;
/*    */ import javax.swing.JFrame;
/*    */ import net.sf.JRecord.Log.ScreenLog;
/*    */ 
/*    */ public class ErrorScreen
/*    */ {
/*    */   public ErrorScreen(String pgm, Exception ex)
/*    */   {
/* 11 */     JFrame frame = new JFrame("Error Screen");
/* 12 */     ScreenLog log = new ScreenLog(frame);
/*    */     
/* 14 */     frame.getContentPane().add(log);
/*    */     
/* 16 */     log.logMsg(30, "      Program: " + pgm + " " + net.sf.RecordEditor.utils.common.Common.currentVersion() + "\n" + " Java Version: " + System.getProperty("java.version") + "\n\n");
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 22 */     log.logException(30, ex);
/* 23 */     frame.pack();
/* 24 */     frame.setDefaultCloseOperation(3);
/* 25 */     frame.setVisible(true);
/* 26 */     ex.printStackTrace();
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/util/ErrorScreen.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */