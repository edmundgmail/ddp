/*    */ package net.sf.RecordEditor.edit.display.util;
/*    */ 
/*    */ import java.awt.Container;
/*    */ import java.io.PrintStream;
/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.JScrollPane;
/*    */ import javax.swing.JTable;
/*    */ import net.sf.RecordEditor.re.file.FileView;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XFullDisplay1
/*    */   extends JFrame
/*    */ {
/*    */   public XFullDisplay1(FileView t)
/*    */   {
/* 31 */     System.out.println(t.getRowCount());
/* 32 */     JScrollPane comp = new JScrollPane(new JTable(t));
/* 33 */     getContentPane().add(comp);
/* 34 */     pack();
/* 35 */     setVisible(true);
/* 36 */     setDefaultCloseOperation(2);
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/util/XFullDisplay1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */