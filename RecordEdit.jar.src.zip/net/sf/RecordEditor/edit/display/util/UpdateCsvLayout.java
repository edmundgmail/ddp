/*     */ package net.sf.RecordEditor.edit.display.util;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.DefaultCellEditor;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JPopupMenu;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.table.AbstractTableModel;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import net.sf.JRecord.Common.FieldDetail;
/*     */ import net.sf.JRecord.Details.LayoutDetail;
/*     */ import net.sf.JRecord.Details.RecordDetail;
/*     */ import net.sf.JRecord.Details.RecordDetail.FieldDetails;
/*     */ import net.sf.RecordEditor.edit.util.ReMessages;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.MenuPopupListener;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.lang.ReAbstractAction;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMsg;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.CheckBoxTableRender;
/*     */ import net.sf.RecordEditor.utils.swing.ComboBoxRender;
/*     */ import net.sf.RecordEditor.utils.swing.ComboBoxs.DelimiterCombo;
/*     */ import net.sf.RecordEditor.utils.swing.ComboBoxs.QuoteCombo;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ public class UpdateCsvLayout implements ActionListener, net.sf.RecordEditor.re.display.IChildDisplay
/*     */ {
/*  40 */   private static final String NUMBER_FIXED_DECIMAL = LangConversion.convertComboItms("Csv Field Types Fixed", "Number (Fixed Decimal)");
/*     */   
/*     */ 
/*  43 */   private static final String TEXT_FIELD = LangConversion.convertComboItms("Csv Field Types Text", "Text");
/*     */   
/*     */ 
/*  46 */   private static final String[] COL_NAMES = LangConversion.convertColHeading("Update Csv File Format", new String[] { "Field Name", "Include", "Type", "Decimal Places", "Source Column", "Default" });
/*     */   
/*     */   private static final int FIELD_COL = 0;
/*     */   
/*     */   private static final int INCLUDE_COL = 1;
/*     */   
/*     */   private static final int TYPE_COL = 2;
/*     */   
/*     */   private static final int DECIMAL_COL = 3;
/*     */   
/*     */   private static final int SOURCE_COL = 4;
/*     */   
/*     */   private static final int DEFAULT_COL = 5;
/*     */   
/*  60 */   private static final String[] TYPES_TEXT = LangConversion.convertComboItms("Csv Field Types", new String[] { TEXT_FIELD, LangConversion.convertComboItms("Csv Field Types Multi-Line", "Multi Line Text"), LangConversion.convertComboItms("Csv Field Types Html", "Html Field"), LangConversion.convertComboItms("Csv Field Types Num", "Number"), NUMBER_FIXED_DECIMAL });
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  69 */   private static final int[] TYPE = { 0, 117, 119, 19, 5 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  74 */   private ArrayList<FieldDef> fields = new ArrayList(20);
/*     */   
/*     */   private LayoutDetail layout;
/*     */   
/*     */   private FileView view;
/*     */   
/*     */   private AbstractFileDisplay source;
/*  81 */   private FieldModel fieldModel = new FieldModel(null);
/*  82 */   private JTable fieldTbl = new JTable(this.fieldModel);
/*     */   private DelimiterCombo delimiterCombo;
/*  84 */   private QuoteCombo quoteCombo = QuoteCombo.newCombo();
/*  85 */   private JButton goBtn = SwingUtils.newButton("Apply");
/*     */   
/*  87 */   private JMenu moveMenu = SwingUtils.newMenu("Move ...");
/*     */   
/*  89 */   private MenuPopupListener popupListner = new MenuPopupListener();
/*     */   private ReFrame frame;
/*     */   private int delimiterIdx;
/*     */   private int quoteIdx;
/*  93 */   private int newFieldCount; private boolean allowTypeUpdates = true;
/*     */   
/*     */ 
/*     */ 
/*     */   public UpdateCsvLayout(AbstractFileDisplay activeScreen)
/*     */   {
/*  99 */     this.source = activeScreen;
/* 100 */     this.view = this.source.getFileView();
/* 101 */     if ((this.view.isSimpleCsvFile()) && ((this.view.getLayout() instanceof LayoutDetail)))
/*     */     {
/* 103 */       this.layout = ((LayoutDetail)this.view.getLayout());
/*     */       
/* 105 */       init_setupFieldList();
/*     */       
/* 107 */       init_setupScreen();
/*     */     }
/*     */   }
/*     */   
/*     */   private void init_setupFieldList() {
/* 112 */     RecordDetail rec = (RecordDetail)this.layout.getRecord(0);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 117 */     for (int i = 0; i < rec.getFieldCount(); i++) {
/* 118 */       FieldDetail f = (FieldDetail)rec.getField(i);
/*     */       
/* 120 */       boolean found = false;
/* 121 */       String typeStr = "";
/* 122 */       for (int j = 0; j < TYPE.length; j++) {
/* 123 */         if (f.getType() == TYPE[j]) {
/* 124 */           found = true;
/* 125 */           typeStr = TYPES_TEXT[j];
/* 126 */           break;
/*     */         }
/*     */       }
/* 129 */       if (!found) {
/* 130 */         this.allowTypeUpdates = false;
/*     */       }
/* 132 */       this.fields.add(new FieldDef(i, f.getName(), typeStr, f.getDecimal(), f.getDefaultValue()));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void init_setupScreen()
/*     */   {
/* 139 */     BasePanel pnl = new BasePanel();
/* 140 */     String delim = this.layout.getDelimiter();
/* 141 */     String quote = ((RecordDetail)this.layout.getRecord(0)).getQuote();
/*     */     
/* 143 */     init_setupTablePopup();
/*     */     
/* 145 */     if ((this.layout.getFileStructure() == 90) || (this.layout.getFileStructure() == 55))
/*     */     {
/* 147 */       this.delimiterCombo = DelimiterCombo.NewTextDelimCombo();
/*     */     } else {
/* 149 */       this.delimiterCombo = DelimiterCombo.NewDelimCombo();
/*     */     }
/*     */     
/*     */ 
/* 153 */     this.delimiterIdx = this.delimiterCombo.getAddEnglish(delim, true);
/*     */     
/* 155 */     this.quoteIdx = this.quoteCombo.getAddEnglish(quote, true);
/*     */     
/*     */ 
/*     */ 
/* 159 */     setupTable();
/*     */     
/* 161 */     pnl.addComponentRE(1, 5, 300.0D, BasePanel.GAP, 2, 2, this.fieldTbl);
/*     */     
/*     */ 
/* 164 */     pnl.setComponentName(this.fieldTbl, "FieldChange");
/*     */     
/* 166 */     pnl.setGapRE(BasePanel.GAP2);
/* 167 */     pnl.addLineRE("Field Delimiter", this.delimiterCombo);
/* 168 */     pnl.addLineRE("Quote", this.quoteCombo);
/*     */     
/* 170 */     pnl.addLineRE(null, null, this.goBtn);
/*     */     
/* 172 */     this.frame = new ReFrame(this.view.getFileNameNoDirectory(), "Update Screen Columns", this.view);
/*     */     
/*     */ 
/*     */ 
/* 176 */     this.frame.setDefaultCloseOperation(2);
/* 177 */     this.frame.addMainComponent(pnl);
/* 178 */     this.frame.setVisible(true);
/* 179 */     this.frame.setToMaximum(false);
/*     */     
/* 181 */     this.goBtn.addActionListener(this);
/* 182 */     this.fieldTbl.addMouseListener(this.popupListner);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_setupTablePopup()
/*     */   {
/* 204 */     this.popupListner.setTable(this.fieldTbl);
/* 205 */     this.popupListner.getPopup().add(this.moveMenu);
/* 206 */     this.popupListner.getPopup().add(new AddAction(false, "Add Field Before"));
/* 207 */     this.popupListner.getPopup().add(new AddAction(true, "Add Field After"));
/*     */     
/* 209 */     setupFieldMenus();
/*     */   }
/*     */   
/*     */ 
/*     */   private void setupFieldMenus()
/*     */   {
/* 215 */     this.moveMenu.removeAll();
/* 216 */     this.moveMenu.add(new MoveAction(0, ReMessages.BEFORE_FIELD.get(((FieldDef)this.fields.get(0)).name)));
/*     */     
/* 218 */     for (int i = 0; i < this.fields.size(); i++) {
/* 219 */       this.moveMenu.add(new MoveAction(i + 1, ReMessages.AFTER_FIELD.get(((FieldDef)this.fields.get(i)).name)));
/*     */     }
/*     */   }
/*     */   
/*     */   private void setupTable()
/*     */   {
/* 225 */     TableColumnModel tcm = this.fieldTbl.getColumnModel();
/* 226 */     RecordDetail rec = (RecordDetail)this.layout.getRecord(0);
/* 227 */     String[] allFields = new String[rec.getFieldCount() + 1];
/* 228 */     allFields[0] = "";
/* 229 */     for (int i = rec.getFieldCount() - 1; i >= 0; i--) {
/* 230 */       allFields[(i + 1)] = ((RecordDetail.FieldDetails)rec.getField(i)).getName();
/*     */     }
/*     */     
/* 233 */     tcm.getColumn(1).setCellRenderer(new CheckBoxTableRender());
/* 234 */     tcm.getColumn(1).setCellEditor(new DefaultCellEditor(new JCheckBox()));
/*     */     
/* 236 */     tcm.getColumn(2).setCellRenderer(new ComboBoxRender(TYPES_TEXT));
/* 237 */     tcm.getColumn(2).setCellEditor(new DefaultCellEditor(new JComboBox(TYPES_TEXT)));
/*     */     
/* 239 */     tcm.getColumn(4).setCellRenderer(new ComboBoxRender(allFields));
/* 240 */     tcm.getColumn(4).setCellEditor(new DefaultCellEditor(new JComboBox(allFields)));
/*     */     
/* 242 */     Common.calcColumnWidths(this.fieldTbl, 0);
/* 243 */     this.fieldTbl.setRowHeight(SwingUtils.COMBO_TABLE_ROW_HEIGHT);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void actionPerformed(ActionEvent arg0)
/*     */   {
/* 253 */     Common.stopCellEditing(this.fieldTbl);
/* 254 */     if (isUpdateExistingLayout())
/*     */     {
/*     */ 
/* 257 */       RecordDetail rec = (RecordDetail)this.layout.getRecord(0);
/* 258 */       for (int i = 0; i < this.fields.size(); i++) {
/* 259 */         FieldDef f = (FieldDef)this.fields.get(i);
/*     */         
/* 261 */         ((RecordDetail.FieldDetails)rec.getField(i)).setNameType(f.name, getType(f));
/* 262 */         if ((f.defaultValue != null) && (!"".equals(f.defaultValue.trim()))) {
/* 263 */           ((RecordDetail.FieldDetails)rec.getField(i)).setDefaultValue(f.defaultValue);
/*     */         }
/*     */       }
/* 266 */       Code.notifyFramesOfUpdatedLayout(this.view.getBaseFile(), this.layout);
/*     */     }
/*     */     else
/*     */     {
/* 270 */       LayoutDetail newLayout = buildNewLayout();
/* 271 */       int[] trans = getFieldTranslation();
/*     */       
/* 273 */       Code.updateFile(this.view.getBaseFile(), newLayout, trans);
/* 274 */       this.view.getBaseFile().setLayout(newLayout);
/*     */     }
/* 276 */     this.frame.doDefaultCloseAction();
/* 277 */     this.frame.setVisible(false);
/*     */   }
/*     */   
/*     */   private boolean isUpdateExistingLayout() {
/* 281 */     boolean ret = true;
/*     */     
/*     */ 
/* 284 */     System.out.println(" !!! 1 " + this.delimiterIdx + " " + this.delimiterCombo.getSelectedIndex());
/* 285 */     System.out.println(" !!! 2 " + this.quoteIdx + " " + this.quoteCombo.getSelectedIndex());
/* 286 */     if ((this.delimiterIdx != this.delimiterCombo.getSelectedIndex()) || (this.quoteIdx != this.quoteCombo.getSelectedIndex()))
/*     */     {
/* 288 */       ret = false;
/*     */     } else {
/* 290 */       for (int i = 0; i < this.fields.size(); i++) {
/* 291 */         FieldDef f = (FieldDef)this.fields.get(i);
/*     */         
/* 293 */         if (((f.include.booleanValue()) && (f.originalPos != i)) || ((!f.include.booleanValue()) && (f.originalPos >= 0)) || ((NUMBER_FIXED_DECIMAL.equals(f.type)) && ((!f.type.equals(f.originalType)) || (f.decimal != f.originalDecimal))))
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/* 298 */           ret = false;
/* 299 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 303 */     System.out.println(" !!! 3 " + ret);
/*     */     
/* 305 */     return ret;
/*     */   }
/*     */   
/*     */   private LayoutDetail buildNewLayout()
/*     */   {
/* 310 */     this.newFieldCount = 0;
/*     */     
/* 312 */     for (int i = 0; i < this.fields.size(); i++) {
/* 313 */       if (((FieldDef)this.fields.get(i)).include.booleanValue()) {
/* 314 */         this.newFieldCount += 1;
/*     */       }
/*     */     }
/*     */     
/* 318 */     RecordDetail.FieldDetails[] flds = new RecordDetail.FieldDetails[this.newFieldCount];
/* 319 */     RecordDetail[] recs = new RecordDetail[1];
/* 320 */     int format = 0;
/*     */     
/* 322 */     RecordDetail rec = (RecordDetail)this.layout.getRecord(0);
/* 323 */     int j = 0;
/*     */     
/* 325 */     String quote = rec.getQuote();
/*     */     
/* 327 */     if (this.quoteCombo.getSelectedIndex() < Common.QUOTE_VALUES.length) {
/* 328 */       quote = (String)this.quoteCombo.getSelectedKey();
/*     */     }
/*     */     
/*     */ 
/* 332 */     for (int i = 0; i < this.fields.size(); i++) {
/* 333 */       FieldDef f = (FieldDef)this.fields.get(i);
/* 334 */       if (f.include.booleanValue()) {
/* 335 */         flds[j] = new RecordDetail.FieldDetails(f.name, f.name, getType(f), f.decimal, this.layout.getFontName(), format, "");
/*     */         
/* 337 */         flds[j].setPosOnly(j + 1);
/* 338 */         if ((f.defaultValue != null) && (!"".equals(f.defaultValue.trim()))) {
/* 339 */           flds[j].setDefaultValue(f.defaultValue);
/*     */         }
/* 341 */         j++;
/*     */       }
/*     */     }
/*     */     
/* 345 */     recs[0] = new RecordDetail(rec.getRecordName(), "", "", rec.getRecordType(), this.delimiterCombo.getSelectedEnglish(), quote, this.layout.getFontName(), flds, rec.getRecordStyle(), 0);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 350 */     return new LayoutDetail(this.layout.getLayoutName(), recs, "", this.layout.getLayoutType(), this.layout.getRecordSep(), "", this.layout.getFontName(), null, this.layout.getFileStructure());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int[] getFieldTranslation()
/*     */   {
/* 359 */     int[] ret = new int[this.newFieldCount];
/*     */     
/* 361 */     int j = 0;
/*     */     
/* 363 */     for (int i = 0; i < this.fields.size(); i++) {
/* 364 */       FieldDef f = (FieldDef)this.fields.get(i);
/* 365 */       if (f.include.booleanValue()) {
/* 366 */         ret[j] = f.sourceField;
/* 367 */         j++;
/*     */       }
/*     */     }
/* 370 */     return ret;
/*     */   }
/*     */   
/*     */   private int getType(FieldDef field) {
/* 374 */     int type = 0;
/* 375 */     for (int j = 0; j < TYPES_TEXT.length; j++) {
/* 376 */       if (TYPES_TEXT[j].equals(field.type)) {
/* 377 */         type = TYPE[j];
/* 378 */         break;
/*     */       }
/*     */     }
/* 381 */     return type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractFileDisplay getSourceDisplay()
/*     */   {
/* 391 */     return this.source;
/*     */   }
/*     */   
/*     */   private static class FieldDef {
/*     */     public final int originalPos;
/*     */     public final int originalDecimal;
/*     */     public final String originalType;
/*     */     public int sourceField;
/*     */     public int decimal;
/* 400 */     public Boolean include = Boolean.TRUE;
/*     */     
/*     */     public String name;
/*     */     public String type;
/* 404 */     public String defaultValue = "";
/*     */     
/*     */     public FieldDef(int row)
/*     */     {
/* 408 */       this(-121, Integer.toString(row + 1), UpdateCsvLayout.TEXT_FIELD, 0, null);
/*     */     }
/*     */     
/*     */ 
/*     */     public FieldDef(int originalPos, String name, String type, int decimal, Object defaultVal)
/*     */     {
/* 414 */       this.sourceField = originalPos;
/* 415 */       this.originalPos = originalPos;
/* 416 */       this.name = name;
/* 417 */       this.type = type;
/* 418 */       this.originalType = type;
/* 419 */       this.decimal = decimal;
/* 420 */       this.originalDecimal = decimal;
/*     */       
/* 422 */       if (defaultVal != null) {
/* 423 */         this.defaultValue = defaultVal.toString();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private void fireFieldTblChanged() {
/* 429 */     this.fieldModel.fireTableDataChanged();
/* 430 */     setupFieldMenus();
/*     */   }
/*     */   
/*     */ 
/*     */   private class FieldModel
/*     */     extends AbstractTableModel
/*     */   {
/*     */     private FieldModel() {}
/*     */     
/*     */ 
/*     */     public String getColumnName(int col)
/*     */     {
/* 442 */       return UpdateCsvLayout.COL_NAMES[col];
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isCellEditable(int row, int col)
/*     */     {
/* 451 */       UpdateCsvLayout.FieldDef f = (UpdateCsvLayout.FieldDef)UpdateCsvLayout.this.fields.get(row);
/* 452 */       switch (col) {
/* 453 */       case 3:  return UpdateCsvLayout.NUMBER_FIXED_DECIMAL.equals(f.type);
/* 454 */       case 2:  return UpdateCsvLayout.this.allowTypeUpdates;
/*     */       }
/*     */       
/* 457 */       return (col < 4) || (col >= 5) || (f.originalPos < 0);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setValueAt(Object val, int row, int col)
/*     */     {
/* 467 */       UpdateCsvLayout.FieldDef f = (UpdateCsvLayout.FieldDef)UpdateCsvLayout.this.fields.get(row);
/*     */       
/* 469 */       switch (col) {
/*     */       case 0: 
/* 471 */         if ((val == null) || ("".equals(val.toString()))) {
/* 472 */           f.name = Integer.toString(row);
/*     */         } else {
/* 474 */           f.name = val.toString();
/*     */         }
/* 476 */         break;
/* 477 */       case 1:  f.include = ((Boolean)val); break;
/* 478 */       case 2:  f.type = val.toString(); break;
/*     */       case 3: 
/* 480 */         if ((val == null) || ("".equals(val.toString()))) {
/* 481 */           f.decimal = 0;
/* 482 */         } else if ((val instanceof Integer)) {
/* 483 */           f.decimal = ((Integer)val).intValue();
/*     */         } else {
/*     */           try {
/* 486 */             f.decimal = Integer.parseInt(val.toString());
/*     */           }
/*     */           catch (Exception e) {}
/*     */         }
/*     */         
/*     */         break;
/*     */       case 4: 
/* 493 */         if ((val == null) || ("".equals(val.toString()))) {
/* 494 */           f.sourceField = -121;
/*     */         } else {
/* 496 */           f.sourceField = ((RecordDetail)UpdateCsvLayout.this.layout.getRecord(0)).getFieldIndex(val.toString());
/*     */         }
/* 498 */         break;
/*     */       case 5: 
/* 500 */         if (val == null) {
/* 501 */           f.defaultValue = "";
/*     */         } else {
/* 503 */           f.defaultValue = val.toString();
/*     */         }
/*     */         
/*     */         break;
/*     */       }
/*     */       
/*     */     }
/*     */     
/*     */ 
/*     */     public int getColumnCount()
/*     */     {
/* 514 */       return UpdateCsvLayout.COL_NAMES.length;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getRowCount()
/*     */     {
/* 522 */       return UpdateCsvLayout.this.fields.size();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Object getValueAt(int row, int col)
/*     */     {
/* 530 */       Object ret = null;
/* 531 */       UpdateCsvLayout.FieldDef f = (UpdateCsvLayout.FieldDef)UpdateCsvLayout.this.fields.get(row);
/*     */       
/* 533 */       switch (col) {
/* 534 */       case 0:  ret = f.name; break;
/* 535 */       case 1:  ret = f.include; break;
/* 536 */       case 2:  ret = f.type; break;
/*     */       case 3: 
/* 538 */         if (UpdateCsvLayout.NUMBER_FIXED_DECIMAL.equals(f.type)) {
/* 539 */           ret = Integer.valueOf(f.decimal);
/*     */         }
/*     */         break;
/*     */       case 4: 
/* 543 */         ret = "";
/* 544 */         if ((f.originalPos < 0) && (f.sourceField >= 0))
/* 545 */           ret = ((RecordDetail.FieldDetails)((RecordDetail)UpdateCsvLayout.this.layout.getRecord(0)).getField(f.sourceField)).getName();
/*     */         break;
/*     */       case 5: 
/* 548 */         ret = f.defaultValue;
/*     */       }
/*     */       
/*     */       
/* 552 */       return ret;
/*     */     }
/*     */   }
/*     */   
/*     */   private class MoveAction
/*     */     extends AbstractAction
/*     */   {
/*     */     int destination;
/*     */     
/*     */     public MoveAction(int destination, String name)
/*     */     {
/* 563 */       super();
/* 564 */       this.destination = destination;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void actionPerformed(ActionEvent arg0)
/*     */     {
/* 573 */       int sourceRow = UpdateCsvLayout.this.popupListner.getPopupRow();
/* 574 */       UpdateCsvLayout.FieldDef f = (UpdateCsvLayout.FieldDef)UpdateCsvLayout.this.fields.get(sourceRow);
/*     */       
/* 576 */       Common.stopCellEditing(UpdateCsvLayout.this.fieldTbl);
/* 577 */       if (sourceRow < this.destination) {
/* 578 */         if (this.destination >= UpdateCsvLayout.this.fields.size()) {
/* 579 */           UpdateCsvLayout.this.fields.add(f);
/*     */         } else {
/* 581 */           UpdateCsvLayout.this.fields.add(this.destination, f);
/*     */         }
/* 583 */         UpdateCsvLayout.this.fields.remove(sourceRow);
/*     */         
/* 585 */         UpdateCsvLayout.this.fireFieldTblChanged();
/* 586 */       } else if (sourceRow > this.destination) {
/* 587 */         UpdateCsvLayout.this.fields.remove(sourceRow);
/* 588 */         UpdateCsvLayout.this.fields.add(this.destination, f);
/*     */         
/* 590 */         UpdateCsvLayout.this.fireFieldTblChanged();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private class AddAction extends ReAbstractAction
/*     */   {
/*     */     boolean after;
/*     */     
/*     */     public AddAction(boolean after, String name)
/*     */     {
/* 601 */       super();
/* 602 */       this.after = after;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void actionPerformed(ActionEvent arg0)
/*     */     {
/* 611 */       int destination = UpdateCsvLayout.this.popupListner.getPopupRow();
/*     */       
/* 613 */       Common.stopCellEditing(UpdateCsvLayout.this.fieldTbl);
/*     */       
/* 615 */       if (this.after) {
/* 616 */         destination++;
/*     */       }
/* 618 */       UpdateCsvLayout.FieldDef f = new UpdateCsvLayout.FieldDef(destination);
/*     */       
/* 620 */       if (destination >= UpdateCsvLayout.this.fields.size()) {
/* 621 */         UpdateCsvLayout.this.fields.add(f);
/*     */       } else {
/* 623 */         UpdateCsvLayout.this.fields.add(destination, f);
/*     */       }
/*     */       
/* 626 */       UpdateCsvLayout.this.fireFieldTblChanged();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/util/UpdateCsvLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */