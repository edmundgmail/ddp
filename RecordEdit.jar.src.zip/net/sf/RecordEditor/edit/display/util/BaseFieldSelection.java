/*     */ package net.sf.RecordEditor.edit.display.util;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.net.URL;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.DefaultCellEditor;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JDesktopPane;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.event.ListSelectionEvent;
/*     */ import javax.swing.event.ListSelectionListener;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail.FieldDetails;
/*     */ import net.sf.RecordEditor.edit.display.models.SortFieldMdl;
/*     */ import net.sf.RecordEditor.edit.util.ReMessages;
/*     */ import net.sf.RecordEditor.jibx.compare.EditorTask;
/*     */ import net.sf.RecordEditor.jibx.compare.SortTree;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*     */ import net.sf.RecordEditor.re.display.IChildDisplay;
/*     */ import net.sf.RecordEditor.re.display.IUpdateExecute;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.re.tree.FieldSummaryDetails;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.lang.ReAbstractAction;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMainFrame;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMsg;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.CheckBoxTableRender;
/*     */ import net.sf.RecordEditor.utils.swing.ComboBoxRender;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.swing.saveRestore.ISaveUpdateDetails;
/*     */ import net.sf.RecordEditor.utils.swing.saveRestore.SaveLoadPnl;
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class BaseFieldSelection
/*     */   extends ReFrame
/*     */   implements ListSelectionListener, ISaveUpdateDetails<EditorTask>, IUpdateExecute<EditorTask>, IChildDisplay
/*     */ {
/*     */   protected static final int FIELD_TABLE_SIZE = 5;
/*  58 */   private static final String[] WHAT_TO_SORT = LangConversion.convertComboItms("File SelectionOptions", new String[] { "Whole View", "Selected Records" });
/*     */   
/*     */ 
/*  61 */   private BaseHelpPanel pnlTop = new BaseHelpPanel();
/*  62 */   private BaseHelpPanel pnlBottom = new BaseHelpPanel();
/*     */   
/*     */   protected JList records;
/*  65 */   protected SortFieldMdl model = new SortFieldMdl(5);
/*     */   protected JTable fldTable;
/*  67 */   protected JTable fldSummaryTbl; private DefaultComboBoxModel[] fldModel = { new DefaultComboBoxModel(), new DefaultComboBoxModel() };
/*     */   
/*     */ 
/*     */ 
/*  71 */   protected JComboBox whatToSelect = new JComboBox(WHAT_TO_SORT);
/*  72 */   protected JButton executeBtn = new JButton();
/*     */   protected FileView fileView;
/*  74 */   protected int lastSelection = 0;
/*     */   
/*     */   protected final AbstractFileDisplay source;
/*     */   protected SortFieldSummaryMdl summaryMdl;
/*  78 */   private SaveLoadPnl<EditorTask> saveLoadPnl = new SaveLoadPnl(this, Parameters.getFileName("SortTreeSaveDirectory"), EditorTask.class);
/*     */   
/*     */ 
/*     */ 
/*     */   private final String saveId;
/*     */   
/*     */ 
/*     */ 
/*  86 */   private KeyAdapter listner = new KeyAdapter()
/*     */   {
/*     */ 
/*     */     public final void keyReleased(KeyEvent event)
/*     */     {
/*     */ 
/*  92 */       switch (event.getKeyCode()) {
/*  93 */       case 10:  BaseFieldSelection.this.doAction(); break;
/*  94 */       case 27:  BaseFieldSelection.this.doDefaultCloseAction();
/*     */       }
/*     */       
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BaseFieldSelection(AbstractFileDisplay src, FileView fileTbl, String id, int icondId, String btnText, int columnCount, boolean addFieldSummary, boolean showRecordList, String saveIdentifier)
/*     */   {
/* 110 */     super(fileTbl.getFileNameNoDirectory(), id, fileTbl.getBaseFile());
/*     */     
/* 112 */     Rectangle screenSize = ReMainFrame.getMasterFrame().getDesktop().getBounds();
/* 113 */     this.saveId = saveIdentifier;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 118 */     int desktopHeight = screenSize.height - SwingUtils.COMBO_TABLE_ROW_HEIGHT * 6;
/* 119 */     JPanel pnl = new JPanel(new BorderLayout());
/* 120 */     pnl.setBorder(BorderFactory.createEmptyBorder());
/* 121 */     this.pnlTop.setBorder(BorderFactory.createEmptyBorder());
/* 122 */     this.pnlBottom.setBorder(BorderFactory.createEmptyBorder());
/*     */     
/* 124 */     super.addCloseOnEsc(this.pnlTop);
/* 125 */     super.addCloseOnEsc(this.pnlBottom);
/*     */     
/*     */ 
/*     */ 
/* 129 */     this.source = src;
/* 130 */     this.fileView = src.getFileView();
/* 131 */     int recCount = this.fileView.getLayout().getRecordCount();
/*     */     
/*     */ 
/* 134 */     this.model.setColumnCount(columnCount);
/*     */     
/*     */ 
/*     */ 
/* 138 */     init(icondId, btnText);
/*     */     
/* 140 */     this.pnlTop.registerComponentRE(pnl);
/* 141 */     if ((showRecordList) && (recCount > 1)) {
/* 142 */       int height = SwingUtils.calculateTableHeight(recCount, desktopHeight * 3 / 10);
/* 143 */       desktopHeight -= height;
/* 144 */       this.pnlTop.addComponentRE(1, 5, height, BasePanel.GAP0, 2, 2, new JScrollPane(this.records));
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 149 */       this.pnlTop.setComponentName(this.records, "records");
/*     */     }
/*     */     
/* 152 */     if (addFieldSummary) {
/* 153 */       int height = SwingUtils.calculateComboTableHeight(this.fldTable.getRowCount(), desktopHeight * 7 / 20);
/* 154 */       desktopHeight -= height;
/* 155 */       this.pnlTop.addComponentRE(1, 5, height, BasePanel.GAP0, 2, 2, this.fldTable);
/*     */       
/*     */ 
/*     */ 
/* 159 */       height = SwingUtils.calculateComboTableHeight(this.fldSummaryTbl.getRowCount(), desktopHeight * 8 / 10);
/* 160 */       this.pnlTop.addComponentRE(1, 5, height, BasePanel.GAP, 2, 2, this.fldSummaryTbl);
/*     */       
/*     */ 
/*     */ 
/* 164 */       this.pnlTop.setComponentName(this.fldSummaryTbl, "fieldSummary");
/*     */     } else {
/* 166 */       int height = SwingUtils.calculateComboTableHeight(this.fldTable.getRowCount(), desktopHeight * 4 / 5);
/* 167 */       this.pnlTop.addComponentRE(1, 5, height, BasePanel.GAP, 2, 2, this.fldTable);
/*     */     }
/*     */     
/*     */ 
/* 171 */     this.pnlTop.setComponentName(this.fldTable, "fields");
/*     */     
/* 173 */     this.pnlBottom.addLineRE("Use", this.whatToSelect);
/* 174 */     this.pnlBottom.setGapRE(BasePanel.GAP0);
/*     */     
/* 176 */     JPanel p = new JPanel();
/* 177 */     p.add(this.executeBtn);
/* 178 */     this.pnlBottom.addLineRE("", this.saveLoadPnl.panel, p);
/* 179 */     this.pnlBottom.setGapRE(3.0D);
/*     */     
/* 181 */     pnl.add("Center", new JScrollPane(this.pnlTop));
/* 182 */     pnl.add("South", this.pnlBottom);
/* 183 */     addMainComponent(pnl);
/*     */     
/* 185 */     setBounds(getY(), getX(), Math.min(getWidth() + 25, screenSize.width - 10), Math.min(getHeight(), screenSize.height - 5));
/*     */     
/*     */ 
/* 188 */     setVisible(true);
/* 189 */     setToMaximum(false);
/* 190 */     super.addCloseOnEsc(this.pnlTop);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void init(int icondId, String btnText)
/*     */   {
/* 201 */     AbstractLayoutDetails layout = this.fileView.getLayout();
/* 202 */     String[] recordName = new String[layout.getRecordCount()];
/*     */     
/* 204 */     JComboBox OperatorList = new JComboBox(FieldSummaryDetails.FOREIGN_OPERATOR_NAMES);
/*     */     
/* 206 */     this.summaryMdl = new SortFieldSummaryMdl(this.fileView.getLayout());
/* 207 */     this.fldSummaryTbl = new JTable(this.summaryMdl);
/*     */     
/* 209 */     this.fldTable = new JTable(this.model);
/*     */     
/* 211 */     for (int i = 0; i < layout.getRecordCount(); i++) {
/* 212 */       recordName[i] = layout.getRecord(i).getRecordName();
/*     */     }
/* 214 */     this.records = new JList(recordName);
/* 215 */     this.records.addListSelectionListener(this);
/*     */     
/* 217 */     this.pnlTop.addReKeyListener(this.listner);
/*     */     
/* 219 */     JComboBox fieldList = new JComboBox(this.fldModel[1]);
/* 220 */     this.fldTable.setRowHeight(SwingUtils.COMBO_TABLE_ROW_HEIGHT);
/* 221 */     TableColumnModel tcm = this.fldTable.getColumnModel();
/* 222 */     TableColumn tc = tcm.getColumn(0);
/* 223 */     tc.setCellRenderer(new ComboBoxRender(this.fldModel[0]));
/* 224 */     tc.setCellEditor(new DefaultCellEditor(fieldList));
/*     */     
/* 226 */     if (this.model.getColumnCount() > 1) {
/* 227 */       tc = tcm.getColumn(1);
/* 228 */       tc.setCellRenderer(new CheckBoxTableRender());
/* 229 */       tc.setCellEditor(new DefaultCellEditor(new JCheckBox()));
/*     */     }
/*     */     
/* 232 */     this.fldSummaryTbl.setRowHeight(SwingUtils.COMBO_TABLE_ROW_HEIGHT);
/* 233 */     tcm = this.fldSummaryTbl.getColumnModel();
/* 234 */     tc = tcm.getColumn(1);
/* 235 */     tc.setCellRenderer(new ComboBoxRender(new JComboBox(FieldSummaryDetails.FOREIGN_OPERATOR_NAMES).getModel()));
/* 236 */     tc.setCellEditor(new DefaultCellEditor(OperatorList));
/*     */     
/*     */ 
/* 239 */     this.pnlTop.registerComponentRE(fieldList);
/*     */     
/*     */ 
/* 242 */     setFieldCombos(this.lastSelection);
/* 243 */     this.records.setSelectedIndex(this.lastSelection);
/*     */     
/* 245 */     this.executeBtn.setAction(new ReAbstractAction(btnText, icondId) {
/*     */       public void actionPerformed(ActionEvent e) {
/* 247 */         BaseFieldSelection.this.doAction();
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void setFieldCombos(int index)
/*     */   {
/* 258 */     AbstractRecordDetail rec = this.fileView.getLayout().getRecord(index);
/*     */     
/* 260 */     this.lastSelection = index;
/*     */     
/* 262 */     for (int i = 0; i < this.fldModel.length; i++) {
/* 263 */       this.fldModel[i].removeAllElements();
/* 264 */       this.fldModel[i].addElement(" ");
/* 265 */       for (int j = 0; j < rec.getFieldCount(); j++) {
/* 266 */         this.fldModel[i].addElement(rec.getField(j).getName());
/*     */       }
/*     */     }
/* 269 */     this.model.resetFields();
/*     */     
/* 271 */     this.summaryMdl.setRecordIndex(index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final AbstractFileDisplay doAction()
/*     */   {
/* 279 */     int numSortFields = getNumberOfSortFields();
/* 280 */     AbstractFileDisplay ret = null;
/*     */     
/* 282 */     if (numSortFields > 0) {
/* 283 */       int[] fieldList = new int[numSortFields];
/* 284 */       boolean[] descending = new boolean[numSortFields];
/* 285 */       AbstractLayoutDetails layout = this.fileView.getLayout();
/*     */       
/*     */ 
/* 288 */       AbstractRecordDetail record = layout.getRecord(this.lastSelection);
/* 289 */       int j = 0;
/*     */       
/* 291 */       for (int i = 0; i < 5; i++) {
/* 292 */         String s = this.model.getFieldName(i);
/* 293 */         if ((s != null) && (!"".equals(s.trim()))) {
/* 294 */           descending[j] = (!this.model.getAscending(i) ? 1 : false);
/* 295 */           fieldList[(j++)] = record.getFieldIndex(this.model.getFieldName(i));
/*     */         }
/*     */       }
/* 298 */       ret = doAction(this.fileView, this.lastSelection, this.source, fieldList, descending, layout);
/*     */     }
/*     */     try
/*     */     {
/* 302 */       setClosed(true);
/*     */     }
/*     */     catch (Exception e) {}
/*     */     
/* 306 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract AbstractFileDisplay doAction(FileView paramFileView, int paramInt, AbstractFileDisplay paramAbstractFileDisplay, int[] paramArrayOfInt, boolean[] paramArrayOfBoolean, AbstractLayoutDetails paramAbstractLayoutDetails);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected int getNumberOfSortFields()
/*     */   {
/* 330 */     int numSortFields = 0;
/*     */     
/* 332 */     for (int i = 0; i < 5; i++) {
/* 333 */       String s = this.model.getFieldName(i);
/* 334 */       if ((s != null) && (!"".equals(s.trim()))) {
/* 335 */         numSortFields++;
/*     */       }
/*     */     }
/*     */     
/* 339 */     return numSortFields;
/*     */   }
/*     */   
/*     */   protected FileView getNewView() {
/* 343 */     FileView view = this.source.getFileView();
/* 344 */     FileView newView = null;
/*     */     
/* 346 */     if (selectWholeFile()) {
/* 347 */       newView = view.getView();
/*     */     } else {
/* 349 */       int[] selected = this.source.getSelectedRows();
/*     */       
/* 351 */       if ((selected != null) && (selected.length > 0)) {
/* 352 */         newView = view.getView(selected);
/*     */       }
/*     */     }
/* 355 */     return newView;
/*     */   }
/*     */   
/*     */   protected boolean selectWholeFile() {
/* 359 */     return this.whatToSelect.getSelectedIndex() == 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void valueChanged(ListSelectionEvent e)
/*     */   {
/* 366 */     int idx = this.records.getSelectedIndex();
/* 367 */     if ((this.lastSelection != idx) && (idx >= 0)) {
/* 368 */       setFieldCombos(idx);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void executeAction(int action)
/*     */   {
/* 379 */     if (action == 23) {
/* 380 */       this.pnlTop.showHelpRE();
/*     */     } else {
/* 382 */       super.executeAction(action);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isActionAvailable(int action)
/*     */   {
/* 394 */     return (action == 23) || (super.isActionAvailable(action));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final EditorTask getSaveDetails()
/*     */   {
/* 403 */     SortTree sortTree = new SortTree();
/* 404 */     Object rn = this.records.getSelectedValue();
/*     */     
/* 406 */     if (rn != null) {
/* 407 */       sortTree.recordName = rn.toString();
/* 408 */       sortTree.sortFields = this.model.getSortFields();
/* 409 */       sortTree.sortSummary = this.summaryMdl.getFieldSummary().getSummary();
/* 410 */       return new EditorTask().setSortTree(this.saveId, this.fileView.getLayout().getLayoutName(), sortTree);
/*     */     }
/*     */     
/* 413 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void update(EditorTask serialisedData)
/*     */   {
/* 422 */     if ((serialisedData == null) || (serialisedData.sortTree == null)) {
/* 423 */       Common.logMsgRaw(ReMessages.NOT_A_SORT.get(), null);
/*     */     } else {
/* 425 */       setFromSavedDetails(serialisedData);
/* 426 */       this.model.fireTableDataChanged();
/* 427 */       if (this.summaryMdl != null) {
/* 428 */         this.summaryMdl.fireTableDataChanged();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractFileDisplay getSourceDisplay()
/*     */   {
/* 438 */     return this.source;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFromSavedDetails(EditorTask details)
/*     */   {
/* 447 */     int idx = this.fileView.getLayout().getRecordIndex(details.sortTree.recordName);
/*     */     
/* 449 */     this.model.setSortTree(details.sortTree.sortFields);
/*     */     
/* 451 */     if (idx >= 0) {
/* 452 */       this.records.setSelectedIndex(idx);
/*     */       
/* 454 */       this.summaryMdl.getFieldSummary().setSummary(idx, details.sortTree.sortSummary);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setHelpURL(URL helpUrl)
/*     */   {
/* 463 */     this.pnlTop.setHelpURLre(helpUrl);
/* 464 */     this.pnlBottom.setHelpURLre(helpUrl);
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/util/BaseFieldSelection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */