/*     */ package net.sf.RecordEditor.edit.display.util;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.JPopupMenu;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*     */ import net.sf.RecordEditor.re.display.IDisplayFrame;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DockingPopupListner
/*     */   extends MouseAdapter
/*     */ {
/*     */   private final AbstractFileDisplay pnl;
/*     */   
/*     */   public DockingPopupListner(AbstractFileDisplay panel)
/*     */   {
/*  24 */     this.pnl = panel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void mouseReleased(MouseEvent e)
/*     */   {
/*  31 */     if (e != null) {
/*  32 */       if (e.isPopupTrigger()) {
/*  33 */         int x = e.getX();
/*  34 */         int y = e.getY();
/*     */         
/*  36 */         getPopup().show(e.getComponent(), x, y);
/*     */       } else {
/*  38 */         this.pnl.getParentFrame().setToActiveTab(this.pnl);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public JPopupMenu getPopup()
/*     */   {
/*  48 */     JPopupMenu ret = new JPopupMenu();
/*     */     
/*  50 */     IDisplayFrame displFrame = this.pnl.getParentFrame();
/*  51 */     int idx = displFrame.indexOf(this.pnl);
/*     */     
/*     */ 
/*  54 */     addAction(ret, displFrame, idx, 61);
/*     */     
/*  56 */     if (displFrame.isActionAvailable(68)) {
/*  57 */       addAction(ret, displFrame, idx, 68);
/*  58 */       addAction(ret, displFrame, idx, 69);
/*     */     } else {
/*  60 */       addAction(ret, displFrame, idx, 67);
/*     */     }
/*  62 */     addAction(ret, displFrame, idx, 70);
/*     */     
/*  64 */     addAction(ret, displFrame, idx, 66);
/*     */     
/*  66 */     if (displFrame.getScreenCount() > 1)
/*     */     {
/*  68 */       addAction(ret, displFrame, idx, 62);
/*  69 */       addAction(ret, displFrame, idx, 63);
/*     */     }
/*  71 */     addAction(ret, displFrame, idx, 65);
/*     */     
/*  73 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */   private void addAction(JPopupMenu ret, IDisplayFrame displFrame, int idx, int action)
/*     */   {
/*  79 */     if (displFrame.isActionAvailable(idx, action)) {
/*  80 */       ret.add(new LocalAction(displFrame, idx, action));
/*     */     }
/*     */   }
/*     */   
/*     */   private static class LocalAction
/*     */     extends AbstractAction
/*     */   {
/*     */     private final IDisplayFrame displFrame;
/*     */     private final int idx;
/*     */     private final int action;
/*     */     
/*     */     public LocalAction(IDisplayFrame displFrame, int idx, int action)
/*     */     {
/*  93 */       super();
/*  94 */       this.displFrame = displFrame;
/*  95 */       this.idx = idx;
/*  96 */       this.action = action;
/*     */       
/*  98 */       putValue("ShortDescription", Common.getReActionDescription(action));
/*     */     }
/*     */     
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/* 103 */       this.displFrame.executeAction(this.idx, this.action);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/util/DockingPopupListner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */