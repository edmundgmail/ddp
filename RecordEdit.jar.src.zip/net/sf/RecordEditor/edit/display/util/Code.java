/*     */ package net.sf.RecordEditor.edit.display.util;
/*     */ 
/*     */ import net.sf.JRecord.Common.RecordException;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.LayoutDetail;
/*     */ import net.sf.JRecord.Details.RecordDetail;
/*     */ import net.sf.JRecord.Details.RecordDetail.FieldDetails;
/*     */ import net.sf.RecordEditor.edit.display.common.ILayoutChanged;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*     */ import net.sf.RecordEditor.re.display.IDisplayFrame;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ 
/*     */ 
/*     */ public class Code
/*     */ {
/*  18 */   private static final byte[] NULL_BYTES = new byte[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void notifyFramesOfNewLayout(FileView masterView, AbstractLayoutDetails layout)
/*     */   {
/*  26 */     masterView.setLayout(layout);
/*  27 */     masterView.fireTableStructureChanged();
/*     */     
/*  29 */     ReFrame[] frames = ReFrame.getAllFrames();
/*  30 */     for (int i = 0; i < frames.length; i++) {
/*  31 */       if (frames[i].getDocument() == masterView) {
/*  32 */         if ((frames[i] instanceof IDisplayFrame)) {
/*  33 */           AbstractFileDisplay p = ((IDisplayFrame)frames[i]).getActiveDisplay();
/*  34 */           if ((p instanceof ILayoutChanged)) {
/*  35 */             ((ILayoutChanged)p).layoutChanged(layout);
/*     */           } else {
/*  37 */             ((IDisplayFrame)frames[i]).close(p);
/*     */           }
/*  39 */         } else if ((frames[i] instanceof ILayoutChanged)) {
/*  40 */           ((ILayoutChanged)frames[i]).layoutChanged(layout);
/*     */         } else {
/*  42 */           frames[i].doDefaultCloseAction();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void notifyFramesOfUpdatedLayout(FileView masterView, AbstractLayoutDetails layout)
/*     */   {
/*  55 */     masterView.fireTableStructureChanged();
/*     */     
/*  57 */     ReFrame[] frames = ReFrame.getAllFrames();
/*  58 */     for (int i = 0; i < frames.length; i++) {
/*  59 */       if (frames[i].getDocument() == masterView)
/*     */       {
/*     */ 
/*     */ 
/*  63 */         setLayout(frames[i], layout);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static void setLayout(Object pnl, AbstractLayoutDetails layout)
/*     */   {
/*  70 */     if ((pnl instanceof AbstractFileDisplay)) {
/*  71 */       ((AbstractFileDisplay)pnl).setNewLayout(layout);
/*  72 */     } else if ((pnl instanceof ILayoutChanged)) {
/*  73 */       ((ILayoutChanged)pnl).layoutChanged(layout);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void updateFile(FileView masterFile, LayoutDetail newLayout, int[] trans)
/*     */   {
/*  81 */     for (int i = 0; i < masterFile.getRowCount(); i++) {
/*  82 */       AbstractLine newLine = masterFile.getLine(i);
/*  83 */       AbstractLine oldLine = newLine.getNewDataLine();
/*  84 */       newLine.setLayout(newLayout);
/*  85 */       newLine.setData(NULL_BYTES);
/*  86 */       for (int j = trans.length - 1; j >= 0; j--) {
/*     */         try {
/*  88 */           if (trans[j] >= 0) {
/*  89 */             newLine.setField(0, j, oldLine.getField(0, trans[j]));
/*     */           }
/*     */         } catch (RecordException e) {
/*  92 */           e.printStackTrace();
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*  97 */     masterFile.setChanged(true);
/*  98 */     notifyFramesOfNewLayout(masterFile, newLayout);
/*     */   }
/*     */   
/*     */   public static void addColumn(FileView masterFile, LayoutDetail layout, int col, int source) {
/* 102 */     String s = Integer.toString(col + 1);
/* 103 */     RecordDetail rec = (RecordDetail)layout.getRecord(0);
/* 104 */     RecordDetail.FieldDetails[] fields = new RecordDetail.FieldDetails[rec.getFieldCount() + 1];
/* 105 */     int[] trans = new int[fields.length];
/*     */     
/* 107 */     for (int i = 0; i < col; i++) {
/* 108 */       fields[i] = cloneCsvField((RecordDetail.FieldDetails)rec.getField(i), i + 1);
/* 109 */       trans[i] = i;
/*     */     }
/* 111 */     fields[col] = new RecordDetail.FieldDetails("Column_" + s, "", 0, 0, rec.getFontName(), 0, "");
/* 112 */     fields[col].setPosOnly(col + 1);
/* 113 */     trans[col] = source;
/*     */     
/* 115 */     for (int i = col + 1; i < fields.length; i++) {
/* 116 */       fields[i] = cloneCsvField((RecordDetail.FieldDetails)rec.getField(i - 1), i + 1);
/* 117 */       trans[i] = (i - 1);
/*     */     }
/*     */     
/* 120 */     updateFile(masterFile, cloneCsvLayout(layout, fields), trans);
/*     */   }
/*     */   
/*     */   public static void moveColumn(FileView masterFile, LayoutDetail layout, int dest, int source) {
/* 124 */     RecordDetail rec = (RecordDetail)layout.getRecord(0);
/* 125 */     RecordDetail.FieldDetails[] fields = new RecordDetail.FieldDetails[rec.getFieldCount()];
/* 126 */     int[] trans = new int[fields.length];
/* 127 */     int k = 0;
/* 128 */     int d = dest;
/* 129 */     if (d > source) {
/* 130 */       d--;
/*     */     }
/*     */     
/* 133 */     for (int i = 0; i < fields.length; i++) {
/* 134 */       if (i != source)
/*     */       {
/*     */ 
/* 137 */         if (k == d) {
/* 138 */           k++;
/*     */         }
/* 140 */         fields[k] = cloneCsvField((RecordDetail.FieldDetails)rec.getField(i), k + 1);
/* 141 */         trans[k] = i;
/* 142 */         k++;
/*     */       }
/*     */     }
/* 145 */     fields[d] = cloneCsvField((RecordDetail.FieldDetails)rec.getField(source), d + 1);
/* 146 */     trans[d] = source;
/*     */     
/* 148 */     updateFile(masterFile, cloneCsvLayout(layout, fields), trans);
/*     */   }
/*     */   
/*     */   public static void deleteColumn(FileView masterFile, LayoutDetail layout, int col) {
/* 152 */     RecordDetail rec = (RecordDetail)layout.getRecord(0);
/* 153 */     RecordDetail.FieldDetails[] fields = new RecordDetail.FieldDetails[rec.getFieldCount() - 1];
/* 154 */     int[] trans = new int[fields.length];
/*     */     
/* 156 */     for (int i = 0; i < col; i++) {
/* 157 */       fields[i] = cloneCsvField((RecordDetail.FieldDetails)rec.getField(i), i + 1);
/* 158 */       trans[i] = i;
/*     */     }
/*     */     
/* 161 */     for (int i = col; i < fields.length; i++) {
/* 162 */       fields[i] = cloneCsvField((RecordDetail.FieldDetails)rec.getField(i + 1), i + 1);
/*     */       
/* 164 */       trans[i] = (i + 1);
/*     */     }
/*     */     
/* 167 */     updateFile(masterFile, cloneCsvLayout(layout, fields), trans);
/*     */   }
/*     */   
/*     */   private static RecordDetail.FieldDetails cloneCsvField(RecordDetail.FieldDetails f, int pos) {
/* 171 */     RecordDetail.FieldDetails ret = new RecordDetail.FieldDetails(f.getName(), f.getDescription(), f.getType(), f.getDecimal(), f.getFontName(), f.getFormat(), f.getParamater());
/*     */     
/*     */ 
/* 174 */     ret.setPosOnly(pos);
/* 175 */     return ret;
/*     */   }
/*     */   
/*     */   private static LayoutDetail cloneCsvLayout(LayoutDetail l, RecordDetail.FieldDetails[] fields) {
/* 179 */     RecordDetail rec = (RecordDetail)l.getRecord(0);
/* 180 */     RecordDetail[] recs = new RecordDetail[1];
/*     */     
/* 182 */     recs[0] = new RecordDetail(rec.getRecordName(), "", "", rec.getRecordType(), rec.getDelimiter(), rec.getQuote(), l.getFontName(), fields, rec.getRecordStyle(), 0);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 187 */     return new LayoutDetail(l.getLayoutName(), recs, "", l.getLayoutType(), l.getRecordSep(), "", l.getFontName(), null, l.getFileStructure());
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/util/Code.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */