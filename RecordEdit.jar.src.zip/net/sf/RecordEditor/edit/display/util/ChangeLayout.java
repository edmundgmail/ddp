/*    */ package net.sf.RecordEditor.edit.display.util;
/*    */ 
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.swing.JButton;
/*    */ import javax.swing.JTextArea;
/*    */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*    */ import net.sf.RecordEditor.re.file.FileView;
/*    */ import net.sf.RecordEditor.re.openFile.AbstractLayoutSelection;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*    */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*    */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*    */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*    */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*    */ 
/*    */ public class ChangeLayout
/*    */   implements ActionListener
/*    */ {
/* 20 */   private static final String CHANGE_LAYOUT_ERROR = LangConversion.convert("Error Changing Layout:");
/*    */   
/*    */   private ReFrame frame;
/*    */   
/*    */   private FileView masterView;
/*    */   
/*    */   private AbstractLayoutSelection layoutReader;
/* 27 */   private JButton goButton = SwingUtils.newButton("Go");
/* 28 */   private JTextArea msgTxt = new JTextArea();
/*    */   
/*    */   public ChangeLayout(AbstractLayoutSelection layoutSelection, FileView file) {
/* 31 */     BaseHelpPanel pnl = new BaseHelpPanel();
/*    */     
/* 33 */     this.layoutReader = layoutSelection;
/* 34 */     this.masterView = file.getBaseFile();
/*    */     
/* 36 */     this.layoutReader.setMessage(this.msgTxt);
/*    */     
/* 38 */     this.frame = new ReFrame(this.masterView.getBaseFile().getFileNameNoDirectory(), "Change Layout", this.masterView);
/* 39 */     this.frame.addCloseOnEsc(pnl);
/*    */     
/* 41 */     this.layoutReader.addLayoutSelection(pnl, null, null, null, null);
/*    */     
/* 43 */     pnl.setGapRE(BasePanel.GAP1);
/* 44 */     pnl.addLineRE("", null, this.goButton);
/* 45 */     pnl.setGapRE(BasePanel.GAP2);
/*    */     
/* 47 */     pnl.addMessage(this.msgTxt);
/* 48 */     this.goButton.addActionListener(this);
/*    */     
/* 50 */     this.frame.setDefaultCloseOperation(2);
/* 51 */     this.frame.addMainComponent(pnl);
/*    */     
/* 53 */     this.frame.setVisible(true);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void actionPerformed(ActionEvent arg0)
/*    */   {
/*    */     try
/*    */     {
/* 62 */       AbstractLayoutDetails layout = this.layoutReader.getRecordLayout(this.masterView.getFileName());
/*    */       
/* 64 */       if (layout != null) {
/* 65 */         this.goButton.removeActionListener(this);
/* 66 */         this.frame.setVisible(false);
/*    */         
/* 68 */         Code.notifyFramesOfNewLayout(this.masterView, layout);
/*    */       }
/*    */     } catch (Exception e) {
/* 71 */       String s = CHANGE_LAYOUT_ERROR + e.getMessage();
/* 72 */       this.msgTxt.setText(s);
/* 73 */       Common.logMsgRaw(s, e);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/util/ChangeLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */