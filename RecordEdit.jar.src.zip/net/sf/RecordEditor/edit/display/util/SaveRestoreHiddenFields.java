/*     */ package net.sf.RecordEditor.edit.display.util;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.JPanel;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*     */ import net.sf.JRecord.Details.AbstractRecordDetail.FieldDetails;
/*     */ import net.sf.RecordEditor.edit.display.common.AbstractFieldSequencePnl;
/*     */ import net.sf.RecordEditor.jibx.compare.EditorTask;
/*     */ import net.sf.RecordEditor.jibx.compare.FieldSequence;
/*     */ import net.sf.RecordEditor.jibx.compare.Layout;
/*     */ import net.sf.RecordEditor.jibx.compare.Record;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplayWithFieldHide;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.re.file.filter.AbstractExecute;
/*     */ import net.sf.RecordEditor.re.file.filter.ExecuteSavedFile;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.swing.saveRestore.ISaveUpdateDetails;
/*     */ import net.sf.RecordEditor.utils.swing.saveRestore.SaveLoadPnl;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SaveRestoreHiddenFields
/*     */   implements ISaveUpdateDetails<EditorTask>, AbstractExecute<EditorTask>
/*     */ {
/*     */   private AbstractFileDisplayWithFieldHide display;
/*     */   private HideFields hideFields;
/*     */   
/*     */   public SaveRestoreHiddenFields(AbstractFileDisplayWithFieldHide display, HideFields hFields)
/*     */   {
/*  37 */     this.display = display;
/*  38 */     this.hideFields = hFields;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EditorTask getSaveDetails()
/*     */   {
/*  47 */     EditorTask ret = new EditorTask();
/*     */     
/*  49 */     ret.type = "VisibleFields";
/*  50 */     ret.filter = getExternalLayout();
/*  51 */     if (((this.display instanceof AbstractFieldSequencePnl)) && (this.hideFields.isSaveSeqSelected()))
/*     */     {
/*  53 */       this.hideFields.applyFieldVisibilty();
/*  54 */       ReFrame.setActiveFrame(this.hideFields.frame);
/*  55 */       FieldSequence fieldSequence = ((AbstractFieldSequencePnl)this.display).getFieldSequence();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  76 */       ret.fieldSequence = fieldSequence;
/*     */     }
/*     */     
/*  79 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFromSavedDetails(EditorTask details)
/*     */   {
/*  89 */     load(details);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void update(EditorTask serialisedData)
/*     */   {
/*  98 */     load(serialisedData);
/*  99 */     ReFrame.setActiveFrame(this.hideFields.frame);
/*     */   }
/*     */   
/*     */ 
/*     */   private Layout getExternalLayout()
/*     */   {
/* 105 */     Layout tmpLayoutSelection = new Layout();
/*     */     
/* 107 */     boolean allSelected = true;
/*     */     
/* 109 */     AbstractLayoutDetails layout = this.display.getFileView().getLayout();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 114 */     tmpLayoutSelection.name = layout.getLayoutName();
/* 115 */     for (int i = 0; i < layout.getRecordCount(); i++)
/*     */     {
/* 117 */       Record rec = new Record();
/* 118 */       boolean[] recordFields; boolean[] recordFields; if (i == this.hideFields.getRecordIndex()) {
/* 119 */         recordFields = this.hideFields.getVisibleFields();
/*     */       } else {
/* 121 */         recordFields = this.display.getFieldVisibility(i);
/*     */       }
/* 123 */       AbstractRecordDetail recordDetail = layout.getRecord(i);
/* 124 */       rec.name = recordDetail.getRecordName();
/*     */       
/* 126 */       if (recordFields != null) {
/* 127 */         int count = 0;
/* 128 */         for (int j = 0; j < recordDetail.getFieldCount(); j++) {
/* 129 */           if (recordFields[j] != 0) {
/* 130 */             count++;
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 135 */         if (count != recordDetail.getFieldCount()) {
/* 136 */           int k = 0;
/* 137 */           allSelected = false;
/* 138 */           rec.fields = new String[count];
/* 139 */           for (j = 0; j < recordDetail.getFieldCount(); j++) {
/* 140 */             if (recordFields[j] != 0) {
/* 141 */               rec.fields[(k++)] = recordDetail.getField(j).getName();
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 147 */       rec.fieldTest = new ArrayList(0);
/*     */       
/* 149 */       tmpLayoutSelection.getRecords().add(rec);
/*     */     }
/*     */     
/*     */ 
/* 153 */     if (allSelected) {
/* 154 */       tmpLayoutSelection.records = null;
/*     */     }
/*     */     
/* 157 */     return tmpLayoutSelection;
/*     */   }
/*     */   
/*     */ 
/*     */   public AbstractFileDisplay execute(EditorTask details)
/*     */   {
/* 163 */     load(details);
/* 164 */     return this.display;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void load(EditorTask details)
/*     */   {
/* 175 */     AbstractLayoutDetails layout = this.display.getFileView().getLayout();
/*     */     
/*     */ 
/*     */ 
/* 179 */     if ((details.filter.records == null) || (details.filter.records.size() == 0))
/*     */     {
/* 181 */       for (int i = 0; i < layout.getRecordCount(); i++) {
/* 182 */         AbstractRecordDetail recordDetail = layout.getRecord(i);
/* 183 */         boolean[] recordFields = createBooleanArray(recordDetail.getFieldCount(), true);
/* 184 */         this.display.setFieldVisibility(i, recordFields);
/*     */       }
/*     */     } else {
/* 187 */       for (int i = 0; i < details.filter.records.size(); i++) {
/* 188 */         Record rec = (Record)details.filter.records.get(i);
/* 189 */         int idx = layout.getRecordIndex(rec.name);
/* 190 */         if (idx >= 0) {
/* 191 */           AbstractRecordDetail recordDetail = layout.getRecord(idx);
/* 192 */           boolean fieldsPresent = (rec.fields != null) && (rec.fields.length > 0);
/* 193 */           boolean[] recordFields = createBooleanArray(recordDetail.getFieldCount(), !fieldsPresent);
/*     */           
/* 195 */           if (fieldsPresent) {
/* 196 */             for (int j = 0; j < rec.fields.length; j++) {
/* 197 */               int fieldIdx = recordDetail.getFieldIndex(rec.fields[j]);
/* 198 */               if (fieldIdx >= 0) {
/* 199 */                 recordFields[fieldIdx] = true;
/*     */               }
/*     */             }
/*     */           }
/* 203 */           this.display.setFieldVisibility(idx, recordFields);
/* 204 */           if ((this.hideFields != null) && (idx == this.hideFields.getRecordIndex())) {
/* 205 */             this.hideFields.updateIncludes(recordFields);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 211 */     if ((details.fieldSequence != null) && ((this.display instanceof AbstractFieldSequencePnl)))
/*     */     {
/* 213 */       ((AbstractFieldSequencePnl)this.display).setFieldSequence(details.fieldSequence);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean[] createBooleanArray(int size, boolean initValue) {
/* 218 */     boolean[] ret = new boolean[size];
/* 219 */     for (int i = 0; i < size; i++) {
/* 220 */       ret[i] = initValue;
/*     */     }
/*     */     
/* 223 */     return ret;
/*     */   }
/*     */   
/*     */   public void executeDialog(EditorTask details) {
/* 227 */     load(details);
/*     */   }
/*     */   
/*     */ 
/*     */   public static JPanel getSaveLoadPnl(AbstractFileDisplayWithFieldHide pnl, HideFields hideFields)
/*     */   {
/* 233 */     String dir = Parameters.getFileName("FieldSaveDirectory");
/* 234 */     return new SaveLoadPnl(new SaveRestoreHiddenFields(pnl, hideFields), dir, EditorTask.class).panel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static void restoreHiddenFields(AbstractFileDisplayWithFieldHide pnl)
/*     */   {
/* 241 */     SaveRestoreHiddenFields action = new SaveRestoreHiddenFields(pnl, null);
/* 242 */     FileView fileView = pnl.getFileView();
/*     */     
/* 244 */     new ExecuteSavedFile(fileView.getBaseFile().getFileNameNoDirectory(), "Execute Saved Filter", fileView, Parameters.getFileName("FieldSaveDirectory"), action, EditorTask.class);
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/util/SaveRestoreHiddenFields.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */