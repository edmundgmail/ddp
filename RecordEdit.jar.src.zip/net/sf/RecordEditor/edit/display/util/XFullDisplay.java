/*    */ package net.sf.RecordEditor.edit.display.util;
/*    */ 
/*    */ import java.awt.Point;
/*    */ import java.awt.Rectangle;
/*    */ import java.io.PrintStream;
/*    */ import javax.swing.JScrollPane;
/*    */ import javax.swing.JTable;
/*    */ import javax.swing.JViewport;
/*    */ import net.sf.RecordEditor.re.file.FileView;
/*    */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*    */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class XFullDisplay
/*    */   extends ReFrame
/*    */ {
/*    */   public XFullDisplay(FileView t)
/*    */   {
/* 32 */     super(t.getFileNameNoDirectory(), "XX", t);
/*    */     
/* 34 */     BasePanel p = new BasePanel();
/* 35 */     JTable tbl = new JTable(t);
/* 36 */     JScrollPane scrollpane = new JScrollPane(tbl);
/* 37 */     p.addComponentRE(1, 5, -1.0D, BasePanel.GAP, 2, 2, scrollpane);
/*    */     
/*    */ 
/*    */ 
/* 41 */     super.addMainComponent(p);
/* 42 */     setVisible(true);
/* 43 */     setDefaultCloseOperation(2);
/*    */     
/* 45 */     System.out.println();
/* 46 */     System.out.println(scrollpane.getViewport().getHeight() + " " + scrollpane.getHeight() + " " + scrollpane.getViewport().getY() + " " + tbl.getVisibleRect().y + " " + tbl.getVisibleRect().height + " " + tbl.getRowHeight() + " " + tbl.rowAtPoint(new Point(5, tbl.getVisibleRect().height - 2)) + " " + tbl.rowAtPoint(new Point(1, 528000000)));
/*    */     
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 56 */     System.out.println(68);
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/util/XFullDisplay.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */