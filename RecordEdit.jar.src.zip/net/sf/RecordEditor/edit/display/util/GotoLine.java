/*     */ package net.sf.RecordEditor.edit.display.util;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JTextField;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*     */ import net.sf.RecordEditor.re.display.IChildDisplay;
/*     */ import net.sf.RecordEditor.re.file.FilePosition;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GotoLine
/*     */   extends ReFrame
/*     */   implements ActionListener, IChildDisplay
/*     */ {
/*     */   private AbstractFileDisplay source;
/*  33 */   private JTextField lineTxt = new JTextField(8);
/*  34 */   private JButton gotoBtn = SwingUtils.newButton("Goto");
/*  35 */   private BaseHelpPanel pnl = new BaseHelpPanel();
/*     */   
/*     */ 
/*  38 */   private KeyAdapter listner = new KeyAdapter()
/*     */   {
/*     */ 
/*     */     public final void keyReleased(KeyEvent event)
/*     */     {
/*     */ 
/*  44 */       switch (event.getKeyCode()) {
/*  45 */       case 10:  GotoLine.this.doGoto(); break;
/*  46 */       case 27:  GotoLine.this.doDefaultCloseAction();
/*     */       }
/*     */     }
/*     */   };
/*     */   
/*     */   public GotoLine(AbstractFileDisplay src, FileView master)
/*     */   {
/*  53 */     super(master.getFileNameNoDirectory(), "Goto Line", master);
/*     */     
/*  55 */     this.source = src;
/*     */     
/*     */ 
/*  58 */     this.pnl.addReKeyListener(this.listner);
/*     */     
/*  60 */     this.pnl.addLineRE("Line Number", this.lineTxt, this.gotoBtn);
/*  61 */     this.pnl.setGapRE(BasePanel.GAP1);
/*  62 */     this.pnl.addMessageRE();
/*     */     
/*  64 */     this.gotoBtn.addActionListener(this);
/*  65 */     this.pnl.addReKeyListener(this.listner);
/*     */     
/*  67 */     addMainComponent(this.pnl);
/*  68 */     setDefaultCloseOperation(2);
/*  69 */     setVisible(true);
/*  70 */     setToMaximum(false);
/*     */   }
/*     */   
/*     */ 
/*     */   public void actionPerformed(ActionEvent arg0)
/*     */   {
/*  76 */     if (arg0.getSource() == this.gotoBtn) {
/*  77 */       doGoto();
/*     */     }
/*     */   }
/*     */   
/*     */   private void doGoto() {
/*  82 */     String s = this.lineTxt.getText();
/*  83 */     if ("".equals(s)) {
/*  84 */       this.pnl.setMessageTxtRE("You must enter a line number");
/*     */     } else {
/*     */       try {
/*  87 */         int lineNo = Integer.parseInt(s);
/*  88 */         if (lineNo < 1) {
/*  89 */           this.pnl.setMessageTxtRE("line number must be > 0");
/*  90 */           return; }
/*  91 */         if (lineNo >= this.source.getFileView().getRowCount()) {
/*  92 */           this.pnl.setMessageRawTxtRE(LangConversion.convert("line number must be <") + " " + this.source.getFileView().getRowCount());
/*  93 */           return;
/*     */         }
/*  95 */         FilePosition position = new FilePosition(lineNo - 1, 0, this.source.getLayoutIndex(), 0, true, this.source.getFileView().getRowCount());
/*     */         
/*  97 */         this.source.setCurrRow(position);
/*     */         
/*  99 */         super.setVisible(false);
/* 100 */         super.doDefaultCloseAction();
/*     */       } catch (Exception e) {
/* 102 */         this.pnl.setMessageTxtRE("Invalid line number");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AbstractFileDisplay getSourceDisplay()
/*     */   {
/* 113 */     return this.source;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/util/GotoLine.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */