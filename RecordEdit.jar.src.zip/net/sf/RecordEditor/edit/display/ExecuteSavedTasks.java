/*     */ package net.sf.RecordEditor.edit.display;
/*     */ 
/*     */ import net.sf.RecordEditor.edit.display.util.HideFields;
/*     */ import net.sf.RecordEditor.edit.display.util.SaveRestoreHiddenFields;
/*     */ import net.sf.RecordEditor.edit.display.util.SortFrame;
/*     */ import net.sf.RecordEditor.jibx.compare.EditorTask;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplayWithFieldHide;
/*     */ import net.sf.RecordEditor.re.display.DisplayBuilderFactory;
/*     */ import net.sf.RecordEditor.re.display.IExecuteSaveAction;
/*     */ import net.sf.RecordEditor.re.display.IUpdateExecute;
/*     */ import net.sf.RecordEditor.re.display.ReChildFrame;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.re.file.filter.AbstractExecute;
/*     */ import net.sf.RecordEditor.re.file.filter.ExecuteSavedFile;
/*     */ import net.sf.RecordEditor.re.file.filter.ExecuteSavedFileBatch;
/*     */ import net.sf.RecordEditor.re.file.filter.FilterDetails;
/*     */ import net.sf.RecordEditor.re.script.CreateRecordTreePnl;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExecuteSavedTasks
/*     */   implements IExecuteSaveAction
/*     */ {
/*     */   private final BaseDisplay parentDisplay;
/*     */   private final FileView parentView;
/*     */   
/*     */   public ExecuteSavedTasks(BaseDisplay display, FileView fileView)
/*     */   {
/*  33 */     this.parentDisplay = display;
/*  34 */     this.parentView = fileView;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void executeSavedFilterDialog()
/*     */   {
/*  44 */     new ExecuteSavedFile(this.parentView.getBaseFile().getFileNameNoDirectory(), "Execute Saved Filter", this.parentView, Parameters.getFileName("FilterSaveDirectory"), getFilterAction(), EditorTask.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void executeSavedSortTreeDialog()
/*     */   {
/*  58 */     new ExecuteSavedFile(this.parentView.getBaseFile().getFileNameNoDirectory(), "Execute Saved Sort Tree", this.parentView, Parameters.getFileName("SortTreeSaveDirectory"), getSortTreeAction(), EditorTask.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void executeSavedRecordTreeDialog()
/*     */   {
/*  72 */     new ExecuteSavedFile(this.parentView.getBaseFile().getFileNameNoDirectory(), "Execute Saved Sort Tree", this.parentView, Parameters.getFileName("RecordTreeSaveDirectory"), getRecordTreeAction(), EditorTask.class);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final AbstractFileDisplay executeSavedTask(String fileName)
/*     */   {
/*  90 */     return new ExecuteSavedFileBatch(EditorTask.class, getTaskAction()).execAction(true, fileName);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final AbstractExecute<EditorTask> getFilterAction()
/*     */   {
/* 144 */     new AbstractExecute() {
/*     */       public AbstractFileDisplay execute(EditorTask details) {
/* 146 */         return ExecuteSavedTasks.this.executeFilter(details);
/*     */       }
/*     */       
/*     */       public void executeDialog(EditorTask details) {
/* 150 */         new FilterFrame(ExecuteSavedTasks.this.parentDisplay, ExecuteSavedTasks.this.parentView).updateFromExternalLayout(details.filter);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */ 
/*     */   public final AbstractExecute<EditorTask> getSortTreeAction()
/*     */   {
/* 158 */     new AbstractExecute() {
/*     */       public AbstractFileDisplay execute(EditorTask details) {
/* 160 */         CreateSortedTree treePnl = new CreateSortedTree(ExecuteSavedTasks.this.parentDisplay, ExecuteSavedTasks.this.parentView);
/* 161 */         treePnl.setFromSavedDetails(details);
/* 162 */         return treePnl.doAction();
/*     */       }
/*     */       
/*     */       public void executeDialog(EditorTask details) {
/* 166 */         new CreateSortedTree(ExecuteSavedTasks.this.parentDisplay, ExecuteSavedTasks.this.parentView).setFromSavedDetails(details);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   public final AbstractExecute<EditorTask> getRecordTreeAction()
/*     */   {
/* 173 */     new AbstractExecute() {
/*     */       public AbstractFileDisplay execute(EditorTask details) {
/* 175 */         CreateRecordTree treePnl = new CreateRecordTree(ExecuteSavedTasks.this.parentDisplay, ExecuteSavedTasks.this.parentView);
/* 176 */         treePnl.treeDisplay.setFromSavedDetails(details);
/* 177 */         return treePnl.doAction();
/*     */       }
/*     */       
/*     */       public void executeDialog(EditorTask details) {
/* 181 */         new CreateRecordTree(ExecuteSavedTasks.this.parentDisplay, ExecuteSavedTasks.this.parentView).treeDisplay.setFromSavedDetails(details);
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   public final AbstractExecute<EditorTask> getTaskAction()
/*     */   {
/* 188 */     new AbstractExecute() {
/*     */       public AbstractFileDisplay execute(EditorTask details) {
/* 190 */         return execTask(details, true);
/*     */       }
/*     */       
/*     */       public void executeDialog(EditorTask details) {
/* 194 */         execTask(details, false);
/*     */       }
/*     */       
/*     */       private AbstractFileDisplay execTask(EditorTask details, boolean execute) {
/* 198 */         IUpdateExecute<EditorTask> task = null;
/*     */         
/* 200 */         if ("Filter".equals(details.type)) {
/* 201 */           if (execute) {
/* 202 */             return ExecuteSavedTasks.this.executeFilter(details);
/*     */           }
/* 204 */           new FilterFrame(ExecuteSavedTasks.this.parentDisplay, ExecuteSavedTasks.this.parentView).updateFromExternalLayout(details.filter);
/*     */           
/* 206 */           return null; }
/* 207 */         if ("RecordTree".equals(details.type)) {
/* 208 */           task = new CreateRecordTree(ExecuteSavedTasks.this.parentDisplay, ExecuteSavedTasks.this.parentView);
/* 209 */         } else if ("SortTree".equals(details.type)) {
/* 210 */           task = new CreateSortedTree(ExecuteSavedTasks.this.parentDisplay, ExecuteSavedTasks.this.parentView);
/* 211 */         } else if ("Sort".equals(details.type)) {
/* 212 */           task = new SortFrame(ExecuteSavedTasks.this.parentDisplay, ExecuteSavedTasks.this.parentView);
/* 213 */         } else if ("FieldTree".equals(details.type)) {
/* 214 */           task = new CreateFieldTree(ExecuteSavedTasks.this.parentDisplay, ExecuteSavedTasks.this.parentView);
/* 215 */         } else { if (("VisibleFields".equals(details.type)) && ((ExecuteSavedTasks.this.parentDisplay instanceof AbstractFileDisplayWithFieldHide)))
/*     */           {
/* 217 */             AbstractFileDisplayWithFieldHide displ = (AbstractFileDisplayWithFieldHide)ExecuteSavedTasks.this.parentDisplay;
/* 218 */             HideFields hFields = new HideFields(displ);
/* 219 */             SaveRestoreHiddenFields sr = new SaveRestoreHiddenFields(displ, hFields);
/* 220 */             if (execute) {
/* 221 */               AbstractFileDisplay ret = sr.execute(details);
/*     */               
/* 223 */               hFields.updateSourcePanel();
/* 224 */               hFields.frame.doDefaultCloseAction();
/* 225 */               return ret;
/*     */             }
/* 227 */             sr.executeDialog(details);
/* 228 */             return null;
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 234 */           throw new RuntimeException("Task: " + details.type + " is not supported");
/*     */         }
/*     */         
/* 237 */         task.setFromSavedDetails(details);
/*     */         
/* 239 */         if (execute) {
/* 240 */           return task.doAction();
/*     */         }
/* 242 */         return null;
/*     */       }
/*     */     };
/*     */   }
/*     */   
/*     */   private AbstractFileDisplay executeFilter(EditorTask details)
/*     */   {
/* 249 */     FilterDetails filter = new FilterDetails(this.parentView.getLayout(), FilterDetails.FT_NORMAL);
/*     */     
/* 251 */     filter.updateFromExternalLayout(details.filter);
/* 252 */     FileView view = this.parentView.getFilteredView(filter);
/* 253 */     if (view == null) {
/* 254 */       Common.logMsg("No records matched the filter", null);
/*     */     } else {
/* 256 */       return DisplayBuilderFactory.newLineList(this.parentDisplay.getParentFrame(), view.getLayout(), view, view.getBaseFile());
/*     */     }
/* 258 */     return null;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/display/ExecuteSavedTasks.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */