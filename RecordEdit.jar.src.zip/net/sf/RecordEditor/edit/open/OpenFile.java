/*     */ package net.sf.RecordEditor.edit.open;
/*     */ 
/*     */ import java.awt.Container;
/*     */ import java.awt.Rectangle;
/*     */ import javax.swing.JButton;
/*     */ import net.sf.JRecord.IO.AbstractLineIOProvider;
/*     */ import net.sf.RecordEditor.re.openFile.AbstractLayoutSelection;
/*     */ import net.sf.RecordEditor.re.openFile.OpenFileInterface;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMainFrame;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OpenFile
/*     */   extends ReFrame
/*     */ {
/*     */   private OpenFileInterface openFilePanel;
/*  49 */   private static final int FRAME_WIDTH = SwingUtils.STANDARD_FONT_WIDTH * (Common.IS_NIX ? 78 : 74);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Rectangle frameSize;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public OpenFile(String pInFile, int pInitialRow, AbstractLineIOProvider pIoProvider, JButton layoutCreate1, JButton layoutCreate2, AbstractLayoutSelection selection)
/*     */   {
/*  78 */     this(1, pInFile, pInitialRow, pIoProvider, layoutCreate1, layoutCreate2, Parameters.getApplicationDirectory() + "Files.txt", "HlpRe02.htm", selection);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public OpenFile(int pFormat, String pInFile, int pInitialRow, AbstractLineIOProvider pIoProvider, JButton layoutCreate1, JButton layoutCreate2, String propertiesFiles, String helpScreen, AbstractLayoutSelection selection)
/*     */   {
/* 111 */     this(new OpenFileEditPnl(pFormat, pInFile, pInitialRow, pIoProvider, layoutCreate1, layoutCreate2, propertiesFiles, helpScreen, selection));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public OpenFile(OpenFileInterface openFile)
/*     */   {
/* 125 */     this(openFile, FRAME_WIDTH, -1);
/*     */   }
/*     */   
/*     */   public OpenFile(OpenFileInterface openFile, int width, int height) {
/* 129 */     super("", "Open File", "", null);
/*     */     
/*     */ 
/*     */ 
/* 133 */     this.openFilePanel = openFile;
/*     */     
/* 135 */     getContentPane().add(this.openFilePanel.getPanel());
/* 136 */     pack();
/*     */     
/* 138 */     ReMainFrame masterFrame = ReMainFrame.getMasterFrame();
/* 139 */     if (height < 0) {
/* 140 */       height = getHeight();
/*     */     }
/*     */     
/* 143 */     height = Math.min(height, masterFrame.getDesktopHeight() - 2);
/* 144 */     width = Math.min(width, masterFrame.getDesktopWidth() - 2);
/*     */     
/* 146 */     if (width > 0) {
/* 147 */       setBounds(1, getX(), width, height);
/*     */     }
/*     */     else {
/* 150 */       Rectangle screenSize = masterFrame.getBounds();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 160 */       setBounds(getY(), getX(), screenSize.width - 7, height);
/*     */     }
/*     */     
/* 163 */     this.frameSize = getBounds();
/*     */     
/* 165 */     setDefaultCloseOperation(1);
/*     */     
/*     */ 
/* 168 */     setVisible(true);
/*     */     
/* 170 */     setToMaximum(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setTheBounds()
/*     */   {
/* 216 */     setBounds(this.frameSize);
/* 217 */     setToMaximum(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final OpenFileInterface getOpenFilePanel()
/*     */   {
/* 225 */     return this.openFilePanel;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/open/OpenFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */