/*    */ package net.sf.RecordEditor.edit.open;
/*    */ 
/*    */ import javax.swing.JTextArea;
/*    */ import net.sf.RecordEditor.re.display.DisplayBuilderFactory;
/*    */ import net.sf.RecordEditor.re.display.IDisplayBuilder;
/*    */ import net.sf.RecordEditor.re.file.FileView;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ import net.sf.RecordEditor.utils.common.GcManager;
/*    */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*    */ import net.sf.RecordEditor.utils.params.BoolOpt;
/*    */ import net.sf.RecordEditor.utils.swing.EditingCancelled;
/*    */ 
/*    */ public class StartEditor
/*    */ {
/*    */   protected FileView file;
/*    */   protected String fName;
/*    */   private boolean pBrowse;
/* 18 */   protected boolean ok = false;
/*    */   
/*    */ 
/*    */   private JTextArea message;
/*    */   
/*    */ 
/*    */   private int initialRow;
/*    */   
/*    */ 
/*    */   public StartEditor(FileView file, String name, boolean browse, JTextArea messageFld, int startRow)
/*    */   {
/* 29 */     this.file = file;
/* 30 */     this.fName = name;
/* 31 */     this.pBrowse = browse;
/* 32 */     this.message = messageFld;
/* 33 */     this.initialRow = startRow;
/*    */   }
/*    */   
/*    */   public void doEdit() {
/* 37 */     if (Common.OPTIONS.loadInBackgroundThread.isSelected()) {
/*    */       try {
/* 39 */         GcManager.doGcIfNeccessary(0.5D);
/* 40 */         new StartEditorBackGround(this).execute();
/* 41 */         return;
/*    */       }
/*    */       catch (NoClassDefFoundError e) {}
/*    */     }
/* 45 */     doRead();
/* 46 */     done();
/*    */   }
/*    */   
/*    */   public void doRead() {
/*    */     try {
/* 51 */       this.file.readFile(this.fName);
/* 52 */       this.ok = true;
/*    */ 
/*    */ 
/*    */     }
/*    */     catch (EditingCancelled e)
/*    */     {
/*    */ 
/*    */ 
/* 60 */       this.message.setText(e.getMessage());
/*    */     } catch (Exception e) {
/* 62 */       this.message.setText(LangConversion.convert("Error Reading the File:") + " " + e.toString());
/* 63 */       Common.logMsgRaw(e.getMessage(), e);
/* 64 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */   public void done()
/*    */   {
/* 71 */     if (this.ok) {
/* 72 */       int opt = 1;
/* 73 */       if (this.pBrowse) {
/* 74 */         opt = 2;
/*    */       }
/*    */       
/* 77 */       DisplayBuilderFactory.getInstance().newDisplay(opt, "", null, this.file.getLayout(), this.file, this.initialRow);
/*    */       
/* 79 */       this.message.setText(this.file.getMsg());
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/open/StartEditor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */