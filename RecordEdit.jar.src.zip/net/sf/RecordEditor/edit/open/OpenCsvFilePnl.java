/*     */ package net.sf.RecordEditor.edit.open;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.io.File;
/*     */ import java.net.URL;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JSplitPane;
/*     */ import javax.swing.JTabbedPane;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ import javax.swing.filechooser.FileFilter;
/*     */ import javax.swing.filechooser.FileNameExtensionFilter;
/*     */ import net.sf.JRecord.Details.LayoutDetail;
/*     */ import net.sf.JRecord.IO.AbstractLineIOProvider;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.re.openFile.FormatFileName;
/*     */ import net.sf.RecordEditor.re.openFile.OpenFileInterface;
/*     */ import net.sf.RecordEditor.re.openFile.RecentFiles;
/*     */ import net.sf.RecordEditor.re.openFile.RecentFilesList;
/*     */ import net.sf.RecordEditor.re.util.csv.CsvSelectionPanel;
/*     */ import net.sf.RecordEditor.re.util.csv.CsvTabPane;
/*     */ import net.sf.RecordEditor.re.util.csv.FilePreview;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.params.BoolOpt;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions.FileNameOpt;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.swing.filechooser.IFileChooserWrapper;
/*     */ import net.sf.RecordEditor.utils.swing.filechooser.JRFileChooserWrapper;
/*     */ 
/*     */ 
/*     */ public class OpenCsvFilePnl
/*     */   extends BaseHelpPanel
/*     */   implements OpenFileInterface, FormatFileName
/*     */ {
/*     */   private static final int NORMAL_CSV = 0;
/*     */   private static final int UNICODE_CSV = 1;
/*  53 */   private final BoolOpt showCsvFChooserOptions = new BoolOpt("ShowFileChooserOptions", Parameters.isWindowsLAF());
/*     */   
/*     */ 
/*     */   private final IFileChooserWrapper chooser;
/*     */   
/*     */ 
/*     */   protected RecentFiles recent;
/*     */   
/*     */   private RecentFilesList recentList;
/*     */   
/*  63 */   private JTextArea msgTxt = new JTextArea();
/*     */   
/*     */   private AbstractLineIOProvider ioProvider;
/*     */   
/*     */   private final CsvTabPane csvTabDtls;
/*     */   
/*     */   private FileFilter csvFilter;
/*     */   
/*  71 */   private boolean execEnter = true;
/*     */   
/*  73 */   public final KeyAdapter keyListner = new KeyAdapter()
/*     */   {
/*     */ 
/*     */     public final void keyReleased(KeyEvent event)
/*     */     {
/*     */ 
/*  79 */       if ((OpenCsvFilePnl.this.execEnter) && (event.getKeyCode() == 10))
/*     */       {
/*  81 */         OpenCsvFilePnl.this.openFile(false);
/*     */       }
/*     */     }
/*     */   };
/*     */   
/*  86 */   private PropertyChangeListener chgListner = new PropertyChangeListener() {
/*  87 */     private String lastFileName = "";
/*     */     
/*     */     public void propertyChange(PropertyChangeEvent e)
/*     */     {
/*  91 */       String pname = e.getPropertyName();
/*     */       
/*     */ 
/*  94 */       if ("SelectedFileChangedProperty".equals(pname)) {
/*  95 */         File f = (File)e.getNewValue();
/*     */         
/*  97 */         if ((f != null) && (f.isFile()) && (!this.lastFileName.equals(f.getPath()))) {
/*  98 */           this.lastFileName = f.getPath();
/*  99 */           OpenCsvFilePnl.this.readFilePreview(f, true);
/*     */         }
/*     */       }
/*     */     }
/*     */   };
/*     */   
/* 105 */   private ActionListener goAction = new ActionListener()
/*     */   {
/*     */     public void actionPerformed(ActionEvent arg0)
/*     */     {
/* 109 */       OpenCsvFilePnl.this.openFile(true);
/*     */     }
/*     */   };
/*     */   
/* 113 */   private ActionListener chooserListner = new ActionListener()
/*     */   {
/*     */ 
/*     */ 
/*     */     public void actionPerformed(ActionEvent evt)
/*     */     {
/*     */ 
/*     */ 
/* 121 */       if ("ApproveSelection".equals(evt.getActionCommand()))
/*     */       {
/* 123 */         OpenCsvFilePnl.this.openFile(false);
/* 124 */       } else if (!"CancelSelection".equals(evt.getActionCommand())) {}
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/* 130 */   private ChangeListener tabListner = new ChangeListener()
/*     */   {
/*     */ 
/*     */     public void stateChanged(ChangeEvent e)
/*     */     {
/*     */ 
/* 136 */       OpenCsvFilePnl.this.csvTabDtls.tab.removeChangeListener(this);
/* 137 */       int idx = OpenCsvFilePnl.this.csvTabDtls.tab.getSelectedIndex();
/*     */       
/*     */ 
/* 140 */       OpenCsvFilePnl.this.execEnter();
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 148 */       OpenCsvFilePnl.this.execEnter = true;
/*     */       
/* 150 */       OpenCsvFilePnl.this.csvTabDtls.tab.setSelectedIndex(idx);
/* 151 */       OpenCsvFilePnl.this.readFilePreview(OpenCsvFilePnl.this.chooser.getFileChooser().getSelectedFile(), false);
/* 152 */       OpenCsvFilePnl.this.csvTabDtls.tab.addChangeListener(this);
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public OpenCsvFilePnl(String fileName, String propertiesFiles, AbstractLineIOProvider pIoProvider, boolean fixedXmlTabs)
/*     */   {
/* 161 */     String defaultDirectory = Common.OPTIONS.DEFAULT_FILE_DIRECTORY.get();
/*     */     
/* 163 */     this.ioProvider = pIoProvider;
/* 164 */     this.recent = new RecentFiles(propertiesFiles, this, true, defaultDirectory);
/* 165 */     this.recentList = new RecentFilesList(this.recent, this, true);
/* 166 */     this.csvTabDtls = new CsvTabPane(this.msgTxt, fixedXmlTabs, true);
/*     */     
/* 168 */     boolean filePresent = true;
/*     */     
/* 170 */     String fname = fileName;
/* 171 */     URL helpname = Common.formatHelpURL("HlpCsv02.htm");
/* 172 */     if ((fname == null) && (Common.OPTIONS.useLastDir.isSelected())) {
/* 173 */       fname = this.recent.getLastDirectory();
/*     */     }
/* 175 */     if ((fname == null) || ("".equals(fname))) {
/* 176 */       fname = defaultDirectory;
/* 177 */       filePresent = false;
/*     */     }
/*     */     
/* 180 */     File file = null;
/* 181 */     if (fname != null) {
/* 182 */       file = adjustForDirectory(fname);
/*     */       
/* 184 */       fname = file.getPath();
/*     */     }
/*     */     
/* 187 */     this.chooser = JRFileChooserWrapper.newChooserCsvEditor(ReFrame.getDesktopWidth(), fname, this.recent.getDirectoryList());
/*     */     
/*     */ 
/* 190 */     setHelpURLre(helpname);
/* 191 */     setTab(this.csvTabDtls.csvDetails, helpname);
/* 192 */     setTab(this.csvTabDtls.unicodeCsvDetails, helpname);
/*     */     
/* 194 */     if (fixedXmlTabs) {
/* 195 */       setTab(this.csvTabDtls.fixedSelectionPanel, helpname);
/* 196 */       setTab(this.csvTabDtls.xmlSelectionPanel, helpname);
/* 197 */       setTab(this.csvTabDtls.otherSelectionPanel, helpname);
/*     */     }
/*     */     
/* 200 */     registerComponentRE(this.chooser.getDisplayItem());
/* 201 */     registerComponentRE(this.csvTabDtls.tab);
/*     */     
/*     */ 
/* 204 */     JFileChooser fc = this.chooser.getFileChooser();
/* 205 */     fc.addActionListener(this.chooserListner);
/*     */     try
/*     */     {
/* 208 */       FileFilter filter = fc.getFileFilter();
/*     */       
/* 210 */       this.csvFilter = new FileNameExtensionFilter("CSV file", new String[] { "csv", "tsv" });
/* 211 */       fc.addChoosableFileFilter(new FileNameExtensionFilter("Text file", new String[] { "txt" }));
/* 212 */       fc.addChoosableFileFilter(this.csvFilter);
/* 213 */       fc.addChoosableFileFilter(new FileNameExtensionFilter("CSV/Text file", new String[] { "csv", "tsv", "txt" }));
/*     */       
/* 215 */       if (fixedXmlTabs) {
/* 216 */         fc.addChoosableFileFilter(new FileNameExtensionFilter("CSV/XML file", new String[] { "csv", "tsv", "xml" }));
/* 217 */         fc.addChoosableFileFilter(new FileNameExtensionFilter("Xml file", new String[] { "xml" }));
/*     */       }
/* 219 */       fc.setFileFilter(filter);
/*     */     }
/*     */     catch (NoClassDefFoundError e) {}
/*     */     
/*     */ 
/*     */ 
/* 225 */     SwingUtils.addKeyListnerToContainer(this.chooser.getDisplayItem(), this.keyListner);
/* 226 */     SwingUtils.addKeyListnerToContainer(this.csvTabDtls.tab, this.keyListner);
/*     */     
/* 228 */     fc.addPropertyChangeListener(this.chgListner);
/* 229 */     if (this.showCsvFChooserOptions.isSelected()) {
/* 230 */       fc.setDialogType(0);
/*     */     } else {
/* 232 */       fc.setControlButtonsAreShown(false);
/*     */     }
/* 234 */     this.csvTabDtls.tab.addChangeListener(this.tabListner);
/*     */     
/* 236 */     if ((filePresent) && (fname != null) && (file.isFile())) {
/* 237 */       readFilePreview(file, true);
/*     */     }
/*     */   }
/*     */   
/*     */   private void setTab(FilePreview pnl, URL helpname) {
/* 242 */     JButton go = pnl.getGoButton();
/*     */     
/* 244 */     pnl.getPanel().setHelpURLre(helpname);
/*     */     
/* 246 */     go.setIcon(Common.getRecordIcon(12));
/*     */     
/* 248 */     go.setText(LangConversion.convert(8, "Edit"));
/* 249 */     go.addActionListener(this.goAction);
/*     */   }
/*     */   
/*     */   private void openFile(boolean executeEnter)
/*     */   {
/* 254 */     JFileChooser fc = this.chooser.getFileChooser();
/* 255 */     File f = fc.getSelectedFile();
/*     */     try
/*     */     {
/* 258 */       if (executeEnter) {
/* 259 */         execEnter();
/*     */       }
/* 261 */       File f1 = fc.getSelectedFile();
/* 262 */       if (!f1.equals(f)) {
/* 263 */         f = f1;
/* 264 */         readFilePreview(f, true);
/*     */       }
/*     */     }
/*     */     catch (Exception ex) {}
/*     */     
/*     */ 
/* 270 */     FilePreview csvpnl = this.csvTabDtls.getSelectedCsvDetails();
/* 271 */     if ((f != null) && (f.getPath() != null)) {
/*     */       try {
/* 273 */         LayoutDetail l = csvpnl.getLayout(csvpnl.getFontName(), null);
/*     */         
/* 275 */         if (l != null) {
/* 276 */           FileView file = new FileView(l, this.ioProvider, false);
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 281 */           StartEditor startEditor = new StartEditor(file, f.getPath(), false, this.msgTxt, 0);
/*     */           
/* 283 */           this.recent.putFileLayout(f.getPath(), csvpnl.getFileDescription());
/* 284 */           this.chooser.updateRecentDirectories(this.recent.getDirectoryList());
/*     */           
/* 286 */           startEditor.doEdit();
/*     */         }
/*     */       } catch (Exception e) {
/* 289 */         Common.logMsg(30, "Error Loading File:", e.getMessage(), null);
/* 290 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   private void execEnter()
/*     */   {
/* 298 */     JFileChooser fc = this.chooser.getFileChooser();
/* 299 */     fc.removeActionListener(this.chooserListner);
/* 300 */     SwingUtils.clickOpenBtn(fc, true);
/*     */     
/* 302 */     this.chooser.addActionListener(this.chooserListner);
/*     */   }
/*     */   
/*     */   public void done()
/*     */   {
/* 307 */     addComponentRE(0, 5, -1.0D, BasePanel.GAP, 2, 2, new JSplitPane(1, this.chooser.getDisplayItem(), this.csvTabDtls.tab));
/*     */     
/*     */ 
/* 310 */     addMessage(this.msgTxt);
/* 311 */     setHeightRE(BasePanel.NORMAL_HEIGHT * 3.0D);
/*     */     
/* 313 */     super.done();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getCurrentDbIdentifier()
/*     */   {
/* 320 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getCurrentDbName()
/*     */   {
/* 327 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getCurrentFileName()
/*     */   {
/* 334 */     return this.chooser.getFileChooser().getSelectedFile().getPath();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setRecordLayout(int layoutId, String layoutName, String filename)
/*     */   {
/* 341 */     JFileChooser fc = this.chooser.getFileChooser();
/*     */     try {
/* 343 */       fc.removeActionListener(this.chooserListner);
/* 344 */       fc.removePropertyChangeListener(this.chgListner);
/* 345 */       this.csvTabDtls.tab.removeChangeListener(this.tabListner);
/*     */       
/* 347 */       File file = adjustForDirectory(filename);
/* 348 */       fc.setSelectedFile(file);
/* 349 */       if ((layoutName != null) && (!"".equals(layoutName)))
/*     */       {
/*     */ 
/* 352 */         if (layoutName.startsWith("CSV")) {
/* 353 */           this.csvTabDtls.csvDetails.setFileDescription(layoutName);
/* 354 */           this.csvTabDtls.tab.setSelectedIndex(0);
/*     */         } else {
/* 356 */           this.csvTabDtls.unicodeCsvDetails.setFileDescription(layoutName);
/* 357 */           this.csvTabDtls.tab.setSelectedIndex(1);
/*     */         }
/* 359 */         this.csvTabDtls.readCheckPreview(file, false, layoutName);
/*     */       }
/*     */     } catch (Exception e) {
/* 362 */       e.printStackTrace();
/*     */     } finally {
/* 364 */       this.chooser.addActionListener(this.chooserListner);
/* 365 */       fc.addPropertyChangeListener(this.chgListner);
/* 366 */       this.csvTabDtls.tab.addChangeListener(this.tabListner);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public BasePanel getPanel()
/*     */   {
/* 374 */     return this;
/*     */   }
/*     */   
/*     */   public final void selectCsvExt() {
/* 378 */     if (this.csvFilter != null) {
/* 379 */       this.chooser.getFileChooser().setFileFilter(this.csvFilter);
/*     */     }
/*     */   }
/*     */   
/*     */   private File adjustForDirectory(String filenmae) {
/* 384 */     File file = new File(filenmae);
/* 385 */     if (file.isDirectory()) {
/* 386 */       String pathname = file.getPath() + Common.FILE_SEPERATOR + "*";
/* 387 */       file = new File(pathname);
/*     */     }
/* 389 */     return file;
/*     */   }
/*     */   
/*     */   private void readFilePreview(File f, boolean allowTabSwap) {
/* 393 */     String layoutDtls = null;
/*     */     try {
/* 395 */       layoutDtls = this.recent.getLayoutName(f.getCanonicalPath(), f);
/*     */     }
/*     */     catch (Exception e) {}
/*     */     
/* 399 */     Rectangle r = getBounds();
/* 400 */     setPreferredSize(new Dimension(r.width, r.height));
/*     */     
/*     */ 
/* 403 */     this.csvTabDtls.readCheckPreview(f, allowTabSwap, layoutDtls);
/*     */     
/* 405 */     super.validate();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public JMenu getRecentFileMenu()
/*     */   {
/* 413 */     return this.recentList.getMenu();
/*     */   }
/*     */   
/*     */ 
/*     */   public JMenu getRecentDirectoryMenu()
/*     */   {
/* 419 */     return this.recentList.getDirectoryMenu();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String formatLayoutName(String layoutName)
/*     */   {
/* 429 */     return layoutName;
/*     */   }
/*     */   
/*     */   public void setParentFrame(ReFrame parentFrame) {
/* 433 */     this.csvTabDtls.setParentFrame(parentFrame);
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/open/OpenCsvFilePnl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */