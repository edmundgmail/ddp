/*    */ package net.sf.RecordEditor.edit.open;
/*    */ 
/*    */ import javax.swing.SwingWorker;
/*    */ import net.sf.RecordEditor.utils.common.Common;
/*    */ import net.sf.RecordEditor.utils.params.BoolOpt;
/*    */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*    */ 
/*    */ public class StartEditorBackGround
/*    */   extends SwingWorker<Void, Void>
/*    */ {
/*    */   StartEditor startEditor;
/*    */   
/*    */   public StartEditorBackGround(StartEditor startEd)
/*    */   {
/* 15 */     this.startEditor = startEd;
/*    */   }
/*    */   
/*    */   public void doEdit() {
/* 19 */     if (Common.OPTIONS.loadInBackgroundThread.isSelected()) {
/* 20 */       execute();
/*    */     } else {
/* 22 */       doInBackground();
/* 23 */       done();
/*    */     }
/*    */   }
/*    */   
/*    */   public Void doInBackground()
/*    */   {
/* 29 */     this.startEditor.doRead();
/* 30 */     return null;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void done()
/*    */   {
/* 37 */     this.startEditor.done();
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/open/StartEditorBackGround.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */