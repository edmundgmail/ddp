/*     */ package net.sf.RecordEditor.edit.open;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JPanel;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.IO.AbstractLineIOProvider;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.re.openFile.AbstractLayoutSelection;
/*     */ import net.sf.RecordEditor.re.openFile.AbstractOpenFilePnl;
/*     */ import net.sf.RecordEditor.re.openFile.IOpenFileExtended;
/*     */ import net.sf.RecordEditor.re.openFile.RecentFiles;
/*     */ import net.sf.RecordEditor.re.openFile.RecentFilesList;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.TreeComboFileSelect;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OpenFileEditPnl
/*     */   extends AbstractOpenFilePnl
/*     */   implements ActionListener, IOpenFileExtended
/*     */ {
/*     */   private int initialRow;
/*  59 */   private JPanel goPanel = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JButton browse;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JButton edit;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private JPanel nullComponent;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private RecentFilesList recentList;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public OpenFileEditPnl(int format, String pInFile, int pInitialRow, AbstractLineIOProvider pIoProvider, JButton layoutCreate1, JButton layoutCreate2, String propertiesFiles, String helpScreen, AbstractLayoutSelection newLayoutSelection)
/*     */   {
/* 115 */     super(format, pInFile, pIoProvider, layoutCreate1, layoutCreate2, propertiesFiles, helpScreen, newLayoutSelection);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 124 */     this.initialRow = (pInitialRow - 1);
/*     */     
/* 126 */     newLayoutSelection.setExecuteAction(this);
/*     */     
/* 128 */     this.recentList = new RecentFilesList(this.recent, this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void processFile(String sFileName, AbstractLayoutDetails layoutDetails, AbstractLineIOProvider ioProvider, boolean pBrowse)
/*     */     throws Exception
/*     */   {
/* 141 */     FileView file = new FileView(layoutDetails, ioProvider, pBrowse);
/*     */     
/*     */ 
/* 144 */     StartEditorExtended startEditor = new StartEditorExtended(file, sFileName, pBrowse);
/*     */     
/* 146 */     startEditor.doEdit();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void actionPerformed(ActionEvent e)
/*     */   {
/* 188 */     if ((e.getSource() == this.edit) || (e.getSource() == this.browse))
/*     */     {
/* 190 */       loadFile(e.getSource() == this.browse);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   protected JPanel getGoPanel()
/*     */   {
/* 198 */     if (this.goPanel == null) {
/* 199 */       this.goPanel = new JPanel();
/* 200 */       this.browse = SwingUtils.newButton("Browse", Common.getRecordIcon(12));
/* 201 */       this.edit = SwingUtils.newButton("Edit", Common.getRecordIcon(12));
/*     */       
/* 203 */       this.nullComponent = new JPanel();
/*     */       
/* 205 */       this.goPanel.setLayout(new BorderLayout());
/* 206 */       this.goPanel.add("North", this.edit);
/* 207 */       this.goPanel.add("Center", this.nullComponent);
/* 208 */       this.goPanel.add("South", this.browse);
/*     */       
/* 210 */       this.browse.addActionListener(this);
/* 211 */       this.edit.addActionListener(this);
/*     */     }
/* 213 */     return this.goPanel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getCurrentDbIdentifier()
/*     */   {
/* 221 */     return getLayoutSelection().getDatabaseIdx();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getCurrentDbName()
/*     */   {
/* 229 */     return getLayoutSelection().getDatabaseName();
/*     */   }
/*     */   
/*     */ 
/*     */   public BasePanel getPanel()
/*     */   {
/* 235 */     return this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRecordLayout(int recordId, String layoutName, String newFileName)
/*     */   {
/* 243 */     super.setDoListener(false);
/*     */     
/* 245 */     AbstractLayoutSelection selection = getLayoutSelection();
/*     */     
/* 247 */     selection.reload();
/*     */     
/* 249 */     if ((newFileName != null) && (!"".equals(newFileName))) {
/* 250 */       this.fileName.setText(newFileName);
/* 251 */       selection.setLayoutName(layoutName);
/* 252 */       loadFile(false);
/*     */     } else {
/* 254 */       selection.setLayoutName(layoutName);
/*     */     }
/* 256 */     super.setDoListener(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final JMenu getRecentFileMenu()
/*     */   {
/* 265 */     return this.recentList.getMenu();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public JMenu getRecentDirectoryMenu()
/*     */   {
/* 273 */     return this.recentList.getDirectoryMenu();
/*     */   }
/*     */   
/*     */ 
/*     */   private class StartEditorExtended
/*     */     extends StartEditor
/*     */   {
/*     */     public StartEditorExtended(FileView file, String name, boolean browse)
/*     */     {
/* 282 */       super(name, browse, OpenFileEditPnl.this.message, OpenFileEditPnl.this.initialRow);
/*     */     }
/*     */     
/*     */ 
/*     */     public void done()
/*     */     {
/* 288 */       if (this.ok) {
/* 289 */         super.done();
/*     */         try
/*     */         {
/* 292 */           if ("".equals(this.file.getMsg())) {
/* 293 */             String layoutName = OpenFileEditPnl.this.getCurrentLayout();
/*     */             
/*     */ 
/* 296 */             OpenFileEditPnl.this.recent.putFileLayout(this.fName, layoutName);
/*     */           }
/*     */         }
/*     */         catch (Exception e) {
/* 300 */           Common.logMsg(30, "Error Updating Recent-History file", e.getMessage(), null);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/open/OpenFileEditPnl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */