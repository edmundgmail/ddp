/*    */ package net.sf.RecordEditor.edit;
/*    */ 
/*    */ import net.sf.JRecord.Common.CommonBits;
/*    */ import net.sf.JRecord.Common.Conversion;
/*    */ import net.sf.JRecord.CsvParser.ParserManager;
/*    */ import net.sf.RecordEditor.utils.params.Parameters;
/*    */ 
/*    */ public class EditCommon
/*    */ {
/*    */   public static void doStandardInit()
/*    */   {
/* 12 */     ParserManager.setUseNewCsvParsers(true);
/* 13 */     CommonBits.setUseCsvLine(false);
/*    */     
/* 15 */     if (Conversion.DEFAULT_CHARSET_DETAILS.isMultiByte) {
/* 16 */       String s = Parameters.getString("defaultSingleByteCharset");
/* 17 */       if ((s != null) && (s.length() > 0)) {
/* 18 */         Conversion.setDefaultSingleByteCharacterset(s);
/* 19 */         s = Parameters.getString("useDefaultSingleByteCharset");
/* 20 */         Conversion.setAlwaysUseDefaultSingByteCharset("y".equalsIgnoreCase(s));
/*    */       }
/*    */     }
/*    */     
/* 24 */     String s = Parameters.getString("defaultEbcidicCharset");
/* 25 */     if ((s != null) && (s.length() > 0)) {
/* 26 */       Conversion.setDefaultEbcidicCharacterset(s);
/*    */     }
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/EditCommon.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */