/*     */ package net.sf.RecordEditor.edit.util;
/*     */ 
/*     */ import java.awt.Container;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JEditorPane;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextArea;
/*     */ import net.sf.RecordEditor.re.openFile.LayoutSelectionDB;
/*     */ import net.sf.RecordEditor.re.openFile.RecentFiles;
/*     */ import net.sf.RecordEditor.re.script.RunVelocity;
/*     */ import net.sf.RecordEditor.utils.CopyBookDbReader;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions.FileNameOpt;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions.FileNameOptWithDefault;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMsgId;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.FileSelectCombo;
/*     */ import net.sf.RecordEditor.utils.swing.treeCombo.TreeComboFileSelect;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RunVelocityGui
/*     */   implements ActionListener
/*     */ {
/*  39 */   private static final int NOT_INSTALLED_MSG_HEIGHT = SwingUtils.STANDARD_FONT_HEIGHT * 25;
/*     */   
/*  41 */   private JFrame frame = new JFrame();
/*  42 */   private BasePanel pnl = new BasePanel();
/*     */   
/*  44 */   private JPanel runPanel = new JPanel();
/*  45 */   private TreeComboFileSelect inputFile = new TreeComboFileSelect(true, false, true, RecentFiles.getMainRecentFile());
/*  46 */   private FileSelectCombo templateFile = new FileSelectCombo("VelocitySkels.", 35, true, false);
/*     */   
/*  48 */   private TreeComboFileSelect outputFile = new TreeComboFileSelect(false, false, true, this.inputFile);
/*     */   
/*  50 */   private JButton runBtn = SwingUtils.newButton("Run");
/*  51 */   private JTextArea message = new JTextArea();
/*     */   
/*     */ 
/*  54 */   private CopyBookDbReader copybookReader = CopyBookDbReader.getInstance();
/*     */   
/*     */ 
/*     */ 
/*     */   private LayoutSelectionDB layoutSelection;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public RunVelocityGui()
/*     */   {
/*  65 */     if (Common.isVelocityAvailable()) {
/*  66 */       init_100_SetupScreenFields();
/*  67 */       init_200_BuildScreen();
/*     */     } else {
/*  69 */       init_300_BuildNoVelocityScreen();
/*     */     }
/*     */     
/*  72 */     this.frame.getContentPane().add(this.pnl);
/*  73 */     this.frame.pack();
/*  74 */     this.frame.setDefaultCloseOperation(3);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_100_SetupScreenFields()
/*     */   {
/*  83 */     this.layoutSelection = new LayoutSelectionDB(this.copybookReader, this.message, false);
/*  84 */     this.inputFile.setText(Common.OPTIONS.DEFAULT_FILE_DIRECTORY.getWithStar());
/*  85 */     this.templateFile.setText(Common.OPTIONS.DEFAULT_VELOCITY_DIRECTORY.get());
/*     */     
/*  87 */     this.runBtn.addActionListener(this);
/*     */     
/*  89 */     this.frame.addWindowListener(new WindowAdapter()
/*     */     {
/*     */       public void windowClosed(WindowEvent e) {}
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_200_BuildScreen()
/*     */   {
/* 102 */     this.pnl.addLineRE("Input File", this.inputFile);
/* 103 */     this.pnl.addLineRE("Template File", this.templateFile);
/* 104 */     this.pnl.setGapRE(BasePanel.GAP1);
/*     */     
/* 106 */     this.layoutSelection.addLayoutSelection(this.pnl, this.inputFile, this.runPanel, null, null);
/* 107 */     this.pnl.setGapRE(BasePanel.GAP1);
/*     */     
/* 109 */     this.pnl.addLineRE("Output File", this.outputFile);
/* 110 */     this.pnl.setGapRE(BasePanel.GAP2);
/*     */     
/* 112 */     this.pnl.addLineRE("", null, this.runBtn);
/* 113 */     this.pnl.setGapRE(BasePanel.GAP2);
/*     */     
/* 115 */     this.pnl.addMessage(this.message);
/* 116 */     this.pnl.setHeightRE(BasePanel.GAP2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void init_300_BuildNoVelocityScreen()
/*     */   {
/* 125 */     JEditorPane description = new JEditorPane("text/html", ReMessages.VELOCITY_NOT_INSTALLED.get());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 139 */     this.pnl.addComponentRE(1, 5, NOT_INSTALLED_MSG_HEIGHT, BasePanel.GAP0, 2, 2, description);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void actionPerformed(ActionEvent e)
/*     */   {
/* 150 */     this.message.setText("");
/* 151 */     if (e.getSource() == this.runBtn) {
/* 152 */       if ("".equals(this.inputFile.getText().trim())) {
/* 153 */         this.pnl.setMessageTxtRE("You must enter an input file");
/* 154 */         this.inputFile.requestFocus();
/* 155 */       } else if ("".equals(this.templateFile.getText().trim())) {
/* 156 */         this.pnl.setMessageTxtRE("You must enter a Velocity Template file");
/* 157 */         this.templateFile.requestFocus();
/* 158 */       } else if ("".equals(this.outputFile.getText().trim())) {
/* 159 */         this.pnl.setMessageTxtRE("You must enter an Output file");
/* 160 */         this.outputFile.requestFocus();
/*     */       } else {
/* 162 */         RunVelocity velocity = RunVelocity.getInstance();
/*     */         try
/*     */         {
/* 165 */           velocity.processFile(this.layoutSelection.getRecordLayout(""), this.inputFile.getText(), this.templateFile.getText(), this.outputFile.getText());
/*     */         }
/*     */         catch (Exception ex) {
/* 168 */           this.message.setText(ex.getMessage());
/* 169 */           ex.printStackTrace();
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPgmArgs(String[] pgmArgs)
/*     */   {
/* 180 */     this.frame.setVisible(true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void main(String[] pgmArgs)
/*     */   {
/* 190 */     new RunVelocityGui().setPgmArgs(null);
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/util/RunVelocityGui.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */