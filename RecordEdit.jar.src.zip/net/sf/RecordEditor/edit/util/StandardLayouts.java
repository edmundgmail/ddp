/*     */ package net.sf.RecordEditor.edit.util;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.List;
/*     */ import net.sf.JRecord.Common.TranslateXmlChars;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.External.Def.ExternalField;
/*     */ import net.sf.JRecord.External.ExternalRecord;
/*     */ import net.sf.JRecord.External.RecordEditorXmlLoader;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StandardLayouts
/*     */ {
/*     */   private static final String ERROR_CREATING_LAYOUT = "Internal Error Creating Layout:";
/*  18 */   private static StandardLayouts instance = new StandardLayouts();
/*     */   
/*  20 */   private static final ExternalRecord xmlExternalRec = getExternal("<RECORD RECORDNAME=\"XML - Build Layout\" COPYBOOK=\"\" DELIMITER=\"|\"  DESCRIPTION=\"XML file, build the layout based on the files contents\" FILESTRUCTURE=\"XML_Build_Layout\" STYLE=\"0\" RECORDTYPE=\"XML\" LIST=\"Y\"  QUOTE=\"'\" RecSep=\"default\" LINE_NO_FIELD_NAMES=\"1\">  <TSTFIELDS></TSTFIELDS><FIELDS><FIELD NAME=\"Dummy\"  DESCRIPTION=\"1 field is Required for the layout to load\"  POSITION=\"1\" TYPE=\"Char\"/></FIELDS></RECORD>", "Build Xml");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  34 */   private static final ExternalRecord genericCsvExternalRec = getExternal("<RECORD RECORDNAME=\"Generic CSV - enter details\" COPYBOOK=\"\" DELIMITER=\"|\" DESCRIPTION=\"Generic CSV - user supplies details\" FILESTRUCTURE=\"CSV_GENERIC\" STYLE=\"0\" RECORDTYPE=\"Delimited\" LIST=\"Y\" QUOTE=\"\" RecSep=\"default\"><FIELDS><FIELD NAME=\"Field 1\" POSITION=\"1\" TYPE=\"Char\"/></FIELDS></RECORD>", "Generic Csv");
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final AbstractLayoutDetails getXmlLayout()
/*     */   {
/*  46 */     return getLayout(xmlExternalRec);
/*     */   }
/*     */   
/*     */   public final AbstractLayoutDetails getGenericCsvLayout() {
/*  50 */     return getLayout(genericCsvExternalRec);
/*     */   }
/*     */   
/*     */   public final AbstractLayoutDetails getCsvLayoutNamesFirstLine(String delim, String charset, String quote, boolean embeddedCr) {
/*  54 */     return getLayout(getCsvExternal("CSV_NAME_1ST_LINE", delim, charset, quote, embeddedCr));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final AbstractLayoutDetails getCsvLayout(List<ExternalField> fields, String fileStructure, String delim, String charset, String quote, boolean embeddedCr)
/*     */   {
/*  66 */     ExternalRecord rec = getCsvExternal(fileStructure, delim, charset, quote, embeddedCr);
/*     */     
/*  68 */     if (rec == null) { return null;
/*     */     }
/*  70 */     if ((fields != null) && (fields.size() > 0)) {
/*  71 */       rec.clearRecordFields();
/*     */       
/*  73 */       for (ExternalField field : fields) {
/*  74 */         rec.addRecordField(field);
/*     */       }
/*     */     }
/*     */     
/*  78 */     return getLayout(rec);
/*     */   }
/*     */   
/*     */ 
/*     */   private final ExternalRecord getCsvExternal(String fileStructure, String delim, String charset, String quote, boolean embeddedCr)
/*     */   {
/*  84 */     String embeddedStr = "";
/*  85 */     String font = "";
/*     */     
/*  87 */     if ("<none>".equals(quote.toLowerCase())) {
/*  88 */       quote = "";
/*     */     }
/*  90 */     if (embeddedCr) {
/*  91 */       embeddedStr = " EMBEDDEDCR=\"Y\" ";
/*     */     }
/*  93 */     if ("\t".equals(delim)) {
/*  94 */       delim = "<tab>";
/*     */     }
/*     */     
/*  97 */     if ((charset != null) && (!"".equals(charset))) {
/*  98 */       font = "FONTNAME=\"" + charset + "\"";
/*     */     }
/*     */     
/* 101 */     String xml = "<RECORD RECORDNAME=\"Delimited\" COPYBOOK=\"\" STYLE=\"0\"        FILESTRUCTURE=\"" + fileStructure + "\"" + "        DELIMITER=\"" + TranslateXmlChars.replaceXmlCharsStr(delim) + "\"" + "        QUOTE=\"" + TranslateXmlChars.replaceXmlCharsStr(quote) + "\"" + embeddedStr + " " + font + "\t\t   DESCRIPTION=\"Delimited\" RECORDTYPE=\"Delimited\" RecSep=\"default\">" + "\t<FIELDS>" + "\t\t<FIELD NAME=\"Dummy\" DESCRIPTION=\" \" POSITION=\"1\" TYPE=\"Char\"/>" + "\t</FIELDS>" + "</RECORD>";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 112 */     System.out.println("Generated Xml: " + xml);
/*     */     
/* 114 */     return getExternal(xml, "CsvNamesFirstLine");
/*     */   }
/*     */   
/*     */ 
/*     */   public final AbstractLayoutDetails getFixedLayout(List<ExternalField> fields, String charset)
/*     */   {
/* 120 */     String charsetTag = "";
/*     */     
/* 122 */     if ((charset != null) && (!"".equals(charset))) {
/* 123 */       charsetTag = "FONTNAME=\"" + charset + "\"";
/*     */     }
/*     */     
/*     */ 
/* 127 */     String xml = "<RECORD RECORDNAME=\"Fixed\" COPYBOOK=\"\" STYLE=\"0\"        FILESTRUCTURE=\"RecordLayout\" DELIMITER=\"\" " + charsetTag + "\t\t   DESCRIPTION=\"Fixed\" RECORDTYPE=\"Delimited\" RecSep=\"default\">" + "\t<FIELDS>" + "\t\t<FIELD NAME=\"Dummy\" DESCRIPTION=\" \" POSITION=\"1\" TYPE=\"Char\"/>" + "\t</FIELDS>" + "</RECORD>";
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 135 */     System.out.println("Generated Xml: " + xml);
/*     */     
/* 137 */     ExternalRecord rec = getExternal(xml, "FixedName");
/* 138 */     if (rec == null) {
/* 139 */       return null;
/*     */     }
/*     */     
/* 142 */     rec.clearRecordFields();
/*     */     
/* 144 */     for (ExternalField field : fields) {
/* 145 */       rec.addRecordField(field);
/*     */     }
/*     */     
/* 148 */     return getLayout(rec);
/*     */   }
/*     */   
/*     */   private AbstractLayoutDetails getLayout(ExternalRecord rec)
/*     */   {
/* 153 */     AbstractLayoutDetails ret = null;
/*     */     try {
/* 155 */       ret = rec.asLayoutDetail();
/*     */     } catch (Exception e) {
/* 157 */       Common.logMsg(30, "Internal Error Creating Layout:", rec.getRecordName(), e);
/* 158 */       e.printStackTrace();
/*     */     }
/*     */     
/* 161 */     return ret;
/*     */   }
/*     */   
/*     */   private static ExternalRecord getExternal(String xml, String name) {
/* 165 */     ExternalRecord ret = null;
/*     */     try
/*     */     {
/* 168 */       ret = RecordEditorXmlLoader.getExternalRecord(xml, name);
/*     */     } catch (Exception e) {
/* 170 */       Common.logMsg(30, "Internal Error Creating Layout:", name, e);
/* 171 */       Common.logMsg(30, "Problem Xml:", xml, null);
/* 172 */       System.out.println("Problem Xml: " + xml);
/* 173 */       e.printStackTrace();
/*     */     }
/*     */     
/* 176 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static StandardLayouts getInstance()
/*     */   {
/* 183 */     return instance;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/util/StandardLayouts.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */