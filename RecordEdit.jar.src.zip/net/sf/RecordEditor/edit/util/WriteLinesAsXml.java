/*    */ package net.sf.RecordEditor.edit.util;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import javax.xml.stream.XMLStreamException;
/*    */ import javax.xml.stream.XMLStreamWriter;
/*    */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*    */ import net.sf.JRecord.Details.AbstractLine;
/*    */ import net.sf.RecordEditor.re.util.BasicLine2Xml;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WriteLinesAsXml
/*    */   extends BasicLine2Xml
/*    */ {
/*    */   private Iterator<? extends AbstractLine> lineIterator;
/*    */   
/*    */   public WriteLinesAsXml(String filename, List<? extends AbstractLine> lines)
/*    */   {
/* 22 */     super(filename);
/*    */     
/* 24 */     this.lineIterator = lines.listIterator();
/*    */     
/* 26 */     doWork();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public WriteLinesAsXml(String filename, Iterator<? extends AbstractLine> iterator)
/*    */   {
/* 35 */     super(filename);
/*    */     
/* 37 */     this.lineIterator = iterator;
/*    */     
/* 39 */     doWork();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected final void writeDetails()
/*    */     throws XMLStreamException
/*    */   {
/* 50 */     this.writer.writeStartElement("ExportData");
/*    */     
/* 52 */     if (this.lineIterator.hasNext()) {
/* 53 */       AbstractLine line = (AbstractLine)this.lineIterator.next();
/* 54 */       String name = fixName(line.getLayout().getLayoutName());
/* 55 */       this.writer.writeEmptyElement(name);
/* 56 */       writeAttributes(line);
/*    */       
/* 58 */       while (this.lineIterator.hasNext()) {
/* 59 */         this.writer.writeEmptyElement(name);
/* 60 */         writeAttributes((AbstractLine)this.lineIterator.next());
/*    */       }
/*    */     }
/*    */     
/* 64 */     this.writer.writeEndElement();
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/util/WriteLinesAsXml.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */