/*     */ package net.sf.RecordEditor.edit.util;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.FocusAdapter;
/*     */ import java.awt.event.FocusEvent;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.ArrayList;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.table.AbstractTableModel;
/*     */ import net.sf.JRecord.CsvParser.ParserManager;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ import net.sf.JRecord.Details.LayoutDetail;
/*     */ import net.sf.JRecord.Details.Line;
/*     */ import net.sf.JRecord.Details.LineProvider;
/*     */ import net.sf.JRecord.Details.RecordDetail;
/*     */ import net.sf.JRecord.Details.RecordDetail.FieldDetails;
/*     */ import net.sf.JRecord.IO.LineIOProvider;
/*     */ import net.sf.RecordEditor.re.display.DisplayBuilderFactory;
/*     */ import net.sf.RecordEditor.re.display.IDisplayBuilder;
/*     */ import net.sf.RecordEditor.re.file.FileView;
/*     */ import net.sf.RecordEditor.utils.charsets.FontCombo;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.edit.ManagerRowList;
/*     */ import net.sf.RecordEditor.utils.fileStorage.DataStoreStd;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.BmKeyedComboBox;
/*     */ import net.sf.RecordEditor.utils.swing.BmKeyedComboModel;
/*     */ import net.sf.RecordEditor.utils.swing.ComboBoxs.DelimiterCombo;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NewCsvFile
/*     */ {
/*  44 */   private static int[][] STRUCTURES = { { 9, 54 }, { 90, 55 } };
/*     */   
/*     */ 
/*     */   public final ReFrame frame;
/*     */   
/*     */ 
/*  50 */   public final BaseHelpPanel panel = new BaseHelpPanel();
/*     */   
/*  52 */   private BmKeyedComboModel styleModel = new BmKeyedComboModel(new ManagerRowList(ParserManager.getInstance(), false));
/*     */   
/*     */ 
/*  55 */   private ColumnNameMdl colNameMdl = new ColumnNameMdl(null);
/*     */   
/*  57 */   private NumField rowFld = new NumField("row", 5, null);
/*  58 */   private NumField colFld = new NumField("row", 3, this.colNameMdl);
/*     */   
/*  60 */   private JCheckBox namesChk = new JCheckBox();
/*  61 */   private JCheckBox unicodeChk = new JCheckBox();
/*  62 */   private FontCombo fontCombo = new FontCombo();
/*  63 */   private DelimiterCombo fieldSep = DelimiterCombo.NewDelimCombo();
/*  64 */   private JComboBox quote = new JComboBox(Common.QUOTE_LIST);
/*  65 */   private BmKeyedComboBox parser = new BmKeyedComboBox(this.styleModel, false);
/*     */   
/*     */ 
/*  68 */   private JTable colNamesTbl = new JTable(this.colNameMdl);
/*     */   
/*  70 */   private JButton goBtn = SwingUtils.newButton("Create");
/*     */   
/*  72 */   private JTextField msgTxt = new JTextField();
/*     */   
/*  74 */   private ArrayList<String> columnNames = new ArrayList();
/*     */   
/*     */   public NewCsvFile() {
/*  77 */     this(new ReFrame("", "New Csv File", null));
/*     */   }
/*     */   
/*     */   public NewCsvFile(ReFrame displayFrame) {
/*  81 */     this.frame = displayFrame;
/*  82 */     init_100_Setup();
/*  83 */     init_200_LayoutScreen();
/*  84 */     init_300_Listners();
/*     */     
/*  86 */     this.frame.setVisible(true);
/*     */   }
/*     */   
/*     */   private void init_100_Setup()
/*     */   {
/*  91 */     this.namesChk.setSelected(true);
/*     */   }
/*     */   
/*     */   private void init_200_LayoutScreen()
/*     */   {
/*  96 */     this.panel.setGapRE(BasePanel.GAP2);
/*  97 */     this.panel.addLineRE("Rows", this.rowFld.field);
/*  98 */     this.panel.addLineRE("Cols", this.colFld.field);
/*  99 */     this.panel.addLineRE("Names on First Line", this.namesChk);
/* 100 */     this.panel.addLineRE("Unicode", this.unicodeChk);
/* 101 */     this.panel.addLineRE("Font", this.fontCombo);
/* 102 */     this.panel.addLineRE("Field Seperator", this.fieldSep);
/* 103 */     this.panel.addLineRE("Quote", this.quote);
/* 104 */     this.panel.addLineRE("Parser", this.parser);
/* 105 */     this.panel.setGapRE(BasePanel.GAP1);
/*     */     
/*     */ 
/*     */ 
/* 109 */     this.panel.addComponentRE(1, 3, SwingUtils.TABLE_ROW_HEIGHT * 10, BasePanel.GAP, 2, 2, this.colNamesTbl);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 115 */     this.panel.addLineRE(null, null, this.goBtn);
/* 116 */     this.panel.setGapRE(BasePanel.GAP1);
/* 117 */     this.panel.addMessage(this.msgTxt);
/* 118 */     this.panel.setHeightRE(BasePanel.HEIGHT_1P6);
/*     */     
/* 120 */     this.frame.addMainComponent(this.panel);
/* 121 */     this.frame.setDefaultCloseOperation(2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private void init_300_Listners()
/*     */   {
/* 128 */     this.namesChk.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent e) {
/* 130 */         boolean visible = NewCsvFile.this.namesChk.isSelected();
/*     */         
/* 132 */         NewCsvFile.this.colNamesTbl.setVisible(visible);
/*     */       }
/*     */       
/* 135 */     });
/* 136 */     this.goBtn.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent e) {
/* 138 */         Common.stopCellEditing(NewCsvFile.this.colNamesTbl);
/* 139 */         NewCsvFile.this.editFile();
/*     */         
/* 141 */         NewCsvFile.this.frame.setVisible(false);
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */   private void editFile()
/*     */   {
/* 148 */     LayoutDetail layout = getLayout();
/*     */     
/* 150 */     DataStoreStd<AbstractLine> store = DataStoreStd.newStore(layout);
/* 151 */     LineProvider<LayoutDetail, Line> p = LineIOProvider.getInstance().getLineProvider(layout);
/*     */     
/* 153 */     for (int i = 0; i < this.rowFld.value; i++) {
/* 154 */       AbstractLine l = p.getLine(layout);
/*     */       try {
/* 156 */         l.setField(0, this.colFld.value - 1, "");
/*     */       }
/*     */       catch (Exception e) {}
/* 159 */       store.add(l);
/*     */     }
/*     */     
/* 162 */     FileView file = new FileView(store, null, null, false);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 167 */     DisplayBuilderFactory.getInstance().newDisplay(1, "", null, file.getLayout(), file, 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private LayoutDetail getLayout()
/*     */   {
/* 174 */     byte[] eol = Common.SYSTEM_EOL_BYTES;
/* 175 */     String font = this.fontCombo.getText();
/* 176 */     String q = Common.QUOTE_VALUES[this.quote.getSelectedIndex()];
/* 177 */     String sep = this.fieldSep.getSelectedEnglish();
/* 178 */     int structure = STRUCTURES[toInt(this.unicodeChk.isSelected())][toInt(this.namesChk.isSelected())];
/*     */     
/* 180 */     RecordDetail.FieldDetails[] flds = new RecordDetail.FieldDetails[this.colFld.value];
/* 181 */     RecordDetail[] recs = new RecordDetail[1];
/*     */     
/* 183 */     for (int i = 0; i < this.colFld.value; i++) {
/* 184 */       String s = (String)this.columnNames.get(i);
/* 185 */       flds[i] = new RecordDetail.FieldDetails(s, s, 0, 0, font, 0, "");
/*     */       
/* 187 */       flds[i].setPosOnly(i + 1);
/*     */     }
/*     */     
/* 190 */     recs[0] = new RecordDetail("GeneratedCsvRecord", "", "", 2, sep, q, font, flds, ((Integer)this.parser.getSelectedItem()).intValue(), 0);
/*     */     
/*     */ 
/*     */ 
/* 194 */     if ((font != null) && (font.length() > 0)) {
/*     */       try {
/* 196 */         eol = "\n".getBytes(font);
/*     */       }
/*     */       catch (UnsupportedEncodingException e) {}
/*     */     }
/*     */     
/* 201 */     LayoutDetail layout = new LayoutDetail("GeneratedCsv", recs, "", 2, eol, "", font, null, structure);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 208 */     return layout;
/*     */   }
/*     */   
/*     */   private int toInt(boolean b) {
/* 212 */     int ret = 0;
/* 213 */     if (b) {
/* 214 */       ret = 1;
/*     */     }
/* 216 */     return ret;
/*     */   }
/*     */   
/*     */   private class NumField extends FocusAdapter
/*     */   {
/*     */     public int value;
/* 222 */     public JTextField field = new JTextField();
/*     */     private final String name;
/*     */     private final AbstractTableModel mdl;
/*     */     
/*     */     public NumField(String fieldName, int initialValue, AbstractTableModel model) {
/* 227 */       this.name = fieldName;
/* 228 */       this.value = initialValue;
/* 229 */       this.field.addFocusListener(this);
/* 230 */       this.mdl = model;
/* 231 */       this.field.setText(Integer.toString(this.value));
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public void focusLost(FocusEvent evt)
/*     */     {
/*     */       try
/*     */       {
/* 240 */         int lastValue = this.value;
/* 241 */         this.value = Integer.parseInt(this.field.getText());
/*     */         
/* 243 */         if ((this.mdl != null) && (lastValue != this.value) && (NewCsvFile.this.namesChk.isSelected())) {
/* 244 */           this.mdl.fireTableDataChanged();
/*     */         }
/*     */       } catch (Exception ex) {
/* 247 */         NewCsvFile.this.msgTxt.setText(LangConversion.convert("Invalid number in {0}, msg=", this.name) + ex.getMessage());
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private class ColumnNameMdl
/*     */     extends AbstractTableModel
/*     */   {
/*     */     private ColumnNameMdl() {}
/*     */     
/*     */ 
/*     */     public int getColumnCount()
/*     */     {
/* 262 */       return 1;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getRowCount()
/*     */     {
/* 270 */       return NewCsvFile.this.colFld.value;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Object getValueAt(int rowIndex, int columnIndex)
/*     */     {
/* 278 */       String s = "";
/*     */       
/* 280 */       if (rowIndex < NewCsvFile.this.columnNames.size()) {
/* 281 */         s = (String)NewCsvFile.this.columnNames.get(rowIndex);
/*     */       }
/*     */       
/* 284 */       return s;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getColumnName(int column)
/*     */     {
/* 292 */       return "Column Name";
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public boolean isCellEditable(int rowIndex, int columnIndex)
/*     */     {
/* 300 */       return true;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void setValueAt(Object value, int rowIndex, int columnIndex)
/*     */     {
/* 308 */       String s = "";
/* 309 */       if (value != null) {
/* 310 */         s = value.toString();
/*     */       }
/* 312 */       while (rowIndex >= NewCsvFile.this.columnNames.size()) {
/* 313 */         NewCsvFile.this.columnNames.add("");
/*     */       }
/* 315 */       NewCsvFile.this.columnNames.set(rowIndex, s);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/util/NewCsvFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */