/*     */ package net.sf.RecordEditor.edit;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.Action;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.SwingUtilities;
/*     */ import net.lingala.zip4j.core.ZipFile;
/*     */ import net.sf.JRecord.IO.AbstractLineIOProvider;
/*     */ import net.sf.JRecord.Types.Type;
/*     */ import net.sf.RecordEditor.edit.display.Action.ChangeFileStructureAction;
/*     */ import net.sf.RecordEditor.edit.display.Action.LoadSavedFieldSeqAction;
/*     */ import net.sf.RecordEditor.edit.display.Action.LoadSavedVisibilityAction;
/*     */ import net.sf.RecordEditor.edit.display.Action.ShowTextViewAction;
/*     */ import net.sf.RecordEditor.edit.display.DisplayBuilderImp;
/*     */ import net.sf.RecordEditor.edit.display.DisplayCobolCopybook;
/*     */ import net.sf.RecordEditor.edit.display.DisplayFrame;
/*     */ import net.sf.RecordEditor.edit.open.OpenFile;
/*     */ import net.sf.RecordEditor.externalInterface.Plugin;
/*     */ import net.sf.RecordEditor.re.display.AbstractFileDisplay;
/*     */ import net.sf.RecordEditor.re.editProperties.EditOptions;
/*     */ import net.sf.RecordEditor.re.jrecord.format.CellFormat;
/*     */ import net.sf.RecordEditor.re.jrecord.types.ReTypeManger;
/*     */ import net.sf.RecordEditor.re.jrecord.types.TypeDateWrapper;
/*     */ import net.sf.RecordEditor.re.openFile.LayoutSelectionDB;
/*     */ import net.sf.RecordEditor.re.openFile.OpenFileInterface;
/*     */ import net.sf.RecordEditor.re.script.ExportScriptPopup;
/*     */ import net.sf.RecordEditor.re.script.RunScriptPopup;
/*     */ import net.sf.RecordEditor.re.script.VelocityPopup;
/*     */ import net.sf.RecordEditor.re.script.XsltPopup;
/*     */ import net.sf.RecordEditor.re.script.bld.RunScriptSkelPopup;
/*     */ import net.sf.RecordEditor.re.script.runScreen.ScriptRunFrame;
/*     */ import net.sf.RecordEditor.re.util.ReIOProvider;
/*     */ import net.sf.RecordEditor.utils.CopyBookDbReader;
/*     */ import net.sf.RecordEditor.utils.CopyBookInterface;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.edit.ParseArgs;
/*     */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*     */ import net.sf.RecordEditor.utils.lang.ReAbstractAction;
/*     */ import net.sf.RecordEditor.utils.params.BoolOpt;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions.FileNameOptWithDefault;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions.InternalBoolOption;
/*     */ import net.sf.RecordEditor.utils.screenManager.AbstractActiveScreenAction;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReAction;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReActionActiveScreen;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReFrame;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMainFrame;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EditRec
/*     */   extends ReMainFrame
/*     */ {
/*  83 */   private AbstractAction newFileAction = null; private AbstractAction open2action = null; private AbstractAction new2action = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*  88 */   private boolean includeWizardOptions = true;
/*  89 */   private AbstractAction optionAction = new ReAbstractAction("Edit Options", 17)
/*     */   {
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/*  93 */       EditRec.this.editProperties(EditRec.this.incJdbc, EditRec.this.includeWizardOptions);
/*     */     }
/*     */   };
/*     */   
/*     */ 
/*  98 */   private final ReActionActiveScreen closeTabAction = newAction(61);
/*  99 */   private final ReActionActiveScreen extractTabAction = newAction(62);
/* 100 */   private final ReActionActiveScreen extractAllAction = newAction(63);
/* 101 */   private final ReActionActiveScreen addToMainScreenAction = newAction(64);
/* 102 */   private final ReActionActiveScreen toOneScreenAction = newAction(65);
/* 103 */   private final ReActionActiveScreen addChildRecAction = newAction(67);
/* 104 */   private final ReActionActiveScreen removeChildRecAction = newAction(66);
/*     */   
/* 106 */   private Action runScriptAction = addAction(new RunScriptAction());
/*     */   
/*     */   private OpenFile open;
/*     */   
/*     */   private JMenu utilityMenu;
/*     */   
/*     */   private JMenu dataMenu;
/*     */   private JMenu viewMenu;
/*     */   private boolean incJdbc;
/*     */   
/*     */   public EditRec(String pInFile, int pInitialRow, CopyBookInterface pInterfaceToCopyBooks)
/*     */   {
/* 118 */     this(pInFile, pInitialRow, ReIOProvider.getInstance(), pInterfaceToCopyBooks);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EditRec(String pInFile, int pInitialRow, AbstractLineIOProvider pIoProvider, CopyBookInterface pInterfaceToCopyBooks)
/*     */   {
/* 135 */     super("Record Editor", "", "re");
/*     */     
/* 137 */     checkVelocityScriptDir();
/*     */     
/* 139 */     this.open = new OpenFile(pInFile, pInitialRow, pIoProvider, null, null, new LayoutSelectionDB(pInterfaceToCopyBooks, null, true));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 145 */     initMenusToolBars(true, null, null, null, null);
/* 146 */     setupMenus(null, null, null, null);
/* 147 */     EditCommon.doStandardInit();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EditRec(boolean includeJdbc)
/*     */   {
/* 156 */     this(includeJdbc, "Record Editor", null, null, null);
/*     */   }
/*     */   
/*     */   public EditRec(boolean includeJdbc, String name, AbstractAction newAction)
/*     */   {
/* 161 */     this(includeJdbc, name, null, newAction, null);
/*     */   }
/*     */   
/*     */ 
/*     */   private EditRec(boolean includeJdbc, String name, AbstractAction open2Action, AbstractAction newAction, AbstractAction new2Action)
/*     */   {
/* 167 */     super(name, "", "re");
/* 168 */     checkVelocityScriptDir();
/*     */     
/* 170 */     initMenusToolBars(includeJdbc, open2Action, newAction, new2Action, null);
/* 171 */     EditCommon.doStandardInit();
/*     */   }
/*     */   
/*     */   public EditRec(String name) {
/* 175 */     super(name, "", "re");
/* 176 */     checkVelocityScriptDir();
/* 177 */     EditCommon.doStandardInit();
/*     */   }
/*     */   
/*     */   public EditRec(boolean includeJdbc, String name, String id, AbstractAction newAction, boolean loadAtBottom)
/*     */   {
/* 182 */     super(name, "", id, loadAtBottom);
/* 183 */     initMenusToolBars(includeJdbc, null, newAction, null, null);
/* 184 */     EditCommon.doStandardInit();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected final void initMenusToolBars(boolean includeJdbc, AbstractAction open2Action, AbstractAction newAction, AbstractAction new2Action, AbstractAction schemaEdit)
/*     */   {
/* 197 */     LoadSavedVisibilityAction savedVisibiltyAction = new LoadSavedVisibilityAction();
/* 198 */     LoadSavedFieldSeqAction fieldSeqAction = new LoadSavedFieldSeqAction();
/* 199 */     AbstractAction filterAction = newAction(8);
/* 200 */     AbstractAction sortAction = newAction(30);
/* 201 */     ReActionActiveScreen autofitAction = newAction(50);
/* 202 */     Action[] toolbarActions = { filterAction, sortAction, autofitAction, null, this.runScriptAction, this.optionAction };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 208 */     if (schemaEdit != null) {
/* 209 */       Action[] tbAction = { filterAction, sortAction, filterAction, autofitAction, null, schemaEdit, null, this.runScriptAction, this.optionAction };
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 216 */       toolbarActions = tbAction;
/*     */     }
/*     */     
/* 219 */     this.newFileAction = newAction;
/* 220 */     this.open2action = open2Action;
/* 221 */     this.new2action = new2Action;
/* 222 */     this.incJdbc = includeJdbc;
/* 223 */     this.optionAction.putValue("ShortDescription", LangConversion.convert(2, "Edit Options"));
/*     */     
/* 225 */     DisplayBuilderImp.register();
/*     */     
/* 227 */     ReMainFrame.setMasterFrame(this);
/* 228 */     ReTypeManger.setDateFormat(Common.DATE_FORMAT_STR);
/*     */     
/* 230 */     buildMenubar(VelocityPopup.getPopup(), XsltPopup.getPopup(), ExportScriptPopup.getPopup());
/* 231 */     buildToolbar(newAction, toolbarActions);
/*     */     
/*     */ 
/* 234 */     this.dataMenu.add(filterAction);
/* 235 */     this.dataMenu.add(newAction(14));
/* 236 */     this.dataMenu.add(sortAction);
/* 237 */     this.dataMenu.add(newAction(37));
/* 238 */     this.dataMenu.addSeparator();
/* 239 */     this.dataMenu.add(newAction(38));
/* 240 */     this.dataMenu.addSeparator();
/* 241 */     this.dataMenu.add(newAction(39));
/*     */     
/* 243 */     this.dataMenu.addSeparator();
/* 244 */     this.dataMenu.add(addAction(new ChangeFileStructureAction()));
/*     */     
/* 246 */     this.viewMenu.add(newAction(17));
/* 247 */     this.viewMenu.add(newAction(18));
/* 248 */     this.viewMenu.add(newAction(19));
/* 249 */     this.viewMenu.addSeparator();
/* 250 */     this.viewMenu.add(newAction(20));
/* 251 */     this.viewMenu.add(newAction(22));
/*     */     
/* 253 */     boolean allowTextView = (Common.OPTIONS.addTextDisplay.isSelected()) && (Common.OPTIONS.allowTextEditting.isSelected());
/*     */     
/*     */ 
/* 256 */     if (allowTextView) {
/* 257 */       this.viewMenu.addSeparator();
/* 258 */       this.viewMenu.add(addAction(ShowTextViewAction.get(false, false)));
/* 259 */       this.viewMenu.add(addAction(ShowTextViewAction.get(false, true)));
/*     */     }
/* 261 */     this.viewMenu.addSeparator();
/* 262 */     this.viewMenu.add(newAction(14));
/* 263 */     this.viewMenu.add(newAction(15));
/* 264 */     this.viewMenu.add(newAction(16));
/* 265 */     this.viewMenu.add(newAction(55));
/* 266 */     this.viewMenu.add(newAction(21));
/* 267 */     if (allowTextView) {
/* 268 */       this.viewMenu.add(addAction(ShowTextViewAction.get(true, false)));
/* 269 */       this.viewMenu.add(addAction(ShowTextViewAction.get(true, true)));
/*     */     }
/*     */     
/* 272 */     this.viewMenu.addSeparator();
/* 273 */     this.viewMenu.add(newAction(40));
/* 274 */     this.viewMenu.add(newAction(41));
/* 275 */     this.viewMenu.add(newAction(42));
/* 276 */     addAction(savedVisibiltyAction);
/* 277 */     addAction(fieldSeqAction);
/* 278 */     this.viewMenu.add(savedVisibiltyAction);
/* 279 */     this.viewMenu.add(fieldSeqAction);
/*     */     
/*     */ 
/*     */ 
/* 283 */     runInitClass(Common.USER_INIT_CLASS, "Error running user Initialize:");
/*     */     
/* 285 */     if (Common.OPTIONS.loadPoScreens.isSelected()) {
/* 286 */       runInitClass("net.sf.RecordEditor.po.PoInit", null);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 307 */     loadUserTypes();
/* 308 */     loadUserFormats();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void removeSpecificMenus()
/*     */   {
/* 328 */     removeSpecificMenus(11);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void addSpecificWindows(JMenu winMenu, ReAction closeAction)
/*     */   {
/* 334 */     winMenu.addSeparator();
/* 335 */     winMenu.add(this.extractTabAction);
/* 336 */     winMenu.add(this.extractAllAction);
/* 337 */     winMenu.add(this.addToMainScreenAction);
/* 338 */     winMenu.add(this.toOneScreenAction);
/* 339 */     winMenu.addSeparator();
/* 340 */     winMenu.add(this.addChildRecAction);
/* 341 */     winMenu.add(this.removeChildRecAction);
/* 342 */     winMenu.addSeparator();
/* 343 */     winMenu.add(this.closeTabAction);
/* 344 */     winMenu.add(closeAction);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setupMenus(Action copyAction, Action compareAction, JMenuItem compareMenu, JMenuItem newMenuItem)
/*     */   {
/* 355 */     buildFileMenu(this.open.getOpenFilePanel().getRecentFileMenu(), this.open.getOpenFilePanel().getRecentDirectoryMenu(), true, false, newMenuItem, this.open2action, this.newFileAction, this.new2action);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 364 */     if (copyAction != null) {
/* 365 */       this.utilityMenu.add(new ReAbstractAction("Cobol Copybook Analysis")
/*     */       {
/*     */ 
/*     */ 
/*     */         public void actionPerformed(ActionEvent e)
/*     */         {
/*     */ 
/* 372 */           new DisplayCobolCopybook();
/*     */         }
/* 374 */       });
/* 375 */       this.utilityMenu.addSeparator();
/* 376 */       this.utilityMenu.add(copyAction);
/* 377 */       this.utilityMenu.addSeparator();
/*     */     }
/* 379 */     this.utilityMenu.add(newAction(43));
/* 380 */     if (compareAction != null) {
/* 381 */       this.utilityMenu.add(compareAction);
/*     */     }
/* 383 */     if (compareMenu != null) {
/* 384 */       this.utilityMenu.add(compareMenu);
/*     */     }
/* 386 */     this.utilityMenu.addSeparator();
/*     */     
/* 388 */     JMenu bldMenu = RunScriptSkelPopup.buildScriptMenu(null, "Script Build");
/* 389 */     if (bldMenu != null) {
/* 390 */       this.utilityMenu.add(bldMenu);
/*     */     }
/* 392 */     this.utilityMenu.add(RunScriptPopup.getPopup());
/* 393 */     this.utilityMenu.add(this.runScriptAction);
/*     */     
/* 395 */     JMenu em = getEditMenu();
/* 396 */     em.addSeparator();
/* 397 */     em.add(this.optionAction);
/*     */     
/* 399 */     super.addExit();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addProgramSpecificMenus(JMenuBar menubar)
/*     */   {
/* 408 */     this.utilityMenu = SwingUtils.newMenu("Utilities");
/* 409 */     this.dataMenu = SwingUtils.newMenu("Data");
/* 410 */     this.viewMenu = SwingUtils.newMenu("View");
/*     */     
/* 412 */     menubar.add(this.utilityMenu);
/* 413 */     menubar.add(this.dataMenu);
/* 414 */     menubar.add(this.viewMenu);
/*     */     
/* 416 */     loadUserFunctions(menubar);
/*     */   }
/*     */   
/*     */   private void loadUserFunctions(JMenuBar menubar) {
/* 420 */     Object[] userFunctions = Common.readPropertiesArray("LocalFuncClass", 32);
/*     */     
/*     */ 
/* 423 */     if (userFunctions != null) {
/* 424 */       JMenu localMenu = SwingUtils.newMenu("Plugin");
/*     */       
/*     */ 
/* 427 */       int j = 0;
/*     */       
/* 429 */       for (int i = 0; i < 32; i++) {
/* 430 */         if (userFunctions[i] != null) {
/*     */           try {
/* 432 */             Plugin userClass = (Plugin)userFunctions[i];
/* 433 */             String name = Parameters.getString("LocalFuncName" + i);
/* 434 */             String param = Parameters.getString("LocalFuncParam" + i);
/* 435 */             localMenu.add(new LocalAction(name, userClass, param));
/* 436 */             j++;
/*     */           } catch (Exception e) {
/* 438 */             Common.logMsg(30, "Error loading Function", e.getMessage(), e);
/*     */           }
/*     */         }
/*     */       }
/*     */       
/* 443 */       if (j > 0) {
/* 444 */         menubar.add(localMenu);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void loadUserTypes()
/*     */   {
/* 457 */     ReTypeManger sysTypes = ReTypeManger.getInstance();
/*     */     
/*     */ 
/*     */ 
/* 461 */     int[] typeIds = Common.readIntPropertiesArray("TypeNumber.", 30);
/* 462 */     Object[] types = Common.readPropertiesArray(typeIds, "TypeClass.");
/*     */     Type newType;
/* 464 */     if (types != null) {
/* 465 */       Object[] formats = Common.readPropertiesArray(typeIds, "TypeFormat.");
/* 466 */       for (int i = 0; i < 30; i++) {
/* 467 */         if (types[i] != null) {
/*     */           try {
/* 469 */             newType = (Type)types[i];
/* 470 */             if ((formats == null) || (formats[i] == null)) {
/* 471 */               sysTypes.registerType(typeIds[i], newType);
/*     */             } else {
/* 473 */               CellFormat newFormat = (CellFormat)formats[i];
/*     */               
/* 475 */               sysTypes.registerType(typeIds[i], newType, newFormat);
/*     */             }
/*     */           } catch (Exception e) {
/* 478 */             Common.logMsg("Error Defining Type > " + typeIds[i] + " class=" + Parameters.getString(new StringBuilder().append("TypeClass.").append(i).toString()) + "  " + e.getMessage(), e);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 487 */     for (int i = 0; i < 20; i++) {
/* 488 */       String name = Parameters.getString("DateTypeName." + i);
/* 489 */       String format = Parameters.getString("DateFormat." + i);
/* 490 */       String baseTypeStr = Parameters.getString("DateBaseType." + i);
/* 491 */       if ((name != null) && (!"".equals(name)) && (format != null) && (!"".equals(format)) && (baseTypeStr != null) && (!"".equals(baseTypeStr)))
/*     */       {
/*     */         try
/*     */         {
/* 495 */           int typeNum = 90 + i;
/* 496 */           int baseType = Integer.parseInt(baseTypeStr);
/* 497 */           CellFormat newFormat = ReTypeManger.getFormatFor(format);
/*     */           
/* 499 */           newType = new TypeDateWrapper(sysTypes.getType(baseType), format);
/*     */           
/* 501 */           sysTypes.registerType(typeNum, newType, newFormat);
/*     */         } catch (Exception e) {
/* 503 */           Common.logMsg("Error Defining Type > " + name + "  " + e.getMessage(), e);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void loadUserFormats()
/*     */   {
/* 515 */     ReTypeManger sysTypes = ReTypeManger.getInstance();
/* 516 */     int[] formatIds = Common.readIntPropertiesArray("FormatNumber.", 30);
/* 517 */     Object[] formats = Common.readPropertiesArray(formatIds, "FormatClass.");
/*     */     
/* 519 */     if (formats != null) {
/* 520 */       for (int i = 0; i < 30; i++) {
/* 521 */         if (formats[i] != null) {
/*     */           try {
/* 523 */             CellFormat fmt = (CellFormat)formats[i];
/* 524 */             sysTypes.registerFormat(formatIds[i], fmt);
/*     */           } catch (Exception e) {
/* 526 */             Common.logMsgRaw(LangConversion.convert("Error Defining Type > {0} class={1} {2}", new Object[] { Integer.valueOf(formatIds[i]), Parameters.getString("TypeClass." + i), e.getMessage() }), e);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void executeAction(int action)
/*     */   {
/* 549 */     switch (action)
/*     */     {
/*     */     case 9: 
/* 552 */       ReFrame activeFrame = ReFrame.getActiveFrame();
/* 553 */       if ((activeFrame != null) && (activeFrame.isActionAvailable(9))) {
/* 554 */         activeFrame.executeAction(9);
/*     */       } else {
/* 556 */         ReFrame.moveFrameToFront(this.open);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 569 */       break;
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public boolean isActionAvailable(int action)
/*     */   {
/* 578 */     return (action == 9) || (super.isActionAvailable(action));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public OpenFile getOpenFileWindow()
/*     */   {
/* 587 */     return this.open;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setOpenFileWindow(OpenFile openWindow, Action copyAction, Action compareAction, JMenuItem newMenuItem, boolean incWizard)
/*     */   {
/* 598 */     this.open = openWindow;
/*     */     
/* 600 */     this.includeWizardOptions = incWizard;
/* 601 */     setupMenus(copyAction, compareAction, null, newMenuItem);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setOpenFileWindow(OpenFile openWindow, Action copyAction, JMenuItem compareMenu, JMenuItem newMenuItem, boolean incWizard)
/*     */   {
/* 612 */     this.open = openWindow;
/*     */     
/* 614 */     this.includeWizardOptions = incWizard;
/* 615 */     setupMenus(copyAction, null, compareMenu, newMenuItem);
/*     */   }
/*     */   
/*     */ 
/*     */   public final JMenu getViewMenu()
/*     */   {
/* 621 */     return this.viewMenu;
/*     */   }
/*     */   
/*     */   protected void editProperties(boolean includeJdbc, boolean includeWizardOptions)
/*     */   {
/* 626 */     new EditOptions(false, includeJdbc, includeWizardOptions);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static class LocalAction
/*     */     extends AbstractAction
/*     */   {
/* 638 */     private Plugin extension = null;
/*     */     private String param;
/*     */     
/*     */     public LocalAction(String name, Plugin userClass, String userParam) {
/* 642 */       super();
/* 643 */       this.extension = userClass;
/* 644 */       this.param = userParam;
/*     */     }
/*     */     
/*     */ 
/*     */     public void actionPerformed(ActionEvent event)
/*     */     {
/* 650 */       ReFrame actionHandler = ReFrame.getActiveFrame();
/* 651 */       if ((actionHandler != null) && ((actionHandler instanceof DisplayFrame))) {
/*     */         try {
/* 653 */           AbstractFileDisplay display = ((DisplayFrame)actionHandler).getActiveDisplay();
/* 654 */           this.extension.execute(this.param, display.getFileView(), display.getSelectedRows());
/*     */         }
/*     */         catch (Exception e) {}
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   private static class RunScriptAction extends ReAbstractAction implements AbstractActiveScreenAction {
/*     */     public RunScriptAction() {
/* 663 */       super(50);
/*     */     }
/*     */     
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/* 668 */       new ScriptRunFrame();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void checkActionEnabled()
/*     */     {
/* 676 */       setEnabled(ReFrame.getActiveFrame() instanceof DisplayFrame);
/*     */     }
/*     */   }
/*     */   
/*     */   protected static void checkVelocityScriptDir() {
/* 681 */     File f = new File(Common.OPTIONS.velocityScriptDir.get());
/* 682 */     File zip = new File(Parameters.getSytemJarFileDirectory() + "/VelocityScript.zip");
/* 683 */     System.out.println("--}}} " + f.getPath() + " " + zip.getPath() + " " + f.exists() + " " + zip.exists());
/*     */     
/* 685 */     if ((!f.exists()) && (zip.exists())) {
/* 686 */       new Thread(new Runnable() {
/*     */         public void run() {
/*     */           try {
/* 689 */             String destDir = Common.OPTIONS.velocityScriptDir.get();
/*     */             
/* 691 */             File f = new File(destDir);
/* 692 */             File destParent = f.getParentFile();
/*     */             
/* 694 */             Common.createDirectory(destParent);
/* 695 */             if (!destParent.exists()) {
/* 696 */               destParent.createNewFile();
/*     */             }
/*     */             
/*     */ 
/*     */ 
/* 701 */             ZipFile zipFile = new ZipFile(Parameters.getSytemJarFileDirectory() + "/VelocityScript.zip");
/*     */             
/* 703 */             zipFile.extractAll(destDir);
/*     */           } catch (Exception e) {
/* 705 */             e.printStackTrace();
/*     */           }
/*     */         }
/*     */       }).start();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void main(String[] pgmArgs)
/*     */   {
/* 717 */     SwingUtilities.invokeLater(new Runnable()
/*     */     {
/*     */       public void run() {
/* 720 */         ParseArgs args = new ParseArgs(this.val$pgmArgs);
/* 721 */         Common.setReadOnly(true);
/* 722 */         new EditRec(args.getDfltFile(), args.getInitialRow(), CopyBookDbReader.getInstance());
/*     */       }
/*     */     });
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/EditRec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */