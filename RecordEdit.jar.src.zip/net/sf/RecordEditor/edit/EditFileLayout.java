/*     */ package net.sf.RecordEditor.edit;
/*     */ 
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.SwingUtilities;
/*     */ import net.sf.JRecord.IO.AbstractLineIOProvider;
/*     */ import net.sf.RecordEditor.copy.CopyFileLayout;
/*     */ import net.sf.RecordEditor.diff.CompareFileLayout;
/*     */ import net.sf.RecordEditor.edit.display.Action.NewFileAction;
/*     */ import net.sf.RecordEditor.edit.display.Action.SaveFieldSequenceAction;
/*     */ import net.sf.RecordEditor.edit.display.Action.VisibilityAction;
/*     */ import net.sf.RecordEditor.edit.open.OpenFile;
/*     */ import net.sf.RecordEditor.layoutWizard.WizardFileLayout;
/*     */ import net.sf.RecordEditor.re.openFile.LayoutSelectionFile;
/*     */ import net.sf.RecordEditor.re.openFile.LayoutSelectionFileCreator;
/*     */ import net.sf.RecordEditor.re.openFile.OpenFileInterface;
/*     */ import net.sf.RecordEditor.re.util.ReIOProvider;
/*     */ import net.sf.RecordEditor.utils.common.Common;
/*     */ import net.sf.RecordEditor.utils.edit.ParseArgs;
/*     */ import net.sf.RecordEditor.utils.lang.ReAbstractAction;
/*     */ import net.sf.RecordEditor.utils.params.CheckUserData;
/*     */ import net.sf.RecordEditor.utils.params.Parameters;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*     */ import net.sf.RecordEditor.utils.params.ProgramOptions.InternalBoolOption;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMainFrame.ShowURI;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EditFileLayout
/*     */   extends EditRec
/*     */ {
/*     */   public EditFileLayout(String pInFile, int pInitialRow)
/*     */   {
/*  61 */     this(pInFile, pInitialRow, ReIOProvider.getInstance());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public EditFileLayout(String pInFile, int pInitialRow, AbstractLineIOProvider pIoProvider)
/*     */   {
/*  76 */     super(false, "Record Editor", new NewFileAction(new LayoutSelectionFileCreator()));
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  82 */     Common.OPTIONS.standardEditor.set(true);
/*  83 */     Common.OPTIONS.addTextDisplay.set(true);
/*  84 */     Common.setDBstatus(false);
/*     */     
/*  86 */     OpenFile open = new OpenFile(1, pInFile, pInitialRow, pIoProvider, null, null, Parameters.getApplicationDirectory() + "CobolFiles.txt", "HlpCe02.htm", new LayoutSelectionFile());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  93 */     setOpenFileWindow(open, new ReAbstractAction("File Copy Menu")new ReAbstractAction { public void actionPerformed(ActionEvent e) {} }, new ReAbstractAction("Compare Menu") { public void actionPerformed(ActionEvent e) {} }, null, true);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 118 */     getEditMenu().add(new ReAbstractAction("Layout Wizard")
/*     */     {
/*     */ 
/*     */ 
/*     */       public void actionPerformed(ActionEvent e)
/*     */       {
/*     */ 
/* 125 */         new WizardFileLayout(EditFileLayout.this.getOpenFileWindow().getOpenFilePanel().getCurrentFileName());
/*     */       }
/*     */       
/*     */ 
/* 129 */     });
/* 130 */     super.getEditMenu().addSeparator();
/* 131 */     super.getEditMenu().add(addAction(new VisibilityAction()));
/* 132 */     super.getEditMenu().add(addAction(new SaveFieldSequenceAction()));
/* 133 */     EditCommon.doStandardInit();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addProgramSpecificMenus(JMenuBar menubar)
/*     */   {
/* 144 */     JMenu layoutMenu = SwingUtils.newMenu("Record Layouts");
/* 145 */     menubar.add(layoutMenu);
/* 146 */     layoutMenu.add(new ReAbstractAction("Layout Wizard") {
/*     */       public void actionPerformed(ActionEvent e) {
/* 148 */         new WizardFileLayout(EditFileLayout.this.getOpenFileWindow().getOpenFilePanel().getCurrentFileName());
/*     */       }
/* 150 */     });
/* 151 */     super.addProgramSpecificMenus(menubar);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void addWebsitesToHelpMenu(JMenu helpMenu)
/*     */   {
/*     */     try
/*     */     {
/* 162 */       helpMenu.add(new ReMainFrame.ShowURI("JRecord Pages", Common.formatHelpURL("index.htm").toURI()));
/*     */       
/*     */ 
/*     */ 
/* 166 */       helpMenu.add(new ReMainFrame.ShowURI("JRecord Documentation", Common.formatHelpURL("Document.html").toURI()));
/*     */       
/*     */ 
/*     */ 
/* 170 */       helpMenu.addSeparator();
/* 171 */       helpMenu.add(new ReMainFrame.ShowURI("JRecord Web Page", new URI("http://jrecord.sourceforge.net/")));
/* 172 */       helpMenu.add(new ReMainFrame.ShowURI("JRecord Forum", new URI("https://sourceforge.net/projects/jrecord/forums")));
/* 173 */       helpMenu.add(new ReMainFrame.ShowURI("RecordEditor Web Page", new URI("http://record-editor.sourceforge.net/")));
/*     */     } catch (URISyntaxException e1) {
/* 175 */       e1.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void showAbout()
/*     */   {
/* 185 */     showAbout("This is the Cobol-Editor, it is part of the <b>RecordEditor</b> project<br/> It is distributed under a GPL 3 (or later) license<br/><pre> <br><b>Authors:</b><br><br> \t<b>Bruce Martin</b>: Main author<br>\t<b>Jean-Francois Gagnon</b>: Provided Fujitsu IO / Types<br><br> <b>Associated:</b><br><br> \t<b>Peter Thomas</b>: Wrote the <b>cb2xml</b> which provides the cobol interface<br/><br/> &nbsp;  <b>Websites:</b><br><br> \t<b>RecordEditor:</b> http://record-editor.sourceforge.net<br><br><br><b>Packages Used:</b><br/>\t<b>cb2xml<b>:\t\tCobol Copybook Analysis<br/>\t<b>jibx<b>:\t\tXml Bindings<br/>\t<b>TableLayout<b>:\tSwing Layout manager used<br>\t<b>jlibdif<b>:\tFile Compare<br/>\t<b>RSyntaxTextArea<b>\tScript Editting Copyright (c) 2012, Robert Futrell");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void main(String[] pgmArgs)
/*     */   {
/*     */     try
/*     */     {
/* 214 */       CheckUserData.checkAndCreate();
/* 215 */       CheckUserData.setUseCsvLine();
/*     */     } catch (Throwable e) {
/* 217 */       e.printStackTrace();
/*     */     }
/*     */     
/* 220 */     SwingUtilities.invokeLater(new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/* 224 */         ParseArgs args = new ParseArgs(this.val$pgmArgs);
/*     */         
/* 226 */         new EditFileLayout(args.getDfltFile(), args.getInitialRow(), ReIOProvider.getInstance());
/*     */       }
/*     */     });
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/edit/EditFileLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */