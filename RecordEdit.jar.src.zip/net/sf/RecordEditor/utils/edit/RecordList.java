/*    */ package net.sf.RecordEditor.utils.edit;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*    */ import net.sf.JRecord.Details.AbstractRecordDetail;
/*    */ import net.sf.RecordEditor.utils.swing.AbsRowList;
/*    */ import net.sf.RecordEditor.utils.swing.ArrayRow;
/*    */ 
/*    */ public class RecordList extends AbsRowList
/*    */ {
/*    */   private AbstractLayoutDetails layout;
/*    */   private boolean allRecords;
/*    */   private boolean firstRowNull;
/*    */   
/*    */   public RecordList(AbstractLayoutDetails recordLayout, boolean sort, boolean nullFirstRow, boolean loadAllRecords)
/*    */   {
/* 17 */     super(0, 1, false, false);
/* 18 */     this.layout = recordLayout;
/* 19 */     this.allRecords = loadAllRecords;
/* 20 */     this.firstRowNull = nullFirstRow;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void loadData()
/*    */   {
/* 32 */     ArrayList<net.sf.JRecord.Common.AbsRow> rows = new ArrayList();
/*    */     
/* 34 */     if (this.firstRowNull) {
/* 35 */       Object[] aRow = { Integer.valueOf(-1), "" };
/* 36 */       rows.add(new ArrayRow(aRow));
/*    */     }
/*    */     
/* 39 */     for (int i = 0; i < this.layout.getRecordCount(); i++) {
/* 40 */       String name = this.layout.getRecord(i).getRecordName();
/*    */       
/* 42 */       if ((this.allRecords) || (!this.layout.isXml()) || (!name.startsWith("/"))) {
/* 43 */         Object[] aRow = { Integer.valueOf(i), name };
/* 44 */         rows.add(new ArrayRow(aRow));
/*    */       }
/*    */     }
/*    */     
/* 48 */     super.loadData(rows);
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/utils/edit/RecordList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */