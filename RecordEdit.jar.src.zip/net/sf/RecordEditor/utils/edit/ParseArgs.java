/*     */ package net.sf.RecordEditor.utils.edit;
/*     */ 
/*     */ import java.io.File;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ParseArgs
/*     */ {
/*     */   private static final int IS_A_FILE = 0;
/*     */   private static final int IS_A_LINE = 3;
/*     */   private static final int IS_A_SCHEMA = 4;
/*     */   private static final int IS_A_DB = 5;
/*     */   private static final int IS_A_PARAM = 6;
/*     */   private static final int IS_UNKNOWN = -121;
/*  30 */   private int initialRow = 1;
/*  31 */   private String dfltFile = "";
/*  32 */   private String schemaName = "";
/*  33 */   private String db = "";
/*  34 */   private String paramFilename = "";
/*  35 */   private boolean overWiteOutputFile = false;
/*     */   
/*     */ 
/*     */ 
/*     */   public ParseArgs(String fileName, String schemaName, int initialRow)
/*     */   {
/*  41 */     if (initialRow > 1) {
/*  42 */       this.initialRow = initialRow;
/*     */     }
/*  44 */     this.dfltFile = fileName;
/*  45 */     this.schemaName = schemaName;
/*     */   }
/*     */   
/*     */ 
/*     */   public ParseArgs(String schemaName)
/*     */   {
/*  51 */     this.schemaName = schemaName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ParseArgs(String[] args)
/*     */   {
/*  61 */     int cat = 0;
/*     */     
/*     */ 
/*  64 */     if ((args != null) && (args.length > 0)) {
/*  65 */       for (int i = 0; i < args.length; i++) {
/*  66 */         String ucArg = args[i].toUpperCase();
/*  67 */         if (ucArg.equals("-L")) {
/*  68 */           cat = 3;
/*  69 */         } else if (ucArg.equals("-F")) {
/*  70 */           cat = 0;
/*  71 */         } else if (ucArg.equals("-OVERWRITE")) {
/*  72 */           this.overWiteOutputFile = true;
/*  73 */         } else if (ucArg.equals("-DB")) {
/*  74 */           cat = 5;
/*  75 */         } else if (ucArg.equals("-PARAMETERFILE")) {
/*  76 */           cat = 6;
/*  77 */         } else if ((ucArg.equals("-SCHEMA")) || (ucArg.equals("-LAYOUT"))) {
/*  78 */           cat = 4;
/*  79 */         } else if ((ucArg.startsWith("-")) && (ucArg.length() > 1)) {
/*  80 */           cat = -121;
/*     */         } else {
/*  82 */           switch (cat) {
/*     */           case 3: 
/*     */             try {
/*  85 */               this.initialRow = Integer.parseInt(args[i]);
/*     */             }
/*     */             catch (Exception e) {}
/*     */           case 4: 
/*  89 */             this.schemaName = accum(this.schemaName, args[i]);
/*  90 */             break;
/*     */           case 5: 
/*  92 */             this.db = accum(this.db, args[i]);
/*  93 */             break;
/*     */           case 6: 
/*  95 */             this.paramFilename = accum(this.paramFilename, args[i]);
/*  96 */             break;
/*     */           case 0: 
/*  98 */             this.dfltFile = accum(this.dfltFile, args[i]);
/*     */           }
/*     */         }
/*     */       }
/* 102 */       if (this.dfltFile != null) {
/* 103 */         File f = new File(this.dfltFile);
/* 104 */         if (f.exists()) {
/*     */           try {
/* 106 */             this.dfltFile = f.getCanonicalPath();
/*     */           }
/*     */           catch (Exception e) {}
/*     */         } else {
/* 110 */           String s = System.getProperty("user.dir") + "/" + this.dfltFile;
/*     */           
/*     */ 
/* 113 */           if (new File(s).exists()) {
/* 114 */             this.dfltFile = s;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean isOverWiteOutputFile()
/*     */   {
/* 126 */     return this.overWiteOutputFile;
/*     */   }
/*     */   
/*     */ 
/*     */   private String accum(String s1, String s2)
/*     */   {
/* 132 */     if (s1 == "") {
/* 133 */       s1 = s2;
/*     */     } else {
/* 135 */       s1 = s1 + " " + s2;
/*     */     }
/* 137 */     return s1;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public String getDfltFile()
/*     */   {
/* 144 */     return this.dfltFile;
/*     */   }
/*     */   
/*     */   public String getSchemaName()
/*     */   {
/* 149 */     return this.schemaName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getInitialRow()
/*     */   {
/* 158 */     return this.initialRow;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getDb()
/*     */   {
/* 167 */     return this.db;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final String getParamFilename()
/*     */   {
/* 176 */     return this.paramFilename;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/utils/edit/ParseArgs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */