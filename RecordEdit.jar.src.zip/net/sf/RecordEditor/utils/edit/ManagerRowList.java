/*    */ package net.sf.RecordEditor.utils.edit;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import net.sf.JRecord.Common.AbstractManager;
/*    */ import net.sf.JRecord.Common.BasicKeyedField;
/*    */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*    */ import net.sf.RecordEditor.utils.swing.AbsRowList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ManagerRowList
/*    */   extends AbsRowList
/*    */ {
/*    */   private AbstractManager functionManager;
/*    */   
/*    */   public ManagerRowList(AbstractManager manager, boolean sort)
/*    */   {
/* 20 */     super(0, 1, sort, false);
/*    */     
/* 22 */     this.functionManager = manager;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   protected void loadData()
/*    */   {
/* 33 */     ArrayList<BasicKeyedField> rows = new ArrayList();
/*    */     
/* 35 */     String mgrName = this.functionManager.getManagerName();
/*    */     
/* 37 */     for (int i = 0; i < this.functionManager.getNumberOfEntries(); i++) {
/* 38 */       int key = this.functionManager.getKey(i);
/* 39 */       String name = this.functionManager.getName(i);
/* 40 */       if ((name != null) && (!"".equals(name))) {
/* 41 */         BasicKeyedField fld = new BasicKeyedField();
/* 42 */         fld.key = key;
/* 43 */         fld.name = LangConversion.convertId(12, mgrName + "_" + key, name);
/*    */         
/*    */ 
/* 46 */         rows.add(fld);
/*    */       }
/*    */     }
/*    */     
/* 50 */     super.loadData(rows);
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/utils/edit/ManagerRowList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */