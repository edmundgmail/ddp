/*     */ package net.sf.RecordEditor.utils.fileStorage;
/*     */ 
/*     */ import java.util.AbstractList;
/*     */ import javax.swing.event.TableModelEvent;
/*     */ import net.sf.JRecord.Details.AbstractLayoutDetails;
/*     */ import net.sf.JRecord.Details.AbstractLine;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class DataStoreBase
/*     */   extends AbstractList<AbstractLine>
/*     */   implements IDataStore<AbstractLine>
/*     */ {
/*     */   protected IDataStore<? extends AbstractLine> parent;
/*  28 */   private TextInterface textInterface = null;
/*     */   
/*     */   public DataStoreBase(IDataStore<? extends AbstractLine> parent) {
/*  31 */     this.parent = parent;
/*     */   }
/*     */   
/*     */ 
/*     */   public final void addChildViewRE(ISortNotify notify)
/*     */   {
/*  37 */     throw new RuntimeException("AddChildView is not supported DataStoreRange");
/*     */   }
/*     */   
/*     */ 
/*     */   public final String getSizeDisplayRE()
/*     */   {
/*  43 */     return "";
/*     */   }
/*     */   
/*     */   public final long getSpaceRE()
/*     */   {
/*  48 */     return 0L;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final AbstractLayoutDetails getLayoutRE()
/*     */   {
/*  56 */     return this.parent.getLayoutRE();
/*     */   }
/*     */   
/*     */   public final void setLayoutRE(AbstractLayoutDetails layout)
/*     */   {
/*  61 */     this.parent.setLayoutRE(layout);
/*     */   }
/*     */   
/*     */   protected final int getParentIndex(Object o)
/*     */   {
/*  66 */     if ((o instanceof IChunkLine))
/*     */     {
/*  68 */       IChunkLine lc = (IChunkLine)o;
/*  69 */       return lc.getActualLine();
/*     */     }
/*     */     
/*  72 */     return this.parent.indexOf(o);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean hasEmbeddedCr()
/*     */   {
/*  81 */     return this.parent.hasEmbeddedCr();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isTextViewPossibleRE()
/*     */   {
/*  90 */     return this.parent.isTextViewPossibleRE();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ITextInterface getTextInterfaceRE()
/*     */   {
/*  99 */     if (this.textInterface == null) {
/* 100 */       this.textInterface = new TextInterface(this);
/*     */     }
/* 102 */     return this.textInterface;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void tableChanged(TableModelEvent e)
/*     */   {
/* 110 */     if (this.textInterface != null) {
/* 111 */       this.textInterface.resetPosition(e);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/utils/fileStorage/DataStoreBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */