/*    */ package net.sf.RecordEditor.utils.fileStorage;
/*    */ 
/*    */ import net.sf.JRecord.Common.IFieldDetail;
/*    */ import net.sf.JRecord.Common.RecordException;
/*    */ import net.sf.JRecord.Details.CharLine;
/*    */ import net.sf.JRecord.Details.LayoutDetail;
/*    */ 
/*    */ public class CharLineChunk extends CharLineBase
/*    */ {
/*    */   public CharLineChunk(LayoutDetail group, FileChunkCharLine fileChunk, int line)
/*    */   {
/* 12 */     super(group, fileChunk, line);
/*    */   }
/*    */   
/*    */ 
/*    */   private String getLineFromChunk()
/*    */   {
/* 18 */     return this.chunk.getString(this.chunkLine);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   protected void clearData()
/*    */   {
/* 25 */     super.clearData();
/* 26 */     updateChunk();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setData(byte[] newVal)
/*    */   {
/* 34 */     this.chunk.putFromLine(this.chunkLine, CharLine.toStr(newVal, ((LayoutDetail)this.layout).getFontName()).toCharArray());
/*    */   }
/*    */   
/*    */ 
/*    */   public void setData(String newVal)
/*    */   {
/* 40 */     this.chunk.putFromLine(this.chunkLine, newVal.toCharArray());
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public void setField(IFieldDetail field, Object value)
/*    */     throws RecordException
/*    */   {
/* 48 */     synchronized (this) {
/* 49 */       String b = getLineFromChunk();
/* 50 */       super.setDataRaw(b);
/*    */       
/*    */ 
/* 53 */       super.setField(field, value);
/* 54 */       updateChunk();
/*    */     }
/*    */   }
/*    */   
/*    */   public String setFieldHex(int recordIdx, int fieldIdx, String val)
/*    */     throws RecordException
/*    */   {
/* 61 */     super.setDataRaw(getLineFromChunk());
/* 62 */     String s = super.setFieldHex(recordIdx, fieldIdx, val);
/* 63 */     updateChunk();
/*    */     
/* 65 */     return s;
/*    */   }
/*    */   
/*    */ 
/*    */   public void setFieldText(int recordIdx, int fieldIdx, String value)
/*    */     throws RecordException
/*    */   {
/* 72 */     super.setDataRaw(getLineFromChunk());
/* 73 */     super.setFieldText(recordIdx, fieldIdx, value);
/* 74 */     updateChunk();
/*    */   }
/*    */   
/*    */ 
/*    */   protected String getLineData()
/*    */   {
/* 80 */     String b = getLineFromChunk();
/* 81 */     super.setDataRaw(b);
/*    */     
/*    */ 
/* 84 */     return b;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/utils/fileStorage/CharLineChunk.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */