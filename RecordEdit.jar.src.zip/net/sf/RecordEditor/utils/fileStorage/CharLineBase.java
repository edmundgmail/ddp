/*     */ package net.sf.RecordEditor.utils.fileStorage;
/*     */ 
/*     */ import net.sf.JRecord.Details.CharLine;
/*     */ import net.sf.JRecord.Details.LayoutDetail;
/*     */ 
/*     */ public abstract class CharLineBase
/*     */   extends CharLine implements IChunkLine<FileChunkCharLine>
/*     */ {
/*     */   protected FileChunkCharLine chunk;
/*     */   protected int chunkLine;
/*  11 */   private boolean live = true;
/*     */   
/*     */   public CharLineBase(LayoutDetail group, FileChunkCharLine fileChunk, int line)
/*     */   {
/*  15 */     super(group, null);
/*     */     
/*  17 */     this.chunk = fileChunk;
/*  18 */     this.chunkLine = line;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getChunkLine()
/*     */   {
/*  29 */     return this.chunkLine;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getActualLine()
/*     */   {
/*  37 */     return this.chunkLine + this.chunk.getFirstLine();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setChunkLine(int chunkLine)
/*     */   {
/*  44 */     this.chunkLine = chunkLine;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public FileChunkCharLine getChunk()
/*     */   {
/*  51 */     return this.chunk;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setChunk(FileChunkCharLine chunk)
/*     */   {
/*  58 */     this.chunk = chunk;
/*     */   }
/*     */   
/*     */   protected final void updateChunk()
/*     */   {
/*  63 */     String b = super.getLineData();
/*  64 */     this.chunk.putFromLine(this.chunkLine, b.toCharArray());
/*     */     
/*  66 */     super.clearData();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public CharLine getNewDataLine()
/*     */   {
/*  73 */     return new CharLine((LayoutDetail)this.layout, this.chunk.getString(this.chunkLine));
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public byte[] getData()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: dup
/*     */     //   2: astore_1
/*     */     //   3: monitorenter
/*     */     //   4: aload_0
/*     */     //   5: getfield 3	net/sf/RecordEditor/utils/fileStorage/CharLineBase:chunk	Lnet/sf/RecordEditor/utils/fileStorage/FileChunkCharLine;
/*     */     //   8: aload_0
/*     */     //   9: getfield 4	net/sf/RecordEditor/utils/fileStorage/CharLineBase:chunkLine	I
/*     */     //   12: invokevirtual 14	net/sf/RecordEditor/utils/fileStorage/FileChunkCharLine:get	(I)[B
/*     */     //   15: aload_1
/*     */     //   16: monitorexit
/*     */     //   17: areturn
/*     */     //   18: astore_2
/*     */     //   19: aload_1
/*     */     //   20: monitorexit
/*     */     //   21: aload_2
/*     */     //   22: athrow
/*     */     // Line number table:
/*     */     //   Java source line #78	-> byte code offset #0
/*     */     //   Java source line #79	-> byte code offset #4
/*     */     //   Java source line #80	-> byte code offset #18
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	23	0	this	CharLineBase
/*     */     //   2	18	1	Ljava/lang/Object;	Object
/*     */     //   18	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   4	17	18	finally
/*     */     //   18	21	18	finally
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   protected String getLineData()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: dup
/*     */     //   2: astore_1
/*     */     //   3: monitorenter
/*     */     //   4: aload_0
/*     */     //   5: getfield 3	net/sf/RecordEditor/utils/fileStorage/CharLineBase:chunk	Lnet/sf/RecordEditor/utils/fileStorage/FileChunkCharLine;
/*     */     //   8: aload_0
/*     */     //   9: getfield 4	net/sf/RecordEditor/utils/fileStorage/CharLineBase:chunkLine	I
/*     */     //   12: invokevirtual 13	net/sf/RecordEditor/utils/fileStorage/FileChunkCharLine:getString	(I)Ljava/lang/String;
/*     */     //   15: aload_1
/*     */     //   16: monitorexit
/*     */     //   17: areturn
/*     */     //   18: astore_2
/*     */     //   19: aload_1
/*     */     //   20: monitorexit
/*     */     //   21: aload_2
/*     */     //   22: athrow
/*     */     // Line number table:
/*     */     //   Java source line #86	-> byte code offset #0
/*     */     //   Java source line #87	-> byte code offset #4
/*     */     //   Java source line #88	-> byte code offset #18
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	23	0	this	CharLineBase
/*     */     //   2	18	1	Ljava/lang/Object;	Object
/*     */     //   18	4	2	localObject1	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   4	17	18	finally
/*     */     //   18	21	18	finally
/*     */   }
/*     */   
/*     */   public void setDead()
/*     */   {
/* 100 */     this.live = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isLive()
/*     */   {
/* 110 */     return this.live;
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/utils/fileStorage/CharLineBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */