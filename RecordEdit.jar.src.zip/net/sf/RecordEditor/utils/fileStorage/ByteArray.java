/*    */ package net.sf.RecordEditor.utils.fileStorage;
/*    */ 
/*    */ public class ByteArray
/*    */ {
/*    */   public final int size;
/*    */   public final byte[] bytes;
/*    */   public final boolean compressed;
/*    */   
/*    */   public ByteArray(int size, byte[] bytes, boolean comp) {
/* 10 */     this.size = size;
/* 11 */     this.bytes = bytes;
/* 12 */     this.compressed = comp;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/utils/fileStorage/ByteArray.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */