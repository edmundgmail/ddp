/*     */ package net.sf.RecordEditor.utils.fileStorage.randomFile;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OverflowFile
/*     */   implements IOverflowFile
/*     */ {
/*  19 */   private RandomAccessFile overflowRandomFile = null;
/*  20 */   private File overflowFile = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final DataOutput getWriter(long pos, int length)
/*     */     throws IOException
/*     */   {
/*  35 */     getOverflowFile().seek(pos);
/*     */     
/*  37 */     return getOverflowFile();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void free(DataOutput out)
/*     */     throws IOException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public final DataInput getReader(long pos)
/*     */     throws IOException
/*     */   {
/*  54 */     getOverflowFile().seek(pos);
/*     */     
/*  56 */     return getOverflowFile();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final void free(DataInput in)
/*     */     throws IOException
/*     */   {}
/*     */   
/*     */ 
/*     */   private RandomAccessFile getOverflowFile()
/*     */     throws IOException
/*     */   {
/*  69 */     if (this.overflowRandomFile == null) {
/*  70 */       synchronized (this) {
/*  71 */         DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss_SSS");
/*     */         
/*     */ 
/*  74 */         this.overflowFile = File.createTempFile("~tmp_" + dateFormat.format(new Date()), ".tmp~");
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*  79 */         this.overflowFile.deleteOnExit();
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  85 */         this.overflowRandomFile = new RandomAccessFile(this.overflowFile, "rw");
/*     */       }
/*     */     }
/*     */     
/*  89 */     return this.overflowRandomFile;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clear()
/*     */   {
/*  98 */     if (this.overflowRandomFile != null) {
/*  99 */       synchronized (this) {
/*     */         try {
/* 101 */           this.overflowRandomFile.close();
/* 102 */           this.overflowFile.delete();
/*     */         }
/*     */         catch (IOException e) {}
/*     */         
/* 106 */         this.overflowRandomFile = null;
/* 107 */         this.overflowFile = null;
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/utils/fileStorage/randomFile/OverflowFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */