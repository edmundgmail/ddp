/*    */ package net.sf.RecordEditor.utils.fileStorage.randomFile;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.DataInput;
/*    */ import java.io.DataInputStream;
/*    */ import java.io.DataOutput;
/*    */ import java.io.DataOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class MockOverflow
/*    */   implements IOverflowFile
/*    */ {
/* 15 */   private HashMap<Long, ByteArrayOutputStream> details = new HashMap(300);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public DataOutput getWriter(long pos, int length)
/*    */     throws IOException
/*    */   {
/* 26 */     ByteArrayOutputStream os = new ByteArrayOutputStream();
/*    */     
/* 28 */     this.details.put(Long.valueOf(pos), os);
/*    */     
/* 30 */     return new DataOutputStream(os);
/*    */   }
/*    */   
/*    */ 
/*    */   public void free(DataOutput out)
/*    */     throws IOException
/*    */   {}
/*    */   
/*    */ 
/*    */   public DataInput getReader(long pos)
/*    */     throws IOException
/*    */   {
/* 42 */     ByteArrayOutputStream os = (ByteArrayOutputStream)this.details.get(Long.valueOf(pos));
/* 43 */     if (os == null) {
/* 44 */       throw new IOException("Position: " + pos + " was not found in mock map");
/*    */     }
/*    */     
/* 47 */     ByteArrayInputStream in = new ByteArrayInputStream(os.toByteArray());
/* 48 */     return new DataInputStream(in);
/*    */   }
/*    */   
/*    */ 
/*    */   public void free(DataInput in)
/*    */     throws IOException
/*    */   {}
/*    */   
/*    */   public void clear()
/*    */   {
/* 58 */     this.details.clear();
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/utils/fileStorage/randomFile/MockOverflow.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */