package net.sf.RecordEditor.utils.fileStorage.randomFile;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public abstract interface IOverflowFile
{
  public abstract DataOutput getWriter(long paramLong, int paramInt)
    throws IOException;
  
  public abstract void free(DataOutput paramDataOutput)
    throws IOException;
  
  public abstract DataInput getReader(long paramLong)
    throws IOException;
  
  public abstract void free(DataInput paramDataInput)
    throws IOException;
  
  public abstract void clear();
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/utils/fileStorage/randomFile/IOverflowFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */