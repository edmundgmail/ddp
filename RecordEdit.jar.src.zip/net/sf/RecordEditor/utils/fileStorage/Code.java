/*    */ package net.sf.RecordEditor.utils.fileStorage;
/*    */ 
/*    */ import java.util.zip.DataFormatException;
/*    */ import java.util.zip.Deflater;
/*    */ import java.util.zip.Inflater;
/*    */ import net.sf.JRecord.Common.RecordRunTimeException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Code
/*    */ {
/*    */   public static byte[] compress(int size, byte[] store)
/*    */   {
/* 15 */     Deflater deflater = new Deflater();
/* 16 */     deflater.setInput(store, 0, store.length);
/* 17 */     deflater.finish();
/* 18 */     byte[] buff = new byte[store.length + 50];
/*    */     
/* 20 */     deflater.deflate(buff);
/*    */     
/* 22 */     int compressedSize = deflater.getTotalOut();
/*    */     
/*    */ 
/* 25 */     if (deflater.getTotalIn() != store.length) {
/* 26 */       return null;
/*    */     }
/*    */     
/* 29 */     byte[] ret = new byte[compressedSize];
/* 30 */     System.arraycopy(buff, 0, ret, 0, compressedSize);
/*    */     
/* 32 */     return ret;
/*    */   }
/*    */   
/*    */   public static ByteArray uncompressed(byte[] compressedData, int length) {
/* 36 */     return uncompressed(compressedData, length, true);
/*    */   }
/*    */   
/*    */ 
/*    */   public static ByteArray uncompressed(byte[] compressedData, int length, boolean doCheck)
/*    */   {
/* 42 */     byte[] store = new byte[length];
/*    */     
/*    */     int bytesUsed;
/*    */     try
/*    */     {
/* 47 */       Inflater inflater = new Inflater();
/* 48 */       inflater.setInput(compressedData, 0, compressedData.length);
/* 49 */       inflater.finished();
/*    */       
/*    */ 
/* 52 */       bytesUsed = inflater.inflate(store);
/*    */       
/*    */ 
/* 55 */       inflater.reset();
/*    */     }
/*    */     catch (DataFormatException e) {
/* 58 */       throw new RecordRunTimeException("Data Format error: {0}", e.getMessage(), e);
/*    */     }
/*    */     
/* 61 */     return new ByteArray(bytesUsed, store, false);
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/utils/fileStorage/Code.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */