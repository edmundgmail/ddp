/*    */ package net.sf.RecordEditor.utils.fileStorage;
/*    */ 
/*    */ import net.sf.JRecord.Common.IFieldDetail;
/*    */ import net.sf.JRecord.Common.RecordException;
/*    */ import net.sf.JRecord.Common.RecordRunTimeException;
/*    */ import net.sf.JRecord.Details.LayoutDetail;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CharLineTemp
/*    */   extends CharLineBase
/*    */ {
/*    */   public CharLineTemp(LayoutDetail group, FileChunkCharLine fileChunk, int line)
/*    */   {
/* 15 */     super(group, fileChunk, line);
/*    */   }
/*    */   
/*    */   protected void clearData()
/*    */   {
/* 20 */     throw new RecordRunTimeException("Can not update temporary Line");
/*    */   }
/*    */   
/*    */   public void setData(byte[] newVal)
/*    */   {
/* 25 */     throw new RecordRunTimeException("Can not update field in temporary Line");
/*    */   }
/*    */   
/*    */   public void setField(IFieldDetail field, Object value)
/*    */     throws RecordException
/*    */   {
/* 31 */     throw new RecordException("Can not update field in temporary Line");
/*    */   }
/*    */   
/*    */   public String setFieldHex(int recordIdx, int fieldIdx, String val)
/*    */     throws RecordException
/*    */   {
/* 37 */     throw new RecordException("Can not update field in temporary Line");
/*    */   }
/*    */   
/*    */   public void setFieldText(int recordIdx, int fieldIdx, String value)
/*    */     throws RecordException
/*    */   {
/* 43 */     throw new RecordException("Can not update field in temporary Line");
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/utils/fileStorage/CharLineTemp.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */