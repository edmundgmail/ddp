package net.sf.RecordEditor.utils.basicStuff;

import java.util.List;

public abstract interface IRetrieveTable
{
  public abstract boolean hasMoreRows();
  
  public abstract String nextRow();
  
  public abstract boolean hasMoreColumns();
  
  public abstract String nextColumn();
  
  public abstract List<String> nextRowAsList();
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/utils/basicStuff/IRetrieveTable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */