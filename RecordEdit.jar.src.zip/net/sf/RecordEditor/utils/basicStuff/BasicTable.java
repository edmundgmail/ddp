/*    */ package net.sf.RecordEditor.utils.basicStuff;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.StringTokenizer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BasicTable
/*    */   implements IRetrieveTable
/*    */ {
/*    */   private final StringTokenizer rowTokenizer;
/*    */   private StringTokenizer columnTokenizer;
/*    */   
/*    */   public BasicTable(String tblString)
/*    */   {
/* 19 */     this.rowTokenizer = new StringTokenizer(tblString, "\n");
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean hasMoreRows()
/*    */   {
/* 27 */     return this.rowTokenizer.hasMoreElements();
/*    */   }
/*    */   
/*    */   public List<String> nextRowAsList()
/*    */   {
/* 32 */     ArrayList<String> columns = new ArrayList();
/* 33 */     nextRow();
/*    */     
/* 35 */     while (this.columnTokenizer.hasMoreTokens()) {
/* 36 */       columns.add(this.columnTokenizer.nextToken());
/*    */     }
/* 38 */     return columns;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String nextRow()
/*    */   {
/* 46 */     String s = this.rowTokenizer.nextToken();
/* 47 */     this.columnTokenizer = new StringTokenizer(s, "\t");
/* 48 */     return s;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public boolean hasMoreColumns()
/*    */   {
/* 56 */     return this.columnTokenizer.hasMoreElements();
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public String nextColumn()
/*    */   {
/* 64 */     return this.columnTokenizer.nextToken();
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/utils/basicStuff/BasicTable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */