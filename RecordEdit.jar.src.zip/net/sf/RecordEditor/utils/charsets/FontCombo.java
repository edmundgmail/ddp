/*     */ package net.sf.RecordEditor.utils.charsets;
/*     */ 
/*     */ import java.awt.Dimension;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.Action;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JPopupMenu;
/*     */ import net.sf.RecordEditor.utils.screenManager.ReMainFrame;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ import net.sf.RecordEditor.utils.swing.common.ComboLikeObject;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FontCombo
/*     */   extends ComboLikeObject
/*     */ {
/*     */   public FontCombo()
/*     */   {
/*  31 */     this(CharsetMgr.getCommonCharsets(), new JButton(""));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public FontCombo(String[] fonts)
/*     */   {
/*  39 */     this(lookupDescription(fonts), new JButton(""));
/*     */   }
/*     */   
/*     */   private FontCombo(String[][] fonts, JButton btn)
/*     */   {
/*  44 */     super("fontTxt", new JButton[] { btn });
/*     */     
/*  46 */     setFontList(fonts);
/*     */     
/*  48 */     setPreferredSize(new Dimension(Math.max(getPreferredSize().width, SwingUtils.CHAR_FIELD_WIDTH * 25), getPreferredSize().height));
/*     */     
/*     */ 
/*     */ 
/*  52 */     btn.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent e) {
/*  54 */         FontCombo.this.showFontScreen();
/*     */       }
/*     */     });
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFontList(String[] fonts)
/*     */   {
/*  64 */     setFontList(lookupDescription(fonts));
/*     */   }
/*     */   
/*     */   private static String[][] lookupDescription(String[] fonts) {
/*  68 */     String[][] ret = new String[fonts.length][];
/*     */     
/*  70 */     for (int i = 0; i < fonts.length; i++) {
/*  71 */       ret[i] = new String[2];
/*  72 */       ret[i][0] = fonts[i];
/*  73 */       ret[i][1] = CharsetMgr.getDescription(fonts[i]);
/*     */     }
/*     */     
/*  76 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFontList(String[][] fonts)
/*     */   {
/*  85 */     if (fonts != null) {
/*  86 */       JPopupMenu menu = new JPopupMenu();
/*     */       
/*  88 */       for (String[] s : fonts) {
/*  89 */         menu.add(new FontAction(s[0], s[1], null));
/*     */       }
/*     */       
/*  92 */       super.setCurrentPopup(menu);
/*     */     }
/*     */   }
/*     */   
/*     */   private void showFontScreen() {
/*  97 */     super.setText(new CharsetSelection(ReMainFrame.getMasterFrame(), super.getText()).getCharset());
/*     */   }
/*     */   
/*     */   private class FontAction
/*     */     extends AbstractAction implements Action
/*     */   {
/*     */     private final String fontName;
/*     */     
/*     */     private FontAction(String fontName, String description)
/*     */     {
/* 107 */       super();
/* 108 */       this.fontName = fontName;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/* 116 */       FontCombo.this.setText(this.fontName);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/utils/charsets/FontCombo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */