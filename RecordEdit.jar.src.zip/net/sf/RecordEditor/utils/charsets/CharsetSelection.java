/*     */ package net.sf.RecordEditor.utils.charsets;
/*     */ 
/*     */ import java.awt.Container;
/*     */ import java.awt.Frame;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.util.List;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.table.AbstractTableModel;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ import net.sf.RecordEditor.utils.swing.BaseHelpPanel;
/*     */ import net.sf.RecordEditor.utils.swing.BasePanel;
/*     */ import net.sf.RecordEditor.utils.swing.ButtonTableRendor;
/*     */ import net.sf.RecordEditor.utils.swing.SwingUtils;
/*     */ 
/*     */ public class CharsetSelection
/*     */ {
/*  21 */   private static String[] COLUMN_NAMES = { "", "Character set", "Description" };
/*     */   
/*     */   private String charset;
/*     */   private JDialog dialog;
/*  25 */   private BaseHelpPanel pnl = new BaseHelpPanel();
/*  26 */   private TblMdl tblMdl = new TblMdl(null);
/*     */   
/*  28 */   private JTextField charsetTxt = new JTextField();
/*     */   
/*  30 */   private ButtonTableRendor tableBtn = new ButtonTableRendor();
/*  31 */   private JTable tbl = new JTable(this.tblMdl);
/*     */   
/*     */   public CharsetSelection(Frame owner, String characterSet)
/*     */   {
/*  35 */     this.charset = characterSet;
/*  36 */     this.charsetTxt.setText(this.charset);
/*     */     
/*  38 */     TableColumn tc = this.tbl.getColumnModel().getColumn(0);
/*  39 */     tc.setCellRenderer(this.tableBtn);
/*  40 */     tc.setPreferredWidth(5);
/*  41 */     this.tbl.getColumnModel().getColumn(1).setPreferredWidth(16 * SwingUtils.CHAR_FIELD_WIDTH);
/*  42 */     this.tbl.getColumnModel().getColumn(2).setPreferredWidth(59 * SwingUtils.CHAR_FIELD_WIDTH);
/*  43 */     this.tbl.setAutoResizeMode(0);
/*     */     
/*  45 */     this.pnl.addLineRE("Selected Characterset", this.charsetTxt).setGapRE(BasePanel.GAP1);
/*     */     
/*     */ 
/*  48 */     this.pnl.addComponentRE(1, 5, -1.0D, BasePanel.GAP, 2, 2, this.tbl);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  53 */     this.dialog = new JDialog(owner, true);
/*  54 */     this.dialog.getContentPane().add(this.pnl);
/*     */     
/*  56 */     this.charsetTxt.setEditable(false);
/*     */     
/*  58 */     this.tbl.addMouseListener(new MouseAdapter() {
/*     */       public void mousePressed(MouseEvent m) {
/*  60 */         int row = CharsetSelection.this.tbl.rowAtPoint(m.getPoint());
/*     */         
/*  62 */         CharsetSelection.this.accept(((CharsetDtls)CharsetSelection.access$200(CharsetSelection.this).charsets.get(row)).id);
/*     */       }
/*     */       
/*  65 */     });
/*  66 */     this.pnl.done();
/*     */     
/*  68 */     this.dialog.pack();
/*  69 */     this.dialog.setVisible(true);
/*     */   }
/*     */   
/*     */   private void accept(String c) {
/*  73 */     this.charset = c;
/*  74 */     this.dialog.setVisible(false);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public final String getCharset()
/*     */   {
/*  81 */     return this.charset;
/*     */   }
/*     */   
/*     */   private static class TblMdl
/*     */     extends AbstractTableModel
/*     */   {
/*  87 */     private List<CharsetDtls> charsets = CharsetMgr.getCharsets();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getRowCount()
/*     */     {
/*  94 */       return this.charsets.size();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getColumnCount()
/*     */     {
/* 102 */       return 3;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     public Object getValueAt(int rowIndex, int columnIndex)
/*     */     {
/* 110 */       switch (columnIndex) {
/* 111 */       case 0:  return "";
/* 112 */       case 1:  return ((CharsetDtls)this.charsets.get(rowIndex)).id;
/*     */       }
/* 114 */       return ((CharsetDtls)this.charsets.get(rowIndex)).description;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public String getColumnName(int column)
/*     */     {
/* 123 */       return CharsetSelection.COLUMN_NAMES[column];
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/utils/charsets/CharsetSelection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */