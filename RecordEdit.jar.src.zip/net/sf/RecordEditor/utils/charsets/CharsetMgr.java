/*     */ package net.sf.RecordEditor.utils.charsets;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.URL;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.SortedMap;
/*     */ import java.util.TreeMap;
/*     */ import java.util.TreeSet;
/*     */ import net.sf.JRecord.CsvParser.BasicCsvLineParserExtended;
/*     */ import net.sf.JRecord.CsvParser.CsvDefinition;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CharsetMgr
/*     */ {
/*  31 */   private static final List<CharsetDtls> charsets = new ArrayList(80);
/*  32 */   private static Map<String, String> charsetDescriptionMap = new HashMap(400);
/*  33 */   private static String[][] commonCharsets = { { "", "" }, { "ISO-8859-19", "5: Latin alphabet No. 9" }, { "US-ASCII", "American Standard Code for Information Interchange" }, { "UTF-16", "Sixteen-bit Unicode (or UCS) Transformation Format, byte orderidentified by an optional byte-order mark" }, { "UTF-32", "32-bit Unicode (or UCS) Transformation Format, byte orderidentified by an optional byte-order mark" }, { "UTF-8", "Eight-bit Unicode (or UCS) Transformation Format" }, { "windows-1252", "Windows Latin-1" } };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  42 */   private static boolean toInit = true;
/*     */   
/*     */   private static void doInit()
/*     */   {
/*  46 */     if (toInit) {
/*     */       try {
/*  48 */         charsetDtls = new TreeMap();
/*     */         
/*     */ 
/*  51 */         updateFromFile(charsetDtls, "Charsets1.txt");
/*  52 */         updateFromFile(charsetDtls, "Charsets2.txt");
/*  53 */         ArrayList<Charset> charsetList = new ArrayList(Charset.availableCharsets().values());
/*     */         
/*  55 */         Set<String> commonCharsetsSet = new TreeSet(Arrays.asList(new String[] { "US-ASCII", "ISO-8859-1", "ISO-8859-19", "UTF-8", "UTF-16", "UTF-32", "windows-1252" }));
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  65 */         commonCharsetsSet.add(Charset.defaultCharset().displayName());
/*     */         
/*  67 */         for (String[] ss : commonCharsets) {
/*  68 */           if (!"".equals(ss[0])) {
/*  69 */             String key = ss[0].toLowerCase();
/*  70 */             String desc = ss[1];
/*  71 */             if (charsetDtls.containsKey(key)) {
/*  72 */               desc = (String)charsetDtls.get(key);
/*     */             }
/*     */             
/*  75 */             charsets.add(new CharsetDtls(ss[0], desc, null));
/*     */           }
/*     */         }
/*     */         
/*  79 */         Collections.sort(charsetList, new CaseInsensitiveCharsetComparitor(null));
/*  80 */         for (Charset c : charsetList) {
/*  81 */           String desc = "";
/*  82 */           String id = c.displayName();
/*  83 */           String key = id.toLowerCase();
/*     */           
/*  85 */           if (charsetDtls.containsKey(key)) {
/*  86 */             desc = (String)charsetDtls.get(key);
/*     */           } else {
/*  88 */             Iterator<String> it = c.aliases().iterator();
/*  89 */             while (it.hasNext()) {
/*  90 */               key = ((String)it.next()).toLowerCase();
/*  91 */               if (charsetDtls.containsKey(key)) {
/*  92 */                 desc = (String)charsetDtls.get(key);
/*     */               }
/*     */             }
/*     */           }
/*     */           
/*  97 */           if (desc.length() > 0) {
/*  98 */             charsetDescriptionMap.put(key, desc);
/*  99 */             Iterator<String> it = c.aliases().iterator();
/* 100 */             while (it.hasNext()) {
/* 101 */               charsetDescriptionMap.put(it.next(), desc);
/*     */             }
/*     */           }
/* 104 */           charsets.add(new CharsetDtls(id, desc, c));
/*     */         }
/*     */       } catch (Throwable e) {
/*     */         Map<String, String> charsetDtls;
/* 108 */         e.printStackTrace();
/*     */       }
/*     */       
/* 111 */       toInit = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static final List<CharsetDtls> getCharsets()
/*     */   {
/* 119 */     doInit();
/* 120 */     return charsets;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public static final String[][] getCommonCharsets()
/*     */   {
/* 127 */     return commonCharsets;
/*     */   }
/*     */   
/*     */   public static String getDescription(String s) {
/* 131 */     String ret = "";
/*     */     
/* 133 */     doInit();
/* 134 */     if (s != null) {
/* 135 */       ret = (String)charsetDescriptionMap.get(s.toLowerCase());
/* 136 */       if (ret == null) {
/* 137 */         ret = "";
/*     */       }
/*     */     }
/* 140 */     return ret;
/*     */   }
/*     */   
/*     */   private static void updateFromFile(Map<String, String> charsetDtls, String filename) {
/* 144 */     try { InputStream in = CharsetMgr.class.getResource(filename).openStream();
/* 145 */       BufferedReader r = new BufferedReader(new InputStreamReader(in));
/*     */       
/*     */ 
/* 148 */       BasicCsvLineParserExtended p = new BasicCsvLineParserExtended(false);
/* 149 */       CsvDefinition csvDef = new CsvDefinition("\t", "");
/*     */       try { String s;
/* 151 */         while ((s = r.readLine()) != null) {
/* 152 */           String[] split = p.split(s, csvDef, 0);
/* 153 */           if (split.length > 2) {
/* 154 */             charsetDtls.put(split[0].toLowerCase(), split[2]);
/*     */           }
/*     */         }
/*     */       } finally {
/* 158 */         r.close();
/*     */       }
/*     */     } catch (Throwable e) {
/* 161 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   private static class CaseInsensitiveCharsetComparitor
/*     */     implements Comparator<Charset>
/*     */   {
/*     */     public int compare(Charset o1, Charset o2)
/*     */     {
/* 172 */       return String.CASE_INSENSITIVE_ORDER.compare(o1.displayName(), o2.displayName());
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/utils/charsets/CharsetMgr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */