/*    */ package net.sf.RecordEditor.utils.charsets;
/*    */ 
/*    */ import java.nio.charset.Charset;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class CharsetDtls
/*    */ {
/*    */   public final String id;
/*    */   public final String description;
/*    */   public final Charset charset;
/*    */   
/*    */   CharsetDtls(String id, String description, Charset charset)
/*    */   {
/* 24 */     this.id = id;
/* 25 */     this.description = description;
/* 26 */     this.charset = charset;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/utils/charsets/CharsetDtls.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */