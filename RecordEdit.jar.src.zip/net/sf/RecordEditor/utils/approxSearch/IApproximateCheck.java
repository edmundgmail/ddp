package net.sf.RecordEditor.utils.approxSearch;

public abstract interface IApproximateCheck
{
  public abstract int check(int paramInt);
  
  public abstract int getNextIndex();
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/utils/approxSearch/IApproximateCheck.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */