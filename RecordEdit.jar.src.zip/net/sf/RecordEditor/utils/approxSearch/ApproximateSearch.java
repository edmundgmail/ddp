/*    */ package net.sf.RecordEditor.utils.approxSearch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ApproximateSearch
/*    */ {
/*    */   public static final int search(int length, IApproximateCheck chk)
/*    */   {
/* 23 */     int n = 0;
/*    */     int c;
/* 25 */     if ((c = chk.check(n)) != 0)
/*    */     {
/* 27 */       if (c < 0) {
/* 28 */         n = -1;
/*    */       } else {
/* 30 */         int high = length - 1;
/* 31 */         n = Math.min(high - 1, Math.max(1, chk.getNextIndex()));
/* 32 */         if (chk.check(high) < 0) {
/* 33 */           int low = 1;
/* 34 */           while ((c = chk.check(n)) != 0) {
/* 35 */             if (c < 0) {
/* 36 */               high = n - 1;
/*    */             } else {
/* 38 */               low = n + 1;
/*    */             }
/* 40 */             n = Math.min(high, Math.max(low, chk.getNextIndex()));
/*    */           }
/*    */         } else {
/* 43 */           n = high;
/*    */         }
/*    */       }
/*    */     }
/* 47 */     return n;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/utils/approxSearch/ApproximateSearch.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */