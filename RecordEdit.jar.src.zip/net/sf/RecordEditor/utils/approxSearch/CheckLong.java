/*    */ package net.sf.RecordEditor.utils.approxSearch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class CheckLong
/*    */   implements IApproximateCheck
/*    */ {
/* 12 */   private int n = 0;
/*    */   private int ave;
/*    */   private int size;
/*    */   private long search;
/*    */   
/*    */   public CheckLong() {}
/*    */   
/*    */   public CheckLong(int size, long search, int ave)
/*    */   {
/* 21 */     set(size, search, ave);
/*    */   }
/*    */   
/*    */   public CheckLong set(int size, long search, int ave) {
/* 25 */     this.size = size;
/* 26 */     this.search = search;
/* 27 */     this.ave = ave;
/*    */     
/* 29 */     this.n = 0;
/*    */     
/* 31 */     return this;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public final void setSearch(long search)
/*    */   {
/* 38 */     this.search = search;
/* 39 */     this.n = 0;
/*    */   }
/*    */   
/*    */   public int getNextIndex()
/*    */   {
/* 44 */     return this.n;
/*    */   }
/*    */   
/*    */ 
/*    */   public int check(int idx)
/*    */   {
/* 50 */     int r = 0;
/*    */     
/*    */     long g;
/* 53 */     if (this.search < (g = get(idx))) {
/* 54 */       r = -1;
/* 55 */       this.n = (idx + (int)((this.search - g) / this.ave) - 1);
/*    */     }
/* 57 */     else if ((idx < this.size - 1) && (this.search >= (g = get(idx + 1)))) {
/* 58 */       r = 1;
/* 59 */       this.n = (idx + (int)(this.search - g) / this.ave + 1);
/*    */     }
/*    */     
/* 62 */     return r;
/*    */   }
/*    */   
/*    */   public abstract long get(int paramInt);
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/utils/approxSearch/CheckLong.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */