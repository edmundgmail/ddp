package net.sf.RecordEditor.utils.approxSearch;

interface package-info {}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/utils/approxSearch/package-info.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       0.7.1
 */