package net.sf.RecordEditor.utils.common;

public abstract interface ReActionHandlerWithSave
  extends ReActionHandler
{
  public abstract boolean saveOk();
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/utils/common/ReActionHandlerWithSave.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */