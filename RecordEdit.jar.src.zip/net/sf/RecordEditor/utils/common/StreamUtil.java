/*    */ package net.sf.RecordEditor.utils.common;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ 
/*    */ public class StreamUtil
/*    */ {
/*    */   public static byte[] read(InputStream in, int bytesToRead) throws java.io.IOException
/*    */   {
/*  9 */     byte[] data = new byte[bytesToRead];
/* 10 */     int total = 0;
/*    */     try
/*    */     {
/* 13 */       int num = in.read(data);
/* 14 */       total = num;
/*    */       
/* 16 */       while ((num >= 0) && (total < bytesToRead)) {
/* 17 */         num = in.read(data, total, bytesToRead - total);
/* 18 */         total += Math.max(0, num);
/*    */       }
/*    */     } finally {
/* 21 */       in.close();
/*    */     }
/*    */     
/* 24 */     if (total <= 0) {
/* 25 */       data = new byte[0];
/* 26 */     } else if (total < bytesToRead) {
/* 27 */       byte[] t = new byte[total];
/* 28 */       System.arraycopy(data, 0, t, 0, total);
/* 29 */       data = t;
/*    */     }
/*    */     
/* 32 */     return data;
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/utils/common/StreamUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */