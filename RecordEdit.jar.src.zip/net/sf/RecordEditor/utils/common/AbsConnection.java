package net.sf.RecordEditor.utils.common;

import java.sql.Connection;

public abstract interface AbsConnection
{
  public abstract Connection getConnection();
  
  public abstract Connection getUpdateConnection();
  
  public abstract boolean isTempUpdateConnection();
  
  public abstract void free();
}


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/utils/common/AbsConnection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */