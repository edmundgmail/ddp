/*    */ package net.sf.RecordEditor.utils.common;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class GcManager
/*    */ {
/* 11 */   private static boolean canDoGC = true;
/* 12 */   private static long lastGC = Long.MIN_VALUE;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public static final void doGcIfNeccessary()
/*    */   {
/* 19 */     doGcIfNeccessary(getSpaceUsedRatio(), 0.8D);
/*    */   }
/*    */   
/*    */   public static final void doGcIfNeccessary(double maxRatio) {
/* 23 */     doGcIfNeccessary(getSpaceUsedRatio(), maxRatio);
/*    */   }
/*    */   
/*    */   public static final void doGcIfNeccessarySupplyRatio(double spaceRatio) {
/* 27 */     doGcIfNeccessary(spaceRatio, 0.8D);
/*    */   }
/*    */   
/*    */   public static final void doGcIfNeccessary(double spaceRatio, double maxRatio) {
/* 31 */     long time = System.currentTimeMillis();
/* 32 */     if ((spaceRatio > maxRatio) || (Math.abs(time - lastGC) > 10000L)) {
/* 33 */       if ((canDoGC) && (Math.abs(time - lastGC) > 1000L)) {
/*    */         try {
/* 35 */           lastGC = time;
/* 36 */           System.gc();
/*    */         } catch (Exception e) {
/* 38 */           e.printStackTrace();
/*    */         }
/*    */       }
/* 41 */       canDoGC = false;
/*    */     } else {
/* 43 */       canDoGC = true;
/*    */     }
/*    */   }
/*    */   
/*    */   public static double getSpaceUsedRatio()
/*    */   {
/* 49 */     Runtime rt = Runtime.getRuntime();
/* 50 */     return rt.totalMemory() / rt.maxMemory();
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/utils/common/GcManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */