/*    */ package net.sf.RecordEditor.utils.common;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ 
/*    */ public class ReConnection implements AbsConnection
/*    */ {
/*    */   private int dbIndex;
/*    */   
/*    */   public ReConnection(int dbId) {
/* 10 */     this.dbIndex = dbId;
/*    */   }
/*    */   
/*    */   public void free()
/*    */   {
/* 15 */     Common.freeConnection(this.dbIndex);
/*    */   }
/*    */   
/*    */   public Connection getConnection()
/*    */   {
/* 20 */     return Common.getDBConnectionLogErrors(this.dbIndex);
/*    */   }
/*    */   
/*    */ 
/*    */   public Connection getUpdateConnection()
/*    */   {
/* 26 */     return Common.getUpdateConnection(this.dbIndex);
/*    */   }
/*    */   
/*    */ 
/*    */   public boolean isTempUpdateConnection()
/*    */   {
/* 32 */     return false;
/*    */   }
/*    */   
/*    */   public static ReConnection getConnection(int dbIdx) {
/* 36 */     return new ReConnection(dbIdx);
/*    */   }
/*    */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/utils/common/ReConnection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */