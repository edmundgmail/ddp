/*     */ package net.sf.RecordEditor.utils.common;
/*     */ 
/*     */ public class ActionConstants
/*     */ {
/*   5 */   public final int SAVE = 1;
/*     */   
/*   7 */   public final int SAVE_AS = 2;
/*   8 */   public final int EXPORT_AS_HTML = 3;
/*   9 */   public final int EXPORT_AS_HTML_TBL_PER_ROW = 4;
/*  10 */   public final int EXPORT_VELOCITY = 5;
/*  11 */   public final int SAVE_AS_XML = 44;
/*  12 */   public final int SAVE_LAYOUT_XML = 45;
/*  13 */   public final int EXPORT_HTML_TREE = 46;
/*  14 */   public final int EXPORT_AS_CSV = 51;
/*  15 */   public final int EXPORT_AS_FIXED = 52;
/*     */   
/*  17 */   public final int DELETE = 6;
/*     */   
/*  19 */   public final int FIND = 7;
/*     */   
/*  21 */   public final int FILTER = 8;
/*     */   
/*  23 */   public final int OPEN = 9;
/*     */   
/*  25 */   public final int CLOSE = 10;
/*  26 */   public final int CLOSE_ALL = 11;
/*     */   
/*  28 */   public final int NEW = 12;
/*  29 */   public final int CORRECT_RECORD_LENGTH = 13;
/*     */   
/*  31 */   public final int TABLE_VIEW_SELECTED = 14;
/*  32 */   public final int RECORD_VIEW_SELECTED = 15;
/*  33 */   public final int COLUMN_VIEW_SELECTED = 16;
/*  34 */   public final int SELECTED_VIEW = 55;
/*  35 */   public final int BUILD_FIELD_TREE = 17;
/*  36 */   public final int BUILD_SORTED_TREE = 18;
/*  37 */   public final int BUILD_RECORD_TREE = 19;
/*  38 */   public final int BUILD_LAYOUT_TREE = 20;
/*     */   
/*  40 */   public final int BUILD_XML_TREE_SELECTED = 21;
/*  41 */   public final int BUILD_LAYOUT_TREE_SELECTED = 22;
/*     */   
/*  43 */   public final int HELP = 23;
/*     */   
/*  45 */   public final int COPY_SELECTED_CELLS = 76;
/*  46 */   public final int COPY_RECORD = 24;
/*     */   
/*  48 */   public final int CUT_RECORD = 25;
/*  49 */   public final int CUT_SELECTED_CELLS = 81;
/*  50 */   public final int CLEAR_SELECTED_CELLS = 82;
/*     */   
/*  52 */   public final int PASTE_RECORD = 26;
/*     */   
/*  54 */   public final int PASTE_RECORD_PRIOR = 27;
/*     */   
/*  56 */   public final int PASTE_RECORD_POPUP = 73;
/*     */   
/*  58 */   public final int PASTE_RECORD_PRIOR_POPUP = 74;
/*  59 */   public final int PASTE_TABLE_OVER_SELECTION = 75;
/*  60 */   public final int PASTE_TABLE_OVERWRITE = 47;
/*  61 */   public final int PASTE_TABLE_INSERT = 48;
/*  62 */   public final int PASTE_INSERT_CELLS = 79;
/*     */   
/*     */ 
/*     */ 
/*  66 */   public final int INSERT_RECORDS = 28;
/*     */   
/*  68 */   public final int DELETE_RECORD = 29;
/*     */   
/*  70 */   public final int DELETE_SELECTED_CELLS = 80;
/*     */   
/*  72 */   public final int SORT = 30;
/*     */   
/*  74 */   public final int REPEAT_RECORD_POPUP = 31;
/*  75 */   public final int NEXT_RECORD = 32;
/*  76 */   public final int PREVIOUS_RECORD = 33;
/*     */   
/*  78 */   public final int CREATE_CHILD = 34;
/*  79 */   public final int EDIT_CHILD = 35;
/*  80 */   public final int PRINT = 36;
/*  81 */   public final int PRINT_SELECTED = 54;
/*  82 */   public final int REBUILD_TREE = 37;
/*     */   
/*     */ 
/*  85 */   public final int ADD_ATTRIBUTES = 38;
/*     */   
/*  87 */   public final int FULL_TREE_REBUILD = 39;
/*  88 */   public final int EXECUTE_SAVED_FILTER = 40;
/*  89 */   public final int EXECUTE_SAVED_SORT_TREE = 41;
/*  90 */   public final int EXECUTE_SAVED_RECORD_TREE = 42;
/*  91 */   public final int COMPARE_WITH_DISK = 43;
/*     */   
/*     */ 
/*  94 */   public final int SHOW_INVALID_ACTIONS = 49;
/*  95 */   public final int AUTOFIT_COLUMNS = 50;
/*     */   
/*  97 */   public final int INSERT_RECORD_PRIOR = 53;
/*  98 */   public final int EXPORT_XSLT = 56;
/*  99 */   public final int EXPORT = 57;
/* 100 */   public final int EXPORT_SCRIPT = 58;
/* 101 */   public final int RUN_SCRIPT = 59;
/* 102 */   public final int REFRESH = 60;
/*     */   
/* 104 */   public final int CLOSE_TAB = 61;
/* 105 */   public final int UNDOCK_TAB = 62;
/* 106 */   public final int UNDOCK_ALL_TABS = 63;
/* 107 */   public final int DOCK_TAB = 64;
/* 108 */   public final int DOCK_ALL_SCREENS = 65;
/*     */   
/* 110 */   public final int REMOVE_CHILD_SCREEN = 66;
/* 111 */   public final int ADD_CHILD_SCREEN = 67;
/* 112 */   public final int ADD_CHILD_SCREEN_RIGHT = 68;
/* 113 */   public final int ADD_CHILD_SCREEN_BOTTOM = 69;
/* 114 */   public final int ADD_CHILD_SCREEN_SWAP = 70;
/*     */   
/* 116 */   public final int INSERT_RECORDS_POPUP = 71;
/* 117 */   public final int INSERT_RECORD_PRIOR_POPUP = 72;
/* 118 */   public final int DELETE_RECORD_POPUP = 77;
/* 119 */   public final int DELETE_BUTTON = 78;
/*     */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/utils/common/ActionConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */