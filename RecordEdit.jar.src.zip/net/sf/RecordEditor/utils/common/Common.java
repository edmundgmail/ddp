/*      */ package net.sf.RecordEditor.utils.common;
/*      */ 
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.GraphicsEnvironment;
/*      */ import java.awt.Insets;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.Toolkit;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import java.lang.reflect.Method;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URI;
/*      */ import java.net.URL;
/*      */ import java.net.URLClassLoader;
/*      */ import java.nio.file.Files;
/*      */ import java.nio.file.attribute.FileAttribute;
/*      */ import java.sql.Connection;
/*      */ import java.sql.Driver;
/*      */ import java.sql.DriverManager;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.Properties;
/*      */ import javax.swing.ImageIcon;
/*      */ import javax.swing.JFrame;
/*      */ import javax.swing.JTable;
/*      */ import javax.swing.table.JTableHeader;
/*      */ import javax.swing.table.TableCellEditor;
/*      */ import javax.swing.table.TableCellRenderer;
/*      */ import javax.swing.table.TableColumn;
/*      */ import javax.swing.table.TableColumnModel;
/*      */ import javax.swing.table.TableModel;
/*      */ import net.sf.JRecord.Common.CommonBits;
/*      */ import net.sf.JRecord.Common.Constants;
/*      */ import net.sf.JRecord.External.CopybookWriterManager;
/*      */ import net.sf.JRecord.Log.AbsSSLogger;
/*      */ import net.sf.JRecord.Log.TextLog;
/*      */ import net.sf.RecordEditor.utils.lang.LangConversion;
/*      */ import net.sf.RecordEditor.utils.params.BoolOpt;
/*      */ import net.sf.RecordEditor.utils.params.Parameters;
/*      */ import net.sf.RecordEditor.utils.params.ProgramOptions;
/*      */ import net.sf.RecordEditor.utils.params.ProgramOptions.IntOpt;
/*      */ import net.sf.RecordEditor.utils.params.ProgramOptions.MultiValOpt;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Common
/*      */   implements Constants
/*      */ {
/*      */   public static final String CURRENT_VERSION = "0097g";
/*      */   public static final int BOOLEAN_OPERATOR_OR = 0;
/*      */   public static final int BOOLEAN_OPERATOR_AND = 1;
/*      */   public static final String BOOLEAN_AND_STRING = "And";
/*      */   public static final String BOOLEAN_OR_STRING = "Or";
/*      */   public static final int DB_OTHER = 1;
/*      */   public static final int DB_HSQL = 2;
/*      */   public static final int DB_MSACCESS = 3;
/*      */   public static final String PO_INIT_CLASS = "net.sf.RecordEditor.po.PoInit";
/*      */   public static final String GENERATED_CSV_SCHEMA_NAME = "GeneratedCsvRecord";
/*  107 */   public static final ProgramOptions OPTIONS = new ProgramOptions();
/*  108 */   public static final Object MISSING_VALUE = CommonBits.NULL_VALUE;
/*  109 */   public static final Object MISSING_REQUIRED_VALUE = new String(new char[0]);
/*      */   
/*  111 */   public static final Color EMPTY_COLOR = new Color(230, 230, 255);
/*  112 */   public static final Color MISSING_COLOR = new Color(255, 230, 230);
/*      */   
/*      */ 
/*      */ 
/*      */   public static final String COLUMN_LINE_SEP = "|";
/*      */   
/*      */ 
/*      */   public static final String CSV_PROGRAM_ID = "csv";
/*      */   
/*      */ 
/*  122 */   public static final boolean TEST_MODE = "Y".equalsIgnoreCase(Parameters.getString("TestMode"));
/*      */   
/*  124 */   public static final boolean NAME_COMPONENTS = "Y".equalsIgnoreCase(Parameters.getString("NameFields"));
/*      */   
/*  126 */   public static final boolean RECORD_EDITOR_LAF = "RecordEditor_Default".equalsIgnoreCase(Parameters.getString("LooksClassName"));
/*      */   
/*      */ 
/*      */   public static final boolean NIMBUS_LAF;
/*      */   
/*      */ 
/*  132 */   public static final boolean IS_MAC = Parameters.IS_MAC;
/*  133 */   public static final boolean IS_NIX = Parameters.IS_NIX;
/*  134 */   public static final boolean IS_WINDOWS = Parameters.IS_WINDOWS;
/*      */   
/*  136 */   public static final float JAVA_VERSION = Parameters.JAVA_VERSION;
/*      */   
/*      */   private static String[] jdbcJarNames;
/*      */   
/*      */   private static boolean searchActiveDB;
/*      */   
/*      */   public static final String HELP_CSV_EDITOR = "HlpCsv02.htm";
/*      */   
/*      */   public static final String HELP_COBOL_EDITOR = "HlpCe02.htm";
/*      */   
/*      */   public static final String HELP_RECORD_MAIN = "HlpRe02.htm";
/*      */   
/*      */   public static final String HELP_RECORD_TABLE = "HlpRe03.htm";
/*      */   
/*      */   public static final String HELP_SINGLE_RECORD = "HlpRe04.htm";
/*      */   
/*      */   public static final String HELP_SEARCH = "HlpRe05.htm";
/*      */   
/*      */   public static final String HELP_FILTER = "HlpRe06.htm";
/*      */   
/*      */   public static final String HELP_SAVE_AS = "HlpRe07.htm";
/*      */   
/*      */   public static final String HELP_SORT = "HlpRe10.htm";
/*      */   
/*      */   public static final String HELP_FIELD_TREE = "HlpRe11.htm";
/*      */   
/*      */   public static final String HELP_SORT_TREE = "HlpRe12.htm";
/*      */   
/*      */   public static final String HELP_RECORD_TREE = "HlpRe13.htm";
/*      */   
/*      */   public static final String HELP_TREE_VIEW = "HlpRe14.htm";
/*      */   
/*      */   public static final String HELP_COLUMN_VIEW = "HlpRe15.htm";
/*      */   
/*      */   public static final String HELP_GENERIC_CSV = "HlpRe16.htm#HDRGENERICCSV";
/*      */   
/*      */   public static final String DATE_FORMAT_DESCRIPTION;
/*      */   
/*      */   public static final String HELP_DIFF = "diff.html";
/*      */   
/*      */   public static final String HELP_DIFF_SL = "diff2.html";
/*      */   
/*      */   public static final String HELP_DIFF_TL = "diff3.html";
/*      */   
/*      */   public static final String HELP_MENU = "HlpLe.htm";
/*      */   
/*      */   public static final String HELP_UPGRADE = "HlpLe.htm#Upgrade";
/*      */   
/*      */   public static final String HELP_LAYOUT_RECORD_DEF = "HlpLe02.htm";
/*      */   
/*      */   public static final String HELP_LAYOUT_CHILD = "HlpLe02.htm#HDRCHILD";
/*      */   
/*      */   public static final String HELP_LAYOUT_FIELD = "HlpLe02.htm#HDRFIELD";
/*      */   
/*      */   public static final String HELP_LAYOUT_RECSEL = "HlpLe02.htm#HDRRECSEL";
/*      */   
/*      */   public static final String HELP_LAYOUT_EXTRA = "HlpLe02.htm#HDREXTRA";
/*      */   
/*      */   public static final String HELP_LAYOUT_RECORD = "HlpLe03.htm";
/*      */   
/*      */   public static final String HELP_LAYOUT_DETAILS = "HlpLe03.htm#RecordDtls";
/*      */   
/*      */   public static final String HELP_LAYOUT_LIST = "HlpLe03.htm#RecordList";
/*      */   
/*      */   public static final String HELP_WIZARD = "HlpLe04.htm";
/*      */   
/*      */   public static final String HELP_WIZARD_PNL2 = "HlpLe04.htm#HDRWIZ2";
/*      */   
/*      */   public static final String HELP_WIZARD_PNL3 = "HlpLe04.htm#HDRWIZ3";
/*      */   
/*      */   public static final String HELP_WIZARD_PNL4 = "HlpLe04.htm#HDRWIZ4";
/*      */   
/*      */   public static final String HELP_WIZARD_PNL5 = "HlpLe04.htm#HDRWIZ5";
/*      */   
/*      */   public static final String HELP_WIZARD_RECORD_TYPE = "HlpLe04.htm#HDRWIZRECORDTYPE";
/*      */   
/*      */   public static final String HELP_WIZARD_RECORD_NAMES = "HlpLe04.htm#HDRWIZRECORDNAMES";
/*      */   
/*      */   public static final String HELP_WIZARD_RECORD_FIELD_DEF = "HlpLe04.htm#HDRWIZ2M";
/*      */   
/*      */   public static final String HELP_WIZARD_RECORD_FIELD_NAMES = "HlpLe04.htm#HDRWIZ3M";
/*      */   
/*      */   public static final String HELP_WIZARD_FILE_STRUCTURE = "HlpLe04.htm#HDRWIZFILESTRUCTURE";
/*      */   
/*      */   public static final String HELP_WIZARD_SAVE = "HlpLe04.htm#HDRWIZSAVE1";
/*      */   
/*      */   public static final String HELP_COMBO_SEARCH = "HlpLe05.htm#HDRCOMBOSEL";
/*      */   
/*      */   public static final String HELP_COMBO_EDIT = "HlpLe05.htm#HDRCOMBOPNL";
/*      */   
/*      */   public static final String HELP_TABLE = "HlpLe07.htm";
/*      */   
/*      */   public static final String HELP_COPYBOOK = "HlpLe08.htm";
/*      */   
/*      */   public static final String HELP_XML_COPYBOOK = "HlpLe08aaa.htm";
/*      */   
/*      */   public static final String HELP_COPYBOOK_CHOOSE = "HlpLe09.htm";
/*      */   
/*      */   public static final String HELP_COPY_LAYOUT = "HlpLe10.htm";
/*      */   
/*      */   public static final String HELP_SCRIPT = "HlpRe17.htm";
/*      */   
/*      */   public static final String FILE_SAVE_FAILED;
/*      */   
/*      */   private static final String DATABASE_NAME;
/*      */   
/*      */   private static final int DEFAULT_ROOM_AROUND_SCREEN = 34;
/*      */   
/*      */   private static int spaceAtBottomOfScreen;
/*      */   
/*      */   private static int spaceAtLeftOfScreen;
/*      */   
/*      */   private static int spaceAtRightOfScreen;
/*      */   
/*      */   private static int spaceAtTopOfScreen;
/*      */   
/*      */   public static final long MAX_MEMORY;
/*      */   
/*      */   public static final BigDecimal MAX_MEMORY_BD;
/*      */   
/*      */   public static final int ID_SEARCH_ICON = 0;
/*      */   
/*      */   public static final int ID_FILTER_ICON = 1;
/*      */   
/*      */   public static final int ID_SAVE_ICON = 2;
/*      */   
/*      */   public static final int ID_SAVE_AS_ICON = 3;
/*      */   
/*      */   public static final int ID_COPY_ICON = 4;
/*      */   
/*      */   public static final int ID_CUT_ICON = 5;
/*      */   
/*      */   public static final int ID_PASTE_ICON = 6;
/*      */   
/*      */   public static final int ID_PASTE_PRIOR_ICON = 7;
/*      */   
/*      */   public static final int ID_NEW_ICON = 8;
/*      */   
/*      */   public static final int ID_SETLENGTH_ICON = 9;
/*      */   
/*      */   public static final int ID_DELETE_ICON = 10;
/*      */   
/*      */   public static final int ID_OPEN_ICON = 12;
/*      */   
/*      */   public static final int ID_SORT_ICON = 13;
/*      */   
/*      */   public static final int ID_HELP_ICON = 11;
/*      */   
/*      */   public static final int ID_NEXT_ICON = 14;
/*      */   
/*      */   public static final int ID_PREV_ICON = 15;
/*      */   
/*      */   public static final int ID_PRINT_ICON = 16;
/*      */   
/*      */   public static final int ID_PREF_ICON = 17;
/*      */   
/*      */   public static final int ID_TREE_ICON = 18;
/*      */   
/*      */   public static final int ID_AUTOFIT_ICON = 19;
/*      */   
/*      */   public static final int ID_COLUMN_DTLS_ICON = 20;
/*      */   
/*      */   public static final int ID_COLUMN_VIEW_ICON = 21;
/*      */   
/*      */   public static final int ID_COLUMN_COPY_ICON = 22;
/*      */   
/*      */   public static final int ID_COLUMN_DELETE_ICON = 23;
/*      */   
/*      */   public static final int ID_COLUMN_MOVE_ICON = 24;
/*      */   
/*      */   public static final int ID_COLUMN_INSERT_ICON = 25;
/*      */   
/*      */   public static final int ID_EDIT_RECORD_ICON = 26;
/*      */   
/*      */   public static final int ID_NEW_UP_ICON = 27;
/*      */   
/*      */   public static final int ID_PASTE_UP_ICON = 28;
/*      */   
/*      */   public static final int ID_EXPORT_ICON = 29;
/*      */   
/*      */   public static final int ID_SAVEAS_CSV_ICON = 30;
/*      */   
/*      */   public static final int ID_SAVEAS_FIXED_ICON = 31;
/*      */   
/*      */   public static final int ID_SAVEAS_HTML_ICON = 32;
/*      */   
/*      */   public static final int ID_SAVEAS_XML_ICON = 33;
/*      */   
/*      */   public static final int ID_SAVEAS_VELOCITY_ICON = 34;
/*      */   
/*      */   public static final int ID_SUMMARY_ICON = 35;
/*      */   
/*      */   public static final int ID_SORT_SUM_ICON = 36;
/*      */   
/*      */   public static final int ID_VIEW_RECORD_ICON = 37;
/*      */   
/*      */   public static final int ID_VIEW_TABLE_ICON = 38;
/*      */   
/*      */   public static final int ID_VIEW_COLUMN_ICON = 39;
/*      */   
/*      */   public static final int ID_EXIT_ICON = 40;
/*      */   
/*      */   public static final int ID_GOTO_ICON = 41;
/*      */   
/*      */   public static final int ID_RELOAD_ICON = 42;
/*      */   
/*      */   public static final int ID_WIZARD_ICON = 43;
/*      */   
/*      */   public static final int ID_LAYOUT_CREATE_ICON = 44;
/*      */   
/*      */   public static final int ID_LAYOUT_EDIT_ICON = 45;
/*      */   
/*      */   public static final int ID_COMBO_EDIT_ICON = 46;
/*      */   
/*      */   public static final int ID_FILE_SEARCH_ICON = 47;
/*      */   
/*      */   public static final int ID_DIRECTORY_SEARCH_ICON = 48;
/*      */   
/*      */   public static final int ID_EXPORT_SCRIPT_ICON = 49;
/*      */   
/*      */   public static final int ID_SCRIPT_ICON = 50;
/*      */   
/*      */   public static final int ID_MENU_FOLDER = 51;
/*      */   
/*      */   public static final int ID_MAX_ICON = 52;
/*      */   
/*      */   public static final int TI_FIELD_TYPE = 1;
/*      */   
/*      */   public static final int TI_RECORD_TYPE = 2;
/*      */   
/*      */   public static final int TI_SYSTEMS = 3;
/*      */   
/*      */   public static final int TI_FILE_STRUCTURE = 4;
/*      */   
/*      */   public static final int TI_FORMAT = 5;
/*      */   
/*      */   private static int copybookWriterIndex;
/*      */   
/*      */   private static boolean doFree;
/*      */   
/*      */   public static final int LOOKS_INDEX;
/*      */   
/*      */   public static final int UNKNOWN_SYSTEM = 0;
/*      */   
/*      */   public static final int ALL_FIELDS = -102;
/*      */   
/*      */   private static final boolean USE_PNG;
/*      */   
/*      */   private static final String[] ICON_NAMES;
/*      */   
/*      */   private static ImageIcon[] icon;
/*      */   
/*      */   private static ImageIcon[] treeIcons;
/*      */   
/*      */   private static ImageIcon[] recIcon;
/*      */   
/*      */   private static int[] reActionRef;
/*      */   
/*      */   private static Class currClass;
/*      */   
/*      */   private static AbsSSLogger logger;
/*      */   
/*      */   private static boolean yet2Init;
/*      */   
/*      */   private static boolean yet2Assign;
/*      */   
/*      */   private static String[] driver;
/*      */   
/*      */   private static String[] commitFlag;
/*      */   
/*      */   private static String[] checkpointFlag;
/*      */   private static String[] dataSource;
/*      */   private static String[] readOnlySource;
/*      */   private static String[] sourceId;
/*      */   private static String[] userId;
/*      */   private static String[] password;
/*      */   private static String[] jdbcMsg;
/*      */   private static Connection[] dbConnection;
/*      */   private static Connection[] dbUpdate;
/*      */   private static boolean[] autoClose;
/*      */   private static boolean[] dropSemi;
/*      */   public static final String DATE_FORMAT_STR;
/*      */   public static final String USER_INIT_CLASS;
/*      */   public static final String GETTEXT_PO_LAYOUT = "<?xml version=\"1.0\" ?><RECORD RECORDNAME=\"GetText_PO\" COPYBOOK=\"\" DELIMITER=\"&lt;Tab&gt;\" FILESTRUCTURE=\"101\" STYLE=\"0\" RECORDTYPE=\"Delimited\" LIST=\"Y\" QUOTE=\"\" RecSep=\"default\" LINE_NO_FIELD_NAMES=\"1\">\t<FIELDS>\t\t<FIELD NAME=\"msgctxt\" POSITION=\"1\" TYPE=\"118\"/>\t\t<FIELD NAME=\"msgid\" POSITION=\"2\" TYPE=\"118\"/>\t\t<FIELD NAME=\"msgstr\" POSITION=\"3\" TYPE=\"118\"/>\t\t<FIELD NAME=\"comments\" POSITION=\"4\" TYPE=\"118\"/>\t\t<FIELD NAME=\"msgidPlural\" POSITION=\"5\" TYPE=\"118\"/>\t\t<FIELD NAME=\"msgstrPlural\" POSITION=\"6\" TYPE=\"92\"/>\t\t<FIELD NAME=\"extractedComments\" POSITION=\"7\" TYPE=\"118\"/>\t\t<FIELD NAME=\"reference\" POSITION=\"8\" TYPE=\"118\"/>\t\t<FIELD NAME=\"flags\" POSITION=\"9\" TYPE=\"118\"/>\t\t<FIELD NAME=\"previousMsgctx\" POSITION=\"10\" TYPE=\"118\"/>\t\t<FIELD NAME=\"previousMsgId\" POSITION=\"11\" TYPE=\"118\"/>\t\t<FIELD NAME=\"previousMsgidPlural\" POSITION=\"12\" TYPE=\"118\"/>\t\t<FIELD NAME=\"fuzzy\" POSITION=\"13\" TYPE=\"109\"/>\t\t<FIELD NAME=\"obsolete\" POSITION=\"14\" TYPE=\"109\"/>\t</FIELDS></RECORD>";
/*      */   public static final String TIP_LAYOUT = "<?xml version=\"1.0\" ?><RECORD RECORDNAME=\"TipDetails\" COPYBOOK=\"\" DELIMITER=\"&lt;Tab&gt;\" FILESTRUCTURE=\"102\" STYLE=\"0\" RECORDTYPE=\"Delimited\"  LIST=\"Y\" QUOTE=\"\" RecSep=\"default\" LINE_NO_FIELD_NAMES=\"1\">\t<FIELDS>\t\t<FIELD NAME=\"name\" POSITION=\"1\" TYPE=\"Char\"/>\t\t<FIELD NAME=\"description\" POSITION=\"2\" TYPE=\"118\"/>\t</FIELDS></RECORD>";
/*      */   public static final String DEFAULT_STRUCTURE;
/*      */   public static final String STANDARD_CHARS = "+-.,/?\\!'\"$%&*@()[]abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
/*      */   public static final String STANDARD_CHARS0 = "+-.,abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
/*      */   public static final String STANDARD_CHARS1;
/*      */   public static final String FILE_SEPERATOR;
/*      */   public static final String[] FIELD_SEPARATOR_LIST;
/*      */   public static final String[] FIELD_SEPARATOR_LIST1;
/*      */   public static final String[] FIELD_SEPARATOR_TEXT_LIST;
/*      */   public static final String[] FIELD_SEPARATOR_LIST1_VALUES;
/*      */   public static final String[] QUOTE_LIST;
/*      */   public static final String[] QUOTE_VALUES;
/*      */   private static String[] TABLE_NAMES;
/*      */   private static int connectionIndex;
/*      */   private static boolean readOnly;
/*      */   private static String htmlDir;
/*      */   private static final int TABLE_WINDOW_SIZE_TO_CHECK = 200;
/*      */   private static final int MINIMUM_MAX_COLUMN_WIDTH = 100;
/*      */   private static String[] reActionNames;
/*      */   private static String[] reActionDesc;
/*      */   private static boolean velocityAvailable;
/*      */   private static boolean toCheckVelocity;
/*      */   private static boolean toWarn;
/*      */   private static boolean dbDefined;
/*      */   
/*      */   public static String getTblLookupKey(int tblId)
/*      */   {
/*  447 */     return "Tbl_" + TABLE_NAMES[tblId] + "_";
/*      */   }
/*      */   
/*      */   static
/*      */   {
/*  138 */     NIMBUS_LAF = ((RECORD_EDITOR_LAF) && (IS_NIX)) || ("Nimbus".equalsIgnoreCase(Parameters.getString("LooksClassName")));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  149 */     jdbcJarNames = null;
/*      */     
/*  151 */     searchActiveDB = true;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  175 */     DATE_FORMAT_DESCRIPTION = LangConversion.convertId(2, "DateFormatDescription", "Please remember that Date formats are case sensitive:<ul compact><li>dd   - is 2 character day (lowercase d for day)</li><li>MM   - is 2 character month (uppercase M for month)</li><li>MMM  - is 3 character month (uppercase M for month)</li><li>yy   - is 2 character year (lowercase y for month)</li><li>yyyy - is 4 character year (lowercase y for month)</li></ul><br>use dd/MM/yy for 25/12/98, dd.MM.yyyy for 25.Dec.1998");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  229 */     FILE_SAVE_FAILED = LangConversion.convert("File Save Failed:");
/*      */     
/*  231 */     DATABASE_NAME = fix(Parameters.getString("DefaultDB"));
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  236 */     spaceAtBottomOfScreen = 34;
/*  237 */     spaceAtLeftOfScreen = 1;
/*  238 */     spaceAtRightOfScreen = 1;
/*  239 */     spaceAtTopOfScreen = 1;
/*      */     
/*      */ 
/*      */ 
/*  243 */     MAX_MEMORY = Runtime.getRuntime().maxMemory();
/*  244 */     MAX_MEMORY_BD = BigDecimal.valueOf(MAX_MEMORY);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  308 */     copybookWriterIndex = -121;
/*      */     
/*  310 */     doFree = true;
/*      */     
/*      */ 
/*      */ 
/*  314 */     LOOKS_INDEX = getIntProperty(0, "LooksClassIndex");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  336 */     ICON_NAMES = new String[] { "LeftM", "Left", "Up", "Down", "Right", "RightM" };
/*      */     
/*      */ 
/*  339 */     icon = new ImageIcon[ICON_NAMES.length - 2];
/*  340 */     treeIcons = new ImageIcon[ICON_NAMES.length];
/*  341 */     recIcon = new ImageIcon[53];
/*  342 */     reActionRef = new int[84];
/*      */     
/*      */ 
/*      */ 
/*  346 */     currClass = Common.class;
/*      */     
/*  348 */     logger = null;
/*      */     
/*  350 */     yet2Init = true;
/*  351 */     yet2Assign = true;
/*      */     
/*      */ 
/*  354 */     driver = new String[16];
/*      */     
/*  356 */     commitFlag = new String[16];
/*  357 */     checkpointFlag = new String[16];
/*  358 */     dataSource = new String[16];
/*  359 */     readOnlySource = new String[16];
/*  360 */     sourceId = new String[16];
/*      */     
/*  362 */     userId = new String[16];
/*  363 */     password = new String[16];
/*  364 */     jdbcMsg = new String[16];
/*  365 */     dbConnection = new Connection[16];
/*  366 */     dbUpdate = new Connection[16];
/*  367 */     autoClose = new boolean[16];
/*  368 */     dropSemi = new boolean[16];
/*      */     
/*      */ 
/*      */ 
/*  372 */     USER_INIT_CLASS = Parameters.getString("UserInitilizeClass");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  410 */     DEFAULT_STRUCTURE = LangConversion.convert("default");
/*      */     
/*      */ 
/*  413 */     STANDARD_CHARS1 = "+-.,/?\\!'\"$%&*@()[]abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".substring("+-.,/?\\!'\"$%&*@()[]abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".indexOf('a'));
/*  414 */     FILE_SEPERATOR = System.getProperty("file.separator");
/*      */     
/*  416 */     FIELD_SEPARATOR_LIST = new String[] { "<Default>", "<Tab>", "<Space>", ",", ";", ":", "|", "/", "\\", "~", "!", "*", "#", "@", "x'00'", "x'01'", "x'02'", "x'FD'", "x'FE'", "x'FF'" };
/*      */     
/*      */ 
/*  419 */     FIELD_SEPARATOR_LIST1 = new String[] { "<Tab>", "<Space>", ",", ";", ":", "|", "/", "\\", "~", "!", "*", "#", "@", "x'00'", "x'01'", "x'02'", "x'FD'", "x'FE'", "x'FF'" };
/*      */     
/*      */ 
/*  422 */     FIELD_SEPARATOR_TEXT_LIST = new String[FIELD_SEPARATOR_LIST1.length - 6];
/*      */     
/*      */ 
/*  425 */     String[] l = (String[])FIELD_SEPARATOR_LIST1.clone();
/*      */     
/*  427 */     l[0] = "\t";
/*  428 */     l[1] = " ";
/*  429 */     FIELD_SEPARATOR_LIST1_VALUES = l;
/*      */     
/*  431 */     System.arraycopy(FIELD_SEPARATOR_LIST1, 0, FIELD_SEPARATOR_TEXT_LIST, 0, FIELD_SEPARATOR_TEXT_LIST.length);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  436 */     QUOTE_LIST = new String[] { "<None>", "<Default>", "\"", "'", "`" };
/*      */     
/*      */ 
/*      */ 
/*  440 */     QUOTE_VALUES = new String[] { "", "\"", "\"", "'", "`" };
/*      */     
/*      */ 
/*      */ 
/*  444 */     TABLE_NAMES = new String[] { "", "FieldType", "RecordType", "System", "FileStructure", "Format" };
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  450 */     connectionIndex = 0;
/*      */     
/*      */ 
/*      */ 
/*  454 */     readOnly = false;
/*      */     
/*  456 */     htmlDir = null;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  463 */     reActionNames = new String[83];
/*  464 */     reActionDesc = new String[83];
/*      */     
/*  466 */     toCheckVelocity = true;
/*      */     
/*  468 */     toWarn = true;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  474 */     String s = Parameters.getString("usePgnIcons");
/*  475 */     USE_PNG = (s == null) || ("Y".equalsIgnoreCase(s));
/*      */     
/*  477 */     s = Parameters.getString("DateFormat");
/*  478 */     if (s != null) {
/*      */       try {
/*  480 */         new SimpleDateFormat(s);
/*      */       } catch (Exception e) {
/*  482 */         System.out.println("Invalid Date Format: " + s + " " + e.getMessage());
/*  483 */         s = null;
/*      */       }
/*      */     }
/*  486 */     DATE_FORMAT_STR = s;
/*      */     
/*      */ 
/*  489 */     spaceAtBottomOfScreen = getIntProperty(spaceAtBottomOfScreen, "spaceAtBottomOfScreen");
/*      */     
/*  491 */     spaceAtTopOfScreen = getIntProperty(spaceAtTopOfScreen, "spaceAtTopOfScreen");
/*      */     
/*  493 */     spaceAtLeftOfScreen = getIntProperty(spaceAtLeftOfScreen, "spaceAtLeftOfScreen");
/*      */     
/*  495 */     spaceAtRightOfScreen = getIntProperty(spaceAtRightOfScreen, "spaceAtRightOfScreen");
/*      */     
/*      */ 
/*  498 */     for (int i = 0; i < 83; i++) {
/*  499 */       reActionNames[i] = "";
/*  500 */       reActionDesc[i] = null;
/*      */     }
/*  502 */     reActionNames[10] = "Close";
/*  503 */     reActionNames[11] = "Close All";
/*  504 */     reActionNames[24] = "Copy Record(s)";
/*  505 */     reActionNames[76] = "Copy Cell(s)";
/*      */     
/*  507 */     reActionNames[25] = "Cut Record(s)";
/*  508 */     reActionNames[81] = "Cut Selected Cells";
/*  509 */     reActionNames[82] = "Clear Selected Cells";
/*  510 */     reActionNames[6] = "Delete";
/*  511 */     reActionNames[29] = "Delete Record(s)";
/*  512 */     reActionNames[78] = "Delete";
/*  513 */     reActionNames[80] = "Delete Selected Cells";
/*  514 */     reActionNames[77] = reActionNames[29];
/*  515 */     reActionNames[8] = "Filter";
/*  516 */     reActionNames[14] = "Table View (Selected Records)";
/*  517 */     reActionNames[15] = "Record View (Selected Records)";
/*  518 */     reActionNames[16] = "Column View (Selected Records)";
/*  519 */     reActionNames[55] = "View Selected Records";
/*  520 */     reActionNames[7] = "Find";
/*  521 */     reActionNames[23] = "Help";
/*  522 */     reActionNames[28] = "Insert Record(s)";
/*  523 */     reActionNames[53] = "Insert Record Prior";
/*  524 */     reActionNames[71] = reActionNames[28];
/*  525 */     reActionNames[72] = reActionNames[53];
/*  526 */     reActionNames[12] = "New";
/*  527 */     reActionNames[9] = "Open";
/*  528 */     reActionNames[36] = "Print";
/*  529 */     reActionNames[54] = "Print Selected";
/*  530 */     reActionNames[26] = "Paste Record(s)";
/*  531 */     reActionNames[27] = "Paste Record(s) Prior";
/*  532 */     reActionNames[73] = reActionNames[26];
/*  533 */     reActionNames[74] = reActionNames[27];
/*  534 */     reActionNames[48] = "Paste Table (Insert)";
/*  535 */     reActionNames[79] = "Paste Cells into the Table";
/*  536 */     reActionNames[47] = "Paste Table Overwrite";
/*  537 */     reActionNames[75] = "Paste Table Over Selected";
/*  538 */     reActionNames[1] = "Save";
/*  539 */     reActionNames[2] = "Save As";
/*  540 */     reActionNames[57] = "Export";
/*  541 */     reActionNames[51] = "Export as CSV file";
/*  542 */     reActionNames[52] = "Export as Fixed Length file";
/*  543 */     reActionNames[3] = "Export as HTML 1 tbl";
/*  544 */     reActionNames[4] = "Export as HTML 1 tbl per Row";
/*  545 */     reActionNames[46] = "Export as HTML (tree)";
/*  546 */     reActionNames[5] = "Export using Velocity";
/*  547 */     reActionNames[56] = "Export using Xslt";
/*  548 */     reActionNames[58] = "Export using a Script";
/*  549 */     reActionNames[59] = "Run a Script";
/*  550 */     reActionNames[44] = "Save Tree as XML";
/*  551 */     reActionNames[45] = "Save Layout as XML";
/*      */     
/*  553 */     reActionNames[30] = "Sort";
/*  554 */     reActionNames[31] = "Repeat Record";
/*  555 */     reActionNames[37] = "Rebuild Tree";
/*      */     
/*  557 */     reActionNames[18] = "Sorted Field Tree";
/*  558 */     reActionNames[17] = "Field Based Tree";
/*  559 */     reActionNames[19] = "Record Based Tree";
/*  560 */     reActionNames[20] = "Record Layout Tree";
/*  561 */     reActionNames[22] = "Record Layout Tree (Selected Records)";
/*  562 */     reActionNames[21] = "XML Tree (Selected Records)";
/*  563 */     reActionNames[39] = "Complete Rebuild of Tree ";
/*      */     
/*  565 */     reActionNames[40] = "Execute Saved Filter";
/*  566 */     reActionNames[41] = "Execute Sort Tree";
/*  567 */     reActionNames[42] = "Execute Record Tree";
/*  568 */     reActionNames[43] = "Compare with Disk";
/*  569 */     reActionNames[49] = "Show invalid Records";
/*  570 */     reActionNames[50] = "Recalculate Column widths";
/*      */     
/*  572 */     reActionNames[61] = "Close Tab";
/*  573 */     reActionNames[62] = "Undock tab";
/*  574 */     reActionNames[63] = "Undock all Tabs";
/*  575 */     reActionNames[64] = "Dock Tab/Screen";
/*  576 */     reActionNames[65] = "Dock related screens";
/*  577 */     reActionNames[67] = "Show Child Record";
/*  578 */     reActionNames[66] = "Remove Child Record";
/*      */     
/*  580 */     reActionNames[68] = "Show Child Record (right)";
/*  581 */     reActionNames[69] = "Show Child Record (bottom)";
/*  582 */     reActionNames[70] = "Swap position of Child Record";
/*      */     
/*      */ 
/*      */ 
/*  586 */     reActionDesc[62] = "Display Tab in seperate screen";
/*  587 */     reActionDesc[63] = "Display all tabs in there own screen";
/*  588 */     reActionDesc[64] = "Dock Tab/Screen with the main screen for this document";
/*  589 */     reActionDesc[65] = "Dock all screens for this document with the main screen";
/*  590 */     reActionDesc[67] = "Add a linked Child Record to the current screen";
/*  591 */     reActionDesc[66] = "Remove the linked Child Record from the current screen";
/*      */     
/*  593 */     reActionNames[68] = "Show Child Record on the Right hand side of the screen";
/*  594 */     reActionNames[69] = "Show Child Record at the bottom of the list";
/*  595 */     reActionNames[70] = "Swap the position of Child Record Screen between the Bottom and right hand side of the screen";
/*      */     
/*  597 */     reActionDesc[57] = "Export in another format";
/*  598 */     reActionDesc[58] = "Export using an external Script (Jython, JRuby, JavaScript etc)";
/*  599 */     reActionDesc[59] = "Run an external Script (Jython, JRuby, JavaScript etc)";
/*  600 */     reActionDesc[44] = "Converts a Tree View to XML";
/*  601 */     reActionDesc[45] = "Save Layout as RecordEditor XML";
/*      */     
/*  603 */     reActionDesc[14] = "Create a new view from the selected records";
/*  604 */     reActionDesc[15] = "Create a new Record view from the selected records";
/*  605 */     reActionDesc[16] = "Create a Column view from the selected records";
/*  606 */     reActionDesc[24] = "Copy selected records to the RecordEditor Clipboard";
/*  607 */     reActionDesc[76] = "Copy selected records to the RecordEditor Clipboard";
/*  608 */     reActionDesc[25] = "Cut selected records to the RecordEditor Clipboard";
/*  609 */     reActionDesc[26] = "Paste records from the RecordEditor Clipboard after the current record";
/*  610 */     reActionDesc[27] = "Paste records from the RecordEditor Clipboard before the current record";
/*  611 */     reActionDesc[73] = "Paste records from the RecordEditor Clipboard after the current record";
/*  612 */     reActionDesc[74] = "Paste records from the RecordEditor Clipboard before the current record";
/*  613 */     reActionDesc[48] = "Paste Table after the current line/row";
/*  614 */     reActionDesc[47] = "Paste Table over current data (from current position)";
/*  615 */     reActionDesc[75] = "Paste Table over selected cells";
/*  616 */     reActionDesc[82] = "Clear (set to \"\"/\"0\") Selected Cells";
/*  617 */     reActionDesc[29] = "Delete Selected records";
/*  618 */     reActionDesc[31] = "Repeat the record under the cursor";
/*  619 */     reActionDesc[37] = "Rebuild the Tree Display";
/*      */     
/*  621 */     reActionNames[38] = "Add Attributes";
/*      */     
/*  623 */     reActionDesc[18] = "Create Tree View by sorting on selected fields";
/*  624 */     reActionDesc[17] = "Create Tree View based on changes in selected fields";
/*  625 */     reActionDesc[19] = "Create Tree View based on Record Hierarchy";
/*  626 */     reActionDesc[22] = "Create XML Tree View using the definition in Record Layout Definition from the currently selected records";
/*      */     
/*  628 */     reActionDesc[21] = "Create XML Tree View from the currently selected records";
/*  629 */     reActionDesc[39] = "Completely rebuild the Tree from scratch";
/*      */     
/*  631 */     reActionDesc[38] = "Add Attributes to the layout Definition";
/*      */     
/*  633 */     reActionDesc[40] = "Load and Execute a saved filter";
/*  634 */     reActionDesc[41] = "Load and Execute a saved Sort Tree";
/*  635 */     reActionDesc[42] = "Load and Execute a saved Record Tree";
/*  636 */     reActionDesc[43] = "Compare what is being edited with what is stored on disk";
/*  637 */     reActionDesc[49] = "Show Invalid (incomplete) Records (Messages)";
/*  638 */     reActionDesc[50] = "Calculate the column widths based on data in the columns";
/*      */     
/*      */ 
/*  641 */     for (int i = 0; i < reActionNames.length; i++) {
/*  642 */       String desc = "Description_for_" + reActionNames[i];
/*  643 */       reActionNames[i] = getName(reActionNames[i], "");
/*  644 */       reActionDesc[i] = getName(reActionDesc[i], desc);
/*      */     }
/*      */   }
/*      */   
/*      */   private static String getName(String s, String desc) {
/*  649 */     if ((s != null) && (!"".equals(s))) {
/*  650 */       s = LangConversion.convertDesc(3, s, desc);
/*      */     }
/*  652 */     return s;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void stopCellEditing(JTable tbl)
/*      */   {
/*  672 */     if (tbl != null) {
/*      */       try {
/*  674 */         TableCellEditor cellEdit = tbl.getCellEditor();
/*  675 */         if (cellEdit != null) {
/*  676 */           cellEdit.stopCellEditing();
/*      */         }
/*      */       }
/*      */       catch (Exception e) {}
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final void initVars()
/*      */   {
/*  690 */     if (yet2Assign)
/*      */     {
/*  692 */       int j = 0;
/*      */       
/*      */ 
/*  695 */       yet2Assign = false;
/*      */       
/*  697 */       for (int i = 0; i < 16; i++) {
/*  698 */         String s = Integer.toString(i);
/*      */         
/*  700 */         dataSource[j] = Parameters.getString("Source." + s);
/*      */         
/*  702 */         if ((dataSource[j] != null) && (!"".equals(dataSource[j].trim()))) {
/*  703 */           String dropSemiStr = Parameters.getString("DBDropSemi." + s);
/*  704 */           readOnlySource[j] = Parameters.getString("ReadOnly." + s);
/*  705 */           sourceId[j] = Parameters.getString("SourceName." + s);
/*  706 */           if (DATABASE_NAME.equalsIgnoreCase(sourceId[j])) {
/*  707 */             System.out.println("Setting DB index : " + DATABASE_NAME + " " + j);
/*  708 */             connectionIndex = j;
/*      */           }
/*  710 */           driver[j] = Parameters.getString("Driver." + s);
/*  711 */           userId[j] = Parameters.getString("User." + s);
/*  712 */           password[j] = Parameters.getString("Password." + s);
/*  713 */           commitFlag[j] = Parameters.getString("Commit." + s);
/*  714 */           checkpointFlag[j] = Parameters.getString("Checkpoint." + s);
/*  715 */           autoClose[j] = "Y".equalsIgnoreCase(Parameters.getString("AutoClose." + s));
/*  716 */           dropSemi[j] = (("Y".equalsIgnoreCase(dropSemiStr)) || (((dropSemiStr == null) || ("".equals(dropSemiStr))) && (driver[j] != null) && (driver[j].toLowerCase().contains("derby"))) ? 1 : false);
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*  721 */           boolean expandVars = "y".equalsIgnoreCase(Parameters.getString("ExpandVars." + s));
/*      */           
/*      */ 
/*  724 */           if (expandVars) {
/*  725 */             dataSource[j] = fixVars(dataSource[j]);
/*  726 */             readOnlySource[j] = fixVars(readOnlySource[j]);
/*  727 */             System.out.println(" ---> " + j + " : " + dataSource[j] + " " + readOnlySource[j]);
/*      */           }
/*      */           
/*      */ 
/*  731 */           j++;
/*      */         }
/*  733 */         dbConnection[i] = null;
/*      */       }
/*      */       
/*  736 */       dbDefined = j > 0;
/*  737 */       for (i = j; i < 16; i++) {
/*  738 */         userId[i] = null;
/*  739 */         sourceId[i] = "";
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public static String fixVars(String var) {
/*  745 */     if (var != null) {
/*  746 */       var = var.replace("<install>", Parameters.getBaseDirectory());
/*  747 */       var = var.replace("<home>", Parameters.getUserhome());
/*  748 */       if (var.indexOf("<hsqlDB>") >= 0) {
/*  749 */         String hsqlDir = Parameters.getBaseDirectory() + FILE_SEPERATOR + "Database";
/*  750 */         if ((IS_WINDOWS) || (!exists(hsqlDir + FILE_SEPERATOR + "recordedit.script")) || (!exists(hsqlDir + FILE_SEPERATOR + "recordedit.properties")))
/*      */         {
/*      */ 
/*      */ 
/*  754 */           hsqlDir = Parameters.getPropertiesDirectory() + FILE_SEPERATOR + "Database";
/*      */         }
/*  756 */         System.out.println();
/*  757 */         System.out.println("HSQL DB  >>" + hsqlDir + "<<");
/*  758 */         System.out.println();
/*  759 */         var = var.replace("<hsqlDB>", hsqlDir);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  769 */     return var;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static int getIntProperty(int defaultValue, String resource)
/*      */   {
/*  783 */     String s = Parameters.getString(resource);
/*      */     
/*  785 */     if ((s != null) && (!s.equals(""))) {
/*      */       try {
/*  787 */         defaultValue = Integer.parseInt(s);
/*      */       }
/*      */       catch (Exception e) {}
/*      */     }
/*      */     
/*  792 */     return defaultValue;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int makeConnection(int connectionIdx)
/*      */     throws SQLException, ClassNotFoundException, MalformedURLException, InstantiationException, IllegalAccessException
/*      */   {
/*      */     int ret;
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  811 */     if ((readOnlySource[connectionIdx] == null) || ("".equals(readOnlySource[connectionIdx]))) {
/*  812 */       int ret = makeConnection(dbConnection, connectionIdx, dataSource, 1, readOnly);
/*  813 */       dbUpdate[connectionIdx] = dbConnection[connectionIdx];
/*      */     } else {
/*  815 */       ret = makeConnection(dbConnection, connectionIdx, readOnlySource, 6, true);
/*      */     }
/*      */     
/*  818 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final int makeConnection(Connection[] connectionArray, int connectionIdx, String[] source, int trys, boolean readOnlyOpt)
/*      */     throws SQLException, ClassNotFoundException, MalformedURLException, InstantiationException, IllegalAccessException
/*      */   {
/*  838 */     if ((connectionArray[connectionIdx] != null) && (!connectionArray[connectionIdx].isClosed())) {
/*  839 */       return connectionIdx;
/*      */     }
/*      */     
/*  842 */     int ret = connectionIdx;
/*      */     
/*  844 */     for (int j = 0; j <= trys; j++) {
/*      */       try {
/*  846 */         if (jdbcJarNames == null) {
/*  847 */           Class.forName(driver[connectionIdx]);
/*      */           
/*  849 */           if ((userId[connectionIdx] == null) || ("".equals(userId[connectionIdx]))) {
/*  850 */             connectionArray[connectionIdx] = DriverManager.getConnection(source[connectionIdx]);
/*      */           }
/*      */           else {
/*  853 */             connectionArray[connectionIdx] = DriverManager.getConnection(source[connectionIdx], userId[connectionIdx], password[connectionIdx]);
/*      */           }
/*      */           
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/*  861 */           URL[] urls = new URL[jdbcJarNames.length];
/*  862 */           String pass = password[connectionIdx];
/*  863 */           if (password[connectionIdx] == null) {
/*  864 */             pass = "";
/*      */           }
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*  874 */           for (int i = 0; i < jdbcJarNames.length; i++) {
/*  875 */             if ((jdbcJarNames[i] != null) && (!"".equals(jdbcJarNames[i]))) {
/*  876 */               System.out.println("  ### Jdbc Jars: " + jdbcJarNames[i] + " -> " + Parameters.expandVars(jdbcJarNames[i]));
/*  877 */               urls[i] = new URL("file:" + Parameters.expandVars(jdbcJarNames[i]));
/*      */             }
/*      */           }
/*      */           
/*      */ 
/*  882 */           URLClassLoader urlLoader = new URLClassLoader(urls);
/*  883 */           Driver d = (Driver)Class.forName(driver[connectionIdx], true, urlLoader).newInstance();
/*      */           
/*  885 */           Properties p = new Properties();
/*      */           
/*  887 */           p.setProperty("user", userId[connectionIdx]);
/*      */           
/*  889 */           p.setProperty("password", pass);
/*      */           
/*  891 */           connectionArray[connectionIdx] = d.connect(source[connectionIdx], p);
/*      */           
/*  893 */           System.out.println("  ~~~ Connection ok : " + connectionIdx + " " + source[connectionIdx] + " " + (dbConnection[connectionIdx] != null));
/*      */         }
/*      */         
/*      */ 
/*      */       }
/*      */       catch (SQLException e)
/*      */       {
/*  900 */         if (j >= trys) {
/*  901 */           System.out.println(" ~~~ SQLException > " + connectionIdx + " " + source[connectionIdx] + "< " + e.getMessage());
/*  902 */           e.printStackTrace();
/*  903 */           throw e;
/*      */         }
/*  905 */         sleep();
/*      */       } catch (InstantiationException e) {
/*  907 */         if (j >= trys) {
/*  908 */           System.out.println(" ~~~ InstantiationException");
/*  909 */           throw e;
/*      */         }
/*  911 */         sleep();
/*      */       } catch (IllegalAccessException e) {
/*  913 */         if (j >= trys) {
/*  914 */           System.out.println(" ~~~ IllegalAccessException");
/*  915 */           throw e;
/*      */         }
/*  917 */         sleep();
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*  922 */     System.out.print("==> " + connectionIdx + " " + driver[connectionIdx] + " " + source[connectionIdx] + " " + userId[connectionIdx] + " " + password[connectionIdx] + " ");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*  927 */     System.out.println(connectionArray[connectionIdx].getClass().getName() + " : " + connectionArray[connectionIdx].isReadOnly());
/*      */     
/*      */ 
/*  930 */     connectionArray[connectionIdx].setReadOnly(readOnlyOpt);
/*      */     
/*  932 */     yet2Init = false;
/*  933 */     jdbcMsg[connectionIdx] = "";
/*      */     
/*  935 */     return ret;
/*      */   }
/*      */   
/*      */   private static void sleep() {
/*      */     try {
/*  940 */       Thread.sleep(75L);
/*      */     }
/*      */     catch (Exception e) {}
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isDbConnectionDefined()
/*      */   {
/*  952 */     initVars();
/*  953 */     return dbDefined;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final void closeConnection()
/*      */   {
/*  960 */     System.out.println("Close Connection; init=" + yet2Init);
/*  961 */     if (!yet2Init) {
/*  962 */       boolean hsql = false;
/*      */       
/*      */ 
/*  965 */       for (int i = 0; i < 16; i++) {
/*  966 */         if (dbConnection[i] != null) {
/*  967 */           hsql = (hsql) || ("org.hsqldb.jdbcDriver".equals(driver[i]));
/*  968 */           System.out.println(" >>> " + i + " ~ " + hsql + " " + driver[i]);
/*  969 */           closeAConnection(i);
/*      */         }
/*      */       }
/*      */       
/*  973 */       if (hsql) {
/*  974 */         closeHSQL();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void closeAConnection(int id)
/*      */   {
/*  987 */     if (dbConnection[id] != null) {
/*      */       try {
/*  989 */         checkpoint(id);
/*  990 */         dbConnection[id].close();
/*  991 */         dbConnection[id] = null;
/*  992 */         dbUpdate[id] = null;
/*      */       } catch (Exception ex1) {
/*  994 */         logMsg("Close DB - " + ex1.getMessage(), null);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final Connection getDBConnection(int dbIdx)
/*      */     throws SQLException
/*      */   {
/*      */     
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1014 */     if (dbConnection[dbIdx] == null) {
/*      */       try {
/* 1016 */         makeConnection(dbIdx);
/*      */       } catch (Exception ex) {
/* 1018 */         dbConnection[dbIdx] = null;
/* 1019 */         String msg = ex.getMessage();
/* 1020 */         jdbcMsg[dbIdx] = (LangConversion.convert("DataBase Connection error:") + " " + msg);
/*      */         
/* 1022 */         logMsgRaw(jdbcMsg[dbIdx] + "\n" + LangConversion.convert("Connection Index") + dbIdx + "\n" + LangConversion.convert("Connection ID") + dataSource[dbIdx], ex);
/*      */         
/* 1024 */         throw new SQLException(jdbcMsg[dbIdx]);
/*      */       }
/*      */     }
/* 1027 */     return dbConnection[dbIdx];
/*      */   }
/*      */   
/*      */   public static final boolean useCopySql(int dbIdx) {
/* 1031 */     return getDbType(dbIdx) == 3;
/*      */   }
/*      */   
/*      */   public static final boolean alterVarChar(int dbIdx) {
/* 1035 */     return getDbType(dbIdx) != 2;
/*      */   }
/*      */   
/*      */   public static final int getDbType(int dbIdx)
/*      */   {
/* 1040 */     int ret = 1;
/*      */     
/* 1042 */     if (driver[dbIdx].contains(".hsqldb.")) {
/* 1043 */       ret = 2;
/* 1044 */     } else if ("JDBC:ODBC:RecordLayout".equals(dataSource[dbIdx])) {
/* 1045 */       ret = 3;
/*      */     }
/* 1047 */     return ret;
/*      */   }
/*      */   
/*      */   public static final Connection getUpdateConnection(int dbIdx)
/*      */   {
/*      */     
/* 1053 */     if (dbUpdate[dbIdx] == null) {
/*      */       try {
/* 1055 */         if ((readOnlySource[dbIdx] == null) || ("".equals(readOnlySource[dbIdx]))) {
/* 1056 */           makeConnection(dbIdx);
/*      */         } else {
/* 1058 */           if (dbConnection[dbIdx] != null)
/*      */           {
/* 1060 */             dbConnection[dbIdx].close();
/* 1061 */             dbConnection[dbIdx] = null;
/* 1062 */             dbUpdate[dbIdx] = null;
/* 1063 */             closeHSQL();
/*      */           }
/* 1065 */           makeConnection(dbUpdate, dbIdx, dataSource, 7, false);
/*      */           
/* 1067 */           dbConnection[dbIdx] = dbUpdate[dbIdx];
/*      */         }
/*      */       } catch (Exception ex) {
/* 1070 */         dbConnection[dbIdx] = null;
/* 1071 */         String msg = ex.getMessage();
/* 1072 */         jdbcMsg[dbIdx] = ("DataBase Connection error: " + msg);
/*      */         
/* 1074 */         logMsgRaw(jdbcMsg[dbIdx] + "\n" + LangConversion.convert("Connection Index") + " " + dbIdx + "\n" + LangConversion.convert("Connection ID ") + " " + dataSource[dbIdx], ex);
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/* 1080 */     return dbUpdate[dbIdx];
/*      */   }
/*      */   
/*      */ 
/*      */   public static void closeHSQL()
/*      */   {
/* 1086 */     System.out.println("Closing HSQL");
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     try
/*      */     {
/* 1094 */       Class runClass = Class.forName("org.hsqldb.DatabaseManager");
/* 1095 */       Method closeDB = runClass.getMethod("closeDatabases", new Class[] { Integer.TYPE });
/* 1096 */       Object[] arguments = { Integer.valueOf(0) };
/*      */       
/* 1098 */       closeDB.invoke(null, arguments);
/*      */     }
/*      */     catch (NoClassDefFoundError e) {
/* 1101 */       e.printStackTrace();
/*      */     } catch (Exception e) {
/* 1103 */       e.printStackTrace();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final Connection getDBConnectionLogErrors(int dbIndex)
/*      */   {
/*      */     try
/*      */     {
/* 1117 */       return getDBConnection(dbIndex);
/*      */     } catch (Exception ex) {
/* 1119 */       logMsgRaw(ex.getMessage(), null); }
/* 1120 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final String[] getSourceId()
/*      */   {
/* 1131 */     initVars();
/* 1132 */     return sourceId;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void setConnectionId(int dbIdx)
/*      */   {
/* 1143 */     if (connectionIndex != dbIdx) {
/* 1144 */       closeAConnection(connectionIndex);
/*      */     }
/* 1146 */     connectionIndex = dbIdx;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final ResultSet getResultSet(String pSQL)
/*      */     throws SQLException
/*      */   {
/* 1159 */     return getDBConnection(connectionIndex).createStatement().executeQuery(pSQL);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void commit(int id)
/*      */   {
/* 1170 */     if ("Y".equalsIgnoreCase(commitFlag[id])) {
/*      */       try {
/* 1172 */         getDBConnection(id).commit();
/*      */       }
/*      */       catch (Exception ex) {
/* 1175 */         logMsg("Commit - " + ex.getMessage(), null);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void checkpoint(int id)
/*      */   {
/* 1187 */     commit(id);
/*      */     
/* 1189 */     if ("Y".equalsIgnoreCase(checkpointFlag[id])) {
/*      */       try
/*      */       {
/* 1192 */         getDBConnection(id).createStatement().execute("checkpoint");
/*      */       }
/*      */       catch (Exception ex) {
/* 1195 */         logMsg("checkpoint - " + ex.getMessage(), null);
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public static final void freeConnection(int idx)
/*      */   {
/* 1202 */     if ((autoClose[idx] != 0) && (doFree)) {
/* 1203 */       closeAConnection(idx);
/* 1204 */       System.out.println("Free Connection: " + idx);
/* 1205 */       if ("org.hsqldb.jdbcDriver".equals(driver[idx])) {
/* 1206 */         closeHSQL();
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */   public static boolean isDropSemi(int idx) {
/* 1212 */     return dropSemi[idx];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final void shutdownHSQLdb()
/*      */   {
/*      */     
/*      */     
/*      */ 
/* 1222 */     for (int i = 0; i < 16; i++) {
/* 1223 */       if ((dataSource[i] != null) && (dataSource[i].startsWith("jdbc:hsqldb:hsql:"))) {
/*      */         try {
/* 1225 */           checkpoint(i);
/*      */           
/* 1227 */           getDBConnection(i).createStatement().execute("shutdown");
/*      */         }
/*      */         catch (Exception e) {
/* 1230 */           System.out.println("Shutdown error " + e.getMessage());
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static final void readIcons()
/*      */   {
/* 1246 */     if (recIcon[0] == null)
/*      */     {
/* 1248 */       recIcon[0] = getIcon("Find");
/* 1249 */       recIcon[1] = getIcon("Filter");
/* 1250 */       recIcon[2] = getIcon("Save");
/* 1251 */       recIcon[3] = getIcon("SaveAs");
/*      */       
/* 1253 */       recIcon[4] = getIcon("Copy");
/* 1254 */       recIcon[5] = getIcon("Cut");
/*      */       
/* 1256 */       recIcon[6] = getIcon("Paste");
/* 1257 */       recIcon[7] = getIcon("PasteUp");
/*      */       
/* 1259 */       recIcon[8] = getIcon("New");
/* 1260 */       recIcon[9] = getIcon("SetLength");
/*      */       
/* 1262 */       recIcon[10] = getIcon("Delete");
/* 1263 */       recIcon[12] = getIcon("Open");
/* 1264 */       recIcon[13] = getIcon("Sort");
/* 1265 */       recIcon[11] = getIcon("Help");
/* 1266 */       recIcon[16] = getIcon("Print");
/* 1267 */       recIcon[17] = getIcon("Preferences");
/* 1268 */       recIcon[18] = getIcon("Tree");
/* 1269 */       recIcon[19] = getIcon("AutofitColumns");
/* 1270 */       recIcon[20] = getIcon("ColumnDetails");
/* 1271 */       recIcon[21] = getIcon("ColumnView");
/* 1272 */       recIcon[22] = getIcon("CopyColumn");
/* 1273 */       recIcon[23] = getIcon("DeleteColumn");
/* 1274 */       recIcon[24] = getIcon("MoveColumn");
/* 1275 */       recIcon[25] = getIcon("InsertColumn");
/* 1276 */       recIcon[26] = getIcon("EditRecord");
/* 1277 */       recIcon[27] = getIcon("NewUp");
/* 1278 */       recIcon[28] = getIcon("PasteUp");
/* 1279 */       recIcon[29] = getIcon("Export");
/* 1280 */       recIcon[30] = getIcon("SaveAs_Csv");
/* 1281 */       recIcon[31] = getIcon("SaveAs_Fixed");
/* 1282 */       recIcon[32] = getIcon("SaveAs_Html");
/* 1283 */       recIcon[33] = getIcon("SaveAs_xml");
/* 1284 */       recIcon[34] = getIcon("SaveAs_Velocity");
/* 1285 */       recIcon[49] = getIcon("ScriptExport");
/* 1286 */       recIcon[50] = getIcon("Script");
/* 1287 */       recIcon[51] = getIcon("BlueFolder");
/* 1288 */       recIcon[35] = getIcon("Summary");
/* 1289 */       recIcon[36] = getIcon("SortSum");
/*      */       
/* 1291 */       recIcon[37] = getIcon("RecordView");
/* 1292 */       recIcon[38] = getIcon("TableView");
/* 1293 */       recIcon[39] = getIcon("ColumnView");
/* 1294 */       recIcon[40] = getIcon("Exit");
/* 1295 */       recIcon[41] = getIcon("Goto");
/* 1296 */       recIcon[42] = getIcon("Reload");
/* 1297 */       recIcon[43] = getIcon("Wizard");
/* 1298 */       recIcon[44] = getIcon("LayoutCreate");
/* 1299 */       recIcon[45] = getIcon("LayoutEdit");
/* 1300 */       recIcon[46] = recIcon[41];
/* 1301 */       recIcon[47] = getIcon("FileSearch");
/* 1302 */       recIcon[48] = getIcon("FolderSearch");
/*      */       
/* 1304 */       for (int i = 0; i < ICON_NAMES.length; i++) {
/* 1305 */         treeIcons[i] = getIcon(ICON_NAMES[i]);
/*      */       }
/* 1307 */       icon[0] = treeIcons[0];
/* 1308 */       icon[1] = treeIcons[1];
/* 1309 */       icon[2] = treeIcons[4];
/* 1310 */       icon[3] = treeIcons[5];
/*      */       
/* 1312 */       recIcon[15] = icon[1];
/* 1313 */       recIcon[14] = icon[2];
/*      */       
/* 1315 */       for (i = 0; i < reActionRef.length; i++) {
/* 1316 */         reActionRef[i] = -1;
/*      */       }
/* 1318 */       reActionRef[7] = 0;
/* 1319 */       reActionRef[8] = 1;
/* 1320 */       reActionRef[40] = 1;
/* 1321 */       reActionRef[14] = 38;
/* 1322 */       reActionRef[15] = 37;
/* 1323 */       reActionRef[16] = 39;
/* 1324 */       reActionRef[17] = 35;
/* 1325 */       reActionRef[20] = 18;
/* 1326 */       reActionRef[19] = 18;
/* 1327 */       reActionRef[18] = 36;
/* 1328 */       reActionRef[42] = 18;
/* 1329 */       reActionRef[41] = 36;
/* 1330 */       reActionRef[21] = 18;
/* 1331 */       reActionRef[22] = 18;
/* 1332 */       reActionRef[39] = 18;
/*      */       
/* 1334 */       reActionRef[1] = 2;
/* 1335 */       reActionRef[2] = 3;
/* 1336 */       reActionRef[57] = 29;
/* 1337 */       reActionRef[3] = 32;
/* 1338 */       reActionRef[51] = 30;
/* 1339 */       reActionRef[52] = 31;
/* 1340 */       reActionRef[4] = 32;
/* 1341 */       reActionRef[46] = 32;
/* 1342 */       reActionRef[5] = 34;
/* 1343 */       reActionRef[56] = 33;
/* 1344 */       reActionRef[58] = 49;
/* 1345 */       reActionRef[59] = 50;
/* 1346 */       reActionRef[44] = 33;
/* 1347 */       reActionRef[45] = 33;
/*      */       
/* 1349 */       reActionRef[31] = 4;
/* 1350 */       reActionRef[24] = 4;
/* 1351 */       reActionRef[76] = 4;
/* 1352 */       reActionRef[25] = 5;
/* 1353 */       reActionRef[81] = 5;
/*      */       
/* 1355 */       reActionRef[26] = 6;
/* 1356 */       reActionRef[27] = 7;
/*      */       
/* 1358 */       reActionRef[73] = 6;
/* 1359 */       reActionRef[74] = 7;
/*      */       
/* 1361 */       reActionRef[48] = 6;
/* 1362 */       reActionRef[75] = 6;
/* 1363 */       reActionRef[79] = 6;
/* 1364 */       reActionRef[28] = 8;
/* 1365 */       reActionRef[53] = 27;
/* 1366 */       reActionRef[71] = 8;
/* 1367 */       reActionRef[72] = 27;
/*      */       
/* 1369 */       reActionRef[12] = 8;
/*      */       
/*      */ 
/* 1372 */       reActionRef[6] = 10;
/* 1373 */       reActionRef[29] = 10;
/*      */       
/* 1375 */       reActionRef[78] = 10;
/*      */       
/* 1377 */       reActionRef[77] = 10;
/*      */       
/* 1379 */       reActionRef[80] = 10;
/*      */       
/* 1381 */       reActionRef[9] = 12;
/* 1382 */       reActionRef[23] = 11;
/* 1383 */       reActionRef[30] = 13;
/*      */       
/* 1385 */       reActionRef[33] = 15;
/* 1386 */       reActionRef[32] = 14;
/*      */       
/* 1388 */       reActionRef[34] = 8;
/* 1389 */       reActionRef[35] = 12;
/* 1390 */       reActionRef[36] = 16;
/* 1391 */       reActionRef[54] = 16;
/* 1392 */       reActionRef[50] = 19;
/* 1393 */       reActionRef[10] = 40;
/* 1394 */       reActionRef[11] = 40;
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static ImageIcon getIcon(String name)
/*      */   {
/* 1410 */     String fullName = "/net/sf/RecordEditor/utils/" + name;
/* 1411 */     URL url = null;
/*      */     
/* 1413 */     if (USE_PNG) {
/* 1414 */       url = currClass.getResource(fullName + ".png");
/*      */     }
/* 1416 */     if (url == null) {
/* 1417 */       url = currClass.getResource(fullName + ".gif");
/*      */       
/* 1419 */       if ((url == null) && (!USE_PNG)) {
/* 1420 */         url = currClass.getResource(fullName + ".png");
/*      */       }
/*      */     }
/*      */     
/*      */ 
/* 1425 */     if (url == null) {
/* 1426 */       logMsgRaw("Can not find icon:" + name, null);
/* 1427 */       return null;
/*      */     }
/* 1429 */     return new ImageIcon(url);
/*      */   }
/*      */   
/*      */   public static ImageIcon readIcon(String name)
/*      */   {
/*      */     try
/*      */     {
/* 1436 */       URL url = currClass.getResource(name);
/*      */       
/* 1438 */       if (url == null) {
/* 1439 */         logMsgRaw(LangConversion.convert(2, "Can not find icon:") + " " + name, null);
/* 1440 */         return null;
/*      */       }
/* 1442 */       return new ImageIcon(url);
/*      */     } catch (Exception e) {
/* 1444 */       logMsgRaw(LangConversion.convert(2, "Can not find icon:") + " " + name, e);
/*      */     }
/* 1446 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final ImageIcon getRecordIcon(int iconNum)
/*      */   {
/*      */     
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1475 */     if ((iconNum < 0) || (iconNum > recIcon.length)) {
/* 1476 */       return null;
/*      */     }
/*      */     
/* 1479 */     return recIcon[iconNum];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final ImageIcon[] getArrowIcons()
/*      */   {
/* 1490 */     readIcons();
/*      */     
/* 1492 */     return icon;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final ImageIcon[] getArrowTreeIcons()
/*      */   {
/* 1504 */     readIcons();
/*      */     
/* 1506 */     return treeIcons;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void logMsg(String message, Exception ex)
/*      */   {
/* 1516 */     logMsgRaw(30, LangConversion.convert(2, message), ex);
/*      */   }
/*      */   
/*      */   public static final void logMsgRaw(String message, Exception ex) {
/* 1520 */     logMsgRaw(30, message, ex);
/*      */   }
/*      */   
/*      */   public static final void logMsg(int level, String message, Exception ex) {
/* 1524 */     logMsgRaw(level, LangConversion.convert(2, message), ex);
/*      */   }
/*      */   
/* 1527 */   public static final void logMsg(int level, String message, String message2, Exception ex) { logMsgRaw(level, LangConversion.convert(2, message) + " " + message2, ex); }
/*      */   
/*      */   public static final void logMsgId(String id, int level, String message, Exception ex)
/*      */   {
/* 1531 */     logMsgRaw(level, LangConversion.convertId(2, id, message), ex);
/*      */   }
/*      */   
/*      */   public static final void logMsgRaw(int level, String message, Exception ex) {
/* 1535 */     if (logger == null) {
/* 1536 */       System.out.println(message);
/* 1537 */       if (ex != null) {
/* 1538 */         ex.printStackTrace();
/*      */       }
/*      */     } else {
/* 1541 */       if (ex != null) {
/* 1542 */         logger.logMsg(level, "Java Version: " + Parameters.JAVA_VERSION_STRING);
/*      */       }
/* 1544 */       logger.logMsg(level, message);
/* 1545 */       logger.logException(level, ex);
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void setCurrClass(Object obj)
/*      */   {
/* 1555 */     currClass = obj.getClass();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final boolean isVelocityAvailable()
/*      */   {
/* 1565 */     if (toCheckVelocity)
/*      */     {
/*      */ 
/*      */ 
/*      */       try
/*      */       {
/*      */ 
/* 1572 */         velocityAvailable = currClass.getClassLoader().getResource("org/apache/velocity/Template.class") != null;
/*      */       } catch (Exception e) {
/* 1574 */         velocityAvailable = false;
/*      */       }
/* 1576 */       toCheckVelocity = false;
/*      */     }
/* 1578 */     return velocityAvailable;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final AbsSSLogger getLogger()
/*      */   {
/* 1586 */     if (logger == null) {
/* 1587 */       logger = new TextLog();
/*      */     }
/* 1589 */     return logger;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void setLogger(AbsSSLogger pLogger)
/*      */   {
/* 1597 */     logger = pLogger;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void setConnection(int idx, Connection con, String name)
/*      */   {
/* 1608 */     dbConnection[idx] = con;
/* 1609 */     sourceId[idx] = name;
/* 1610 */     yet2Assign = false;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void setReadOnly(boolean dbIsReadOnly)
/*      */   {
/* 1620 */     readOnly = dbIsReadOnly;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final String getJdbcMsg(int idx)
/*      */   {
/* 1630 */     return jdbcMsg[idx];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final URL formatHelpURL(String helpId)
/*      */   {
/* 1643 */     String lang = Parameters.getString("Language");
/*      */     
/* 1645 */     if (htmlDir == null) {
/* 1646 */       htmlDir = Parameters.getFileName("HelpDir");
/*      */     }
/*      */     
/*      */ 
/* 1650 */     if ((htmlDir == null) || ("".equals(htmlDir))) {
/*      */       try {
/* 1652 */         htmlDir = Parameters.getBaseDirectory() + "/Docs/";
/*      */       } catch (Exception e) {
/* 1654 */         e.printStackTrace();
/* 1655 */         htmlDir = "";
/*      */       }
/*      */     }
/*      */     
/* 1659 */     if (htmlDir.toUpperCase().startsWith("FILE:")) {
/* 1660 */       htmlDir = htmlDir.substring(5);
/*      */     }
/* 1662 */     if ((!htmlDir.endsWith("/")) && (!htmlDir.endsWith("\""))) {
/* 1663 */       htmlDir += "/";
/*      */     }
/*      */     
/* 1666 */     File f = new File(htmlDir + lang + "/" + helpId);
/*      */     
/*      */ 
/* 1669 */     if (f.isFile()) {
/*      */       try {
/* 1671 */         return f.toURI().toURL();
/*      */       }
/*      */       catch (Exception e) {}
/*      */     }
/*      */     try
/*      */     {
/* 1677 */       return new File(htmlDir + helpId).toURI().toURL();
/*      */     } catch (Exception e) {
/* 1679 */       e.printStackTrace();
/*      */     }
/* 1681 */     return null;
/*      */   }
/*      */   
/*      */ 
/*      */   public static void setBounds1(JFrame frame, String id)
/*      */   {
/* 1687 */     Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
/*      */     
/* 1689 */     switch (OPTIONS.screenStartSizeOpt.get()) {
/*      */     case 'L': 
/* 1691 */       setSizeFromVars(frame, screenSize, id + "lastScreenWidth", id + "lastScreenHeight");
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1696 */       break;
/*      */     case 'S': 
/* 1698 */       setStandardHeight(frame, screenSize);
/* 1699 */       break;
/*      */     
/*      */     case 'D': 
/* 1702 */       setSizeFromVars(frame, getUsableScreenArea(frame), id + "ScreenStartWidth", id + "ScreenStartHeight");
/*      */       
/*      */ 
/*      */ 
/*      */ 
/* 1707 */       break;
/*      */     default: 
/* 1709 */       setMaximised(frame, getUsableScreenArea(frame));
/*      */     }
/*      */   }
/*      */   
/*      */   private static void setSizeFromVars(JFrame frame, Dimension screenSize, String widthPrm, String heightPrm)
/*      */   {
/*      */     try {
/* 1716 */       int width = screenSize.width;
/* 1717 */       int height = screenSize.height;
/*      */       
/* 1719 */       width = setVal(width, Parameters.getString(widthPrm));
/* 1720 */       height = setVal(height, Parameters.getString(heightPrm));
/*      */       
/* 1722 */       if ((width > 0) && (height > 0)) {
/* 1723 */         frame.setSize(width, height);
/*      */       } else {
/* 1725 */         setMaximised(frame, screenSize);
/*      */       }
/*      */     } catch (Exception e2) {
/* 1728 */       setMaximised(frame, screenSize);
/*      */     }
/*      */   }
/*      */   
/*      */   private static int setVal(int defaultValue, String val) {
/* 1733 */     if ((val != null) && (!"".equals(val))) {
/* 1734 */       defaultValue = Math.min(defaultValue, Integer.parseInt(val));
/*      */     }
/* 1736 */     return defaultValue;
/*      */   }
/*      */   
/*      */   public static void setMaximised(JFrame frame, Dimension screenSize)
/*      */   {
/* 1741 */     frame.setSize(screenSize);
/* 1742 */     GraphicsEnvironment e = GraphicsEnvironment.getLocalGraphicsEnvironment();
/*      */     
/* 1744 */     frame.setMaximizedBounds(e.getMaximumWindowBounds());
/*      */     
/* 1746 */     frame.setExtendedState(frame.getExtendedState() | 0x6);
/*      */   }
/*      */   
/*      */   public static Dimension getUsableScreenArea(Component c) {
/* 1750 */     Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
/*      */     
/*      */ 
/* 1753 */     Insets scnMax = Toolkit.getDefaultToolkit().getScreenInsets(c.getGraphicsConfiguration());
/*      */     
/* 1755 */     return new Dimension(screenSize.width - scnMax.left - scnMax.right, screenSize.height - scnMax.top - scnMax.bottom);
/*      */   }
/*      */   
/*      */ 
/*      */   private static void setStandardHeight(JFrame frame, Dimension screenSize)
/*      */   {
/* 1761 */     frame.setBounds(spaceAtLeftOfScreen, spaceAtTopOfScreen, screenSize.width - spaceAtRightOfScreen - spaceAtLeftOfScreen, screenSize.height - spaceAtBottomOfScreen - spaceAtTopOfScreen);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int getSpaceAtBottomOfScreen()
/*      */   {
/* 1798 */     return spaceAtBottomOfScreen;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int getSpaceAtRightOfScreen()
/*      */   {
/* 1814 */     return spaceAtRightOfScreen;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static ImageIcon getReActionIcon(int action)
/*      */   {
/* 1833 */     return getRecordIcon(reActionRef[action]);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getReActionNames(int action)
/*      */   {
/* 1843 */     return reActionNames[action];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String getReActionDescription(int action)
/*      */   {
/* 1853 */     if (reActionDesc[action] != null) {
/* 1854 */       return reActionDesc[action];
/*      */     }
/* 1856 */     return reActionNames[action];
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void calcColumnWidths(JTable table, int minColumns)
/*      */   {
/* 1866 */     int screenWidth = table.getVisibleRect().width;
/*      */     
/* 1868 */     int maxColWidth = Math.max(screenWidth * 2 / 3, 100);
/*      */     
/*      */ 
/* 1871 */     calcColumnWidths(table, minColumns, maxColWidth);
/*      */   }
/*      */   
/*      */   public static void calcColumnWidths(JTable table, int minColumns, int maxColWidth) {
/* 1875 */     JTableHeader header = table.getTableHeader();
/*      */     
/* 1877 */     TableCellRenderer defaultHeaderRenderer = null;
/*      */     
/* 1879 */     if (header != null) {
/* 1880 */       defaultHeaderRenderer = header.getDefaultRenderer();
/*      */     }
/*      */     
/* 1883 */     TableColumnModel columns = table.getColumnModel();
/* 1884 */     TableModel data = table.getModel();
/*      */     
/* 1886 */     int margin = Math.min(4, columns.getColumnMargin());
/* 1887 */     Rectangle visbleRect = table.getVisibleRect();
/* 1888 */     int screenWidth = visbleRect.width;
/* 1889 */     int screenStart = visbleRect.y;
/*      */     
/*      */ 
/* 1892 */     if (screenWidth == 0) {
/* 1893 */       Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
/* 1894 */       screenWidth = dim.width - 34;
/*      */     }
/*      */     
/* 1897 */     int firstRow = Math.max(0, screenStart - 200);
/* 1898 */     int rowCount = Math.min(data.getRowCount(), 400);
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1907 */     for (int i = columns.getColumnCount() - 1; i >= 0; i--) {
/* 1908 */       TableColumn column = columns.getColumn(i);
/*      */       
/* 1910 */       int width = -1;
/*      */       
/* 1912 */       TableCellRenderer h = column.getHeaderRenderer();
/*      */       
/* 1914 */       if (h == null) {
/* 1915 */         h = defaultHeaderRenderer;
/*      */       }
/*      */       
/* 1918 */       if (h != null) {
/* 1919 */         Component c = h.getTableCellRendererComponent(table, column.getHeaderValue(), false, false, -1, i);
/*      */         
/*      */ 
/* 1922 */         width = c.getPreferredSize().width;
/*      */       }
/*      */       
/* 1925 */       width = getColumnWidth(table, i, firstRow, rowCount, width);
/*      */       
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 1939 */       if (width >= 0)
/*      */       {
/* 1941 */         if (columns.getColumnCount() == minColumns) {
/* 1942 */           column.setPreferredWidth(width + margin);
/*      */         } else {
/* 1944 */           column.setPreferredWidth(Math.min(width + margin, maxColWidth));
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int getColumnWidth(JTable table, int idx, int firstRow, int rowCount, int defaultWidth)
/*      */   {
/* 1958 */     int width = defaultWidth;
/* 1959 */     int columnIndex = table.getColumnModel().getColumn(idx).getModelIndex();
/* 1960 */     TableModel data = table.getModel();
/*      */     
/*      */ 
/*      */ 
/*      */ 
/* 1965 */     for (int row = rowCount - 1; row >= firstRow; row--) {
/* 1966 */       TableCellRenderer r = table.getCellRenderer(row, idx);
/*      */       try
/*      */       {
/* 1969 */         Component c = r.getTableCellRendererComponent(table, data.getValueAt(row, columnIndex), false, false, row, idx);
/*      */         
/*      */ 
/*      */ 
/* 1973 */         width = Math.max(width, c.getPreferredSize().width);
/*      */       } catch (Exception e) {
/* 1975 */         System.out.println("Error Row,col= " + row + ", " + columnIndex);
/*      */       }
/*      */     }
/* 1978 */     return width;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int[] readIntPropertiesArray(String prefix, int numberInArray)
/*      */   {
/* 1992 */     int[] ret = null;
/*      */     
/*      */ 
/*      */ 
/* 1996 */     for (int i = 0; i < numberInArray; i++) {
/* 1997 */       String s = Parameters.getString(prefix + i);
/* 1998 */       if ((s != null) && (!"".equals(s))) {
/*      */         try {
/* 2000 */           int id = Integer.parseInt(s);
/* 2001 */           if (ret == null) {
/* 2002 */             ret = new int[numberInArray];
/* 2003 */             for (int j = 0; j < numberInArray; j++) {
/* 2004 */               ret[j] = -121;
/*      */             }
/*      */           }
/* 2007 */           ret[i] = id;
/*      */         } catch (Exception e) {
/* 2009 */           logMsg(30, "Error Loading Array, Index:", i + " " + s + " " + "TypeClass." + " " + e.getMessage(), null);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2018 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Object[] readPropertiesArray(int[] ids, String prefix)
/*      */   {
/* 2031 */     Object[] ret = null;
/*      */     
/* 2033 */     if (ids != null) {
/* 2034 */       ret = readPropertiesArrayImp(ids, prefix, ids.length);
/*      */     }
/* 2036 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static Object[] readPropertiesArray(String prefix, int numberInArray)
/*      */   {
/* 2048 */     return readPropertiesArrayImp(null, prefix, numberInArray);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   private static Object[] readPropertiesArrayImp(int[] ids, String prefix, int numberInArray)
/*      */   {
/* 2062 */     Object[] ret = null;
/*      */     
/*      */ 
/* 2065 */     for (int i = 0; i < numberInArray; i++) {
/* 2066 */       if ((ids == null) || (ids[i] != -121)) {
/* 2067 */         String s = Parameters.getString(prefix + i);
/* 2068 */         if ((s != null) && (!"".equals(s))) {
/*      */           try
/*      */           {
/* 2071 */             if (ret == null) {
/* 2072 */               ret = new Object[numberInArray];
/* 2073 */               for (int j = 0; j < numberInArray; j++) {
/* 2074 */                 ret[j] = null;
/*      */               }
/*      */             }
/* 2077 */             ret[i] = Class.forName(s).newInstance();
/*      */           } catch (Exception e) {
/* 2079 */             logMsg(30, "Error Loading Property:", i + " " + e.getMessage(), null);
/*      */             
/*      */ 
/*      */ 
/* 2083 */             e.printStackTrace();
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 2088 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static String stripDirectory(String fileName)
/*      */   {
/* 2098 */     if (fileName == null) {
/* 2099 */       return null;
/*      */     }
/*      */     
/* 2102 */     return new File(fileName).getName();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static int getConnectionIndex()
/*      */   {
/* 2123 */     if (searchActiveDB) {
/*      */       try {
/* 2125 */         initVars();
/* 2126 */         makeConnection(connectionIndex);
/* 2127 */         searchActiveDB = false;
/*      */       } catch (Exception e) {
/* 2129 */         boolean hsqlServer = (dataSource[connectionIndex] != null) && (dataSource[connectionIndex].toLowerCase().startsWith("jdbc:hsqldb:hsql:"));
/*      */         
/* 2131 */         for (int i = 0; i < 16; i++) {
/* 2132 */           if ((i != connectionIndex) && (dataSource[i] != null) && (!"".equals(dataSource[i].trim()))) {
/*      */             try {
/* 2134 */               makeConnection(i);
/* 2135 */               connectionIndex = i;
/* 2136 */               searchActiveDB = false;
/*      */             }
/*      */             catch (Exception ex) {}
/*      */           }
/*      */         }
/*      */         
/*      */ 
/* 2143 */         if ((hsqlServer) && (toWarn) && (dataSource[connectionIndex] != null) && (dataSource[connectionIndex].toLowerCase().startsWith("jdbc:hsqldb:file:")))
/*      */         {
/*      */ 
/* 2146 */           String message = LangConversion.convertId(2, "DB001", "\t********************   Warning ***************************\nTried to Connect to the HSQL Data Base Server and failed. Will run in Database embedded mode.\nThis package works best in Data Base Server Mode (option on menu, exit this program before you start the Server).\n\nIf you wish to use the package in imbeded Mode, You may wish to reveiw the Database\nOptions (Menu option Edit >>> Edit Startup options) \n 1) Properties >>>> Defaults     then click on the Default DB tab. You can now select the Normal DB Connection\n 2) JDBC Parameters >>> JDBC Properties ~  Auto Close Connection. Setting it to Y will alow\n multiple versions of the RecordEditor to be run at once, but you may have update problems\n\nSee \"Improving the running of RecordEditor HSQL\" section in HowTo documnetation for more details");
/*      */           
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/* 2162 */           logMsgRaw(message, null);
/*      */         }
/*      */       }
/*      */     }
/*      */     
/* 2167 */     return connectionIndex;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final int getCopybookWriterIndex()
/*      */   {
/* 2185 */     if (copybookWriterIndex < 0) {
/* 2186 */       CopybookWriterManager manager = CopybookWriterManager.getInstance();
/* 2187 */       String name = Parameters.getString("CopyBookWriter");
/* 2188 */       copybookWriterIndex = 1;
/* 2189 */       if ((name != null) && (!"".equals(name))) {
/* 2190 */         for (int i = 0; i < manager.getNumberOfEntries(); i++) {
/* 2191 */           if (name.equalsIgnoreCase(manager.getName(i))) {
/* 2192 */             copybookWriterIndex = i;
/* 2193 */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 2198 */     return copybookWriterIndex;
/*      */   }
/*      */   
/*      */   public static final String trimRight(Object o)
/*      */   {
/* 2203 */     if ((o == null) || ("".equals(o)) || ("".equals(o.toString().trim()))) {
/* 2204 */       return "";
/*      */     }
/*      */     
/* 2207 */     String s = o.toString();
/* 2208 */     int l = s.length() - 1;
/*      */     
/* 2210 */     while (s.charAt(l) == ' ') {
/* 2211 */       l--;
/*      */     }
/*      */     
/* 2214 */     return s.substring(0, l + 1);
/*      */   }
/*      */   
/*      */   public static final String fix(String s) {
/* 2218 */     if (s == null) {
/* 2219 */       return "";
/*      */     }
/* 2221 */     return s;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final boolean isSetDoFree(boolean free)
/*      */   {
/* 2262 */     boolean ret = doFree;
/* 2263 */     doFree = free;
/* 2264 */     return ret;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static final void setDoFree(boolean free, int idx)
/*      */   {
/* 2272 */     doFree = free;
/* 2273 */     freeConnection(idx);
/*      */   }
/*      */   
/*      */   public static final boolean usePrefered() {
/* 2277 */     return OPTIONS.usePrefered.isSelected();
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public static void runOptionalyInBackground(Runnable runnable)
/*      */   {
/* 2354 */     if (OPTIONS.loadInBackgroundThread.isSelected()) {
/* 2355 */       new Thread(runnable).start();
/*      */     } else {
/* 2357 */       runnable.run();
/*      */     }
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */   public static boolean isEmpty(Object value)
/*      */   {
/* 2366 */     return (value == null) || (value == MISSING_VALUE) || (value == MISSING_REQUIRED_VALUE);
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static long getMemoryCompare()
/*      */   {
/* 2373 */     BigDecimal pct = BigDecimal.valueOf(OPTIONS.bigFilePercent.get());
/* 2374 */     BigDecimal calc = MAX_MEMORY_BD.multiply(pct);
/* 2375 */     calc = calc.divide(BigDecimal.valueOf(100L));
/*      */     
/* 2377 */     return calc.longValue();
/*      */   }
/*      */   
/*      */   public static int toInt(byte b) {
/* 2381 */     int i = b;
/* 2382 */     if (i < 0) {
/* 2383 */       i += 256;
/*      */     }
/* 2385 */     return i;
/*      */   }
/*      */   
/*      */   public static void setDBstatus(boolean dbPresent)
/*      */   {
/* 2390 */     if (!dbPresent) {
/* 2391 */       searchActiveDB = false;
/* 2392 */       connectionIndex = 0;
/*      */     }
/*      */   }
/*      */   
/*      */   public static String currentVersion() {
/* 2397 */     return formatVersion("0097g");
/*      */   }
/*      */   
/*      */   public static String formatVersion(String s) {
/* 2401 */     s = s.substring(0, 2) + '.' + s.substring(2);
/* 2402 */     if (s.startsWith("0")) {
/* 2403 */       s = s.substring(1);
/*      */     }
/* 2405 */     return s;
/*      */   }
/*      */   
/*      */   public static void createDirectory(File f) throws IOException
/*      */   {
/* 2410 */     if (!f.exists())
/*      */     {
/* 2412 */       if (JAVA_VERSION >= 1.699D) {
/* 2413 */         Files.createDirectories(f.toPath(), new FileAttribute[0]);
/*      */       } else
/* 2415 */         f.mkdirs();
/*      */     }
/*      */   }
/*      */   
/*      */   public static boolean exists(String filename) {
/* 2420 */     return Parameters.exists(filename);
/*      */   }
/*      */ }


/* Location:              /home/eguo/workspace/RecordEditor/lib/RecordEdit.jar!/net/sf/RecordEditor/utils/common/Common.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */